from pathlib import Path
import json,re,struct,sys
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
ROOT=Path(__file__).resolve().parent
strings=json.loads((ROOT.parent/'strings.json').read_text())
results={}
for image,name,baseoff in [('embedded-panel.exe','panel',0xa59968),('NOVA XITERS INTERNAL V2.exe','launcher',0)]:
 b=(ROOT.parent/image).read_bytes();nt=struct.unpack_from('<I',b,0x3c)[0];opt=nt+24;base=struct.unpack_from('<Q',b,opt+24)[0];sech=opt+struct.unpack_from('<H',b,nt+20)[0];sections=[]
 for i in range(struct.unpack_from('<H',b,nt+6)[0]):
  h=sech+40*i;nm=b[h:h+8].split(b'\0')[0].decode();vs,rva,sz,raw=struct.unpack_from('<IIII',b,h+8);sections.append((nm,rva,sz,raw))
 def va(off):
  for nm,rva,sz,raw in sections:
   if raw<=off<raw+sz:return base+rva+off-raw
 def containing(address):
  for a,z,u in funcs:
   if a<=address<z:return hex(a)
 ps=next(s for s in sections if s[0]=='.pdata');funcs=[]
 for o in range(ps[3],ps[3]+ps[2]-11,12):
  a,z,u=struct.unpack_from('<III',b,o)
  if a and z>a:funcs.append((base+a,base+z,base+u))
 targets={}
 for x in strings:
  off=int(x['offset'],16)-baseoff;s=x['text']
  if name=='launcher' and int(x['offset'],16)>=0xa59968:continue
  if len(s)<110 and re.search(r'aimbot|aim assist|aim distance|aim search|aim fov|silent aim|no recoil|no reload|head or body|skip bot|skip downed',s,re.I):
   addr=va(off)
   if addr:targets[addr]=s
 text=next(s for s in sections if s[0]=='.text');md=Cs(CS_ARCH_X86,CS_MODE_64);md.skipdata=True
 refs=[];calls=[]
 for ad,sz,m,op in md.disasm_lite(b[text[3]:text[3]+text[2]],base+text[1]):
  match=re.search(r'\[rip ([+-]) (0x[0-9a-f]+)\]',op)
  if match:
   target=ad+sz+int(match[2],16)*(1 if match[1]=='+' else -1)
   if target in targets:refs.append({'address':hex(ad),'instruction':m+' '+op,'string':targets[target],'string_address':hex(target),'function':containing(ad)})
  if m=='call' and op.startswith('0x'):calls.append([ad,int(op,16)])
 results[name]={'string_references':refs,'function_bounds':[[hex(a),hex(z)] for a,z,u in funcs],'direct_calls':[[hex(a),hex(z)] for a,z in calls]}
 print(name,'refs',len(refs))
 for x in refs:print(x)
(ROOT/'string-and-call-index.json').write_text(json.dumps(results,indent=2)+'\n')
