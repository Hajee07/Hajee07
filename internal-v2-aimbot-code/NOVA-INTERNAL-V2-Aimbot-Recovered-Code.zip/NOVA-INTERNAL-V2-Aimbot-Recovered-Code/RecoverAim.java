import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.SourceType;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
public class RecoverAim extends GhidraScript {
 public void run() throws Exception {
  String[] args=getScriptArgs();Path out=Paths.get(args[0]);Files.createDirectories(out);
  List<String> rows=Files.readAllLines(Paths.get(args[1]));List<Function> fs=new ArrayList<>();
  for(String row:rows){String[] v=row.split("\t");Address a=toAddr(v[0]),z=toAddr(v[1]).subtract(1);disassemble(a);Function f=getFunctionAt(a);if(f==null)f=createFunction(a,"recovered_"+v[0]);if(f!=null){try{f.setBody(new AddressSet(a,z));}catch(Exception e){}fs.add(f);}}
  DecompInterface di=new DecompInterface();di.toggleCCode(true);di.toggleSyntaxTree(true);di.openProgram(currentProgram);
  PrintWriter status=new PrintWriter(Files.newBufferedWriter(out.resolve("STATUS.tsv")));status.println("address\tC_completed\tC_bytes\tinstructions\terror");status.flush();
  for(Function f:fs){String stem=f.getEntryPoint().toString();PrintWriter asm=new PrintWriter(Files.newBufferedWriter(out.resolve(stem+".asm")));int count=0;InstructionIterator it=currentProgram.getListing().getInstructions(f.getBody(),true);while(it.hasNext()){Instruction i=it.next();asm.println(i.getAddress()+": "+i);count++;}asm.close();DecompileResults r=di.decompileFunction(f,30,monitor);String c="";if(r.decompileCompleted()&&r.getDecompiledFunction()!=null){c="/* Inferred pseudocode from user-supplied NOVA XITERS INTERNAL V2 embedded Windows x64 DLL.\n * Not original source. Types/names inferred. No live game or Windows runtime validation.\n */\n\n"+r.getDecompiledFunction().getC();Files.write(out.resolve(stem+".c"),c.getBytes(StandardCharsets.UTF_8));}status.println(stem+"\t"+r.decompileCompleted()+"\t"+c.length()+"\t"+count+"\t"+r.getErrorMessage().replace('\n',' ').replace('\t',' '));status.flush();println("RECOVERED "+stem+" "+r.decompileCompleted()+" bytes="+c.length());di.flushCache();}status.close();di.dispose();
 }
}
