1800afa60: MOV qword ptr [RSP + 0x8],RBX
1800afa65: MOV qword ptr [RSP + 0x10],RDI
1800afa6a: PUSH RBP
1800afa6b: LEA RBP,[RSP + -0x680]
1800afa73: SUB RSP,0x780
1800afa7a: XORPS XMM0,XMM0
1800afa7d: LEA RCX,[RBP + -0x74]
1800afa81: MOVUPS xmmword ptr [RSP + 0x30],XMM0
1800afa86: XOR EAX,EAX
1800afa88: MOV dword ptr [RSP + 0x30],0x44960000
1800afa90: MOVUPS xmmword ptr [RSP + 0x70],XMM0
1800afa95: MOV qword ptr [RBP + -0x80],RAX
1800afa99: XOR EDI,EDI
1800afa9b: MOVUPS xmmword ptr [RSP + 0x40],XMM0
1800afaa0: MOV word ptr [RSP + 0x3c],AX
1800afaa5: XOR EDX,EDX
1800afaa7: MOVUPS xmmword ptr [RSP + 0x50],XMM0
1800afaac: MOV byte ptr [RSP + 0x52],AL
1800afab0: MOV R8D,0x118
1800afab6: MOVUPS xmmword ptr [RSP + 0x60],XMM0
1800afabb: MOV word ptr [RSP + 0x64],AX
1800afac0: MOVUPS xmmword ptr [RSP + 0x20],XMM0
1800afac5: MOV byte ptr [RSP + 0x66],AL
1800afac9: MOVDQA XMM0,xmmword ptr [0x181a036d0]
1800afad1: MOVDQU xmmword ptr [RSP + 0x68],XMM0
1800afad7: MOV qword ptr [RBP + -0x7c],0x42f00000
1800afadf: MOV word ptr [RBP + -0x78],AX
1800afae3: MOV EAX,dword ptr [RBP + -0x78]
1800afae6: MOV dword ptr [RSP + 0x2c],0x64
1800afaee: MOVUPS XMM0,xmmword ptr [RSP + 0x20]
1800afaf3: MOV qword ptr [RSP + 0x34],0x1
1800afafc: MOVUPS XMM1,xmmword ptr [RSP + 0x30]
1800afb01: MOV qword ptr [RSP + 0x40],RDI
1800afb06: MOVAPS xmmword ptr [0x181b2b400],XMM0
1800afb0d: MOVAPS xmmword ptr [0x181b2b410],XMM1
1800afb14: MOV dword ptr [RSP + 0x48],0x44960000
1800afb1c: MOV dword ptr [RSP + 0x4c],0x3f800000
1800afb24: MOVUPS XMM0,xmmword ptr [RSP + 0x40]
1800afb29: MOV dword ptr [RSP + 0x54],0x3f800000
1800afb31: MOVUPS XMM1,xmmword ptr [RSP + 0x50]
1800afb36: MOV dword ptr [RSP + 0x78],0x5
1800afb3e: MOVAPS xmmword ptr [0x181b2b420],XMM0
1800afb45: MOVUPS XMM0,xmmword ptr [RSP + 0x60]
1800afb4a: MOV dword ptr [RSP + 0x7c],0x14
1800afb52: MOVAPS xmmword ptr [0x181b2b430],XMM1
1800afb59: MOVUPS XMM1,xmmword ptr [RSP + 0x70]
1800afb5e: MOV dword ptr [RBP + -0x80],0x96
1800afb65: MOVAPS xmmword ptr [0x181b2b440],XMM0
1800afb6c: MOVSD XMM0,qword ptr [RBP + -0x80]
1800afb71: MOVSD qword ptr [0x181b2b460],XMM0
1800afb79: MOVAPS xmmword ptr [0x181b2b450],XMM1
1800afb80: MOV dword ptr [0x181b2b468],EAX
1800afb86: CALL 0x1801ca899
1800afb8b: LEA RCX,[RBP + -0x74]
1800afb8f: CALL 0x180052c60
1800afb94: MOV EBX,0x2
1800afb99: LEA RCX,[0x181b2b46c]
1800afba0: MOV EDX,EBX
1800afba2: LEA RCX,[RCX + 0x80]
1800afba9: MOVUPS XMM0,xmmword ptr [RAX]
1800afbac: LEA RAX,[RAX + 0x80]
1800afbb3: MOVUPS xmmword ptr [RCX + -0x80],XMM0
1800afbb7: MOVUPS XMM1,xmmword ptr [RAX + -0x70]
1800afbbb: MOVUPS xmmword ptr [RCX + -0x70],XMM1
1800afbbf: MOVUPS XMM0,xmmword ptr [RAX + -0x60]
1800afbc3: MOVUPS xmmword ptr [RCX + -0x60],XMM0
1800afbc7: MOVUPS XMM1,xmmword ptr [RAX + -0x50]
1800afbcb: MOVUPS xmmword ptr [RCX + -0x50],XMM1
1800afbcf: MOVUPS XMM0,xmmword ptr [RAX + -0x40]
1800afbd3: MOVUPS xmmword ptr [RCX + -0x40],XMM0
1800afbd7: MOVUPS XMM1,xmmword ptr [RAX + -0x30]
1800afbdb: MOVUPS xmmword ptr [RCX + -0x30],XMM1
1800afbdf: MOVUPS XMM0,xmmword ptr [RAX + -0x20]
1800afbe3: MOVUPS xmmword ptr [RCX + -0x20],XMM0
1800afbe7: MOVUPS XMM1,xmmword ptr [RAX + -0x10]
1800afbeb: MOVUPS xmmword ptr [RCX + -0x10],XMM1
1800afbef: SUB RDX,0x1
1800afbf3: JNZ 0x1800afba2
1800afbf5: MOVUPS XMM0,xmmword ptr [RAX]
1800afbf8: MOV R8D,0x6e8
1800afbfe: MOVUPS xmmword ptr [RCX],XMM0
1800afc01: MOV RAX,qword ptr [RAX + 0x10]
1800afc05: MOVDQA XMM0,xmmword ptr [0x181a03970]
1800afc0d: MOV qword ptr [RCX + 0x10],RAX
1800afc11: LEA RCX,[RBP + -0x74]
1800afc15: MOV byte ptr [0x181b2b46c],0x1
1800afc1c: MOV dword ptr [0x181b2b57c],0xa0
1800afc26: MOV dword ptr [0x181b2b478],0x3f800000
1800afc30: MOV dword ptr [0x181b2b47c],0x3f800000
1800afc3a: MOV dword ptr [0x181b2b480],0x3f800000
1800afc44: MOV dword ptr [0x181b2b484],0x3f800000
1800afc4e: MOVAPS xmmword ptr [0x181b2b4a0],XMM0
1800afc55: MOV dword ptr [0x181b2b53c],0x3f800000
1800afc5f: MOV dword ptr [0x181b2b540],0x3f800000
1800afc69: MOV dword ptr [0x181b2b544],0x3f800000
1800afc73: MOV dword ptr [0x181b2b548],0x3f800000
1800afc7d: MOV dword ptr [0x181b2b4c8],0x3f800000
1800afc87: MOV dword ptr [0x181b2b4cc],0x3f800000
1800afc91: MOV dword ptr [0x181b2b4d0],0x3f800000
1800afc9b: MOV dword ptr [0x181b2b4d4],0x3f800000
1800afca5: MOV dword ptr [0x181b2b4dc],0x3f800000
1800afcaf: MOV dword ptr [0x181b2b4e0],0x3f800000
1800afcb9: MOV dword ptr [0x181b2b4e4],0x3f800000
1800afcc3: MOV dword ptr [0x181b2b4e8],0x3f800000
1800afccd: MOVAPS xmmword ptr [0x181b2b550],XMM0
1800afcd4: CALL 0x1801ca899
1800afcd9: LEA RCX,[RBP + -0x74]
1800afcdd: CALL 0x180052e70
1800afce2: MOV RDX,RAX
1800afce5: LEA RCX,[0x181b2b584]
1800afcec: CALL 0x1800afec0
1800afcf1: MOV R8D,0x10c
1800afcf7: LEA RCX,[RBP + -0x74]
1800afcfb: XOR EDX,EDX
1800afcfd: CALL 0x1801ca899
1800afd02: XORPS XMM0,XMM0
1800afd05: MOV dword ptr [RBP + -0x72],0x1
1800afd0c: XOR EAX,EAX
1800afd0e: MOV dword ptr [RBP + -0x6c],0x1
1800afd15: MOVUPS xmmword ptr [RBP + -0x67],XMM0
1800afd19: MOV qword ptr [RBP + -0x37],RAX
1800afd1d: LEA RCX,[0x181b2bc6c]
1800afd24: MOVUPS xmmword ptr [RBP + -0x57],XMM0
1800afd28: MOV qword ptr [RBP + -0x2f],RAX
1800afd2c: LEA RDX,[RBP + -0x74]
1800afd30: MOVUPS xmmword ptr [RBP + -0x47],XMM0
1800afd34: MOV qword ptr [RBP + 0x9],RAX
1800afd38: MOVUPS xmmword ptr [RBP + -0x27],XMM0
1800afd3c: MOV qword ptr [RBP + 0x11],RAX
1800afd40: MOVUPS xmmword ptr [RBP + -0x17],XMM0
1800afd44: MOV qword ptr [RBP + 0x89],RAX
1800afd4b: MOVUPS xmmword ptr [RBP + -0x7],XMM0
1800afd4f: MOV dword ptr [RBP + 0x91],EAX
1800afd55: MOVUPS xmmword ptr [RBP + 0x19],XMM0
1800afd59: MOV word ptr [RBP + 0x95],AX
1800afd60: MOVUPS xmmword ptr [RBP + 0x29],XMM0
1800afd64: MOV byte ptr [RBP + 0x97],AL
1800afd6a: MOVUPS xmmword ptr [RBP + 0x39],XMM0
1800afd6e: MOV byte ptr [RBP + -0x68],DIL
1800afd72: MOVUPS xmmword ptr [RBP + 0x49],XMM0
1800afd76: MOVUPS xmmword ptr [RBP + 0x59],XMM0
1800afd7a: MOVUPS xmmword ptr [RBP + 0x69],XMM0
1800afd7e: MOVUPS xmmword ptr [RBP + 0x79],XMM0
1800afd82: LEA RCX,[RCX + 0x80]
1800afd89: MOVUPS XMM0,xmmword ptr [RDX]
1800afd8c: MOVUPS XMM1,xmmword ptr [RDX + 0x10]
1800afd90: LEA RDX,[RDX + 0x80]
1800afd97: MOVUPS xmmword ptr [RCX + -0x80],XMM0
1800afd9b: MOVUPS XMM0,xmmword ptr [RDX + -0x60]
1800afd9f: MOVUPS xmmword ptr [RCX + -0x70],XMM1
1800afda3: MOVUPS XMM1,xmmword ptr [RDX + -0x50]
1800afda7: MOVUPS xmmword ptr [RCX + -0x60],XMM0
1800afdab: MOVUPS XMM0,xmmword ptr [RDX + -0x40]
1800afdaf: MOVUPS xmmword ptr [RCX + -0x50],XMM1
1800afdb3: MOVUPS XMM1,xmmword ptr [RDX + -0x30]
1800afdb7: MOVUPS xmmword ptr [RCX + -0x40],XMM0
1800afdbb: MOVUPS XMM0,xmmword ptr [RDX + -0x20]
1800afdbf: MOVUPS xmmword ptr [RCX + -0x30],XMM1
1800afdc3: MOVUPS XMM1,xmmword ptr [RDX + -0x10]
1800afdc7: MOVUPS xmmword ptr [RCX + -0x20],XMM0
1800afdcb: MOVUPS xmmword ptr [RCX + -0x10],XMM1
1800afdcf: SUB RBX,0x1
1800afdd3: JNZ 0x1800afd82
1800afdd5: MOV RAX,qword ptr [RDX]
1800afdd8: MOV R8D,0x270f
1800afdde: MOV qword ptr [RCX],RAX
1800afde1: MOV EAX,dword ptr [RDX + 0x8]
1800afde4: XOR EDX,EDX
1800afde6: MOV dword ptr [RCX + 0x8],EAX
1800afde9: LEA RCX,[0x181b30430]
1800afdf0: MOV byte ptr [0x181b2bc6e],0x1
1800afdf7: CALL 0x1801ca899
1800afdfc: XOR EDX,EDX
1800afdfe: LEA RCX,[0x181b32b80]
1800afe05: MOV R8D,0x2f90
1800afe0b: CALL 0x1801ca899
1800afe10: LEA RCX,[0x1819dce90]
1800afe17: MOV byte ptr [0x181b2f8c9],DIL
1800afe1e: MOV dword ptr [0x181b32b7c],EDI
1800afe24: MOV dword ptr [0x181b303b8],EDI
1800afe2a: MOV dword ptr [0x181b32b54],EDI
1800afe30: MOV dword ptr [0x181b32b64],EDI
1800afe36: MOV dword ptr [0x181b32b4c],EDI
1800afe3c: MOV dword ptr [0x181b303bc],EDI
1800afe42: MOV dword ptr [0x181b30428],EDI
1800afe48: MOV dword ptr [0x181b30420],EDI
1800afe4e: MOV dword ptr [0x181b32b50],EDI
1800afe54: MOV dword ptr [0x181ade2b8],EDI
1800afe5a: MOV dword ptr [0x181b32b78],EDI
1800afe60: MOV dword ptr [0x181b3042c],EDI
1800afe66: MOV dword ptr [0x181b32b48],EDI
1800afe6c: MOV dword ptr [0x181b32b40],EDI
1800afe72: MOV dword ptr [0x181ade1f8],0x77
1800afe7c: MOV byte ptr [0x181ade204],0x1
1800afe83: MOV dword ptr [0x181b32b60],EDI
1800afe89: MOV byte ptr [0x181b2f6dd],0x1
1800afe90: MOV byte ptr [0x181b2bede],DIL
1800afe97: LEA R11,[RSP + 0x780]
1800afe9f: MOV RBX,qword ptr [R11 + 0x10]
1800afea3: MOV RDI,qword ptr [R11 + 0x18]
1800afea7: MOV RSP,R11
1800afeaa: POP RBP
1800afeab: JMP qword ptr [0x1801d2d38]
