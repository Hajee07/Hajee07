1800aeb50: MOV qword ptr [RSP + 0x18],RBX
1800aeb55: PUSH RBP
1800aeb56: PUSH RSI
1800aeb57: PUSH RDI
1800aeb58: LEA RBP,[RSP + -0xc0]
1800aeb60: SUB RSP,0x1c0
1800aeb67: MOVAPS xmmword ptr [RSP + 0x1b0],XMM6
1800aeb6f: XOR EDI,EDI
1800aeb71: MOV dword ptr [RBP + 0xe0],EDI
1800aeb77: LEA RCX,[RBP + -0x80]
1800aeb7b: CALL 0x1800ae560
1800aeb80: NOP
1800aeb81: MOV R8D,0xc
1800aeb87: LEA RDX,[0x1819dceb8]
1800aeb8e: MOV RCX,RAX
1800aeb91: CALL 0x180066ec0
1800aeb96: XORPS XMM0,XMM0
1800aeb99: MOVUPS xmmword ptr [RSP + 0x60],XMM0
1800aeb9e: XORPS XMM1,XMM1
1800aeba1: MOVDQU xmmword ptr [RSP + 0x70],XMM1
1800aeba7: MOVUPS XMM0,xmmword ptr [RAX]
1800aebaa: MOVUPS xmmword ptr [RSP + 0x60],XMM0
1800aebaf: MOVUPS XMM1,xmmword ptr [RAX + 0x10]
1800aebb3: MOVUPS xmmword ptr [RSP + 0x70],XMM1
1800aebb8: MOV qword ptr [RAX + 0x10],RDI
1800aebbc: MOV qword ptr [RAX + 0x18],0xf
1800aebc4: MOV byte ptr [RAX],DIL
1800aebc7: LEA RCX,[RBP + -0x80]
1800aebcb: CALL 0x180066e40
1800aebd0: NOP
1800aebd1: LEA RBX,[RSP + 0x60]
1800aebd6: CMP qword ptr [RSP + 0x78],0xf
1800aebdc: CMOVA RBX,qword ptr [RSP + 0x60]
1800aebe2: LEA RAX,[0x1819de2c8]
1800aebe9: MOV qword ptr [RBP + -0x60],RAX
1800aebed: LEA RCX,[RBP + 0x50]
1800aebf1: CALL qword ptr [0x1801d2818]
1800aebf7: NOP
1800aebf8: MOV dword ptr [RBP + 0xe0],0x7
1800aec02: XOR R9D,R9D
1800aec05: XOR R8D,R8D
1800aec08: LEA RDX,[RBP + -0x50]
1800aec0c: LEA RCX,[RBP + -0x60]
1800aec10: CALL qword ptr [0x1801d2678]
1800aec16: NOP
1800aec17: MOV RAX,qword ptr [RBP + -0x60]
1800aec1b: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aec1f: LEA RSI,[0x1801f22f0]
1800aec26: MOV qword ptr [RBP + RCX*0x1 + -0x60],RSI
1800aec2b: MOV RAX,qword ptr [RBP + -0x60]
1800aec2f: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aec33: LEA EDX,[RCX + -0xb0]
1800aec39: MOV dword ptr [RBP + RCX*0x1 + -0x64],EDX
1800aec3d: LEA RCX,[RBP + -0x50]
1800aec41: CALL qword ptr [0x1801d2810]
1800aec47: LEA RAX,[0x1801f2270]
1800aec4e: MOV qword ptr [RBP + -0x50],RAX
1800aec52: MOV byte ptr [RBP + 0x2c],DIL
1800aec56: MOV byte ptr [RBP + 0x21],DIL
1800aec5a: LEA RCX,[RBP + -0x50]
1800aec5e: CALL qword ptr [0x1801d2670]
1800aec64: MOV qword ptr [RBP + 0x30],RDI
1800aec68: MOV RAX,qword ptr [0x181b50d48]
1800aec6f: MOV qword ptr [RBP + 0x24],RAX
1800aec73: MOV qword ptr [RBP + 0x18],RDI
1800aec77: MOV R9D,0x40
1800aec7d: MOV R8D,0x21
1800aec83: MOV RDX,RBX
1800aec86: LEA RCX,[RBP + -0x50]
1800aec8a: CALL 0x1800bbbc0
1800aec8f: TEST RAX,RAX
1800aec92: JNZ 0x1800aecb2
1800aec94: MOV RAX,qword ptr [RBP + -0x60]
1800aec98: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aec9c: LEA RAX,[RBP + -0x60]
1800aeca0: ADD RCX,RAX
1800aeca3: XOR R8D,R8D
1800aeca6: MOV EDX,0x2
1800aecab: CALL qword ptr [0x1801d2760]
1800aecb1: NOP
1800aecb2: MOV RAX,qword ptr [RBP + -0x60]
1800aecb6: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aecba: MOV qword ptr [RBP + RCX*0x1 + -0x60],RSI
1800aecbf: MOV RAX,qword ptr [RBP + -0x60]
1800aecc3: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aecc7: LEA EDX,[RCX + -0xb0]
1800aeccd: MOV dword ptr [RBP + RCX*0x1 + -0x64],EDX
1800aecd1: MOV RDX,qword ptr [RSP + 0x78]
1800aecd6: CMP RDX,0xf
1800aecda: JBE 0x1800aed20
1800aecdc: INC RDX
1800aecdf: MOV RCX,qword ptr [RSP + 0x60]
1800aece4: MOV RAX,RCX
1800aece7: CMP RDX,0x1000
1800aecee: JC 0x1800aed1b
1800aecf0: ADD RDX,0x27
1800aecf4: MOV RCX,qword ptr [RCX + -0x8]
1800aecf8: SUB RAX,RCX
1800aecfb: SUB RAX,0x8
1800aecff: CMP RAX,0x1f
1800aed03: JBE 0x1800aed1b
1800aed05: MOV qword ptr [RSP + 0x20],RDI
1800aed0a: XOR R9D,R9D
1800aed0d: XOR R8D,R8D
1800aed10: XOR EDX,EDX
1800aed12: XOR ECX,ECX
1800aed14: CALL qword ptr [0x1801d2e48]
1800aed1a: INT3
1800aed1b: CALL 0x180127e40
1800aed20: MOVDQA XMM0,xmmword ptr [0x181a03530]
1800aed28: MOVDQU xmmword ptr [RSP + 0x70],XMM0
1800aed2e: MOV byte ptr [RSP + 0x60],0x0
1800aed33: MOV RAX,qword ptr [RBP + -0x60]
1800aed37: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aed3b: LEA RAX,[RBP + -0x60]
1800aed3f: ADD RCX,RAX
1800aed42: CALL qword ptr [0x1801d26b0]
1800aed48: TEST AL,AL
1800aed4a: JNZ 0x1800aef25
1800aed50: MOV qword ptr [RBP + -0x80],RDI
1800aed54: MOV word ptr [RBP + -0x78],0x1
1800aed5a: MOV RAX,qword ptr [RBP + -0x60]
1800aed5e: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aed62: MOV RCX,qword ptr [RBP + RCX*0x1 + -0x18]
1800aed67: MOV qword ptr [RSP + 0x50],RCX
1800aed6c: TEST RCX,RCX
1800aed6f: SETZ byte ptr [RSP + 0x58]
1800aed74: MOV byte ptr [RSP + 0x59],0x0
1800aed79: XORPS XMM0,XMM0
1800aed7c: MOVUPS xmmword ptr [RSP + 0x30],XMM0
1800aed81: MOV qword ptr [RSP + 0x40],RDI
1800aed86: MOV qword ptr [RSP + 0x48],RDI
1800aed8b: MOVAPS XMM0,xmmword ptr [RSP + 0x50]
1800aed90: MOVAPS xmmword ptr [RSP + 0x50],XMM0
1800aed95: MOVAPS XMM6,xmmword ptr [RBP + -0x80]
1800aed99: TEST RCX,RCX
1800aed9c: JZ 0x1800aedd2
1800aed9e: CALL qword ptr [0x1801d2668]
1800aeda4: CMP EAX,-0x1
1800aeda7: JZ 0x1800aedbe
1800aeda9: MOV byte ptr [RSP + 0x59],AL
1800aedad: MOV RAX,qword ptr [RSP + 0x50]
1800aedb2: MOV byte ptr [RSP + 0x58],0x1
1800aedb7: MOVAPS XMM0,xmmword ptr [RSP + 0x50]
1800aedbc: JMP 0x1800aedd7
1800aedbe: MOV RAX,RDI
1800aedc1: MOV qword ptr [RSP + 0x50],RAX
1800aedc6: MOV byte ptr [RSP + 0x58],0x1
1800aedcb: MOVAPS XMM0,xmmword ptr [RSP + 0x50]
1800aedd0: JMP 0x1800aedd7
1800aedd2: MOVQ RAX,XMM0
1800aedd7: TEST RAX,RAX
1800aedda: MOVQ RAX,XMM6
1800aeddf: JNZ 0x1800aee77
1800aede5: TEST RAX,RAX
1800aede8: JZ 0x1800aee80
1800aedee: MOVDQA xmmword ptr [RBP + -0x80],XMM6
1800aedf3: MOVDQA xmmword ptr [RSP + 0x50],XMM0
1800aedf9: LEA R8,[RBP + -0x80]
1800aedfd: LEA RDX,[RSP + 0x50]
1800aee02: LEA RCX,[RSP + 0x30]
1800aee07: CALL 0x1800b82b0
1800aee0c: MOV RDX,qword ptr [RSP + 0x40]
1800aee11: TEST RDX,RDX
1800aee14: JZ 0x1800aeec2
1800aee1a: NOP word ptr [RAX + RAX*0x1]
1800aee20: LEA RAX,[RSP + 0x30]
1800aee25: MOV RCX,qword ptr [RSP + 0x30]
1800aee2a: MOV R9,qword ptr [RSP + 0x48]
1800aee2f: CMP R9,0xf
1800aee33: CMOVA RAX,RCX
1800aee37: CMP byte ptr [RDX + RAX*0x1 + -0x1],0xd
1800aee3c: JZ 0x1800aee52
1800aee3e: LEA RAX,[RSP + 0x30]
1800aee43: CMP R9,0xf
1800aee47: CMOVA RAX,RCX
1800aee4b: CMP byte ptr [RDX + RAX*0x1 + -0x1],0xa
1800aee50: JNZ 0x1800aee97
1800aee52: DEC RDX
1800aee55: MOV qword ptr [RSP + 0x40],RDX
1800aee5a: LEA RAX,[RSP + 0x30]
1800aee5f: CMP R9,0xf
1800aee63: CMOVA RAX,RCX
1800aee67: MOV byte ptr [RAX + RDX*0x1],0x0
1800aee6b: MOV RDX,qword ptr [RSP + 0x40]
1800aee70: TEST RDX,RDX
1800aee73: JNZ 0x1800aee20
1800aee75: JMP 0x1800aeec2
1800aee77: TEST RAX,RAX
1800aee7a: JZ 0x1800aedee
1800aee80: MOV qword ptr [RSP + 0x40],RDI
1800aee85: MOV R9D,0xf
1800aee8b: MOV qword ptr [RSP + 0x48],R9
1800aee90: MOV byte ptr [RSP + 0x30],0x0
1800aee95: JMP 0x1800aeec7
1800aee97: TEST RDX,RDX
1800aee9a: JZ 0x1800aeecc
1800aee9c: LEA R8,[RSP + 0x30]
1800aeea1: CMP R9,0xf
1800aeea5: CMOVA R8,RCX
1800aeea9: MOV EDX,0x80
1800aeeae: MOV R9,-0x1
1800aeeb5: LEA RCX,[0x181b2bcf8]
1800aeebc: CALL qword ptr [0x1801d3088]
1800aeec2: MOV R9,qword ptr [RSP + 0x48]
1800aeec7: MOV RCX,qword ptr [RSP + 0x30]
1800aeecc: CMP R9,0xf
1800aeed0: JBE 0x1800aef12
1800aeed2: LEA RDX,[R9 + 0x1]
1800aeed6: MOV RAX,RCX
1800aeed9: CMP RDX,0x1000
1800aeee0: JC 0x1800aef0d
1800aeee2: ADD RDX,0x27
1800aeee6: MOV RCX,qword ptr [RCX + -0x8]
1800aeeea: SUB RAX,RCX
1800aeeed: SUB RAX,0x8
1800aeef1: CMP RAX,0x1f
1800aeef5: JBE 0x1800aef0d
1800aeef7: MOV qword ptr [RSP + 0x20],RDI
1800aeefc: XOR R9D,R9D
1800aeeff: XOR R8D,R8D
1800aef02: XOR EDX,EDX
1800aef04: XOR ECX,ECX
1800aef06: CALL qword ptr [0x1801d2e48]
1800aef0c: INT3
1800aef0d: CALL 0x180127e40
1800aef12: MOV qword ptr [RSP + 0x40],RDI
1800aef17: MOV qword ptr [RSP + 0x48],0xf
1800aef20: MOV byte ptr [RSP + 0x30],0x0
1800aef25: MOV RAX,qword ptr [RBP + -0x60]
1800aef29: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aef2d: MOV qword ptr [RBP + RCX*0x1 + -0x60],RSI
1800aef32: MOV RAX,qword ptr [RBP + -0x60]
1800aef36: MOVSXD RCX,dword ptr [RAX + 0x4]
1800aef3a: LEA EDX,[RCX + -0xb0]
1800aef40: MOV dword ptr [RBP + RCX*0x1 + -0x64],EDX
1800aef44: LEA RCX,[RBP + -0x50]
1800aef48: CALL 0x1800b7db0
1800aef4d: LEA RCX,[RBP + -0x48]
1800aef51: CALL qword ptr [0x1801d26a0]
1800aef57: LEA RCX,[RBP + 0x50]
1800aef5b: CALL qword ptr [0x1801d2898]
1800aef61: MOV RBX,qword ptr [RSP + 0x1f0]
1800aef69: MOVAPS XMM6,xmmword ptr [RSP + 0x1b0]
1800aef71: ADD RSP,0x1c0
1800aef78: POP RDI
1800aef79: POP RSI
1800aef7a: POP RBP
1800aef7b: RET
