1800abdc0: MOV qword ptr [RSP + 0x8],RBX
1800abdc5: PUSH RBP
1800abdc6: PUSH RSI
1800abdc7: PUSH RDI
1800abdc8: LEA RBP,[RSP + -0x3f]
1800abdcd: SUB RSP,0xe0
1800abdd4: XOR ESI,ESI
1800abdd6: MOV dword ptr [RBP + -0x61],ECX
1800abdd9: MOV byte ptr [RBP + -0x5d],DL
1800abddc: MOV qword ptr [RBP + -0x59],R8
1800abde0: LEA RAX,[RBP + -0x51]
1800abde4: MOV qword ptr [RBP + 0x6f],RAX
1800abde8: MOV qword ptr [RBP + -0x19],RSI
1800abdec: MOV RCX,qword ptr [R9 + 0x38]
1800abdf0: TEST RCX,RCX
1800abdf3: JZ 0x1800abe02
1800abdf5: MOV RAX,qword ptr [RCX]
1800abdf8: LEA RDX,[RBP + -0x51]
1800abdfc: CALL qword ptr [RAX]
1800abdfe: MOV qword ptr [RBP + -0x19],RAX
1800abe02: LEA RAX,[RBP + -0x11]
1800abe06: MOV qword ptr [RBP + 0x6f],RAX
1800abe0a: MOV qword ptr [RBP + 0x27],RSI
1800abe0e: MOV RAX,qword ptr [RBP + 0x7f]
1800abe12: MOV RCX,qword ptr [RAX + 0x38]
1800abe16: TEST RCX,RCX
1800abe19: JZ 0x1800abe28
1800abe1b: MOV RAX,qword ptr [RCX]
1800abe1e: LEA RDX,[RBP + -0x11]
1800abe22: CALL qword ptr [RAX]
1800abe24: MOV qword ptr [RBP + 0x27],RAX
1800abe28: MOV ECX,0x90
1800abe2d: CALL 0x180127a94
1800abe32: MOV RBX,RAX
1800abe35: MOV qword ptr [RBP + 0x7f],RAX
1800abe39: MOV qword ptr [RBP + 0x6f],RAX
1800abe3d: MOV ECX,dword ptr [RBP + -0x61]
1800abe40: MOV dword ptr [RAX],ECX
1800abe42: MOVZX ECX,byte ptr [RBP + -0x5d]
1800abe46: MOV byte ptr [RAX + 0x4],CL
1800abe49: MOV RCX,qword ptr [RBP + -0x59]
1800abe4d: MOV qword ptr [RAX + 0x8],RCX
1800abe51: LEA RDI,[RAX + 0x10]
1800abe55: MOV qword ptr [RBP + 0x77],RDI
1800abe59: MOV qword ptr [RDI + 0x38],RSI
1800abe5d: MOV RCX,qword ptr [RBP + -0x19]
1800abe61: TEST RCX,RCX
1800abe64: JZ 0x1800abe72
1800abe66: MOV RAX,qword ptr [RCX]
1800abe69: MOV RDX,RDI
1800abe6c: CALL qword ptr [RAX]
1800abe6e: MOV qword ptr [RDI + 0x38],RAX
1800abe72: LEA RDI,[RBX + 0x50]
1800abe76: MOV qword ptr [RBP + 0x77],RDI
1800abe7a: MOV qword ptr [RDI + 0x38],RSI
1800abe7e: MOV RCX,qword ptr [RBP + 0x27]
1800abe82: TEST RCX,RCX
1800abe85: JZ 0x1800abe93
1800abe87: MOV RAX,qword ptr [RCX]
1800abe8a: MOV RDX,RDI
1800abe8d: CALL qword ptr [RAX]
1800abe8f: MOV qword ptr [RDI + 0x38],RAX
1800abe93: MOV qword ptr [RBP + 0x7f],RBX
1800abe97: LEA RAX,[RBP + -0x69]
1800abe9b: MOV qword ptr [RSP + 0x28],RAX
1800abea0: MOV dword ptr [RSP + 0x20],ESI
1800abea4: MOV R9,RBX
1800abea7: LEA R8,[0x1800b9aa0]
1800abeae: XOR EDX,EDX
1800abeb0: XOR ECX,ECX
1800abeb2: CALL qword ptr [0x1801d2e50]
1800abeb8: MOV qword ptr [RBP + -0x71],RAX
1800abebc: TEST RAX,RAX
1800abebf: JZ 0x1800abf3b
1800abec1: CMP dword ptr [RBP + -0x69],0x0
1800abec5: JZ 0x1800abf2f
1800abec7: MOVAPS XMM0,xmmword ptr [RBP + -0x71]
1800abecb: MOVDQA xmmword ptr [RBP + 0x2f],XMM0
1800abed0: LEA RCX,[RBP + 0x2f]
1800abed4: CALL qword ptr [0x1801d2748]
1800abeda: TEST EAX,EAX
1800abedc: JNZ 0x1800abf2f
1800abede: XORPS XMM0,XMM0
1800abee1: MOVDQA xmmword ptr [RBP + -0x71],XMM0
1800abee6: MOV RCX,qword ptr [RBP + 0x27]
1800abeea: TEST RCX,RCX
1800abeed: JZ 0x1800abf03
1800abeef: LEA RAX,[RBP + -0x11]
1800abef3: CMP RCX,RAX
1800abef6: SETNZ DL
1800abef9: MOV RAX,qword ptr [RCX]
1800abefc: CALL qword ptr [RAX + 0x20]
1800abeff: MOV qword ptr [RBP + 0x27],RSI
1800abf03: MOV RCX,qword ptr [RBP + -0x19]
1800abf07: TEST RCX,RCX
1800abf0a: JZ 0x1800abf1c
1800abf0c: LEA RAX,[RBP + -0x51]
1800abf10: CMP RCX,RAX
1800abf13: SETNZ DL
1800abf16: MOV RAX,qword ptr [RCX]
1800abf19: CALL qword ptr [RAX + 0x20]
1800abf1c: MOV RBX,qword ptr [RSP + 0x100]
1800abf24: ADD RSP,0xe0
1800abf2b: POP RDI
1800abf2c: POP RSI
1800abf2d: POP RBP
1800abf2e: RET
1800abf2f: MOV ECX,0x1
1800abf34: CALL qword ptr [0x1801d2710]
1800abf3a: NOP
1800abf3b: MOV dword ptr [RBP + -0x69],ESI
1800abf3e: MOV ECX,0x6
1800abf43: CALL qword ptr [0x1801d2710]
1800abf49: INT3
