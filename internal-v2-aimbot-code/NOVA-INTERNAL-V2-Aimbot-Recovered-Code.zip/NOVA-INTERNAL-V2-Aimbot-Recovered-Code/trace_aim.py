from pathlib import Path
import sys,json,re
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT.parent/'inner-flow'))
import analyze as a
from capstone.x86 import X86_OP_MEM,X86_REG_RIP
controls={0x1800b3d7f:'aim_toggle',0x1800b3dc8:'aim_type',0x1800b3df2:'show_fov',0x1800b3e0c:'no_recoil',0x1800b3e40:'ignore_bots',0x1800b3e5a:'ignore_knocked'}
targets={}
for addr,name in controls.items():
 i=next(a.cs.disasm(a.data(addr,16),addr))
 for o in i.operands:
  if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP:targets[i.address+i.size+o.mem.disp]=name
refs=[]
a.cs.skipdata=True
text=next(s for s in a.S if s['name']=='.text')
for i in a.cs.disasm(a.B[text['raw']:text['raw']+text['rawsize']],a.BASE+text['rva']):
 if i.id==0:continue
 for o in i.operands:
  if o.type==X86_OP_MEM and o.mem.base==X86_REG_RIP:
   target=i.address+i.size+o.mem.disp
   if target in targets:
    f=a.function(i.address);refs.append({'global':hex(target),'label':targets[target],'address':hex(i.address),'instruction':i.mnemonic+' '+i.op_str,'function':hex(f[0]) if f else None})
print(json.dumps(refs,indent=2));(ROOT/'aim-state-references.json').write_text(json.dumps(refs,indent=2)+'\n')
seeds={0x1800acfd0,0x1800ad030,0x1800a8dd0,0x1800ad260,0x1800b1990}
seeds.update(int(r['function'],16) for r in refs if r['function'])
idx=json.loads((ROOT/'string-and-call-index.json').read_text())['panel'];bounds=[(int(x,16),int(y,16)) for x,y in idx['function_bounds']]
# Keep directly associated application routines; C runtime and broad ImGui dependency expansion would obscure this request.
for depth in range(2):
 for start in list(seeds):
  bound=next((z for x,z in bounds if x==start),None)
  if not bound or start==0x1800b1990:continue
  for call,target in idx['direct_calls']:
   c,t=int(call,16),int(target,16)
   if start<=c<bound and 0x180060000<=t<0x1800b0000:seeds.add(t)
rows=[{'address':hex(x),'end':hex(next(z for y,z in bounds if y==x))} for x in sorted(seeds) if any(y==x for y,z in bounds)]
(ROOT/'targets.json').write_text(json.dumps(rows,indent=2)+'\n')
(ROOT/'targets.tsv').write_text(''.join(r['address'][2:]+'\t'+r['end'][2:]+'\n' for r in rows))
print('TARGETS',len(rows))
