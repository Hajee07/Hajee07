// Generated from exact SHA-256-verified Unity/IL2CPP ELF inputs.
namespace HeadBridge.Mapping {
    internal static class NativeTransformReference {
        internal const string FileSha256 = "1029519376944ff6310fcbbe84356976a839e080da67da716b3aae470f80dd77";
        internal const string BuildId = "667862f2d29b22ee";
        internal const string HeaderHex = "7f454c460201010000000000000000000300b70001000000003a4100000000004000000000000000285041010000000000000000400038000a0040001d001a00";
        internal const string ProgramsHex = "06000000040000004000000000000000400000000000000040000000000000003002000000000000300200000000000008000000000000000100000004000000000000000000000000000000000000000000000000000000fcf9400000000000fcf94000000000000040000000000000010000000500000000fa400000000000003a410000000000003a410000000000701bfa0000000000701bfa00000000000040000000000000010000000600000070153b010000000070953b010000000070953b01000000002895040000000000289504000000000000400000000000000100000006000000a0aa3f0100000000a06a400100000000a06a400100000000f8a301000000000020041100000000000040000000000000020000000600000080743f010000000080f43f010000000080f43f010000000040020000000000004002000000000000080000000000000052e574640400000070153b010000000070953b010000000070953b01000000002895040000000000909a040000000000010000000000000050e57464040000000c611e00000000000c611e00000000000c611e00000000002c3e0700000000002c3e070000000000040000000000000051e57464060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000004000000700200000000000070020000000000007002000000000000b000000000000000b0000000000000000400000000000000";
        internal const string NoteHex = "040000000800000003000000474e5500667862f2d29b22ee";
        internal static readonly GameLayoutCheck[] UnityAnchors = new GameLayoutCheck[] {
            new GameLayoutCheck("position_binding_0", 0x46e9e4UL, "80e3ffd081ffff900090299121302991638e0a14"),
            new GameLayoutCheck("local_position_binding_0", 0x46ea0cUL, "20e4ff9081ffff90006c119121903191598e0a14"),
            new GameLayoutCheck("managed_native_pointer_0", 0x71f7d0UL, "400000b4000840f9c0035fd6"),
            new GameLayoutCheck("position_icall_0", 0x45ea4cUL, "ff8301d1fe5704a9f44f05a9157d00b0b56243f9f30301aaf40300aae1630091a80240f9e0031faae2031faaff7f03a9ff0f00f900013fd6a80240f9e1230091"),
            new GameLayoutCheck("position_icall_64", 0x45ea8cUL, "e0031faae20314aaff1300f9ffa3003900013fd6e20740f9a80240f9e1230091e0031faaff0700f900013fd6e20740f9a80240f9e1630091e0031faa00013fd6"),
            new GameLayoutCheck("position_icall_128", 0x45eaccUL, "e8a34039a8010034e01340f9400200b4e8230091a9ca0894e81340b9e90740f9fe5744a9680a00b9690200f9f44f45a9ff830191c0035fd6e00f40f9400000b4"),
            new GameLayoutCheck("position_icall_192", 0x45eb0cUL, "31030b9428008052e01300f9e8a3003900feffb5a80240f9e1230091e20314aa00013fd6e00740f9fa010b94a80240f9e20300aaf30301aae1c30091e0031faa"),
            new GameLayoutCheck("position_icall_256", 0x45eb4cUL, "00013fd6e01b40f9e10313aaf31f00f971000b94"),
            new GameLayoutCheck("local_position_icall_0", 0x45ec64UL, "ff8301d1fe5704a9f44f05a9157d00b0b56243f9f30301aaf40300aae1630091a80240f9e0031faae2031faaff7f03a9ff0f00f900013fd6a80240f9e1230091"),
            new GameLayoutCheck("local_position_icall_64", 0x45eca4UL, "e0031faae20314aaff1300f9ffa3003900013fd6e20740f9a80240f9e1230091e0031faaff0700f900013fd6e20740f9a80240f9e1630091e0031faa00013fd6"),
            new GameLayoutCheck("local_position_icall_128", 0x45ece4UL, "e8a34039a8010034e01340f9400200b4e82300912bc80894e81340b9e90740f9fe5744a9680a00b9690200f9f44f45a9ff830191c0035fd6e00f40f9400000b4"),
            new GameLayoutCheck("local_position_icall_192", 0x45ed24UL, "ab020b9428008052e01300f9e8a3003900feffb5a80240f9e1230091e20314aa00013fd6e00740f974010b94a80240f9e20300aaf30301aae1c30091e0031faa"),
            new GameLayoutCheck("local_position_icall_256", 0x45ed64UL, "00013fd6e01b40f9e10313aaf31f00f9ebff0a94"),
            new GameLayoutCheck("transform_access_0", 0x69304cUL, "fe0f1ef8f44f01a9141c40f9f30300aa880240f9e80000b4e00314aae1031f2ad293fd97e00314aa3190fd97741e40f9612240f9e00314aaf44f41a9fe0742f8"),
            new GameLayoutCheck("transform_access_64", 0x69308cUL, "c0035fd6"),
            new GameLayoutCheck("world_position_0", 0x691584UL, "fe4fbfa9f30308aab006009408a441a92b7c40920a0680526c7d0a9b2b5961b80069ec3ceb04f837acd7ff908dd7ffb0aed7ff908111c03da295c13dc3f1c23d"),
            new GameLayoutCheck("world_position_64", 0x6915c4UL, "1f2003d56c21aa9b859140ad8601c03d2b596bb800dc246ea408a04e3090a54f3390854fa740056e5198854f90dc306e84dc336e5390854f7298854f6590a54f"),
            new GameLayoutCheck("world_position_128", 0x691604UL, "f1dc316ef3dc336ee708a04e10d6b14ef1dc326ee5dc256e24d6a44e65d6a54e0792804f07d4274e8490a04fa098804f80d4204ee0d4204ec0d4204e4bfcff36"),
            new GameLayoutCheck("world_position_192", 0x691644UL, "68220091600200fd0081004dfe4fc1a8c0035fd6"),
            new GameLayoutCheck("local_position_0", 0x690da4UL, "fe4fbfa9f30308aaa8080094080c40f9297c40920a068052297d0a9b0069e93c68220091600200fd0081004dfe4fc1a8c0035fd6"),
            new GameLayoutCheck("hierarchy_capacity_0", 0x693cfcUL, "fe0f1ff8d3fcff97001040b9fe0741f8c0035fd6"),
            new GameLayoutCheck("hierarchy_assignment_0", 0x693d28UL, "011c00f9024000b9c0035fd6"),
            new GameLayoutCheck("hierarchy_backlinks_0", 0x693d54UL, "181840f9193840f9f30302aaf40301aaf50300aa1cdb63f8951f00f9834300b9a81240f908d9a3b81f05003160000054087b68f802000014e8031faa7a7c4093"),
            new GameLayoutCheck("hierarchy_backlinks_64", 0x693d94UL, "884b00f9"),
            new GameLayoutCheck("capacity_resize_0", 0x693698UL, "fe5fbda9f65701a9f44f02a9f50301aaf30300aa45f6ff97081040b91f0115eba1000054"),
            new GameLayoutCheck("job_clear_0", 0x5f7138UL, "1f0000f91f0800b9c0035fd6"),
            new GameLayoutCheck("rotation_coefficients_1_0", 0x185040UL, "000000c000000040000000c000000000"),
            new GameLayoutCheck("rotation_coefficients_2_0", 0x182650UL, "00000040000000c0000000c000000000"),
            new GameLayoutCheck("rotation_coefficients_3_0", 0x185bc0UL, "000000c0000000c00000004000000000"),
        };
        internal static readonly GameLayoutCheck[] CameraAnchors = new GameLayoutCheck[] {
            new GameLayoutCheck("CameraMain_registration_0", 0x468ddcUL, "80e5ffd0a1fdffb0001c2a912110239165a50a14"),
            new GameLayoutCheck("CameraMain_icall_name_0", 0x11aa87UL, "556e697479456e67696e652e43616d6572613a3a6765745f6d61696e00"),
            new GameLayoutCheck("CameraMain_code_0", 0x41d8c4UL, "fe0f1ff874ac0794400000b4450d0c94fe0741f8c0035fd6"),
            new GameLayoutCheck("ComponentTransform_registration_0", 0x46dabcUL, "c0e5ff9021ffffd000ac3d91211034912d920a14"),
            new GameLayoutCheck("ComponentTransform_icall_name_0", 0x125f6bUL, "556e697479456e67696e652e436f6d706f6e656e743a3a6765745f7472616e73666f726d00"),
            new GameLayoutCheck("ComponentTransform_code_0", 0x453d04UL, "ff4301d1fe1b00f9f44f04a9747d0090946243f9f30300aae1230091e0031faa880240f9e2031faaff7f02a9ff0700f900013fd6880240f9e1e30091e0031faa"),
            new GameLayoutCheck("ComponentTransform_code_64", 0x453d44UL, "e20313aaff0b00f9ff63003900013fd6e21f40f9880240f9e1e30091e0031faaff1f00f900013fd6e21f40f9880240f9e1230091e0031faa00013fd6e8634039"),
            new GameLayoutCheck("ComponentTransform_code_128", 0x453d84UL, "68020034e00b40f9000300b4131840f9d30400b4880240f9e1830091e0031faae2031faa00013fd6ff1700f9681a40f9140540f9882240b91f090071e1040054"),
            new GameLayoutCheck("ComponentTransform_code_192", 0x453dc4UL, "931640f9d30500b529000014e00740f9400000b47e2e0b9428008052e00b00f9e863003940fdffb5880240f9e1e30091e20313aa00013fd6e01f40f9472d0b94"),
            new GameLayoutCheck("ComponentTransform_code_256", 0x453e04UL, "880240f9e20300aaf30301aae1830091e0031faa00013fd6e01340f9e10313aaf31700f9be2b0b9480e6fff0005c11916b2d0b94880240f9e20300aaf40301aa"),
            new GameLayoutCheck("ComponentTransform_code_320", 0x453e44UL, "e1830091e0031faa00013fd6e8031faaf41700f90d000014800e40f9800000b4bf0a0b94f30300aab30000b5e00314aadc330b94f30300aa200200b4e00313aa"),
            new GameLayoutCheck("ComponentTransform_code_384", 0x453e84UL, "532e0b94e80300aae01340f9c00100b5e11740f9a10100b5880000b4e00308aad0330b94f30300aae00313aaf44f44a9fe1b40f9ff430191c0035fd6e8031faa"),
            new GameLayoutCheck("ComponentTransform_code_448", 0x453ec4UL, "f2ffff17e11740f9952b0b94"),
        };
        internal static readonly GameLayoutCheck[] CameraSelectorAnchors = new GameLayoutCheck[] {
            new GameLayoutCheck("main_selector_0", 0x608a98UL, "fe0f1df8f65701a9f44f02a9e287fc97a1008052b7a2f997600200b4160440f9f30300aadf0200ebe0010054147000b094020191c00a40f9e10314aaf688fc97"),
            new GameLayoutCheck("main_selector_64", 0x608ad8UL, "c00000b4080040f9f50300aa086940f900013fd6a0000037d60640f9df0213eba1feff54f5031faae00315aaf44f42a9f65741a9fe0743f8c0035fd6"),
            new GameLayoutCheck("tag_manager_global_0", 0x52aa2cUL, "887800f000b546f9c0035fd6"),
            new GameLayoutCheck("tag_list_lookup_0", 0x471588UL, "ffc300d1fe4f02a9e11f00b9e8230091e1730091f30300aa0f000094690a40b96a0240f9e80740f92905098b4901098b296100911f0109eb60000054000940f9"),
            new GameLayoutCheck("tag_list_lookup_64", 0x4715c8UL, "02000014e0031faafe4f42a9ffc30091c0035fd6fe0f1ef8f44f01a902500091f40300aaf30308aa13000094880a40b9890240f90805088b2801088b08610091"),
            new GameLayoutCheck("tag_list_lookup_128", 0x471608UL, "1f0008eb680600f9e2000054090040b93f09003183000054006000911f0008eb63ffff54600200f9f44f41a9fe0742f8c0035fd6"),
            new GameLayoutCheck("tag_hash_lookup_0", 0x47163cUL, "280040b9c9a28b52a9daaf728a4798520d31080ba901090b2aecb872294d494aab8399520c408c5229010a4a0b3fbd72ec99b5722915090b2a010b0b8b25090b"),
            new GameLayoutCheck("tag_hash_lookup_64", 0x47167cUL, "add888524a010b4a0daebf72090840b94a0d0a0b2ee189524a010d0b4eabb6724b414a4a0a0040f96b010eca6d01098aac050d8b40010c8b0c0040b96b751e12"),
            new GameLayoutCheck("tag_hash_lookup_128", 0x4716bcUL, "9f010b6b810000540e0840b91f010e6b800200549f050031e00100540c018052ad010c0bad01098aae050d8b40010e8b0e0040b9df010b6b810000540f0840b9"),
            new GameLayoutCheck("tag_hash_lookup_192", 0x4716fcUL, "1f010f6be0000054df0500318c21001181feff542805098b4801088b00610091c0035fd6"),
            new GameLayoutCheck("component_type_lookup_0", 0x52aeacUL, "0b2040f98b0100b4091840f9282846296bed7cd3292100912c815fb88c01084b9f010a6bc30000546b4100f12941009141ffff54e0031faac0035fd6200140f9"),
            new GameLayoutCheck("component_type_lookup_64", 0x52aeecUL, "c0035fd6"),
        };
        internal static readonly GameLayoutCheck[] CameraPredicateAnchors = new GameLayoutCheck[] {
            new GameLayoutCheck("native_camera_predicate", 0x50700cUL, "08e040391f010071e0079f1ac0035fd6"),
        };
        internal static readonly GameLayoutCheck[] Il2CppAnchors = new GameLayoutCheck[] {
            new GameLayoutCheck("get_position", 0x9ff5f40UL, "ffc300d1fe0b00f9f44f02a9347e0090880247f9f30300aaff0b00b9ff0300f9c80000b580cdfbf0000033910b7b0d94e80300aa800207f9e1030091e00313aa00013fd6e007402de20b40bdf44f42a9fe0b40f9ffc30091c0035fd6"),
            new GameLayoutCheck("get_position_injected", 0x9ff5f9cUL, "fe57bea9f44f01a9357e0090a20247f9f30301aaf40300aac20000b580cdfbf000003391f67a0d94e20300aaa00207f9e00314aae10313aaf44f41a9fe57c2a840001fd6"),
            new GameLayoutCheck("get_local_position_injected", 0x9ff6078UL, "fe57bea9f44f01a9157e00f0a20a47f9f30301aaf40300aac20000b5a0cbfbf000542391bf7a0d94e20300aaa00a07f9e00314aae10313aaf44f41a9fe57c2a840001fd6"),
        };
        internal const ulong CameraPredicateTarget=0x50700cUL, CameraPredicateByteOffset=0x38UL;
        internal const ulong CameraTagManagerCell=0x143dd68UL, CameraTypeDescriptor=0x1409040UL;
        internal const ulong CameraMainTarget=0x41d8c4UL, ComponentTransformTarget=0x453d04UL;
        internal const ulong CameraExecutableStart=0x413a00UL, CameraExecutableEnd=0x13b5570UL;
    }
}
