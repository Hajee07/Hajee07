#!/usr/bin/env bash
set -euo pipefail
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$project_dir"
mkdir -p build/native build/windows-x64
common_flags=(-std=c++17 -Wall -Wextra -Werror -pedantic -Iinclude)
native_cxx=${CXX:-g++}
"$native_cxx" "${common_flags[@]}" -O2 src/head_aim.cpp tests/core_tests.cpp \
    -o build/native/core_tests
./build/native/core_tests

windows_cxx=${MINGW_CXX:-x86_64-w64-mingw32-g++}
if ! command -v "$windows_cxx" >/dev/null 2>&1; then
    printf '%s\n' 'Windows build unavailable: install a MinGW x64 C++ compiler or set MINGW_CXX to its full path.' >&2
    exit 2
fi
"$windows_cxx" "${common_flags[@]}" -O2 -DHEAD_AIM_BUILD -shared \
    -static-libgcc -static-libstdc++ src/head_aim.cpp \
    -Wl,--out-implib,build/windows-x64/libhead_aim.a \
    -o build/windows-x64/head_aim.dll
"$windows_cxx" "${common_flags[@]}" -O2 -municode -static \
    windows/smoke.cpp -o build/windows-x64/smoke.exe
printf '%s\n' 'Windows x64 DLL and own-process smoke loader compiled. Run smoke.exe on Windows to verify DLL loading; live game integration remains unimplemented.'
