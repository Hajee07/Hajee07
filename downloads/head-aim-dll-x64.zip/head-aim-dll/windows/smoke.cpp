#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include "head_aim.h"

#include <cmath>
#include <cstring>
#include <iostream>
#include <string>

namespace {

class LoadedLibrary {
public:
    explicit LoadedLibrary(HMODULE handle) : handle_(handle) {}
    ~LoadedLibrary() {
        if (handle_) {
            FreeLibrary(handle_);
        }
    }
    LoadedLibrary(const LoadedLibrary&) = delete;
    LoadedLibrary& operator=(const LoadedLibrary&) = delete;

private:
    HMODULE handle_;
};

bool is_absolute_path(const std::wstring& path) {
    const bool drive_path = path.size() >= 3 && path[1] == L':' &&
        ((path[0] >= L'A' && path[0] <= L'Z') ||
         (path[0] >= L'a' && path[0] <= L'z')) &&
        (path[2] == L'\\' || path[2] == L'/');
    const bool unc_path = path.size() >= 2 &&
        path[0] == L'\\' && path[1] == L'\\';
    return drive_path || unc_path;
}

bool approximately_equal(double actual, double expected) {
    return std::isfinite(actual) && std::abs(actual - expected) < 1e-12;
}

template <typename FunctionPointer>
FunctionPointer resolve_function(HMODULE module, const char* name) {
    const FARPROC address = GetProcAddress(module, name);
    if (!address) {
        return nullptr;
    }
    static_assert(sizeof(FunctionPointer) == sizeof(FARPROC),
                  "Windows export and typed function pointers must have equal sizes");
    FunctionPointer function = nullptr;
    std::memcpy(&function, &address, sizeof(function));
    return function;
}

bool check(bool condition, const char* description) {
    if (!condition) {
        std::cerr << "FAIL: " << description << '\n';
    }
    return condition;
}

} // namespace

int wmain(int argc, wchar_t** argv) {
    if (argc != 2 || !is_absolute_path(argv[1])) {
        std::wcerr << L"Usage: smoke.exe <full absolute path to head_aim.dll>\n";
        return 2;
    }

    const HMODULE module = LoadLibraryW(argv[1]);
    if (!module) {
        std::wcerr << L"LoadLibraryW failed (Windows error " << GetLastError()
                   << L"). Check the DLL path and host/DLL architecture.\n";
        return 2;
    }
    const LoadedLibrary cleanup(module);

    const auto api_version = resolve_function<decltype(&HeadAimApiVersion)>(
        module, "HeadAimApiVersion");
    const auto direction = resolve_function<decltype(&HeadAimDirection)>(
        module, "HeadAimDirection");
    const auto select = resolve_function<decltype(&HeadAimSelect)>(
        module, "HeadAimSelect");
    if (!api_version || !direction || !select) {
        std::cerr << "Required DLL exports are missing.\n";
        return 2;
    }

    bool passed = check(api_version() == 1, "API version is 1");
    const HeadAimVec3 camera{1.0, 2.0, 3.0};
    const HeadAimVec3 head{4.0, 6.0, 3.0};
    HeadAimVec3 output{};
    auto status = direction(&camera, &head, &output);
    passed = check(static_cast<unsigned>(status) == 0 &&
                   approximately_equal(output.x, 0.6) && approximately_equal(output.y, 0.8) &&
                   approximately_equal(output.z, 0.0),
                   "known head point gives the expected unit direction") && passed;
    status = direction(nullptr, &head, &output);
    passed = check(static_cast<unsigned>(status) == 1,
                   "null camera returns INVALID_ARGUMENT") && passed;
    status = direction(&camera, &camera, &output);
    passed = check(static_cast<unsigned>(status) == 2,
                   "coincident points return COINCIDENT") && passed;

    const HeadAimVec3 origin{0.0, 0.0, 0.0};
    const HeadAimVec3 forward{1.0, 0.0, 0.0};
    // Flags 1|2|4 mean alive, visible, and opponent, respectively.
    const HeadAimCandidate candidates[] = {
        {10u, 7u, {10.0, 2.0, 0.0}},
        {42u, 7u, {10.0, 0.0, 0.0}},
        {7u, 7u, {5.0, 0.0, 0.0}},
        {5u, 7u, {5.0, 0.0, 0.0}},
        {1u, 3u, {1.0, 0.0, 0.0}},
    };
    uint32_t selected_id = 0;
    status = select(&origin, &forward, candidates, 5u, 20.0, 100.0,
                    &selected_id, &output);
    passed = check(static_cast<unsigned>(status) == 0 && selected_id == 5u &&
                   approximately_equal(output.x, 1.0) && approximately_equal(output.y, 0.0) &&
                   approximately_equal(output.z, 0.0),
                   "selection filters flags and breaks angle/distance ties by ID") && passed;
    status = select(&origin, &forward, nullptr, 0u, 20.0, 100.0,
                    &selected_id, &output);
    passed = check(static_cast<unsigned>(status) == 3,
                   "an empty candidate list returns NO_TARGET") && passed;
    status = select(&origin, &forward, candidates, 5u, -1.0, 100.0,
                    &selected_id, &output);
    passed = check(static_cast<unsigned>(status) == 1,
                   "an invalid angle limit returns INVALID_ARGUMENT") && passed;

    if (!passed) {
        return 1;
    }
    std::cout << "PASS: DLL exports, directions, selection, and error statuses.\n";
    return 0;
}
