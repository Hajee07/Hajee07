#include "head_aim.h"

#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>

namespace {

constexpr unsigned kOk = 0;
constexpr unsigned kInvalid = 1;
constexpr unsigned kCoincident = 2;
constexpr unsigned kNoTarget = 3;
constexpr uint32_t kEligible = 7u;
constexpr uint32_t kSentinelId = 0xdeadbeefu;
const HeadAimVec3 kSentinelDirection{123.0, -45.0, 6.0};
const HeadAimVec3 kOrigin{0.0, 0.0, 0.0};
const HeadAimVec3 kForward{1.0, 0.0, 0.0};

unsigned cases = 0;
unsigned failures = 0;

void run_case(const char* name, bool passed) {
    ++cases;
    if (!passed) {
        ++failures;
        std::cerr << "FAIL: " << name << '\n';
    }
}

bool near(double a, double b) {
    return std::isfinite(a) && std::isfinite(b) && std::abs(a - b) <= 1e-12;
}

bool same(const HeadAimVec3& a, const HeadAimVec3& b) {
    return a.x == b.x && a.y == b.y && a.z == b.z;
}

bool unit_matches(const HeadAimVec3& actual, const HeadAimVec3& expected) {
    return near(actual.x, expected.x) && near(actual.y, expected.y) &&
           near(actual.z, expected.z) &&
           near(std::hypot(std::hypot(actual.x, actual.y), actual.z), 1.0);
}

bool direction_matches(const HeadAimVec3& camera, const HeadAimVec3& head,
                       const HeadAimVec3& expected) {
    HeadAimVec3 output = kSentinelDirection;
    return static_cast<unsigned>(HeadAimDirection(&camera, &head, &output)) == kOk &&
           unit_matches(output, expected);
}

bool direction_error(const HeadAimVec3* camera, const HeadAimVec3* head,
                     unsigned expected_status, bool null_output = false) {
    HeadAimVec3 output = kSentinelDirection;
    const auto status = HeadAimDirection(camera, head, null_output ? nullptr : &output);
    return static_cast<unsigned>(status) == expected_status &&
           same(output, kSentinelDirection);
}

bool select_matches(const HeadAimVec3& camera, const HeadAimVec3& current,
                    const HeadAimCandidate* candidates, uint32_t count,
                    double max_angle, double max_distance, uint32_t expected_id,
                    const HeadAimVec3& expected_direction) {
    HeadAimVec3 output = kSentinelDirection;
    uint32_t id = kSentinelId;
    const auto status = HeadAimSelect(&camera, &current, candidates, count,
                                      max_angle, max_distance, &id, &output);
    return static_cast<unsigned>(status) == kOk && id == expected_id &&
           unit_matches(output, expected_direction);
}

bool select_error(const HeadAimVec3* camera, const HeadAimVec3* current,
                  const HeadAimCandidate* candidates, uint32_t count,
                  double max_angle, double max_distance, unsigned expected_status,
                  bool null_id = false, bool null_direction = false) {
    HeadAimVec3 output = kSentinelDirection;
    uint32_t id = kSentinelId;
    const auto status = HeadAimSelect(camera, current, candidates, count,
                                      max_angle, max_distance,
                                      null_id ? nullptr : &id,
                                      null_direction ? nullptr : &output);
    return static_cast<unsigned>(status) == expected_status && id == kSentinelId &&
           same(output, kSentinelDirection);
}

} // namespace

int main() {
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const double inf = std::numeric_limits<double>::infinity();
    const double tiny = std::numeric_limits<double>::denorm_min();
    const HeadAimVec3 ordinary_head{3.0, 4.0, 0.0};
    const HeadAimVec3 nan_point{nan, 0.0, 0.0};
    const HeadAimVec3 positive_inf{0.0, inf, 0.0};
    const HeadAimVec3 negative_inf{0.0, 0.0, -inf};

    run_case("API version", HeadAimApiVersion() == 1u);
    run_case("translated 3-4-5 direction",
             direction_matches({10.0, -20.0, 7.0}, {13.0, -16.0, 7.0},
                               {0.6, 0.8, 0.0}));
    run_case("negative direction components",
             direction_matches(kOrigin, {-3.0, -4.0, 0.0}, {-0.6, -0.8, 0.0}));
    run_case("three-dimensional unit direction",
             direction_matches(kOrigin, {2.0, 3.0, 6.0}, {2.0 / 7.0, 3.0 / 7.0, 6.0 / 7.0}));
    run_case("huge representable direction",
             direction_matches(kOrigin, {3e300, 4e300, 0.0}, {0.6, 0.8, 0.0}));
    run_case("tiny representable direction",
             direction_matches(kOrigin, {3e-300, 4e-300, 0.0}, {0.6, 0.8, 0.0}));
    run_case("smallest subnormal axis direction",
             direction_matches(kOrigin, {tiny, 0.0, 0.0}, kForward));
    run_case("direction null camera preserves output",
             direction_error(nullptr, &ordinary_head, kInvalid));
    run_case("direction null head preserves output",
             direction_error(&kOrigin, nullptr, kInvalid));
    run_case("direction null output",
             direction_error(&kOrigin, &ordinary_head, kInvalid, true));
    run_case("coincident direction preserves output",
             direction_error(&ordinary_head, &ordinary_head, kCoincident));
    const HeadAimVec3 negative_zero{-0.0, 0.0, -0.0};
    run_case("signed-zero points are coincident",
             direction_error(&kOrigin, &negative_zero, kCoincident));
    run_case("direction NaN camera preserves output",
             direction_error(&nan_point, &ordinary_head, kInvalid));
    run_case("direction positive infinity head preserves output",
             direction_error(&kOrigin, &positive_inf, kInvalid));
    run_case("direction negative infinity head preserves output",
             direction_error(&kOrigin, &negative_inf, kInvalid));

    const HeadAimCandidate eligibility[] = {
        {0u, 0u, {1.0, 0.0, 0.0}},
        {1u, 1u, {1.0, 0.0, 0.0}},
        {2u, 2u, {1.0, 0.0, 0.0}},
        {3u, 4u, {1.0, 0.0, 0.0}},
        {4u, 3u, {1.0, 0.0, 0.0}},
        {5u, 5u, {1.0, 0.0, 0.0}},
        {6u, 6u, {1.0, 0.0, 0.0}},
        {7u, kEligible, {5.0, 0.0, 0.0}},
    };
    run_case("selection requires all eligibility flags",
             select_matches(kOrigin, kForward, eligibility, 8u, 180.0, 100.0,
                            7u, kForward));
    const HeadAimCandidate angular[] = {
        {1u, kEligible, {10.0, 10.0, 0.0}},
        {2u, kEligible, {100.0, 1.0, 0.0}},
    };
    const double angular_length = std::hypot(100.0, 1.0);
    run_case("angular error outranks distance",
             select_matches(kOrigin, kForward, angular, 2u, 90.0, 200.0, 2u,
                            {100.0 / angular_length, 1.0 / angular_length, 0.0}));
    const HeadAimCandidate distance_tie[] = {
        {1u, kEligible, {10.0, 0.0, 0.0}},
        {2u, kEligible, {5.0, 0.0, 0.0}},
    };
    run_case("equal angle chooses shorter distance",
             select_matches(kOrigin, kForward, distance_tie, 2u, 0.0, 20.0, 2u, kForward));
    const HeadAimCandidate id_tie[] = {
        {42u, kEligible, {5.0, 0.0, 0.0}},
        {7u, kEligible, {5.0, 0.0, 0.0}},
        {0u, kEligible, {5.0, 0.0, 0.0}},
    };
    run_case("equal angle and distance choose smallest ID including zero",
             select_matches(kOrigin, kForward, id_tie, 3u, 0.0, 20.0, 0u, kForward));
    const HeadAimCandidate forward[] = {{17u, kEligible, {5.0, 0.0, 0.0}}};
    run_case("nonunit current direction is normalized",
             select_matches(kOrigin, {10.0, 0.0, 0.0}, forward, 1u,
                            0.0, 5.0, 17u, kForward));
    const HeadAimCandidate translated[] = {{23u, kEligible, {103.0, -16.0, 7.0}}};
    run_case("selection accounts for translated camera",
             select_matches({100.0, -20.0, 7.0}, {0.6, 0.8, 0.0}, translated, 1u,
                            1.0, 5.0, 23u, {0.6, 0.8, 0.0}));
    run_case("zero-degree angle boundary is inclusive",
             select_matches(kOrigin, kForward, forward, 1u, 0.0, 10.0, 17u, kForward));
    const HeadAimCandidate perpendicular[] = {{31u, kEligible, {0.0, 5.0, 0.0}}};
    run_case("90-degree angle boundary is inclusive",
             select_matches(kOrigin, kForward, perpendicular, 1u, 90.0, 10.0,
                            31u, {0.0, 1.0, 0.0}));
    run_case("angle outside 89-degree bound is excluded",
             select_error(&kOrigin, &kForward, perpendicular, 1u, 89.0, 10.0, kNoTarget));
    const HeadAimCandidate opposite[] = {{32u, kEligible, {-5.0, 0.0, 0.0}}};
    run_case("180-degree angle boundary is inclusive",
             select_matches(kOrigin, kForward, opposite, 1u, 180.0, 10.0,
                            32u, {-1.0, 0.0, 0.0}));
    run_case("angle outside 179-degree bound is excluded",
             select_error(&kOrigin, &kForward, opposite, 1u, 179.0, 10.0, kNoTarget));
    const HeadAimCandidate five_units[] = {{33u, kEligible, {3.0, 4.0, 0.0}}};
    run_case("distance boundary is inclusive",
             select_matches(kOrigin, kForward, five_units, 1u, 90.0, 5.0,
                            33u, {0.6, 0.8, 0.0}));
    run_case("candidate beyond distance boundary is excluded",
             select_error(&kOrigin, &kForward, five_units, 1u, 90.0, 4.99, kNoTarget));
    const HeadAimCandidate huge[] = {{34u, kEligible, {3e300, 4e300, 0.0}}};
    run_case("huge candidate and current direction stay finite",
             select_matches(kOrigin, {3e300, 4e300, 0.0}, huge, 1u, 90.0, 1e301,
                            34u, {0.6, 0.8, 0.0}));
    const HeadAimCandidate small[] = {{35u, kEligible, {3e-300, 4e-300, 0.0}}};
    run_case("tiny candidate and current direction stay finite",
             select_matches(kOrigin, {3e-300, 4e-300, 0.0}, small, 1u, 90.0, 1e-299,
                            35u, {0.6, 0.8, 0.0}));
    const HeadAimCandidate coincident_then_valid[] = {
        {1u, kEligible, {0.0, 0.0, 0.0}},
        {17u, kEligible, {5.0, 0.0, 0.0}},
    };
    run_case("coincident candidate is skipped",
             select_matches(kOrigin, kForward, coincident_then_valid, 2u,
                            0.0, 5.0, 17u, kForward));
    run_case("all coincident candidates give no target with unchanged outputs",
             select_error(&kOrigin, &kForward, coincident_then_valid, 1u,
                          180.0, 10.0, kNoTarget));
    run_case("no eligible flags gives no target with unchanged outputs",
             select_error(&kOrigin, &kForward, eligibility, 7u, 180.0, 10.0, kNoTarget));
    run_case("empty null candidate array gives no target with unchanged outputs",
             select_error(&kOrigin, &kForward, nullptr, 0u, 180.0, 10.0, kNoTarget));
    run_case("empty nonnull candidate array gives no target with unchanged outputs",
             select_error(&kOrigin, &kForward, forward, 0u, 180.0, 10.0, kNoTarget));

    run_case("selection null camera preserves outputs",
             select_error(nullptr, &kForward, forward, 1u, 90.0, 10.0, kInvalid));
    run_case("selection null current direction preserves outputs",
             select_error(&kOrigin, nullptr, forward, 1u, 90.0, 10.0, kInvalid));
    run_case("selection null candidates with positive count preserves outputs",
             select_error(&kOrigin, &kForward, nullptr, 1u, 90.0, 10.0, kInvalid));
    run_case("selection null ID output preserves direction",
             select_error(&kOrigin, &kForward, forward, 1u, 90.0, 10.0, kInvalid, true));
    run_case("selection null direction output preserves ID",
             select_error(&kOrigin, &kForward, forward, 1u, 90.0, 10.0,
                          kInvalid, false, true));
    run_case("zero current direction is invalid",
             select_error(&kOrigin, &kOrigin, forward, 1u, 90.0, 10.0, kInvalid));
    run_case("NaN current direction is invalid",
             select_error(&kOrigin, &nan_point, forward, 1u, 90.0, 10.0, kInvalid));
    run_case("infinite current direction is invalid",
             select_error(&kOrigin, &positive_inf, forward, 1u, 90.0, 10.0, kInvalid));
    run_case("nonfinite camera is invalid",
             select_error(&nan_point, &kForward, forward, 1u, 90.0, 10.0, kInvalid));
    run_case("negative angle limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, -1.0, 10.0, kInvalid));
    run_case("angle limit above 180 is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, 180.01, 10.0, kInvalid));
    run_case("NaN angle limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, nan, 10.0, kInvalid));
    run_case("infinite angle limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, inf, 10.0, kInvalid));
    run_case("zero distance limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, 90.0, 0.0, kInvalid));
    run_case("negative distance limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, 90.0, -1.0, kInvalid));
    run_case("NaN distance limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, 90.0, nan, kInvalid));
    run_case("infinite distance limit is invalid",
             select_error(&kOrigin, &kForward, forward, 1u, 90.0, inf, kInvalid));
    const HeadAimCandidate nan_head[] = {{36u, kEligible, {nan, 0.0, 0.0}}};
    run_case("eligible NaN head is invalid",
             select_error(&kOrigin, &kForward, nan_head, 1u, 180.0, 10.0, kInvalid));
    const HeadAimCandidate infinite_head[] = {{37u, kEligible, {0.0, inf, 0.0}}};
    run_case("eligible infinite head is invalid",
             select_error(&kOrigin, &kForward, infinite_head, 1u, 180.0, 10.0, kInvalid));
    const HeadAimCandidate ignored_nonfinite[] = {
        {1u, 0u, {nan, inf, -inf}},
        {17u, kEligible, {5.0, 0.0, 0.0}},
    };
    run_case("ineligible nonfinite head is ignored",
             select_matches(kOrigin, kForward, ignored_nonfinite, 2u,
                            0.0, 10.0, 17u, kForward));
    run_case("empty list still validates limits",
             select_error(&kOrigin, &kForward, nullptr, 0u, -1.0, 10.0, kInvalid));
    run_case("empty list still validates current direction",
             select_error(&kOrigin, &kOrigin, nullptr, 0u, 90.0, 10.0, kInvalid));

    std::cout << (failures == 0 ? "PASS: " : "FAIL: ") << cases << " cases, "
              << failures << " failures.\n";
    return failures == 0 ? 0 : 1;
}
