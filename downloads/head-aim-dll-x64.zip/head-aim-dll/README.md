# Standalone head-direction DLL core

This project computes a unit direction from a camera position to a caller-supplied
head point and selects an eligible candidate by angular error, then distance and
ID. It provides a small C ABI and native tests. The caller must supply positions
in one consistent coordinate system, a current aim direction, and accurate
alive/visible/opponent flags.

The intended context supplied by the user is Windows 11, BlueStacks
5.22.130.1019 P64, and Free Fire v1.132.1. Compatibility with that environment has
not been verified. This core has no live game reads, game integration, or aim
input; it is not a working Free Fire aimlock and cannot guarantee headshot
accuracy. The Windows smoke program loads the DLL into its own process only.

## Build and test

From this directory on Linux, run:

```sh
./build.sh
```

Prerequisites are a C++17 native compiler (`g++` by default) and a MinGW x64 C++
compiler. Set `CXX` and `MINGW_CXX` to override them. In this cloud session the
MinGW compiler was installed locally from signed Debian package metadata; the
tested build command is:

```sh
MINGW_CXX=/workspace/scratch/head-aim-toolchain/root/usr/bin/x86_64-w64-mingw32-g++-posix ./build.sh
```

The script runs the native tests and cross-builds
`build/windows-x64/head_aim.dll` and `build/windows-x64/smoke.exe`. A missing
Windows compiler is a build failure, even if native tests passed. Linux
compilation does not verify behavior inside Windows or BlueStacks.

On Windows, copy both Windows artifacts into a local directory and run the smoke
check in PowerShell using the DLL's full path:

```powershell
.\smoke.exe "C:\path\to\head_aim.dll"
```

The check resolves all three exports, verifies known vector and selection
results and error statuses, and unloads the DLL. A successful run prints `PASS`
and exits with code zero. The DLL and loading process must have matching
architectures. The supplied Windows artifacts target x64; BlueStacks' P64 label
describes its Android instance and does not establish the Windows host process
architecture.

## API contract

`HeadAimApiVersion()` returns `1`. `HeadAimDirection()` accepts camera/head
positions and writes a unit vector. `HeadAimSelect()` accepts candidates, a
current direction, an angular limit in degrees from 0 through 180, and a positive
maximum distance. Candidates are eligible only when all three flags are set:
alive (`1`), visible (`2`), and opponent (`4`). Status codes are `0` (OK), `1`
(invalid argument or nonfinite input), `2` (coincident points), and `3` (no
eligible target). An empty candidate list may use a null candidates pointer.
Use output values only after an OK result. See `include/head_aim.h` for types
and function signatures.
