#ifndef HEAD_AIM_H
#define HEAD_AIM_H

#include <stdint.h>

#if defined(_WIN32)
#if defined(HEAD_AIM_BUILD)
#define HEAD_AIM_API __declspec(dllexport)
#else
#define HEAD_AIM_API __declspec(dllimport)
#endif
#define HEAD_AIM_CALL __cdecl
#else
#define HEAD_AIM_API
#define HEAD_AIM_CALL
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct HeadAimVec3 {
    double x;
    double y;
    double z;
} HeadAimVec3;

typedef enum HeadAimStatus {
    HEAD_AIM_OK = 0,
    HEAD_AIM_INVALID_ARGUMENT = 1,
    HEAD_AIM_COINCIDENT = 2,
    HEAD_AIM_NO_TARGET = 3
} HeadAimStatus;

enum {
    HEAD_AIM_ALIVE = 1u,
    HEAD_AIM_VISIBLE = 2u,
    HEAD_AIM_OPPONENT = 4u
};

typedef struct HeadAimCandidate {
    uint32_t id;
    uint32_t flags;
    HeadAimVec3 head;
} HeadAimCandidate;

HEAD_AIM_API uint32_t HEAD_AIM_CALL HeadAimApiVersion(void);

/* All positions must use one coordinate system. Output is unchanged on error.
 * The output may alias either input position. */
HEAD_AIM_API HeadAimStatus HEAD_AIM_CALL HeadAimDirection(
    const HeadAimVec3* camera,
    const HeadAimVec3* head,
    HeadAimVec3* direction);

/* Eligible candidates require all three flags. Positions are supplied by the
 * caller; this library does not discover game entities or control any input.
 * The angular limit is inclusive, in degrees [0, 180]. Distance is inclusive
 * and must be finite and positive. Ties use distance, then numeric ID.
 * Coincident candidates are skipped. Eligible nonfinite positions are errors.
 * An empty list allows candidates == NULL. Other pointers must be valid.
 * Outputs are unchanged unless HEAD_AIM_OK is returned. */
HEAD_AIM_API HeadAimStatus HEAD_AIM_CALL HeadAimSelect(
    const HeadAimVec3* camera,
    const HeadAimVec3* current_direction,
    const HeadAimCandidate* candidates,
    uint32_t count,
    double max_angle_degrees,
    double max_distance,
    uint32_t* selected_id,
    HeadAimVec3* direction);

#ifdef __cplusplus
}
#endif

#endif
