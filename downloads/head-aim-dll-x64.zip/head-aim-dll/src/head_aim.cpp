#include "head_aim.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace {

constexpr double radians_to_degrees = 57.2957795130823208768;
constexpr uint32_t required_flags =
    HEAD_AIM_ALIVE | HEAD_AIM_VISIBLE | HEAD_AIM_OPPONENT;

bool finite(const HeadAimVec3& value) {
    return std::isfinite(value.x) && std::isfinite(value.y) &&
           std::isfinite(value.z);
}

double length(const HeadAimVec3& value) {
    return std::hypot(value.x, value.y, value.z);
}

HeadAimVec3 unit(const HeadAimVec3& value, double magnitude) {
    return {value.x / magnitude, value.y / magnitude, value.z / magnitude};
}

HeadAimStatus between(const HeadAimVec3& camera, const HeadAimVec3& head,
                      HeadAimVec3& result, double& distance) {
    if (!finite(camera) || !finite(head)) {
        return HEAD_AIM_INVALID_ARGUMENT;
    }
    const HeadAimVec3 delta{head.x - camera.x, head.y - camera.y,
                           head.z - camera.z};
    distance = length(delta);
    if (!finite(delta) || !std::isfinite(distance)) {
        return HEAD_AIM_INVALID_ARGUMENT;
    }
    if (distance == 0.0) {
        return HEAD_AIM_COINCIDENT;
    }
    result = unit(delta, distance);
    return HEAD_AIM_OK;
}

double angle_degrees(const HeadAimVec3& a, const HeadAimVec3& b) {
    const HeadAimVec3 cross{a.y * b.z - a.z * b.y,
                           a.z * b.x - a.x * b.z,
                           a.x * b.y - a.y * b.x};
    const double dot = a.x * b.x + a.y * b.y + a.z * b.z;
    // atan2 preserves small angles and works at both 0 and 180 degrees.
    return std::atan2(length(cross), dot) * radians_to_degrees;
}

} // namespace

extern "C" HEAD_AIM_API uint32_t HEAD_AIM_CALL HeadAimApiVersion(void) {
    return 1u;
}

extern "C" HEAD_AIM_API HeadAimStatus HEAD_AIM_CALL HeadAimDirection(
    const HeadAimVec3* camera, const HeadAimVec3* head, HeadAimVec3* direction) {
    if (!camera || !head || !direction) {
        return HEAD_AIM_INVALID_ARGUMENT;
    }
    HeadAimVec3 result{};
    double distance = 0.0;
    const auto status = between(*camera, *head, result, distance);
    if (status == HEAD_AIM_OK) {
        *direction = result;
    }
    return status;
}

extern "C" HEAD_AIM_API HeadAimStatus HEAD_AIM_CALL HeadAimSelect(
    const HeadAimVec3* camera, const HeadAimVec3* current_direction,
    const HeadAimCandidate* candidates, uint32_t count, double max_angle_degrees,
    double max_distance, uint32_t* selected_id, HeadAimVec3* direction) {
    if (!camera || !current_direction || !selected_id || !direction ||
        (count != 0u && !candidates) || !finite(*camera) ||
        !finite(*current_direction) || !std::isfinite(max_angle_degrees) ||
        max_angle_degrees < 0.0 || max_angle_degrees > 180.0 ||
        !std::isfinite(max_distance) || max_distance <= 0.0) {
        return HEAD_AIM_INVALID_ARGUMENT;
    }
    const double current_length = length(*current_direction);
    if (!std::isfinite(current_length) || current_length == 0.0) {
        return HEAD_AIM_INVALID_ARGUMENT;
    }
    const auto current = unit(*current_direction, current_length);
    bool found = false;
    double best_angle = std::numeric_limits<double>::infinity();
    double best_distance = std::numeric_limits<double>::infinity();
    uint32_t best_id = 0u;
    HeadAimVec3 best_direction{};

    for (uint32_t i = 0u; i < count; ++i) {
        const auto& candidate = candidates[i];
        if ((candidate.flags & required_flags) != required_flags) {
            continue;
        }
        HeadAimVec3 candidate_direction{};
        double distance = 0.0;
        const auto status =
            between(*camera, candidate.head, candidate_direction, distance);
        if (status == HEAD_AIM_COINCIDENT) {
            continue;
        }
        if (status != HEAD_AIM_OK) {
            return status;
        }
        if (distance > max_distance) {
            continue;
        }
        const double angle = angle_degrees(current, candidate_direction);
        if (angle > max_angle_degrees) {
            continue;
        }
        const bool better = !found || angle < best_angle ||
            (angle == best_angle && (distance < best_distance ||
             (distance == best_distance && candidate.id < best_id)));
        if (better) {
            found = true;
            best_angle = angle;
            best_distance = distance;
            best_id = candidate.id;
            best_direction = candidate_direction;
        }
    }
    if (!found) {
        return HEAD_AIM_NO_TARGET;
    }
    *selected_id = best_id;
    *direction = best_direction;
    return HEAD_AIM_OK;
}
