@echo off
setlocal
cd /d "%~dp0"
where cl >nul 2>nul
if errorlevel 1 (
  echo ERROR: Run from x64 Native Tools Command Prompt for VS 2022.
  exit /b 1
)
if not exist build mkdir build
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /Febuild\contract-tests.exe /Fobuild\ bridge.cpp tests.cpp
if errorlevel 1 exit /b 1
build\contract-tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /LD /Febuild\VBoxDbgHeadAimBridge.dll /Fobuild\ bridge.cpp plugin.cpp advapi32.lib /link /MACHINE:X64
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -Command "Get-FileHash -LiteralPath 'build\VBoxDbgHeadAimBridge.dll' -Algorithm SHA256 | Format-List"
if errorlevel 1 exit /b 1
echo BUILD_ONLY_COMPLETE: Existing original-build guard preserved. MSI5 runtime support UNVERIFIED.
exit /b 0
