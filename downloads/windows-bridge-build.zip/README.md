# Windows bridge compilation bundle

Scope: source compilation and simulated-host tests only. This is NOT an MSI5-enabled deployment package. The plugin retains the original exact VMM hash guard, so it intentionally rejects the uploaded MSI5 VMM. Do not copy the resulting DLL into BlueStacks or load it as an MSI5 bridge.

Install Visual Studio Build Tools2022 with Desktop development with C++ (MSVC v143 x64/x86 and Windows SDK). Open x64 Native Tools Command Prompt for VS2022, change into the extracted bundle and run Build-Windows.cmd. It stops on compiler/test failure, runs simulated-host tests before linking the DLL, and prints the output SHA256. No host VM or game is contacted by the build command. Compilation of plugin.cpp does not execute it.

Linux g++ optimized and ASan/UBSan tests passed for the same bridge/test source. MSVC build is NOT_RUN in this cloud environment. Any MSVC warning/error must be reviewed, not suppressed to force a pass. Existing exact-hash guard and cleanup pin are preserved. Changing the guard is not a supported way to validate another VMM build.

Remaining: full read-helper/locking audit, an exact MSI5 profile with appropriate tests, and actual Windows load/read/unload verification. Camera, target and visibility calibration and aim integration remain separate unverified work.
