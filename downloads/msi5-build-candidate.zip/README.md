# MSI5 exact-hash build candidate

This is an experimental compilation candidate, not a compatible/approved deployment. Source differs from the original plugin ONLY by its exact VMM digest. This makes it specific to the uploaded MSI5 DLL but does not establish ABI safety. Never substitute this candidate into the existing camera/projection kit. No runtime loader or game integration is included.

Build-Windows.cmd requires an x64 Visual Studio developer environment. It runs the portable simulated-host tests and builds VBoxDbgMsi5Candidate.dll. Send console output and the resulting DLL for static inspection only. Do not load/copy it into BlueStacks.

Partial static contracts corroborated: init/term arguments, callback argument preparation/storage, physical-address layout, bounded read dispatch, individual/bulk unload shape. Remaining: transitive read helpers, reentrancy/locking guarantees and actual MSI5 Windows lifecycle. Runtime tests are NOT_RUN. Camera/viewport/landmark/target/LOS/aim verification remains separate.
