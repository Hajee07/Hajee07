@echo off
setlocal
cd /d "%~dp0"
where cl >nul 2>nul
if errorlevel 1 (
  echo ERROR: Run from x64 Native Tools Command Prompt for VS 2022.
  exit /b 1
)
if not exist build mkdir build
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /Febuild\contract-tests.exe /Fobuild\ bridge.cpp tests.cpp
if errorlevel 1 exit /b 1
build\contract-tests.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /LD /Febuild\VBoxDbgMsi5Candidate.dll /Fobuild\ bridge.cpp plugin.cpp advapi32.lib /link /MACHINE:X64
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -Command "Get-FileHash -LiteralPath 'build\VBoxDbgMsi5Candidate.dll' -Algorithm SHA256 | Format-List"
if errorlevel 1 exit /b 1
echo BUILD_ONLY_COMPLETE: EXPERIMENTAL MSI5 exact-hash candidate. Runtime NOT_RUN. DO NOT LOAD into BlueStacks.
exit /b 0
