# Experimental MSI5 lifecycle probe

Requires running Pie64 home screen and64-bit Administrator Windows PowerShell. Free Fire is not required. Run Run-Msi5Lifecycle.ps1. This actively loads the candidate via the VM debugger SDK, requests a single physical byte at address0 (contents omitted), unloads only its returned plugin identity, checks handler removal and releases its shared session. It will not replace an existing headbridge handler. No camera/player traversal, aim update or guest-memory writes are requested. Host plugin registration and VM bookkeeping do change.

This is the first runtime compatibility experiment for this exact VMM/candidate pair, not a supported deployment or full compatibility proof. A native plugin defect can affect the running emulator. Save emulator work first. Do not run parallel camera/bridge probes. On failure preserve output, do not repeatedly retry unchanged and do not force-unload unknown handlers. A clean completed probe proves only this limited lifecycle/read path, not Free Fire mappings or aim.

Reused existing runner lifecycle with exact MSI5 digest and candidate identity bound in the runner. Offline bridge contracts and sanitizers passed; new runner syntax checked on PowerShell7. Actual Windows COM execution is NOT_RUN in cloud. Existing installed game/emulator files are never replaced by this kit.
