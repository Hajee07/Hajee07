@echo off
setlocal EnableExtensions DisableDelayedExpansion
title NOVA old EXE cleanup - quarantine and Defender scan

rem This script does not execute the old EXE. It moves only exact known files.
rem Run it after closing all NOVA windows. For System32 files, right-click and
rem choose "Run as administrator". Do not turn off Windows Security.

if not defined LOCALAPPDATA goto :missing_profile
set "NOVA_STAMP="
for /f "usebackq delims=" %%T in (`powershell.exe -NoProfile -Command "Get-Date -Format 'yyyyMMdd-HHmmss'" 2^>nul`) do set "NOVA_STAMP=%%T"
if not defined NOVA_STAMP set "NOVA_STAMP=unknown-date"
set "NOVA_Q=%LOCALAPPDATA%\NOVA-Cleanup\Quarantine-%NOVA_STAMP%-%RANDOM%"
md "%NOVA_Q%\OldExe" >nul 2>&1
md "%NOVA_Q%\Temp" >nul 2>&1
md "%NOVA_Q%\System32" >nul 2>&1
md "%NOVA_Q%\Config" >nul 2>&1
if not exist "%NOVA_Q%\OldExe\" goto :cannot_create
set "NOVA_LOG=%NOVA_Q%\cleanup.log"
set "NOVA_MOVED=0"
set "NOVA_FAILED=0"
set "NOVA_UNKNOWN=0"
set "NOVA_ITEM=0"
echo NOVA old EXE cleanup - %DATE% %TIME% > "%NOVA_LOG%"
echo Quarantine: "%NOVA_Q%" >> "%NOVA_LOG%"
echo This is a targeted cleanup, not proof that the PC is malware-free. >> "%NOVA_LOG%"
echo.
echo Close all NOVA windows before this script continues.
echo Quarantine and log: "%NOVA_Q%"
echo BlueStacks and unrelated files will not be changed.
echo.

fltmc >nul 2>&1
if errorlevel 1 goto :not_admin
echo Administrator access: yes >> "%NOVA_LOG%"
goto :after_admin
:not_admin
echo Administrator access: no >> "%NOVA_LOG%"
echo Not running as administrator. System32 moves may fail; failures are logged.
:after_admin

rem Drag an old NOVA EXE onto this BAT to check any location. Common download
rem locations are checked automatically, using SHA-256 before any EXE is moved.
if not "%~1"=="" call :candidate "%~1"
for %%N in ("NOVA-External-Desktop-Experimental.exe" "NOVA-External-Experimental.exe" "NOVA-External-Desktop.exe" "NOVA XITERS INTERNAL V2.exe" "NOVA-XITERS-INTERNAL-V2-no-login.exe") do call :scan_roots "%%~N"

rem The old external host extracted two DLLs into its own temporary folder.
rem Verify the OLD engine's SHA-256 first, so the hardened build is untouched.
for /d %%D in ("%TEMP%\NOVA_external_*") do call :temp_folder "%%~fD"

rem These are the two exact script destinations in the old engine. Their
rem contents on this PC are unknown, so keep a renamed backup for review.
call :quarantine_file "C:\Windows\System32\bypass.bat" "%NOVA_Q%\System32\bypass.bat.quarantined"
call :quarantine_file "C:\Windows\System32\tempcleaner.bat" "%NOVA_Q%\System32\tempcleaner.bat.quarantined"
rem Sysnative reaches the real System32 when launched from a 32-bit CMD.
call :quarantine_file "C:\Windows\Sysnative\bypass.bat" "%NOVA_Q%\System32\bypass.bat.quarantined"
call :quarantine_file "C:\Windows\Sysnative\tempcleaner.bat" "%NOVA_Q%\System32\tempcleaner.bat.quarantined"
call :quarantine_file "C:\ImGuiConfig.bin" "%NOVA_Q%\Config\ImGuiConfig.bin.quarantined"

rem The engine also created this app-data location. Its contents were not
rem recovered, so report and scan it without deleting or moving unknown data.
set "NOVA_APPDATA=%LOCALAPPDATA%\NovaXite\BRUTAL-X"
if exist "%NOVA_APPDATA%" echo App-data path present: "%NOVA_APPDATA%" >> "%NOVA_LOG%"

echo.
echo Updating Microsoft Defender signatures, if Defender is available...
powershell.exe -NoProfile -Command "try { Update-MpSignature -ErrorAction Stop; exit 0 } catch { Write-Error $_; exit 1 }" >> "%NOVA_LOG%" 2>&1
if errorlevel 1 echo Defender signature update did not complete. Check the log and Windows Security.

echo Scanning quarantined files with Microsoft Defender...
powershell.exe -NoProfile -Command "try { Start-MpScan -ScanType CustomScan -ScanPath $env:NOVA_Q -ErrorAction Stop; exit 0 } catch { Write-Error $_; exit 1 }" >> "%NOVA_LOG%" 2>&1
if errorlevel 1 echo Defender custom scan did not complete. Check the log and Windows Security.
if not exist "%NOVA_APPDATA%" goto :skip_appdata_scan
echo Scanning the NOVA app-data path...
powershell.exe -NoProfile -Command "try { Start-MpScan -ScanType CustomScan -ScanPath $env:NOVA_APPDATA -ErrorAction Stop; exit 0 } catch { Write-Error $_; exit 1 }" >> "%NOVA_LOG%" 2>&1
if errorlevel 1 echo Defender app-data scan did not complete. Check the log.
:skip_appdata_scan
echo Starting Microsoft Defender Quick Scan...
powershell.exe -NoProfile -Command "try { Start-MpScan -ScanType QuickScan -ErrorAction Stop; exit 0 } catch { Write-Error $_; exit 1 }" >> "%NOVA_LOG%" 2>&1
if errorlevel 1 echo Defender Quick Scan did not complete. Check Windows Security.
powershell.exe -NoProfile -Command "Get-MpComputerStatus -ErrorAction SilentlyContinue | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,QuickScanEndTime | Format-List; Get-MpThreatDetection -ErrorAction SilentlyContinue | Select-Object ThreatID,ActionSuccess,InitialDetectionTime,Resources | Format-List" >> "%NOVA_LOG%" 2>&1

echo. >> "%NOVA_LOG%"
echo Files quarantined: %NOVA_MOVED% >> "%NOVA_LOG%"
echo Move failures: %NOVA_FAILED% >> "%NOVA_LOG%"
echo Unmatched EXE hashes left in place: %NOVA_UNKNOWN% >> "%NOVA_LOG%"
echo.
echo Files quarantined: %NOVA_MOVED%  Move failures: %NOVA_FAILED%
echo Unmatched EXE hashes left in place: %NOVA_UNKNOWN%
echo Review the log: "%NOVA_LOG%"
echo Review Windows Security ^> Virus ^& threat protection ^> Protection history.
echo If the laptop stays slow, use Windows Security Scan options for a Full
echo Scan or Microsoft Defender Offline scan, then share the detection name.
echo This script does not prove that a virus was present or fully removed.
echo.
pause
exit /b 0

:scan_roots
call :candidate "%USERPROFILE%\Downloads\%~1"
call :candidate "%USERPROFILE%\Desktop\%~1"
call :candidate "%USERPROFILE%\Documents\%~1"
call :candidate "%USERPROFILE%\Downloads\NOVA-External-Desktop-Experimental\%~1"
call :candidate "%USERPROFILE%\Downloads\NOVA-External-Experimental\%~1"
call :candidate "%USERPROFILE%\Downloads\external-desktop-experimental\%~1"
exit /b 0

:candidate
if not exist "%~1" exit /b 0
if exist "%~1\NUL" exit /b 0
set "NOVA_HASH_TARGET=%~1"
call :get_hash
echo Candidate EXE: "%~1" SHA-256=%NOVA_HASH% >> "%NOVA_LOG%"
set "NOVA_MATCH=0"
if /I "%NOVA_HASH%"=="47024c6269515859ba32749603ff310f92bcb6e3e2dfa768b207f9fd733cd6b6" set "NOVA_MATCH=1"
if /I "%NOVA_HASH%"=="8bf21d30105db28aab6a72c98ffa991ab5504f74a26df5caeb61610b55443e44" set "NOVA_MATCH=1"
if /I "%NOVA_HASH%"=="069d76f5392843bb99ce034a1f8a4de6f8b714f8c94bef16995ff13fc88b7297" set "NOVA_MATCH=1"
if /I "%NOVA_HASH%"=="fb70eb9987a6a2f8a728b0eb8664c39458eafe2b566035f71808edfee4c065a0" set "NOVA_MATCH=1"
if /I "%NOVA_HASH%"=="9df04b4f32da77f0193073ba05e8603fca45e7a8b53c26191cb0468cfc132735" set "NOVA_MATCH=1"
if "%NOVA_MATCH%"=="0" goto :unknown_candidate
set /a NOVA_ITEM+=1 >nul
call :quarantine_file "%~1" "%NOVA_Q%\OldExe\%NOVA_ITEM%-%~nx1.quarantined"
exit /b 0
:unknown_candidate
set /a NOVA_UNKNOWN+=1 >nul
echo Unknown or unreadable EXE hash. Left in place: "%~1" >> "%NOVA_LOG%"
exit /b 0

:temp_folder
set "NOVA_FOLDER_TARGET=%~1"
rem Fail closed on directory junctions, symlinks, and unreadable folders.
powershell.exe -NoProfile -Command "try { $i=Get-Item -LiteralPath $env:NOVA_FOLDER_TARGET -Force -ErrorAction Stop; if ($i.Attributes -band [IO.FileAttributes]::ReparsePoint) { exit 1 }; exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 exit /b 0
if not exist "%~1\NOVA-engine.dll" exit /b 0
set "NOVA_HASH_TARGET=%~1\NOVA-engine.dll"
call :get_hash
echo Temp engine: "%~1\NOVA-engine.dll" SHA-256=%NOVA_HASH% >> "%NOVA_LOG%"
if /I not "%NOVA_HASH%"=="ac625470cf00fe4ddb7ccc3cec542b7dbb849f399e2e617e01cac88b3ffcc5b7" exit /b 0
set /a NOVA_ITEM+=1 >nul
md "%NOVA_Q%\Temp\%NOVA_ITEM%" >nul 2>&1
call :quarantine_file "%~1\NOVA-engine.dll" "%NOVA_Q%\Temp\%NOVA_ITEM%\NOVA-engine.dll.quarantined"
call :quarantine_file "%~1\BstkVMM.dll" "%NOVA_Q%\Temp\%NOVA_ITEM%\BstkVMM.dll.quarantined"
rd "%~1" >> "%NOVA_LOG%" 2>&1
if exist "%~1\" echo Temp folder has remaining files or is in use: "%~1" >> "%NOVA_LOG%"
exit /b 0

:quarantine_file
if not exist "%~1" exit /b 0
if exist "%~1\NUL" exit /b 0
set "NOVA_HASH_TARGET=%~1"
call :get_hash
echo Quarantine source: "%~1" SHA-256=%NOVA_HASH% >> "%NOVA_LOG%"
move /Y "%~1" "%~2" >> "%NOVA_LOG%" 2>&1
if errorlevel 1 goto :move_failed
set /a NOVA_MOVED+=1 >nul
echo Moved: "%~1" >> "%NOVA_LOG%"
exit /b 0
:move_failed
set /a NOVA_FAILED+=1 >nul
echo FAILED to move: "%~1" >> "%NOVA_LOG%"
exit /b 1

:get_hash
set "NOVA_HASH="
for /f "usebackq delims=" %%H in (`powershell.exe -NoProfile -Command "try { (Get-FileHash -LiteralPath $env:NOVA_HASH_TARGET -Algorithm SHA256 -ErrorAction Stop).Hash } catch { exit 1 }" 2^>nul`) do if not defined NOVA_HASH set "NOVA_HASH=%%H"
exit /b 0

:missing_profile
echo LOCALAPPDATA is unavailable. No files were changed.
pause
exit /b 1
:cannot_create
echo Could not create the quarantine directory. No files were changed.
pause
exit /b 1
