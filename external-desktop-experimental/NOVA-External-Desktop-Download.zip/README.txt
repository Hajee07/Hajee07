NOVA External Desktop - experimental Aim/Scope update

Start BlueStacks Pie 64 and the game, then run the EXE outside HD-Player.
Aim: switch Aimbot ON, focus the game, and hold Aim trigger VK (default 1 = left mouse) near a target in Aim/Scope range. The original Aimbot Visible worker writes guest hit data; it does not move the cursor.
Sniper Scope: hold left mouse near a target within Scope FOV. Head/Body selects the Scope target point. If updated weapon IDs are excluded by the original list, try Scope: any weapon ID.
Visual aim movement: Mouse aim assist (experimental) runs in this external host via Windows SendInput and is OFF by default. Enable it and adjust Mouse assist gain if desired. The game must be foreground; BlueStacks may ignore simulated input.
The Aim tab status reports backend writes or Windows mouse-input acceptance. Neither guarantees an in-game effect. This Linux build could not test Windows, BlueStacks, or gameplay. Some guest page states cannot be written without the original VM-side SDK behavior. No helper or DLL is loaded into HD-Player.
