NOVA External Desktop (experimental)

Extract the EXE and run it after BlueStacks Pie 64 and the game are open. The movable controls window is separate from HD-Player; F8 hides or shows it. The console must stay open. Live game features have not yet been verified. If a feature still fails, send the latest Game base: and Backend: lines from the console.
