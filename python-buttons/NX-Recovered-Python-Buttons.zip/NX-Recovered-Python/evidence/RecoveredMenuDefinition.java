/* Readable reconstruction of 58 observed native -> Java menu calls.
 * Generated from recovered execution, NOT the original Java source.
 * Requires the original com.NovaX.Menu class; this is not a buildable project.
 * Menu definitions do not prove that game features work.
 */
package recovered;

import com.NovaX.Menu;

public final class RecoveredMenuDefinition {
    public static void populate() {
        Menu.addTab("AIM");
        Menu.addSwitch("Enable All", 102);
        Menu.addSwitch("Aimkill MultiTarget", 110);
        Menu.addSwitch("Speed Timer", 517);
        Menu.addSwitch("Speed Slow V2", 1099);
        Menu.addSwitch("Speed Run", 507);
        Menu.addSwitch("Auto Target", 34834);
        Menu.addSwitch("Auto Revive", 7896);
        Menu.addTab("ESP");
        Menu.addSwitch("ESP Line", 1);
        Menu.addSwitch("ESP Box", 2);
        Menu.addSwitch("ESP Health", 3);
        Menu.addSwitch("ESP Weapon Icon", 32);
        Menu.addSwitch("ESP Distance", 4);
        Menu.addSwitch("ESP Grenade", 33);
        Menu.addSwitch("Draw FOV", 16);
        Menu.addTab("LOOK");
        Menu.addCategory("Look Changer");
        Menu.addSwitch("Enable Look Changer", 7100);
        Menu.addSwitch("Show For Others (OS)", 7101);
        Menu.addCategory("Presets");
        Menu.addSwitch("Look 1 - Rampage", 7102);
        Menu.addSwitch("Look 2 - Cobra", 7103);
        Menu.addSwitch("Look 3 - Criminal Red", 7104);
        Menu.addSwitch("Look 4 - Sakura", 7105);
        Menu.addSwitch("Look 5 - Venom", 7106);
        Menu.addSwitch("Look 6 - Titan", 7107);
        Menu.addSwitch("Look 7 - Hip Hop", 7108);
        Menu.addSwitch("Look 8 - Bunny Warrior", 7109);
        Menu.addSwitch("Look 9 - Breakdancer", 7110);
        Menu.addSwitch("Look 10 - Arctic Blue", 7111);
        Menu.addSwitch("Look 11 - Naruto", 7112);
        Menu.addSwitch("Look 12 - Sasuke", 7113);
        Menu.addSwitch("Look 13 - Kakashi", 7114);
        Menu.addSwitch("Look 14 - Saitama", 7115);
        Menu.addSwitch("Look 15 - Dino", 7116);
        Menu.addSwitch("Look 16 - Old Man", 7117);
        Menu.addSwitch("Look 17 - Criminal Blue", 7118);
        Menu.addSwitch("Look 18 - Criminal Green", 7119);
        Menu.addSwitch("Look 19 - Angelic Set", 7120);
        Menu.addSwitch("Look 20 - Galaxy Set", 7121);
        Menu.addTab("BRTL");
        Menu.addSwitch("Fly Lock", 5194);
        Menu.addSwitch("Rise Up", 111);
        Menu.addSeekBar("Rise Up New Height", 15, 100, "M", 5660);
        Menu.addSwitch("Tp Anywhere", 5198);
        Menu.addSwitch("TeleSpot [MANUAL]", 59910);
        Menu.addSwitch("TeleSpot [AUTO]", 59912);
        Menu.addSwitch("Wide Camera", 7003);
        Menu.addSwitch("Invisible Kill", 532);
        Menu.addSwitch("Black Sky", 7001);
        Menu.addSwitch("Downkill", 5658);
        Menu.addSwitch("Joystick Speed", 114);
        Menu.addTab("SET");
        Menu.addSwitch("Show Keybinds", 6002);
        Menu.addSwitch("Enable Keybind System", 6000);
        Menu.addSwitch("Show Match Timer", 6003);
        Menu.addSwitch("Clear All Keybinds", 6001);
    }
}
