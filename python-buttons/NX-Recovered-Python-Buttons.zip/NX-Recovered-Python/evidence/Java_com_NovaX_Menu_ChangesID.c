/* Decompiled C-like pseudocode from an emulated unpacked memory image.
 * This is NOT original C/C++ source and is NOT independently buildable.
 * Types, signatures and names can be inferred or incomplete.
 * Android/game behavior has not been tested.
 */


void Java_com_NovaX_Menu_ChangesID(int *param_1,undefined4 param_2,int param_3,uint param_4)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  byte *pbVar12;
  undefined *puVar13;
  undefined (*pauVar14) [16];
  undefined4 *puVar15;
  undefined4 uVar16;
  int *piVar17;
  uint in_fpscr;
  float fVar18;
  uint uVar19;
  undefined auVar20 [16];
  undefined8 local_29c8;
  ulonglong local_29c0;
  undefined8 local_29b8;
  ulonglong local_29b0;
  undefined auStack_29a8 [184];
  undefined8 local_28f0;
  undefined8 uStack_28e8;
  undefined4 local_28e0;
  undefined4 local_28dc;
  undefined8 local_2840;
  undefined8 uStack_2838;
  undefined4 local_2830;
  undefined4 local_282c;
  undefined8 local_2790;
  undefined8 uStack_2788;
  undefined4 local_2780;
  undefined4 local_277c;
  undefined8 local_26e0;
  undefined8 uStack_26d8;
  undefined4 local_26d0;
  undefined4 local_26cc;
  undefined8 local_2630;
  undefined8 uStack_2628;
  undefined4 local_2620;
  undefined4 local_261c;
  undefined8 local_2580;
  undefined8 uStack_2578;
  undefined4 local_2570;
  undefined4 local_256c;
  undefined8 local_24d0;
  undefined8 uStack_24c8;
  undefined4 local_24c0;
  undefined4 local_24bc;
  undefined8 local_2420;
  undefined8 uStack_2418;
  undefined4 local_2410;
  undefined4 local_240c;
  undefined8 local_2370;
  undefined8 uStack_2368;
  undefined4 local_2360;
  undefined4 local_235c;
  undefined8 local_22c0;
  undefined8 uStack_22b8;
  undefined4 local_22b0;
  undefined4 local_22ac;
  undefined8 local_2210;
  undefined8 uStack_2208;
  undefined4 local_2200;
  undefined4 local_21fc;
  undefined8 local_2160;
  undefined8 uStack_2158;
  undefined4 local_2150;
  undefined4 local_214c;
  undefined8 local_20b0;
  undefined8 uStack_20a8;
  undefined4 local_20a0;
  undefined4 local_209c;
  undefined8 local_2000;
  undefined8 uStack_1ff8;
  undefined4 local_1ff0;
  undefined4 local_1fec;
  undefined8 local_1f50;
  undefined8 uStack_1f48;
  undefined4 local_1f40;
  undefined4 local_1f3c;
  undefined8 local_1ea0;
  undefined8 uStack_1e98;
  undefined4 local_1e90;
  undefined4 local_1e8c;
  undefined8 local_1df0;
  undefined8 uStack_1de8;
  undefined4 local_1de0;
  undefined4 local_1ddc;
  undefined8 local_1d40;
  undefined8 uStack_1d38;
  undefined4 local_1d30;
  undefined4 local_1d2c;
  undefined8 local_1c90;
  undefined8 uStack_1c88;
  undefined4 local_1c80;
  undefined4 local_1c7c;
  undefined8 local_1be0;
  undefined8 uStack_1bd8;
  undefined4 local_1bd0;
  undefined4 local_1bcc;
  undefined8 local_1b30;
  undefined8 uStack_1b28;
  undefined4 local_1b20;
  undefined4 local_1b1c;
  undefined8 local_1a80;
  undefined8 uStack_1a78;
  undefined4 local_1a70;
  undefined4 local_1a6c;
  undefined8 local_19d0;
  undefined8 uStack_19c8;
  undefined4 local_19c0;
  undefined4 local_19bc;
  undefined8 local_1920;
  undefined8 uStack_1918;
  undefined4 uStack_1910;
  undefined4 uStack_190c;
  undefined8 local_1870;
  undefined8 uStack_1868;
  undefined4 uStack_1860;
  undefined4 uStack_185c;
  undefined8 local_17c0;
  undefined8 uStack_17b8;
  undefined4 uStack_17b0;
  undefined4 uStack_17ac;
  undefined8 local_1710;
  undefined8 uStack_1708;
  undefined4 uStack_1700;
  undefined4 uStack_16fc;
  undefined8 local_1660;
  undefined8 uStack_1658;
  undefined4 uStack_1650;
  undefined4 uStack_164c;
  undefined8 local_15b0;
  undefined8 uStack_15a8;
  undefined4 uStack_15a0;
  undefined4 uStack_159c;
  undefined8 local_1500;
  undefined8 uStack_14f8;
  undefined4 uStack_14f0;
  undefined4 uStack_14ec;
  undefined8 local_1450;
  undefined8 uStack_1448;
  undefined4 uStack_1440;
  undefined4 uStack_143c;
  undefined8 local_13a0;
  undefined8 uStack_1398;
  undefined4 uStack_1390;
  undefined4 uStack_138c;
  undefined8 local_12f0;
  undefined8 uStack_12e8;
  undefined4 uStack_12e0;
  undefined4 uStack_12dc;
  undefined8 local_1240;
  undefined8 uStack_1238;
  undefined4 uStack_1230;
  undefined4 uStack_122c;
  undefined8 local_1190;
  undefined8 uStack_1188;
  undefined4 uStack_1180;
  undefined4 uStack_117c;
  undefined8 local_10e0;
  undefined8 uStack_10d8;
  undefined4 uStack_10d0;
  undefined4 uStack_10cc;
  undefined8 local_1030;
  undefined8 uStack_1028;
  undefined4 uStack_1020;
  undefined4 uStack_101c;
  undefined8 local_f80;
  undefined8 uStack_f78;
  undefined4 uStack_f70;
  undefined4 uStack_f6c;
  undefined8 local_ed0;
  undefined8 uStack_ec8;
  undefined4 uStack_ec0;
  undefined4 uStack_ebc;
  undefined8 local_e20;
  undefined8 uStack_e18;
  undefined4 uStack_e10;
  undefined4 uStack_e0c;
  undefined8 local_d70;
  undefined8 uStack_d68;
  undefined4 uStack_d60;
  undefined4 uStack_d5c;
  undefined8 local_cc0;
  undefined8 uStack_cb8;
  undefined4 uStack_cb0;
  undefined4 uStack_cac;
  undefined8 local_c10;
  undefined8 uStack_c08;
  undefined4 uStack_c00;
  undefined4 uStack_bfc;
  undefined8 local_b60;
  undefined8 uStack_b58;
  undefined4 uStack_b50;
  undefined4 uStack_b4c;
  undefined8 local_ab0;
  undefined8 uStack_aa8;
  undefined4 uStack_aa0;
  undefined4 uStack_a9c;
  undefined8 local_a00;
  undefined8 uStack_9f8;
  undefined4 uStack_9f0;
  undefined4 uStack_9ec;
  undefined8 local_950;
  undefined8 uStack_948;
  undefined4 uStack_940;
  undefined4 uStack_93c;
  undefined8 local_8a0;
  undefined8 uStack_898;
  undefined4 uStack_890;
  undefined4 uStack_88c;
  undefined8 local_7f0;
  undefined8 uStack_7e8;
  undefined4 uStack_7e0;
  undefined4 uStack_7dc;
  undefined8 local_740;
  undefined8 uStack_738;
  undefined4 uStack_730;
  undefined4 uStack_72c;
  undefined8 local_690;
  undefined8 uStack_688;
  undefined4 uStack_680;
  undefined4 uStack_67c;
  undefined8 local_5e0;
  undefined8 uStack_5d8;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined8 local_530;
  undefined8 uStack_528;
  undefined4 uStack_520;
  undefined4 uStack_51c;
  undefined8 local_480;
  undefined8 uStack_478;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined8 local_3d0;
  undefined8 uStack_3c8;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  undefined8 local_320;
  undefined8 uStack_318;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined8 local_270;
  undefined8 uStack_268;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined8 local_1c0;
  undefined8 uStack_1b8;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 local_110;
  undefined8 uStack_108;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  int local_44;
  
  iVar7 = DAT_100967c0;
  iVar8 = DAT_10096778;
  iVar6 = DAT_1009674c;
  iVar5 = DAT_10096744;
  iVar4 = DAT_10096738;
  iVar3 = DAT_10096730;
  iVar2 = DAT_10096724;
  iVar9 = DAT_10094c48;
  iVar11 = DAT_10094598;
  piVar17 = *(int **)(DAT_10093d9c + 0x10093138);
  local_44 = *piVar17;
  if (0x144d < param_3) {
    if (0x1eb9 < param_3) {
      if (0xea05 < param_3) {
        uVar16 = 0x56552b;
        if (param_3 == 0x56552b) {
          pbVar12 = (byte *)(DAT_1009457c + 0x100938f0);
          bVar1 = *pbVar12;
          iVar8 = DAT_10094580 + 0x100938fc;
LAB_100938f8:
          *pbVar12 = bVar1 ^ 1;
          local_29c8 = (ulonglong)CONCAT14(bVar1,uVar16) ^ 0x100000000;
          goto LAB_10098314;
        }
        uVar16 = 0xea08;
        if (param_3 == 0xea08) {
          iVar9 = DAT_10094584 + 0x10093930;
        }
        else {
          uVar16 = 0xea06;
          if (param_3 != 0xea06) goto switchD_10093180_caseD_1ff;
          iVar9 = DAT_10094574 + 0x100937b4;
        }
        goto LAB_1009838c;
      }
      switch(param_3) {
      case 0xdd02:
        bVar1 = *(byte *)(DAT_10094594 + 0x10093a44);
        *(byte *)(DAT_10094594 + 0x10093a44) = bVar1 ^ 1;
        iVar9 = iVar11 + 0x10093a5c;
        local_29c8._4_4_ = bVar1 ^ 1;
        param_3 = 0xdd02;
        goto LAB_1009349c;
      case 0xdd03:
      case 0xdd0b:
        goto switchD_10093180_caseD_1ff;
      case 0xdd04:
        iVar8 = DAT_10098b18 + 0x100980c4;
        uVar16 = 0xdd04;
        break;
      case 0xdd05:
        iVar8 = DAT_10098b1c + 0x100980e8;
        uVar16 = 0xdd05;
        break;
      case 0xdd06:
        iVar8 = DAT_10098b20 + 0x1009810c;
        uVar16 = 0xdd06;
        break;
      case 0xdd07:
        iVar8 = DAT_10098b24 + 0x10098130;
        uVar16 = 0xdd07;
        break;
      case 0xdd08:
        iVar8 = DAT_10098b28 + 0x10098154;
        uVar16 = 0xdd08;
        break;
      case 0xdd09:
        iVar8 = DAT_10098b2c + 0x10098178;
        uVar16 = 0xdd09;
        break;
      case 0xdd0a:
        iVar8 = DAT_10098b30 + 0x1009819c;
        uVar16 = 0xdd0a;
        break;
      case 0xdd0c:
        iVar8 = DAT_10098b34 + 0x100981c0;
        uVar16 = 0xdd0c;
        break;
      case 0xdd0d:
        iVar8 = DAT_10098b38 + 0x100981e4;
        uVar16 = 0xdd0d;
        break;
      case 0xdd0e:
        uVar19 = VectorSignedToFloat(param_4,(byte)(in_fpscr >> 0x15) & 3);
        local_29b0 = 0;
        local_29b8 = (ulonglong)local_29b8._4_4_ << 0x20;
        local_29c8 = (ulonglong)local_29c8._5_3_ << 0x28;
        local_29c8 = CONCAT44(local_29c8._4_4_,0xdd0e);
        local_29c0 = (ulonglong)uVar19;
        iVar11 = FUN_1009d8f4(DAT_10098b3c + 0x10098208,&local_29c8,0x20);
        if (iVar11 != 0) {
          __aeabi_memclr8(auStack_29a8,0x2960);
          iVar11 = DAT_10098b40 + 0x10098250;
          goto LAB_10097ad4;
        }
        goto switchD_10093180_caseD_1ff;
      case 0xdd0f:
        iVar8 = DAT_10098b44 + 0x1009826c;
        uVar16 = 0xdd0f;
        break;
      case 0xdd10:
        iVar8 = DAT_10098b48 + 0x10098290;
        uVar16 = 0xdd10;
        break;
      case 0xdd11:
        iVar8 = DAT_10098b4c + 0x100982b4;
        uVar16 = 0xdd11;
        break;
      case 0xdd12:
        iVar8 = DAT_10098b50 + 0x100982d8;
        uVar16 = 0xdd12;
        break;
      default:
        switch(param_3) {
        case 0x1eba:
          iVar8 = DAT_100945b0 + 0x10093be4;
          uVar16 = 0x1eba;
          goto LAB_10098304;
        case 0x1ebb:
          iVar8 = DAT_10098b14 + 0x100982fc;
          uVar16 = 0x1ebb;
          goto LAB_10098304;
        case 0x1ebc:
        case 0x1ebd:
        case 0x1ebe:
        case 0x1ebf:
        case 0x1ec0:
        case 0x1ec1:
        case 0x1ec2:
        case 0x1ec3:
        case 0x1ec4:
        case 0x1ec5:
        case 0x1ec6:
        case 0x1ec7:
        case 0x1ec8:
        case 0x1ec9:
        case 0x1eca:
        case 0x1ecb:
        case 0x1ecc:
        case 0x1ecd:
        case 0x1ece:
        case 0x1ecf:
        case 0x1ed0:
        case 0x1ed1:
        case 0x1ed2:
        case 0x1ed3:
        case 0x1ed4:
        case 0x1ed5:
        case 0x1ed6:
        case 0x1ed7:
        case 0x1ed9:
          break;
        case 0x1ed8:
          iVar9 = DAT_10098ae8 + 0x10098358;
          uVar16 = 0x1ed8;
          goto LAB_1009838c;
        case 0x1eda:
          iVar9 = DAT_10098aec + 0x10098384;
          uVar16 = 0x1eda;
          goto LAB_1009838c;
        default:
          uVar16 = 0x8812;
          if (param_3 == 0x8812) {
            iVar9 = DAT_10098ae0 + 0x100980a8;
            goto LAB_1009838c;
          }
        }
        goto switchD_10093180_caseD_1ff;
      }
LAB_10098304:
      local_29c8._0_5_ = CONCAT14(param_4 == 1,uVar16);
      local_29c8 = (ulonglong)(uint5)local_29c8;
      goto LAB_10098314;
    }
    if (param_3 < 0x161c) {
      uVar16 = 0x144e;
      if (param_3 != 0x144e) {
        if (param_3 == 0x161a) {
          iVar8 = DAT_100945ac + 0x10093b20;
          uVar16 = 0x1f8;
        }
        else {
          if (param_3 != 0x161b) goto switchD_10093180_caseD_1ff;
          iVar8 = DAT_10094590 + 0x100939cc;
          uVar16 = 0x161b;
        }
        goto LAB_10098304;
      }
      pbVar12 = (byte *)(DAT_100945a4 + 0x10093ad4);
      bVar1 = *pbVar12;
      iVar9 = DAT_100945a8 + 0x10093ae0;
LAB_10093adc:
      *pbVar12 = bVar1 ^ 1;
      local_29c8 = (ulonglong)CONCAT14(bVar1,uVar16) ^ 0x100000000;
      goto LAB_1009839c;
    }
    switch(param_3) {
    case 0x1b59:
      goto switchD_10093288_caseD_1b59;
    case 0x1b5a:
      iVar9 = DAT_1009679c + 0x10096540;
      uVar16 = 0x1b5a;
      break;
    case 0x1b5b:
      iVar9 = DAT_100967a0 + 0x10096564;
      uVar16 = 0x1b5b;
      break;
    case 0x1b5c:
      iVar9 = DAT_100967a4 + 0x10096588;
      uVar16 = 0x1b5c;
      break;
    case 0x1b5d:
      uVar16 = 0x1b5d;
      uVar19 = VectorSignedToFloat(param_4,(byte)(in_fpscr >> 0x15) & 3);
      iVar11 = DAT_100967a8 + 0x100965ac;
LAB_10097a8c:
      local_29b0 = 0;
      local_29b8 = local_29b8 & 0xffffffff00000000;
      local_29c8 = CONCAT44((int)(local_29c8 >> 0x20),uVar16) & 0xffffff00ffffffff;
      local_29c0 = (ulonglong)uVar19;
      iVar11 = FUN_1009d8f4(iVar11,&local_29c8,0x20);
      if (iVar11 != 0) {
        __aeabi_memclr8(auStack_29a8,0x2960);
        iVar11 = DAT_10098a48 + 0x10097ad8;
LAB_10097ad4:
        local_110 = 0;
        uStack_108 = 0;
        goto LAB_10098978;
      }
      goto switchD_10093180_caseD_1ff;
    case 0x1b5e:
      iVar9 = DAT_100967ac + 0x100965c8;
      uVar16 = 0x1b5e;
      break;
    case 0x1b5f:
      iVar9 = DAT_100967b0 + 0x100965ec;
      uVar16 = 0x1b5f;
      break;
    case 0x1b60:
      iVar9 = DAT_100967b4 + 0x10096610;
      uVar16 = 0x1b60;
      break;
    case 0x1b61:
      iVar9 = DAT_100967b8 + 0x10096634;
      uVar16 = 0x1b61;
      break;
    case 0x1b62:
      bVar1 = *(byte *)(DAT_100967bc + 0x1009664c);
      *(byte *)(DAT_100967bc + 0x1009664c) = bVar1 ^ 1;
      iVar9 = iVar7 + 0x10096664;
      local_29c8._4_4_ = bVar1 ^ 1;
      param_3 = 0x1b62;
LAB_1009349c:
      local_29c8 = CONCAT44(local_29c8._4_4_,param_3);
      goto LAB_1009839c;
    case 0x1b63:
      iVar9 = DAT_100967c4 + 0x10096694;
      uVar16 = 0x1b63;
      break;
    case 0x1b64:
      iVar9 = DAT_100967c8 + 0x100966b8;
      uVar16 = 0x1b64;
      break;
    case 0x1b65:
      iVar9 = DAT_100967cc + 0x100966dc;
      uVar16 = 0x1b65;
      break;
    case 0x1b66:
    case 0x1b67:
    case 0x1b68:
    case 0x1b69:
    case 0x1b6a:
    case 0x1b6b:
    case 0x1b6d:
    case 0x1b6e:
    case 0x1b6f:
    case 0x1b70:
    case 0x1b71:
    case 0x1b72:
    case 0x1b73:
    case 0x1b74:
    case 0x1b75:
    case 0x1b76:
    case 0x1b77:
    case 0x1b78:
    case 0x1b79:
    case 0x1b7a:
    case 0x1b7b:
    case 0x1b7c:
    case 0x1b7d:
    case 0x1b7e:
    case 0x1b7f:
    case 0x1b80:
    case 0x1b81:
    case 0x1b82:
    case 0x1b83:
    case 0x1b84:
    case 0x1b85:
    case 0x1b86:
    case 0x1b87:
    case 0x1b88:
    case 0x1b89:
    case 0x1b8a:
    case 0x1b8b:
    case 0x1b8c:
    case 0x1b8d:
    case 0x1b8e:
    case 0x1b8f:
    case 0x1b90:
    case 0x1b91:
    case 0x1b92:
    case 0x1b93:
    case 0x1b94:
    case 0x1b95:
    case 0x1b96:
    case 0x1b97:
    case 0x1b98:
    case 0x1b99:
    case 0x1b9a:
    case 0x1b9b:
    case 0x1b9c:
    case 0x1b9d:
    case 0x1b9e:
    case 0x1b9f:
    case 0x1ba0:
    case 0x1ba1:
    case 0x1ba2:
    case 0x1ba3:
    case 0x1ba4:
    case 0x1ba5:
    case 0x1ba6:
    case 0x1ba7:
    case 0x1ba8:
    case 0x1ba9:
    case 0x1baa:
    case 0x1bab:
    case 0x1bac:
    case 0x1bad:
    case 0x1bae:
    case 0x1baf:
    case 0x1bb0:
    case 0x1bb1:
    case 0x1bb2:
    case 0x1bb3:
    case 0x1bb4:
    case 0x1bb5:
    case 0x1bb6:
    case 0x1bb7:
    case 0x1bb8:
    case 0x1bb9:
    case 0x1bba:
    case 0x1bbb:
      goto switchD_10093180_caseD_1ff;
    case 0x1b6c:
      auVar20 = ZEXT816(0);
      pbVar12 = (byte *)(DAT_100967d0 + 0x100967f0);
      bVar1 = *pbVar12;
      local_29c0 = 0;
      iVar11 = DAT_100967d4 + 0x10096808;
      local_29b8 = 0;
      local_29b0 = 0;
      *pbVar12 = bVar1 ^ 1;
      local_29c8 = CONCAT44((uint)bVar1,0x1b6c) ^ 0x100000000;
      iVar11 = FUN_1009d8f4(iVar11,&local_29c8,0x20);
      if (iVar11 != 0) {
        __aeabi_memclr8(auStack_29a8,0x2960);
        local_28f0 = auVar20._0_8_;
        uStack_28e8 = auVar20._8_8_;
        local_28dc = 0;
        local_28e0 = 0;
        local_282c = 0;
        local_2830 = 0;
        local_277c = 0;
        local_2780 = 0;
        local_26cc = 0;
        local_26d0 = 0;
        local_261c = 0;
        local_2620 = 0;
        local_256c = 0;
        local_2570 = 0;
        local_24bc = 0;
        local_24c0 = 0;
        local_240c = 0;
        local_2410 = 0;
        local_2360 = 0;
        local_235c = 0;
        local_22b0 = 0;
        local_22ac = 0;
        local_2200 = 0;
        local_21fc = 0;
        local_2150 = 0;
        local_214c = 0;
        local_209c = 0;
        local_20a0 = 0;
        local_1fec = 0;
        local_1ff0 = 0;
        local_1f3c = 0;
        local_1f40 = 0;
        local_1e8c = 0;
        local_1e90 = 0;
        local_1ddc = 0;
        local_1de0 = 0;
        local_1d2c = 0;
        local_1d30 = 0;
        local_1c7c = 0;
        local_1c80 = 0;
        local_1bcc = 0;
        local_1bd0 = 0;
        local_1b1c = 0;
        local_1b20 = 0;
        local_1a6c = 0;
        local_1a70 = 0;
        local_19c0 = 0;
        local_19bc = 0;
        uStack_190c = 0;
        uStack_1910 = 0;
        uStack_185c = 0;
        uStack_1860 = 0;
        uStack_17ac = 0;
        uStack_17b0 = 0;
        uStack_16fc = 0;
        uStack_1700 = 0;
        uStack_164c = 0;
        uStack_1650 = 0;
        uStack_159c = 0;
        uStack_15a0 = 0;
        uStack_14ec = 0;
        uStack_14f0 = 0;
        uStack_143c = 0;
        uStack_1440 = 0;
        uStack_138c = 0;
        uStack_1390 = 0;
        uStack_12dc = 0;
        uStack_12e0 = 0;
        uStack_122c = 0;
        uStack_1230 = 0;
        uStack_117c = 0;
        uStack_1180 = 0;
        uStack_10cc = 0;
        uStack_10d0 = 0;
        uStack_101c = 0;
        uStack_1020 = 0;
        uStack_f6c = 0;
        uStack_f70 = 0;
        uStack_ebc = 0;
        uStack_ec0 = 0;
        uStack_e0c = 0;
        uStack_e10 = 0;
        uStack_d5c = 0;
        uStack_d60 = 0;
        uStack_cac = 0;
        uStack_cb0 = 0;
        uStack_bfc = 0;
        uStack_c00 = 0;
        uStack_b4c = 0;
        uStack_b50 = 0;
        uStack_a9c = 0;
        uStack_aa0 = 0;
        uStack_9ec = 0;
        uStack_9f0 = 0;
        uStack_93c = 0;
        uStack_940 = 0;
        uStack_88c = 0;
        uStack_890 = 0;
        uStack_7dc = 0;
        uStack_7e0 = 0;
        uStack_72c = 0;
        uStack_730 = 0;
        uStack_67c = 0;
        uStack_680 = 0;
        uStack_5cc = 0;
        uStack_5d0 = 0;
        uStack_51c = 0;
        uStack_520 = 0;
        uStack_46c = 0;
        uStack_470 = 0;
        uStack_3bc = 0;
        uStack_3c0 = 0;
        uStack_30c = 0;
        uStack_310 = 0;
        uStack_25c = 0;
        uStack_260 = 0;
        uStack_1ac = 0;
        uStack_1b0 = 0;
        uStack_fc = 0;
        uStack_100 = 0;
        local_58 = 0;
        local_54 = 0;
        local_50 = 0;
        local_2840 = local_28f0;
        uStack_2838 = uStack_28e8;
        local_2790 = local_28f0;
        uStack_2788 = uStack_28e8;
        local_26e0 = local_28f0;
        uStack_26d8 = uStack_28e8;
        local_2630 = local_28f0;
        uStack_2628 = uStack_28e8;
        local_2580 = local_28f0;
        uStack_2578 = uStack_28e8;
        local_24d0 = local_28f0;
        uStack_24c8 = uStack_28e8;
        local_2420 = local_28f0;
        uStack_2418 = uStack_28e8;
        local_2370 = local_28f0;
        uStack_2368 = uStack_28e8;
        local_22c0 = local_28f0;
        uStack_22b8 = uStack_28e8;
        local_2210 = local_28f0;
        uStack_2208 = uStack_28e8;
        local_2160 = local_28f0;
        uStack_2158 = uStack_28e8;
        local_20b0 = local_28f0;
        uStack_20a8 = uStack_28e8;
        local_2000 = local_28f0;
        uStack_1ff8 = uStack_28e8;
        local_1f50 = local_28f0;
        uStack_1f48 = uStack_28e8;
        local_1ea0 = local_28f0;
        uStack_1e98 = uStack_28e8;
        local_1df0 = local_28f0;
        uStack_1de8 = uStack_28e8;
        local_1d40 = local_28f0;
        uStack_1d38 = uStack_28e8;
        local_1c90 = local_28f0;
        uStack_1c88 = uStack_28e8;
        local_1be0 = local_28f0;
        uStack_1bd8 = uStack_28e8;
        local_1b30 = local_28f0;
        uStack_1b28 = uStack_28e8;
        local_1a80 = local_28f0;
        uStack_1a78 = uStack_28e8;
        local_19d0 = local_28f0;
        uStack_19c8 = uStack_28e8;
        local_1920 = local_28f0;
        uStack_1918 = uStack_28e8;
        local_1870 = local_28f0;
        uStack_1868 = uStack_28e8;
        local_17c0 = local_28f0;
        uStack_17b8 = uStack_28e8;
        local_1710 = local_28f0;
        uStack_1708 = uStack_28e8;
        local_1660 = local_28f0;
        uStack_1658 = uStack_28e8;
        local_15b0 = local_28f0;
        uStack_15a8 = uStack_28e8;
        local_1500 = local_28f0;
        uStack_14f8 = uStack_28e8;
        local_1450 = local_28f0;
        uStack_1448 = uStack_28e8;
        local_13a0 = local_28f0;
        uStack_1398 = uStack_28e8;
        local_12f0 = local_28f0;
        uStack_12e8 = uStack_28e8;
        local_1240 = local_28f0;
        uStack_1238 = uStack_28e8;
        local_1190 = local_28f0;
        uStack_1188 = uStack_28e8;
        local_10e0 = local_28f0;
        uStack_10d8 = uStack_28e8;
        local_1030 = local_28f0;
        uStack_1028 = uStack_28e8;
        local_f80 = local_28f0;
        uStack_f78 = uStack_28e8;
        local_ed0 = local_28f0;
        uStack_ec8 = uStack_28e8;
        local_e20 = local_28f0;
        uStack_e18 = uStack_28e8;
        local_d70 = local_28f0;
        uStack_d68 = uStack_28e8;
        local_cc0 = local_28f0;
        uStack_cb8 = uStack_28e8;
        local_c10 = local_28f0;
        uStack_c08 = uStack_28e8;
        local_b60 = local_28f0;
        uStack_b58 = uStack_28e8;
        local_ab0 = local_28f0;
        uStack_aa8 = uStack_28e8;
        local_a00 = local_28f0;
        uStack_9f8 = uStack_28e8;
        local_950 = local_28f0;
        uStack_948 = uStack_28e8;
        local_8a0 = local_28f0;
        uStack_898 = uStack_28e8;
        local_7f0 = local_28f0;
        uStack_7e8 = uStack_28e8;
        local_740 = local_28f0;
        uStack_738 = uStack_28e8;
        local_690 = local_28f0;
        uStack_688 = uStack_28e8;
        local_5e0 = local_28f0;
        uStack_5d8 = uStack_28e8;
        local_530 = local_28f0;
        uStack_528 = uStack_28e8;
        local_480 = local_28f0;
        uStack_478 = uStack_28e8;
        local_3d0 = local_28f0;
        uStack_3c8 = uStack_28e8;
        local_320 = local_28f0;
        uStack_318 = uStack_28e8;
        local_270 = local_28f0;
        uStack_268 = uStack_28e8;
        local_1c0 = local_28f0;
        uStack_1b8 = uStack_28e8;
        local_110 = local_28f0;
        uStack_108 = uStack_28e8;
        FUN_1009d9fc(DAT_100967d8 + 0x10096858,auStack_29a8);
      }
      if (*pbVar12 != 0) {
        auVar20 = ZEXT816(0);
        iVar11 = DAT_10097a70 + 0x10096e2c;
        *(undefined *)(DAT_10097a6c + 0x10096e24) = 1;
        local_29c0 = 0;
        local_29b8 = 0;
        local_29b0 = 0;
        local_29c8 = 0x10000144a;
        iVar11 = FUN_1009d8f4(iVar11,&local_29c8,0x20);
        if (iVar11 != 0) {
          __aeabi_memclr8(auStack_29a8,0x2960);
          local_28f0 = auVar20._0_8_;
          uStack_28e8 = auVar20._8_8_;
          local_28dc = 0;
          local_28e0 = 0;
          local_282c = 0;
          local_2830 = 0;
          local_277c = 0;
          local_2780 = 0;
          local_26cc = 0;
          local_26d0 = 0;
          local_261c = 0;
          local_2620 = 0;
          local_256c = 0;
          local_2570 = 0;
          local_24bc = 0;
          local_24c0 = 0;
          local_240c = 0;
          local_2410 = 0;
          local_2360 = 0;
          local_235c = 0;
          local_22b0 = 0;
          local_22ac = 0;
          local_2200 = 0;
          local_21fc = 0;
          local_2150 = 0;
          local_214c = 0;
          local_209c = 0;
          local_20a0 = 0;
          local_1fec = 0;
          local_1ff0 = 0;
          local_1f3c = 0;
          local_1f40 = 0;
          local_1e8c = 0;
          local_1e90 = 0;
          local_1ddc = 0;
          local_1de0 = 0;
          local_1d2c = 0;
          local_1d30 = 0;
          local_1c7c = 0;
          local_1c80 = 0;
          local_1bcc = 0;
          local_1bd0 = 0;
          local_1b1c = 0;
          local_1b20 = 0;
          local_1a6c = 0;
          local_1a70 = 0;
          local_19c0 = 0;
          local_19bc = 0;
          uStack_190c = 0;
          uStack_1910 = 0;
          uStack_185c = 0;
          uStack_1860 = 0;
          uStack_17ac = 0;
          uStack_17b0 = 0;
          uStack_16fc = 0;
          uStack_1700 = 0;
          uStack_164c = 0;
          uStack_1650 = 0;
          uStack_159c = 0;
          uStack_15a0 = 0;
          uStack_14ec = 0;
          uStack_14f0 = 0;
          uStack_143c = 0;
          uStack_1440 = 0;
          uStack_138c = 0;
          uStack_1390 = 0;
          uStack_12dc = 0;
          uStack_12e0 = 0;
          uStack_122c = 0;
          uStack_1230 = 0;
          uStack_117c = 0;
          uStack_1180 = 0;
          uStack_10cc = 0;
          uStack_10d0 = 0;
          uStack_101c = 0;
          uStack_1020 = 0;
          uStack_f6c = 0;
          uStack_f70 = 0;
          uStack_ebc = 0;
          uStack_ec0 = 0;
          uStack_e0c = 0;
          uStack_e10 = 0;
          uStack_d5c = 0;
          uStack_d60 = 0;
          uStack_cac = 0;
          uStack_cb0 = 0;
          uStack_bfc = 0;
          uStack_c00 = 0;
          uStack_b4c = 0;
          uStack_b50 = 0;
          uStack_a9c = 0;
          uStack_aa0 = 0;
          uStack_9ec = 0;
          uStack_9f0 = 0;
          uStack_93c = 0;
          uStack_940 = 0;
          uStack_88c = 0;
          uStack_890 = 0;
          uStack_7dc = 0;
          uStack_7e0 = 0;
          uStack_72c = 0;
          uStack_730 = 0;
          uStack_67c = 0;
          uStack_680 = 0;
          uStack_5cc = 0;
          uStack_5d0 = 0;
          uStack_51c = 0;
          uStack_520 = 0;
          uStack_46c = 0;
          uStack_470 = 0;
          uStack_3bc = 0;
          uStack_3c0 = 0;
          uStack_30c = 0;
          uStack_310 = 0;
          uStack_25c = 0;
          uStack_260 = 0;
          uStack_1ac = 0;
          uStack_1b0 = 0;
          uStack_fc = 0;
          uStack_100 = 0;
          local_58 = 0;
          local_54 = 0;
          local_50 = 0;
          local_2840 = local_28f0;
          uStack_2838 = uStack_28e8;
          local_2790 = local_28f0;
          uStack_2788 = uStack_28e8;
          local_26e0 = local_28f0;
          uStack_26d8 = uStack_28e8;
          local_2630 = local_28f0;
          uStack_2628 = uStack_28e8;
          local_2580 = local_28f0;
          uStack_2578 = uStack_28e8;
          local_24d0 = local_28f0;
          uStack_24c8 = uStack_28e8;
          local_2420 = local_28f0;
          uStack_2418 = uStack_28e8;
          local_2370 = local_28f0;
          uStack_2368 = uStack_28e8;
          local_22c0 = local_28f0;
          uStack_22b8 = uStack_28e8;
          local_2210 = local_28f0;
          uStack_2208 = uStack_28e8;
          local_2160 = local_28f0;
          uStack_2158 = uStack_28e8;
          local_20b0 = local_28f0;
          uStack_20a8 = uStack_28e8;
          local_2000 = local_28f0;
          uStack_1ff8 = uStack_28e8;
          local_1f50 = local_28f0;
          uStack_1f48 = uStack_28e8;
          local_1ea0 = local_28f0;
          uStack_1e98 = uStack_28e8;
          local_1df0 = local_28f0;
          uStack_1de8 = uStack_28e8;
          local_1d40 = local_28f0;
          uStack_1d38 = uStack_28e8;
          local_1c90 = local_28f0;
          uStack_1c88 = uStack_28e8;
          local_1be0 = local_28f0;
          uStack_1bd8 = uStack_28e8;
          local_1b30 = local_28f0;
          uStack_1b28 = uStack_28e8;
          local_1a80 = local_28f0;
          uStack_1a78 = uStack_28e8;
          local_19d0 = local_28f0;
          uStack_19c8 = uStack_28e8;
          local_1920 = local_28f0;
          uStack_1918 = uStack_28e8;
          local_1870 = local_28f0;
          uStack_1868 = uStack_28e8;
          local_17c0 = local_28f0;
          uStack_17b8 = uStack_28e8;
          local_1710 = local_28f0;
          uStack_1708 = uStack_28e8;
          local_1660 = local_28f0;
          uStack_1658 = uStack_28e8;
          local_15b0 = local_28f0;
          uStack_15a8 = uStack_28e8;
          local_1500 = local_28f0;
          uStack_14f8 = uStack_28e8;
          local_1450 = local_28f0;
          uStack_1448 = uStack_28e8;
          local_13a0 = local_28f0;
          uStack_1398 = uStack_28e8;
          local_12f0 = local_28f0;
          uStack_12e8 = uStack_28e8;
          local_1240 = local_28f0;
          uStack_1238 = uStack_28e8;
          local_1190 = local_28f0;
          uStack_1188 = uStack_28e8;
          local_10e0 = local_28f0;
          uStack_10d8 = uStack_28e8;
          local_1030 = local_28f0;
          uStack_1028 = uStack_28e8;
          local_f80 = local_28f0;
          uStack_f78 = uStack_28e8;
          local_ed0 = local_28f0;
          uStack_ec8 = uStack_28e8;
          local_e20 = local_28f0;
          uStack_e18 = uStack_28e8;
          local_d70 = local_28f0;
          uStack_d68 = uStack_28e8;
          local_cc0 = local_28f0;
          uStack_cb8 = uStack_28e8;
          local_c10 = local_28f0;
          uStack_c08 = uStack_28e8;
          local_b60 = local_28f0;
          uStack_b58 = uStack_28e8;
          local_ab0 = local_28f0;
          uStack_aa8 = uStack_28e8;
          local_a00 = local_28f0;
          uStack_9f8 = uStack_28e8;
          local_950 = local_28f0;
          uStack_948 = uStack_28e8;
          local_8a0 = local_28f0;
          uStack_898 = uStack_28e8;
          local_7f0 = local_28f0;
          uStack_7e8 = uStack_28e8;
          local_740 = local_28f0;
          uStack_738 = uStack_28e8;
          local_690 = local_28f0;
          uStack_688 = uStack_28e8;
          local_5e0 = local_28f0;
          uStack_5d8 = uStack_28e8;
          local_530 = local_28f0;
          uStack_528 = uStack_28e8;
          local_480 = local_28f0;
          uStack_478 = uStack_28e8;
          local_3d0 = local_28f0;
          uStack_3c8 = uStack_28e8;
          local_320 = local_28f0;
          uStack_318 = uStack_28e8;
          local_270 = local_28f0;
          uStack_268 = uStack_28e8;
          local_1c0 = local_28f0;
          uStack_1b8 = uStack_28e8;
          local_110 = local_28f0;
          uStack_108 = uStack_28e8;
          FUN_1009d9fc(DAT_10097a74 + 0x10096e80,auStack_29a8);
        }
        local_29b8 = auVar20._0_8_;
        local_29b0 = auVar20._8_8_;
        iVar11 = DAT_10098360 + 0x1009743c;
        uVar16 = 1099;
        local_29c8._5_3_ = auVar20._5_3_;
        local_29c8 = CONCAT35(local_29c8._5_3_,0x100000000);
        goto LAB_10097444;
      }
      goto switchD_10093180_caseD_1ff;
    case 0x1bbc:
      iVar9 = DAT_10098a20 + 0x10097a40;
      uVar16 = 0x1bbc;
      break;
    case 0x1bbd:
      iVar9 = DAT_10098a40 + 0x10097a64;
      uVar16 = 0x1bbd;
      break;
    case 0x1bbe:
    case 0x1bbf:
    case 0x1bc0:
    case 0x1bc1:
    case 0x1bc2:
    case 0x1bc3:
    case 0x1bc4:
    case 0x1bc5:
    case 0x1bc6:
    case 0x1bc7:
    case 0x1bc8:
    case 0x1bc9:
    case 0x1bca:
    case 0x1bcb:
    case 0x1bcc:
    case 0x1bcd:
    case 0x1bce:
    case 0x1bcf:
    case 0x1bd0:
    case 0x1bd1:
      if (param_4 == 1) {
        iVar9 = DAT_1009447c + 0x10093494;
        local_29c8._4_4_ = 1;
        goto LAB_1009349c;
      }
      goto switchD_10093180_caseD_1ff;
    default:
      uVar16 = 0x161c;
      if (param_3 == 0x161c) {
        uVar19 = VectorSignedToFloat(param_4,(byte)(in_fpscr >> 0x15) & 3);
        iVar11 = DAT_10098a44 + 0x10097a90;
        goto LAB_10097a8c;
      }
      if (param_3 == 0x1773) {
        *(bool *)(DAT_100945a0 + 0x10093adb) = param_4 == 1;
      }
      goto switchD_10093180_caseD_1ff;
    }
    goto LAB_1009838c;
  }
  if (0x1fa < param_3) {
    if (0x412 < param_3) {
      if (param_3 < 0x1389) {
        switch(param_3) {
        case 0x413:
          uVar16 = 0x413;
          fVar18 = (float)VectorSignedToFloat(param_4,(byte)(in_fpscr >> 0x15) & 3);
          iVar11 = DAT_10094578 + 0x100938e0;
          uVar19 = VectorSignedToFloat((int)fVar18,(byte)(in_fpscr >> 0x15) & 3);
          goto LAB_10097a8c;
        case 0x414:
          iVar9 = DAT_100945b4 + 0x10093bfc;
          goto LAB_10096074;
        case 0x415:
          iVar9 = DAT_100945d0 + 0x10093c18;
          uVar16 = 0x415;
          break;
        case 0x416:
          iVar9 = DAT_10094c20 + 0x10093c3c;
          uVar16 = 0x416;
          break;
        case 0x417:
          iVar9 = DAT_10094c24 + 0x10093c54;
          goto LAB_100952d0;
        case 0x418:
          iVar9 = DAT_10094c28 + 0x10093c64;
          goto LAB_10096098;
        case 0x419:
          iVar9 = DAT_10094c2c + 0x10093c80;
          uVar16 = 0x419;
          break;
        default:
          goto switchD_10093180_caseD_1ff;
        case 0x41b:
          iVar8 = DAT_10094c30 + 0x10093ca4;
          uVar16 = 0x41b;
          goto LAB_10098304;
        case 0x41c:
          iVar9 = DAT_10094c34 + 0x10093cc8;
          uVar16 = 0x41a;
          break;
        case 0x41d:
          iVar9 = DAT_10094c38 + 0x10093cec;
          uVar16 = 0x41d;
          break;
        case 0x41e:
          iVar9 = DAT_10094c3c + 0x10093d10;
          uVar16 = 0x41e;
          break;
        case 0x420:
          iVar9 = DAT_10094c40 + 0x10093d34;
          uVar16 = 0x420;
          break;
        case 0x438:
          bVar1 = *(byte *)(DAT_10094c44 + 0x10093d4c);
          *(byte *)(DAT_10094c44 + 0x10093d4c) = bVar1 ^ 1;
          iVar9 = iVar9 + 0x10093d64;
          local_29c8._4_4_ = bVar1 ^ 1;
          param_3 = 0x438;
          goto LAB_1009349c;
        case 1099:
          iVar9 = DAT_10094c4c + 0x10093d94;
          uVar16 = 1099;
        }
        goto LAB_1009838c;
      }
      if (param_3 < 0x138b) {
        uVar16 = 0x1389;
        if (param_3 == 0x1389) {
          iVar9 = DAT_100952f4 + 0x1009440c;
        }
        else {
          uVar16 = 0x138a;
          if (param_3 != 0x138a) goto switchD_10093180_caseD_1ff;
          iVar9 = DAT_1009459c + 0x10093a98;
        }
        goto LAB_1009838c;
      }
      if (param_3 == 0x138b) {
        auVar20 = ZEXT816(0);
        local_29c0 = 0;
        local_29b8 = 0;
        local_29b0 = 0;
        local_29c8._0_5_ = CONCAT14(param_4 == 1,0x138b);
        local_29c8 = (ulonglong)(uint5)local_29c8;
        iVar11 = FUN_1009d8f4(DAT_10094c50 + 0x10093dc0,&local_29c8,0x20);
        if (iVar11 != 0) {
          __aeabi_memclr8(auStack_29a8,0x2960);
          local_28f0 = auVar20._0_8_;
          uStack_28e8 = auVar20._8_8_;
          local_28dc = 0;
          local_28e0 = 0;
          local_282c = 0;
          local_2830 = 0;
          local_277c = 0;
          local_2780 = 0;
          local_26cc = 0;
          local_26d0 = 0;
          local_261c = 0;
          local_2620 = 0;
          local_256c = 0;
          local_2570 = 0;
          local_24bc = 0;
          local_24c0 = 0;
          local_240c = 0;
          local_2410 = 0;
          local_2360 = 0;
          local_235c = 0;
          local_22b0 = 0;
          local_22ac = 0;
          local_2200 = 0;
          local_21fc = 0;
          local_2150 = 0;
          local_214c = 0;
          local_209c = 0;
          local_20a0 = 0;
          local_1fec = 0;
          local_1ff0 = 0;
          local_1f3c = 0;
          local_1f40 = 0;
          local_1e8c = 0;
          local_1e90 = 0;
          local_1ddc = 0;
          local_1de0 = 0;
          local_1d2c = 0;
          local_1d30 = 0;
          local_1c7c = 0;
          local_1c80 = 0;
          local_1bcc = 0;
          local_1bd0 = 0;
          local_1b1c = 0;
          local_1b20 = 0;
          local_1a6c = 0;
          local_1a70 = 0;
          local_19c0 = 0;
          local_19bc = 0;
          uStack_190c = 0;
          uStack_1910 = 0;
          uStack_185c = 0;
          uStack_1860 = 0;
          uStack_17ac = 0;
          uStack_17b0 = 0;
          uStack_16fc = 0;
          uStack_1700 = 0;
          uStack_164c = 0;
          uStack_1650 = 0;
          uStack_159c = 0;
          uStack_15a0 = 0;
          uStack_14ec = 0;
          uStack_14f0 = 0;
          uStack_143c = 0;
          uStack_1440 = 0;
          uStack_138c = 0;
          uStack_1390 = 0;
          uStack_12dc = 0;
          uStack_12e0 = 0;
          uStack_122c = 0;
          uStack_1230 = 0;
          uStack_117c = 0;
          uStack_1180 = 0;
          uStack_10cc = 0;
          uStack_10d0 = 0;
          uStack_101c = 0;
          uStack_1020 = 0;
          uStack_f6c = 0;
          uStack_f70 = 0;
          uStack_ebc = 0;
          uStack_ec0 = 0;
          uStack_e0c = 0;
          uStack_e10 = 0;
          uStack_d5c = 0;
          uStack_d60 = 0;
          uStack_cac = 0;
          uStack_cb0 = 0;
          uStack_bfc = 0;
          uStack_c00 = 0;
          uStack_b4c = 0;
          uStack_b50 = 0;
          uStack_a9c = 0;
          uStack_aa0 = 0;
          uStack_9ec = 0;
          uStack_9f0 = 0;
          uStack_93c = 0;
          uStack_940 = 0;
          uStack_88c = 0;
          uStack_890 = 0;
          uStack_7dc = 0;
          uStack_7e0 = 0;
          uStack_72c = 0;
          uStack_730 = 0;
          uStack_67c = 0;
          uStack_680 = 0;
          uStack_5cc = 0;
          uStack_5d0 = 0;
          uStack_51c = 0;
          uStack_520 = 0;
          uStack_46c = 0;
          uStack_470 = 0;
          uStack_3bc = 0;
          uStack_3c0 = 0;
          uStack_30c = 0;
          uStack_310 = 0;
          uStack_25c = 0;
          uStack_260 = 0;
          uStack_1ac = 0;
          uStack_1b0 = 0;
          uStack_fc = 0;
          uStack_100 = 0;
          local_58 = 0;
          local_54 = 0;
          local_50 = 0;
          local_2840 = local_28f0;
          uStack_2838 = uStack_28e8;
          local_2790 = local_28f0;
          uStack_2788 = uStack_28e8;
          local_26e0 = local_28f0;
          uStack_26d8 = uStack_28e8;
          local_2630 = local_28f0;
          uStack_2628 = uStack_28e8;
          local_2580 = local_28f0;
          uStack_2578 = uStack_28e8;
          local_24d0 = local_28f0;
          uStack_24c8 = uStack_28e8;
          local_2420 = local_28f0;
          uStack_2418 = uStack_28e8;
          local_2370 = local_28f0;
          uStack_2368 = uStack_28e8;
          local_22c0 = local_28f0;
          uStack_22b8 = uStack_28e8;
          local_2210 = local_28f0;
          uStack_2208 = uStack_28e8;
          local_2160 = local_28f0;
          uStack_2158 = uStack_28e8;
          local_20b0 = local_28f0;
          uStack_20a8 = uStack_28e8;
          local_2000 = local_28f0;
          uStack_1ff8 = uStack_28e8;
          local_1f50 = local_28f0;
          uStack_1f48 = uStack_28e8;
          local_1ea0 = local_28f0;
          uStack_1e98 = uStack_28e8;
          local_1df0 = local_28f0;
          uStack_1de8 = uStack_28e8;
          local_1d40 = local_28f0;
          uStack_1d38 = uStack_28e8;
          local_1c90 = local_28f0;
          uStack_1c88 = uStack_28e8;
          local_1be0 = local_28f0;
          uStack_1bd8 = uStack_28e8;
          local_1b30 = local_28f0;
          uStack_1b28 = uStack_28e8;
          local_1a80 = local_28f0;
          uStack_1a78 = uStack_28e8;
          local_19d0 = local_28f0;
          uStack_19c8 = uStack_28e8;
          local_1920 = local_28f0;
          uStack_1918 = uStack_28e8;
          local_1870 = local_28f0;
          uStack_1868 = uStack_28e8;
          local_17c0 = local_28f0;
          uStack_17b8 = uStack_28e8;
          local_1710 = local_28f0;
          uStack_1708 = uStack_28e8;
          local_1660 = local_28f0;
          uStack_1658 = uStack_28e8;
          local_15b0 = local_28f0;
          uStack_15a8 = uStack_28e8;
          local_1500 = local_28f0;
          uStack_14f8 = uStack_28e8;
          local_1450 = local_28f0;
          uStack_1448 = uStack_28e8;
          local_13a0 = local_28f0;
          uStack_1398 = uStack_28e8;
          local_12f0 = local_28f0;
          uStack_12e8 = uStack_28e8;
          local_1240 = local_28f0;
          uStack_1238 = uStack_28e8;
          local_1190 = local_28f0;
          uStack_1188 = uStack_28e8;
          local_10e0 = local_28f0;
          uStack_10d8 = uStack_28e8;
          local_1030 = local_28f0;
          uStack_1028 = uStack_28e8;
          local_f80 = local_28f0;
          uStack_f78 = uStack_28e8;
          local_ed0 = local_28f0;
          uStack_ec8 = uStack_28e8;
          local_e20 = local_28f0;
          uStack_e18 = uStack_28e8;
          local_d70 = local_28f0;
          uStack_d68 = uStack_28e8;
          local_cc0 = local_28f0;
          uStack_cb8 = uStack_28e8;
          local_c10 = local_28f0;
          uStack_c08 = uStack_28e8;
          local_b60 = local_28f0;
          uStack_b58 = uStack_28e8;
          local_ab0 = local_28f0;
          uStack_aa8 = uStack_28e8;
          local_a00 = local_28f0;
          uStack_9f8 = uStack_28e8;
          local_950 = local_28f0;
          uStack_948 = uStack_28e8;
          local_8a0 = local_28f0;
          uStack_898 = uStack_28e8;
          local_7f0 = local_28f0;
          uStack_7e8 = uStack_28e8;
          local_740 = local_28f0;
          uStack_738 = uStack_28e8;
          local_690 = local_28f0;
          uStack_688 = uStack_28e8;
          local_5e0 = local_28f0;
          uStack_5d8 = uStack_28e8;
          local_530 = local_28f0;
          uStack_528 = uStack_28e8;
          local_480 = local_28f0;
          uStack_478 = uStack_28e8;
          local_3d0 = local_28f0;
          uStack_3c8 = uStack_28e8;
          local_320 = local_28f0;
          uStack_318 = uStack_28e8;
          local_270 = local_28f0;
          uStack_268 = uStack_28e8;
          local_1c0 = local_28f0;
          uStack_1b8 = uStack_28e8;
          local_110 = local_28f0;
          uStack_108 = uStack_28e8;
          FUN_1009d9fc(DAT_10094c54 + 0x10093e14,auStack_29a8);
        }
        local_29b8 = auVar20._0_8_;
        local_29b0 = auVar20._8_8_;
        iVar11 = DAT_100952e8 + 0x100943d0;
        local_29c8._5_3_ = auVar20._5_3_;
        local_29c8 = CONCAT44(CONCAT31(local_29c8._5_3_,param_4 == 1),0x1eba);
        goto LAB_1009744c;
      }
      uVar16 = 0x1405;
      if (param_3 == 0x1405) {
        pbVar12 = (byte *)(DAT_100952ec + 0x100943f0);
        bVar1 = *pbVar12;
        iVar8 = DAT_100952f0 + 0x100943fc;
        goto LAB_100938f8;
      }
      uVar16 = 0x144a;
      if (param_3 == 0x144a) {
        pbVar12 = (byte *)(DAT_10094588 + 0x10093980);
        bVar1 = *pbVar12;
        iVar9 = DAT_1009458c + 0x1009398c;
        goto LAB_10093adc;
      }
      goto switchD_10093180_caseD_1ff;
    }
    switch(param_3) {
    case 0x1fb:
      iVar9 = DAT_10093da0 + 0x10093258;
      goto LAB_10095fb4;
    case 0x1fc:
      iVar9 = DAT_1009671c + 0x10096114;
      uVar16 = 0x1fc;
      goto LAB_1009838c;
    case 0x1fd:
      bVar1 = *(byte *)(DAT_10096720 + 0x1009612c);
      *(byte *)(DAT_10096720 + 0x1009612c) = bVar1 ^ 1;
      iVar8 = iVar2 + 0x10096144;
      local_29c8 = CONCAT44((uint)bVar1,0x1fd) ^ 0x100000000;
      break;
    case 0x1fe:
      iVar9 = DAT_10096728 + 0x10096178;
      uVar16 = 0x1fe;
      goto LAB_1009838c;
    case 0x1ff:
    case 0x200:
    case 0x201:
    case 0x202:
    case 0x20d:
    case 0x20f:
    case 0x212:
    case 0x215:
    case 0x216:
    case 0x217:
    case 0x218:
    case 0x219:
    case 0x21a:
    case 0x21b:
    case 0x21c:
    case 0x21d:
    case 0x21e:
    case 0x21f:
    case 0x220:
    case 0x221:
    case 0x222:
    case 0x223:
    case 0x224:
    case 0x225:
    case 0x226:
    case 0x227:
    case 0x228:
    case 0x229:
    case 0x22a:
      goto switchD_10093180_caseD_1ff;
    case 0x203:
      bVar1 = *(byte *)(DAT_1009672c + 0x10096190);
      *(byte *)(DAT_1009672c + 0x10096190) = bVar1 ^ 1;
      iVar8 = iVar3 + 0x100961a8;
      local_29c8 = CONCAT44((uint)bVar1,0x203) ^ 0x100000000;
      break;
    case 0x204:
      bVar1 = *(byte *)(DAT_10096734 + 0x100961d0);
      *(byte *)(DAT_10096734 + 0x100961d0) = bVar1 ^ 1;
      iVar8 = iVar4 + 0x100961e8;
      local_29c8 = CONCAT44((uint)bVar1,0x204) ^ 0x100000000;
      break;
    case 0x205:
      iVar8 = DAT_1009673c + 0x1009621c;
      uVar16 = 0x205;
      goto LAB_10098304;
    case 0x206:
      bVar1 = *(byte *)(DAT_10096740 + 0x10096234);
      *(byte *)(DAT_10096740 + 0x10096234) = bVar1 ^ 1;
      iVar8 = iVar5 + 0x1009624c;
      local_29c8 = CONCAT44((uint)bVar1,0x206) ^ 0x100000000;
      break;
    case 0x207:
      bVar1 = *(byte *)(DAT_10096748 + 0x10096274);
      *(byte *)(DAT_10096748 + 0x10096274) = bVar1 ^ 1;
      iVar8 = iVar6 + 0x1009628c;
      local_29c8 = CONCAT44((uint)bVar1,0x207) ^ 0x100000000;
      break;
    case 0x208:
      bVar1 = *(byte *)(DAT_10096750 + 0x100962b8);
      *(byte *)(DAT_10096750 + 0x100962b8) = bVar1 ^ 1;
      if (bVar1 == 0) {
        *(undefined *)(DAT_10096754 + 0x100962d8) = 1;
      }
      iVar8 = DAT_10096758 + 0x100962f4;
      local_29c8 = CONCAT44((uint)bVar1,0x208) ^ 0x100000000;
      break;
    case 0x209:
      bVar1 = *(byte *)(DAT_1009675c + 0x10096314);
      *(byte *)(DAT_1009675c + 0x10096314) = bVar1 ^ 1;
      if (bVar1 == 0) {
        puVar13 = (undefined *)(DAT_10096764 + 0x1009633c);
        *(undefined *)(DAT_10096760 + 0x10096338) = 1;
        *puVar13 = 1;
      }
      iVar8 = DAT_10096768 + 0x1009635c;
      local_29c8 = CONCAT44((uint)bVar1,0x209) ^ 0x100000000;
      break;
    case 0x20a:
      iVar8 = DAT_1009676c + 0x10096390;
      uVar16 = 0x20a;
      goto LAB_10098304;
    case 0x20b:
      iVar9 = DAT_10096770 + 0x100963b8;
      uVar16 = 0x20b;
      goto LAB_1009838c;
    case 0x20c:
      bVar1 = *(byte *)(DAT_10096774 + 0x100963d0);
      *(byte *)(DAT_10096774 + 0x100963d0) = bVar1 ^ 1;
      iVar8 = iVar8 + 0x100963e8;
      local_29c8 = CONCAT44((uint)bVar1,0x20c) ^ 0x100000000;
      break;
    case 0x20e:
      uVar16 = (**(code **)(*param_1 + 0x18))(param_1,DAT_1009677c + 0x10096414);
      uVar10 = (**(code **)(*param_1 + 0x1c4))
                         (param_1,uVar16,DAT_10096780 + 0x10096438,DAT_10096784 + 0x1009643c);
      if (*piVar17 == local_44) {
        FUN_10098b58(param_1,uVar16,uVar10);
        return;
      }
      goto LAB_1009899c;
    case 0x210:
      iVar8 = DAT_10096788 + 0x1009648c;
      uVar16 = 0x210;
      goto LAB_10098304;
    case 0x211:
      iVar9 = DAT_1009678c + 0x100964b0;
      uVar16 = 0x211;
      goto LAB_1009838c;
    case 0x213:
      iVar9 = DAT_10096790 + 0x100964d4;
      uVar16 = 0x213;
      goto LAB_1009838c;
    case 0x214:
      iVar9 = DAT_10096794 + 0x100964f8;
      uVar16 = 0x214;
      goto LAB_1009838c;
    case 0x22b:
      iVar9 = DAT_10096798 + 0x1009651c;
      uVar16 = 0x20f;
      goto LAB_1009838c;
    default:
      uVar16 = 0x379;
      if (param_3 == 0x379) {
        iVar9 = DAT_100952f8 + 0x10094428;
        goto LAB_1009838c;
      }
      goto switchD_10093180_caseD_1ff;
    }
LAB_10098314:
    local_29b0 = 0;
    local_29b8 = 0;
    local_29c0 = 0;
    auVar20 = ZEXT816(0);
    iVar11 = FUN_1009d8f4(iVar8,&local_29c8,0x20);
    if (iVar11 == 0) goto switchD_10093180_caseD_1ff;
    __aeabi_memclr8(auStack_29a8,0x2960);
    iVar11 = DAT_10098b54 + 0x1009833c;
    goto LAB_100983c0;
  }
  switch(param_3) {
  case 1:
    *(bool *)(DAT_10094570 + 0x10093768) = param_4 == 1;
    break;
  case 2:
    *(bool *)(DAT_100952fc + 0x1009443d) = param_4 == 1;
    break;
  case 3:
    *(bool *)(DAT_10095300 + 0x1009445b) = param_4 == 1;
    break;
  case 4:
    *(bool *)(DAT_10095304 + 0x10094476) = param_4 == 1;
    break;
  case 5:
    switch(param_4) {
    case 0:
      pauVar14 = (undefined (*) [16])&DAT_100945c0;
      iVar11 = DAT_10095308 + 0x100944cc;
      break;
    case 1:
      pauVar14 = (undefined (*) [16])&DAT_10098ad0;
      iVar11 = DAT_10098af0 + 0x100989b0;
      break;
    case 2:
      pauVar14 = (undefined (*) [16])&DAT_10098ac0;
      iVar11 = DAT_10098af4 + 0x100989c0;
      break;
    case 3:
      pauVar14 = (undefined (*) [16])&DAT_10098ab0;
      iVar11 = DAT_10098af8 + 0x100989d0;
      break;
    case 4:
      pauVar14 = (undefined (*) [16])&DAT_10098aa0;
      iVar11 = DAT_10098afc + 0x100989e0;
      break;
    case 5:
      pauVar14 = (undefined (*) [16])&DAT_10098a90;
      iVar11 = DAT_10098b00 + 0x100989f0;
      break;
    case 6:
      pauVar14 = (undefined (*) [16])&DAT_10098a80;
      iVar11 = DAT_10098b04 + 0x10098a00;
      break;
    case 7:
      pauVar14 = (undefined (*) [16])&DAT_10098a70;
      iVar11 = DAT_10098b08 + 0x10098a10;
      break;
    case 8:
      pauVar14 = (undefined (*) [16])&DAT_10098a60;
      iVar11 = (int)&DAT_10098a20 + DAT_10098b0c;
      break;
    case 9:
      pauVar14 = (undefined (*) [16])&DAT_10098a50;
      iVar11 = DAT_10098b10 + 0x10098a34;
      break;
    default:
      goto switchD_10093180_caseD_1ff;
    }
    auVar20 = *pauVar14;
    *(longlong *)(iVar11 + 8) = auVar20._0_8_;
    *(longlong *)(iVar11 + 0x10) = auVar20._8_8_;
    break;
  case 6:
    *(uint *)(DAT_100966fc + 0x10096024) = param_4;
    break;
  case 7:
    *(uint *)(DAT_1009530c + 0x100944f8) = param_4;
    break;
  case 9:
    *(bool *)(DAT_10096700 + 0x10096038) = param_4 == 1;
    break;
  case 0x10:
    *(bool *)(DAT_10095310 + 0x100944f4) = param_4 == 1;
    break;
  case 0x11:
    *(bool *)(DAT_10096704 + 0x10096060) = param_4 == 1;
    break;
  case 0x1f:
    *(bool *)(DAT_10095314 + 0x10094525) = param_4 == 1;
    break;
  case 0x20:
    *(bool *)(DAT_10095318 + 0x10094542) = param_4 == 1;
    break;
  case 0x21:
    iVar9 = DAT_1009531c + 0x1009454c;
    *(bool *)(DAT_10095320 + 0x10094575) = param_4 == 1;
    local_29c8._4_4_ = (uint)(param_4 == 1);
    param_3 = 0x21;
    goto LAB_1009349c;
  case 100:
    iVar9 = DAT_10096708 + 0x10096060;
    uVar16 = 100;
    goto LAB_1009838c;
  case 0x66:
    auVar20 = ZEXT816(0);
    puVar13 = (undefined *)(DAT_10095328 + 0x100945f8);
    local_29c0 = 0;
    iVar11 = DAT_10095324 + 0x10094604;
    local_29b8 = 0;
    local_29b0 = 0;
    *puVar13 = param_4 == 1;
    local_29c8 = CONCAT44((uint)(param_4 == 1),0x66);
    iVar11 = FUN_1009d8f4(iVar11,&local_29c8,0x20);
    if (iVar11 != 0) {
      __aeabi_memclr8(auStack_29a8,0x2960);
      local_28f0 = auVar20._0_8_;
      uStack_28e8 = auVar20._8_8_;
      local_28dc = 0;
      local_28e0 = 0;
      local_282c = 0;
      local_2830 = 0;
      local_277c = 0;
      local_2780 = 0;
      local_26cc = 0;
      local_26d0 = 0;
      local_261c = 0;
      local_2620 = 0;
      local_256c = 0;
      local_2570 = 0;
      local_24bc = 0;
      local_24c0 = 0;
      local_240c = 0;
      local_2410 = 0;
      local_2360 = 0;
      local_235c = 0;
      local_22b0 = 0;
      local_22ac = 0;
      local_2200 = 0;
      local_21fc = 0;
      local_2150 = 0;
      local_214c = 0;
      local_209c = 0;
      local_20a0 = 0;
      local_1fec = 0;
      local_1ff0 = 0;
      local_1f3c = 0;
      local_1f40 = 0;
      local_1e8c = 0;
      local_1e90 = 0;
      local_1ddc = 0;
      local_1de0 = 0;
      local_1d2c = 0;
      local_1d30 = 0;
      local_1c7c = 0;
      local_1c80 = 0;
      local_1bcc = 0;
      local_1bd0 = 0;
      local_1b1c = 0;
      local_1b20 = 0;
      local_1a6c = 0;
      local_1a70 = 0;
      local_19c0 = 0;
      local_19bc = 0;
      uStack_190c = 0;
      uStack_1910 = 0;
      uStack_185c = 0;
      uStack_1860 = 0;
      uStack_17ac = 0;
      uStack_17b0 = 0;
      uStack_16fc = 0;
      uStack_1700 = 0;
      uStack_164c = 0;
      uStack_1650 = 0;
      uStack_159c = 0;
      uStack_15a0 = 0;
      uStack_14ec = 0;
      uStack_14f0 = 0;
      uStack_143c = 0;
      uStack_1440 = 0;
      uStack_138c = 0;
      uStack_1390 = 0;
      uStack_12dc = 0;
      uStack_12e0 = 0;
      uStack_122c = 0;
      uStack_1230 = 0;
      uStack_117c = 0;
      uStack_1180 = 0;
      uStack_10cc = 0;
      uStack_10d0 = 0;
      uStack_101c = 0;
      uStack_1020 = 0;
      uStack_f6c = 0;
      uStack_f70 = 0;
      uStack_ebc = 0;
      uStack_ec0 = 0;
      uStack_e0c = 0;
      uStack_e10 = 0;
      uStack_d5c = 0;
      uStack_d60 = 0;
      uStack_cac = 0;
      uStack_cb0 = 0;
      uStack_bfc = 0;
      uStack_c00 = 0;
      uStack_b4c = 0;
      uStack_b50 = 0;
      uStack_a9c = 0;
      uStack_aa0 = 0;
      uStack_9ec = 0;
      uStack_9f0 = 0;
      uStack_93c = 0;
      uStack_940 = 0;
      uStack_88c = 0;
      uStack_890 = 0;
      uStack_7dc = 0;
      uStack_7e0 = 0;
      uStack_72c = 0;
      uStack_730 = 0;
      uStack_67c = 0;
      uStack_680 = 0;
      uStack_5cc = 0;
      uStack_5d0 = 0;
      uStack_51c = 0;
      uStack_520 = 0;
      uStack_46c = 0;
      uStack_470 = 0;
      uStack_3bc = 0;
      uStack_3c0 = 0;
      uStack_30c = 0;
      uStack_310 = 0;
      uStack_25c = 0;
      uStack_260 = 0;
      uStack_1ac = 0;
      uStack_1b0 = 0;
      uStack_fc = 0;
      uStack_100 = 0;
      local_58 = 0;
      local_54 = 0;
      local_50 = 0;
      local_2840 = local_28f0;
      uStack_2838 = uStack_28e8;
      local_2790 = local_28f0;
      uStack_2788 = uStack_28e8;
      local_26e0 = local_28f0;
      uStack_26d8 = uStack_28e8;
      local_2630 = local_28f0;
      uStack_2628 = uStack_28e8;
      local_2580 = local_28f0;
      uStack_2578 = uStack_28e8;
      local_24d0 = local_28f0;
      uStack_24c8 = uStack_28e8;
      local_2420 = local_28f0;
      uStack_2418 = uStack_28e8;
      local_2370 = local_28f0;
      uStack_2368 = uStack_28e8;
      local_22c0 = local_28f0;
      uStack_22b8 = uStack_28e8;
      local_2210 = local_28f0;
      uStack_2208 = uStack_28e8;
      local_2160 = local_28f0;
      uStack_2158 = uStack_28e8;
      local_20b0 = local_28f0;
      uStack_20a8 = uStack_28e8;
      local_2000 = local_28f0;
      uStack_1ff8 = uStack_28e8;
      local_1f50 = local_28f0;
      uStack_1f48 = uStack_28e8;
      local_1ea0 = local_28f0;
      uStack_1e98 = uStack_28e8;
      local_1df0 = local_28f0;
      uStack_1de8 = uStack_28e8;
      local_1d40 = local_28f0;
      uStack_1d38 = uStack_28e8;
      local_1c90 = local_28f0;
      uStack_1c88 = uStack_28e8;
      local_1be0 = local_28f0;
      uStack_1bd8 = uStack_28e8;
      local_1b30 = local_28f0;
      uStack_1b28 = uStack_28e8;
      local_1a80 = local_28f0;
      uStack_1a78 = uStack_28e8;
      local_19d0 = local_28f0;
      uStack_19c8 = uStack_28e8;
      local_1920 = local_28f0;
      uStack_1918 = uStack_28e8;
      local_1870 = local_28f0;
      uStack_1868 = uStack_28e8;
      local_17c0 = local_28f0;
      uStack_17b8 = uStack_28e8;
      local_1710 = local_28f0;
      uStack_1708 = uStack_28e8;
      local_1660 = local_28f0;
      uStack_1658 = uStack_28e8;
      local_15b0 = local_28f0;
      uStack_15a8 = uStack_28e8;
      local_1500 = local_28f0;
      uStack_14f8 = uStack_28e8;
      local_1450 = local_28f0;
      uStack_1448 = uStack_28e8;
      local_13a0 = local_28f0;
      uStack_1398 = uStack_28e8;
      local_12f0 = local_28f0;
      uStack_12e8 = uStack_28e8;
      local_1240 = local_28f0;
      uStack_1238 = uStack_28e8;
      local_1190 = local_28f0;
      uStack_1188 = uStack_28e8;
      local_10e0 = local_28f0;
      uStack_10d8 = uStack_28e8;
      local_1030 = local_28f0;
      uStack_1028 = uStack_28e8;
      local_f80 = local_28f0;
      uStack_f78 = uStack_28e8;
      local_ed0 = local_28f0;
      uStack_ec8 = uStack_28e8;
      local_e20 = local_28f0;
      uStack_e18 = uStack_28e8;
      local_d70 = local_28f0;
      uStack_d68 = uStack_28e8;
      local_cc0 = local_28f0;
      uStack_cb8 = uStack_28e8;
      local_c10 = local_28f0;
      uStack_c08 = uStack_28e8;
      local_b60 = local_28f0;
      uStack_b58 = uStack_28e8;
      local_ab0 = local_28f0;
      uStack_aa8 = uStack_28e8;
      local_a00 = local_28f0;
      uStack_9f8 = uStack_28e8;
      local_950 = local_28f0;
      uStack_948 = uStack_28e8;
      local_8a0 = local_28f0;
      uStack_898 = uStack_28e8;
      local_7f0 = local_28f0;
      uStack_7e8 = uStack_28e8;
      local_740 = local_28f0;
      uStack_738 = uStack_28e8;
      local_690 = local_28f0;
      uStack_688 = uStack_28e8;
      local_5e0 = local_28f0;
      uStack_5d8 = uStack_28e8;
      local_530 = local_28f0;
      uStack_528 = uStack_28e8;
      local_480 = local_28f0;
      uStack_478 = uStack_28e8;
      local_3d0 = local_28f0;
      uStack_3c8 = uStack_28e8;
      local_320 = local_28f0;
      uStack_318 = uStack_28e8;
      local_270 = local_28f0;
      uStack_268 = uStack_28e8;
      local_1c0 = local_28f0;
      uStack_1b8 = uStack_28e8;
      local_110 = local_28f0;
      uStack_108 = uStack_28e8;
      FUN_1009d9fc(DAT_1009532c + 0x10094654,auStack_29a8);
    }
    local_29b8 = auVar20._0_8_;
    local_29b0 = auVar20._8_8_;
    iVar11 = DAT_10095330 + 0x10094c10;
    local_29c8._5_3_ = auVar20._5_3_;
    local_29c8._4_4_ = CONCAT31(local_29c8._5_3_,*puVar13);
    uVar16 = 3;
LAB_10097444:
    local_29c8 = CONCAT44(local_29c8._4_4_,uVar16);
LAB_1009744c:
    local_29c0 = local_29b0;
    iVar11 = FUN_1009d8f4(iVar11,&local_29c8,0x20);
    if (iVar11 == 0) break;
    __aeabi_memclr8(auStack_29a8,0x2960);
    iVar11 = DAT_10098364 + 0x1009748c;
    local_110 = 0;
    uStack_108 = 0;
    goto LAB_10098978;
  case 0x68:
    uVar16 = VectorSignedToFloat(param_4,(byte)(in_fpscr >> 0x15) & 3);
    uVar19 = param_4;
    if (param_4 == 1) {
      uVar19 = 2000;
      uVar16 = DAT_10094c58;
    }
    uVar19 = VectorSignedToFloat(uVar19,(byte)(in_fpscr >> 0x15) & 3);
    iVar11 = DAT_10095338 + 0x10094ca0;
    local_29b0 = 0;
    local_29b8 = (ulonglong)local_29b8._4_4_ << 0x20;
    *(undefined4 *)(DAT_10095334 + 0x10094c8c) = uVar16;
    local_29c0 = (ulonglong)uVar19;
    local_29c8 = (ulonglong)local_29c8._5_3_ << 0x28;
    local_29c8 = CONCAT44(local_29c8._4_4_,0x68);
    iVar11 = FUN_1009d8f4(iVar11,&local_29c8,0x20);
    if (iVar11 != 0) {
      __aeabi_memclr8(auStack_29a8,0x2960);
      local_28f0 = 0;
      uStack_28e8 = 0;
      local_2840 = 0;
      uStack_2838 = 0;
      local_2790 = 0;
      uStack_2788 = 0;
      local_26e0 = 0;
      uStack_26d8 = 0;
      local_2630 = 0;
      uStack_2628 = 0;
      local_2580 = 0;
      uStack_2578 = 0;
      local_24d0 = 0;
      uStack_24c8 = 0;
      local_28dc = 0;
      local_28e0 = 0;
      local_282c = 0;
      local_2830 = 0;
      local_277c = 0;
      local_2780 = 0;
      local_26cc = 0;
      local_26d0 = 0;
      local_261c = 0;
      local_2620 = 0;
      local_256c = 0;
      local_2570 = 0;
      local_24bc = 0;
      local_24c0 = 0;
      local_2420 = 0;
      uStack_2418 = 0;
      local_2370 = 0;
      uStack_2368 = 0;
      local_22c0 = 0;
      uStack_22b8 = 0;
      local_2210 = 0;
      uStack_2208 = 0;
      local_2160 = 0;
      uStack_2158 = 0;
      local_20b0 = 0;
      uStack_20a8 = 0;
      local_240c = 0;
      local_2410 = 0;
      local_2360 = 0;
      local_235c = 0;
      local_22b0 = 0;
      local_22ac = 0;
      local_2200 = 0;
      local_21fc = 0;
      local_2150 = 0;
      local_214c = 0;
      local_209c = 0;
      local_20a0 = 0;
      local_2000 = 0;
      uStack_1ff8 = 0;
      local_1fec = 0;
      local_1ff0 = 0;
      local_1f50 = 0;
      uStack_1f48 = 0;
      local_1f3c = 0;
      local_1f40 = 0;
      local_1ea0 = 0;
      uStack_1e98 = 0;
      local_1e8c = 0;
      local_1e90 = 0;
      local_1df0 = 0;
      uStack_1de8 = 0;
      local_1ddc = 0;
      local_1de0 = 0;
      local_1d40 = 0;
      uStack_1d38 = 0;
      local_1d2c = 0;
      local_1d30 = 0;
      local_1c90 = 0;
      uStack_1c88 = 0;
      local_1c7c = 0;
      local_1c80 = 0;
      local_1be0 = 0;
      uStack_1bd8 = 0;
      local_1bcc = 0;
      local_1bd0 = 0;
      local_1b30 = 0;
      uStack_1b28 = 0;
      local_1b1c = 0;
      local_1b20 = 0;
      local_1a80 = 0;
      uStack_1a78 = 0;
      local_1a6c = 0;
      local_1a70 = 0;
      local_19d0 = 0;
      uStack_19c8 = 0;
      local_19c0 = 0;
      local_19bc = 0;
      uStack_190c = 0;
      uStack_1910 = 0;
      local_1920 = 0;
      uStack_1918 = 0;
      uStack_185c = 0;
      uStack_1860 = 0;
      local_1870 = 0;
      uStack_1868 = 0;
      uStack_17ac = 0;
      uStack_17b0 = 0;
      local_17c0 = 0;
      uStack_17b8 = 0;
      uStack_16fc = 0;
      uStack_1700 = 0;
      local_1710 = 0;
      uStack_1708 = 0;
      uStack_164c = 0;
      uStack_1650 = 0;
      local_1660 = 0;
      uStack_1658 = 0;
      uStack_159c = 0;
      uStack_15a0 = 0;
      local_15b0 = 0;
      uStack_15a8 = 0;
      uStack_14ec = 0;
      uStack_14f0 = 0;
      local_1500 = 0;
      uStack_14f8 = 0;
      uStack_143c = 0;
      uStack_1440 = 0;
      local_1450 = 0;
      uStack_1448 = 0;
      uStack_138c = 0;
      uStack_1390 = 0;
      local_13a0 = 0;
      uStack_1398 = 0;
      uStack_12dc = 0;
      uStack_12e0 = 0;
      local_12f0 = 0;
      uStack_12e8 = 0;
      uStack_122c = 0;
      uStack_1230 = 0;
      local_1240 = 0;
      uStack_1238 = 0;
      uStack_117c = 0;
      uStack_1180 = 0;
      local_1190 = 0;
      uStack_1188 = 0;
      uStack_10cc = 0;
      uStack_10d0 = 0;
      local_10e0 = 0;
      uStack_10d8 = 0;
      uStack_101c = 0;
      uStack_1020 = 0;
      local_1030 = 0;
      uStack_1028 = 0;
      uStack_f6c = 0;
      uStack_f70 = 0;
      local_f80 = 0;
      uStack_f78 = 0;
      uStack_ebc = 0;
      uStack_ec0 = 0;
      local_ed0 = 0;
      uStack_ec8 = 0;
      uStack_e0c = 0;
      uStack_e10 = 0;
      local_e20 = 0;
      uStack_e18 = 0;
      uStack_d5c = 0;
      uStack_d60 = 0;
      local_d70 = 0;
      uStack_d68 = 0;
      uStack_cac = 0;
      uStack_cb0 = 0;
      local_cc0 = 0;
      uStack_cb8 = 0;
      uStack_bfc = 0;
      uStack_c00 = 0;
      local_c10 = 0;
      uStack_c08 = 0;
      uStack_b4c = 0;
      uStack_b50 = 0;
      local_b60 = 0;
      uStack_b58 = 0;
      uStack_a9c = 0;
      uStack_aa0 = 0;
      local_ab0 = 0;
      uStack_aa8 = 0;
      uStack_9ec = 0;
      uStack_9f0 = 0;
      local_a00 = 0;
      uStack_9f8 = 0;
      uStack_93c = 0;
      uStack_940 = 0;
      local_950 = 0;
      uStack_948 = 0;
      uStack_88c = 0;
      uStack_890 = 0;
      local_8a0 = 0;
      uStack_898 = 0;
      uStack_7dc = 0;
      uStack_7e0 = 0;
      local_7f0 = 0;
      uStack_7e8 = 0;
      uStack_72c = 0;
      uStack_730 = 0;
      local_740 = 0;
      uStack_738 = 0;
      uStack_67c = 0;
      uStack_680 = 0;
      local_690 = 0;
      uStack_688 = 0;
      uStack_5cc = 0;
      uStack_5d0 = 0;
      local_5e0 = 0;
      uStack_5d8 = 0;
      uStack_51c = 0;
      uStack_520 = 0;
      local_530 = 0;
      uStack_528 = 0;
      uStack_46c = 0;
      uStack_470 = 0;
      local_480 = 0;
      uStack_478 = 0;
      uStack_3bc = 0;
      uStack_3c0 = 0;
      local_3d0 = 0;
      uStack_3c8 = 0;
      uStack_30c = 0;
      uStack_310 = 0;
      local_320 = 0;
      uStack_318 = 0;
      uStack_25c = 0;
      uStack_260 = 0;
      local_270 = 0;
      uStack_268 = 0;
      uStack_1ac = 0;
      uStack_1b0 = 0;
      local_1c0 = 0;
      uStack_1b8 = 0;
      uStack_fc = 0;
      uStack_100 = 0;
      local_110 = 0;
      uStack_108 = 0;
      local_58 = 0;
      local_54 = 0;
      local_50 = 0;
      FUN_1009d9fc(DAT_1009533c + 0x10094cf4,auStack_29a8);
    }
switchD_10093288_caseD_1b59:
    iVar9 = DAT_100962a4 + 0x100952bc;
    uVar16 = 0x1b59;
    goto LAB_1009838c;
  case 0x69:
    iVar9 = DAT_1009670c + 0x10096078;
LAB_10096074:
    uVar16 = 0x414;
    goto LAB_1009838c;
  case 0x6a:
    iVar9 = DAT_100962a8 + 0x100952d4;
LAB_100952d0:
    uVar16 = 0x417;
    goto LAB_1009838c;
  case 0x6b:
    iVar9 = DAT_10096710 + 0x1009609c;
LAB_10096098:
    uVar16 = 0x418;
    goto LAB_1009838c;
  case 0x6e:
    auVar20 = ZEXT816(0);
    local_29c0 = 0;
    local_29b8 = 0;
    local_29b0 = 0;
    local_29c8._0_5_ = CONCAT14(param_4 == 1,0x419);
    local_29c8 = (ulonglong)(uint5)local_29c8;
    iVar11 = FUN_1009d8f4(DAT_10096304 + 0x10095360,&local_29c8,0x20);
    if (iVar11 != 0) {
      __aeabi_memclr8(auStack_29a8,0x2960);
      local_28f0 = auVar20._0_8_;
      uStack_28e8 = auVar20._8_8_;
      local_28dc = 0;
      local_28e0 = 0;
      local_282c = 0;
      local_2830 = 0;
      local_277c = 0;
      local_2780 = 0;
      local_26cc = 0;
      local_26d0 = 0;
      local_261c = 0;
      local_2620 = 0;
      local_256c = 0;
      local_2570 = 0;
      local_24bc = 0;
      local_24c0 = 0;
      local_240c = 0;
      local_2410 = 0;
      local_2360 = 0;
      local_235c = 0;
      local_22b0 = 0;
      local_22ac = 0;
      local_2200 = 0;
      local_21fc = 0;
      local_2150 = 0;
      local_214c = 0;
      local_209c = 0;
      local_20a0 = 0;
      local_1fec = 0;
      local_1ff0 = 0;
      local_1f3c = 0;
      local_1f40 = 0;
      local_1e8c = 0;
      local_1e90 = 0;
      local_1ddc = 0;
      local_1de0 = 0;
      local_1d2c = 0;
      local_1d30 = 0;
      local_1c7c = 0;
      local_1c80 = 0;
      local_1bcc = 0;
      local_1bd0 = 0;
      local_1b1c = 0;
      local_1b20 = 0;
      local_1a6c = 0;
      local_1a70 = 0;
      local_19c0 = 0;
      local_19bc = 0;
      uStack_190c = 0;
      uStack_1910 = 0;
      uStack_185c = 0;
      uStack_1860 = 0;
      uStack_17ac = 0;
      uStack_17b0 = 0;
      uStack_16fc = 0;
      uStack_1700 = 0;
      uStack_164c = 0;
      uStack_1650 = 0;
      uStack_159c = 0;
      uStack_15a0 = 0;
      uStack_14ec = 0;
      uStack_14f0 = 0;
      uStack_143c = 0;
      uStack_1440 = 0;
      uStack_138c = 0;
      uStack_1390 = 0;
      uStack_12dc = 0;
      uStack_12e0 = 0;
      uStack_122c = 0;
      uStack_1230 = 0;
      uStack_117c = 0;
      uStack_1180 = 0;
      uStack_10cc = 0;
      uStack_10d0 = 0;
      uStack_101c = 0;
      uStack_1020 = 0;
      uStack_f6c = 0;
      uStack_f70 = 0;
      uStack_ebc = 0;
      uStack_ec0 = 0;
      uStack_e0c = 0;
      uStack_e10 = 0;
      uStack_d5c = 0;
      uStack_d60 = 0;
      uStack_cac = 0;
      uStack_cb0 = 0;
      uStack_bfc = 0;
      uStack_c00 = 0;
      uStack_b4c = 0;
      uStack_b50 = 0;
      uStack_a9c = 0;
      uStack_aa0 = 0;
      uStack_9ec = 0;
      uStack_9f0 = 0;
      uStack_93c = 0;
      uStack_940 = 0;
      uStack_88c = 0;
      uStack_890 = 0;
      uStack_7dc = 0;
      uStack_7e0 = 0;
      uStack_72c = 0;
      uStack_730 = 0;
      uStack_67c = 0;
      uStack_680 = 0;
      uStack_5cc = 0;
      uStack_5d0 = 0;
      uStack_51c = 0;
      uStack_520 = 0;
      uStack_46c = 0;
      uStack_470 = 0;
      uStack_3bc = 0;
      uStack_3c0 = 0;
      uStack_30c = 0;
      uStack_310 = 0;
      uStack_25c = 0;
      uStack_260 = 0;
      uStack_1ac = 0;
      uStack_1b0 = 0;
      uStack_fc = 0;
      uStack_100 = 0;
      local_58 = 0;
      local_54 = 0;
      local_50 = 0;
      local_2840 = local_28f0;
      uStack_2838 = uStack_28e8;
      local_2790 = local_28f0;
      uStack_2788 = uStack_28e8;
      local_26e0 = local_28f0;
      uStack_26d8 = uStack_28e8;
      local_2630 = local_28f0;
      uStack_2628 = uStack_28e8;
      local_2580 = local_28f0;
      uStack_2578 = uStack_28e8;
      local_24d0 = local_28f0;
      uStack_24c8 = uStack_28e8;
      local_2420 = local_28f0;
      uStack_2418 = uStack_28e8;
      local_2370 = local_28f0;
      uStack_2368 = uStack_28e8;
      local_22c0 = local_28f0;
      uStack_22b8 = uStack_28e8;
      local_2210 = local_28f0;
      uStack_2208 = uStack_28e8;
      local_2160 = local_28f0;
      uStack_2158 = uStack_28e8;
      local_20b0 = local_28f0;
      uStack_20a8 = uStack_28e8;
      local_2000 = local_28f0;
      uStack_1ff8 = uStack_28e8;
      local_1f50 = local_28f0;
      uStack_1f48 = uStack_28e8;
      local_1ea0 = local_28f0;
      uStack_1e98 = uStack_28e8;
      local_1df0 = local_28f0;
      uStack_1de8 = uStack_28e8;
      local_1d40 = local_28f0;
      uStack_1d38 = uStack_28e8;
      local_1c90 = local_28f0;
      uStack_1c88 = uStack_28e8;
      local_1be0 = local_28f0;
      uStack_1bd8 = uStack_28e8;
      local_1b30 = local_28f0;
      uStack_1b28 = uStack_28e8;
      local_1a80 = local_28f0;
      uStack_1a78 = uStack_28e8;
      local_19d0 = local_28f0;
      uStack_19c8 = uStack_28e8;
      local_1920 = local_28f0;
      uStack_1918 = uStack_28e8;
      local_1870 = local_28f0;
      uStack_1868 = uStack_28e8;
      local_17c0 = local_28f0;
      uStack_17b8 = uStack_28e8;
      local_1710 = local_28f0;
      uStack_1708 = uStack_28e8;
      local_1660 = local_28f0;
      uStack_1658 = uStack_28e8;
      local_15b0 = local_28f0;
      uStack_15a8 = uStack_28e8;
      local_1500 = local_28f0;
      uStack_14f8 = uStack_28e8;
      local_1450 = local_28f0;
      uStack_1448 = uStack_28e8;
      local_13a0 = local_28f0;
      uStack_1398 = uStack_28e8;
      local_12f0 = local_28f0;
      uStack_12e8 = uStack_28e8;
      local_1240 = local_28f0;
      uStack_1238 = uStack_28e8;
      local_1190 = local_28f0;
      uStack_1188 = uStack_28e8;
      local_10e0 = local_28f0;
      uStack_10d8 = uStack_28e8;
      local_1030 = local_28f0;
      uStack_1028 = uStack_28e8;
      local_f80 = local_28f0;
      uStack_f78 = uStack_28e8;
      local_ed0 = local_28f0;
      uStack_ec8 = uStack_28e8;
      local_e20 = local_28f0;
      uStack_e18 = uStack_28e8;
      local_d70 = local_28f0;
      uStack_d68 = uStack_28e8;
      local_cc0 = local_28f0;
      uStack_cb8 = uStack_28e8;
      local_c10 = local_28f0;
      uStack_c08 = uStack_28e8;
      local_b60 = local_28f0;
      uStack_b58 = uStack_28e8;
      local_ab0 = local_28f0;
      uStack_aa8 = uStack_28e8;
      local_a00 = local_28f0;
      uStack_9f8 = uStack_28e8;
      local_950 = local_28f0;
      uStack_948 = uStack_28e8;
      local_8a0 = local_28f0;
      uStack_898 = uStack_28e8;
      local_7f0 = local_28f0;
      uStack_7e8 = uStack_28e8;
      local_740 = local_28f0;
      uStack_738 = uStack_28e8;
      local_690 = local_28f0;
      uStack_688 = uStack_28e8;
      local_5e0 = local_28f0;
      uStack_5d8 = uStack_28e8;
      local_530 = local_28f0;
      uStack_528 = uStack_28e8;
      local_480 = local_28f0;
      uStack_478 = uStack_28e8;
      local_3d0 = local_28f0;
      uStack_3c8 = uStack_28e8;
      local_320 = local_28f0;
      uStack_318 = uStack_28e8;
      local_270 = local_28f0;
      uStack_268 = uStack_28e8;
      local_1c0 = local_28f0;
      uStack_1b8 = uStack_28e8;
      local_110 = local_28f0;
      uStack_108 = uStack_28e8;
      FUN_1009d9fc(DAT_10096398 + 0x100953b4,auStack_29a8);
    }
    local_29b8 = auVar20._0_8_;
    local_29c0 = auVar20._8_8_;
    local_29c8._5_3_ = auVar20._5_3_;
    local_29c8 = CONCAT44(CONCAT31(local_29c8._5_3_,param_4 == 1),0x418);
    local_29b0 = local_29c0;
    iVar11 = FUN_1009d8f4(DAT_100966e4 + 0x10095974,&local_29c8,0x20);
    if (iVar11 != 0) {
      __aeabi_memclr8(auStack_29a8,0x2960);
      local_28f0 = 0;
      uStack_28e8 = 0;
      local_2840 = 0;
      uStack_2838 = 0;
      local_2790 = 0;
      uStack_2788 = 0;
      local_26e0 = 0;
      uStack_26d8 = 0;
      local_2630 = 0;
      uStack_2628 = 0;
      local_2580 = 0;
      uStack_2578 = 0;
      local_24d0 = 0;
      uStack_24c8 = 0;
      local_28dc = 0;
      local_28e0 = 0;
      local_282c = 0;
      local_2830 = 0;
      local_277c = 0;
      local_2780 = 0;
      local_26cc = 0;
      local_26d0 = 0;
      local_261c = 0;
      local_2620 = 0;
      local_256c = 0;
      local_2570 = 0;
      local_24bc = 0;
      local_24c0 = 0;
      local_2420 = 0;
      uStack_2418 = 0;
      local_2370 = 0;
      uStack_2368 = 0;
      local_22c0 = 0;
      uStack_22b8 = 0;
      local_2210 = 0;
      uStack_2208 = 0;
      local_2160 = 0;
      uStack_2158 = 0;
      local_20b0 = 0;
      uStack_20a8 = 0;
      local_240c = 0;
      local_2410 = 0;
      local_2360 = 0;
      local_235c = 0;
      local_22b0 = 0;
      local_22ac = 0;
      local_2200 = 0;
      local_21fc = 0;
      local_2150 = 0;
      local_214c = 0;
      local_209c = 0;
      local_20a0 = 0;
      local_2000 = 0;
      uStack_1ff8 = 0;
      local_1fec = 0;
      local_1ff0 = 0;
      local_1f50 = 0;
      uStack_1f48 = 0;
      local_1f3c = 0;
      local_1f40 = 0;
      local_1ea0 = 0;
      uStack_1e98 = 0;
      local_1e8c = 0;
      local_1e90 = 0;
      local_1df0 = 0;
      uStack_1de8 = 0;
      local_1ddc = 0;
      local_1de0 = 0;
      local_1d40 = 0;
      uStack_1d38 = 0;
      local_1d2c = 0;
      local_1d30 = 0;
      local_1c90 = 0;
      uStack_1c88 = 0;
      local_1c7c = 0;
      local_1c80 = 0;
      local_1be0 = 0;
      uStack_1bd8 = 0;
      local_1bcc = 0;
      local_1bd0 = 0;
      local_1b30 = 0;
      uStack_1b28 = 0;
      local_1b1c = 0;
      local_1b20 = 0;
      local_1a80 = 0;
      uStack_1a78 = 0;
      local_1a6c = 0;
      local_1a70 = 0;
      local_19d0 = 0;
      uStack_19c8 = 0;
      local_19c0 = 0;
      local_19bc = 0;
      uStack_190c = 0;
      uStack_1910 = 0;
      local_1920 = 0;
      uStack_1918 = 0;
      uStack_185c = 0;
      uStack_1860 = 0;
      local_1870 = 0;
      uStack_1868 = 0;
      uStack_17ac = 0;
      uStack_17b0 = 0;
      local_17c0 = 0;
      uStack_17b8 = 0;
      uStack_16fc = 0;
      uStack_1700 = 0;
      local_1710 = 0;
      uStack_1708 = 0;
      uStack_164c = 0;
      uStack_1650 = 0;
      local_1660 = 0;
      uStack_1658 = 0;
      uStack_159c = 0;
      uStack_15a0 = 0;
      local_15b0 = 0;
      uStack_15a8 = 0;
      uStack_14ec = 0;
      uStack_14f0 = 0;
      local_1500 = 0;
      uStack_14f8 = 0;
      uStack_143c = 0;
      uStack_1440 = 0;
      local_1450 = 0;
      uStack_1448 = 0;
      uStack_138c = 0;
      uStack_1390 = 0;
      local_13a0 = 0;
      uStack_1398 = 0;
      uStack_12dc = 0;
      uStack_12e0 = 0;
      local_12f0 = 0;
      uStack_12e8 = 0;
      uStack_122c = 0;
      uStack_1230 = 0;
      local_1240 = 0;
      uStack_1238 = 0;
      uStack_117c = 0;
      uStack_1180 = 0;
      local_1190 = 0;
      uStack_1188 = 0;
      uStack_10cc = 0;
      uStack_10d0 = 0;
      local_10e0 = 0;
      uStack_10d8 = 0;
      uStack_101c = 0;
      uStack_1020 = 0;
      local_1030 = 0;
      uStack_1028 = 0;
      uStack_f6c = 0;
      uStack_f70 = 0;
      local_f80 = 0;
      uStack_f78 = 0;
      uStack_ebc = 0;
      uStack_ec0 = 0;
      local_ed0 = 0;
      uStack_ec8 = 0;
      uStack_e0c = 0;
      uStack_e10 = 0;
      local_e20 = 0;
      uStack_e18 = 0;
      uStack_d5c = 0;
      uStack_d60 = 0;
      local_d70 = 0;
      uStack_d68 = 0;
      uStack_cac = 0;
      uStack_cb0 = 0;
      local_cc0 = 0;
      uStack_cb8 = 0;
      uStack_bfc = 0;
      uStack_c00 = 0;
      local_c10 = 0;
      uStack_c08 = 0;
      uStack_b4c = 0;
      uStack_b50 = 0;
      local_b60 = 0;
      uStack_b58 = 0;
      uStack_a9c = 0;
      uStack_aa0 = 0;
      local_ab0 = 0;
      uStack_aa8 = 0;
      uStack_9ec = 0;
      uStack_9f0 = 0;
      local_a00 = 0;
      uStack_9f8 = 0;
      uStack_93c = 0;
      uStack_940 = 0;
      local_950 = 0;
      uStack_948 = 0;
      uStack_88c = 0;
      uStack_890 = 0;
      local_8a0 = 0;
      uStack_898 = 0;
      uStack_7dc = 0;
      uStack_7e0 = 0;
      local_7f0 = 0;
      uStack_7e8 = 0;
      uStack_72c = 0;
      uStack_730 = 0;
      local_740 = 0;
      uStack_738 = 0;
      uStack_67c = 0;
      uStack_680 = 0;
      local_690 = 0;
      uStack_688 = 0;
      uStack_5cc = 0;
      uStack_5d0 = 0;
      local_5e0 = 0;
      uStack_5d8 = 0;
      uStack_51c = 0;
      uStack_520 = 0;
      local_530 = 0;
      uStack_528 = 0;
      uStack_46c = 0;
      uStack_470 = 0;
      local_480 = 0;
      uStack_478 = 0;
      uStack_3bc = 0;
      uStack_3c0 = 0;
      local_3d0 = 0;
      uStack_3c8 = 0;
      uStack_30c = 0;
      uStack_310 = 0;
      local_320 = 0;
      uStack_318 = 0;
      uStack_25c = 0;
      uStack_260 = 0;
      local_270 = 0;
      uStack_268 = 0;
      uStack_1ac = 0;
      uStack_1b0 = 0;
      local_1c0 = 0;
      uStack_1b8 = 0;
      uStack_fc = 0;
      uStack_100 = 0;
      local_110 = 0;
      uStack_108 = 0;
      local_58 = 0;
      local_54 = 0;
      local_50 = 0;
      FUN_1009d9fc(DAT_100966e8 + 0x100959c0,auStack_29a8);
    }
    uVar16 = 0;
    if (param_4 == 1) {
      uVar16 = 2000;
    }
    puVar15 = (undefined4 *)0x1009636c;
    iVar11 = DAT_100966ec + 0x10095f8c;
    uVar19 = VectorSignedToFloat(uVar16,(byte)(in_fpscr >> 0x15) & 3);
    if (param_4 == 1) {
      puVar15 = (undefined4 *)0x10096370;
    }
    *(undefined4 *)(DAT_100966f0 + 0x10095f98) = *puVar15;
    uVar16 = 0x68;
    goto LAB_10097a8c;
  case 0x6f:
    iVar9 = DAT_10096714 + 0x100960cc;
    uVar16 = 0x1619;
    goto LAB_1009838c;
  case 0x70:
    iVar9 = DAT_10096718 + 0x100960f0;
    uVar16 = 0x379;
    goto LAB_1009838c;
  case 0x72:
    iVar9 = DAT_100966f4 + 0x10095fb8;
LAB_10095fb4:
    if (param_4 != 0) {
      param_4 = 1;
    }
    param_3 = 0x1fb;
    local_29c8._4_4_ = param_4 & 0xff;
    goto LAB_1009349c;
  case 0xa6:
    iVar9 = DAT_100966f8 + 0x10095ff4;
    uVar16 = 0xa6;
LAB_1009838c:
    local_29c8._0_5_ = CONCAT14(param_4 == 1,uVar16);
    local_29c8 = (ulonglong)(uint5)local_29c8;
LAB_1009839c:
    local_29b0 = 0;
    local_29b8 = 0;
    local_29c0 = 0;
    auVar20 = ZEXT816(0);
    iVar11 = FUN_1009d8f4(iVar9,&local_29c8,0x20);
    if (iVar11 != 0) {
      __aeabi_memclr8(auStack_29a8,0x2960);
      iVar11 = DAT_10098ae4 + 0x100983c4;
LAB_100983c0:
      local_110 = auVar20._0_8_;
      uStack_108 = auVar20._8_8_;
LAB_10098978:
      local_50 = 0;
      local_54 = 0;
      local_58 = 0;
      uStack_fc = 0;
      uStack_100 = 0;
      uStack_1ac = 0;
      uStack_1b0 = 0;
      uStack_25c = 0;
      uStack_260 = 0;
      uStack_30c = 0;
      uStack_310 = 0;
      uStack_3bc = 0;
      uStack_3c0 = 0;
      uStack_46c = 0;
      uStack_470 = 0;
      uStack_51c = 0;
      uStack_520 = 0;
      uStack_5cc = 0;
      uStack_5d0 = 0;
      uStack_67c = 0;
      uStack_680 = 0;
      uStack_72c = 0;
      uStack_730 = 0;
      uStack_7dc = 0;
      uStack_7e0 = 0;
      uStack_88c = 0;
      uStack_890 = 0;
      uStack_93c = 0;
      uStack_940 = 0;
      uStack_9ec = 0;
      uStack_9f0 = 0;
      uStack_a9c = 0;
      uStack_aa0 = 0;
      uStack_b4c = 0;
      uStack_b50 = 0;
      uStack_bfc = 0;
      uStack_c00 = 0;
      uStack_cac = 0;
      uStack_cb0 = 0;
      uStack_d5c = 0;
      uStack_d60 = 0;
      uStack_e0c = 0;
      uStack_e10 = 0;
      uStack_ebc = 0;
      uStack_ec0 = 0;
      uStack_f6c = 0;
      uStack_f70 = 0;
      uStack_101c = 0;
      uStack_1020 = 0;
      uStack_10cc = 0;
      uStack_10d0 = 0;
      uStack_117c = 0;
      uStack_1180 = 0;
      uStack_122c = 0;
      uStack_1230 = 0;
      uStack_12dc = 0;
      uStack_12e0 = 0;
      uStack_138c = 0;
      uStack_1390 = 0;
      uStack_143c = 0;
      uStack_1440 = 0;
      uStack_14ec = 0;
      uStack_14f0 = 0;
      uStack_159c = 0;
      uStack_15a0 = 0;
      uStack_164c = 0;
      uStack_1650 = 0;
      uStack_16fc = 0;
      uStack_1700 = 0;
      uStack_17ac = 0;
      uStack_17b0 = 0;
      uStack_185c = 0;
      uStack_1860 = 0;
      uStack_190c = 0;
      uStack_1910 = 0;
      local_19bc = 0;
      local_19c0 = 0;
      local_1a6c = 0;
      local_1a70 = 0;
      local_1b1c = 0;
      local_1b20 = 0;
      local_1bcc = 0;
      local_1bd0 = 0;
      local_1c7c = 0;
      local_1c80 = 0;
      local_1d2c = 0;
      local_1d30 = 0;
      local_1ddc = 0;
      local_1de0 = 0;
      local_1e8c = 0;
      local_1e90 = 0;
      local_1f3c = 0;
      local_1f40 = 0;
      local_1fec = 0;
      local_1ff0 = 0;
      local_209c = 0;
      local_20a0 = 0;
      local_214c = 0;
      local_2150 = 0;
      local_21fc = 0;
      local_2200 = 0;
      local_22ac = 0;
      local_22b0 = 0;
      local_235c = 0;
      local_2360 = 0;
      local_240c = 0;
      local_2410 = 0;
      local_24bc = 0;
      local_24c0 = 0;
      local_256c = 0;
      local_2570 = 0;
      local_261c = 0;
      local_2620 = 0;
      local_26cc = 0;
      local_26d0 = 0;
      local_277c = 0;
      local_2780 = 0;
      local_282c = 0;
      local_2830 = 0;
      local_28dc = 0;
      local_28e0 = 0;
      local_28f0 = local_110;
      uStack_28e8 = uStack_108;
      local_2840 = local_110;
      uStack_2838 = uStack_108;
      local_2790 = local_110;
      uStack_2788 = uStack_108;
      local_26e0 = local_110;
      uStack_26d8 = uStack_108;
      local_2630 = local_110;
      uStack_2628 = uStack_108;
      local_2580 = local_110;
      uStack_2578 = uStack_108;
      local_24d0 = local_110;
      uStack_24c8 = uStack_108;
      local_2420 = local_110;
      uStack_2418 = uStack_108;
      local_2370 = local_110;
      uStack_2368 = uStack_108;
      local_22c0 = local_110;
      uStack_22b8 = uStack_108;
      local_2210 = local_110;
      uStack_2208 = uStack_108;
      local_2160 = local_110;
      uStack_2158 = uStack_108;
      local_20b0 = local_110;
      uStack_20a8 = uStack_108;
      local_2000 = local_110;
      uStack_1ff8 = uStack_108;
      local_1f50 = local_110;
      uStack_1f48 = uStack_108;
      local_1ea0 = local_110;
      uStack_1e98 = uStack_108;
      local_1df0 = local_110;
      uStack_1de8 = uStack_108;
      local_1d40 = local_110;
      uStack_1d38 = uStack_108;
      local_1c90 = local_110;
      uStack_1c88 = uStack_108;
      local_1be0 = local_110;
      uStack_1bd8 = uStack_108;
      local_1b30 = local_110;
      uStack_1b28 = uStack_108;
      local_1a80 = local_110;
      uStack_1a78 = uStack_108;
      local_19d0 = local_110;
      uStack_19c8 = uStack_108;
      local_1920 = local_110;
      uStack_1918 = uStack_108;
      local_1870 = local_110;
      uStack_1868 = uStack_108;
      local_17c0 = local_110;
      uStack_17b8 = uStack_108;
      local_1710 = local_110;
      uStack_1708 = uStack_108;
      local_1660 = local_110;
      uStack_1658 = uStack_108;
      local_15b0 = local_110;
      uStack_15a8 = uStack_108;
      local_1500 = local_110;
      uStack_14f8 = uStack_108;
      local_1450 = local_110;
      uStack_1448 = uStack_108;
      local_13a0 = local_110;
      uStack_1398 = uStack_108;
      local_12f0 = local_110;
      uStack_12e8 = uStack_108;
      local_1240 = local_110;
      uStack_1238 = uStack_108;
      local_1190 = local_110;
      uStack_1188 = uStack_108;
      local_10e0 = local_110;
      uStack_10d8 = uStack_108;
      local_1030 = local_110;
      uStack_1028 = uStack_108;
      local_f80 = local_110;
      uStack_f78 = uStack_108;
      local_ed0 = local_110;
      uStack_ec8 = uStack_108;
      local_e20 = local_110;
      uStack_e18 = uStack_108;
      local_d70 = local_110;
      uStack_d68 = uStack_108;
      local_cc0 = local_110;
      uStack_cb8 = uStack_108;
      local_c10 = local_110;
      uStack_c08 = uStack_108;
      local_b60 = local_110;
      uStack_b58 = uStack_108;
      local_ab0 = local_110;
      uStack_aa8 = uStack_108;
      local_a00 = local_110;
      uStack_9f8 = uStack_108;
      local_950 = local_110;
      uStack_948 = uStack_108;
      local_8a0 = local_110;
      uStack_898 = uStack_108;
      local_7f0 = local_110;
      uStack_7e8 = uStack_108;
      local_740 = local_110;
      uStack_738 = uStack_108;
      local_690 = local_110;
      uStack_688 = uStack_108;
      local_5e0 = local_110;
      uStack_5d8 = uStack_108;
      local_530 = local_110;
      uStack_528 = uStack_108;
      local_480 = local_110;
      uStack_478 = uStack_108;
      local_3d0 = local_110;
      uStack_3c8 = uStack_108;
      local_320 = local_110;
      uStack_318 = uStack_108;
      local_270 = local_110;
      uStack_268 = uStack_108;
      local_1c0 = local_110;
      uStack_1b8 = uStack_108;
      FUN_1009d9fc(iVar11,auStack_29a8);
    }
  }
switchD_10093180_caseD_1ff:
  if (*piVar17 == local_44) {
    return;
  }
LAB_1009899c:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

