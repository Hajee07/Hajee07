"""Bounded ARM emulation of supplied recovered dispatcher; no target process or network."""
from pathlib import Path
import struct
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE, UC_HOOK_MEM_WRITE
from unicorn.arm_const import *

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'evidence/Java_com_NovaX_Menu_ChangesID.bin'
BASE = 0x10093100
BODY = SOURCE.read_bytes()

def trace(option, value, seeds=None, send_ok=True):
    uc = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_A15)
    uc.mem_map(0x10000000, 0x200000)
    uc.mem_map(0x20000000, 0x100000)
    uc.mem_map(0x50000000, 0x1000)
    uc.mem_write(BASE, BODY)
    uc.reg_write(UC_ARM_REG_C1_C0_2, 0x00f00000)
    uc.reg_write(UC_ARM_REG_FPEXC, 0x40000000)
    uc.mem_write(0x100e0c54, struct.pack('<I', 0x101f0000))
    uc.mem_write(0x101f0000, struct.pack('<I', 0x12345678))
    for address, byte in (seeds or {}).items():
        uc.mem_write(address, bytes([byte]))
    uc.reg_write(UC_ARM_REG_SP, 0x200f0000)
    uc.reg_write(UC_ARM_REG_LR, 0x50000000)
    uc.reg_write(UC_ARM_REG_R0, 0x101e0000)
    uc.reg_write(UC_ARM_REG_R1, 0)
    uc.reg_write(UC_ARM_REG_R2, option)
    uc.reg_write(UC_ARM_REG_R3, value & 0xffffffff)
    result = {'packets': [], 'writes': [], 'receives': [], 'events': [], 'returned': False}
    def code(engine, address, size, unused):
        if address == 0x50000000:
            result['returned'] = True
            engine.emu_stop()
            return
        if address == 0x1009d8f4:
            context = engine.reg_read(UC_ARM_REG_R0)
            ptr = engine.reg_read(UC_ARM_REG_R1)
            length = engine.reg_read(UC_ARM_REG_R2)
            assert length == 32
            packet = {'channel': context, 'payload': bytes(engine.mem_read(ptr, length)).hex()}
            result['packets'].append(packet)
            result['events'].append({'type': 'send', **packet})
            engine.reg_write(UC_ARM_REG_R0, int(send_ok))
        elif address == 0x1009d9fc:
            context = engine.reg_read(UC_ARM_REG_R0)
            result['receives'].append(context)
            result['events'].append({'type': 'receive', 'channel': context})
            engine.reg_write(UC_ARM_REG_R0, 0)
        elif address == 0x1008af18:
            ptr = engine.reg_read(UC_ARM_REG_R0)
            length = engine.reg_read(UC_ARM_REG_R1)
            assert 0x20000000 <= ptr < ptr + length <= 0x20100000
            engine.mem_write(ptr, b'\x00' * length)
        else:
            if not BASE <= address < BASE + len(BODY):
                raise RuntimeError(f'Unexpected native destination {address:#x}')
            return
        engine.reg_write(UC_ARM_REG_PC, engine.reg_read(UC_ARM_REG_LR))
    def write(engine, access, address, size, value, unused):
        if 0x10000000 <= address < 0x10200000:
            operation = {'address': address, 'size': size, 'value': value & ((1 << (8 * size)) - 1)}
            result['writes'].append(operation)
            result['events'].append({'type': 'write', **operation})
    uc.hook_add(UC_HOOK_CODE, code)
    uc.hook_add(UC_HOOK_MEM_WRITE, write)
    uc.emu_start(BASE, 0x50000004, count=50000)
    assert result['returned'], 'Dispatcher did not return within the instruction bound'
    return result

if __name__ == '__main__':
    import json, sys
    print(json.dumps(trace(int(sys.argv[1]), int(sys.argv[2])), indent=2))
