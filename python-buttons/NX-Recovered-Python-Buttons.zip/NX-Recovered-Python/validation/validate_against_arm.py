"""Compare translated handlers to bounded emulation of the supplied ARM bytes.

This validates dispatcher events, not Android UI, transport endpoints, rendering,
or game features. Native I/O is intercepted; no game or app is started.
"""
from pathlib import Path
import importlib.metadata
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from all_buttons import BY_ID
from runtime import MenuRuntime, RecordingTransport, NativeBackendRequired, UnknownInitialState, frame_payload
from arm_oracle import trace


TOGGLE_ADDRESSES = {5194: 0x1010DDDC, 5198: 0x1010DDD4}


def compare(option, value, initial=0, send_ok=True):
    seeds = {TOGGLE_ADDRESSES[option]: initial} if option in TOGGLE_ADDRESSES else {}
    expected = trace(option, value, seeds, send_ok=send_ok)
    transport = RecordingTransport(send_ok=send_ok)
    runtime = MenuRuntime(transport, initial_bytes=seeds)
    BY_ID[option](runtime, value)
    if runtime.events != expected['events']:
        raise AssertionError(json.dumps({'id':option,'value':value,'initial':initial,
                                        'send_ok':send_ok,'python':runtime.events,
                                        'arm':expected['events']},indent=2))
    return {'id':option,'value':value,'initial_toggle_byte':initial,
            'send_ok':send_ok,'events':runtime.events}


def main():
    mapping = json.loads((ROOT / 'button_mapping.json').read_text())
    assert len(mapping) == len(BY_ID) == 51
    assert {r['id'] for r in mapping} == set(BY_ID)
    results = []
    for option in BY_ID:
        values = [0, 1, 2, 0xFFFFFFFF]
        if option == 5660:
            values = [0, 1, 2, 15, 100, -1, 0x7FFFFFFF, -0x80000000]
        for value in values:
            for send_ok in (True, False):
                results.append(compare(option, value, send_ok=send_ok))
        if option in TOGGLE_ADDRESSES:
            for initial in (1, 2, 255):
                for value in values:
                    for send_ok in (True, False):
                        results.append(compare(option,value,initial,send_ok))

    # Repeat-toggle behavior must depend on previous state, not the UI argument.
    for option, address in TOGGLE_ADDRESSES.items():
        runtime = MenuRuntime(RecordingTransport(), {address: 0})
        for expected in (1, 0, 1, 0):
            BY_ID[option](runtime,1)
            assert runtime.read_u8(address) == expected

    # Missing native implementations must not silently report gameplay success.
    for option in (517, 1099):
        try:
            BY_ID[option](MenuRuntime(),1)
        except NativeBackendRequired:
            pass
        else:
            raise AssertionError('Missing native backend did not raise')
    for option in TOGGLE_ADDRESSES:
        try:
            BY_ID[option](MenuRuntime(RecordingTransport()),1)
        except UnknownInitialState:
            pass
        else:
            raise AssertionError('Unknown toggle state silently assumed')
    assert frame_payload(b'AB') == b'\x00\x00\x00\x02AB'
    summary = {'controls':51,'arm_comparison_cases_passed':len(results),
               'mismatches':0,'unicorn_version':importlib.metadata.version('unicorn'),
               'native_game_io_executed':False,'android_or_gameplay_verified':False,
               'scope':'Writes and ordered send/conditional-receive events versus the supplied recovered dispatcher binary; zeroed analysis memory except explicit toggle seeds and stack guard. I/O and memclear hooks are modeled.'}
    (ROOT/'validation/results.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'validation/arm_comparison_cases.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
