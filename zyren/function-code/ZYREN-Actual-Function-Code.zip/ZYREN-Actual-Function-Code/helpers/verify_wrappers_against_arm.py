"""Bounded ARM/JNI-model checks of freshly recovered wrapper machine code.

The response producer, JNI API and transport are modeled. No Android runtime,
game, native syscalls or host-network calls are executed.
"""
from pathlib import Path
import json
import struct
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import *
from get_enemy_list import getEnemyList, decode_modified_utf8
from get_match_timer_status import getMatchTimerStatus
from lock_player import LockPlayer

BASE = 0x10000000
STOP = 0x30000000
SNAPSHOT = Path(__file__).parents[1] / 'unpack/libNOVA_MENU.so.dt_init_memory.bin'
BODY = b''


class JNIModel:
    def __init__(self, response=None, timer=(0,-1), send_ok=True):
        self.uc=Uc(UC_ARCH_ARM,UC_MODE_ARM)
        self.uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_A15)
        self.uc.mem_map(BASE,(len(BODY)+4095)&~4095)
        self.uc.mem_write(BASE,BODY)
        for address,size in [(0x20000000,0x100000),(STOP,0x1000),(0x50000000,0x100000),(0x60000000,0x10000)]:
            self.uc.mem_map(address,size)
        self.uc.reg_write(UC_ARM_REG_C1_C0_2,0xF00000)
        self.uc.reg_write(UC_ARM_REG_FPEXC,0x40000000)
        self.write32(0x60000000,0x60001000)
        self.slots={}
        for offset in (0x18,0x29C,0x2B0,0x2B8,0x2CC,0x34C):
            callback=0x60002000+offset
            self.write32(0x60001000+offset,callback)
            self.slots[callback]=offset
        # Current relocations resolve the stack-guard pointer outside the library.
        guard_pointer=self.read32(0x100E0C54)
        assert 0x50000000<=guard_pointer<0x50100000
        self.write32(guard_pointer,0x12345678)
        self.uc.mem_write(0x100E3A60,struct.pack('<i',timer[0]))
        self.uc.mem_write(0x100E1000,struct.pack('<i',timer[1]))
        self.response=response
        self.send_ok=send_ok
        self.objects={}
        self.next_handle=0x70000000
        self.events=[]
        self.returned=False
        self.uc.hook_add(UC_HOOK_CODE,self.hook)

    def read32(self,address):return struct.unpack('<I',self.uc.mem_read(address,4))[0]
    def write32(self,address,value):self.uc.mem_write(address,struct.pack('<I',value&0xFFFFFFFF))
    def cstr(self,address):
        result=bytearray()
        for offset in range(0x3000):
            value=self.uc.mem_read(address+offset,1)[0]
            if value==0:return bytes(result)
            result.append(value)
        raise AssertionError('Bounded modeled C string did not terminate')
    def handle(self,value):
        result=self.next_handle;self.next_handle+=4;self.objects[result]=value;return result
    def ret(self,value=0):
        self.uc.reg_write(UC_ARM_REG_R0,value&0xFFFFFFFF)
        self.uc.reg_write(UC_ARM_REG_PC,self.uc.reg_read(UC_ARM_REG_LR))

    def hook(self,uc,address,size,unused):
        a,b,c,d=[uc.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3)]
        if address==STOP:
            self.returned=True;uc.emu_stop();return
        if address==0x1008C0A0:
            assert (b,c)==(1920,1080)
            uc.mem_write(a,self.response);self.ret();return
        if address==0x100993B4:
            fmt=self.cstr(c)
            if fmt==b'%s':value=self.cstr(d)
            elif fmt==b'%llu':
                target=struct.unpack('<Q',uc.mem_read(uc.reg_read(UC_ARM_REG_SP),8))[0]
                value=str(target).encode()
            else:raise AssertionError(fmt)
            uc.mem_write(a,value[:b-1]+b'\0');self.ret(len(value));return
        if address==0x1009D8F4:
            assert c==32
            self.events.append(('send',a,bytes(uc.mem_read(b,c))))
            self.ret(int(self.send_ok));return
        if address==0x1009D9FC:
            self.events.append(('receive',a,0x2960));self.ret();return
        if address==0x1008AF18:
            assert b==0x2960
            uc.mem_write(a,b'\0'*b);self.ret();return
        if address in self.slots:
            slot=self.slots[address]
            if slot==0x18:
                assert self.cstr(b)==b'java/lang/String'
                self.ret(self.handle('java/lang/String'))
            elif slot==0x29C:self.ret(self.handle(decode_modified_utf8(self.cstr(b))))
            elif slot in (0x2B0,0x2CC):self.ret(self.handle([None]*b))
            elif slot==0x2B8:self.objects[b][c]=self.objects[d];self.ret()
            elif slot==0x34C:
                pointer=self.read32(uc.reg_read(UC_ARM_REG_SP))
                values=list(struct.unpack('<'+'i'*d,uc.mem_read(pointer,4*d)))
                self.objects[b][c:c+d]=values;self.ret()
            return
        if not BASE<=address<BASE+len(BODY):
            raise AssertionError(f'Unexpected executable destination {address:#x}')

    def run(self,address,target=0):
        self.uc.reg_write(UC_ARM_REG_SP,0x200F0000)
        self.uc.reg_write(UC_ARM_REG_LR,STOP)
        self.uc.reg_write(UC_ARM_REG_R0,0x60000000)
        self.uc.reg_write(UC_ARM_REG_R1,0)
        self.uc.reg_write(UC_ARM_REG_R2,target&0xFFFFFFFF)
        self.uc.reg_write(UC_ARM_REG_R3,(target>>32)&0xFFFFFFFF)
        self.uc.emu_start(address,STOP+4,count=50000)
        assert self.returned
        result=self.uc.reg_read(UC_ARM_REG_R0)
        return None if result==0 else self.objects.get(result,result)


def main(snapshot_path=SNAPSHOT):
    global BODY
    BODY = Path(snapshot_path).read_bytes()
    outcomes=[]
    for status,count in [(0,2),(1,0),(1,2)]:
        response=bytearray(0x2960);response[0]=status
        struct.pack_into('<I',response,4,count)
        for index,(name,target) in enumerate([(b'Alpha',0xFFFFFFFFFFFFFFFF),(b'Beta',42)]):
            response[0x24+index*0xB0:0x24+index*0xB0+len(name)+1]=name+b'\0'
            struct.pack_into('<Q',response,0xB0+index*0xB0,target)
        model=JNIModel(bytes(response))
        native=model.run(0x10099220)
        python=getEnemyList(lambda w,h:bytes(response))
        assert native==python,(native,python)
        outcomes.append({'function':'getEnemyList','status':status,'count':count,'result':native})
    for timer in [(0,-1),(-3,123),(0x7FFFFFFF,-0x80000000)]:
        model=JNIModel(timer=timer)
        native=model.run(0x1008CDB8)
        python=getMatchTimerStatus(lambda address,size:bytes(model.uc.mem_read(address,size)))
        assert native==python==list(timer)
        outcomes.append({'function':'getMatchTimerStatus','result':native})
    class Recorder:
        def __init__(self,ok):self.events=[];self.ok=ok
        def send(self,channel,payload):self.events.append(('send',channel,payload));return self.ok
        def receive(self,channel,maximum):self.events.append(('receive',channel,maximum));return b''
    for target in (0,0x1122334455667788,0xFFFFFFFFFFFFFFFF):
        for success in (True,False):
            model=JNIModel(send_ok=success);model.run(0x10098BB4,target)
            recorder=Recorder(success);LockPlayer(target,recorder)
            assert model.events==recorder.events,(model.events,recorder.events)
            outcomes.append({'function':'LockPlayer','target':target,'send_success':success})
    report={'arm_wrapper_comparisons_passed':len(outcomes),'cases':outcomes,
            'scope':'Fresh recovered ARM wrappers with modeled JNI, response producer, formatting and native transport; no Android or game execution.',
            'live_game_verified':False}
    (Path(__file__).parent/'arm-wrapper-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot',type=Path,default=SNAPSHOT)
    main(parser.parse_args().snapshot)
