/* Decompiled C-like pseudocode from an emulated unpacked memory image.
 * This is NOT original C/C++ source and is NOT independently buildable.
 * Types, signatures and names can be inferred or incomplete.
 * Android/game behavior has not been tested.
 */


/* WARNING: Removing unreachable block (ram,0x1009abac) */

void Java_com_NovaX_Menu_OnDrawLoad(float *param_1,undefined4 param_2,float *param_3,float *param_4)

{
  int iVar1;
  uint uVar2;
  byte bVar3;
  char cVar4;
  byte bVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  float *pfVar11;
  float *pfVar12;
  char *pcVar13;
  char *pcVar14;
  float *pfVar15;
  undefined4 uVar16;
  float *pfVar17;
  undefined4 *puVar18;
  uint *puVar19;
  float *extraout_r1;
  float *extraout_r1_00;
  float *extraout_r1_01;
  float *extraout_r1_02;
  float *extraout_r1_03;
  float *extraout_r1_04;
  float *extraout_r1_05;
  float *extraout_r1_06;
  float *extraout_r1_07;
  float *extraout_r1_08;
  float *unaff_r4;
  float *pfVar20;
  int *piVar21;
  float *pfVar22;
  float fVar23;
  size_t __n;
  float *pfVar24;
  int iVar25;
  undefined8 *puVar26;
  float fVar27;
  uint uVar28;
  bool bVar29;
  uint in_fpscr;
  uint uVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  undefined4 extraout_s1_05;
  undefined4 extraout_s1_06;
  undefined4 extraout_s1_07;
  float fVar35;
  undefined4 extraout_s3;
  undefined4 extraout_s3_00;
  undefined4 extraout_s3_01;
  undefined4 extraout_s3_02;
  undefined4 extraout_s3_03;
  undefined4 extraout_s3_04;
  undefined4 extraout_s3_05;
  undefined4 extraout_s3_06;
  undefined4 extraout_s3_07;
  undefined4 extraout_s3_08;
  undefined4 extraout_s3_09;
  undefined4 extraout_s3_10;
  float unaff_s16;
  float fVar37;
  double dVar36;
  float fVar38;
  float fVar39;
  float fVar41;
  double dVar40;
  float fVar42;
  float fVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  float fVar48;
  float fVar49;
  float fVar50;
  double dVar51;
  double dVar52;
  undefined8 uVar53;
  undefined8 uVar54;
  float *local_2bd4;
  float *local_2bc0;
  float *local_2bbc;
  float *local_2bb8;
  float *local_2bb4;
  float *local_2bb0;
  undefined2 local_2bab;
  byte local_2ba9;
  undefined2 local_2ba8;
  byte local_2ba6;
  undefined2 local_2ba4;
  byte local_2ba2;
  undefined8 local_2ba0;
  undefined8 local_2b98;
  undefined8 local_2b90;
  undefined8 uStack_2b88;
  char local_2b60;
  undefined auStack_2b5f [254];
  undefined local_2a61;
  undefined8 local_2a60;
  float local_2a58;
  char local_2a50;
  undefined8 local_2a4f;
  undefined8 uStack_2a47;
  undefined8 local_2a3f;
  undefined8 uStack_2a37;
  undefined8 local_2a2f;
  undefined8 uStack_2a27;
  undefined8 local_2a1f;
  undefined8 uStack_2a17;
  undefined8 local_2a0f;
  undefined8 uStack_2a07;
  undefined8 local_29ff;
  undefined8 uStack_29f7;
  undefined8 local_29ef;
  undefined7 uStack_29e7;
  undefined local_29e0;
  undefined7 uStack_29df;
  undefined local_29d1;
  byte local_29d0 [4];
  int local_29cc;
  undefined8 local_2924 [1299];
  undefined4 local_88;
  undefined4 uStack_84;
  float local_80;
  float local_7c;
  int local_70;
  
  piVar21 = *(int **)(DAT_1009a3d4 + 0x10099448 /* snapshot -> 0x100e0c54 */);
  local_70 = *piVar21;
  local_2bb8 = param_1;
  local_2bb4 = param_3;
  local_2bb0 = param_4;
  if (param_1 != (float *)0x0) {
    if (param_3 != (float *)0x0) {
      unaff_r4 = param_4;
    }
    if (param_3 != (float *)0x0 && param_4 != (float *)0x0) {
      uVar7 = (**(code **)((int)*param_1 + 0x7c))(param_1,unaff_r4);
      iVar25 = DAT_1009a3dc + 0x100994cc /* snapshot -> 0x100b19f9 "()I" */;
      uVar7 = (**(code **)((int)*param_1 + 0x84))(param_1,uVar7,DAT_1009a3d8 + 0x100994c8 /* snapshot -> 0x100b19f0 "getWidth" */,iVar25);
      uVar7 = FUN_1009d250(param_1,unaff_r4,uVar7);
      uVar8 = (**(code **)((int)*param_1 + 0x7c))(param_1,unaff_r4);
      pfVar22 = *(float **)((int)*param_1 + 0x84);
      uVar8 = (*(code *)pfVar22)(param_1,uVar8,DAT_1009a3e0 + 0x10099518 /* snapshot -> 0x100b19fd "getHeight" */,iVar25);
      uVar8 = FUN_1009d250(param_1,unaff_r4,uVar8);
      FUN_1008c0a0(local_29d0,uVar7,uVar8);
      pfVar24 = (float *)(uint)local_29d0[0];
      puVar18 = (undefined4 *)(DAT_1009a3e8 + 0x1009955c /* snapshot -> 0x100e1000 */);
      *(undefined4 *)(DAT_1009a3e4 + 0x10099554 /* snapshot -> 0x100e3a60 */) = local_88;
      *puVar18 = uStack_84;
      fVar27 = DAT_100998cc;
      fVar23 = DAT_100998c8;
      local_2bd4 = (float *)0x0;
      if (pfVar24 == (float *)0x0) {
        local_2bc0 = (float *)0x0;
      }
      else {
        local_2bc0 = (float *)0x0;
        if (0 < local_29cc) {
          puVar26 = local_2924;
          local_2bbc = (float *)0x0;
          iVar25 = 0;
          local_2bc0 = (float *)0x0;
          local_2bd4 = (float *)0x0;
          fVar44 = DAT_100998d0;
          fVar34 = DAT_100998d4;
          fVar49 = DAT_100998d8;
          do {
            fVar38 = *(float *)((int)puVar26 + -0xa4);
            fVar42 = *(float *)(puVar26 + -0x14);
            fVar41 = *(float *)((int)puVar26 + -0x9c);
            fVar37 = *(float *)(puVar26 + -0x13);
            fVar50 = *(float *)((int)puVar26 + -0x94);
            fVar47 = *(float *)(puVar26 + -0x12);
            fVar45 = *(float *)((int)puVar26 + -0x8c);
            __aeabi_memcpy4(&local_2b60,puVar26 + -0x11,0x80);
            pfVar20 = local_2bb8;
            bVar3 = *(byte *)(puVar26 + -1);
            pfVar24 = (float *)(uint)bVar3;
            uVar28 = in_fpscr & 0xfffffff;
            in_fpscr = uVar28 | (uint)(fVar45 == 0.0) << 0x1e | (uint)(0.0 <= fVar45) << 0x1d;
            local_2ba2 = *(byte *)((int)puVar26 + -5);
            bVar5 = (byte)(in_fpscr >> 0x18);
            fVar43 = *(float *)((int)puVar26 + -4);
            local_2ba0 = *puVar26;
            local_2ba4 = *(undefined2 *)((int)puVar26 + -7);
            local_2b98 = CONCAT44(local_2b98._4_4_,*(undefined4 *)(puVar26 + 1));
            pfVar17 = local_2bd4;
            if ((((bool)(bVar5 >> 5 & 1) && !(bool)(bVar5 >> 6)) &&
                (uVar30 = uVar28 | (uint)(fVar43 < fVar23) << 0x1f |
                          (uint)(fVar43 == fVar23) << 0x1e,
                in_fpscr = uVar30 | (uint)(NAN(fVar43) || NAN(fVar23)) << 0x1c,
                bVar5 = (byte)(uVar30 >> 0x18),
                (bool)(bVar5 >> 6 & 1) || bVar5 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1))) &&
               (in_fpscr = uVar28 | (uint)(fVar43 == 0.0) << 0x1e | (uint)(0.0 <= fVar43) << 0x1d,
               bVar5 = (byte)(in_fpscr >> 0x18), (bool)(bVar5 >> 5 & 1) && !(bool)(bVar5 >> 6))) {
              in_fpscr = uVar28 | (uint)(fVar38 == 0.0) << 0x1e;
              bVar29 = SUB41(in_fpscr >> 0x1e,0);
              if (bVar29) {
                in_fpscr = uVar28 | (uint)(fVar42 == 0.0) << 0x1e;
                bVar29 = SUB41(in_fpscr >> 0x1e,0);
              }
              if ((!bVar29) ||
                 (in_fpscr = in_fpscr & 0xfffffff | (uint)(fVar41 == 0.0) << 0x1e,
                 !SUB41(in_fpscr >> 0x1e,0))) {
                uVar28 = in_fpscr & 0xfffffff;
                in_fpscr = uVar28 | (uint)(fVar37 == 0.0) << 0x1e;
                bVar29 = SUB41(in_fpscr >> 0x1e,0);
                if (bVar29) {
                  in_fpscr = uVar28 | (uint)(fVar50 == 0.0) << 0x1e;
                  bVar29 = SUB41(in_fpscr >> 0x1e,0);
                }
                if ((!bVar29) ||
                   (in_fpscr = in_fpscr & 0xfffffff | (uint)(fVar47 == 0.0) << 0x1e,
                   !SUB41(in_fpscr >> 0x1e,0))) {
                  uVar28 = in_fpscr & 0xfffffff;
                  in_fpscr = uVar28 | (uint)(fVar41 < fVar27) << 0x1f;
                  bVar29 = SUB41(in_fpscr >> 0x1f,0);
                  if (!bVar29) {
                    in_fpscr = uVar28 | (uint)(fVar47 < fVar27) << 0x1f;
                    bVar29 = SUB41(in_fpscr >> 0x1f,0);
                  }
                  if (!bVar29) {
                    fVar31 = ABS(fVar42 - fVar50);
                    uVar28 = in_fpscr & 0xfffffff;
                    in_fpscr = uVar28 | (uint)(fVar31 < 5.0) << 0x1f;
                    if ((!SUB41(in_fpscr >> 0x1f,0)) &&
                       (uVar30 = uVar28 | (uint)(fVar31 < fVar44) << 0x1f |
                                 (uint)(fVar31 == fVar44) << 0x1e,
                       in_fpscr = uVar30 | (uint)(NAN(fVar31) || NAN(fVar44)) << 0x1c,
                       bVar5 = (byte)(uVar30 >> 0x18),
                       (bool)(bVar5 >> 6 & 1) || bVar5 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1))) {
                      uVar7 = 0;
                      fVar44 = 1.0;
                      if (fVar34 / fVar43 < 1.0) {
                        fVar44 = fVar34 / fVar43;
                      }
                      uVar28 = uVar28 | (uint)(fVar44 < 0.5) << 0x1f | (uint)(fVar44 == 0.5) << 0x1e
                      ;
                      uVar30 = uVar28 | (uint)NAN(fVar44) << 0x1c;
                      bVar5 = (byte)(uVar28 >> 0x18);
                      fVar46 = 0.5;
                      if (!(bool)(bVar5 >> 6 & 1) && bVar5 >> 7 == ((byte)(uVar30 >> 0x1c) & 1)) {
                        fVar46 = fVar44;
                      }
                      fVar31 = fVar31 * fVar46;
                      fVar48 = fVar31 * fVar49;
                      if (local_2bb8 != (float *)0x0) {
                        if (local_2bb4 != (float *)0x0) {
                          pfVar22 = local_2bb0;
                        }
                        if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                          uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar22);
                          uVar7 = (**(code **)((int)*pfVar20 + 0x84))
                                            (pfVar20,uVar7,DAT_1009a6b4 + 0x10099740 /* snapshot -> 0x100b19fd "getHeight" */,
                                             DAT_1009a6b8 + 0x10099744 /* snapshot -> 0x100b19f9 "()I" */);
                          uVar7 = FUN_1009d250(pfVar20,pfVar22,uVar7);
                        }
                      }
                      pfVar20 = local_2bb8;
                      fVar32 = (float)VectorSignedToFloat(uVar7,(byte)(uVar30 >> 0x15) & 3);
                      fVar39 = fVar38 - fVar48 * 0.5;
                      in_fpscr = uVar30 & 0xfffffff | (uint)(fVar39 < 0.0) << 0x1f;
                      fVar44 = DAT_100998d0;
                      fVar34 = DAT_100998d4;
                      fVar49 = DAT_100998d8;
                      if (!SUB41(in_fpscr >> 0x1f,0)) {
                        uVar7 = 0;
                        fVar32 = (fVar32 - fVar42) + fVar31 * DAT_10099a0c;
                        if (local_2bb8 != (float *)0x0) {
                          if (local_2bb4 != (float *)0x0) {
                            pfVar22 = local_2bb0;
                          }
                          if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                            uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar22);
                            uVar7 = (**(code **)((int)*pfVar20 + 0x84))
                                              (pfVar20,uVar7,DAT_1009a6bc + 0x100997d8 /* snapshot -> 0x100b19f0 "getWidth" */,
                                               DAT_1009a6c0 + 0x100997dc /* snapshot -> 0x100b19f9 "()I" */);
                            uVar7 = FUN_1009d250(pfVar20,pfVar22,uVar7);
                          }
                        }
                        pfVar20 = local_2bb8;
                        uVar28 = in_fpscr & 0xfffffff;
                        in_fpscr = uVar28 | (uint)(fVar32 < 0.0) << 0x1f;
                        fVar33 = (float)VectorSignedToFloat(uVar7,(byte)(in_fpscr >> 0x15) & 3);
                        fVar44 = DAT_100998d0;
                        fVar34 = DAT_100998d4;
                        fVar49 = DAT_100998d8;
                        if (!SUB41(in_fpscr >> 0x1f,0)) {
                          fVar35 = fVar48 + fVar39;
                          uVar28 = uVar28 | (uint)(fVar35 < fVar33) << 0x1f |
                                   (uint)(fVar35 == fVar33) << 0x1e;
                          in_fpscr = uVar28 | (uint)(NAN(fVar35) || NAN(fVar33)) << 0x1c;
                          bVar5 = (byte)(uVar28 >> 0x18);
                          if ((bool)(bVar5 >> 6 & 1) || bVar5 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1)
                             ) {
                            uVar7 = 0;
                            fVar31 = fVar31 * DAT_10099bb8;
                            fVar44 = fVar31 + fVar32;
                            if (local_2bb8 != (float *)0x0) {
                              if (local_2bb4 != (float *)0x0) {
                                pfVar22 = local_2bb0;
                              }
                              if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar22);
                                uVar7 = (**(code **)((int)*pfVar20 + 0x84))
                                                  (pfVar20,uVar7,DAT_1009a6c4 + 0x10099878 /* snapshot -> 0x100b19fd "getHeight" */,
                                                   DAT_1009a6c8 + 0x1009987c /* snapshot -> 0x100b19f9 "()I" */);
                                uVar7 = FUN_1009d250(pfVar20,pfVar22,uVar7);
                              }
                            }
                            fVar34 = (float)VectorSignedToFloat(uVar7,(byte)(in_fpscr >> 0x15) & 3);
                            uVar28 = in_fpscr & 0xfffffff | (uint)(fVar44 < fVar34) << 0x1f |
                                     (uint)(fVar44 == fVar34) << 0x1e;
                            in_fpscr = uVar28 | (uint)(NAN(fVar44) || NAN(fVar34)) << 0x1c;
                            bVar5 = (byte)(uVar28 >> 0x18);
                            fVar44 = DAT_100998d0;
                            fVar34 = DAT_100998d4;
                            fVar49 = DAT_100998d8;
                            if ((bool)(bVar5 >> 6 & 1) ||
                                bVar5 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1)) {
                              __aeabi_memcpy8(&local_2a50,&local_2b60,0x80);
                              pfVar22 = (float *)((uint)pfVar24 & 1);
                              local_2ba6 = local_2ba2;
                              local_2ba8 = local_2ba4;
                              local_2a58 = (float)local_2b98;
                              local_2a60 = local_2ba0;
                              fVar44 = DAT_10099c2c;
                              fVar34 = DAT_10099c30;
                              fVar49 = DAT_10099c30;
                              fVar33 = DAT_10099c2c;
                              if ((bVar3 & 1) == 0) {
                                fVar33 = *(float *)(DAT_1009a8d4 + 0x1009993c /* snapshot -> 0x100e3a70 */);
                                fVar34 = *(float *)(DAT_1009a8d4 + 0x10099940 /* snapshot -> 0x100e3a74 */);
                                fVar49 = *(float *)(DAT_1009a8d4 + 0x10099944 /* snapshot -> 0x100e3a78 */);
                                fVar44 = *(float *)(DAT_1009a8d4 + 0x10099948 /* snapshot -> 0x100e3a7c */);
                              }
                              fVar35 = fVar48 * 0.5 + fVar39;
                              if (local_2bc0 == local_2bbc) {
                                iVar9 = (int)local_2bc0 - (int)local_2bd4;
                                iVar1 = iVar9 >> 3;
                                uVar28 = iVar1 * 0x4f72c235 + 1;
                                if (0x11a7b96 < uVar28) {
                    /* WARNING: Subroutine does not return */
                                  abort();
                                }
                                iVar10 = (int)local_2bbc - (int)local_2bd4 >> 3;
                                uVar30 = 0x11a7b96;
                                if ((uint)(iVar10 * 0x4f72c235) < 0x8d3dcb) {
                                  if (uVar28 <= (uint)(iVar10 * -0x611a7b96)) {
                                    uVar28 = iVar10 * -0x611a7b96;
                                  }
                                  uVar30 = uVar28;
                                  if (uVar28 != 0) goto LAB_10099a84;
                                  uVar30 = 0;
                                  iVar10 = 0;
                                }
                                else {
LAB_10099a84:
                                  iVar10 = thunk_FUN_1009e084(uVar30 * 0xe8);
                                }
                                local_2bc0 = (float *)(iVar1 * 8 + iVar10);
                                *local_2bc0 = fVar38;
                                local_2bc0[1] = fVar42;
                                local_2bc0[2] = fVar41;
                                local_2bc0[3] = fVar37;
                                local_2bc0[4] = fVar50;
                                local_2bc0[5] = fVar47;
                                local_2bc0[6] = fVar45;
                                __aeabi_memcpy4(local_2bc0 + 7,&local_2a50,0x80);
                                *(byte *)(local_2bc0 + 0x27) = bVar3;
                                *(undefined2 *)((int)local_2bc0 + 0x9d) = local_2ba8;
                                *(byte *)((int)local_2bc0 + 0x9f) = local_2ba6;
                                local_2bc0[0x28] = fVar43;
                                local_2bbc = (float *)(uVar30 * 0xe8 + iVar10);
                                local_2bc0[0x2b] = local_2a58;
                                *(byte *)(local_2bc0 + 0x33) = (byte)pfVar22;
                                local_2bc0[0x2c] = fVar39;
                                local_2bc0[0x2d] = fVar32;
                                local_2bc0[0x2e] = fVar48;
                                local_2bc0[0x2f] = fVar31;
                                local_2bc0[0x30] = fVar35;
                                local_2bc0[0x31] = fVar32;
                                local_2bc0[0x32] = fVar31;
                                *(undefined8 *)(local_2bc0 + 0x29) = local_2a60;
                                *(undefined2 *)((int)local_2bc0 + 0xcd) = local_2bab;
                                *(byte *)((int)local_2bc0 + 0xcf) = local_2ba9;
                                pfVar22 = (float *)((int)local_2bc0 - iVar9);
                                local_2bc0[0x34] = fVar46;
                                local_2bc0[0x35] = fVar33;
                                local_2bc0[0x36] = fVar34;
                                local_2bc0[0x37] = fVar49;
                                local_2bc0[0x38] = fVar44;
                                if (0 < iVar9) {
                                  __aeabi_memcpy(pfVar22,local_2bd4);
                                }
                                fVar49 = DAT_100998d8;
                                fVar34 = DAT_100998d4;
                                fVar44 = DAT_100998d0;
                                local_2bc0 = local_2bc0 + 0x3a;
                                pfVar24 = local_2bd4;
                                pfVar17 = pfVar22;
                                if (local_2bd4 != (float *)0x0) {
                                  thunk_FUN_1009e100(local_2bd4);
                                }
                              }
                              else {
                                *local_2bc0 = fVar38;
                                local_2bc0[1] = fVar42;
                                local_2bc0[2] = fVar41;
                                local_2bc0[3] = fVar37;
                                local_2bc0[4] = fVar50;
                                local_2bc0[5] = fVar47;
                                local_2bc0[6] = fVar45;
                                __aeabi_memcpy4(local_2bc0 + 7,&local_2a50,0x80);
                                *(byte *)(local_2bc0 + 0x27) = bVar3;
                                *(undefined2 *)((int)local_2bc0 + 0x9d) = local_2ba8;
                                *(byte *)((int)local_2bc0 + 0x9f) = local_2ba6;
                                local_2bc0[0x28] = fVar43;
                                local_2bc0[0x2b] = local_2a58;
                                *(byte *)(local_2bc0 + 0x33) = (byte)pfVar22;
                                local_2bc0[0x2c] = fVar39;
                                local_2bc0[0x2d] = fVar32;
                                local_2bc0[0x2e] = fVar48;
                                local_2bc0[0x2f] = fVar31;
                                local_2bc0[0x30] = fVar35;
                                local_2bc0[0x31] = fVar32;
                                local_2bc0[0x32] = fVar31;
                                *(undefined8 *)(local_2bc0 + 0x29) = local_2a60;
                                *(undefined2 *)((int)local_2bc0 + 0xcd) = local_2bab;
                                *(byte *)((int)local_2bc0 + 0xcf) = local_2ba9;
                                local_2bc0[0x34] = fVar46;
                                local_2bc0[0x35] = fVar33;
                                local_2bc0[0x36] = fVar34;
                                local_2bc0[0x37] = fVar49;
                                local_2bc0[0x38] = fVar44;
                                local_2bc0 = local_2bc0 + 0x3a;
                                fVar44 = DAT_100998d0;
                                fVar34 = DAT_100998d4;
                                fVar49 = DAT_100998d8;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            local_2bd4 = pfVar17;
            iVar25 = iVar25 + 1;
            puVar26 = puVar26 + 0x16;
            unaff_s16 = fVar23;
          } while (iVar25 < local_29cc);
        }
      }
      pfVar20 = local_2bb0;
      pfVar22 = local_2bb8;
      fVar23 = DAT_1009c708;
      bVar29 = *(char *)(DAT_1009abb0 + 0x10099bf8 /* snapshot -> 0x100e3a8c */) == '\0';
      if (!bVar29) {
        in_fpscr = in_fpscr & 0xfffffff | (uint)(local_80 == 0.0) << 0x1e;
        bVar29 = SUB41(in_fpscr >> 0x1e,0);
        unaff_s16 = local_80;
      }
      if (!bVar29) {
        in_fpscr = in_fpscr & 0xfffffff | (uint)(local_7c == 0.0) << 0x1e;
        bVar29 = SUB41(in_fpscr >> 0x1e,0);
        if (!bVar29) {
          bVar29 = local_2bd4 == local_2bc0;
        }
        if (!bVar29) {
          pfVar12 = (float *)0x0;
          pfVar17 = local_2bd4;
          fVar27 = DAT_1009c618;
          do {
            if (*(byte *)(pfVar17 + 0x33) == 0) {
              fVar44 = pfVar17[0x28];
              uVar28 = in_fpscr & 0xfffffff | (uint)(fVar44 < 0.0) << 0x1f |
                       (uint)(fVar44 == 0.0) << 0x1e;
              in_fpscr = uVar28 | (uint)NAN(fVar44) << 0x1c;
              bVar3 = (byte)(uVar28 >> 0x18);
              if ((!(bool)(bVar3 >> 6 & 1) && bVar3 >> 7 == ((byte)(in_fpscr >> 0x1c) & 1)) &&
                  fVar44 < fVar27) {
                pfVar12 = pfVar17;
                fVar27 = fVar44;
              }
            }
            pfVar17 = pfVar17 + 0x3a;
          } while (local_2bc0 != pfVar17);
          if (pfVar12 != (float *)0x0) {
            fVar27 = fVar23;
            if (local_2bb8 == (float *)0x0) {
              pfVar22 = (float *)0x0;
            }
            else if (local_2bb4 != (float *)0x0) {
              if (local_2bb0 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb0);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c918 + 0x1009c3d8 /* snapshot -> 0x100b19f0 "getWidth" */,DAT_1009c91c + 0x1009c3dc /* snapshot -> 0x100b19f9 "()I" */
                                  );
                FUN_1009d250(pfVar22,pfVar20,uVar7);
                unaff_s16 = local_80;
              }
              pfVar17 = local_2bb0;
              pfVar22 = local_2bb8;
              pfVar24 = pfVar20;
              if (((local_2bb8 != (float *)0x0) && (local_2bb4 != (float *)0x0)) &&
                 (pfVar24 = pfVar17, local_2bb0 != (float *)0x0)) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb0);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c920 + 0x1009c448 /* snapshot -> 0x100b19fd "getHeight" */,DAT_1009c924 + 0x1009c44c /* snapshot -> 0x100b19f9 "()I" */
                                  );
                uVar7 = FUN_1009d250(pfVar22,pfVar17,uVar7);
                fVar27 = (float)VectorSignedToFloat(uVar7,(byte)(in_fpscr >> 0x15) & 3);
                pfVar22 = local_2bb8;
              }
            }
            fVar44 = *pfVar12;
            fVar27 = fVar27 - local_7c;
            if (pfVar22 != (float *)0x0) {
              if (local_2bb4 != (float *)0x0) {
                pfVar24 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar24 != (float *)0x0) {
                uVar7 = (**(code **)((int)*pfVar22 + 0x7c))(pfVar22,pfVar24);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c928 + 0x1009c4dc /* snapshot -> 0x100b19fd "getHeight" */,DAT_1009c92c + 0x1009c4e0 /* snapshot -> 0x100b19f9 "()I" */
                                  );
                uVar7 = FUN_1009d250(pfVar22,pfVar24,uVar7);
                fVar23 = (float)VectorSignedToFloat(uVar7,(byte)(in_fpscr >> 0x15) & 3);
                pfVar22 = local_2bb8;
              }
            }
            pfVar24 = local_2bb4;
            fVar23 = fVar23 - pfVar12[1];
            fVar34 = SQRT((fVar23 - fVar27) * (fVar23 - fVar27) +
                          (fVar44 - unaff_s16) * (fVar44 - unaff_s16));
            iVar25 = (int)(DAT_1009c8fc + fVar34 * DAT_1009c8f8);
            if (iVar25 < 0xb) {
              iVar25 = 10;
            }
            fVar49 = (float)VectorSignedToFloat(iVar25,(byte)(in_fpscr >> 0x15) & 3);
            pfVar20 = (float *)0x0;
            if (((pfVar22 != (float *)0x0) && (pfVar20 = pfVar22, local_2bb4 != (float *)0x0)) &&
               (local_2bb0 != (float *)0x0)) {
              uVar7 = (**(code **)((int)*pfVar22 + 0x7c))(pfVar22,local_2bb4);
              uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                (pfVar22,uVar7,DAT_1009c930 + 0x1009c598 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c934 + 0x1009c59c /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
              FUN_1009d2ac(pfVar22,pfVar24,uVar7,local_2bb0,(int)fVar49,200,0,0,0,0x40360000,
                           (double)unaff_s16,(double)fVar27,(double)fVar44,(double)fVar23);
              pfVar20 = local_2bb8;
            }
            pfVar22 = local_2bb4;
            iVar25 = (int)(DAT_1009c904 + fVar34 * DAT_1009c900);
            if (iVar25 < 0x1f) {
              iVar25 = 0x1e;
            }
            fVar49 = (float)VectorSignedToFloat(iVar25,(byte)(in_fpscr >> 0x15) & 3);
            pfVar24 = (float *)0x0;
            if (((pfVar20 != (float *)0x0) && (pfVar24 = pfVar20, local_2bb4 != (float *)0x0)) &&
               (local_2bb0 != (float *)0x0)) {
              uVar7 = (**(code **)((int)*pfVar20 + 0x7c))(pfVar20,local_2bb4);
              uVar7 = (**(code **)((int)*pfVar20 + 0x84))
                                (pfVar20,uVar7,DAT_1009c938 + 0x1009c694 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c93c + 0x1009c698 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
              FUN_1009d2ac(pfVar20,pfVar22,uVar7,local_2bb0,(int)fVar49,0xdc,0x14,0x28,0,0x40280000,
                           (double)unaff_s16,(double)fVar27,(double)fVar44,(double)fVar23);
              pfVar24 = local_2bb8;
            }
            pfVar20 = local_2bb4;
            pfVar22 = (float *)(int)(DAT_1009c90c + fVar34 * DAT_1009c908);
            if ((int)pfVar22 < 0x33) {
              pfVar22 = (float *)0x32;
            }
            fVar49 = (float)VectorSignedToFloat(pfVar22,(byte)(in_fpscr >> 0x15) & 3);
            if (pfVar24 == (float *)0x0) {
              pfVar24 = (float *)0x0;
            }
            else {
              if (local_2bb4 != (float *)0x0) {
                pfVar22 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                uVar7 = (**(code **)((int)*pfVar24 + 0x7c))(pfVar24,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar24 + 0x84))
                                  (pfVar24,uVar7,DAT_1009c940 + 0x1009c780 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c944 + 0x1009c784 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */
                                  );
                FUN_1009d2ac(pfVar24,pfVar20,uVar7,local_2bb0,(int)fVar49,0xff,0x28,0x3c,0,
                             0x40180000,(double)unaff_s16,(double)fVar27,(double)fVar44,
                             (double)fVar23);
                pfVar24 = local_2bb8;
              }
            }
            pfVar20 = local_2bb4;
            pfVar22 = (float *)(int)(DAT_1009c914 + fVar34 * DAT_1009c910);
            if ((int)pfVar22 < 0x79) {
              pfVar22 = (float *)0x78;
            }
            fVar34 = (float)VectorSignedToFloat(pfVar22,(byte)(in_fpscr >> 0x15) & 3);
            if (pfVar24 != (float *)0x0) {
              if (local_2bb4 != (float *)0x0) {
                pfVar22 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                uVar7 = (**(code **)((int)*pfVar24 + 0x7c))(pfVar24,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar24 + 0x84))
                                  (pfVar24,uVar7,DAT_1009c948 + 0x1009c870 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c94c + 0x1009c874 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */
                                  );
                FUN_1009d2ac(pfVar24,pfVar20,uVar7,local_2bb0,(int)fVar34,0xff,0x78,0x8c,0,
                             0x40000000,(double)unaff_s16,(double)fVar27,(double)fVar44,
                             (double)fVar23);
              }
            }
          }
        }
      }
      if (local_2bd4 != local_2bc0) {
        pfVar22 = local_2bc0;
        pfVar24 = local_2bd4;
        do {
          pfVar12 = local_2bb4;
          pfVar17 = local_2bb8;
          fVar34 = pfVar24[0x2d];
          pfVar20 = (float *)pfVar24[0x35];
          fVar23 = pfVar24[0x36];
          fVar27 = pfVar24[0x37];
          fVar44 = pfVar24[0x38];
          fVar49 = pfVar24[0x34];
          pfVar11 = (float *)(uint)*(byte *)(pfVar24 + 0x33);
          if (local_2bb8 != (float *)0x0) {
            pfVar15 = pfVar11;
            if (local_2bb4 != (float *)0x0) {
              pfVar15 = local_2bb0;
            }
            pfVar22 = pfVar12;
            if (local_2bb4 != (float *)0x0 && pfVar15 != (float *)0x0) {
              fVar37 = pfVar24[0x2c];
              fVar38 = pfVar24[0x2e];
              fVar41 = pfVar24[0x2f];
              uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
              uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                (pfVar17,uVar7,DAT_1009ac5c + 0x10099ce0 /* snapshot -> 0x100b1a36 "DrawFilledRect" */,DAT_1009ac60 + 0x10099ce4 /* snapshot -> 0x100b1a45 "(Landroid/graphics/Canvas;IIIIFFFF)V" */);
              FUN_1009d2ac(pfVar17,pfVar12,uVar7,local_2bb0,0x5a,0,0,0,(double)fVar37,(double)fVar34
                           ,(double)fVar38,(double)fVar41);
            }
          }
          pfVar17 = local_2bb8;
          if (*(char *)(DAT_1009ac64 + 0x10099d51 /* snapshot -> 0x100e3a69 */) != '\0') {
            fVar34 = pfVar24[0x2c];
            fVar37 = pfVar24[0x2d];
            pfVar12 = (float *)pfVar24[0x2e];
            if (*(int *)(DAT_1009ac68 + 0x10099d94 /* snapshot -> 0x100e3a88 */) == 0) {
              FUN_1009cb34(&local_2bb8,pfVar20,fVar23,fVar27,fVar44,0x3f800000,fVar34,fVar37,pfVar12
                           ,pfVar24[0x2f],2);
            }
            else {
              if (local_2bb8 != (float *)0x0) {
                pfVar22 = local_2bb4;
              }
              if (local_2bb8 != (float *)0x0 && pfVar22 != (float *)0x0) {
                fVar38 = fVar37 + pfVar24[0x2f];
                if (local_2bb0 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar22);
                  uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                    (pfVar17,uVar7,DAT_1009ac6c + 0x10099df4 /* snapshot -> 0x100b1a07 "DrawLine" */,
                                     DAT_1009ac70 + 0x10099df8 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
                  dVar40 = (double)(fVar34 + (float)pfVar12);
                  dVar36 = (double)fVar37;
                  dVar51 = (double)fVar34;
                  FUN_1009d2ac(pfVar17,pfVar22,uVar7,local_2bb0,(int)fVar44,(int)(float)pfVar20,
                               (int)fVar23,(int)fVar27,0,0x3ff00000,dVar51,dVar36,dVar40,dVar36,
                               dVar51);
                  pfVar17 = local_2bb8;
                  if (local_2bb8 != (float *)0x0) {
                    pfVar22 = local_2bb4;
                  }
                  if (local_2bb8 == (float *)0x0 || pfVar22 == (float *)0x0) goto LAB_1009a104;
                  pfVar12 = local_2bb0;
                  if (local_2bb0 != (float *)0x0) {
                    uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar22);
                    uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                      (pfVar17,uVar7,DAT_1009aeb0 + 0x10099ec8 /* snapshot -> 0x100b1a07 "DrawLine" */,
                                       DAT_1009aeb4 + 0x10099ecc /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
                    dVar52 = (double)fVar38;
                    FUN_1009d2ac(pfVar17,pfVar22,uVar7,local_2bb0,(int)fVar44,(int)(float)pfVar20,
                                 (int)fVar23,(int)fVar27,0,0x3ff00000,dVar40,dVar36,dVar40,dVar52);
                    pfVar17 = local_2bb8;
                    if (local_2bb8 != (float *)0x0) {
                      pfVar22 = local_2bb4;
                    }
                    if (local_2bb8 == (float *)0x0 || pfVar22 == (float *)0x0) goto LAB_1009a104;
                    pfVar12 = local_2bb0;
                    if (local_2bb0 != (float *)0x0) {
                      uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar22);
                      uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                        (pfVar17,uVar7,DAT_1009af44 + 0x10099f84 /* snapshot -> 0x100b1a07 "DrawLine" */,
                                         DAT_1009af48 + 0x10099f88 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
                      pfVar12 = (float *)FUN_1009d2ac(pfVar17,pfVar22,uVar7,local_2bb0,(int)fVar44,
                                                      (int)(float)pfVar20,(int)fVar23,(int)fVar27,0,
                                                      0x3ff00000,dVar40,dVar52,dVar51,dVar52);
                      if (local_2bb8 == (float *)0x0) goto LAB_1009a104;
                    }
                  }
                }
                pfVar17 = local_2bb4;
                pfVar22 = local_2bb8;
                if (local_2bb4 != (float *)0x0) {
                  pfVar12 = local_2bb0;
                }
                if (local_2bb4 != (float *)0x0 && pfVar12 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  pfVar12 = *(float **)((int)*pfVar22 + 0x84);
                  uVar7 = (*(code *)pfVar12)(pfVar22,uVar7,DAT_1009afe4 + 0x1009a048 /* snapshot -> 0x100b1a07 "DrawLine" */,
                                             DAT_1009afe8 + 0x1009a04c /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
                  FUN_1009d2ac(pfVar22,pfVar17,uVar7,local_2bb0,(int)fVar44,(int)(float)pfVar20,
                               (int)fVar23,(int)fVar27,0,0x3ff00000,(double)fVar34,(double)fVar38,
                               (double)fVar34,(double)fVar37);
                  pfVar20 = pfVar12;
                }
              }
            }
          }
LAB_1009a104:
          __aeabi_memclr(auStack_2b5f,0xff);
          uVar28 = 0;
          local_2b60 = '\0';
          local_29ef = 0;
          uStack_29e7 = 0;
          local_29ff = 0;
          uStack_29f7 = 0;
          local_2a0f = 0;
          uStack_2a07 = 0;
          local_2a1f = 0;
          uStack_2a17 = 0;
          local_2a2f = 0;
          uStack_2a27 = 0;
          local_2a3f = 0;
          uStack_2a37 = 0;
          puVar19 = (uint *)0x6f;
          local_2a4f = 0;
          uStack_2a47 = 0;
          local_29e0 = 0;
          uStack_29df = 0;
          local_29d1 = 0;
          local_2a50 = '\0';
          pfVar22 = pfVar24 + 7;
          uVar7 = extraout_s3;
          uVar8 = extraout_s1;
          if (*(byte *)pfVar22 != 0) {
            pcVar13 = strchr((char *)pfVar22,9);
            if (pcVar13 == (char *)0x0) {
              strncpy(&local_2b60,(char *)pfVar22,0xff);
              uVar28 = 0;
              local_2a61 = 0;
              puVar19 = (uint *)extraout_r1_02;
              uVar7 = extraout_s3_03;
              uVar8 = extraout_s1_03;
            }
            else {
              __n = (int)pcVar13 - (int)pfVar22;
              if (__n - 1 < 0xff) {
                pcVar14 = strncpy(&local_2b60,(char *)pfVar22,__n);
                pcVar14[__n] = '\0';
              }
              pfVar20 = (float *)(pcVar13 + 1);
              pcVar13 = strchr((char *)pfVar20,9);
              if (pcVar13 == (char *)0x0) {
                uVar28 = atoi((char *)pfVar20);
                puVar19 = (uint *)extraout_r1_03;
                uVar7 = extraout_s3_04;
                uVar8 = extraout_s1_04;
              }
              else {
                uVar28 = 0;
                local_2ba0 = 0;
                local_2b98 = 0;
                local_2b90 = 0;
                uStack_2b88 = 0;
                puVar19 = (uint *)extraout_r1;
                uVar7 = extraout_s3_00;
                uVar8 = extraout_s1_00;
                if (((int)pcVar13 - (int)pfVar20) - 1U < 0x1f) {
                  pcVar14 = strncpy((char *)&local_2ba0,(char *)pfVar20,(int)pcVar13 - (int)pfVar20)
                  ;
                  uVar28 = atoi(pcVar14);
                  puVar19 = (uint *)extraout_r1_00;
                  uVar7 = extraout_s3_01;
                  uVar8 = extraout_s1_01;
                }
                pfVar22 = (float *)(pcVar13 + 1);
                if (*(byte *)pfVar22 != 0) {
                  strncpy(&local_2a50,(char *)pfVar22,0x7f);
                  local_29d1 = 0;
                  puVar19 = (uint *)extraout_r1_01;
                  uVar7 = extraout_s3_02;
                  uVar8 = extraout_s1_02;
                }
              }
            }
          }
          pfVar17 = local_2bb8;
          uVar54 = CONCAT44(puVar19,local_2bb0);
          if (pfVar11 == (float *)0x0) {
            cVar4 = *(char *)(DAT_1009b210 + 0x1009a290 /* snapshot -> 0x100e3a80 */);
            cVar6 = cVar4;
            if (cVar4 != '\0') {
              cVar6 = local_2b60;
            }
            if (cVar4 != '\0' && cVar6 != '\0') {
              if (local_2bb8 != (float *)0x0) {
                pfVar20 = local_2bb4;
              }
              pfVar22 = local_2bb8;
              if (local_2bb8 != (float *)0x0 && pfVar20 != (float *)0x0) {
                if (local_2bb0 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar20);
                  uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                    (pfVar17,uVar7,DAT_1009b8b0 + 0x1009a92c /* snapshot -> 0x100b1a6a "DrawTextCenter" */,
                                     DAT_1009b8b4 + 0x1009a930 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */);
                  pfVar22 = local_2bb0;
                  uVar16 = (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2b60);
                  uVar8 = 0;
                  uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff,0,0,0,0x40000000,
                                        0x3fe33333,uVar16);
                  puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                  pfVar22 = local_2bb8;
                  uVar7 = extraout_s3_06;
                  if (local_2bb8 == (float *)0x0) goto LAB_1009a29c;
                }
                pfVar20 = local_2bb4;
                pfVar17 = local_2bb8;
                pfVar22 = (float *)uVar54;
                if (local_2bb4 != (float *)0x0) {
                  pfVar22 = local_2bb0;
                }
                uVar54 = CONCAT44((int)((ulonglong)uVar54 >> 0x20),pfVar22);
                if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                    (pfVar17,uVar7,DAT_1009c954 + 0x1009b9bc /* snapshot -> 0x100b1a6a "DrawTextCenter" */,
                                     DAT_1009c958 + 0x1009b9c0 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */);
                  pfVar22 = local_2bb0;
                  uVar16 = (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2b60);
                  uVar8 = 0;
                  uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff,0,0,0,0x40000000,
                                        0x3fe33333,uVar16);
                  puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                  pfVar22 = local_2bb8;
                  uVar7 = extraout_s3_08;
                  if (local_2bb8 == (float *)0x0) goto LAB_1009a29c;
                }
                pfVar20 = local_2bb4;
                pfVar17 = local_2bb8;
                pfVar22 = (float *)uVar54;
                if (local_2bb4 != (float *)0x0) {
                  pfVar22 = local_2bb0;
                }
                uVar54 = CONCAT44((int)((ulonglong)uVar54 >> 0x20),pfVar22);
                if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                    (pfVar17,uVar7,DAT_1009c95c + 0x1009ba88 /* snapshot -> 0x100b1a6a "DrawTextCenter" */,
                                     DAT_1009c960 + 0x1009ba8c /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */);
                  pfVar22 = local_2bb0;
                  uVar8 = (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2b60);
                  uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff,0,0,0,0x40000000,
                                        0x3fe33333,uVar8);
                  puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                  pfVar22 = local_2bb8;
                  uVar7 = extraout_s3_09;
                  uVar8 = extraout_s1_06;
                  if (local_2bb8 == (float *)0x0) goto LAB_1009a29c;
                }
                pfVar20 = local_2bb4;
                pfVar17 = local_2bb8;
                pfVar22 = (float *)uVar54;
                if (local_2bb4 != (float *)0x0) {
                  pfVar22 = local_2bb0;
                }
                uVar54 = CONCAT44((int)((ulonglong)uVar54 >> 0x20),pfVar22);
                if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                    (pfVar17,uVar7,DAT_1009c964 + 0x1009bb5c /* snapshot -> 0x100b1a6a "DrawTextCenter" */,
                                     DAT_1009c968 + 0x1009bb60 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */);
                  pfVar22 = local_2bb0;
                  uVar8 = (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2b60);
                  uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff,0,0,0,0x40000000,
                                        0x3fe33333,uVar8);
                  puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                  pfVar22 = local_2bb8;
                  uVar7 = extraout_s3_10;
                  uVar8 = extraout_s1_07;
                  if (local_2bb8 == (float *)0x0) goto LAB_1009a29c;
                }
                pfVar20 = local_2bb4;
                pfVar22 = local_2bb8;
                puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                pfVar17 = (float *)uVar54;
                if (local_2bb4 != (float *)0x0) {
                  pfVar17 = local_2bb0;
                }
                if (local_2bb4 != (float *)0x0 && pfVar17 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                    (pfVar22,uVar7,DAT_1009b980 + 0x1009aa38 /* snapshot -> 0x100b1a6a "DrawTextCenter" */,
                                     DAT_1009b984 + 0x1009aa3c /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */);
                  pfVar17 = local_2bb0;
                  uVar8 = (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2b60);
                  FUN_1009d2ac(pfVar22,pfVar20,uVar7,pfVar17,0xff,0xff,0xff,0xff,0x40000000,
                               0x3fe33333,uVar8);
                  puVar19 = (uint *)extraout_r1_07;
                  uVar7 = extraout_s3_07;
                  uVar8 = extraout_s1_05;
                }
              }
            }
          }
LAB_1009a29c:
          pfVar12 = local_2bb4;
          pfVar17 = local_2bb8;
          fVar49 = fVar49 * 4.0;
          if (pfVar11 == (float *)0x0) {
            pfVar15 = (float *)(uint)*(byte *)(DAT_1009b214 + 0x1009a2bf /* snapshot -> 0x100e3a6b */);
            uVar54 = CONCAT44(puVar19,pfVar15);
            if (pfVar15 != (float *)0x0) {
              fVar44 = pfVar24[0x2d];
              fVar27 = pfVar24[0x2f];
              fVar23 = (pfVar24[0x2c] - fVar49) - fVar49;
              if (local_2bb8 != (float *)0x0) {
                if (local_2bb4 != (float *)0x0) {
                  pfVar15 = local_2bb0;
                }
                uVar54 = CONCAT44(puVar19,pfVar15);
                pfVar20 = pfVar12;
                if (local_2bb4 != (float *)0x0 && pfVar15 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                    (pfVar17,uVar7,DAT_1009b218 + 0x1009a348 /* snapshot -> 0x100b1a36 "DrawFilledRect" */,
                                     DAT_1009b21c + 0x1009a34c /* snapshot -> 0x100b1a45 "(Landroid/graphics/Canvas;IIIIFFFF)V" */);
                  uVar8 = 0;
                  uVar54 = FUN_1009d2ac(pfVar17,pfVar12,uVar7,local_2bb0,0xdc,0,0,0,
                                        (double)(fVar23 + -1.0),(double)(fVar44 + -1.0),
                                        (double)(fVar49 + 2.0),(double)(fVar27 + 2.0));
                  uVar7 = extraout_s3_05;
                }
              }
              pfVar17 = local_2bb4;
              pfVar22 = local_2bb8;
              puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
              uVar53 = FloatVectorMin(CONCAT44(uVar8,pfVar24[6] / DAT_1009a6cc),
                                      CONCAT44(uVar7,0x3f800000),2,0x20);
              uVar53 = FloatVectorMax(uVar53,CONCAT44(uVar8,DAT_1009a6d0),2,0x20);
              fVar34 = (float)uVar53;
              uVar30 = in_fpscr & 0xfffffff;
              uVar2 = uVar30 | (uint)(fVar34 < 0.5) << 0x1f | (uint)(fVar34 == 0.5) << 0x1e;
              in_fpscr = uVar2 | (uint)NAN(fVar34) << 0x1c;
              bVar3 = (byte)(uVar2 >> 0x18);
              if ((bool)(bVar3 >> 6 & 1) || bVar3 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1)) {
                uVar7 = 0xff;
                uVar30 = uVar30 | (uint)(fVar34 < DAT_1009a6d4) << 0x1f |
                         (uint)(fVar34 == DAT_1009a6d4) << 0x1e;
                in_fpscr = uVar30 | (uint)(NAN(fVar34) || NAN(DAT_1009a6d4)) << 0x1c;
                bVar3 = (byte)(uVar30 >> 0x18);
                if ((bool)(bVar3 >> 6 & 1) || bVar3 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1)) {
                  uVar8 = 0;
                }
                else {
                  uVar8 = 0xff;
                }
              }
              else {
                uVar8 = 0xff;
                uVar7 = 0;
              }
              if (local_2bb8 != (float *)0x0) {
                pfVar12 = (float *)uVar54;
                if (local_2bb4 != (float *)0x0) {
                  pfVar12 = local_2bb0;
                }
                pfVar20 = pfVar17;
                if (local_2bb4 != (float *)0x0 && pfVar12 != (float *)0x0) {
                  uVar16 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar16 = (**(code **)((int)*pfVar22 + 0x84))
                                     (pfVar22,uVar16,DAT_1009b220 + 0x1009a468 /* snapshot -> 0x100b1a36 "DrawFilledRect" */,
                                      DAT_1009b224 + 0x1009a46c /* snapshot -> 0x100b1a45 "(Landroid/graphics/Canvas;IIIIFFFF)V" */);
                  FUN_1009d2ac(pfVar22,pfVar17,uVar16,local_2bb0,0xff,uVar7,uVar8,0,(double)fVar23,
                               (double)(fVar44 + (fVar27 - fVar27 * fVar34)),(double)fVar49,
                               (double)(fVar27 * fVar34));
                  puVar19 = (uint *)extraout_r1_04;
                }
              }
            }
          }
          if ((pfVar11 == (float *)0x0) && (*(char *)(DAT_1009b228 + 0x1009a4d6 /* snapshot -> 0x100e3a6a */) != '\0')) {
            dVar36 = (double)pfVar24[0x28];
            FUN_100993b4(&local_2ba0,0x20,DAT_1009b22c + 0x1009a4fc /* snapshot -> 0x100b192a "[%.2fm]" */);
            pfVar22 = local_2bb8;
            uVar54 = CONCAT44(extraout_r1_05,local_2bb0);
            if (local_2bb8 != (float *)0x0) {
              pfVar20 = local_2bb4;
            }
            puVar19 = (uint *)extraout_r1_05;
            if (local_2bb8 != (float *)0x0 && pfVar20 != (float *)0x0) {
              if (local_2bb0 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar20);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009b5cc + 0x1009a720 /* snapshot -> 0x100b1a6a "DrawTextCenter" */,DAT_1009b5d0 + 0x1009a724 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */
                                   ,dVar36);
                pfVar17 = local_2bb0;
                (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2ba0);
                uVar54 = FUN_1009d2ac(pfVar22,pfVar20,uVar7,pfVar17,0xff);
                puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                pfVar22 = local_2bb8;
                if (local_2bb8 == (float *)0x0) goto LAB_1009a51c;
              }
              pfVar20 = local_2bb4;
              pfVar17 = local_2bb8;
              pfVar22 = (float *)uVar54;
              if (local_2bb4 != (float *)0x0) {
                pfVar22 = local_2bb0;
              }
              uVar54 = CONCAT44((int)((ulonglong)uVar54 >> 0x20),pfVar22);
              if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                  (pfVar17,uVar7,DAT_1009c0a0 + 0x1009b0b4 /* snapshot -> 0x100b1a6a "DrawTextCenter" */,DAT_1009c0a4 + 0x1009b0b8 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */
                                  );
                pfVar22 = local_2bb0;
                (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2ba0);
                uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff);
                puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                pfVar22 = local_2bb8;
                if (local_2bb8 == (float *)0x0) goto LAB_1009a51c;
              }
              pfVar20 = local_2bb4;
              pfVar17 = local_2bb8;
              pfVar22 = (float *)uVar54;
              if (local_2bb4 != (float *)0x0) {
                pfVar22 = local_2bb0;
              }
              uVar54 = CONCAT44((int)((ulonglong)uVar54 >> 0x20),pfVar22);
              if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                  (pfVar17,uVar7,DAT_1009c114 + 0x1009b17c /* snapshot -> 0x100b1a6a "DrawTextCenter" */,DAT_1009c118 + 0x1009b180 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */
                                  );
                pfVar22 = local_2bb0;
                (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2ba0);
                uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff);
                puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                pfVar22 = local_2bb8;
                if (local_2bb8 == (float *)0x0) goto LAB_1009a51c;
              }
              pfVar20 = local_2bb4;
              pfVar17 = local_2bb8;
              pfVar22 = (float *)uVar54;
              if (local_2bb4 != (float *)0x0) {
                pfVar22 = local_2bb0;
              }
              uVar54 = CONCAT44((int)((ulonglong)uVar54 >> 0x20),pfVar22);
              if (local_2bb4 != (float *)0x0 && pfVar22 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                  (pfVar17,uVar7,DAT_1009c7f4 + 0x1009b8ec /* snapshot -> 0x100b1a6a "DrawTextCenter" */,DAT_1009c7f8 + 0x1009b8f0 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */
                                  );
                pfVar22 = local_2bb0;
                (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2ba0);
                uVar54 = FUN_1009d2ac(pfVar17,pfVar20,uVar7,pfVar22,0xff);
                puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
                pfVar22 = local_2bb8;
                if (local_2bb8 == (float *)0x0) goto LAB_1009a51c;
              }
              pfVar20 = local_2bb4;
              pfVar22 = local_2bb8;
              puVar19 = (uint *)((ulonglong)uVar54 >> 0x20);
              pfVar17 = (float *)uVar54;
              if (local_2bb4 != (float *)0x0) {
                pfVar17 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar17 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009b5d4 + 0x1009a82c /* snapshot -> 0x100b1a6a "DrawTextCenter" */,DAT_1009b5d8 + 0x1009a830 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */
                                  );
                pfVar17 = local_2bb0;
                (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2ba0);
                FUN_1009d2ac(pfVar22,pfVar20,uVar7,pfVar17,0xff);
                puVar19 = (uint *)extraout_r1_06;
              }
            }
          }
LAB_1009a51c:
          pfVar12 = local_2bb4;
          pfVar17 = local_2bb8;
          if ((pfVar11 == (float *)0x0) && (*(char *)(DAT_1009b230 + 0x1009a54a /* snapshot -> 0x100e3a82 */) != '\0')) {
            if ((uVar28 < 7) && (puVar19 = (uint *)0x47, (0x47U >> (uVar28 & 0xff) & 1) != 0)) {
              pfVar22 = *(float **)(DAT_1009b8a8 + 0x1009a8b4 /* snapshot -> 0x100df2cc */ + uVar28 * 4);
            }
            else {
              pfVar22 = (float *)(DAT_1009b234 + 0x1009a568 /* snapshot -> 0x100b1aba "m4a1" */);
              if (2 < uVar28 - 0x50) {
                if ((int)uVar28 < 5) {
                  pfVar22 = (float *)(DAT_1009b238 + 0x1009a580 /* snapshot -> 0x100b1abf "usp" */);
                  if (uVar28 != 3) {
                    if (uVar28 != 4) goto LAB_1009a588;
LAB_1009a8c8:
                    pfVar22 = (float *)((int)&DAT_1009a8d4 + DAT_1009b8ac);
                  }
                }
                else {
                  if (uVar28 != 5) {
                    if (uVar28 == 0x41) goto LAB_1009a8c8;
LAB_1009a588:
                    if (2 < uVar28 - 0xb8) {
                      if (uVar28 - 7 < 0x39) {
                        puVar19 = &switchD_1009a5b0::switchdataD_1009a5b4;
                        pfVar22 = (float *)((int)&switchD_1009a5b0::switchdataD_1009a5b4 +
                                           DAT_1009b23c);
                        switch(uVar28) {
                        case 7:
                          break;
                        case 8:
                        case 0x3c:
                          goto switchD_1009a5b0_caseD_8;
                        case 9:
                          pfVar22 = (float *)(DAT_1009b5c8 + 0x1009a6a4 /* snapshot -> 0x100b1ad5 "desert-eagle" */);
                          break;
                        case 10:
                          pfVar22 = (float *)(DAT_1009c970 + 0x1009bc4c /* snapshot -> 0x100b1ae2 "g18" */);
                          break;
                        case 0xb:
                        case 0x3f:
switchD_1009a5b0_caseD_b:
                          pfVar22 = (float *)(DAT_1009c9e4 + 0x1009bc14 /* snapshot -> 0x100b1ae6 "m14" */);
                          break;
                        case 0xc:
switchD_1009a5b0_caseD_c:
                          pfVar22 = (float *)(DAT_1009c96c + 0x1009bc40 /* snapshot -> 0x100b1aea "scar" */);
                          break;
                        default:
switchD_1009a5b0_caseD_d:
                          if (uVar28 - 0xb2 < 3) goto switchD_1009a5b0_caseD_c;
                          puVar19 = &switchD_1009bc68::switchdataD_1009bc8c;
                          pfVar22 = (float *)((int)&DAT_1009bc6c + DAT_1009c974);
                          switch(uVar28) {
                          case 0xd:
                          case 0x3e:
                          case 0x7c:
                          case 0x7d:
                            break;
                          case 0xe:
                          case 0x46:
                            pfVar22 = (float *)(DAT_1009c9e8 + 0x1009be94 /* snapshot -> 0x100b1af3 "groza" */);
                            break;
                          case 0xf:
                            pfVar22 = (float *)(DAT_1009c978 + 0x1009c07c /* snapshot -> 0x100b1af9 "mp40" */);
                            break;
                          default:
                            pfVar22 = (float *)(DAT_1009c990 + 0x1009becc /* snapshot -> 0x100b1b2e "m60" */);
                            if ((uVar28 & 0xfffffffe) != 0x7a) {
                              puVar19 = &switchD_1009bee8::switchdataD_1009bf04;
                              pfVar22 = (float *)((int)&DAT_1009beec + DAT_1009c994);
                              switch(uVar28) {
                              case 0x20:
                                break;
                              case 0x21:
                                pfVar22 = (float *)(DAT_1009c998 + 0x1009c0cc /* snapshot -> 0x100b1b36 "an94" */);
                                break;
                              default:
                                if (uVar28 - 0xc1 < 3) goto switchD_1009bee8_caseD_2e;
                                uVar30 = uVar28 - 0x2f;
                                if ((uVar30 < 0x17) &&
                                   (puVar19 = (uint *)0x1, (0x400f8fU >> (uVar30 & 0xff) & 1) != 0))
                                {
                                  puVar19 = (uint *)(DAT_1009ca08 + 0x1009c1e0 /* snapshot -> 0x100df2e8 */);
                                  pfVar22 = (float *)((float *)puVar19)[uVar30];
                                }
                                else {
                                  pfVar22 = (float *)(DAT_1009c9b0 + 0x1009c168 /* snapshot -> 0x100b1baa "g36" */);
                                  if (1 < uVar28 - 0x49) {
                                    puVar19 = &switchD_1009c18c::switchdataD_1009c190;
                                    pfVar22 = (float *)((int)&switchD_1009c18c::switchdataD_1009c190
                                                       + DAT_1009c9b4);
                                    switch(uVar28) {
                                    case 0x4b:
                                      break;
                                    default:
                                      if (uVar28 - 0xe4 < 3) goto switchD_1009c18c_caseD_58;
                                      if ((int)uVar28 < 99) {
                                        pfVar22 = (float *)(DAT_1009c9c4 + 0x1009c268 /* snapshot -> 0x100b1bc3 "ac80" */);
                                        if (uVar28 != 0x59) {
                                          if (uVar28 == 0x5d) goto LAB_1009c278;
LAB_1009c298:
                                          pfVar22 = (float *)(DAT_1009c9c8 + 0x1009c2b8 /* snapshot -> 0x100b1be5 "trogon" */);
                                          if (1 < uVar28 - 0xb5) {
                                            pfVar22 = (float *)(DAT_1009c9cc + 0x1009c2d8 /* snapshot -> 0x100b1bf7 */);
                                            if (uVar28 == 0x520a) {
                                              pfVar22 = (float *)(DAT_1009c9d0 + 0x1009c2dc /* snapshot -> 0x100b1bf2 "m590" */);
                                            }
                                            if (uVar28 == 0xc5) {
                                              pfVar22 = (float *)(DAT_1009c9d4 + 0x1009c2ec /* snapshot -> 0x100b1bec "vsk94" */);
                                            }
                                          }
                                        }
                                      }
                                      else if (uVar28 == 0x5209) {
LAB_1009c278:
                                        pfVar22 = (float *)(DAT_1009ca04 + 0x1009c284 /* snapshot -> 0x100b1bc8 "heal-pistol" */);
                                      }
                                      else if (uVar28 == 0x96) {
                                        pfVar22 = (float *)((int)&DAT_1009c290 + DAT_1009c9dc);
                                      }
                                      else {
                                        if (uVar28 != 99) goto LAB_1009c298;
                                        pfVar22 = (float *)(DAT_1009c9d8 + 0x1009c24c /* snapshot -> 0x100b1bd4 "shield-gun" */);
                                      }
                                      break;
                                    case 0x4e:
                                      pfVar22 = (float *)(DAT_1009c9b8 + 0x1009c1d4 /* snapshot -> 0x100b1bb2 "healsniper" */);
                                      break;
                                    case 0x56:
                                      pfVar22 = (float *)(DAT_1009c9bc + 0x1009c21c /* snapshot -> 0x100b1b3b "chargebuster" */);
                                      break;
                                    case 0x58:
switchD_1009c18c_caseD_58:
                                      pfVar22 = (float *)(DAT_1009c9c0 + 0x1009c210 /* snapshot -> 0x100b1bbd "mac10" */);
                                    }
                                  }
                                }
                                break;
                              case 0x23:
                                pfVar22 = (float *)(DAT_1009c99c + 0x1009c0f0 /* snapshot -> 0x100b1b3b "chargebuster" */);
                                break;
                              case 0x27:
                                pfVar22 = (float *)(DAT_1009c9a0 + 0x1009c0fc /* snapshot -> 0x100b1b48 "plasma" */);
                                break;
                              case 0x29:
                              case 0x77:
                                pfVar22 = (float *)(DAT_1009ca00 + 0x1009c070 /* snapshot -> 0x100b1b4f "m1887" */);
                                break;
                              case 0x2b:
                                pfVar22 = (float *)(DAT_1009c9a4 + 0x1009c108 /* snapshot -> 0x100b1b55 "thompson" */);
                                break;
                              case 0x2d:
                                pfVar22 = (float *)((int)&DAT_1009c114 + DAT_1009c9a8);
                                break;
                              case 0x2e:
switchD_1009bee8_caseD_2e:
                                pfVar22 = (float *)(DAT_1009c9ac + 0x1009c0e4 /* snapshot -> 0x100b1b63 "aug" */);
                              }
                            }
                            break;
                          case 0x12:
                            pfVar22 = (float *)(DAT_1009c97c + 0x1009c088 /* snapshot -> 0x100b1afe "sks" */);
                            break;
                          case 0x13:
                          case 0x47:
                            pfVar22 = (float *)(DAT_1009c9ec + 0x1009bea0 /* snapshot -> 0x100b1b02 "m249" */);
                            break;
                          case 0x14:
                            pfVar22 = (float *)(DAT_1009c980 + 0x1009c094 /* snapshot -> 0x100b1b07 "m1873" */);
                            break;
                          case 0x15:
                          case 0x40:
                          case 0x80:
                          case 0x81:
                            pfVar22 = (float *)(DAT_1009c9f0 + 0x1009be74 /* snapshot -> 0x100b1b0d "kar98k" */);
                            break;
                          case 0x18:
                          case 0x43:
                          case 0x82:
                          case 0x83:
                            pfVar22 = (float *)((int)&DAT_1009be80 + DAT_1009c9f4);
                            break;
                          case 0x19:
                            pfVar22 = (float *)((int)&DAT_1009c0a0 + DAT_1009c984);
                            break;
                          case 0x1a:
                          case 0x48:
                            pfVar22 = (float *)(DAT_1009c9f8 + 0x1009beac /* snapshot -> 0x100b1b1f "svd" */);
                            break;
                          case 0x1c:
                            pfVar22 = (float *)(DAT_1009c988 + 0x1009c0b4 /* snapshot -> 0x100b1b23 "xm8" */);
                            break;
                          case 0x1d:
                            pfVar22 = (float *)(DAT_1009c98c + 0x1009c0c0 /* snapshot -> 0x100b1b27 "spas12" */);
                            break;
                          case 0x1e:
                          case 0x3d:
                            pfVar22 = (float *)(DAT_1009c9fc + 0x1009beb8 /* snapshot -> 0x100b1b2e "m60" */);
                          }
                        }
                      }
                      else {
                        if (1 < uVar28 - 0x78) {
                          if (1 < uVar28 - 0x7e) goto switchD_1009a5b0_caseD_d;
                          goto switchD_1009a5b0_caseD_b;
                        }
switchD_1009a5b0_caseD_8:
                        pfVar22 = (float *)((int)&DAT_1009bc20 + DAT_1009c9e0);
                      }
                      goto switchD_1009a5b0_caseD_7;
                    }
                  }
                  pfVar22 = (float *)(DAT_1009ba50 + 0x1009aac0 /* snapshot -> 0x100b1ac7 "m1014" */);
                }
              }
            }
switchD_1009a5b0_caseD_7:
            if (((float *)(uint)*(byte *)pfVar22 != (float *)0x0) &&
               (pfVar20 = pfVar17, local_2bb8 != (float *)0x0)) {
              pfVar11 = (float *)(uint)*(byte *)pfVar22;
              if (local_2bb4 != (float *)0x0) {
                pfVar11 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar11 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar17 + 0x84))
                                  (pfVar17,uVar7,DAT_1009bb1c + 0x1009ab44 /* snapshot -> 0x100b1bf8 "DrawWeaponIcon" */,DAT_1009bb20 + 0x1009ab48 /* snapshot -> 0x100b1c07 "(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V" */
                                  );
                pfVar11 = local_2bb0;
                uVar8 = (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,pfVar22);
                FUN_1009d2ac(pfVar17,pfVar12,uVar7,pfVar11,uVar8);
                puVar19 = (uint *)extraout_r1_08;
              }
            }
LAB_1009abc0:
            pfVar17 = local_2bb0;
            pfVar11 = local_2bb8;
            pfVar12 = (float *)(uint)*(byte *)(DAT_1009bb24 + 0x1009abd0 /* snapshot -> 0x100e3a6c */);
            if (pfVar12 != (float *)0x0) {
              pfVar20 = (float *)0x0;
              if (local_2bb8 != (float *)0x0) {
                puVar19 = (uint *)local_2bb4;
              }
              if (local_2bb8 != (float *)0x0 && (float *)puVar19 != (float *)0x0) {
                if (local_2bb0 == (float *)0x0) {
                  pfVar12 = (float *)0x0;
                }
                else {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb0);
                  uVar7 = (**(code **)((int)*pfVar11 + 0x84))
                                    (pfVar11,uVar7,DAT_1009bc20 + 0x1009ac3c /* snapshot -> 0x100b19f0 "getWidth" */,
                                     DAT_1009bc24 + 0x1009ac40 /* snapshot -> 0x100b19f9 "()I" */);
                  pfVar12 = (float *)FUN_1009d250(pfVar11,pfVar17,uVar7);
                  puVar19 = (uint *)local_2bb4;
                }
                pfVar22 = local_2bb8;
                VectorSignedToFloat(pfVar12,(byte)(in_fpscr >> 0x15) & 3);
                pfVar20 = (float *)0x0;
                if (local_2bb8 != (float *)0x0) {
                  if ((float *)puVar19 != (float *)0x0) {
                    pfVar17 = local_2bb0;
                  }
                  if ((float *)puVar19 != (float *)0x0 && pfVar17 != (float *)0x0) {
                    uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar17);
                    uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                      (pfVar22,uVar7,DAT_1009bc6c + 0x1009acd4 /* snapshot -> 0x100b19fd "getHeight" */,
                                       DAT_1009bc70 + 0x1009acd8 /* snapshot -> 0x100b19f9 "()I" */);
                    pfVar12 = (float *)FUN_1009d250(pfVar22,pfVar17,uVar7);
                    pfVar20 = pfVar12;
                  }
                }
              }
              pfVar17 = local_2bb4;
              pfVar22 = local_2bb8;
              VectorSignedToFloat(pfVar20,(byte)(in_fpscr >> 0x15) & 3);
              if (local_2bb8 != (float *)0x0) {
                if (local_2bb4 != (float *)0x0) {
                  pfVar12 = local_2bb0;
                }
                pfVar20 = pfVar17;
                if (local_2bb4 != (float *)0x0 && pfVar12 != (float *)0x0) {
                  fVar23 = *(float *)(DAT_1009bc74 + 0x1009ad40 /* snapshot -> 0x100e3a7c */);
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                  uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                    (pfVar22,uVar7,DAT_1009bc7c + 0x1009ad78 /* snapshot -> 0x100b1c3a "DrawCircle" */,
                                     DAT_1009bc80 + 0x1009ad7c /* snapshot -> 0x100b1a45 "(Landroid/graphics/Canvas;IIIIFFFF)V" */);
                  FUN_1009d2ac(pfVar22,pfVar17,uVar7,local_2bb0,(int)fVar23);
                }
              }
            }
          }
          else if (pfVar11 == (float *)0x0) goto LAB_1009abc0;
          pfVar17 = local_2bb0;
          pfVar12 = local_2bb8;
          if (*(char *)(DAT_1009bc84 + 0x1009ade8 /* snapshot -> 0x100e3a68 */) != '\0') {
            pfVar11 = *(float **)(DAT_1009bc88 + 0x1009ae18 /* snapshot -> 0x100e3a84 */);
            if (pfVar11 == (float *)0x0) {
              pfVar11 = (float *)0x0;
              if (local_2bb8 != (float *)0x0) {
                if (local_2bb4 != (float *)0x0) {
                  pfVar20 = local_2bb0;
                }
                if (local_2bb4 != (float *)0x0 && pfVar20 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar20);
                  uVar7 = (**(code **)((int)*pfVar12 + 0x84))
                                    (pfVar12,uVar7,DAT_1009bef4 + 0x1009afa4 /* snapshot -> 0x100b19f0 "getWidth" */,
                                     DAT_1009bef8 + 0x1009afa8 /* snapshot -> 0x100b19f9 "()I" */);
                  pfVar11 = (float *)FUN_1009d250(pfVar12,pfVar20,uVar7);
                }
              }
              VectorSignedToFloat(pfVar11,(byte)(in_fpscr >> 0x15) & 3);
            }
            else {
              pfVar20 = local_2bb8;
              if (pfVar11 == (float *)0x1) {
                pfVar22 = (float *)0x0;
                if ((local_2bb8 != (float *)0x0) && (local_2bb4 != (float *)0x0)) {
                  if (local_2bb0 == (float *)0x0) {
                    pfVar11 = (float *)0x0;
                  }
                  else {
                    uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb0);
                    uVar7 = (**(code **)((int)*pfVar12 + 0x84))
                                      (pfVar12,uVar7,DAT_1009beec + 0x1009af24 /* snapshot -> 0x100b19f0 "getWidth" */,
                                       DAT_1009bef0 + 0x1009af28 /* snapshot -> 0x100b19f9 "()I" */);
                    pfVar11 = (float *)FUN_1009d250(pfVar12,pfVar17,uVar7);
                  }
                  pfVar20 = local_2bb8;
                  VectorSignedToFloat(pfVar11,(byte)(in_fpscr >> 0x15) & 3);
                  pfVar22 = (float *)0x0;
                  if (local_2bb8 != (float *)0x0) {
                    if (local_2bb4 != (float *)0x0) {
                      pfVar17 = local_2bb0;
                    }
                    if (local_2bb4 != (float *)0x0 && pfVar17 != (float *)0x0) {
                      uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar17);
                      uVar7 = (**(code **)((int)*pfVar20 + 0x84))
                                        (pfVar20,uVar7,DAT_1009c290 + 0x1009b2a0 /* snapshot -> 0x100b19fd "getHeight" */,
                                         DAT_1009c294 + 0x1009b2a4 /* snapshot -> 0x100b19f9 "()I" */);
                      pfVar11 = (float *)FUN_1009d250(pfVar20,pfVar17,uVar7);
                      pfVar22 = pfVar11;
                    }
                  }
                }
                VectorSignedToFloat(pfVar22,(byte)(in_fpscr >> 0x15) & 3);
              }
              else {
                if (pfVar11 == (float *)0x2) {
                  in_fpscr = in_fpscr & 0xfffffff;
                }
                pfVar22 = (float *)0x0;
                if ((local_2bb8 != (float *)0x0) && (local_2bb4 != (float *)0x0)) {
                  if (local_2bb0 == (float *)0x0) {
                    pfVar11 = (float *)0x0;
                  }
                  else {
                    uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb0);
                    uVar7 = (**(code **)((int)*pfVar12 + 0x84))
                                      (pfVar12,uVar7,DAT_1009be80 + 0x1009ae90 /* snapshot -> 0x100b19f0 "getWidth" */,
                                       DAT_1009be84 + 0x1009ae94 /* snapshot -> 0x100b19f9 "()I" */);
                    pfVar11 = (float *)FUN_1009d250(pfVar12,pfVar17,uVar7);
                  }
                  pfVar20 = local_2bb8;
                  VectorSignedToFloat(pfVar11,(byte)(in_fpscr >> 0x15) & 3);
                  pfVar22 = (float *)0x0;
                  if (local_2bb8 != (float *)0x0) {
                    if (local_2bb4 != (float *)0x0) {
                      pfVar17 = local_2bb0;
                    }
                    if (local_2bb4 != (float *)0x0 && pfVar17 != (float *)0x0) {
                      uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar17);
                      uVar7 = (**(code **)((int)*pfVar20 + 0x84))
                                        (pfVar20,uVar7,DAT_1009befc + 0x1009b050 /* snapshot -> 0x100b19fd "getHeight" */,
                                         DAT_1009bf00 + 0x1009b054 /* snapshot -> 0x100b19f9 "()I" */);
                      pfVar11 = (float *)FUN_1009d250(pfVar20,pfVar17,uVar7);
                      pfVar22 = pfVar11;
                    }
                  }
                }
                VectorSignedToFloat(pfVar22,(byte)(in_fpscr >> 0x15) & 3);
              }
            }
            pfVar17 = local_2bb4;
            pfVar22 = local_2bb8;
            if (local_2bb8 != (float *)0x0) {
              if (local_2bb4 != (float *)0x0) {
                pfVar11 = local_2bb0;
              }
              pfVar20 = pfVar17;
              if (local_2bb4 != (float *)0x0 && pfVar11 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c300 + 0x1009b320 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c304 + 0x1009b324 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */
                                  );
                FUN_1009d2ac(pfVar22,pfVar17,uVar7,local_2bb0,0xff);
              }
            }
          }
          if ((*(char *)(DAT_1009c354 + 0x1009b3b1 /* snapshot -> 0x100e3a8d */) != '\0') &&
             (((uVar28 == 0x21 || (uVar28 - 300 < 0x10)) ||
              ((local_2a50 != '\0' &&
               (((((pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c358 + 0x1009b3c4 /* snapshot -> 0x100b1932 "Grenade" */)),
                   pcVar13 != (char *)0x0 ||
                   (pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c35c + 0x1009b3dc /* snapshot -> 0x100b193a "grenade" */)),
                   pcVar13 != (char *)0x0)) ||
                  (pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c360 + 0x1009b3f4 /* snapshot -> 0x100b1942 "Gloo" */)),
                  pcVar13 != (char *)0x0)) ||
                 ((pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c364 + 0x1009b40c /* snapshot -> 0x100b1947 "gloo" */)),
                  pcVar13 != (char *)0x0 ||
                  (pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c368 + 0x1009b424 /* snapshot -> 0x100b194c "Flash" */)),
                  pcVar13 != (char *)0x0)))) ||
                ((pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c36c + 0x1009b43c /* snapshot -> 0x100b1952 "flash" */)),
                 pcVar13 != (char *)0x0 ||
                 ((pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c370 + 0x1009b454 /* snapshot -> 0x100b1958 "Smoke" */)),
                  pcVar13 != (char *)0x0 ||
                  (pcVar13 = strstr(&local_2a50,(char *)(DAT_1009c374 + 0x1009b46c /* snapshot -> 0x100b195e "smoke" */)),
                  pcVar13 != (char *)0x0)))))))))))) {
            pfVar22 = local_2bb8;
            in_fpscr = in_fpscr & 0xfffffff;
            if (local_2bb8 != (float *)0x0) {
              pfVar20 = local_2bb4;
            }
            if (local_2bb8 != (float *)0x0 && pfVar20 != (float *)0x0) {
              pfVar17 = local_2bb0;
              if (local_2bb0 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar20);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c608 + 0x1009b634 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c60c + 0x1009b638 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */
                                  );
                FUN_1009d2ac(pfVar22,pfVar20,uVar7,local_2bb0,0xff);
                pfVar22 = local_2bb8;
                if (local_2bb8 != (float *)0x0) {
                  pfVar20 = local_2bb4;
                }
                if (local_2bb8 == (float *)0x0 || pfVar20 == (float *)0x0) goto LAB_1009b4bc;
                pfVar17 = local_2bb0;
                if (local_2bb0 != (float *)0x0) {
                  uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar20);
                  uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                    (pfVar22,uVar7,DAT_1009c610 + 0x1009b6ec /* snapshot -> 0x100b1a07 "DrawLine" */,
                                     DAT_1009c614 + 0x1009b6f0 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
                  FUN_1009d2ac(pfVar22,pfVar20,uVar7,local_2bb0,0xff);
                  pfVar22 = local_2bb8;
                  if (local_2bb8 != (float *)0x0) {
                    pfVar20 = local_2bb4;
                  }
                  if (local_2bb8 == (float *)0x0 || pfVar20 == (float *)0x0) goto LAB_1009b4bc;
                  pfVar17 = local_2bb0;
                  if (local_2bb0 != (float *)0x0) {
                    uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,pfVar20);
                    uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                      (pfVar22,uVar7,DAT_1009c700 + 0x1009b798 /* snapshot -> 0x100b1a07 "DrawLine" */,
                                       DAT_1009c704 + 0x1009b79c /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */);
                    pfVar17 = (float *)FUN_1009d2ac(pfVar22,pfVar20,uVar7,local_2bb0,0xff);
                    if (local_2bb8 == (float *)0x0) goto LAB_1009b4bc;
                  }
                }
              }
              pfVar20 = local_2bb4;
              pfVar22 = local_2bb8;
              if (local_2bb4 != (float *)0x0) {
                pfVar17 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar17 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c7ec + 0x1009b840 /* snapshot -> 0x100b1a07 "DrawLine" */,DAT_1009c7f0 + 0x1009b844 /* snapshot -> 0x100b1a10 "(Landroid/graphics/Canvas;IIIIFFFFF)V" */
                                  );
                FUN_1009d2ac(pfVar22,pfVar20,uVar7,local_2bb0,0xff);
              }
            }
LAB_1009b4bc:
            pfVar20 = (float *)FUN_100993b4(&local_2ba0,0x40,DAT_1009c470 + 0x1009b4d8 /* snapshot -> 0x100b1964 "GRENADE %dm" */,
                                            (int)pfVar24[0x28]);
            pfVar17 = local_2bb4;
            pfVar22 = local_2bb8;
            if (local_2bb8 != (float *)0x0) {
              if (local_2bb4 != (float *)0x0) {
                pfVar20 = local_2bb0;
              }
              if (local_2bb4 != (float *)0x0 && pfVar20 != (float *)0x0) {
                uVar7 = (**(code **)((int)*local_2bb8 + 0x7c))(local_2bb8,local_2bb4);
                uVar7 = (**(code **)((int)*pfVar22 + 0x84))
                                  (pfVar22,uVar7,DAT_1009c474 + 0x1009b540 /* snapshot -> 0x100b1a6a "DrawTextCenter" */,DAT_1009c478 + 0x1009b544 /* snapshot -> 0x100b1a79 "(Landroid/graphics/Canvas;IIIIFLjava/lang/String;FFF)V" */
                                  );
                pfVar20 = local_2bb0;
                (**(code **)((int)*local_2bb8 + 0x29c))(local_2bb8,&local_2ba0);
                FUN_1009d2ac(pfVar22,pfVar17,uVar7,pfVar20,0xff);
              }
            }
          }
          pfVar24 = pfVar24 + 0x3a;
        } while (local_2bc0 != pfVar24);
      }
      piVar21 = *(int **)(DAT_1009c950 + 0x1009c8ec /* snapshot -> 0x100e0c54 */);
      if (local_2bd4 != (float *)0x0) {
        thunk_FUN_1009e100();
      }
    }
  }
  if (*piVar21 == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}

