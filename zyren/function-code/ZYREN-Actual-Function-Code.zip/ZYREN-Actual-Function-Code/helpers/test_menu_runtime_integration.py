"""One real Unix-stream integration using the existing recovered Enable All handler."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import sys

from local_unix_ipc import LocalUnixIPCTransport
from test_local_unix_ipc import synthetic_server, read_exact


def main(handlers_dir):
    handlers_dir=Path(handlers_dir).resolve()
    sys.path.insert(0,str(handlers_dir))
    from runtime import MenuRuntime
    from all_buttons import BY_ID
    packets=[]
    def peer(stream):
        for _ in range(2):
            assert read_exact(stream,4)==b'\0\0\0\x20'
            packets.append(read_exact(stream,32))
            stream.sendall(struct.pack('>I',2)+b'OK')
    endpoint,finish=synthetic_server(peer)
    with LocalUnixIPCTransport(endpoint) as transport:
        assert transport.connect()
        runtime=MenuRuntime(transport)
        BY_ID[102](runtime,1)
        assert runtime.read_u8(0x1010DDE0)==1
    finish()
    assert packets==[struct.pack('<IB27x',102,1),struct.pack('<IB27x',3,1)]
    report={'integration_passed':True,'handler':'Enable All / ID102',
            'observed_wire_command_ids':[struct.unpack_from('<I',p)[0] for p in packets],
            'packets_hex':[p.hex() for p in packets],
            'local_flag_address':'0x1010DDE0','local_flag_value':1,
            'runtime_sha256':hashlib.sha256((handlers_dir/'runtime.py').read_bytes()).hexdigest(),
            'enable_all_module_sha256':hashlib.sha256((handlers_dir/'buttons/button_01_enable_all.py').read_bytes()).hexdigest(),
            'scope':'Existing MenuRuntime and recovered handler using a synthetic host-local abstract Unix peer. No actual game/native server contacted.',
            'live_gameplay_verified':False}
    (Path(__file__).parent/'menu-runtime-integration.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--handlers-dir',type=Path,required=True,
                        help='Directory containing the earlier runtime.py, all_buttons.py and buttons/')
    main(parser.parse_args().handlers_dir)
