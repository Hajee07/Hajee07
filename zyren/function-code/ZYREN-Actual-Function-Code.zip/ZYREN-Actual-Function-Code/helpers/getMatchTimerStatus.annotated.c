/* Decompiled C-like pseudocode from an emulated unpacked memory image.
 * This is NOT original C/C++ source and is NOT independently buildable.
 * Types, signatures and names can be inferred or incomplete.
 * Android/game behavior has not been tested.
 */


void Java_com_NovaX_Menu_getMatchTimerStatus(int *param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 local_24;
  undefined4 local_20;
  int local_1c;
  
  piVar2 = *(int **)(DAT_1008ce50 + 0x1008cdd8 /* snapshot -> 0x100e0c54 */);
  local_1c = *piVar2;
  iVar1 = (**(code **)(*param_1 + 0x2cc))(param_1,2);
  if (iVar1 != 0) {
    local_24 = *(undefined4 *)(DAT_1008ce54 + 0x1008ce10 /* snapshot -> 0x100e3a60 */);
    local_20 = *(undefined4 *)(DAT_1008ce58 + 0x1008ce1c /* snapshot -> 0x100e1000 */);
    (**(code **)(*param_1 + 0x34c))(param_1,iVar1,0,2,&local_24);
  }
  iVar1 = *piVar2 - local_1c;
  if (iVar1 != 0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(iVar1);
  }
  return;
}

