"""Known byte-vector checks of the recovered wrapper translations."""
from pathlib import Path
import json
import struct
from get_enemy_list import getEnemyList, getEnemyListRaw, decode_modified_utf8
from get_match_timer_status import getMatchTimerStatus, update_timer_status_from_response
from lock_player import LockPlayer


def main():
    checks = []
    response = bytearray(0x2960)
    def fetch(width, height):
        assert (width, height) == (1920, 1080)
        return bytes(response)
    assert getEnemyList(fetch) is None
    checks.append('zero status returns None')
    response[0] = 1
    assert getEnemyList(fetch) is None
    checks.append('zero count returns None')
    struct.pack_into('<I',response,4,2)
    response[0x24:0x24+6] = b'Alpha\0'
    response[0x24+0xB0:0x24+0xB0+5] = b'Beta\0'
    struct.pack_into('<Q',response,0xB0,0xFFFFFFFFFFFFFFFF)
    struct.pack_into('<Q',response,0xB0*2,42)
    assert getEnemyList(fetch) == ['Alpha','18446744073709551615','Beta','42']
    checks.append('exact name offsets, 176-byte stride and uint64 ID formatting')
    assert getEnemyListRaw(bytes(response)) == [b'Alpha',b'18446744073709551615',b'Beta',b'42']
    checks.append('pre-JNI raw formatting')
    assert decode_modified_utf8(b'A\xC0\x80B') == 'A\0B'
    assert decode_modified_utf8(b'\xED\xA0\xBD\xED\xB8\x80') == '\U0001F600'
    checks.append('valid modified UTF-8 NUL and surrogate-pair decoding')
    struct.pack_into('<I',response,4,61)
    try:getEnemyListRaw(bytes(response))
    except ValueError:pass
    else:raise AssertionError('Bound check missing')
    checks.append('explicit Python record bound')
    memory = {0x100E3A60:struct.pack('<i',-3),0x100E1000:struct.pack('<i',123)}
    assert getMatchTimerStatus(lambda address,size:memory[address]) == [-3,123]
    checks.append('timer status is two signed integers, not float/countdown')
    trailer=bytearray(0x2960);struct.pack_into('<ii',trailer,0x2948,-7,55)
    update_timer_status_from_response(trailer,lambda address,value:memory.__setitem__(address,value))
    assert getMatchTimerStatus(lambda address,size:memory[address]) == [-7,55]
    checks.append('OnDrawLoad timer trailer assignments at offsets0x2948/0x294C')
    class Transport:
        def __init__(self,ok=True):self.events=[];self.ok=ok
        def send(self,channel,payload):self.events.append(('send',channel,payload));return self.ok
        def receive(self,channel,max_bytes):self.events.append(('receive',channel,max_bytes));return b''
    t=Transport();LockPlayer(0x1122334455667788,t)
    assert t.events[0] == ('send',0x100E1020,b'\x0D\x02\x00\x00'+b'\0'*20+bytes.fromhex('8877665544332211'))
    assert t.events[1] == ('receive',0x100E1020,0x2960)
    checks.append('LockPlayer exact command525, 32-byte payload, target offset24 and reply')
    t=Transport(False);LockPlayer(-1,t)
    assert len(t.events)==1 and t.events[0][2][24:]==b'\xFF'*8
    checks.append('JNI long two-complement bits; failed send skips reply')
    result={'checks_passed':len(checks),'checks':checks,'live_game_verified':False,
            'scope':'Crafted byte vectors; wrappers consume supplied responses/state and do not recover game-side implementations.'}
    (Path(__file__).parent/'helper-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':main()
