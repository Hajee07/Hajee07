/* Decompiled C-like pseudocode from an emulated unpacked memory image.
 * This is NOT original C/C++ source and is NOT independently buildable.
 * Types, signatures and names can be inferred or incomplete.
 * Android/game behavior has not been tested.
 */


void Java_com_NovaX_Menu_getEnemyList(int *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined auStack_2ad0 [64];
  undefined auStack_2a90 [256];
  byte local_2990 [4];
  uint local_298c;
  undefined4 local_28e0 [2605];
  int local_2c;
  
  piVar8 = *(int **)(DAT_100993a0 + 0x1009924c /* snapshot -> 0x100e0c54 */);
  local_2c = *piVar8;
  FUN_1008c0a0(local_2990,0x780,0x438);
  uVar2 = (uint)local_2990[0];
  uVar1 = uVar2;
  if (uVar2 != 0) {
    uVar1 = local_298c;
  }
  if (uVar2 != 0 && uVar1 != 0) {
    uVar3 = (**(code **)(*param_1 + 0x18))(param_1,DAT_100993a4 + 0x100992a0 /* snapshot -> 0x100b1911 "java/lang/String" */);
    iVar7 = 0;
    uVar3 = (**(code **)(*param_1 + 0x2b0))(param_1,local_298c << 1,uVar3,0);
    if (0 < (int)local_298c) {
      puVar9 = local_28e0;
      iVar10 = 0;
      do {
        FUN_100993b4(auStack_2a90,0x100,DAT_100993a8 + 0x100992fc /* snapshot -> 0x100b1922 "%s" */,puVar9 + -0x23);
        uVar4 = (**(code **)(*param_1 + 0x29c))(param_1,auStack_2a90);
        (**(code **)(*param_1 + 0x2b8))(param_1,uVar3,iVar7,uVar4);
        uVar4 = *puVar9;
        uVar6 = puVar9[1];
        FUN_100993b4(auStack_2ad0,0x40,DAT_100993ac + 0x1009934c /* snapshot -> 0x100b1925 "%llu" */);
        uVar5 = (**(code **)(*param_1 + 0x29c))(param_1,auStack_2ad0);
        (**(code **)(*param_1 + 0x2b8))(param_1,uVar3,iVar7 + 1,uVar5,uVar4,uVar6);
        iVar10 = iVar10 + 1;
        iVar7 = iVar7 + 2;
        puVar9 = puVar9 + 0x2c;
      } while (iVar10 < (int)local_298c);
      piVar8 = *(int **)((int)&DAT_100993a0 + DAT_100993b0);
    }
  }
  if (*piVar8 - local_2c != 0) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(*piVar8 - local_2c);
  }
  return;
}

