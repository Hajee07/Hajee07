"""Synthetic host-local AF_UNIX tests; no real game/server is contacted."""
from pathlib import Path
import json
import queue
import socket
import struct
import threading
import uuid

from local_unix_ipc import (LocalUnixIPCTransport, NATIVE_ENDPOINT, SNAPSHOT_CHANNEL,
                            INITIALIZE_PAYLOAD, MAX_REPLY_BYTES, IPCProtocolError,
                            IPCConnectionClosed)
from lock_player import LockPlayer


def read_exact(stream, count):
    output=bytearray()
    while len(output)<count:
        block=stream.recv(count-len(output))
        if not block:raise AssertionError('Synthetic peer closed prematurely')
        output.extend(block)
    return bytes(output)


class ChunkedSocket:
    """Wrap an actual connected Unix socket to force one-byte client reads."""
    def __init__(self,stream):self.stream=stream;self.reads=0
    def recv(self,count):self.reads+=1;return self.stream.recv(min(count,1))
    def __getattr__(self,name):return getattr(self.stream,name)


def synthetic_server(handler):
    endpoint=(b'\0ZYREN_TEST_'+uuid.uuid4().hex.encode()).ljust(108,b'\0')
    listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    listener.settimeout(3);listener.bind(endpoint);listener.listen(1)
    failures=queue.Queue()
    def run():
        try:
            connection,_=listener.accept()
            with connection:
                connection.settimeout(3);handler(connection)
        except Exception as error:failures.put(error)
        finally:listener.close()
    thread=threading.Thread(target=run,daemon=True);thread.start()
    def finish():
        thread.join(4)
        assert not thread.is_alive(),'Synthetic server did not finish'
        if not failures.empty():raise failures.get()
    return endpoint,finish


def main():
    checks=[]
    assert len(NATIVE_ENDPOINT)==108
    assert NATIVE_ENDPOINT[:10]==b'\0FHKFKLFLF'
    assert NATIVE_ENDPOINT[10:]==b'\0'*98
    assert INITIALIZE_PAYLOAD==b'\1\0\0\0\1'+b'\0'*27
    checks.append('Exact native abstract endpoint length/padding and init request bytes')

    requests=[]
    def init_peer(stream):
        length=struct.unpack('>I',read_exact(stream,4))[0]
        assert length==32;requests.append(read_exact(stream,length))
        reply=b'initialization-reply'
        for byte in struct.pack('>I',len(reply))+reply:stream.sendall(bytes([byte]))
    endpoint,finish=synthetic_server(init_peer)
    client_socket=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);client_socket.connect(endpoint)
    chunked=ChunkedSocket(client_socket)
    with LocalUnixIPCTransport(endpoint,connected_socket=chunked) as transport:
        assert transport.initialize()==b'initialization-reply'
        assert chunked.reads>=4+len(b'initialization-reply')
    finish();assert requests==[INITIALIZE_PAYLOAD]
    checks.append('Real Unix-stream init exchange; BE32 framing and forced fragmented reads')

    received=[]
    def lock_peer(stream):
        assert read_exact(stream,4)==b'\0\0\0\x20'
        received.append(read_exact(stream,32))
        stream.sendall(struct.pack('>I',3)+b'ACK')
    endpoint,finish=synthetic_server(lock_peer)
    with LocalUnixIPCTransport(endpoint) as transport:
        assert transport.connect()
        LockPlayer(0x1122334455667788,transport)
    finish()
    assert received==[b'\x0D\x02\0\0'+b'\0'*20+bytes.fromhex('8877665544332211')]
    checks.append('LockPlayer uses recovered command525 and 64-bit target offset24 on real Unix stream')

    for name,data in [('header',b'\0\0'),('payload',struct.pack('>I',5)+b'AB')]:
        endpoint,finish=synthetic_server(lambda stream,data=data:stream.sendall(data))
        with LocalUnixIPCTransport(endpoint) as transport:
            assert transport.connect()
            assert transport.receive(SNAPSHOT_CHANNEL,MAX_REPLY_BYTES)==b''
            assert not transport.connected and isinstance(transport.last_error,IPCConnectionClosed)
        finish();checks.append('EOF during '+name+' discards partial frame and closes client')

    endpoint,finish=synthetic_server(lambda stream:stream.sendall(struct.pack('>I',MAX_REPLY_BYTES+1)))
    with LocalUnixIPCTransport(endpoint) as transport:
        assert transport.connect()
        try:transport.receive(SNAPSHOT_CHANNEL,MAX_REPLY_BYTES)
        except IPCProtocolError:pass
        else:raise AssertionError('Oversized response accepted')
        assert not transport.connected
    finish();checks.append('Oversized declared response rejected before payload read')

    endpoint,finish=synthetic_server(lambda stream:stream.sendall(b'\0'*4))
    with LocalUnixIPCTransport(endpoint) as transport:
        assert transport.connect()
        assert transport.receive(SNAPSHOT_CHANNEL,MAX_REPLY_BYTES)==b'' and transport.connected
    finish();checks.append('A valid zero-length response is distinct from an EOF state')

    transport=LocalUnixIPCTransport()
    assert not transport.send(SNAPSHOT_CHANNEL,INITIALIZE_PAYLOAD)
    assert transport.initialize() is None
    checks.append('Disconnected send/init do not pretend a native server exists')
    for call in (lambda:transport.send(SNAPSHOT_CHANNEL,b'bad'),
                 lambda:transport.send(0,INITIALIZE_PAYLOAD),
                 lambda:transport.receive(SNAPSHOT_CHANNEL,MAX_REPLY_BYTES+1)):
        try:call()
        except ValueError:pass
        else:raise AssertionError('Invalid input unexpectedly accepted')
    checks.append('Explicit request-size/channel/capacity input bounds')

    class BrokenSend:
        def settimeout(self,value):pass
        def set_inheritable(self,value):pass
        def sendall(self,value):raise BrokenPipeError('Synthetic send failure')
        def close(self):self.closed=True
    failing=BrokenSend();transport=LocalUnixIPCTransport(connected_socket=failing)
    assert not transport.send(SNAPSHOT_CHANNEL,INITIALIZE_PAYLOAD)
    assert not transport.connected and failing.closed
    checks.append('Send failure returns false and closes only the client socket')

    report={'synthetic_unix_ipc_checks_passed':len(checks),'checks':checks,
            'native_game_server_contacted':False,'internet_contacted':False,
            'live_gameplay_verified':False,
            'scope':'Synthetic abstract AF_UNIX server tests of recovered endpoint structure, framing and adapters; explicit Python bounds/EOF adaptations.'}
    (Path(__file__).parent/'local-ipc-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
