"""Run our own static Ghidra analysis/export scripts against file copies."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent.parent / "outputs" / "NX-APK-Recovery-20261023"
GHIDRA = ROOT / "tools/ghidra/ghidra_11.0.3_PUBLIC/support/analyzeHeadless.bat"
PROJECTS = ROOT / "ghidra-projects"
PROJECTS.mkdir(exist_ok=True)
jobs = [
    ("libNOVA_MENU.so", "lib/armeabi-v7a", True),
    ("libNOVAXITERS.so", "lib/armeabi-v7a", True),
    ("l32e337ef_a32.so", "assets", False),
    ("l32e337ef_x86.so", "assets", False),
    ("libinjectEmulator.so", "lib/armeabi-v7a", False),
    ("libshadowhook.so", "lib/armeabi-v7a", False),
    ("libshadowhook_nothing.so", "lib/armeabi-v7a", False),
]
results=[]
for index,(name,subdir,snapshot) in enumerate(jobs):
    target=OUT / "06_native_pseudocode" / name
    log=ROOT / (name+".ghidra.log")
    args=[str(GHIDRA),str(PROJECTS),"recovery_"+str(index),"-import",
          str(OUT / "01_original_apk_contents" / subdir / name),
          "-scriptPath",str(ROOT),"-analysisTimeoutPerFile","150","-max-cpu","4"]
    if snapshot:
        args += ["-preScript","ApplySnapshot.java",
                 str(OUT / "04_supplied_prior_recovery/native_memory" / (name+".unpacked_memory.bin")),
                 str(OUT / "04_supplied_prior_recovery/native_memory" / (name+".modeled_imports.json"))]
    args += ["-postScript","ExportNative.java",str(target)]
    print("START "+name+(" supplied snapshot" if snapshot else " original disk bytes"),flush=True)
    with log.open("w",encoding="utf-8") as output:
        try:
            result=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,timeout=1200)
            code=result.returncode
        except subprocess.TimeoutExpired:
            code="process_timeout"
    summary=target / "summary.json"
    row={"library":name,"supplied_snapshot":snapshot,"process_exit":code,
         "export_summary":json.loads(summary.read_text()) if summary.exists() else None}
    results.append(row)
    (ROOT / "native_pipeline_status.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
    print(json.dumps(row),flush=True)
