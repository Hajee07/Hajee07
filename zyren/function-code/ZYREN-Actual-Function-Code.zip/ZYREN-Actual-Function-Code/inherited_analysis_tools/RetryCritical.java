// Retry the large JNI/constructor functions which previously timed out.
// @category Recovery
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.listing.Function;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.PrintWriter;

public class RetryCritical extends GhidraScript {
    public void run() throws Exception {
        String[] args=getScriptArgs();
        Path folder=Path.of(args[0]);Files.createDirectories(folder);
        DecompInterface decompiler=new DecompInterface();
        DecompileOptions options=new DecompileOptions();
        options.setMaxInstructions(1000000);options.setMaxPayloadMBytes(100);
        decompiler.setOptions(options);decompiler.openProgram(currentProgram);
        try(PrintWriter log=new PrintWriter(Files.newBufferedWriter(folder.resolve("retry_status.csv"),StandardCharsets.UTF_8))) {
            log.println("address,name,pseudocode_emitted,error");
            for(int i=1;i<args.length;i++) {
                Function function=getFunctionAt(toAddr(args[i]));
                if(function==null) {log.println(args[i]+",,false,Function not discovered");continue;}
                println("CRITICAL_RETRY "+args[i]+" "+function.getName());
                DecompileResults result=decompiler.decompileFunction(function,75,monitor);
                boolean ok=result.decompileCompleted()&&result.getDecompiledFunction()!=null;
                String error=result.getErrorMessage().replace("\"","\"\"").replace('\n',' ');
                log.println(args[i]+",\""+function.getName().replace("\"","\"\"")+"\","+ok+",\""+error+"\"");log.flush();
                String heading="/* Retried inferred pseudocode. NOT original or buildable source.\n * Based on supplied emulation-derived snapshot; actual game behavior unverified.\n */\n";
                String code=ok?result.getDecompiledFunction().getC():"/* DECOMPILATION FAILED: "+error.replace("*/","* /")+" */";
                Files.writeString(folder.resolve(args[i]+".c"),heading+code,StandardCharsets.UTF_8);
                println("CRITICAL_RESULT "+args[i]+" emitted="+ok+" "+error);
            }
        } finally {decompiler.dispose();}
    }
}
