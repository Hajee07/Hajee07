"""Additional byte-level checks and readable string substitutions; no target execution."""
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent.parent / "outputs/NX-APK-Recovery-20261023"
ANALYSIS = OUT / "05_analysis"
SOURCE = OUT / "02_java_dex/jadx/sources/v32e337ef/l32e337ef.java"
text = SOURCE.read_text(encoding="utf-8")
pattern = re.compile(r"a\(new byte\[\]\{([\d,\s-]+)\}\)")
constants = []
def substitute(match):
    numbers = [int(n.strip()) for n in match.group(1).split(",")]
    result = bytes((n & 255) ^ 105 for n in numbers).decode("utf-8", "replace")
    constants.append({"source_line": text.count("\n", 0, match.start())+1,
                      "encoded": numbers, "decoded": result})
    return json.dumps(result, ensure_ascii=True)
readable = "/* ANALYST TRANSFORMATION: constant XOR-105 byte arrays replaced by strings.\n * Derived from JADX output; not original Java and not a complete application.\n */\n" + pattern.sub(substitute, text)
target = OUT / "02_java_dex/readable_loader"
target.mkdir(parents=True, exist_ok=True)
(target / "Loader_decoded_constants.java.txt").write_text(readable, encoding="utf-8")
(target / "string_constants.json").write_text(json.dumps(constants, indent=2), encoding="utf-8")

data = (OUT / "01_original_apk_contents/classes.dex").read_bytes()
class_count, class_off = struct.unpack_from("<II", data, 96)
def uleb(off):
    value=0
    for i in range(5):
        byte=data[off];off+=1;value|=(byte&127)<<(7*i)
        if byte<128:return value,off
    raise ValueError("Invalid ULEB128")
defined=0
with_code=0
for c in range(class_count):
    off=struct.unpack_from("<I",data,class_off+c*32+24)[0]
    if not off:continue
    sf,off=uleb(off);inf,off=uleb(off);dm,off=uleb(off);vm,off=uleb(off)
    for _ in range(sf+inf):
        _,off=uleb(off);_,off=uleb(off)
    for _ in range(dm+vm):
        _,off=uleb(off);_,off=uleb(off);code,off=uleb(off)
        defined+=1
        with_code+=bool(code)
tail=(ANALYSIS / "dex/classes.dex.after_declared_data.bin").read_bytes()
counts=collections.Counter(tail)
stats={"dex_defined_methods":defined,"dex_methods_with_bytecode":with_code,
       "dex_method_reference_table_entries":struct.unpack_from("<I",data,88)[0],
       "appended_payload_size":len(tail),"appended_payload_magic_ascii":tail[:4].decode("ascii","replace"),
       "appended_payload_entropy_bits_per_byte":-sum((n/len(tail))*math.log2(n/len(tail)) for n in counts.values()),
       "qualification":"High entropy and a non-DEX header establish an opaque appended payload, not its decrypted contents.",
       "xor_string_call_sites_decoded":len(constants)}
(ANALYSIS / "payload_checks.json").write_text(json.dumps(stats,indent=2),encoding="utf-8")

candidate_folder=OUT / "02_java_dex/embedded_loader_dex"
candidate_folder.mkdir(exist_ok=True)
seen=set()
for row in json.loads((ANALYSIS / "embedded_dex_candidates.json").read_text()):
    if not row["standard_header_valid"] or row["offset"]==0:continue
    original=(OUT / row["source"]).read_bytes()
    blob=original[row["offset"]:row["offset"]+row["declared_size"]]
    digest=hashlib.sha256(blob).hexdigest()
    if digest in seen:continue
    seen.add(digest)
    dex=candidate_folder / "loader_embedded.dex"
    dex.write_bytes(blob)
    with (ROOT / "embedded-jadx.log").open("w",encoding="utf-8") as log:
        result=subprocess.run([str(ROOT / "tools/jadx/bin/jadx.bat"),"-d",str(candidate_folder / "jadx"),str(dex)],stdout=log,stderr=subprocess.STDOUT,timeout=120)
    row.update({"extracted_sha256":digest,"jadx_process_exit":result.returncode})
(ANALYSIS / "embedded_dex_extraction.json").write_text(json.dumps({"unique_embedded_dex_extracted":len(seen)},indent=2),encoding="utf-8")
print(json.dumps(stats),flush=True)
