"""Validate recovered artifacts and package them without asserting original-source recovery."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
NORMAL = ROOT.parent.parent / "outputs/NX-APK-Recovery-20261023"
OUT = Path("\\\\?\\" + str(NORMAL))

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read_json(path):return json.loads(path.read_text(encoding="utf-8"))
def write_json(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding="utf-8")

status=read_json(ROOT / "native_pipeline_status.json")
assert len(status)==7,"Native export pipeline has not finished"
assert all(row["process_exit"]==0 and row["export_summary"] for row in status),"A library export did not complete"

analysis=OUT / "05_analysis"
logs=analysis / "tool_logs"
logs.mkdir(exist_ok=True)
for path in ROOT.glob("*.log"):
    shutil.copyfile(path,logs/path.name)
shutil.copyfile(ROOT / "tools/provenance.json",analysis/"tool_provenance.json")
repro=OUT / "07_recovery_scripts"
repro.mkdir(exist_ok=True)
for path in [*ROOT.glob("*.py"),*ROOT.glob("*.java")]:
    shutil.copyfile(path,repro/path.name)
(repro / "requirements.txt").write_text("pyelftools==0.33\ncapstone==5.0.9\n",encoding="utf-8")

libraries=[]
jni=[]
for directory in sorted((OUT / "06_native_pseudocode").iterdir()):
    if not directory.is_dir():continue
    rows=list(csv.DictReader((directory/"function_status.csv").open(encoding="utf-8",newline="")))
    warnings=[]
    emitted=failed=skipped=0
    aggregate=[]
    for row in rows:
        instruction_count=int(row["instruction_count"])
        if instruction_count==0 or int(row["address"],16)>=0x50000000:
            row.update(status="skipped_no_real_instruction_body",error="Import/modeled symbol; no recoverable instruction body",file="")
            skipped+=1
            # An early export tried such symbols. Preserve the symbol in the CSV, not fictitious C bodies.
            early=directory/"functions"/(row["address"]+".c")
            if early.exists():early.write_text("/* No instruction body was available. Import/modeled symbol only; no source recovered. */\n",encoding="utf-8")
            continue
        if row["status"]=="pseudocode_emitted":emitted+=1
        else:failed+=1
        code=(directory/row["file"]).read_text(encoding="utf-8")
        aggregate.append(code)
        flags=[]
        if "halt_baddata" in code or "halt_unimplemented" in code:flags.append("invalid_or_unsupported_instruction_halt")
        if "WARNING:" in code:flags.append("decompiler_warning_present")
        if "unrecovered_jumptable" in code:flags.append("unresolved_jump_table")
        if flags:warnings.append({"address":row["address"],"name":row["name"],"flags":";".join(flags)})
        if row["name"].startswith("Java_com_NovaX_Menu_"):
            jni.append({"name":row["name"],"address":row["address"],"fresh_status":row["status"],
                        "file":(directory/row["file"]).relative_to(OUT).as_posix(),"quality_flags":flags})
    with (directory/"function_status.csv").open("w",encoding="utf-8",newline="") as output:
        writer=csv.DictWriter(output,fieldnames=["address","name","status","instruction_count","error","file"])
        writer.writeheader();writer.writerows(rows)
    (directory/"ALL_FUNCTIONS.c").write_text("\n\n".join(aggregate),encoding="utf-8")
    write_json(directory/"quality_flags.json",warnings)
    summary={"library":directory.name,"instruction_bearing_functions_attempted":emitted+failed,
             "pseudocode_emitted":emitted,"failed":failed,"imports_or_empty_bodies_skipped":skipped,
             "emitted_files_with_quality_flags":len(warnings),"complete_original_source_recovered":False,
             "input_provenance":"Supplied prior emulation snapshot applied to copied ELF analysis database"
                 if directory.name in ("libNOVAXITERS.so","libNOVA_MENU.so") else "Original ELF bytes from supplied APK"}
    write_json(directory/"summary.json",summary)
    libraries.append(summary)

checks={}
for manifest_name,folder in [("original_entries.json","01_original_apk_contents"),("prior_entries.json","04_supplied_prior_recovery")]:
    entries=read_json(analysis/manifest_name)
    for row in entries:
        path=OUT/folder/row["path"]
        assert path.stat().st_size==row["size"] and digest(path)==row["sha256"],f"Artifact differs: {row['path']}"
    checks[folder+"_files_verified"]=len(entries)
apk=Path(r"C:\Users\Hajzzy\Downloads\NX AIMKILL PVT 1.2\NX AIMKILL PVT 1.2.apk")
assert digest(apk)=="55e3514b0ba0be5658a64d07771644c41fe4ffad5009a6d3f363be28c2dc4644"
checks["source_apk_unchanged"]=True
checks["new_target_execution"]=False
checks["new_live_game_testing"]=False
write_json(analysis/"artifact_validation.json",checks)
write_json(analysis/"native_decompilation_summary.json",libraries)
write_json(analysis/"jni_function_index.json",jni)

native_attempted=sum(row["instruction_bearing_functions_attempted"] for row in libraries)
native_emitted=sum(row["pseudocode_emitted"] for row in libraries)
native_failed=sum(row["failed"] for row in libraries)
retry_results=[]
for path in (OUT/"06_native_pseudocode").glob("*/critical_retry*/retry_status.csv"):
    for row in csv.DictReader(path.open(encoding="utf-8",newline="")):
        row["library"]=path.parent.parent.name
        result_path=path.parent/(row["address"]+".c")
        row["result_file"]=(result_path if result_path.exists() else path).relative_to(OUT).as_posix()
        code=result_path.read_text(encoding="utf-8") if result_path.exists() else ""
        row["quality_flags"]=[]
        if not result_path.exists():row["quality_flags"].append("no_function_body_recovered")
        if "halt_baddata" in code or "halt_unimplemented" in code:row["quality_flags"].append("invalid_or_unsupported_instruction_halt")
        if "WARNING:" in code:row["quality_flags"].append("decompiler_warning_present")
        retry_results.append(row)
write_json(analysis/"critical_retry_summary.json",retry_results)

main_index=["# Main native code index", "", "These are inferred native representations, not recovered original Java or a complete project.", "", "| Function | Initial status | Higher-limit retry |", "|---|---|---|"]
for row in jni:
    retried=[r for r in retry_results if r["address"]==row["address"]]
    retry="No separate retry"
    if retried:
        r=retried[-1]
        retry=("[Pseudocode emitted]" if r["pseudocode_emitted"]=="true" else "[Failed; error recorded]")+"("+r["result_file"]+")"
    main_index.append("| "+row["name"]+" | ["+row["fresh_status"]+"]("+row["file"]+") | "+retry+" |")
main_index += ["", "## Core startup retry outputs", ""]
for row in retry_results:
    if row["library"]=="libNOVAXITERS.so":
        main_index.append("- ["+row["name"]+" / "+row["address"]+"]("+row["result_file"]+"): pseudocode emitted = "+row["pseudocode_emitted"])
main_index += ["", "Full original `com.NovaX.MainActivity` and `com.NovaX.Menu` Java implementations remain unrecovered. See RECOVERY-REPORT.md for provenance and limitations."]
main_index += ["", "All nine observed core initializer entry points also have decoded instruction and raw P-code exports under `06_native_pseudocode/libNOVAXITERS.so/raw_startup_instructions/`. The two large C decompilation failures are retained in the status files; their assembly/P-code is an intermediate representation, not recovered original C++."]
(OUT/"MAIN-CODE-INDEX.md").write_text("\n".join(main_index)+"\n",encoding="utf-8")

report=f"""# NX APK code recovery — 23 October 2026

**This package is a verified partial recovery. The complete original project and
the protected main Java/game implementations have NOT been recovered.**
No replacement app or guessed AimKill implementation is presented as original code.

Input: `NX AIMKILL PVT 1.2.apk` (6,321,031 bytes).
SHA-256: `55e3514b0ba0be5658a64d07771644c41fe4ffad5009a6d3f363be28c2dc4644`.
This hash matches the prior recovery supplied by the user. Prior evidence is preserved
separately and is not claimed as a new runtime observation.

## Open these first

| Folder | What it contains | What it establishes |
|---|---|---|
| `01_original_apk_contents` | All 159 original ZIP entries, byte-identical | Exact APK contents, assets, native libraries, protected DEX payload |
| `02_java_dex/jadx/sources` | Fresh decompiled loader Java and generated resource identifiers | Visible on-disk classes; not hidden original application source |
| `02_java_dex/apktool/smali` | Fresh complete on-disk Smali disassembly | Bytecode representation of available classes |
| `02_java_dex/readable_loader` | 77 XOR-105 constant call sites decoded | Analyst transformation of loader Java, labelled as such |
| `02_java_dex/embedded_loader_dex` | Extracted 316-byte embedded dummy DEX and Java | A fake loader class, not recovered MainActivity/Menu |
| `03_native_static` | All 7 ELF inventories, symbols, strings, executable-section ARM/Thumb/x86 disassembly | Static instruction decoding; protected bytes may yield misleading instructions |
| `04_supplied_prior_recovery/MAIN_NATIVE_CODE` | Prior eight JNI machine-code bodies, available pseudocode and constructor outputs | User-supplied prior modeled recovery, preserved verbatim |
| `06_native_pseudocode` | Fresh native function pseudocode, assembly, per-function status and quality flags | Decompiler output, not original C/C++ or a buildable project |
| `07_recovery_scripts` | Our extraction, export and packaging scripts | Reproducible analysis workflow; source paths may need adjustment |

## Fresh native export results

Across seven libraries, **{native_attempted} instruction-bearing functions were attempted**;
**{native_emitted} produced C-like pseudocode** and **{native_failed} failed** in the initial bounded pass.
Counts include compiler support, protection-loader and third-party library code;
they are not counts of AimKill/game features. Separate critical retries are recorded
in `05_analysis/critical_retry_summary.json` and `critical_retry/` folders.
Each library has `ALL_FUNCTIONS.c`, individual `functions/<address>.c`,
`function_status.csv`, `quality_flags.json`, and `FUNCTIONS.asm`.
Emitting C does not prove correct control flow, complete recovery, or runnable behavior.
Invalid-instruction halts, decompiler warnings and unresolved branches are flagged.

For `libNOVA_MENU.so` and `libNOVAXITERS.so`, fresh exports use the exact supplied
prior emulation-derived snapshots, applied only to analysis databases. Snapshot
base is 0x10000000; import labels at 0x50000000 are modeled addresses. They are not
live process addresses or newly unpacked runtime files. Other five exports use the
original on-disk ELF bytes. Original ELF symbol names/types may be incomplete or
inferred; raw memory snapshots are not rebuilt loadable shared libraries.

The separate raw-snapshot pass explicitly preserved the ARM/Thumb bit from all
nine observed core initializer pointers. Its assembly and raw P-code exports are
under `06_native_pseudocode/libNOVAXITERS.so/raw_startup_instructions/`.
The two previously unavailable large core constructors still exceeded the extended
75-second C decompilation limit. Their instruction-level exports and failure
records are included; no guessed C implementation replaces them. The previously
timed-out menu `Java_com_NovaX_Menu_Functions` body did produce fresh pseudocode
in a separate higher-limit retry, derived from the supplied snapshot.

## Why the main code is still missing

The actual class table has only four protection/loader classes. There are 39
declared methods, of which 31 have Dalvik bytecode; 140 is the method-reference
table size, not a count of implemented methods. `com.NovaX.MainActivity` and
`com.NovaX.Menu` are not defined in the parsed disk DEX. Resource class `R.java`
is generated by JADX from resources and must not be mistaken for an extra DEX class.

After the declared DEX data is a 781,311-byte opaque payload with `VBPD` magic
and measured entropy about 7.9998 bits/byte. It is preserved intact under
`05_analysis/dex/classes.dex.after_declared_data.bin`. Those bytes are not a
second readable DEX. Standard DEX signature scanning found the main loader DEX
and a 316-byte dummy DEX embedded in both loader native libraries; it did not
establish a recovered MainActivity/Menu implementation. Signature scanning alone
cannot exclude encrypted or headerless code.

The supplied old archive reports partial unpacking/JNI recovery, unresolved
virtualized bodies and previous instrumented-runtime failures. That old evidence
is included with its own provenance. It does not establish complete gameplay
implementations, and it has not been silently promoted to new results.

The 5 tabs / 50 switches / 58 observed menu callbacks in
`04_supplied_prior_recovery/MAIN_NATIVE_CODE/menu/RecoveredMenuDefinition.java`
are a labelled reconstruction. Labels such as Aimkill MultiTarget, ESP and
teleport do not prove the underlying feature implementation was recovered.
Original names, comments, source structure, Gradle/CMake configuration, full
protected Java implementations and complete devirtualized game logic remain missing.

## Verification and boundaries of this run

- Source APK SHA-256 unchanged; all 159 APK entries independently re-hashed.
- All 345 supplied prior-recovery files independently re-hashed and preserved.
- Fresh JADX 1.5.6, Apktool 2.12.1, Ghidra 11.0.3, Capstone 5.0.9 and pyelftools 0.33 outputs.
- Ghidra release archive matched its upstream published SHA-256.
- Native export statuses and warnings are recorded rather than replaced by invented bodies.
- No APK/native initializer, recovered runtime script or game was executed in this run.
- No current device, game compatibility, all-feature functionality or rebuilt APK is claimed.
- ZIP CRC and content-hash verification is performed after packaging.

Tool sources: [JADX](https://github.com/skylot/jadx/releases/tag/v1.5.6),
[Apktool](https://github.com/iBotPeaches/Apktool/releases/tag/v2.12.1),
[Ghidra](https://github.com/NationalSecurityAgency/ghidra/releases/tag/Ghidra_11.0.3_build).
"""
(OUT/"RECOVERY-REPORT.md").write_text(report,encoding="utf-8")
tamil=f"""# NX APK — recovery result

**Full original source code recover aagala. Indha package verified partial recovery.**

Pudhusa seythathu:
- APK-oda 159 original files exact-aa extract panni hash verify panniyirukkom.
- Available loader Java, complete on-disk Smali, resources recover panniyirukkom.
- Loader-oda 77 encoded string call sites readable-aa decode panniyirukkom.
- 7 native libraries-kku symbols, strings, instruction disassembly irukku.
- {native_attempted} native function attempts-la {native_emitted} C-like pseudocode outputs;
  {native_failed} initial decompilation failures. Idhu game-feature count illai.
- Per-function status/warnings irukku. Important large functions-ku separate retry result irukku.
- Neenga anuppina 345 previous recovery files-um separate-aa unchanged preserve panniyirukkom.

Main problem:
Disk DEX-la 4 loader/protection classes mattum irukku. Original MainActivity/Menu
implementations parsed class table-la illai. 781 KB opaque protected payload irukku.
Adhai decode/devirtualize seytha full source indha run-la kidaikkala.

Mudhalil `RECOVERY-REPORT.md`, appuram
`06_native_pseudocode/libNOVA_MENU.so/ALL_FUNCTIONS.c`,
`06_native_pseudocode/libNOVAXITERS.so/ALL_FUNCTIONS.c`,
`05_analysis/jni_function_index.json` open pannunga.

`.c` = inferred pseudocode; `.asm`/Smali = disassembly;
`04_supplied_prior_recovery` = unga old recovery, pudhu result illai.
Idhu original Android Studio project allathu ready-to-build working APK illai.
Game functions working-nu live test pannala. Invent panna source files include pannala.
"""
(OUT/"START-HERE-TAMIL.md").write_text(tamil,encoding="utf-8")

# Hash every deliverable file. This manifest excludes itself.
files=sorted(p for p in OUT.rglob("*") if p.is_file() and p!=OUT/"SHA256SUMS.txt")
(OUT/"SHA256SUMS.txt").write_text("".join(digest(p)+"  "+p.relative_to(OUT).as_posix()+"\n" for p in files),encoding="utf-8")

def package(name, readable_only):
    destination=NORMAL.parent/name
    expected={}
    with zipfile.ZipFile(destination,"w",zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as archive:
        for path in sorted(OUT.rglob("*")):
            if not path.is_file():continue
            relative=path.relative_to(OUT).as_posix()
            if readable_only:
                allowed=(relative.startswith(("06_native_pseudocode/","07_recovery_scripts/","02_java_dex/readable_loader/","02_java_dex/jadx/sources/","02_java_dex/apktool/smali/","04_supplied_prior_recovery/MAIN_NATIVE_CODE/"))
                         or relative.startswith(("04_supplied_prior_recovery/MENU_FEATURES",))
                         or relative in ("RECOVERY-REPORT.md","START-HERE-TAMIL.md","MAIN-CODE-INDEX.md")
                         or relative.startswith("05_analysis/") and path.suffix in (".json",".csv"))
                if not allowed:continue
            payload=path.read_bytes()
            archive.writestr("NX-APK-Recovery-20261023/"+relative,payload)
            expected["NX-APK-Recovery-20261023/"+relative]=hashlib.sha256(payload).hexdigest()
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(expected)
        for name,hash_value in expected.items():assert hashlib.sha256(archive.read(name)).hexdigest()==hash_value
    return {"path":str(destination),"size":destination.stat().st_size,"sha256":digest(destination),"entries":len(expected),"crc_and_all_content_hashes_verified":True}

archives=[package("NX-APK-Recovery-20261023.zip",False),package("NX-Recovered-Code-20261023.zip",True)]
write_json(ROOT/"release_validation.json",{"archives":archives,"checks":checks,"native_libraries":libraries,"critical_retries":retry_results})
shutil.copyfile(OUT/"START-HERE-TAMIL.md",NORMAL.parent/"NX-Recovery-Readme-Tamil.md")
print(json.dumps({"archives":archives,"native_attempts":native_attempted,"pseudocode_outputs":native_emitted,"initial_failures":native_failed,"checks":checks}),flush=True)
