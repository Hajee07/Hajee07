// Apply supplied modeled memory bytes to an analysis database, never to the APK.
// @category Recovery
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.SourceType;
import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ApplySnapshot extends GhidraScript {
    public void run() throws Exception {
        String[] args = getScriptArgs();
        byte[] snapshot = Files.readAllBytes(Path.of(args[0]));
        long base = 0x10000000L;
        currentProgram.setImageBase(toAddr(base), true);
        Memory memory = currentProgram.getMemory();
        long offset = 0;
        int gap = 0;
        while (offset < snapshot.length) {
            Address address = toAddr(base + offset);
            MemoryBlock block = memory.getBlock(address);
            if (block != null) {
                if (!block.isInitialized()) block = memory.convertToInitialized(block, (byte)0);
                int length = (int)Math.min(snapshot.length-offset, block.getEnd().subtract(address)+1);
                memory.setBytes(address, snapshot, (int)offset, length);
                offset += length;
            } else {
                long limit = snapshot.length;
                for (MemoryBlock b : memory.getBlocks()) {
                    long next = b.getStart().getOffset() - base;
                    if (next > offset && next < limit) limit = next;
                }
                int length = (int)(limit-offset);
                MemoryBlock added = memory.createInitializedBlock("snapshot_gap_"+(gap++), address,
                    new ByteArrayInputStream(snapshot, (int)offset, length), length, monitor, false);
                added.setRead(true); added.setWrite(true); added.setExecute(false);
                offset = limit;
            }
        }
        JsonObject imports = JsonParser.parseString(Files.readString(Path.of(args[1]))).getAsJsonObject().getAsJsonObject("imports");
        long end = 0x50000000L;
        for (String name : imports.keySet()) end = Math.max(end, imports.get(name).getAsLong()+16);
        memory.createInitializedBlock("MODELED_import_labels_not_real_code", toAddr(0x50000000L), end-0x50000000L, (byte)0, monitor, false);
        for (String name : imports.keySet()) {
            createLabel(toAddr(imports.get(name).getAsLong()), name, true, SourceType.USER_DEFINED);
        }
        println("Applied supplied snapshot: "+snapshot.length+" bytes. Imported labels are modeled addresses, not actual library code.");
    }
}
