"""Fetch pinned analysis tools from their upstream releases; never run the APK."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / "tools"
TOOLS.mkdir(exist_ok=True)

def fetch(repo, tag, match, directory, expected=None):
    request = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/releases/tags/{tag}",
        headers={"User-Agent": "Codex-local-static-analysis"},
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        release = json.load(response)
    asset = next(a for a in release["assets"] if match(a["name"]))
    dest = TOOLS / asset["name"]
    if not dest.exists():
        with urllib.request.urlopen(asset["browser_download_url"], timeout=60) as response, dest.open("wb") as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
    digest = hashlib.sha256(dest.read_bytes()).hexdigest()
    if expected and digest != expected:
        raise ValueError(f"Hash mismatch: {dest.name}")
    upstream = asset.get("digest") or ""
    if upstream.startswith("sha256:") and digest != upstream[7:]:
        raise ValueError(f"Upstream hash mismatch: {dest.name}")
    if directory:
        target = TOOLS / directory
        if not target.exists():
            target.mkdir()
            with zipfile.ZipFile(dest) as archive:
                for member in archive.infolist():
                    result = (target / member.filename).resolve()
                    if not result.is_relative_to(target.resolve()):
                        raise ValueError("Unsafe tool archive path")
                archive.extractall(target)
    print(json.dumps({"tool": repo, "file": dest.name, "sha256": digest}), flush=True)
    return {"repository": repo, "tag": tag, "file": str(dest), "sha256": digest,
            "url": asset["browser_download_url"], "upstream_digest": upstream}

jobs = [
    ("skylot/jadx", "v1.5.6", lambda n: n == "jadx-1.5.6.zip", "jadx", None),
    ("iBotPeaches/Apktool", "v2.12.1", lambda n: n.endswith(".jar"), None, None),
    ("NationalSecurityAgency/ghidra", "Ghidra_11.0.3_build", lambda n: n.endswith(".zip"), "ghidra",
     "2462a2d0ab11e30f9e907cd3b4aa6b48dd2642f325617e3d922c28e752be6761"),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(lambda job: fetch(*job), jobs))
(TOOLS / "provenance.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
