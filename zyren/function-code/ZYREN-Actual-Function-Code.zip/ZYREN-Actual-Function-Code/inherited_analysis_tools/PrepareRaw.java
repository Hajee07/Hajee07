// Establish observed initializer entry points in a separate raw-snapshot database.
// @category Recovery
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.lang.Register;
import ghidra.program.model.symbol.SourceType;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class PrepareRaw extends GhidraScript {
    public void run() throws Exception {
        String[] args=getScriptArgs();
        JsonObject imports=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject().getAsJsonObject("imports");
        long end=0x50000000L;
        for(String name:imports.keySet())end=Math.max(end,imports.get(name).getAsLong()+16);
        currentProgram.getMemory().createInitializedBlock("MODELED_import_labels_not_real_code",toAddr(0x50000000L),end-0x50000000L,(byte)0,monitor,false);
        for(String name:imports.keySet())createLabel(toAddr(imports.get(name).getAsLong()),name,true,SourceType.USER_DEFINED);
        Register tmode=currentProgram.getRegister("TMode");
        for(int index=1;index<args.length;index++) {
            long pointer=Long.parseUnsignedLong(args[index],16);
            Address entry=toAddr(pointer&~1L);
            currentProgram.getProgramContext().setValue(tmode,entry,entry,BigInteger.valueOf(pointer&1));
            addEntryPoint(entry);
            createLabel(entry,"Recovered_raw_ctor_"+(index-1),true,SourceType.USER_DEFINED);
            disassemble(entry);
            if(getFunctionAt(entry)==null)createFunction(entry,"Recovered_raw_ctor_"+(index-1));
            println("RAW_ENTRY "+entry+" Thumb="+(pointer&1)+" function="+(getFunctionAt(entry)!=null));
        }
    }
}
