"""Reproducible static extraction, DEX inventory, and native disassembly.

No APK, native initializer, recovered script, or game code is executed.
"""
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "deps"))
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM, CS_ARCH_X86, CS_MODE_ARM, CS_MODE_THUMB, CS_MODE_32

WORKSPACE = ROOT.parent.parent
APK = Path(r"C:\Users\Hajzzy\Downloads\NX AIMKILL PVT 1.2\NX AIMKILL PVT 1.2.apk")
PRIOR = Path(r"C:\Users\Hajzzy\Downloads\NX_AIMKILL_Recovered_Code (3).zip")
OUT = Path("\\\\?\\" + str(WORKSPACE / "outputs" / "NX-APK-Recovery-20261023"))
OUT.mkdir(parents=True, exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")

def extract(archive_path, target, strip_prefix=""):
    rows = []
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive CRC verification failed")
        for member in archive.infolist():
            if member.is_dir():
                continue
            name = member.filename
            if strip_prefix:
                if not name.startswith(strip_prefix):
                    raise ValueError("Unexpected archive root")
                name = name[len(strip_prefix):]
            path = (target / name).resolve()
            if not path.is_relative_to(target.resolve()):
                raise ValueError("Unsafe archive path")
            data = archive.read(member)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            rows.append({"path": name, "size": len(data), "sha256": sha(data)})
    return rows

original = OUT / "01_original_apk_contents"
entries = extract(APK, original)
previous = OUT / "04_supplied_prior_recovery"
prior_entries = extract(PRIOR, previous, "NX_AIMKILL_Recovered_Code/")
provenance = json.loads((previous / "analysis_provenance.json").read_text(encoding="utf-8"))
assert provenance["input_sha256"] == sha(APK.read_bytes()), "Prior recovery has a different APK"

def uleb(data, off):
    value = 0
    for n in range(5):
        b = data[off]
        off += 1
        value |= (b & 127) << (n * 7)
        if b < 128:
            return value, off
    raise ValueError("Invalid ULEB128")

def dex_inventory(data):
    if not data.startswith(b"dex\n") or len(data) < 112:
        raise ValueError("Not a standard DEX header")
    values = struct.unpack_from("<20I", data, 32)
    keys = ["file_size", "header_size", "endian_tag", "link_size", "link_off", "map_off",
            "string_ids_size", "string_ids_off", "type_ids_size", "type_ids_off",
            "proto_ids_size", "proto_ids_off", "field_ids_size", "field_ids_off",
            "method_ids_size", "method_ids_off", "class_defs_size", "class_defs_off",
            "data_size", "data_off"]
    result = dict(zip(keys, values))
    strings = []
    for i in range(result["string_ids_size"]):
        offset = struct.unpack_from("<I", data, result["string_ids_off"] + 4 * i)[0]
        _, offset = uleb(data, offset)
        end = data.index(0, offset)
        strings.append(data[offset:end].decode("utf-8", "replace"))
    types = [strings[struct.unpack_from("<I", data, result["type_ids_off"] + 4 * i)[0]]
             for i in range(result["type_ids_size"])]
    result["classes"] = []
    for i in range(result["class_defs_size"]):
        row = struct.unpack_from("<8I", data, result["class_defs_off"] + i * 32)
        result["classes"].append({"descriptor": types[row[0]], "access_flags": row[1],
                                   "class_data_off": row[6]})
    result["actual_size"] = len(data)
    result["declared_data_end"] = result["data_off"] + result["data_size"]
    result["bytes_after_declared_data"] = len(data) - result["declared_data_end"]
    result["sha256"] = sha(data)
    return result, strings

dex_info = []
for path in original.rglob("*.dex"):
    result, strings = dex_inventory(path.read_bytes())
    result["path"] = path.relative_to(original).as_posix()
    dex_info.append(result)
    target = OUT / "05_analysis" / "dex"
    target.mkdir(parents=True, exist_ok=True)
    (target / (path.name + ".strings.txt")).write_text("\n".join(strings), encoding="utf-8")
    tail = path.read_bytes()[result["declared_data_end"]:]
    (target / (path.name + ".after_declared_data.bin")).write_bytes(tail)
save_json(OUT / "05_analysis" / "dex_inventory.json", dex_info)

def analyze_elf(path):
    blob = path.read_bytes()
    elf = ELFFile(io.BytesIO(blob))
    output = OUT / "03_native_static" / path.name
    output.mkdir(parents=True, exist_ok=True)
    symbols = []
    functions = []
    mappings = []
    for section in elf.iter_sections():
        if section["sh_type"] in ("SHT_DYNSYM", "SHT_SYMTAB"):
            for symbol in section.iter_symbols():
                row = {"table": section.name, "name": symbol.name, "address": symbol["st_value"],
                       "size": symbol["st_size"], "type": symbol["st_info"]["type"],
                       "binding": symbol["st_info"]["bind"], "section": symbol["st_shndx"]}
                symbols.append(row)
                if row["type"] == "STT_FUNC":
                    functions.append(row)
                if re.match(r"^\$[atd](?:\.|$)", symbol.name):
                    mappings.append((symbol["st_value"], symbol.name[1]))
    mappings = sorted(set(mappings))
    unique = {(r["address"], r["name"]): r for r in functions if r["section"] != "SHN_UNDEF"}
    with (output / "functions.csv").open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=["table", "name", "address", "size", "type", "binding", "section"])
        writer.writeheader()
        writer.writerows(sorted(unique.values(), key=lambda r: (r["address"], r["name"])))
    save_json(output / "symbols.json", symbols)
    imports = [r["name"] for r in symbols if r["section"] == "SHN_UNDEF" and r["name"]]
    sections = [{"name": s.name, "address": s["sh_addr"], "offset": s["sh_offset"],
                 "size": s["sh_size"], "flags": s["sh_flags"], "type": s["sh_type"]}
                for s in elf.iter_sections()]
    meta = {"source": path.relative_to(original).as_posix(), "sha256": sha(blob),
            "machine": elf["e_machine"], "class": elf.elfclass, "imports": sorted(set(imports)),
            "sections": sections, "defined_function_symbols": len(unique)}
    save_json(output / "metadata.json", meta)
    with (output / "printable_strings.txt").open("w", encoding="utf-8") as out:
        for match in re.finditer(rb"[\x20-\x7e]{5,}", blob):
            out.write(f"file+0x{match.start():08x}\t{match.group().decode('ascii')}\n")
    count = 0
    with (output / "executable_sections.asm").open("w", encoding="utf-8") as out:
        out.write("; Static instruction decoding, NOT original source or proof of executable behavior.\n")
        out.write("; ARM mapping symbols select ARM/Thumb/data where available. Packed bytes can decode as misleading instructions.\n")
        for s in elf.iter_sections():
            if not (s["sh_flags"] & 4) or s["sh_type"] == "SHT_NOBITS":
                continue
            start = s["sh_addr"]
            end = start + s["sh_size"]
            raw = s.data()
            points = [(a, mode) for a, mode in mappings if start <= a < end]
            if not points or points[0][0] != start:
                points.insert(0, (start, "a"))
            points.append((end, "d"))
            out.write(f"\n; SECTION {s.name} 0x{start:x}..0x{end:x}\n")
            for (address, mode), (limit, _) in zip(points, points[1:]):
                if limit <= address:
                    continue
                if elf["e_machine"] == "EM_ARM" and mode == "d":
                    out.write(f"; DATA 0x{address:x}..0x{limit:x}\n")
                    continue
                decoder = Cs(CS_ARCH_ARM if elf["e_machine"] == "EM_ARM" else CS_ARCH_X86,
                             (CS_MODE_THUMB if mode == "t" else CS_MODE_ARM) if elf["e_machine"] == "EM_ARM" else CS_MODE_32)
                decoder.skipdata = True
                for insn in decoder.disasm(raw[address-start:limit-start], address):
                    out.write(f"{insn.address:08x}  {insn.bytes.hex():20} {insn.mnemonic:10} {insn.op_str}\n")
                    count += 1
    meta["static_instruction_or_data_records"] = count
    save_json(output / "metadata.json", meta)
    print(f"ELF {path.name}: {len(unique)} function symbols, {count} static decoding records", flush=True)
    return meta

native = [analyze_elf(p) for p in sorted(original.rglob("*.so"))]
save_json(OUT / "05_analysis" / "native_inventory.json", native)

# Search bytecode signatures without assuming a signature is a valid executable file.
candidates = []
for p in [*original.rglob("*"), *previous.glob("native_memory/*.bin")]:
    if not p.is_file():
        continue
    data = p.read_bytes()
    for match in re.finditer(rb"(?:dex\n0[0-9]{2}\x00|cdex[0-9]{3}\x00)", data):
        row = {"source": p.relative_to(OUT).as_posix(), "offset": match.start(), "standard_header_valid": False}
        try:
            info, _ = dex_inventory(data[match.start():])
            size = info["file_size"]
            row.update({"standard_header_valid": 112 <= size <= len(data)-match.start(),
                        "declared_size": size, "class_count": info["class_defs_size"]})
        except Exception as error:
            row["parse_error"] = type(error).__name__
        candidates.append(row)
save_json(OUT / "05_analysis" / "embedded_dex_candidates.json", candidates)
save_json(OUT / "05_analysis" / "original_entries.json", entries)
save_json(OUT / "05_analysis" / "prior_entries.json", prior_entries)
save_json(OUT / "05_analysis" / "extraction_status.json", {
    "apk_sha256": sha(APK.read_bytes()), "apk_entries_extracted": len(entries),
    "supplied_prior_zip_sha256": sha(PRIOR.read_bytes()), "prior_entries_preserved": len(prior_entries),
    "prior_apk_hash_matches": True, "new_apk_execution": False,
    "java_classes_on_disk": [c["descriptor"] for info in dex_info for c in info["classes"]],
    "native_libraries": len(native), "complete_original_source_recovered": False,
})
print(json.dumps({"output": str(OUT), "apk_entries": len(entries), "prior_entries": len(prior_entries), "native_libraries": len(native)}))
