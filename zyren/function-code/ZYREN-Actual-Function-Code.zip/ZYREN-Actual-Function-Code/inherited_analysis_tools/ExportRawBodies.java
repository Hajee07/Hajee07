// Preserve decoded initializer instructions and raw P-code even when C decompilation times out.
// @category Recovery
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.pcode.PcodeOp;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class ExportRawBodies extends GhidraScript {
    public void run() throws Exception {
        String[] args=getScriptArgs();Path folder=Path.of(args[0]);Files.createDirectories(folder);
        try(PrintWriter index=new PrintWriter(Files.newBufferedWriter(folder.resolve("index.csv"),StandardCharsets.UTF_8))) {
            index.println("address,name,instructions,pcode_error_count");
            for(int i=1;i<args.length;i++) {
                Function function=getFunctionAt(toAddr(args[i]));if(function==null)continue;
                int count=0,errors=0;
                try(PrintWriter asm=new PrintWriter(Files.newBufferedWriter(folder.resolve(args[i]+".asm"),StandardCharsets.UTF_8));
                    PrintWriter pcode=new PrintWriter(Files.newBufferedWriter(folder.resolve(args[i]+".pcode.txt"),StandardCharsets.UTF_8))) {
                    String note="; Decoded from a supplied emulation-derived memory snapshot. Not original source; no game execution verified.";
                    asm.println(note);pcode.println(note);
                    InstructionIterator instructions=currentProgram.getListing().getInstructions(function.getBody(),true);
                    while(instructions.hasNext()) {
                        Instruction instruction=instructions.next();count++;
                        String line=instruction.getAddress()+"  "+instruction.toString();
                        asm.println(line);pcode.println("\n; "+line);
                        try {for(PcodeOp op:instruction.getPcode())pcode.println(op.toString());}
                        catch(Exception error){errors++;pcode.println("; PCODE ERROR: "+error);}
                    }
                }
                index.println(args[i]+","+function.getName()+","+count+","+errors);index.flush();
            }
        }
    }
}
