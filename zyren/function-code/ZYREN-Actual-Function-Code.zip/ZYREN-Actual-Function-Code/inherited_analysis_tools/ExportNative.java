// Export every discovered native function with explicit per-function failure status.
// @category Recovery
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public class ExportNative extends GhidraScript {
    private String csv(String value) { return "\""+value.replace("\"", "\"\"")+"\""; }
    public void run() throws Exception {
        Path folder = Path.of(getScriptArgs()[0]);
        Files.createDirectories(folder.resolve("functions"));
        DecompInterface decompiler = new DecompInterface();
        decompiler.toggleCCode(true);
        decompiler.toggleSyntaxTree(false);
        if (!decompiler.openProgram(currentProgram)) throw new RuntimeException(decompiler.getLastMessage());
        int total=0, success=0, failed=0, external=0;
        String disclaimer = "/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.\n"+
            " * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.\n"+
            " * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.\n"+
            " * No current APK/game execution or feature verification was performed.\n */\n\n";
        try (PrintWriter index = new PrintWriter(Files.newBufferedWriter(folder.resolve("function_status.csv"), StandardCharsets.UTF_8));
             PrintWriter all = new PrintWriter(Files.newBufferedWriter(folder.resolve("ALL_FUNCTIONS.c"), StandardCharsets.UTF_8));
             PrintWriter asm = new PrintWriter(Files.newBufferedWriter(folder.resolve("FUNCTIONS.asm"), StandardCharsets.UTF_8))) {
            index.println("address,name,status,instruction_count,error,file");
            all.print(disclaimer);
            asm.println("; Ghidra function disassembly. Snapshot bytes have supplied modeled provenance. Not original source.");
            FunctionIterator functions=currentProgram.getFunctionManager().getFunctions(true);
            while (functions.hasNext() && !monitor.isCancelled()) {
                Function function=functions.next();
                if(function.isExternal()) { external++; continue; }
                String address=function.getEntryPoint().toString();
                String relative="functions/"+address+".c";
                asm.println("\n; "+address+" "+function.getName());
                InstructionIterator instructions=currentProgram.getListing().getInstructions(function.getBody(),true);
                int count=0;
                while(instructions.hasNext()) {
                    Instruction instruction=instructions.next(); count++;
                    asm.println(instruction.getAddress()+"  "+instruction.toString());
                }
                if (count==0 || function.getEntryPoint().getOffset()>=0x50000000L) {
                    external++;
                    index.println(csv(address)+","+csv(function.getName())+",\"skipped_no_real_instruction_body\","+count+",\"Import or modeled symbol; no recoverable implementation\",\"\"");
                    continue;
                }
                total++;
                String status="failed",error="",code="";
                try {
                    DecompileResults result=decompiler.decompileFunction(function,4,monitor);
                    if(result.decompileCompleted() && result.getDecompiledFunction()!=null) {
                        code=result.getDecompiledFunction().getC(); status="pseudocode_emitted";success++;
                    } else { error=result.getErrorMessage();failed++; }
                } catch(Exception exception) { error=exception.toString();failed++; }
                String text=disclaimer+"/* Function "+address+" "+function.getName()+" */\n"+
                    (status.equals("pseudocode_emitted") ? code : "/* DECOMPILATION FAILED: "+error.replace("*/","* /")+" */\n");
                Files.writeString(folder.resolve(relative),text,StandardCharsets.UTF_8);
                all.println(text);
                index.println(csv(address)+","+csv(function.getName())+","+csv(status)+","+count+","+csv(error.replace('\n',' '))+","+csv(relative));
                if(total%100==0) { index.flush();all.flush();asm.flush();println("EXPORT_PROGRESS "+total+" functions, "+success+" emitted, "+failed+" failed"); }
            }
        } finally { decompiler.dispose(); }
        String result=String.format(Locale.ROOT,"{\"functions_attempted\":%d,\"pseudocode_emitted\":%d,\"decompilation_failed\":%d,\"externals_skipped\":%d,\"complete_original_source\":false}",total,success,failed,external);
        Files.writeString(folder.resolve("summary.json"),result,StandardCharsets.UTF_8);
        println("EXPORT_SUMMARY "+result);
    }
}
