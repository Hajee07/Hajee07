"""Wait for the copied core analysis database to close, then retry two large bodies."""
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent
for _ in range(240):
    path=ROOT/"native_pipeline_status.json"
    if path.exists():
        try:
            rows=json.loads(path.read_text())
            if any(r["library"]=="libNOVAXITERS.so" for r in rows):break
        except json.JSONDecodeError:pass
    time.sleep(5)
else:raise RuntimeError("Core analysis database did not become ready")
args=[str(ROOT/"tools/ghidra/ghidra_11.0.3_PUBLIC/support/analyzeHeadless.bat"),
      str(ROOT/"ghidra-projects"),"recovery_1","-process","libNOVAXITERS.so","-noanalysis",
      "-scriptPath",str(ROOT),"-postScript","RetryCritical.java",
      str(ROOT.parent.parent/"outputs/NX-APK-Recovery-20261023/06_native_pseudocode/libNOVAXITERS.so/critical_retry"),
      "1010e708","10111bfc"]
print("Starting critical core retries",flush=True)
with (ROOT/"core-critical.log").open("w",encoding="utf-8") as output:
    result=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,timeout=600)
print("Critical core retry process exit",result.returncode,flush=True)
