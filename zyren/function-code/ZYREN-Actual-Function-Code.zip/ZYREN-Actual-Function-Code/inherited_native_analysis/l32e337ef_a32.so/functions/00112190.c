/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00112190 FUN_00112190 */

undefined4 FUN_00112190(uint *param_1,char *param_2,uint param_3)

{
  uint uVar1;
  char *pcVar2;
  char **ppcVar3;
  char *pcVar4;
  uint uVar5;
  void *__ptr;
  
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  uVar5 = param_1[0x12];
  if ((uVar5 == 0) || (param_1[5] != 1)) goto LAB_0011235c;
  if ((param_3 & 0x4000) == 0) {
    uVar1 = param_1[4];
    if (*(int *)(uVar5 + 0x34) != 0) goto LAB_0011221c;
    if (uVar1 == 0xffff) goto LAB_001122bc;
    if (param_1[1] + (uint)(0xffffffb3 < *param_1) != 0) {
      param_1[7] = 3;
      return 0;
    }
  }
  else {
    if (*(int *)(uVar5 + 0x34) == 0) goto LAB_0011235c;
    uVar1 = param_1[4];
LAB_0011221c:
    if (uVar1 == 0xffffffff) {
LAB_001122bc:
      param_1[7] = 2;
      return 0;
    }
  }
  __ptr = *(void **)(uVar5 + 0x3c);
  if (__ptr == (void *)0x0) {
    if (*(int *)(uVar5 + 0x48) == 0) {
      if (param_1[0xf] == 0) goto LAB_0011235c;
      goto LAB_00112314;
    }
    if ((uint *)param_1[0x11] != param_1) {
LAB_0011235c:
      param_1[7] = 0x18;
      return 0;
    }
    uVar1 = DAT_0011239c + 0x1122f8;
    *(undefined4 *)(uVar5 + 0x50) = *(undefined4 *)(uVar5 + 0x4c);
  }
  else {
    if ((uint *)param_1[0x11] != param_1) goto LAB_0011235c;
    uVar1 = DAT_00112398 + 0x11224c;
    if (param_1[6] == 4) {
      if (param_2 == (char *)0x0) goto LAB_0011235c;
      if (*(int *)((int)__ptr + 8) != 0) {
        FUN_00120238();
        free(__ptr);
      }
      pcVar2 = (char *)FUN_001201d4(param_2,0);
      if (pcVar2 == (char *)0xffffffff || (int)(pcVar2 + 1) < 0 != SCARRY4((int)pcVar2,1)) {
        *(undefined4 *)(uVar5 + 0x3c) = 0;
LAB_00112374:
        FUN_0010b938(param_1,0);
        param_1[7] = 0x11;
        return 0;
      }
      ppcVar3 = (char **)malloc(0xc);
      pcVar4 = strdup(param_2);
      *ppcVar3 = pcVar4;
      ppcVar3[1] = (char *)0x0;
      ppcVar3[2] = pcVar2;
      *(char ***)(uVar5 + 0x3c) = ppcVar3;
      if (ppcVar3 == (char **)0x0) goto LAB_00112374;
      uVar5 = param_1[0x12];
    }
  }
  param_1[0xf] = uVar1;
  param_1[0x10] = 0;
LAB_00112314:
  *param_1 = param_1[2];
  param_1[1] = param_1[3];
  param_1[2] = 0;
  param_1[3] = 0;
  (*(code *)param_1[0xb])(param_1[0xd],*(undefined4 *)(uVar5 + 0x20));
  *(undefined4 *)(uVar5 + 0x20) = 0;
  *(undefined4 *)(uVar5 + 0x24) = 0;
  *(undefined4 *)(uVar5 + 0x28) = 0;
  *(undefined4 *)(uVar5 + 0x2c) = 0;
  param_1[5] = 2;
  return 1;
}

