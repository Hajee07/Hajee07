/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00119d54 FUN_00119d54 */

undefined4 FUN_00119d54(byte *param_1,int param_2,uint param_3)

{
  bool bVar1;
  char *pcVar2;
  char cVar3;
  byte *pbVar4;
  void *pvVar5;
  char *pcVar6;
  char **ppcVar7;
  char *pcVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  char *pcVar12;
  uint uVar13;
  undefined4 uVar14;
  byte *unaff_r7;
  stat sStack_e0;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  int local_50;
  int local_4c;
  int local_48;
  int local_3c;
  undefined4 local_38;
  undefined4 *local_34;
  void *local_30;
  
  pbVar4 = param_1;
  if (param_1 != (byte *)0x0) {
    pbVar4 = (byte *)(uint)*param_1;
    unaff_r7 = param_1;
  }
  if (param_1 == (byte *)0x0 || pbVar4 == (byte *)0x0) {
    return 0xffffffea;
  }
  __aeabi_memclr8(&local_78,0x50);
  local_3c = DAT_0011a04c + 0x119db0;
  local_48 = DAT_0011a050 + 0x119db8;
  local_38 = 0;
  local_4c = DAT_0011a054 + 0x119dc8;
  local_50 = DAT_0011a058 + 0x119dd8;
  local_78 = 0;
  local_74 = 0;
  local_70 = 0;
  local_6c = 0;
  local_68 = 0;
  local_34 = &local_78;
  pvVar5 = malloc(0x58);
  if (pvVar5 != (void *)0x0) {
    local_30 = pvVar5;
    __aeabi_memclr8(pvVar5,0x58);
    *(undefined4 *)((int)pvVar5 + 0x34) = 0;
    *(undefined4 *)((int)pvVar5 + 0x38) = 0;
    *(undefined4 *)((int)pvVar5 + 0x2c) = 4;
    *(undefined4 *)((int)pvVar5 + 0x1c) = 4;
    local_64 = 2;
    *(undefined4 *)((int)pvVar5 + 0xc) = 1;
    local_60 = 1;
    pcVar6 = (char *)FUN_001201d4(unaff_r7,0);
    if (-1 < (int)pcVar6) {
      ppcVar7 = (char **)malloc(0xc);
      pcVar8 = strdup((char *)unaff_r7);
      uVar14 = 0;
      *ppcVar7 = pcVar8;
      ppcVar7[1] = (char *)0x0;
      ppcVar7[2] = pcVar6;
      if (ppcVar7 != (char **)0x0) {
        *(char ***)((int)local_30 + 0x3c) = ppcVar7;
        local_60 = 4;
        __aeabi_memclr8(&sStack_e0,0x68);
        if (param_3 != 0) {
          uVar13 = 0;
          uVar14 = 0;
LAB_00119ea4:
          pcVar6 = *(char **)(param_2 + uVar13 * 4);
          if (pcVar6 == (char *)0x0) {
            uVar14 = 0xfffffffe;
          }
          else {
            iVar9 = stat(pcVar6,&sStack_e0);
            if (iVar9 == 0) {
              uVar11 = sStack_e0.st_mode & 0xf000;
              uVar10 = sStack_e0.st_mode & 0xfff;
              if (uVar11 == 0x4000) {
                uVar10 = uVar10 | 0x4000;
              }
              if (uVar11 == 0x8000) {
                uVar10 = uVar10 | 0x8000;
              }
              if (uVar11 == 0xa000) {
                uVar10 = uVar10 | 0xa000;
              }
              if (uVar11 == 0x6000) {
                uVar10 = uVar10 | 0x6000;
              }
              if (uVar11 == 0x2000) {
                uVar10 = uVar10 | 0x2000;
              }
              if (uVar11 == 0x1000) {
                uVar10 = uVar10 | 0x1000;
              }
              if (uVar11 == 0xc000) {
                uVar10 = uVar10 | 0xc000;
              }
              bVar1 = true;
              uVar10 = ((sStack_e0.st_mode << 0x18) >> 0x1f | uVar10 << 0x10) ^ 1;
              cVar3 = *pcVar6;
              pcVar8 = pcVar6;
              pcVar2 = pcVar6 + 1;
              pcVar12 = pcVar6 + 1;
              if (cVar3 != '/' && cVar3 != '\\') goto LAB_00119f5c;
              do {
                do {
                  pcVar8 = pcVar2;
                  cVar3 = *pcVar8;
                  pcVar2 = pcVar8 + 1;
                  pcVar12 = pcVar8 + 1;
                } while (cVar3 == '/' || cVar3 == '\\');
LAB_00119f5c:
                do {
                  if (cVar3 == '\0') {
                    if (uVar11 == 0x4000) {
                      uVar10 = uVar10 | 0x10;
                    }
                    if (((*pcVar8 == '\0') && (*pcVar6 == '\\' || *pcVar6 == '/')) && (bVar1)) {
                      pcVar8 = pcVar8 + -1;
                    }
                    iVar9 = FUN_0011535c(&local_78,pcVar8,pcVar6,DAT_0011a05c + 0x119fd0,0,6,uVar10)
                    ;
                    uVar13 = uVar13 + 1;
                    if (iVar9 == 0) {
                      uVar14 = 0xffffffed;
                    }
                    if ((param_3 <= uVar13) || (iVar9 == 0)) goto LAB_0011a028;
                    goto LAB_00119ea4;
                  }
                  bVar1 = false;
                  cVar3 = *pcVar12;
                  pcVar2 = pcVar12 + 1;
                  pcVar12 = pcVar12 + 1;
                } while (cVar3 != '/' && cVar3 != '\\');
              } while( true );
            }
            uVar14 = 0xffffffed;
          }
        }
LAB_0011a028:
        FUN_001164ac(&local_78);
        FUN_00111a30(&local_78,1);
        return uVar14;
      }
    }
    FUN_00111a30(&local_78,1);
  }
  return 0xffffffff;
}

