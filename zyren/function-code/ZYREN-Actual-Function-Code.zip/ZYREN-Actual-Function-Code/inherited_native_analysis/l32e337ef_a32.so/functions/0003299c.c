/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003299c FUN_0003299c */

undefined4 FUN_0003299c(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_18;
  
  local_18 = 0;
  if (*(int *)(param_1 + 0x30) == 0) {
    if (*(int *)(param_1 + 0x2c) != 0) {
      local_18 = FUN_00032ce0(param_1,param_2,param_3);
    }
  }
  else {
    local_18 = FUN_00032a1c(param_1,param_2,param_3);
  }
  return local_18;
}

