/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030fb8 FUN_00030fb8 */

void FUN_00030fb8(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)(param_1 + 4);
  do {
    if (piVar2[-1] == 1) {
      iVar1 = FUN_00030f2c(param_2 + *piVar2,param_3);
      if (iVar1 != 0) {
        return;
      }
    }
    else if (piVar2[-1] == 0) {
      dlsym(0,param_3);
      return;
    }
    piVar2 = piVar2 + 2;
  } while( true );
}

