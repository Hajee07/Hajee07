/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0022d688 thunk_FUN_00281594 */

void thunk_FUN_00281594(undefined4 param_1,undefined4 param_2)

{
                    /* WARNING: Could not recover jumptable at 0x00281620. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_002815e0 + DAT_002815e0))(param_1,param_2);
  return;
}

