/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003272c FUN_0003272c */

void FUN_0003272c(int **param_1)

{
  int iVar1;
  char *__s2;
  int iVar2;
  int *piVar3;
  int **ppiVar4;
  char *local_2c;
  int **local_24;
  int **local_20;
  int *local_18;
  int **local_14;
  
  iVar1 = FUN_00031adc(param_1,DAT_00032998 + 0x32744);
  if (((iVar1 != 0) && (*(int *)(iVar1 + 0x14) != 0)) && (*(int *)(iVar1 + 0x1c) != 0)) {
    local_14 = (int **)0x0;
    for (local_18 = *(int **)(iVar1 + 0x14); *local_18 != 0; local_18 = local_18 + 2) {
      if ((*local_18 == 1) && (__s2 = (char *)(*(int *)(iVar1 + 0x1c) + local_18[1]), *__s2 != '\0')
         ) {
        local_24 = (int **)*param_1;
        while( true ) {
          if (local_24 != param_1) {
            local_20 = (int **)*local_24;
          }
          if (local_24 == param_1 || local_24 == (int **)0x0) break;
          local_2c = strrchr((char *)((int)local_24 + 0x3d),0x2f);
          if (local_2c == (char *)0x0) {
            local_2c = (char *)((int)local_24 + 0x3d);
          }
          else {
            local_2c = local_2c + 1;
          }
          iVar2 = strcmp(local_2c,__s2);
          if (iVar2 == 0) {
            piVar3 = *local_24;
            ppiVar4 = (int **)local_24[1];
            piVar3[1] = (int)ppiVar4;
            *ppiVar4 = piVar3;
            if (local_14 == (int **)0x0) {
              *local_24 = *param_1;
              local_24[1] = (int *)param_1;
              (*local_24)[1] = (int)local_24;
              *param_1 = (int *)local_24;
              local_14 = local_24;
            }
            else {
              *local_24 = *local_14;
              local_24[1] = (int *)local_14;
              (*local_24)[1] = (int)local_24;
              *local_14 = (int *)local_24;
            }
          }
          local_24 = local_20;
        }
      }
    }
  }
  return;
}

