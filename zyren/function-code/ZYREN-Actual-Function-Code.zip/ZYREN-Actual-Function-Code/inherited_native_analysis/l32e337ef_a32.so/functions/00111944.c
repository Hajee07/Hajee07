/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00111944 FUN_00111944 */

uint FUN_00111944(int param_1,undefined4 param_2,uint param_3,int param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  
  iVar7 = *(int *)(param_1 + 0x48);
  uVar6 = param_4 + (uint)CARRY4(param_6,param_3);
  uVar2 = (uint)((uint)(param_6 + param_3 <= *(uint *)(iVar7 + 0x4c)) <= -uVar6);
  uVar1 = *(uint *)(iVar7 + 0x4c);
  if (uVar2 != 0) {
    uVar2 = uVar6;
    uVar1 = param_6 + param_3;
  }
  if (param_6 != 0) {
    if (uVar2 == 0 && (0x7fffffff < uVar1) <= uVar2) {
      uVar6 = *(uint *)(iVar7 + 0x50);
      if (-uVar2 < (uint)(uVar1 <= uVar6)) {
        iVar4 = *(int *)(iVar7 + 0x48);
LAB_00111a0c:
        __aeabi_memcpy(iVar4 + param_3,param_5,param_6);
        *(uint *)(iVar7 + 0x4c) = uVar1;
        return param_6;
      }
      if (uVar6 < 0x41) {
        uVar6 = 0x40;
      }
      do {
        uVar5 = uVar6;
        uVar6 = uVar5 << 1;
      } while ((uint)(uVar1 <= uVar5) <= -uVar2);
      iVar4 = (**(code **)(param_1 + 0x30))
                        (*(undefined4 *)(param_1 + 0x34),*(undefined4 *)(iVar7 + 0x48),1,uVar5);
      if (iVar4 != 0) {
        *(uint *)(iVar7 + 0x50) = uVar5;
        *(int *)(iVar7 + 0x48) = iVar4;
        goto LAB_00111a0c;
      }
      uVar3 = 0x10;
    }
    else {
      uVar3 = 3;
    }
    *(undefined4 *)(param_1 + 0x1c) = uVar3;
  }
  return 0;
}

