/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030ee8 FUN_00030ee8 */

int FUN_00030ee8(int param_1,uint param_2)

{
  int iVar1;
  
  while( true ) {
    iVar1 = param_1 + *(int *)(param_1 + 8);
    while( true ) {
      if (*(ushort *)(iVar1 + 6) == param_2) {
        return param_1;
      }
      if (*(int *)(iVar1 + 0xc) == 0) break;
      iVar1 = iVar1 + *(int *)(iVar1 + 0xc);
    }
    if (*(int *)(param_1 + 0xc) == 0) break;
    param_1 = param_1 + *(int *)(param_1 + 0xc);
  }
  return 0;
}

