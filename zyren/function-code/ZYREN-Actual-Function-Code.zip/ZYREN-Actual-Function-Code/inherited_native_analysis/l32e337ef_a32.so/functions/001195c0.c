/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001195c0 FUN_001195c0 */

undefined4
FUN_001195c0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_r6;
  undefined auStack_70 [80];
  
  if (param_1 != 0) {
    unaff_r6 = param_3;
  }
  if (param_1 != 0 && param_3 != 0) {
    __aeabi_memclr8(auStack_70,0x50);
    iVar1 = FUN_0010c8a4(auStack_70,param_1,param_2,0);
    if (iVar1 != 0) {
      uVar2 = FUN_00119648(auStack_70,unaff_r6,param_4,param_5);
      return uVar2;
    }
  }
  return 0xffffffff;
}

