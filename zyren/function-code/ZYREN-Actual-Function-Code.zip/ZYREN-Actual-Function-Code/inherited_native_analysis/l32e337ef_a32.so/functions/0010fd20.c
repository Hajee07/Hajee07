/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010fd20 FUN_0010fd20 */

bool FUN_0010fd20(int *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  bool bVar4;
  
  if (param_1 == (int *)0x0) {
    return false;
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    param_3 = *(int *)(iVar3 + 0x48);
  }
  if (iVar3 == 0 || param_3 == 0) {
    return false;
  }
  bVar4 = param_1[2] == 0;
  if (bVar4) {
    bVar4 = (*(byte *)((int)param_1 + 5) & 4) == 0;
  }
  if (bVar4) {
    if ((param_1[0xc] ^ param_1[0x1a] | param_1[0xd] ^ param_1[0x1b]) == 0) {
      if (param_1[3] == param_1[0x17]) goto LAB_0010fd64;
      uVar2 = 0xb;
    }
    else {
      uVar2 = 0xd;
    }
    *(undefined4 *)(iVar3 + 0x1c) = uVar2;
    param_1[2] = -1;
    iVar1 = *(int *)(param_3 + 0x48);
  }
  else {
LAB_0010fd64:
    iVar1 = *(int *)(param_3 + 0x48);
  }
  if (iVar1 == 0) {
    (**(code **)(iVar3 + 0x2c))(*(undefined4 *)(iVar3 + 0x34),param_1[0x124]);
  }
  if (param_1[0x125] != 0) {
    (**(code **)(*param_1 + 0x2c))(*(undefined4 *)(*param_1 + 0x34));
  }
  iVar3 = param_1[2];
  (**(code **)(*param_1 + 0x2c))(*(undefined4 *)(*param_1 + 0x34),param_1);
  return iVar3 == 0;
}

