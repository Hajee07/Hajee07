/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d584 FUN_0021d584 */

char * FUN_0021d584(char *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  char cVar3;
  
  if (*param_2 != '\0') {
    cVar3 = *param_1;
    while (cVar3 != '\0') {
      iVar2 = 1;
      cVar1 = *param_2;
      do {
        if ((cVar1 == '\0') || (cVar3 != cVar1)) break;
        cVar3 = param_1[iVar2];
        cVar1 = param_2[iVar2];
        iVar2 = iVar2 + 1;
      } while (cVar3 != '\0');
      if (cVar1 == '\0') {
        return param_1;
      }
      param_1 = param_1 + 1;
      cVar3 = *param_1;
    }
    param_1 = (char *)0x0;
  }
  return param_1;
}

