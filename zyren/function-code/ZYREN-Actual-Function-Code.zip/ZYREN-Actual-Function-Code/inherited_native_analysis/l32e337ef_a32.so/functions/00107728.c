/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00107728 FUN_00107728 */

int FUN_00107728(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5)

{
  int iVar1;
  undefined4 local_58;
  undefined4 local_54;
  undefined auStack_50 [4];
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  int local_3c;
  code *local_34;
  undefined4 local_30;
  
  __aeabi_memclr8(auStack_50,0x30);
  local_48 = *param_2;
  local_58 = param_3;
  local_54 = param_4;
  local_4c = param_1;
  iVar1 = FUN_00105de4(&local_58,param_5,8,0xf,9,0);
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = FUN_001065d0(&local_58,4);
  if (iVar1 == 1) {
    *param_2 = local_44;
    if (local_3c != 0) {
      (*local_34)(local_30);
      return 0;
    }
    return 0;
  }
  if (local_3c != 0) {
    (*local_34)(local_30);
  }
  if (iVar1 == 0) {
    iVar1 = -5;
  }
  return iVar1;
}

