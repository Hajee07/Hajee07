/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110d90 FUN_00110d90 */

undefined4 FUN_00110d90(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  undefined auStack_480 [80];
  undefined auStack_430 [1028];
  uint local_2c [2];
  
  if (param_1 != 0) {
    piVar1 = *(int **)(param_1 + 0x48);
    if (piVar1 != (int *)0x0) {
      iVar2 = *(int *)(param_1 + 0x28);
      bVar4 = iVar2 != 0;
      if (bVar4) {
        iVar2 = *(int *)(param_1 + 0x2c);
      }
      if ((bVar4 && iVar2 != 0) && (*(int *)(param_1 + 0x38) != 0)) {
        iVar2 = piVar1[0xd];
        uVar3 = *(uint *)(param_1 + 0x10);
        if (iVar2 == 0) {
          if ((0xffff < uVar3) || (*(int *)(param_1 + 4) != 0)) goto LAB_00110e2c;
        }
        else {
          if (uVar3 != 0xffffffff) {
            iVar2 = piVar1[1];
          }
          if (uVar3 == 0xffffffff || iVar2 == -1) {
LAB_00110e2c:
            *(undefined4 *)(param_1 + 0x1c) = 0x1d;
            return 0;
          }
        }
        if (uVar3 == 0) {
          return 1;
        }
        if ((param_2 & 0x1000) == 0) {
          uVar3 = 0;
          do {
            iVar2 = FUN_00110218(param_1,uVar3,param_2);
            if (iVar2 == 0) {
              return 0;
            }
            uVar3 = uVar3 + 1;
          } while (uVar3 < *(uint *)(param_1 + 0x10));
          return 1;
        }
        uVar3 = 0;
        while( true ) {
          iVar2 = 0;
          if (piVar1 != (int *)0x0) {
            iVar2 = *piVar1 + *(int *)(piVar1[4] + uVar3 * 4);
          }
          iVar2 = FUN_001107b8(param_1,uVar3,iVar2,auStack_480,0);
          if (iVar2 == 0) {
            return 0;
          }
          iVar2 = FUN_0010d5e8(param_1,auStack_430,0,0,local_2c);
          if (iVar2 == 0) {
            return 0;
          }
          if (uVar3 != local_2c[0]) break;
          iVar2 = FUN_00110218(param_1,uVar3,param_2);
          if (iVar2 == 0) {
            return 0;
          }
          uVar3 = uVar3 + 1;
          if (*(uint *)(param_1 + 0x10) <= uVar3) {
            return 1;
          }
          piVar1 = *(int **)(param_1 + 0x48);
        }
        *(undefined4 *)(param_1 + 0x1c) = 0x1e;
        return 0;
      }
    }
    *(undefined4 *)(param_1 + 0x1c) = 0x18;
  }
  return 0;
}

