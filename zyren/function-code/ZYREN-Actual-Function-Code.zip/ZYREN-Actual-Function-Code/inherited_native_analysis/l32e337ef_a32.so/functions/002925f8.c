/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002925f8 __aeabi_memcpy */

void __aeabi_memcpy(void)

{
  (*(code *)PTR___aeabi_memcpy_00307d7c)();
  return;
}

