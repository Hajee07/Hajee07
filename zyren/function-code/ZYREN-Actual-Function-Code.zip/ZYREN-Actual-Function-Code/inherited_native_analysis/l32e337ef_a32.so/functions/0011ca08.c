/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011ca08 FUN_0011ca08 */

undefined4 FUN_0011ca08(int param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  
  uVar1 = FUN_0011c904(param_2);
  uVar2 = FUN_0011c904(param_1);
  if ((uVar1 <= uVar2) && (iVar3 = FUN_0011d208(param_1 + (uVar2 - uVar1),param_2), iVar3 == 0)) {
    return 1;
  }
  return 0;
}

