/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011a060 FUN_0011a060 */

undefined4 FUN_0011a060(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int unaff_r6;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_70 [80];
  
  if (param_1 != 0) {
    unaff_r6 = param_2;
  }
  if (param_1 == 0 || param_2 == 0) {
    return 0xffffffea;
  }
  __aeabi_memclr8(auStack_70,0x50);
  uVar2 = 0;
  uVar3 = 0;
  uVar4 = 0;
  uVar5 = 0;
  iVar1 = FUN_0010cac4(auStack_70,param_1,0);
  if (iVar1 != 0) {
    uVar2 = FUN_00119648(auStack_70,unaff_r6,param_3,param_4,uVar2,uVar3,uVar4,uVar5);
    return uVar2;
  }
  return 0xffffffff;
}

