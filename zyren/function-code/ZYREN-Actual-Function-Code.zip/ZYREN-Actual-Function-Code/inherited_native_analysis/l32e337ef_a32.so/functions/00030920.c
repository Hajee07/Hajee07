/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030920 FUN_00030920 */

int FUN_00030920(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = param_1[10];
  iVar2 = param_1[0xb];
  iVar4 = iVar3 + *(int *)(iVar2 + param_2 * 0x10);
  if ((param_1[0xe] == 0) || (*(ushort *)(param_1[0xe] + param_2 * 2) < 2)) {
    iVar1 = iVar2 + param_2 * 0x10;
    if (*(short *)(iVar1 + 0xe) == 0) {
      iVar1 = FUN_00030fb8(param_1[3],iVar3,iVar4);
    }
    else {
      iVar1 = (*param_1 - param_1[2]) + *(int *)(iVar1 + 4);
    }
    iVar3 = 0;
  }
  else {
    iVar1 = FUN_00030ee8(param_1[0xc]);
    iVar3 = iVar3 + *(int *)(iVar1 + 4);
    iVar1 = FUN_00030f2c(iVar3,iVar4);
  }
  if ((iVar1 == 0) && ((*(byte *)(iVar2 + param_2 * 0x10 + 0xc) & 0xf0) != 0x20)) {
    if (iVar3 == 0) {
      iVar3 = DAT_00030a1c + 0x309f8;
    }
    __android_log_print(4,DAT_00030a1c + 0x309f8,DAT_00030a18 + 0x309f0,iVar3,iVar4);
  }
  return iVar1;
}

