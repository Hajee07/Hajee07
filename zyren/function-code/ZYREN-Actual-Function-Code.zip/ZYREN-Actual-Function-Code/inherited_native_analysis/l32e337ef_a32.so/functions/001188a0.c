/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001188a0 FUN_001188a0 */

undefined4 FUN_001188a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_1 != 0) {
    uVar2 = 0xfffffffd;
    if ((*(int *)(param_1 + 0x14) == 1) && (-1 < *(int *)(param_1 + 0x58))) {
      uVar2 = 0;
      iVar1 = FUN_0010e71c(param_1,*(int *)(param_1 + 0x58),param_2,param_3,0);
      if (iVar1 == 0) {
        uVar2 = 0xfffffff6;
      }
    }
    return uVar2;
  }
  return 0xffffffff;
}

