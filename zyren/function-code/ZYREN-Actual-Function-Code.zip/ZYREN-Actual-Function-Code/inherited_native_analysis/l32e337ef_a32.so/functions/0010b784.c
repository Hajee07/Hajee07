/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b784 FUN_0010b784 */

undefined4 FUN_0010b784(void *param_1)

{
  void *pvVar1;
  undefined4 uVar2;
  void *unaff_r4;
  
  pvVar1 = param_1;
  if (param_1 != (void *)0x0) {
    pvVar1 = *(void **)((int)param_1 + 8);
    unaff_r4 = param_1;
  }
  if (param_1 != (void *)0x0 && pvVar1 != (void *)0x0) {
    uVar2 = FUN_00120238();
    free(unaff_r4);
    return uVar2;
  }
  return 0xffffffff;
}

