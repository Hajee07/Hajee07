/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031010 FUN_00031010 */

undefined4 FUN_00031010(char *param_1)

{
  char *pcVar1;
  ssize_t sVar2;
  FILE *__stream;
  size_t sVar3;
  undefined4 uVar4;
  ulonglong uVar5;
  char acStack_524 [260];
  char acStack_420 [1024];
  
  pcVar1 = strstr(param_1,(char *)(DAT_00031180 + 0x31030));
  uVar4 = 0;
  if (pcVar1 != (char *)0x0) {
    strcpy(acStack_420,(char *)(DAT_00031184 + 0x31048));
    strcat(acStack_420,param_1);
    sVar2 = readlink(acStack_420,acStack_524,0x104);
    if (sVar2 == -1 || sVar2 + 1 < 0 != SCARRY4(sVar2,1)) {
      __android_log_print(4,DAT_00031188 + 0x31148,DAT_0003118c + 0x31150);
    }
    else {
      uVar4 = 0;
      acStack_524[sVar2] = '\0';
      __stream = fopen((char *)(DAT_00031190 + 0x31084),(char *)(DAT_00031194 + 0x3108c));
      if (__stream == (FILE *)0x0) {
        __android_log_print(4,DAT_00031198 + 0x31164,DAT_0003119c + 0x3116c);
        uVar4 = 0;
      }
      else {
        pcVar1 = fgets(acStack_420,0x400,__stream);
        if (pcVar1 != (char *)0x0) {
          do {
            sVar3 = strlen(acStack_420);
            if ((sVar3 != 0) && (pcVar1 = strstr(acStack_420,acStack_524), pcVar1 != (char *)0x0)) {
              pcVar1 = strchr(acStack_420,0x2d);
              *pcVar1 = '\0';
              uVar5 = strtoull(acStack_420,(char **)0x0,0x10);
              uVar4 = (undefined4)uVar5;
              break;
            }
            pcVar1 = fgets(acStack_420,0x400,__stream);
          } while (pcVar1 != (char *)0x0);
        }
        fclose(__stream);
      }
    }
  }
  return uVar4;
}

