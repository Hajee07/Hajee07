/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001172ac FUN_001172ac */

void * FUN_001172ac(int param_1,int param_2,uint param_3)

{
  void *__ptr;
  int iVar1;
  int unaff_r4;
  
  if (param_1 != 0) {
    unaff_r4 = param_2;
  }
  if (param_1 != 0 && param_2 != 0) {
    if ((int)param_3 < 0) {
      param_3 = 6;
    }
    if (((param_3 & 0xf) < 0xb) && (__ptr = calloc(1,0x4e010), __ptr != (void *)0x0)) {
      *(uint *)((int)__ptr + 0x50) = param_3;
      iVar1 = FUN_0010c8a4(__ptr,param_1,unaff_r4,param_3 | 0x800);
      if (iVar1 != 0) {
        return __ptr;
      }
      free(__ptr);
    }
  }
  return (void *)0x0;
}

