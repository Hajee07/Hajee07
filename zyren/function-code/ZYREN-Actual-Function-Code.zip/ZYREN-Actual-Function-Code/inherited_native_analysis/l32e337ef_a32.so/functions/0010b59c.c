/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b59c FUN_0010b59c */

undefined4
FUN_0010b59c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  int iVar1;
  undefined4 local_2b08 [2748];
  undefined4 local_18;
  undefined4 local_14;
  
  local_2b08[0] = 0;
  local_18 = param_4;
  local_14 = param_2;
  iVar1 = FUN_001081f0(local_2b08,param_3,&local_18,param_1,param_1,&local_14,
                       param_5 & 0xfffffff9 | 4);
  if (iVar1 != 0) {
    local_14 = 0xffffffff;
  }
  return local_14;
}

