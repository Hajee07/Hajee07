/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002925bc __cxa_atexit */

void __cxa_atexit(void)

{
  (*(code *)PTR___cxa_atexit_00307d68)();
  return;
}

