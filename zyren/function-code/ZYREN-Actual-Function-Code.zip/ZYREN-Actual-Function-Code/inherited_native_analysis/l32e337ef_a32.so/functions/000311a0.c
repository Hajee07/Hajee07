/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000311a0 FUN_000311a0 */

undefined4 FUN_000311a0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  
  uVar5 = (uint)*(ushort *)(param_1 + 0x2c);
  if (uVar5 != 0) {
    piVar2 = (int *)(param_1 + *(int *)(param_1 + 0x1c));
    uVar8 = 0;
    if (*piVar2 != 1) {
      uVar7 = 1;
      do {
        uVar5 = (uint)*(ushort *)(param_1 + 0x2c);
        uVar8 = uVar7 & 0xffff;
        if (uVar8 == uVar5) {
          param_1 = 0;
          if (uVar5 == 0) {
            return 0;
          }
          goto LAB_00031218;
        }
        uVar7 = uVar7 + 1;
      } while (piVar2[uVar8 * 8] != 1);
    }
    param_1 = param_1 - piVar2[uVar8 * 8 + 2];
    if (uVar5 != 0) {
LAB_00031218:
      uVar8 = 0;
      do {
        uVar7 = uVar8 & 0xffff;
        if (piVar2[uVar7 * 8] == 2) {
          puVar3 = (uint *)(piVar2[uVar7 * 8 + 2] + param_1);
          if (puVar3 != (uint *)0x0) {
            uVar7 = *puVar3;
          }
          if (puVar3 == (uint *)0x0 || uVar7 == 0) {
            return 0;
          }
          puVar3 = puVar3 + 1;
          iVar6 = 0;
          iVar10 = 0;
          iVar4 = 0;
          iVar9 = 0;
          do {
            uVar5 = *puVar3;
            if (uVar5 != 0) {
              if ((int)uVar7 < 6) {
                if (uVar7 == 4) {
                  iVar6 = uVar5 + param_1;
                }
                else if (uVar7 == 5) {
                  iVar4 = uVar5 + param_1;
                }
              }
              else if (uVar7 == 0x6ffffef5) {
                iVar10 = uVar5 + param_1;
              }
              else if (uVar7 == 6) {
                iVar9 = uVar5 + param_1;
              }
            }
            uVar7 = puVar3[1];
            puVar3 = puVar3 + 2;
          } while (uVar7 != 0);
          if (iVar9 == 0 || iVar4 == 0) {
            return 0;
          }
          if (iVar10 != 0) {
            uVar1 = FUN_00030380(param_1,iVar9,iVar4,iVar10,param_2);
            return uVar1;
          }
          if (iVar6 == 0) {
            return 0;
          }
          uVar1 = FUN_00030488(param_1,iVar9,iVar4,iVar6,param_2);
          return uVar1;
        }
        uVar8 = uVar8 + 1;
      } while ((uVar8 & 0xffff) != uVar5);
    }
  }
  return 0;
}

