/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00119ba8 FUN_00119ba8 */

void * FUN_00119ba8(int param_1,int param_2,uint param_3,int param_4)

{
  void *__ptr;
  int iVar1;
  
  __ptr = calloc(1,0x4e010);
  if (__ptr == (void *)0x0) {
    return (void *)0x0;
  }
  if ((int)param_3 < 0) {
    param_3 = 6;
  }
  if ((param_3 & 0xf) < 0xb) {
    *(uint *)((int)__ptr + 0x50) = param_3;
    if ((param_1 == 0 || param_2 == 0) || (param_4 != 0x72)) {
      if ((param_1 != 0) || (param_2 != 0 || param_4 != 0x77)) goto LAB_00119c58;
      iVar1 = FUN_00111bbc(__ptr,0,0x400);
    }
    else {
      iVar1 = FUN_0010c8a4(__ptr,param_1,param_2,0);
    }
    if (iVar1 != 0) {
      return __ptr;
    }
  }
LAB_00119c58:
  free(__ptr);
  return (void *)0x0;
}

