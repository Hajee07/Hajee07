/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001168f4 FUN_001168f4 */

undefined4 FUN_001168f4(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *unaff_r6;
  
  if (param_2 != (undefined4 *)0x0) {
    unaff_r6 = param_3;
  }
  if (param_2 != (undefined4 *)0x0 && param_3 != (undefined4 *)0x0) {
    uVar2 = 0;
    *param_2 = 0;
    *unaff_r6 = 0;
    if (param_1 != 0) {
      if ((*(int *)(param_1 + 0x48) == 0) || (*(int *)(param_1 + 0x3c) != DAT_001169ac + 0x116954))
      goto LAB_00116958;
      iVar1 = FUN_001164ac(param_1);
      if (iVar1 != 0) {
        uVar2 = 1;
        *param_2 = *(undefined4 *)(*(int *)(param_1 + 0x48) + 0x48);
        iVar1 = *(int *)(param_1 + 0x48);
        *unaff_r6 = *(undefined4 *)(iVar1 + 0x4c);
        *(undefined4 *)(iVar1 + 0x48) = 0;
        *(undefined4 *)(iVar1 + 0x4c) = 0;
        *(undefined4 *)(iVar1 + 0x50) = 0;
      }
    }
  }
  else {
    uVar2 = 0;
    if (param_1 != 0) {
LAB_00116958:
      *(undefined4 *)(param_1 + 0x1c) = 0x18;
      return 0;
    }
  }
  return uVar2;
}

