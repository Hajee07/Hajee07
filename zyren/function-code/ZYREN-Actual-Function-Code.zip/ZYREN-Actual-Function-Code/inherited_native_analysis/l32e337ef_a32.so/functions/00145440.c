/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00145440 _DT_FINI */

void _DT_FINI(void)

{
  thunk_FUN_00150308();
                    /* WARNING: Could not recover jumptable at 0x0015f9ac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_0015f994 + *(int *)(&UNK_0015fba8 + DAT_0015f994) + DAT_0015f994))();
  return;
}

