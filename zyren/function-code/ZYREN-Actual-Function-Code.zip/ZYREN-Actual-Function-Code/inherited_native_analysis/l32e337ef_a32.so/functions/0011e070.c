/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011e070 FUN_0011e070 */

void FUN_0011e070(uint *param_1,uint *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  uint uVar34;
  uint uVar35;
  uint uVar36;
  uint uVar37;
  int iVar38;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  uint uVar42;
  uint uVar43;
  uint uVar44;
  uint uVar45;
  uint uVar46;
  uint uVar47;
  uint uVar48;
  uint uVar49;
  uint uVar50;
  uint uVar51;
  
  uVar13 = *param_1;
  uVar26 = param_1[1];
  uVar29 = param_1[2];
  uVar45 = param_1[3];
  uVar3 = *param_2;
  uVar4 = uVar3 << 0x18 | (uVar3 >> 8 & 0xff) << 0x10 | (uVar3 >> 0x10 & 0xff) << 8 | uVar3 >> 0x18;
  uVar3 = param_2[1];
  uVar11 = uVar4 + (uVar13 >> 0x1b | uVar13 << 5) + param_1[4] +
           ((uVar45 ^ uVar29) & uVar26 ^ uVar45) + 0x5a827999;
  uVar5 = uVar3 << 0x18 | (uVar3 >> 8 & 0xff) << 0x10 | (uVar3 >> 0x10 & 0xff) << 8 | uVar3 >> 0x18;
  uVar30 = uVar5 + uVar45 + ((uVar29 ^ (uVar26 >> 2 | uVar26 << 0x1e)) & uVar13 ^ uVar29) +
           (uVar11 >> 0x1b | uVar11 * 0x20) + 0x5a827999;
  uVar3 = param_2[2];
  uVar3 = uVar3 << 0x18 | (uVar3 >> 8 & 0xff) << 0x10 | (uVar3 >> 0x10 & 0xff) << 8 | uVar3 >> 0x18;
  uVar48 = param_2[3];
  uVar6 = uVar3 + uVar29 +
          (uVar11 & ((uVar26 >> 2 | uVar26 << 0x1e) ^ (uVar13 >> 2 | uVar13 << 0x1e)) ^
          (uVar26 >> 2 | uVar26 << 0x1e)) + (uVar30 >> 0x1b | uVar30 * 0x20) + 0x5a827999;
  uVar48 = uVar48 << 0x18 | (uVar48 >> 8 & 0xff) << 0x10 | (uVar48 >> 0x10 & 0xff) << 8 |
           uVar48 >> 0x18;
  uVar27 = param_2[4];
  uVar9 = uVar27 << 0x18 | (uVar27 >> 8 & 0xff) << 0x10 | (uVar27 >> 0x10 & 0xff) << 8 |
          uVar27 >> 0x18;
  uVar14 = param_2[5];
  uVar27 = uVar48 + (uVar26 >> 2 | uVar26 << 0x1e) +
           (uVar30 & ((uVar11 >> 2 | uVar11 * 0x40000000) ^ (uVar13 >> 2 | uVar13 << 0x1e)) ^
           (uVar13 >> 2 | uVar13 << 0x1e)) + (uVar6 >> 0x1b | uVar6 * 0x20) + 0x5a827999;
  uVar15 = uVar14 << 0x18 | (uVar14 >> 8 & 0xff) << 0x10 | (uVar14 >> 0x10 & 0xff) << 8 |
           uVar14 >> 0x18;
  uVar16 = param_2[6];
  uVar14 = uVar9 + (uVar13 >> 2 | uVar13 << 0x1e) +
           (uVar6 & ((uVar30 >> 2 | uVar30 * 0x40000000) ^ (uVar11 >> 2 | uVar11 * 0x40000000)) ^
           (uVar11 >> 2 | uVar11 * 0x40000000)) + (uVar27 >> 0x1b | uVar27 * 0x20) + 0x5a827999;
  uVar17 = uVar16 << 0x18 | (uVar16 >> 8 & 0xff) << 0x10 | (uVar16 >> 0x10 & 0xff) << 8 |
           uVar16 >> 0x18;
  uVar16 = param_2[7];
  uVar11 = uVar15 + (uVar11 >> 2 | uVar11 * 0x40000000) +
           (uVar27 & ((uVar6 >> 2 | uVar6 * 0x40000000) ^ (uVar30 >> 2 | uVar30 * 0x40000000)) ^
           (uVar30 >> 2 | uVar30 * 0x40000000)) + (uVar14 >> 0x1b | uVar14 * 0x20) + 0x5a827999;
  uVar18 = uVar16 << 0x18 | (uVar16 >> 8 & 0xff) << 0x10 | (uVar16 >> 0x10 & 0xff) << 8 |
           uVar16 >> 0x18;
  uVar31 = uVar17 + (uVar30 >> 2 | uVar30 * 0x40000000) +
           (uVar14 & ((uVar27 >> 2 | uVar27 * 0x40000000) ^ (uVar6 >> 2 | uVar6 * 0x40000000)) ^
           (uVar6 >> 2 | uVar6 * 0x40000000)) + (uVar11 >> 0x1b | uVar11 * 0x20) + 0x5a827999;
  uVar16 = param_2[8];
  uVar28 = uVar18 + (uVar6 >> 2 | uVar6 * 0x40000000) +
           (uVar11 & ((uVar14 >> 2 | uVar14 * 0x40000000) ^ (uVar27 >> 2 | uVar27 * 0x40000000)) ^
           (uVar27 >> 2 | uVar27 * 0x40000000)) + (uVar31 >> 0x1b | uVar31 * 0x20) + 0x5a827999;
  uVar19 = uVar16 << 0x18 | (uVar16 >> 8 & 0xff) << 0x10 | (uVar16 >> 0x10 & 0xff) << 8 |
           uVar16 >> 0x18;
  uVar6 = param_2[9];
  uVar20 = uVar6 << 0x18 | (uVar6 >> 8 & 0xff) << 0x10 | (uVar6 >> 0x10 & 0xff) << 8 | uVar6 >> 0x18
  ;
  uVar27 = uVar19 + (uVar27 >> 2 | uVar27 * 0x40000000) +
           (uVar31 & ((uVar11 >> 2 | uVar11 * 0x40000000) ^ (uVar14 >> 2 | uVar14 * 0x40000000)) ^
           (uVar14 >> 2 | uVar14 * 0x40000000)) + (uVar28 >> 0x1b | uVar28 * 0x20) + 0x5a827999;
  uVar6 = param_2[10];
  uVar39 = uVar20 + (uVar14 >> 2 | uVar14 * 0x40000000) +
           (uVar28 & ((uVar31 >> 2 | uVar31 * 0x40000000) ^ (uVar11 >> 2 | uVar11 * 0x40000000)) ^
           (uVar11 >> 2 | uVar11 * 0x40000000)) + (uVar27 >> 0x1b | uVar27 * 0x20) + 0x5a827999;
  uVar16 = uVar6 << 0x18 | (uVar6 >> 8 & 0xff) << 0x10 | (uVar6 >> 0x10 & 0xff) << 8 | uVar6 >> 0x18
  ;
  uVar6 = param_2[0xb];
  uVar30 = uVar6 << 0x18 | (uVar6 >> 8 & 0xff) << 0x10 | (uVar6 >> 0x10 & 0xff) << 8 | uVar6 >> 0x18
  ;
  uVar6 = uVar16 + (uVar11 >> 2 | uVar11 * 0x40000000) +
          (uVar27 & ((uVar28 >> 2 | uVar28 * 0x40000000) ^ (uVar31 >> 2 | uVar31 * 0x40000000)) ^
          (uVar31 >> 2 | uVar31 * 0x40000000)) + (uVar39 >> 0x1b | uVar39 * 0x20) + 0x5a827999;
  uVar11 = param_2[0xd];
  uVar14 = param_2[0xc];
  uVar32 = uVar11 << 0x18 | (uVar11 >> 8 & 0xff) << 0x10 | (uVar11 >> 0x10 & 0xff) << 8 |
           uVar11 >> 0x18;
  uVar31 = uVar30 + (uVar31 >> 2 | uVar31 * 0x40000000) +
           (uVar39 & ((uVar27 >> 2 | uVar27 * 0x40000000) ^ (uVar28 >> 2 | uVar28 * 0x40000000)) ^
           (uVar28 >> 2 | uVar28 * 0x40000000)) + (uVar6 >> 0x1b | uVar6 * 0x20) + 0x5a827999;
  uVar12 = uVar14 << 0x18 | (uVar14 >> 8 & 0xff) << 0x10 | (uVar14 >> 0x10 & 0xff) << 8 |
           uVar14 >> 0x18;
  uVar14 = param_2[0xe];
  uVar11 = uVar12 + (uVar28 >> 2 | uVar28 * 0x40000000) +
           (uVar6 & ((uVar39 >> 2 | uVar39 * 0x40000000) ^ (uVar27 >> 2 | uVar27 * 0x40000000)) ^
           (uVar27 >> 2 | uVar27 * 0x40000000)) + (uVar31 >> 0x1b | uVar31 * 0x20) + 0x5a827999;
  uVar33 = uVar14 << 0x18 | (uVar14 >> 8 & 0xff) << 0x10 | (uVar14 >> 0x10 & 0xff) << 8 |
           uVar14 >> 0x18;
  uVar28 = param_2[0xf];
  uVar14 = uVar32 + (uVar27 >> 2 | uVar27 * 0x40000000) +
           (uVar31 & ((uVar6 >> 2 | uVar6 * 0x40000000) ^ (uVar39 >> 2 | uVar39 * 0x40000000)) ^
           (uVar39 >> 2 | uVar39 * 0x40000000)) + (uVar11 >> 0x1b | uVar11 * 0x20) + 0x5a827999;
  uVar40 = uVar28 << 0x18 | (uVar28 >> 8 & 0xff) << 0x10 | (uVar28 >> 0x10 & 0xff) << 8 |
           uVar28 >> 0x18;
  uVar27 = uVar33 + (uVar39 >> 2 | uVar39 * 0x40000000) +
           (uVar11 & ((uVar31 >> 2 | uVar31 * 0x40000000) ^ (uVar6 >> 2 | uVar6 * 0x40000000)) ^
           (uVar6 >> 2 | uVar6 * 0x40000000)) + (uVar14 >> 0x1b | uVar14 * 0x20) + 0x5a827999;
  uVar6 = uVar40 + (uVar6 >> 2 | uVar6 * 0x40000000) +
          (uVar14 & ((uVar11 >> 2 | uVar11 * 0x40000000) ^ (uVar31 >> 2 | uVar31 * 0x40000000)) ^
          (uVar31 >> 2 | uVar31 * 0x40000000)) + (uVar27 >> 0x1b | uVar27 * 0x20) + 0x5a827999;
  uVar21 = uVar3 ^ uVar4 ^ uVar19 ^ uVar32;
  uVar49 = (uVar21 >> 0x1f | uVar21 << 1) + (uVar31 >> 2 | uVar31 * 0x40000000) +
           (uVar27 & ((uVar14 >> 2 | uVar14 * 0x40000000) ^ (uVar11 >> 2 | uVar11 * 0x40000000)) ^
           (uVar11 >> 2 | uVar11 * 0x40000000)) + (uVar6 >> 0x1b | uVar6 * 0x20) + 0x5a827999;
  uVar34 = uVar48 ^ uVar5 ^ uVar20 ^ uVar33;
  uVar39 = (uVar34 >> 0x1f | uVar34 << 1) + (uVar11 >> 2 | uVar11 * 0x40000000) +
           (uVar6 & ((uVar27 >> 2 | uVar27 * 0x40000000) ^ (uVar14 >> 2 | uVar14 * 0x40000000)) ^
           (uVar14 >> 2 | uVar14 * 0x40000000)) + (uVar49 >> 0x1b | uVar49 * 0x20) + 0x5a827999;
  uVar22 = uVar9 ^ uVar3 ^ uVar16 ^ uVar40;
  uVar3 = uVar22 >> 0x1f | uVar22 << 1;
  uVar28 = uVar3 + (uVar14 >> 2 | uVar14 * 0x40000000) +
           (uVar49 & ((uVar6 >> 2 | uVar6 * 0x40000000) ^ (uVar27 >> 2 | uVar27 * 0x40000000)) ^
           (uVar27 >> 2 | uVar27 * 0x40000000)) + (uVar39 >> 0x1b | uVar39 * 0x20) + 0x5a827999;
  uVar23 = uVar15 ^ uVar48 ^ uVar30 ^ (uVar21 >> 0x1f | uVar21 << 1);
  uVar48 = uVar23 >> 0x1f | uVar23 << 1;
  uVar14 = uVar48 + (uVar27 >> 2 | uVar27 * 0x40000000) +
           (uVar39 & ((uVar49 >> 2 | uVar49 * 0x40000000) ^ (uVar6 >> 2 | uVar6 * 0x40000000)) ^
           (uVar6 >> 2 | uVar6 * 0x40000000)) + (uVar28 >> 0x1b | uVar28 * 0x20) + 0x5a827999;
  uVar24 = uVar17 ^ uVar9 ^ uVar12 ^ (uVar34 >> 0x1f | uVar34 << 1);
  uVar27 = uVar24 >> 0x1f | uVar24 << 1;
  uVar11 = uVar27 + (uVar6 >> 2 | uVar6 * 0x40000000) +
           ((uVar39 >> 2 | uVar39 * 0x40000000) ^ (uVar49 >> 2 | uVar49 * 0x40000000) ^ uVar28) +
           (uVar14 >> 0x1b | uVar14 * 0x20) + 0x6ed9eba1;
  uVar31 = uVar18 ^ uVar15 ^ uVar32 ^ (uVar22 >> 0x1f | uVar22 << 1);
  uVar4 = uVar31 >> 0x1f | uVar31 << 1;
  uVar15 = uVar4 + (uVar49 >> 2 | uVar49 * 0x40000000) +
           ((uVar28 >> 2 | uVar28 * 0x40000000) ^ (uVar39 >> 2 | uVar39 * 0x40000000) ^ uVar14) +
           (uVar11 >> 0x1b | uVar11 * 0x20) + 0x6ed9eba1;
  uVar35 = uVar19 ^ uVar17 ^ uVar33 ^ (uVar23 >> 0x1f | uVar23 << 1);
  uVar5 = uVar35 >> 0x1f | uVar35 << 1;
  uVar46 = uVar5 + (uVar39 >> 2 | uVar39 * 0x40000000) +
           ((uVar14 >> 2 | uVar14 * 0x40000000) ^ (uVar28 >> 2 | uVar28 * 0x40000000) ^ uVar11) +
           (uVar15 >> 0x1b | uVar15 * 0x20) + 0x6ed9eba1;
  uVar25 = uVar20 ^ uVar18 ^ uVar40 ^ (uVar24 >> 0x1f | uVar24 << 1);
  uVar6 = uVar25 >> 0x1f | uVar25 << 1;
  uVar50 = uVar6 + (uVar28 >> 2 | uVar28 * 0x40000000) +
           ((uVar11 >> 2 | uVar11 * 0x40000000) ^ (uVar14 >> 2 | uVar14 * 0x40000000) ^ uVar15) +
           (uVar46 >> 0x1b | uVar46 * 0x20) + 0x6ed9eba1;
  uVar39 = uVar16 ^ uVar19 ^ (uVar21 >> 0x1f | uVar21 << 1) ^ (uVar31 >> 0x1f | uVar31 << 1);
  uVar9 = uVar39 >> 0x1f | uVar39 << 1;
  uVar28 = uVar9 + (uVar14 >> 2 | uVar14 * 0x40000000) +
           ((uVar15 >> 2 | uVar15 * 0x40000000) ^ (uVar11 >> 2 | uVar11 * 0x40000000) ^ uVar46) +
           (uVar50 >> 0x1b | uVar50 * 0x20) + 0x6ed9eba1;
  uVar43 = uVar30 ^ uVar20 ^ (uVar34 >> 0x1f | uVar34 << 1) ^ (uVar35 >> 0x1f | uVar35 << 1);
  uVar14 = uVar43 >> 0x1f | uVar43 << 1;
  uVar17 = uVar14 + (uVar11 >> 2 | uVar11 * 0x40000000) +
           ((uVar46 >> 2 | uVar46 * 0x40000000) ^ (uVar15 >> 2 | uVar15 * 0x40000000) ^ uVar50) +
           (uVar28 >> 0x1b | uVar28 * 0x20) + 0x6ed9eba1;
  uVar41 = uVar12 ^ uVar16 ^ (uVar22 >> 0x1f | uVar22 << 1) ^ (uVar25 >> 0x1f | uVar25 << 1);
  uVar11 = uVar41 >> 0x1f | uVar41 << 1;
  uVar18 = uVar11 + (uVar15 >> 2 | uVar15 * 0x40000000) +
           ((uVar50 >> 2 | uVar50 * 0x40000000) ^ (uVar46 >> 2 | uVar46 * 0x40000000) ^ uVar28) +
           (uVar17 >> 0x1b | uVar17 * 0x20) + 0x6ed9eba1;
  uVar49 = uVar32 ^ uVar30 ^ (uVar23 >> 0x1f | uVar23 << 1) ^ (uVar39 >> 0x1f | uVar39 << 1);
  uVar15 = uVar49 >> 0x1f | uVar49 << 1;
  uVar20 = uVar15 + (uVar46 >> 2 | uVar46 * 0x40000000) +
           ((uVar28 >> 2 | uVar28 * 0x40000000) ^ (uVar50 >> 2 | uVar50 * 0x40000000) ^ uVar17) +
           (uVar18 >> 0x1b | uVar18 * 0x20) + 0x6ed9eba1;
  uVar44 = uVar33 ^ uVar12 ^ (uVar24 >> 0x1f | uVar24 << 1) ^ (uVar43 >> 0x1f | uVar43 << 1);
  uVar16 = uVar44 >> 0x1f | uVar44 << 1;
  uVar50 = uVar16 + (uVar50 >> 2 | uVar50 * 0x40000000) +
           ((uVar17 >> 2 | uVar17 * 0x40000000) ^ (uVar28 >> 2 | uVar28 * 0x40000000) ^ uVar18) +
           (uVar20 >> 0x1b | uVar20 * 0x20) + 0x6ed9eba1;
  uVar46 = uVar40 ^ uVar32 ^ (uVar31 >> 0x1f | uVar31 << 1) ^ (uVar41 >> 0x1f | uVar41 << 1);
  uVar30 = uVar46 >> 0x1f | uVar46 << 1;
  uVar19 = uVar30 + (uVar28 >> 2 | uVar28 * 0x40000000) +
           ((uVar18 >> 2 | uVar18 * 0x40000000) ^ (uVar17 >> 2 | uVar17 * 0x40000000) ^ uVar20) +
           (uVar50 >> 0x1b | uVar50 * 0x20) + 0x6ed9eba1;
  uVar32 = uVar33 ^ (uVar21 >> 0x1f | uVar21 << 1) ^ (uVar35 >> 0x1f | uVar35 << 1) ^
           (uVar49 >> 0x1f | uVar49 << 1);
  uVar28 = uVar32 >> 0x1f | uVar32 << 1;
  uVar12 = uVar28 + (uVar17 >> 2 | uVar17 * 0x40000000) +
           ((uVar20 >> 2 | uVar20 * 0x40000000) ^ (uVar18 >> 2 | uVar18 * 0x40000000) ^ uVar50) +
           (uVar19 >> 0x1b | uVar19 * 0x20) + 0x6ed9eba1;
  uVar40 = uVar40 ^ (uVar34 >> 0x1f | uVar34 << 1) ^ (uVar25 >> 0x1f | uVar25 << 1) ^
           (uVar44 >> 0x1f | uVar44 << 1);
  uVar17 = uVar40 >> 0x1f | uVar40 << 1;
  uVar18 = uVar17 + (uVar18 >> 2 | uVar18 * 0x40000000) +
           ((uVar50 >> 2 | uVar50 * 0x40000000) ^ (uVar20 >> 2 | uVar20 * 0x40000000) ^ uVar19) +
           (uVar12 >> 0x1b | uVar12 * 0x20) + 0x6ed9eba1;
  uVar42 = uVar3 ^ (uVar21 >> 0x1f | uVar21 << 1) ^ (uVar39 >> 0x1f | uVar39 << 1) ^
           (uVar46 >> 0x1f | uVar46 << 1);
  uVar3 = uVar42 >> 0x1f | uVar42 << 1;
  uVar20 = uVar3 + (uVar20 >> 2 | uVar20 * 0x40000000) +
           ((uVar19 >> 2 | uVar19 * 0x40000000) ^ (uVar50 >> 2 | uVar50 * 0x40000000) ^ uVar12) +
           (uVar18 >> 0x1b | uVar18 * 0x20) + 0x6ed9eba1;
  uVar34 = uVar48 ^ (uVar34 >> 0x1f | uVar34 << 1) ^ (uVar43 >> 0x1f | uVar43 << 1) ^
           (uVar32 >> 0x1f | uVar32 << 1);
  uVar48 = uVar34 >> 0x1f | uVar34 << 1;
  uVar33 = uVar48 + (uVar50 >> 2 | uVar50 * 0x40000000) +
           ((uVar12 >> 2 | uVar12 * 0x40000000) ^ (uVar19 >> 2 | uVar19 * 0x40000000) ^ uVar18) +
           (uVar20 >> 0x1b | uVar20 * 0x20) + 0x6ed9eba1;
  uVar36 = uVar27 ^ (uVar22 >> 0x1f | uVar22 << 1) ^ (uVar41 >> 0x1f | uVar41 << 1) ^
           (uVar40 >> 0x1f | uVar40 << 1);
  uVar27 = uVar36 >> 0x1f | uVar36 << 1;
  uVar51 = uVar27 + (uVar19 >> 2 | uVar19 * 0x40000000) +
           ((uVar18 >> 2 | uVar18 * 0x40000000) ^ (uVar12 >> 2 | uVar12 * 0x40000000) ^ uVar20) +
           (uVar33 >> 0x1b | uVar33 * 0x20) + 0x6ed9eba1;
  uVar50 = uVar4 ^ (uVar23 >> 0x1f | uVar23 << 1) ^ (uVar49 >> 0x1f | uVar49 << 1) ^
           (uVar42 >> 0x1f | uVar42 << 1);
  uVar4 = uVar50 >> 0x1f | uVar50 << 1;
  uVar12 = uVar4 + (uVar12 >> 2 | uVar12 * 0x40000000) +
           ((uVar20 >> 2 | uVar20 * 0x40000000) ^ (uVar18 >> 2 | uVar18 * 0x40000000) ^ uVar33) +
           (uVar51 >> 0x1b | uVar51 * 0x20) + 0x6ed9eba1;
  uVar21 = uVar5 ^ (uVar24 >> 0x1f | uVar24 << 1) ^ (uVar44 >> 0x1f | uVar44 << 1) ^
           (uVar34 >> 0x1f | uVar34 << 1);
  uVar5 = uVar21 >> 0x1f | uVar21 << 1;
  uVar18 = uVar5 + (uVar18 >> 2 | uVar18 * 0x40000000) +
           ((uVar33 >> 2 | uVar33 * 0x40000000) ^ (uVar20 >> 2 | uVar20 * 0x40000000) ^ uVar51) +
           (uVar12 >> 0x1b | uVar12 * 0x20) + 0x6ed9eba1;
  uVar19 = uVar6 ^ (uVar31 >> 0x1f | uVar31 << 1) ^ (uVar46 >> 0x1f | uVar46 << 1) ^
           (uVar36 >> 0x1f | uVar36 << 1);
  uVar6 = uVar19 >> 0x1f | uVar19 << 1;
  uVar20 = uVar6 + (uVar20 >> 2 | uVar20 * 0x40000000) +
           ((uVar51 >> 2 | uVar51 * 0x40000000) ^ (uVar33 >> 2 | uVar33 * 0x40000000) ^ uVar12) +
           (uVar18 >> 0x1b | uVar18 * 0x20) + 0x6ed9eba1;
  uVar37 = uVar9 ^ (uVar35 >> 0x1f | uVar35 << 1) ^ (uVar32 >> 0x1f | uVar32 << 1) ^
           (uVar50 >> 0x1f | uVar50 << 1);
  uVar9 = uVar37 >> 0x1f | uVar37 << 1;
  uVar31 = uVar9 + (uVar33 >> 2 | uVar33 * 0x40000000) +
           ((uVar12 >> 2 | uVar12 * 0x40000000) ^ (uVar51 >> 2 | uVar51 * 0x40000000) ^ uVar18) +
           (uVar20 >> 0x1b | uVar20 * 0x20) + 0x6ed9eba1;
  uVar22 = uVar11 ^ (uVar39 >> 0x1f | uVar39 << 1) ^ (uVar42 >> 0x1f | uVar42 << 1) ^
           (uVar19 >> 0x1f | uVar19 << 1);
  uVar11 = uVar22 >> 0x1f | uVar22 << 1;
  uVar47 = uVar14 ^ (uVar25 >> 0x1f | uVar25 << 1) ^ (uVar40 >> 0x1f | uVar40 << 1) ^
           (uVar21 >> 0x1f | uVar21 << 1);
  uVar14 = uVar47 >> 0x1f | uVar47 << 1;
  uVar39 = uVar14 + (uVar51 >> 2 | uVar51 * 0x40000000) +
           ((uVar18 >> 2 | uVar18 * 0x40000000) ^ (uVar12 >> 2 | uVar12 * 0x40000000) ^ uVar20) +
           (uVar31 >> 0x1b | uVar31 * 0x20) + 0x6ed9eba1;
  iVar7 = uVar11 + (uVar12 >> 2 | uVar12 * 0x40000000) +
          ((uVar31 | uVar20 >> 2 | uVar20 * 0x40000000) & (uVar18 >> 2 | uVar18 * 0x40000000) |
          uVar31 & (uVar20 >> 2 | uVar20 * 0x40000000)) + (uVar39 >> 0x1b | uVar39 * 0x20);
  uVar24 = iVar7 + 0x8f1bbcdc;
  uVar51 = uVar15 ^ (uVar43 >> 0x1f | uVar43 << 1) ^ (uVar34 >> 0x1f | uVar34 << 1) ^
           (uVar37 >> 0x1f | uVar37 << 1);
  uVar15 = uVar51 >> 0x1f | uVar51 << 1;
  iVar8 = uVar15 + (uVar18 >> 2 | uVar18 * 0x40000000) +
          ((uVar39 | uVar31 >> 2 | uVar31 * 0x40000000) & (uVar20 >> 2 | uVar20 * 0x40000000) |
          uVar39 & (uVar31 >> 2 | uVar31 * 0x40000000)) + (uVar24 >> 0x1b | uVar24 * 0x20);
  uVar18 = iVar8 + 0x8f1bbcdc;
  uVar43 = uVar16 ^ (uVar41 >> 0x1f | uVar41 << 1) ^ (uVar36 >> 0x1f | uVar36 << 1) ^
           (uVar47 >> 0x1f | uVar47 << 1);
  uVar16 = uVar43 >> 0x1f | uVar43 << 1;
  iVar10 = uVar16 + (uVar20 >> 2 | uVar20 * 0x40000000) +
           ((uVar24 | uVar39 >> 2 | uVar39 * 0x40000000) & (uVar31 >> 2 | uVar31 * 0x40000000) |
           uVar24 & (uVar39 >> 2 | uVar39 * 0x40000000)) + (uVar18 >> 0x1b | uVar18 * 0x20);
  uVar12 = iVar10 + 0x8f1bbcdc;
  uVar25 = uVar30 ^ (uVar49 >> 0x1f | uVar49 << 1) ^ (uVar50 >> 0x1f | uVar50 << 1) ^
           (uVar22 >> 0x1f | uVar22 << 1);
  uVar30 = uVar25 >> 0x1f | uVar25 << 1;
  iVar1 = uVar30 + (uVar31 >> 2 | uVar31 * 0x40000000) +
          ((uVar18 | uVar24 >> 2 | iVar7 * 0x40000000) & (uVar39 >> 2 | uVar39 * 0x40000000) |
          uVar18 & (uVar24 >> 2 | iVar7 * 0x40000000)) + (uVar12 >> 0x1b | uVar12 * 0x20);
  uVar20 = iVar1 + 0x8f1bbcdc;
  uVar35 = uVar28 ^ (uVar44 >> 0x1f | uVar44 << 1) ^ (uVar21 >> 0x1f | uVar21 << 1) ^
           (uVar51 >> 0x1f | uVar51 << 1);
  uVar28 = uVar35 >> 0x1f | uVar35 << 1;
  iVar2 = uVar28 + (uVar39 >> 2 | uVar39 * 0x40000000) +
          ((uVar12 | uVar18 >> 2 | iVar8 * 0x40000000) & (uVar24 >> 2 | iVar7 * 0x40000000) |
          uVar12 & (uVar18 >> 2 | iVar8 * 0x40000000)) + (uVar20 >> 0x1b | uVar20 * 0x20);
  uVar33 = iVar2 + 0x8f1bbcdc;
  uVar23 = uVar17 ^ (uVar46 >> 0x1f | uVar46 << 1) ^ (uVar19 >> 0x1f | uVar19 << 1) ^
           (uVar43 >> 0x1f | uVar43 << 1);
  uVar17 = uVar23 >> 0x1f | uVar23 << 1;
  iVar7 = uVar17 + (uVar24 >> 2 | iVar7 * 0x40000000) +
          ((uVar20 | uVar12 >> 2 | iVar10 * 0x40000000) & (uVar18 >> 2 | iVar8 * 0x40000000) |
          uVar20 & (uVar12 >> 2 | iVar10 * 0x40000000)) + (uVar33 >> 0x1b | uVar33 * 0x20);
  uVar39 = iVar7 + 0x8f1bbcdc;
  uVar44 = uVar3 ^ (uVar32 >> 0x1f | uVar32 << 1) ^ (uVar37 >> 0x1f | uVar37 << 1) ^
           (uVar25 >> 0x1f | uVar25 << 1);
  uVar3 = uVar44 >> 0x1f | uVar44 << 1;
  iVar8 = uVar3 + (uVar18 >> 2 | iVar8 * 0x40000000) +
          ((uVar33 | uVar20 >> 2 | iVar1 * 0x40000000) & (uVar12 >> 2 | iVar10 * 0x40000000) |
          uVar33 & (uVar20 >> 2 | iVar1 * 0x40000000)) + (uVar39 >> 0x1b | uVar39 * 0x20);
  uVar31 = iVar8 + 0x8f1bbcdc;
  uVar49 = uVar48 ^ (uVar40 >> 0x1f | uVar40 << 1) ^ (uVar47 >> 0x1f | uVar47 << 1) ^
           (uVar35 >> 0x1f | uVar35 << 1);
  uVar48 = uVar49 >> 0x1f | uVar49 << 1;
  iVar10 = uVar48 + (uVar12 >> 2 | iVar10 * 0x40000000) +
           ((uVar39 | uVar33 >> 2 | iVar2 * 0x40000000) & (uVar20 >> 2 | iVar1 * 0x40000000) |
           uVar39 & (uVar33 >> 2 | iVar2 * 0x40000000)) + (uVar31 >> 0x1b | uVar31 * 0x20);
  uVar18 = iVar10 + 0x8f1bbcdc;
  uVar41 = uVar27 ^ (uVar42 >> 0x1f | uVar42 << 1) ^ (uVar22 >> 0x1f | uVar22 << 1) ^
           (uVar23 >> 0x1f | uVar23 << 1);
  uVar27 = uVar41 >> 0x1f | uVar41 << 1;
  iVar1 = uVar27 + (uVar20 >> 2 | iVar1 * 0x40000000) +
          ((uVar31 | uVar39 >> 2 | iVar7 * 0x40000000) & (uVar33 >> 2 | iVar2 * 0x40000000) |
          uVar31 & (uVar39 >> 2 | iVar7 * 0x40000000)) + (uVar18 >> 0x1b | uVar18 * 0x20);
  uVar20 = iVar1 + 0x8f1bbcdc;
  uVar46 = uVar4 ^ (uVar34 >> 0x1f | uVar34 << 1) ^ (uVar51 >> 0x1f | uVar51 << 1) ^
           (uVar44 >> 0x1f | uVar44 << 1);
  uVar4 = uVar46 >> 0x1f | uVar46 << 1;
  iVar2 = uVar4 + (uVar33 >> 2 | iVar2 * 0x40000000) +
          ((uVar18 | uVar31 >> 2 | iVar8 * 0x40000000) & (uVar39 >> 2 | iVar7 * 0x40000000) |
          uVar18 & (uVar31 >> 2 | iVar8 * 0x40000000)) + (uVar20 >> 0x1b | uVar20 * 0x20);
  uVar32 = iVar2 + 0x8f1bbcdc;
  uVar34 = uVar5 ^ (uVar36 >> 0x1f | uVar36 << 1) ^ (uVar43 >> 0x1f | uVar43 << 1) ^
           (uVar49 >> 0x1f | uVar49 << 1);
  uVar5 = uVar34 >> 0x1f | uVar34 << 1;
  iVar7 = uVar5 + (uVar39 >> 2 | iVar7 * 0x40000000) +
          ((uVar20 | uVar18 >> 2 | iVar10 * 0x40000000) & (uVar31 >> 2 | iVar8 * 0x40000000) |
          uVar20 & (uVar18 >> 2 | iVar10 * 0x40000000)) + (uVar32 >> 0x1b | uVar32 * 0x20);
  uVar24 = iVar7 + 0x8f1bbcdc;
  uVar33 = uVar6 ^ (uVar50 >> 0x1f | uVar50 << 1) ^ (uVar25 >> 0x1f | uVar25 << 1) ^
           (uVar41 >> 0x1f | uVar41 << 1);
  uVar6 = uVar33 >> 0x1f | uVar33 << 1;
  iVar8 = uVar6 + (uVar31 >> 2 | iVar8 * 0x40000000) +
          ((uVar32 | uVar20 >> 2 | iVar1 * 0x40000000) & (uVar18 >> 2 | iVar10 * 0x40000000) |
          uVar32 & (uVar20 >> 2 | iVar1 * 0x40000000)) + (uVar24 >> 0x1b | uVar24 * 0x20);
  uVar50 = iVar8 + 0x8f1bbcdc;
  uVar31 = uVar9 ^ (uVar21 >> 0x1f | uVar21 << 1) ^ (uVar35 >> 0x1f | uVar35 << 1) ^
           (uVar46 >> 0x1f | uVar46 << 1);
  uVar9 = uVar31 >> 0x1f | uVar31 << 1;
  iVar10 = uVar9 + (uVar18 >> 2 | iVar10 * 0x40000000) +
           ((uVar24 | uVar32 >> 2 | iVar2 * 0x40000000) & (uVar20 >> 2 | iVar1 * 0x40000000) |
           uVar24 & (uVar32 >> 2 | iVar2 * 0x40000000)) + (uVar50 >> 0x1b | uVar50 * 0x20);
  uVar39 = iVar10 + 0x8f1bbcdc;
  uVar12 = uVar14 ^ (uVar19 >> 0x1f | uVar19 << 1) ^ (uVar23 >> 0x1f | uVar23 << 1) ^
           (uVar34 >> 0x1f | uVar34 << 1);
  uVar14 = uVar12 >> 0x1f | uVar12 << 1;
  iVar1 = uVar14 + (uVar20 >> 2 | iVar1 * 0x40000000) +
          ((uVar50 | uVar24 >> 2 | iVar7 * 0x40000000) & (uVar32 >> 2 | iVar2 * 0x40000000) |
          uVar50 & (uVar24 >> 2 | iVar7 * 0x40000000)) + (uVar39 >> 0x1b | uVar39 * 0x20);
  uVar40 = iVar1 + 0x8f1bbcdc;
  uVar19 = uVar11 ^ (uVar37 >> 0x1f | uVar37 << 1) ^ (uVar44 >> 0x1f | uVar44 << 1) ^
           (uVar33 >> 0x1f | uVar33 << 1);
  uVar11 = uVar19 >> 0x1f | uVar19 << 1;
  iVar2 = uVar11 + (uVar32 >> 2 | iVar2 * 0x40000000) +
          ((uVar39 | uVar50 >> 2 | iVar8 * 0x40000000) & (uVar24 >> 2 | iVar7 * 0x40000000) |
          uVar39 & (uVar50 >> 2 | iVar8 * 0x40000000)) + (uVar40 >> 0x1b | uVar40 * 0x20);
  uVar18 = iVar2 + 0x8f1bbcdc;
  uVar36 = uVar15 ^ (uVar47 >> 0x1f | uVar47 << 1) ^ (uVar49 >> 0x1f | uVar49 << 1) ^
           (uVar31 >> 0x1f | uVar31 << 1);
  uVar15 = uVar36 >> 0x1f | uVar36 << 1;
  iVar7 = uVar15 + (uVar24 >> 2 | iVar7 * 0x40000000) +
          ((uVar40 | uVar39 >> 2 | iVar10 * 0x40000000) & (uVar50 >> 2 | iVar8 * 0x40000000) |
          uVar40 & (uVar39 >> 2 | iVar10 * 0x40000000)) + (uVar18 >> 0x1b | uVar18 * 0x20);
  uVar20 = iVar7 + 0x8f1bbcdc;
  uVar21 = uVar16 ^ (uVar22 >> 0x1f | uVar22 << 1) ^ (uVar41 >> 0x1f | uVar41 << 1) ^
           (uVar12 >> 0x1f | uVar12 << 1);
  uVar16 = uVar21 >> 0x1f | uVar21 << 1;
  iVar38 = uVar16 + (uVar50 >> 2 | iVar8 * 0x40000000) +
           ((uVar18 | uVar40 >> 2 | iVar1 * 0x40000000) & (uVar39 >> 2 | iVar10 * 0x40000000) |
           uVar18 & (uVar40 >> 2 | iVar1 * 0x40000000)) + (uVar20 >> 0x1b | uVar20 * 0x20);
  uVar50 = iVar38 + 0x8f1bbcdc;
  uVar22 = uVar30 ^ (uVar51 >> 0x1f | uVar51 << 1) ^ (uVar46 >> 0x1f | uVar46 << 1) ^
           (uVar19 >> 0x1f | uVar19 << 1);
  uVar30 = uVar22 >> 0x1f | uVar22 << 1;
  iVar8 = uVar30 + (uVar39 >> 2 | iVar10 * 0x40000000) +
          ((uVar20 | uVar18 >> 2 | iVar2 * 0x40000000) & (uVar40 >> 2 | iVar1 * 0x40000000) |
          uVar20 & (uVar18 >> 2 | iVar2 * 0x40000000)) + (uVar50 >> 0x1b | uVar50 * 0x20);
  uVar39 = iVar8 + 0x8f1bbcdc;
  uVar37 = uVar28 ^ (uVar43 >> 0x1f | uVar43 << 1) ^ (uVar34 >> 0x1f | uVar34 << 1) ^
           (uVar36 >> 0x1f | uVar36 << 1);
  uVar28 = uVar37 >> 0x1f | uVar37 << 1;
  iVar10 = uVar28 + (uVar40 >> 2 | iVar1 * 0x40000000) +
           ((uVar50 | uVar20 >> 2 | iVar7 * 0x40000000) & (uVar18 >> 2 | iVar2 * 0x40000000) |
           uVar50 & (uVar20 >> 2 | iVar7 * 0x40000000)) + (uVar39 >> 0x1b | uVar39 * 0x20);
  uVar43 = iVar10 + 0x8f1bbcdc;
  uVar42 = uVar17 ^ (uVar25 >> 0x1f | uVar25 << 1) ^ (uVar33 >> 0x1f | uVar33 << 1) ^
           (uVar21 >> 0x1f | uVar21 << 1);
  uVar17 = uVar42 >> 0x1f | uVar42 << 1;
  iVar1 = uVar17 + (uVar18 >> 2 | iVar2 * 0x40000000) +
          ((uVar39 | uVar50 >> 2 | iVar38 * 0x40000000) & (uVar20 >> 2 | iVar7 * 0x40000000) |
          uVar39 & (uVar50 >> 2 | iVar38 * 0x40000000)) + (uVar43 >> 0x1b | uVar43 * 0x20);
  uVar32 = iVar1 + 0x8f1bbcdc;
  uVar25 = uVar3 ^ (uVar35 >> 0x1f | uVar35 << 1) ^ (uVar31 >> 0x1f | uVar31 << 1) ^
           (uVar22 >> 0x1f | uVar22 << 1);
  uVar3 = uVar25 >> 0x1f | uVar25 << 1;
  uVar24 = uVar3 + (uVar20 >> 2 | iVar7 * 0x40000000) +
           ((uVar39 >> 2 | iVar8 * 0x40000000) ^ (uVar50 >> 2 | iVar38 * 0x40000000) ^ uVar43) +
           (uVar32 >> 0x1b | uVar32 * 0x20) + 0xca62c1d6;
  uVar20 = uVar48 ^ (uVar23 >> 0x1f | uVar23 << 1) ^ (uVar12 >> 0x1f | uVar12 << 1) ^
           (uVar37 >> 0x1f | uVar37 << 1);
  uVar48 = uVar20 >> 0x1f | uVar20 << 1;
  uVar40 = uVar48 + (uVar50 >> 2 | iVar38 * 0x40000000) +
           ((uVar43 >> 2 | iVar10 * 0x40000000) ^ (uVar39 >> 2 | iVar8 * 0x40000000) ^ uVar32) +
           (uVar24 >> 0x1b | uVar24 * 0x20) + 0xca62c1d6;
  uVar35 = uVar27 ^ (uVar44 >> 0x1f | uVar44 << 1) ^ (uVar19 >> 0x1f | uVar19 << 1) ^
           (uVar42 >> 0x1f | uVar42 << 1);
  uVar27 = uVar35 >> 0x1f | uVar35 << 1;
  uVar18 = uVar27 + (uVar39 >> 2 | iVar8 * 0x40000000) +
           ((uVar32 >> 2 | iVar1 * 0x40000000) ^ (uVar43 >> 2 | iVar10 * 0x40000000) ^ uVar24) +
           (uVar40 >> 0x1b | uVar40 * 0x20) + 0xca62c1d6;
  uVar49 = uVar4 ^ (uVar49 >> 0x1f | uVar49 << 1) ^ (uVar36 >> 0x1f | uVar36 << 1) ^
           (uVar25 >> 0x1f | uVar25 << 1);
  uVar4 = uVar49 >> 0x1f | uVar49 << 1;
  uVar39 = uVar4 + (uVar43 >> 2 | iVar10 * 0x40000000) +
           ((uVar24 >> 2 | uVar24 * 0x40000000) ^ (uVar32 >> 2 | iVar1 * 0x40000000) ^ uVar40) +
           (uVar18 >> 0x1b | uVar18 * 0x20) + 0xca62c1d6;
  uVar50 = uVar5 ^ (uVar41 >> 0x1f | uVar41 << 1) ^ (uVar21 >> 0x1f | uVar21 << 1) ^
           (uVar20 >> 0x1f | uVar20 << 1);
  uVar5 = uVar50 >> 0x1f | uVar50 << 1;
  uVar32 = uVar5 + (uVar32 >> 2 | iVar1 * 0x40000000) +
           ((uVar40 >> 2 | uVar40 * 0x40000000) ^ (uVar24 >> 2 | uVar24 * 0x40000000) ^ uVar18) +
           (uVar39 >> 0x1b | uVar39 * 0x20) + 0xca62c1d6;
  uVar23 = uVar6 ^ (uVar46 >> 0x1f | uVar46 << 1) ^ (uVar22 >> 0x1f | uVar22 << 1) ^
           (uVar35 >> 0x1f | uVar35 << 1);
  uVar6 = uVar23 >> 0x1f | uVar23 << 1;
  uVar24 = uVar6 + (uVar24 >> 2 | uVar24 * 0x40000000) +
           ((uVar18 >> 2 | uVar18 * 0x40000000) ^ (uVar40 >> 2 | uVar40 * 0x40000000) ^ uVar39) +
           (uVar32 >> 0x1b | uVar32 * 0x20) + 0xca62c1d6;
  uVar34 = uVar9 ^ (uVar34 >> 0x1f | uVar34 << 1) ^ (uVar37 >> 0x1f | uVar37 << 1) ^
           (uVar49 >> 0x1f | uVar49 << 1);
  uVar46 = (uVar34 >> 0x1f | uVar34 << 1) + (uVar40 >> 2 | uVar40 * 0x40000000) +
           ((uVar39 >> 2 | uVar39 * 0x40000000) ^ (uVar18 >> 2 | uVar18 * 0x40000000) ^ uVar32) +
           (uVar24 >> 0x1b | uVar24 * 0x20) + 0xca62c1d6;
  uVar33 = uVar14 ^ (uVar33 >> 0x1f | uVar33 << 1) ^ (uVar42 >> 0x1f | uVar42 << 1) ^
           (uVar50 >> 0x1f | uVar50 << 1);
  uVar9 = (uVar33 >> 0x1f | uVar33 << 1) + (uVar18 >> 2 | uVar18 * 0x40000000) +
          ((uVar32 >> 2 | uVar32 * 0x40000000) ^ (uVar39 >> 2 | uVar39 * 0x40000000) ^ uVar24) +
          (uVar46 >> 0x1b | uVar46 * 0x20) + 0xca62c1d6;
  uVar18 = uVar11 ^ (uVar31 >> 0x1f | uVar31 << 1) ^ (uVar25 >> 0x1f | uVar25 << 1) ^
           (uVar23 >> 0x1f | uVar23 << 1);
  uVar14 = (uVar18 >> 0x1f | uVar18 << 1) + (uVar39 >> 2 | uVar39 * 0x40000000) +
           ((uVar24 >> 2 | uVar24 * 0x40000000) ^ (uVar32 >> 2 | uVar32 * 0x40000000) ^ uVar46) +
           (uVar9 >> 0x1b | uVar9 * 0x20) + 0xca62c1d6;
  uVar31 = uVar15 ^ (uVar12 >> 0x1f | uVar12 << 1) ^ (uVar20 >> 0x1f | uVar20 << 1) ^
           (uVar34 >> 0x1f | uVar34 << 1);
  uVar11 = (uVar31 >> 0x1f | uVar31 << 1) + (uVar32 >> 2 | uVar32 * 0x40000000) +
           ((uVar46 >> 2 | uVar46 * 0x40000000) ^ (uVar24 >> 2 | uVar24 * 0x40000000) ^ uVar9) +
           (uVar14 >> 0x1b | uVar14 * 0x20) + 0xca62c1d6;
  uVar16 = uVar16 ^ (uVar19 >> 0x1f | uVar19 << 1) ^ (uVar35 >> 0x1f | uVar35 << 1) ^
           (uVar33 >> 0x1f | uVar33 << 1);
  uVar15 = (uVar16 >> 0x1f | uVar16 << 1) + (uVar24 >> 2 | uVar24 * 0x40000000) +
           ((uVar9 >> 2 | uVar9 * 0x40000000) ^ (uVar46 >> 2 | uVar46 * 0x40000000) ^ uVar14) +
           (uVar11 >> 0x1b | uVar11 * 0x20) + 0xca62c1d6;
  uVar30 = uVar30 ^ (uVar36 >> 0x1f | uVar36 << 1) ^ (uVar49 >> 0x1f | uVar49 << 1) ^
           (uVar18 >> 0x1f | uVar18 << 1);
  uVar19 = (uVar30 >> 0x1f | uVar30 << 1) + (uVar46 >> 2 | uVar46 * 0x40000000) +
           ((uVar14 >> 2 | uVar14 * 0x40000000) ^ (uVar9 >> 2 | uVar9 * 0x40000000) ^ uVar11) +
           (uVar15 >> 0x1b | uVar15 * 0x20) + 0xca62c1d6;
  uVar12 = uVar28 ^ (uVar21 >> 0x1f | uVar21 << 1) ^ (uVar50 >> 0x1f | uVar50 << 1) ^
           (uVar31 >> 0x1f | uVar31 << 1);
  uVar39 = (uVar12 >> 0x1f | uVar12 << 1) + (uVar9 >> 2 | uVar9 * 0x40000000) +
           ((uVar11 >> 2 | uVar11 * 0x40000000) ^ (uVar14 >> 2 | uVar14 * 0x40000000) ^ uVar15) +
           (uVar19 >> 0x1b | uVar19 * 0x20) + 0xca62c1d6;
  uVar28 = uVar17 ^ (uVar22 >> 0x1f | uVar22 << 1) ^ (uVar23 >> 0x1f | uVar23 << 1) ^
           (uVar16 >> 0x1f | uVar16 << 1);
  uVar9 = (uVar28 >> 0x1f | uVar28 << 1) + (uVar14 >> 2 | uVar14 * 0x40000000) +
          ((uVar15 >> 2 | uVar15 * 0x40000000) ^ (uVar11 >> 2 | uVar11 * 0x40000000) ^ uVar19) +
          (uVar39 >> 0x1b | uVar39 * 0x20) + 0xca62c1d6;
  uVar17 = uVar3 ^ (uVar37 >> 0x1f | uVar37 << 1) ^ (uVar34 >> 0x1f | uVar34 << 1) ^
           (uVar30 >> 0x1f | uVar30 << 1);
  uVar3 = (uVar17 >> 0x1f | uVar17 << 1) + (uVar11 >> 2 | uVar11 * 0x40000000) +
          ((uVar19 >> 2 | uVar19 * 0x40000000) ^ (uVar15 >> 2 | uVar15 * 0x40000000) ^ uVar39) +
          (uVar9 >> 0x1b | uVar9 * 0x20) + 0xca62c1d6;
  uVar12 = uVar48 ^ (uVar42 >> 0x1f | uVar42 << 1) ^ (uVar33 >> 0x1f | uVar33 << 1) ^
           (uVar12 >> 0x1f | uVar12 << 1);
  uVar14 = (uVar12 >> 0x1f | uVar12 << 1) + (uVar15 >> 2 | uVar15 * 0x40000000) +
           ((uVar39 >> 2 | uVar39 * 0x40000000) ^ (uVar19 >> 2 | uVar19 * 0x40000000) ^ uVar9) +
           (uVar3 >> 0x1b | uVar3 * 0x20) + 0xca62c1d6;
  param_1[4] = param_1[4] + (uVar14 >> 2 | uVar14 * 0x40000000);
  uVar15 = uVar27 ^ (uVar25 >> 0x1f | uVar25 << 1) ^ (uVar18 >> 0x1f | uVar18 << 1) ^
           (uVar28 >> 0x1f | uVar28 << 1);
  uVar11 = (uVar15 >> 0x1f | uVar15 << 1) + (uVar19 >> 2 | uVar19 * 0x40000000) +
           ((uVar9 >> 2 | uVar9 * 0x40000000) ^ (uVar39 >> 2 | uVar39 * 0x40000000) ^ uVar3) +
           (uVar14 >> 0x1b | uVar14 * 0x20) + 0xca62c1d6;
  param_1[3] = uVar45 + (uVar11 >> 2 | uVar11 * 0x40000000);
  uVar48 = uVar4 ^ (uVar20 >> 0x1f | uVar20 << 1) ^ (uVar31 >> 0x1f | uVar31 << 1) ^
           (uVar17 >> 0x1f | uVar17 << 1);
  uVar27 = (uVar48 >> 0x1f | uVar48 << 1) + (uVar39 >> 2 | uVar39 * 0x40000000) +
           ((uVar3 >> 2 | uVar3 * 0x40000000) ^ (uVar9 >> 2 | uVar9 * 0x40000000) ^ uVar14) +
           (uVar11 >> 0x1b | uVar11 * 0x20) + 0xca62c1d6;
  param_1[2] = uVar29 + (uVar27 >> 2 | uVar27 * 0x40000000);
  uVar48 = uVar5 ^ (uVar35 >> 0x1f | uVar35 << 1) ^ (uVar16 >> 0x1f | uVar16 << 1) ^
           (uVar12 >> 0x1f | uVar12 << 1);
  uVar48 = (uVar48 >> 0x1f | uVar48 << 1) + (uVar9 >> 2 | uVar9 * 0x40000000) +
           ((uVar14 >> 2 | uVar14 * 0x40000000) ^ (uVar3 >> 2 | uVar3 * 0x40000000) ^ uVar11) +
           (uVar27 >> 0x1b | uVar27 * 0x20) + 0xca62c1d6;
  param_1[1] = uVar48 + uVar26;
  uVar4 = uVar6 ^ (uVar49 >> 0x1f | uVar49 << 1) ^ (uVar30 >> 0x1f | uVar30 << 1) ^
          (uVar15 >> 0x1f | uVar15 << 1);
  *param_1 = uVar13 + (uVar4 >> 0x1f | uVar4 << 1) + (uVar3 >> 2 | uVar3 * 0x40000000) +
             ((uVar11 >> 2 | uVar11 * 0x40000000) ^ (uVar14 >> 2 | uVar14 * 0x40000000) ^ uVar27) +
             (uVar48 >> 0x1b | uVar48 * 0x20) + 0xca62c1d6;
  return;
}

