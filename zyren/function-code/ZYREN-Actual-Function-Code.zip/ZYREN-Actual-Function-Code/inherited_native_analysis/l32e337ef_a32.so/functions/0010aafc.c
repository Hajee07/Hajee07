/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010aafc FUN_0010aafc */

undefined4
FUN_0010aafc(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  
  iVar1 = DAT_0010ab68;
  local_20 = 0;
  local_24 = 0;
  local_28 = 0;
  uVar2 = 0;
  if (param_3 != (undefined4 *)0x0) {
    *param_3 = 0;
    local_1c = 1;
    iVar1 = FUN_0010a934(param_1,param_2,iVar1 + 0x10ab40,&local_28,param_4);
    uVar2 = 0;
    if (iVar1 != 0) {
      *param_3 = local_28;
      uVar2 = local_20;
    }
  }
  return uVar2;
}

