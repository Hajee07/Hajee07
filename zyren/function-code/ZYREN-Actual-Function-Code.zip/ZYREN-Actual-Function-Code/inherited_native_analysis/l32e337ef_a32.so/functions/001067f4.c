/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001067f4 FUN_001067f4 */

uint FUN_001067f4(int *param_1,byte *param_2,uint *param_3,uint param_4,int *param_5,int param_6)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  char cVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined *puVar10;
  short *psVar11;
  int iVar12;
  short *psVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  byte *pbVar22;
  int iVar23;
  int iVar24;
  int iVar25;
  int iVar26;
  uint uVar27;
  uint uVar28;
  uint in_r12;
  uint uVar29;
  bool bVar30;
  byte *local_28;
  
  if (param_1 == (int *)0x0) {
    if (param_3 != (uint *)0x0) {
      *param_3 = 0;
    }
    if (param_5 == (int *)0x0) {
      return 0xfffffffe;
    }
    *param_5 = 0;
    return 0xfffffffe;
  }
  param_1[0x21] = (int)param_2;
  param_1[0x1c] = (int)param_2;
  uVar28 = 0;
  param_1[0x1d] = param_4;
  param_1[0x1e] = (int)param_3;
  param_1[0x1f] = (int)param_5;
  if (param_3 != (uint *)0x0) {
    uVar28 = *param_3;
  }
  uVar21 = param_4 | (uint)param_5;
  if (uVar21 != 0) {
    uVar21 = 1;
  }
  param_1[0x22] = uVar28;
  param_1[0x23] = 0;
  param_1[0x20] = param_6;
  uVar6 = (uint)(*param_1 == 0);
  bVar30 = uVar21 == uVar6;
  if (bVar30) {
    uVar6 = param_1[0x1b];
  }
  if ((bVar30 && uVar6 == 0) && (param_6 == 4 || param_1[0x1a] == 0)) {
    if ((param_3 == (uint *)0x0) || ((param_2 != (byte *)0x0 || (*param_3 == 0)))) {
      if ((param_5 == (int *)0x0) || ((param_4 != 0 || (*param_5 == 0)))) {
        uVar21 = param_1[0x1a] | (uint)(param_6 == 4);
        param_1[0x1a] = uVar21;
        if (param_1[0x17] == 0) {
          uVar21 = param_1[0x18];
        }
        if (param_1[0x17] == 0 && uVar21 == 0) {
          local_28 = param_2;
          if (uVar28 != 0) goto LAB_00106a24;
LAB_00106b30:
          uVar21 = in_r12;
          if (param_6 != 0) {
            uVar21 = param_1[8];
          }
          if (param_6 != 0 && uVar21 != 0) {
            uVar6 = param_1[9];
            uVar7 = uVar6 + uVar21;
            if (uVar7 < 2) goto LAB_00106a38;
LAB_00106b50:
            uVar16 = param_1[7] + uVar21;
            uVar9 = uVar16 - 2;
            uVar7 = 0x102 - uVar21;
            if (uVar28 < 0x102 - uVar21) {
              uVar7 = uVar28;
            }
            bVar2 = *(byte *)((int)param_1 + (uVar16 - 1 & 0x7fff) + 0x90);
            in_r12 = uVar7 + uVar21;
            bVar3 = *(byte *)((int)param_1 + (uVar9 & 0x7fff) + 0x90);
            uVar28 = uVar28 - uVar7;
            param_1[8] = in_r12;
            pbVar22 = local_28;
            if (uVar7 != 0) {
              uVar21 = (uint)bVar2 ^ (uint)bVar3 << 5;
              pbVar22 = local_28 + uVar7;
              do {
                uVar17 = uVar16 & 0x7fff;
                iVar15 = (int)param_1 + uVar17;
                bVar2 = *local_28;
                *(byte *)(iVar15 + 0x90) = bVar2;
                if (uVar17 < 0x101) {
                  iVar15 = (int)param_1 + (uVar17 | 0x8000);
                }
                uVar16 = uVar17 + 1;
                if (uVar17 < 0x101) {
                  *(byte *)(iVar15 + 0x90) = bVar2;
                }
                uVar21 = (uVar21 & 0x3ff) << 5 ^ (uint)bVar2;
                uVar7 = uVar7 - 1;
                *(undefined2 *)(&DAT_00019272 + (int)param_1 + (uVar9 & 0x7fff) * 2) =
                     *(undefined2 *)(&DAT_00029272 + (int)param_1 + uVar21 * 2);
                *(short *)(&DAT_00029272 + (int)param_1 + uVar21 * 2) = (short)uVar9;
                uVar9 = uVar9 + 1;
                local_28 = local_28 + 1;
              } while (uVar7 != 0);
            }
LAB_00106c7c:
            local_28 = pbVar22;
            if (0x8000 - in_r12 < uVar6) {
              uVar6 = 0x8000 - in_r12;
            }
            param_1[9] = uVar6;
            if ((param_6 != 0) || (0x80 < in_r12 >> 1)) {
              do {
                uVar29 = param_1[7];
                uVar7 = 0;
                uVar9 = param_1[0x14];
                uVar17 = param_1[2];
                uVar16 = uVar29 & 0x7fff;
                uVar21 = uVar9;
                if (uVar9 == 0) {
                  uVar21 = 2;
                }
                if ((uVar17 & 0x90000) == 0) {
                  if (uVar21 < in_r12) {
                    iVar15 = param_1[(0x1f < uVar21) + 3] + -1;
                    uVar7 = 0;
                    if (iVar15 != 0) {
                      uVar7 = 0;
                      cVar4 = *(char *)((int)param_1 + uVar21 + uVar16 + 0x8f);
                      cVar5 = *(char *)((int)param_1 + uVar21 + uVar16 + 0x90);
                      uVar27 = uVar16;
                      do {
                        iVar8 = 1 - iVar15;
                        while( true ) {
                          uVar27 = (uint)*(ushort *)(&DAT_00019272 + (int)param_1 + uVar27 * 2);
                          if ((uVar27 == 0) || (uVar20 = uVar29 - uVar27 & 0xffff, uVar6 < uVar20))
                          goto LAB_00106f60;
                          uVar27 = uVar27 & 0x7fff;
                          if ((*(char *)((int)param_1 + uVar21 + uVar27 + 0x90) == cVar5) &&
                             (*(char *)((int)param_1 + uVar21 + uVar27 + 0x8f) == cVar4)) break;
                          uVar27 = (uint)*(ushort *)(&DAT_00019272 + (int)param_1 + uVar27 * 2);
                          if ((uVar27 == 0) || (uVar20 = uVar29 - uVar27 & 0xffff, uVar6 < uVar20))
                          goto LAB_00106f60;
                          uVar27 = uVar27 & 0x7fff;
                          if ((*(char *)((int)param_1 + uVar21 + uVar27 + 0x90) == cVar5) &&
                             (*(char *)((int)param_1 + uVar21 + uVar27 + 0x8f) == cVar4)) break;
                          uVar27 = (uint)*(ushort *)(&DAT_00019272 + (int)param_1 + uVar27 * 2);
                          if ((uVar27 == 0) || (uVar20 = uVar29 - uVar27 & 0xffff, uVar6 < uVar20))
                          goto LAB_00106f60;
                          uVar27 = uVar27 & 0x7fff;
                          if ((*(char *)((int)param_1 + uVar21 + uVar27 + 0x90) == cVar5) &&
                             (*(char *)((int)param_1 + uVar21 + uVar27 + 0x8f) == cVar4)) break;
                          iVar8 = iVar8 + 1;
                          if (iVar8 == 1) goto LAB_00106f60;
                        }
                        if (uVar20 == 0) break;
                        uVar18 = 0;
                        do {
                          uVar19 = uVar18;
                          if (*(char *)((int)param_1 + uVar18 + uVar16 + 0x90) !=
                              *(char *)((int)param_1 + uVar18 + uVar27 + 0x90)) break;
                          uVar18 = uVar18 + 1;
                          uVar19 = in_r12;
                        } while (in_r12 != uVar18);
                        if (uVar21 < uVar19) {
                          uVar21 = in_r12;
                          uVar7 = uVar20;
                          if (uVar19 == in_r12) break;
                          cVar4 = *(char *)((int)param_1 + uVar19 + uVar16 + 0x8f);
                          cVar5 = *(char *)((int)param_1 + uVar19 + uVar16 + 0x90);
                          uVar21 = uVar19;
                        }
                        iVar15 = -iVar8;
                      } while (iVar8 != 0);
                    }
                  }
                }
                else if ((uVar6 != 0) && ((uVar17 & 0x80000) == 0)) {
                  if (in_r12 == 0) {
                    uVar21 = 0;
                  }
                  else {
                    uVar6 = 0;
                    do {
                      uVar21 = uVar6;
                      if (*(char *)((int)param_1 + uVar6 + uVar16 + 0x90) !=
                          *(char *)((int)param_1 + (uVar29 - 1 & 0x7fff) + 0x90)) break;
                      uVar6 = uVar6 + 1;
                      uVar21 = in_r12;
                    } while (in_r12 != uVar6);
                  }
                  uVar7 = (uint)(2 < uVar21);
                  if (uVar21 < 3) {
                    uVar21 = 0;
                  }
                }
LAB_00106f60:
                uVar6 = uVar7 >> 0xd;
                if (uVar7 >> 0xd != 0) {
                  uVar6 = 1;
                }
                if (((uVar16 == uVar7) || ((uVar6 & uVar21 == 3) != 0)) ||
                   (((uVar17 & 0x20000) != 0 && (uVar21 < 6)))) {
                  uVar7 = 0;
                  uVar21 = 0;
                }
                if (uVar9 == 0) {
                  if (uVar7 == 0) {
                    pbVar22 = (byte *)param_1[10];
                    bVar2 = *(byte *)((int)param_1 + uVar16 + 0x90);
                    param_1[0xf] = param_1[0xf] + 1;
                    param_1[10] = (int)(pbVar22 + 1);
                    *pbVar22 = bVar2;
                    *(byte *)param_1[0xb] = *(byte *)param_1[0xb] >> 1;
                    iVar15 = param_1[0xe];
                    param_1[0xe] = iVar15 + -1;
                    if (iVar15 + -1 == 0) {
                      iVar15 = param_1[10];
                      param_1[0xe] = 8;
                      param_1[10] = iVar15 + 1;
                      param_1[0xb] = iVar15;
                    }
                    psVar11 = (short *)((int)param_1 + (uint)bVar2 * 2 + 0x8192);
                    *psVar11 = *psVar11 + 1;
LAB_0010739c:
                    uVar21 = 1;
                  }
                  else {
                    bVar30 = param_1[5] == 0;
                    if (bVar30) {
                      bVar30 = (uVar17 & 0x10000) == 0;
                    }
                    if ((bVar30) && (uVar21 < 0x80)) goto LAB_00107388;
                    param_1[0xf] = param_1[0xf] + uVar21;
                    *(char *)param_1[10] = (char)(uVar21 - 3);
                    uVar7 = uVar7 - 1;
                    *(char *)(param_1[10] + 1) = (char)uVar7;
                    *(char *)(param_1[10] + 2) = (char)(uVar7 >> 8);
                    param_1[10] = param_1[10] + 3;
                    *(byte *)param_1[0xb] = *(byte *)param_1[0xb] >> 1 | 0x80;
                    iVar15 = param_1[0xe];
                    param_1[0xe] = iVar15 + -1;
                    if (iVar15 + -1 == 0) {
                      iVar15 = param_1[10];
                      param_1[0xe] = 8;
                      param_1[10] = iVar15 + 1;
                      param_1[0xb] = iVar15;
                    }
                    pbVar22 = (byte *)(DAT_001076d0 + 0x1071c8 + (uVar7 >> 8 & 0x7f));
                    if (uVar7 < 0x200) {
                      pbVar22 = (byte *)(DAT_001076d4 + 0x1071d4 + (uVar7 & 0x1ff));
                    }
                    psVar13 = (short *)((int)param_1 + (uint)*pbVar22 * 2 + 0x83d2);
                    psVar11 = (short *)((int)param_1 +
                                       (uint)*(ushort *)(DAT_001076d8 + 0x1071e8 + (uVar21 - 3) * 2)
                                       * 2 + 0x8192);
                    *psVar13 = *psVar13 + 1;
                    *psVar11 = *psVar11 + 1;
                  }
                }
                else if (uVar9 < uVar21) {
                  puVar10 = (undefined *)param_1[10];
                  uVar6 = param_1[0x15];
                  param_1[0xf] = param_1[0xf] + 1;
                  param_1[10] = (int)(puVar10 + 1);
                  *puVar10 = (char)uVar6;
                  *(byte *)param_1[0xb] = *(byte *)param_1[0xb] >> 1;
                  iVar15 = param_1[0xe];
                  param_1[0xe] = iVar15 + -1;
                  if (iVar15 + -1 == 0) {
                    iVar15 = param_1[10];
                    param_1[0xe] = 8;
                    param_1[10] = iVar15 + 1;
                    param_1[0xb] = iVar15;
                  }
                  psVar11 = (short *)((int)param_1 + (uVar6 & 0xff) * 2 + 0x8192);
                  *psVar11 = *psVar11 + 1;
                  if (uVar21 < 0x80) {
LAB_00107388:
                    bVar2 = *(byte *)((int)param_1 + uVar16 + 0x90);
                    param_1[0x13] = uVar7;
                    param_1[0x14] = uVar21;
                    param_1[0x15] = (uint)bVar2;
                    goto LAB_0010739c;
                  }
                  param_1[0xf] = param_1[0xf] + uVar21;
                  *(char *)param_1[10] = (char)(uVar21 - 3);
                  uVar7 = uVar7 - 1;
                  *(char *)(param_1[10] + 1) = (char)uVar7;
                  *(char *)(param_1[10] + 2) = (char)(uVar7 >> 8);
                  param_1[10] = param_1[10] + 3;
                  *(byte *)param_1[0xb] = *(byte *)param_1[0xb] >> 1 | 0x80;
                  iVar15 = param_1[0xe];
                  param_1[0xe] = iVar15 + -1;
                  if (iVar15 + -1 == 0) {
                    iVar15 = param_1[10];
                    param_1[0xe] = 8;
                    param_1[10] = iVar15 + 1;
                    param_1[0xb] = iVar15;
                  }
                  pbVar22 = (byte *)(DAT_001076b8 + 0x1070c4 + (uVar7 >> 8 & 0x7f));
                  if (uVar7 < 0x200) {
                    pbVar22 = (byte *)(DAT_001076bc + 0x1070d0 + (uVar7 & 0x1ff));
                  }
                  psVar13 = (short *)((int)param_1 + (uint)*pbVar22 * 2 + 0x83d2);
                  psVar11 = (short *)((int)param_1 +
                                     (uint)*(ushort *)(DAT_001076c0 + 0x1070e4 + (uVar21 - 3) * 2) *
                                     2 + 0x8192);
                  *psVar13 = *psVar13 + 1;
                  *psVar11 = *psVar11 + 1;
                  param_1[0x14] = 0;
                }
                else {
                  iVar15 = param_1[0x13];
                  param_1[0xf] = param_1[0xf] + uVar9;
                  *(char *)param_1[10] = (char)(uVar9 - 3);
                  uVar21 = iVar15 - 1;
                  *(char *)(param_1[10] + 1) = (char)uVar21;
                  *(char *)(param_1[10] + 2) = (char)(uVar21 >> 8);
                  param_1[10] = param_1[10] + 3;
                  *(byte *)param_1[0xb] = *(byte *)param_1[0xb] >> 1 | 0x80;
                  iVar15 = param_1[0xe];
                  param_1[0xe] = iVar15 + -1;
                  if (iVar15 + -1 == 0) {
                    iVar15 = param_1[10];
                    param_1[0xe] = 8;
                    param_1[10] = iVar15 + 1;
                    param_1[0xb] = iVar15;
                  }
                  pbVar22 = (byte *)(DAT_001076c4 + 0x1072ac + (uVar21 >> 8 & 0x7f));
                  if (uVar21 < 0x200) {
                    pbVar22 = (byte *)(DAT_001076c8 + 0x1072b8 + (uVar21 & 0x1ff));
                  }
                  psVar13 = (short *)((int)param_1 + (uint)*pbVar22 * 2 + 0x83d2);
                  psVar11 = (short *)((int)param_1 +
                                     (uint)*(ushort *)(DAT_001076cc + 0x1072cc + (uVar9 - 3) * 2) *
                                     2 + 0x8192);
                  *psVar13 = *psVar13 + 1;
                  *psVar11 = *psVar11 + 1;
                  iVar15 = param_1[0x14];
                  param_1[0x14] = 0;
                  uVar21 = iVar15 - 1;
                }
                uVar6 = param_1[9] + uVar21;
                param_1[7] = param_1[7] + uVar21;
                if (0x7fff < uVar6) {
                  uVar6 = 0x8000;
                }
                param_1[8] = param_1[8] - uVar21;
                param_1[9] = uVar6;
                if ((&UNK_0001926a + (int)param_1 < (undefined *)param_1[10]) ||
                   ((0x7c00 < (uint)param_1[0xf] &&
                    (((uint)param_1[0xf] <=
                      (uint)(((int)(undefined *)param_1[10] - ((int)param_1 + 0x9272)) * 0x73) >> 7
                     || ((*(byte *)((int)param_1 + 10) & 8) != 0)))))) {
                  param_1[0x21] = (int)local_28;
                  param_1[0x22] = uVar28;
                  iVar15 = FUN_00109f28(param_1,0);
                  if (iVar15 != 0) {
                    if (iVar15 == -1 || iVar15 + 1 < 0 != SCARRY4(iVar15,1)) goto LAB_001076ac;
                    bVar30 = param_2 == (byte *)0x0;
                    if (!bVar30) {
                      bVar30 = (param_1[2] & 0x3000U) == 0;
                    }
                    goto joined_r0x00107444;
                  }
                }
                if (uVar28 == 0) goto LAB_00106b30;
LAB_00106a24:
                uVar21 = param_1[8];
                uVar6 = param_1[9];
                uVar7 = uVar6 + uVar21;
                if (1 < uVar7) goto LAB_00106b50;
LAB_00106a38:
                in_r12 = uVar21;
                if (uVar28 == 0) goto LAB_00106c2c;
                uVar9 = 0;
                while (in_r12 >> 1 < 0x81) {
                  iVar15 = param_1[7];
                  uVar16 = uVar21 + uVar9 + iVar15 & 0x7fff;
                  bVar2 = local_28[uVar9];
                  *(byte *)((int)param_1 + uVar16 + 0x90) = bVar2;
                  if (uVar16 < 0x101) {
                    *(byte *)((int)param_1 + (uVar16 | 0x8000) + 0x90) = bVar2;
                  }
                  param_1[8] = uVar21 + uVar9 + 1;
                  if (2 < uVar7 + 1 + uVar9) {
                    uVar16 = (uVar21 - 2) + uVar9 + iVar15;
                    uVar17 = uVar16 & 0x7fff;
                    bVar3 = *(byte *)((int)param_1 +
                                     (uVar21 + 0x7fff + uVar9 + iVar15 & 0x7fff) + 0x90);
                    bVar1 = *(byte *)((int)param_1 + uVar17 + 0x90);
                    *(undefined2 *)(&DAT_00019272 + (int)param_1 + uVar17 * 2) =
                         *(undefined2 *)
                          (&DAT_00029272 +
                          (int)param_1 + ((uint)bVar2 ^ (uint)bVar3 << 5 ^ (bVar1 & 0x1f) << 10) * 2
                          );
                    *(short *)(&DAT_00029272 +
                              (int)param_1 +
                              ((uint)bVar2 ^ (uint)bVar3 << 5 ^ (bVar1 & 0x1f) << 10) * 2) =
                         (short)uVar16;
                  }
                  uVar9 = uVar9 + 1;
                  if (uVar28 == uVar9) {
                    in_r12 = uVar21 + uVar9;
                    uVar28 = 0;
                    pbVar22 = local_28 + uVar9;
                    goto LAB_00106c7c;
                  }
                  in_r12 = uVar21 + uVar9;
                }
                uVar28 = uVar28 - uVar9;
                if (0x8000 - in_r12 < uVar6) {
                  uVar6 = 0x8000 - in_r12;
                }
                param_1[9] = uVar6;
                local_28 = local_28 + uVar9;
              } while( true );
            }
            goto LAB_00107410;
          }
          uVar28 = 0;
LAB_00107410:
          param_1[0x21] = (int)local_28;
          param_1[0x22] = uVar28;
          bVar30 = param_2 == (byte *)0x0;
          if (!bVar30) {
            bVar30 = (param_1[2] & 0x3000U) == 0;
          }
joined_r0x00107444:
          if (!bVar30) {
            uVar6 = param_1[0x21] - (int)param_2;
            uVar28 = (uint)param_1[6] >> 0x10;
            uVar21 = param_1[6] & 0xffff;
            if (uVar6 != 0) {
              uVar9 = uVar6 % 0x15b0;
              uVar7 = 0;
              if (uVar9 < 8) goto LAB_00107568;
              do {
                iVar15 = 0;
                uVar16 = uVar9 - 8 & 0xfffffff8;
                do {
                  pbVar22 = param_2 + iVar15;
                  iVar14 = uVar21 + *pbVar22;
                  iVar8 = iVar14 + (uint)pbVar22[1];
                  iVar23 = iVar8 + (uint)pbVar22[2];
                  iVar24 = iVar23 + (uint)pbVar22[3];
                  iVar25 = iVar24 + (uint)pbVar22[4];
                  iVar26 = iVar25 + (uint)pbVar22[5];
                  iVar12 = iVar26 + (uint)pbVar22[6];
                  uVar21 = iVar12 + (uint)pbVar22[7];
                  uVar28 = iVar14 + uVar28 + iVar8 + iVar23 + iVar24 + iVar25 + iVar26 + iVar12 +
                           uVar21;
                  uVar7 = iVar15 + 0xf;
                  iVar15 = iVar15 + 8;
                } while (uVar7 < uVar9);
                uVar7 = uVar16 + 8;
                param_2 = param_2 + uVar16 + 8;
LAB_00107568:
                if (uVar7 < uVar9) {
                  iVar15 = uVar9 - uVar7;
                  pbVar22 = param_2;
                  do {
                    iVar15 = iVar15 + -1;
                    uVar21 = uVar21 + *pbVar22;
                    uVar28 = uVar21 + uVar28;
                    pbVar22 = pbVar22 + 1;
                  } while (iVar15 != 0);
                  param_2 = param_2 + (uVar9 - uVar7);
                }
                uVar6 = uVar6 - uVar9;
                uVar9 = 0x15b0;
                uVar28 = uVar28 % 0xfff1;
                uVar21 = uVar21 % 0xfff1;
              } while (uVar6 != 0);
            }
            param_1[6] = uVar21 | uVar28 << 0x10;
          }
          if ((param_6 != 0) && (param_1[8] == 0)) {
            iVar15 = param_1[0x22];
            bVar30 = iVar15 == 0;
            if (bVar30) {
              iVar15 = param_1[0x17];
            }
            if (bVar30 && iVar15 == 0) {
              iVar15 = FUN_00109f28(param_1,param_6);
              if (iVar15 == -1 || iVar15 + 1 < 0 != SCARRY4(iVar15,1)) {
LAB_001076ac:
                return param_1[0x1b];
              }
              param_1[0x18] = (uint)(param_6 == 4);
              if (param_6 == 3) {
                param_1[9] = 0;
                __aeabi_memclr(&DAT_00019272 + (int)param_1,0x20000);
              }
            }
          }
          if ((int *)param_1[0x1e] != (int *)0x0) {
            *(int *)param_1[0x1e] = param_1[0x21] - param_1[0x1c];
          }
          if ((int *)param_1[0x1f] != (int *)0x0) {
            uVar21 = *(int *)param_1[0x1f] - param_1[0x23];
            uVar28 = param_1[0x17];
            if (uVar21 < (uint)param_1[0x17]) {
              uVar28 = uVar21;
            }
            __aeabi_memcpy(param_1[0x1d] + param_1[0x23],
                           &UNK_00039272 + (int)param_1 + param_1[0x16],uVar28);
            iVar15 = param_1[0x23];
            param_1[0x16] = param_1[0x16] + uVar28;
            param_1[0x17] = param_1[0x17] - uVar28;
            param_1[0x23] = iVar15 + uVar28;
            *(uint *)param_1[0x1f] = iVar15 + uVar28;
          }
          iVar15 = param_1[0x18];
        }
        else {
          if (param_3 != (uint *)0x0) {
            *param_3 = 0;
          }
          if (param_5 != (int *)0x0) {
            uVar21 = *param_5 - param_1[0x23];
            uVar28 = param_1[0x17];
            if (uVar21 < (uint)param_1[0x17]) {
              uVar28 = uVar21;
            }
            __aeabi_memcpy(param_4 + param_1[0x23],&UNK_00039272 + (int)param_1 + param_1[0x16],
                           uVar28);
            iVar15 = param_1[0x23];
            param_1[0x16] = param_1[0x16] + uVar28;
            param_1[0x17] = param_1[0x17] - uVar28;
            param_1[0x23] = iVar15 + uVar28;
            *(uint *)param_1[0x1f] = iVar15 + uVar28;
          }
          iVar15 = param_1[0x18];
        }
        if (iVar15 == 0) {
          uVar28 = 0;
        }
        else {
          uVar28 = (uint)(param_1[0x17] == 0);
        }
        goto LAB_0010688c;
      }
      goto LAB_0010686c;
    }
LAB_00106874:
    *param_3 = 0;
  }
  else {
LAB_0010686c:
    if (param_3 != (uint *)0x0) goto LAB_00106874;
  }
  if (param_5 != (int *)0x0) {
    *param_5 = 0;
  }
  uVar28 = 0xfffffffe;
LAB_0010688c:
  param_1[0x1b] = uVar28;
  return uVar28;
LAB_00106c2c:
  uVar28 = 0;
  pbVar22 = local_28;
  goto LAB_00106c7c;
}

