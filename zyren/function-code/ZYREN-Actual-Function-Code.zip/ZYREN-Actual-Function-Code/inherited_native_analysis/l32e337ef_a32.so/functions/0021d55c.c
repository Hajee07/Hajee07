/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d55c FUN_0021d55c */

void FUN_0021d55c(int param_1,char param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0021d4e4();
  iVar1 = iVar1 + 1;
  do {
    if (iVar1 == 0) {
      return;
    }
    iVar2 = param_1 + iVar1;
    iVar1 = iVar1 + -1;
  } while (*(char *)(iVar2 + -1) != param_2);
  return;
}

