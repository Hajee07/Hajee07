/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00121d00 _DT_INIT */

void _DT_INIT(void)

{
  thunk_FUN_00281594();
                    /* WARNING: Could not recover jumptable at 0x0006872c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_00068714 + *(int *)(&UNK_00068928 + DAT_00068714) + DAT_00068714))();
  return;
}

