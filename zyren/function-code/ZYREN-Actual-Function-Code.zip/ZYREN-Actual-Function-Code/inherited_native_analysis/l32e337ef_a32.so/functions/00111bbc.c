/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00111bbc FUN_00111bbc */

undefined4 FUN_00111bbc(uint *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  code *pcVar4;
  bool bVar5;
  
  param_1[0xf] = DAT_00111db4 + 0x111bdc;
  param_1[0x10] = 0;
  param_1[0x11] = (uint)param_1;
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  uVar1 = param_1[0x12];
  bVar5 = uVar1 == 0;
  if (bVar5) {
    uVar1 = param_1[5];
  }
  if (bVar5 && uVar1 == 0) {
    uVar1 = param_1[8];
    uVar3 = param_1[9];
    if (((uVar1 | uVar3) == 0) ||
       (uVar1 = uVar1 - (uVar1 >> 1 & 0x55555555),
       uVar1 = (uVar1 & 0x33333333) + (uVar1 >> 2 & 0x33333333),
       uVar3 = uVar3 - (uVar3 >> 1 & 0x55555555),
       uVar3 = (uVar3 & 0x33333333) + (uVar3 >> 2 & 0x33333333),
       ((uVar1 + (uVar1 >> 4) & 0xf0f0f0f) * 0x1010101 >> 0x18) +
       ((uVar3 + (uVar3 >> 4) & 0xf0f0f0f) * 0x1010101 >> 0x18) < 2)) {
      pcVar4 = (code *)param_1[10];
      if (pcVar4 == (code *)0x0) {
        pcVar4 = (code *)(DAT_00111db8 + 0x111cb4);
        param_1[10] = (uint)pcVar4;
      }
      if (param_1[0xb] == 0) {
        param_1[0xb] = DAT_00111dbc + 0x111cc8;
      }
      if (param_1[0xc] == 0) {
        param_1[0xc] = DAT_00111dc0 + 0x111ce0;
      }
      *param_1 = param_2;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      uVar1 = (*pcVar4)(param_1[0xd],1,0x58);
      param_1[0x12] = uVar1;
      if (uVar1 != 0) {
        __aeabi_memclr8(uVar1,0x58);
        uVar1 = param_1[0x12];
        if (param_2 < param_3) {
          param_2 = param_3;
        }
        *(undefined4 *)(uVar1 + 0x34) = 0;
        *(undefined4 *)(uVar1 + 0x38) = 0;
        *(undefined4 *)(uVar1 + 0x2c) = 4;
        *(undefined4 *)(uVar1 + 0x1c) = 4;
        *(undefined4 *)(uVar1 + 0xc) = 1;
        param_1[5] = 2;
        param_1[6] = 3;
        if (param_2 == 0) {
          return 1;
        }
        iVar2 = (*(code *)param_1[10])(param_1[0xd],1,param_2);
        uVar1 = param_1[0x12];
        *(int *)(uVar1 + 0x48) = iVar2;
        if (iVar2 != 0) {
          *(uint *)(uVar1 + 0x50) = param_2;
          return 1;
        }
        FUN_00111a30(param_1,0);
        param_1[7] = 0x10;
        return 0;
      }
      param_1[7] = 0x10;
      return 0;
    }
  }
  param_1[7] = 0x18;
  return 0;
}

