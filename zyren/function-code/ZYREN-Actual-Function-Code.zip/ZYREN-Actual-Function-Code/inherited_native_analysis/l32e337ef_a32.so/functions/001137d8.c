/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001137d8 FUN_001137d8 */

undefined4
FUN_001137d8(int param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5,
            undefined4 param_6,int param_7,undefined4 param_8,uint param_9,uint param_10,
            uint param_11,uint param_12,undefined4 param_13,int param_14,undefined4 param_15,
            undefined4 param_16,undefined4 param_17,undefined4 param_18_00,uint param_18,
            uint param_19,undefined4 param_20,undefined4 param_21,uint param_22)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  byte bVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined4 local_58;
  undefined local_52;
  undefined local_51;
  undefined local_50;
  undefined local_4f;
  undefined local_4e;
  undefined local_4d;
  undefined local_4c;
  undefined local_4b;
  undefined local_4a;
  undefined local_49;
  undefined local_48;
  undefined local_47;
  undefined local_46;
  undefined local_45;
  undefined local_44;
  undefined local_43;
  undefined local_42;
  undefined local_41;
  undefined local_40;
  undefined local_3f;
  undefined local_3e;
  undefined local_3d;
  undefined local_3c;
  undefined local_3b;
  undefined local_3a;
  undefined local_39;
  undefined local_38;
  undefined local_37;
  undefined local_32;
  undefined local_31;
  undefined local_30;
  undefined local_2f;
  undefined local_2e;
  undefined local_2d;
  undefined local_2c;
  undefined local_2b;
  uint local_28;
  
  piVar9 = *(int **)(param_1 + 0x48);
  uVar6 = piVar9[1];
  if ((param_19 != 0) && (piVar9[0xd] == 0)) {
    *(undefined4 *)(param_1 + 0x1c) = 3;
    return 0;
  }
  uVar1 = param_3 + param_5 + param_7;
  uVar2 = uVar1 + param_22;
  uVar3 = uVar2 + uVar6;
  bVar5 = CARRY4(uVar1,param_22) + CARRY4(uVar2,uVar6) + (0xffffffd1 < uVar3);
  if (bVar5 != 0 || bVar5 < (0xfffffffe < uVar3 + 0x2e)) {
    *(undefined4 *)(param_1 + 0x1c) = 0xf;
    return 0;
  }
  local_28 = uVar6;
  __aeabi_memclr4((uint)&local_58 | 4,0x2a);
  local_2f = (undefined)((uint)param_20 >> 0x18);
  local_30 = (undefined)((uint)param_20 >> 0x10);
  local_31 = (undefined)((uint)param_20 >> 8);
  local_32 = (undefined)param_20;
  local_37 = (undefined)((uint)param_7 >> 8);
  local_38 = (undefined)param_7;
  local_3b = (undefined)((uint)param_3 >> 8);
  local_3c = (undefined)param_3;
  local_45 = (undefined)((uint)param_13 >> 0x18);
  local_46 = (undefined)((uint)param_13 >> 0x10);
  local_47 = (undefined)((uint)param_13 >> 8);
  local_48 = (undefined)param_13;
  local_49 = (undefined)((uint)param_17 >> 8);
  local_4a = (undefined)param_17;
  local_4b = (undefined)((uint)param_16 >> 8);
  local_4c = (undefined)param_16;
  local_4d = (undefined)((uint)param_14 >> 8);
  local_4f = (undefined)((uint)param_15 >> 8);
  if (param_12 != 0 || param_12 < (0xfffffffe < param_11)) {
    param_11 = 0xffffffff;
  }
  if (param_10 != 0 || param_10 < (0xfffffffe < param_9)) {
    param_9 = 0xffffffff;
  }
  uVar1 = 0xffffffff;
  if (param_19 == 0 && (0xfffffffe < param_18) <= param_19) {
    uVar1 = param_18;
  }
  local_2e = (undefined)uVar1;
  local_3a = (undefined)(param_22 + param_5);
  local_40 = (undefined)param_9;
  local_44 = (undefined)param_11;
  local_4e = (undefined)param_14;
  if (param_14 != 0) {
    param_14 = 0x14;
  }
  local_50 = (undefined)param_15;
  local_51 = 0;
  local_52 = (undefined)param_14;
  local_58 = 0x2014b50;
  local_39 = (undefined)(param_22 + param_5 >> 8);
  local_2b = (undefined)(uVar1 >> 0x18);
  local_2c = (undefined)(uVar1 >> 0x10);
  local_2d = (undefined)(uVar1 >> 8);
  local_3d = (undefined)(param_9 >> 0x18);
  local_3e = (undefined)(param_9 >> 0x10);
  local_3f = (undefined)(param_9 >> 8);
  local_41 = (undefined)(param_11 >> 0x18);
  local_42 = (undefined)(param_11 >> 0x10);
  local_43 = (undefined)(param_11 >> 8);
  iVar7 = piVar9[1];
  uVar1 = piVar9[2];
  uVar2 = iVar7 + 0x2e;
  if (uVar1 < uVar2) {
    if (uVar1 == 0) {
      uVar1 = 1;
    }
    do {
      uVar3 = uVar1;
      uVar1 = uVar3 << 1;
    } while (uVar3 < uVar2);
    iVar4 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),*piVar9,piVar9[3],uVar3);
    if (iVar4 != 0) {
      piVar9[2] = uVar3;
      *piVar9 = iVar4;
      goto LAB_00113a8c;
    }
  }
  else {
    iVar4 = *piVar9;
LAB_00113a8c:
    piVar9[1] = uVar2;
    __aeabi_memcpy(piVar9[3] * iVar7 + iVar4,&local_58,piVar9[3] * 0x2e);
    iVar7 = piVar9[1];
    uVar1 = piVar9[2];
    uVar2 = iVar7 + param_3;
    if (uVar1 < uVar2) {
      uVar3 = uVar1;
      if (uVar1 == 0) {
        uVar3 = 1;
      }
      do {
        uVar1 = uVar3;
        uVar3 = uVar1 << 1;
      } while (uVar1 < uVar2);
      iVar4 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),*piVar9,piVar9[3],uVar1)
      ;
      if (iVar4 == 0) goto LAB_00113d4c;
      piVar9[2] = uVar1;
      *piVar9 = iVar4;
      piVar9[1] = uVar2;
    }
    else {
      piVar9[1] = uVar2;
    }
    if (param_3 != 0) {
      __aeabi_memcpy(piVar9[3] * iVar7 + *piVar9,param_2,piVar9[3] * param_3);
      uVar2 = piVar9[1];
      uVar1 = piVar9[2];
    }
    uVar3 = uVar2 + param_5;
    if (uVar1 < uVar3) {
      uVar8 = uVar1;
      if (uVar1 == 0) {
        uVar8 = 1;
      }
      do {
        uVar1 = uVar8;
        uVar8 = uVar1 << 1;
      } while (uVar1 < uVar3);
      iVar7 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),*piVar9,piVar9[3],uVar1)
      ;
      if (iVar7 == 0) goto LAB_00113d4c;
      piVar9[2] = uVar1;
      *piVar9 = iVar7;
      piVar9[1] = uVar3;
    }
    else {
      piVar9[1] = uVar3;
    }
    if (param_5 != 0) {
      __aeabi_memcpy(piVar9[3] * uVar2 + *piVar9,param_4,piVar9[3] * param_5);
      uVar3 = piVar9[1];
      uVar1 = piVar9[2];
    }
    uVar2 = uVar3 + param_22;
    if (uVar1 < uVar2) {
      uVar8 = uVar1;
      if (uVar1 == 0) {
        uVar8 = 1;
      }
      do {
        uVar1 = uVar8;
        uVar8 = uVar1 << 1;
      } while (uVar1 < uVar2);
      iVar7 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),*piVar9,piVar9[3],uVar1)
      ;
      if (iVar7 == 0) goto LAB_00113d4c;
      piVar9[2] = uVar1;
      *piVar9 = iVar7;
      piVar9[1] = uVar2;
    }
    else {
      piVar9[1] = uVar2;
    }
    if (param_22 != 0) {
      __aeabi_memcpy(piVar9[3] * uVar3 + *piVar9,param_21,piVar9[3] * param_22);
      uVar2 = piVar9[1];
      uVar1 = piVar9[2];
    }
    uVar3 = uVar2 + param_7;
    if (uVar1 < uVar3) {
      if (uVar1 == 0) {
        uVar1 = 1;
      }
      do {
        uVar8 = uVar1;
        uVar1 = uVar8 << 1;
      } while (uVar8 < uVar3);
      iVar7 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),*piVar9,piVar9[3],uVar8)
      ;
      if (iVar7 == 0) goto LAB_00113d4c;
      piVar9[2] = uVar8;
      *piVar9 = iVar7;
    }
    piVar9[1] = uVar3;
    if (param_7 != 0) {
      __aeabi_memcpy(piVar9[3] * uVar2 + *piVar9,param_6,piVar9[3] * param_7);
    }
    iVar7 = piVar9[5];
    uVar1 = piVar9[6];
    uVar2 = iVar7 + 1;
    if (uVar2 <= uVar1) {
      iVar4 = piVar9[4];
LAB_00113da4:
      piVar9[5] = uVar2;
      __aeabi_memcpy(piVar9[7] * iVar7 + iVar4,&local_28);
      return 1;
    }
    if (uVar1 == 0) {
      uVar1 = 1;
    }
    do {
      uVar3 = uVar1;
      uVar1 = uVar3 << 1;
    } while (uVar3 < uVar2);
    iVar4 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),piVar9[4],piVar9[7],uVar3)
    ;
    if (iVar4 != 0) {
      piVar9[6] = uVar3;
      piVar9[4] = iVar4;
      goto LAB_00113da4;
    }
  }
LAB_00113d4c:
  if ((uint)piVar9[2] < uVar6) {
    iVar7 = (**(code **)(param_1 + 0x30))(*(undefined4 *)(param_1 + 0x34),*piVar9,piVar9[3],uVar6);
    if (iVar7 == 0) goto LAB_00113d88;
    piVar9[2] = uVar6;
    *piVar9 = iVar7;
  }
  piVar9[1] = uVar6;
LAB_00113d88:
  *(undefined4 *)(param_1 + 0x1c) = 0x10;
  return 0;
}

