/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001164ac FUN_001164ac */

undefined4 FUN_001164ac(uint *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  uint local_130;
  uint local_12c;
  undefined4 local_128;
  undefined local_124;
  undefined4 local_123;
  undefined local_11f;
  undefined local_11e;
  undefined local_11d;
  uint local_11c;
  uint local_118 [2];
  undefined local_110;
  undefined local_10f;
  undefined local_10e;
  undefined local_10d;
  undefined4 local_10c;
  undefined local_108;
  undefined local_107;
  undefined local_106;
  undefined local_105;
  undefined4 local_104;
  undefined local_100;
  undefined local_ff;
  undefined local_fe;
  undefined local_fd;
  undefined4 local_fc;
  undefined local_f8;
  undefined local_f7;
  undefined local_f6;
  undefined local_f5;
  undefined local_f4;
  undefined local_f3;
  undefined local_f2;
  undefined local_f1;
  
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  puVar5 = (undefined4 *)param_1[0x12];
  if ((puVar5 == (undefined4 *)0x0) || (param_1[5] != 2)) {
    param_1[7] = 0x18;
    return 0;
  }
  iVar1 = puVar5[0xd];
  if (iVar1 == 0) {
    uVar3 = param_1[4];
    if ((uVar3 >> 0x10 != 0) ||
       (uVar6 = puVar5[1],
       param_1[1] + (uint)CARRY4(*param_1,uVar6) + (uint)(0xffffffe9 < *param_1 + uVar6) != 0))
    goto LAB_0011658c;
  }
  else {
    uVar6 = puVar5[1];
    if (uVar6 == 0xffffffff) {
LAB_0011658c:
      param_1[7] = 2;
      return 0;
    }
    uVar3 = param_1[4];
  }
  if (uVar3 == 0) {
    uVar3 = 0;
    uVar7 = 0;
    uVar6 = 0;
  }
  else {
    uVar3 = *param_1;
    uVar7 = param_1[1];
    param_1[2] = uVar3;
    param_1[3] = uVar7;
    uVar2 = (*(code *)param_1[0xf])(param_1[0x11],(code *)param_1[0xf],uVar3,uVar7,*puVar5,uVar6);
    if (uVar2 != uVar6) {
      param_1[7] = 0x13;
      return 0;
    }
    uVar2 = *param_1;
    *param_1 = uVar2 + uVar6;
    param_1[1] = param_1[1] + (uint)CARRY4(uVar2,uVar6);
    iVar1 = puVar5[0xd];
  }
  local_12c = *param_1;
  local_130 = param_1[1];
  if (iVar1 != 0) {
    __aeabi_memclr8(local_118,0xf0);
    local_124 = 0x2c;
    local_128 = 0x6064b50;
    local_123 = 0;
    local_11f = 0;
    local_11e = 0;
    local_11d = 0;
    local_11c = 0x2d031e;
    uVar2 = param_1[4];
    local_10c = 0;
    local_110 = (undefined)uVar2;
    local_104 = 0;
    local_fc = 0;
    local_f8 = (undefined)uVar3;
    local_f4 = (undefined)uVar7;
    local_f3 = (undefined)(uVar7 >> 8);
    local_f2 = (undefined)(uVar7 >> 0x10);
    local_f1 = (undefined)(uVar7 >> 0x18);
    local_f5 = (undefined)(uVar3 >> 0x18);
    local_f6 = (undefined)(uVar3 >> 0x10);
    local_f7 = (undefined)(uVar3 >> 8);
    local_fd = (undefined)(uVar6 >> 0x18);
    local_10f = (undefined)(uVar2 >> 8);
    local_10e = (undefined)(uVar2 >> 0x10);
    local_10d = (undefined)(uVar2 >> 0x18);
    local_108 = local_110;
    local_107 = local_10f;
    local_106 = local_10e;
    local_105 = local_10d;
    local_100 = (char)uVar6;
    local_ff = (char)(uVar6 >> 8);
    local_fe = (char)(uVar6 >> 0x10);
    iVar1 = (*(code *)param_1[0xf])
                      (param_1[0x11],(code *)param_1[0xf],local_12c,local_130,&local_128,0x38);
    if (iVar1 != 0x38) goto LAB_001168cc;
    uVar2 = *param_1 + 0x38;
    uVar4 = param_1[1] + (uint)(0xffffffc7 < *param_1);
    *param_1 = uVar2;
    param_1[1] = uVar4;
    __aeabi_memclr4((uint)&local_128 | 4,0xfc);
    local_118[0] = 1;
    local_11d = (undefined)(local_12c >> 0x18);
    local_11e = (undefined)(local_12c >> 0x10);
    local_11f = (undefined)(local_12c >> 8);
    local_123 = CONCAT13((char)local_12c,(undefined3)local_123);
    local_128 = 0x7064b50;
    local_11c = local_130;
    iVar1 = (*(code *)param_1[0xf])(param_1[0x11],(code *)param_1[0xf],uVar2,uVar4,&local_128,0x14);
    if (iVar1 != 0x14) goto LAB_001168cc;
    local_12c = *param_1 + 0x14;
    local_130 = param_1[1] + (uint)(0xffffffeb < *param_1);
    *param_1 = local_12c;
    param_1[1] = local_130;
  }
  __aeabi_memclr4((uint)&local_128 | 4,0xfc);
  local_128 = 0x6054b50;
  local_118[0] = 0xffffffff;
  if (uVar7 == 0 && (0xfffffffe < uVar3) <= uVar7) {
    local_118[0] = uVar3;
  }
  uVar3 = 0xffff;
  if (param_1[4] < 0xffff) {
    uVar3 = param_1[4];
  }
  local_11e = (undefined)uVar3;
  local_11f = (undefined)(uVar3 >> 8);
  local_123 = CONCAT13(local_11e,(undefined3)local_123);
  local_11d = local_11f;
  local_11c = uVar6;
  iVar1 = (*(code *)param_1[0xf])
                    (param_1[0x11],(code *)param_1[0xf],local_12c,local_130,&local_128,0x16);
  if (iVar1 == 0x16) {
    if (((FILE *)puVar5[0xf] != (FILE *)0x0) && (iVar1 = fflush((FILE *)puVar5[0xf]), iVar1 == -1))
    {
      param_1[7] = 0x15;
      return 0;
    }
    uVar3 = *param_1;
    param_1[5] = 3;
    *param_1 = uVar3 + 0x16;
    param_1[1] = param_1[1] + (uint)(0xffffffe9 < uVar3);
    return 1;
  }
LAB_001168cc:
  param_1[7] = 0x13;
  return 0;
}

