/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011ca5c FUN_0011ca5c */

char * FUN_0011ca5c(char *param_1,char *param_2)

{
  char cVar1;
  size_t __n;
  int iVar2;
  char *unaff_r6;
  
  if (param_1 != (char *)0x0) {
    unaff_r6 = param_2;
  }
  if ((param_1 != (char *)0x0 && param_2 != (char *)0x0) && (__n = FUN_0011c904(unaff_r6), __n != 0)
     ) {
    cVar1 = *param_1;
    while (cVar1 != '\0') {
      iVar2 = strncasecmp(param_1,unaff_r6,__n);
      if (iVar2 == 0) {
        return param_1;
      }
      param_1 = param_1 + 1;
      cVar1 = *param_1;
    }
  }
  return (char *)0x0;
}

