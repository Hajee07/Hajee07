/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000322ec FUN_000322ec */

void FUN_000322ec(int param_1,int param_2,int param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  char *local_34;
  int *local_30;
  int local_2c;
  int *local_28;
  int local_24;
  ushort local_1c;
  
  if (*(int *)(param_1 + 0x10) == 0) {
    bVar1 = true;
    for (local_1c = 0; local_1c != *(ushort *)(*(int *)(param_1 + 8) + 0x2c);
        local_1c = local_1c + 1) {
      if (*(int *)(param_2 + (uint)local_1c * 0x20) == 1) {
        if (bVar1) {
          *(int *)(param_1 + 0x28) =
               *(int *)(param_1 + 8) - *(int *)(param_2 + (uint)local_1c * 0x20 + 8);
          bVar1 = false;
        }
        iVar2 = param_2 + (uint)local_1c * 0x20;
        *(int *)(param_1 + 0x10) =
             (*(int *)(iVar2 + 8) + *(int *)(iVar2 + 0x14) + *(int *)(param_1 + 0x28)) -
             *(int *)(param_1 + 8);
      }
    }
  }
  iVar2 = *(int *)(param_1 + 0x28);
  *(undefined *)(param_1 + 0x3c) = 1;
  local_24 = 0;
  while( true ) {
    if (local_24 == param_3) goto LAB_000325c4;
    if (*(int *)(param_2 + local_24 * 0x20) == 2) break;
    local_24 = local_24 + 1;
  }
  *(int *)(param_1 + 0x14) = *(int *)(param_2 + local_24 * 0x20 + 8) + *(int *)(param_1 + 0x28);
  for (local_28 = *(int **)(param_1 + 0x14); *local_28 != 0; local_28 = local_28 + 2) {
    if (*local_28 == 6) {
      *(int *)(param_1 + 0x18) = local_28[1] + iVar2;
    }
    else if (*local_28 == 5) {
      *(int *)(param_1 + 0x1c) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_00032720) {
      *(int *)(param_1 + 0x20) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_00032724) {
      *(int *)(param_1 + 0x24) = local_28[1] + *(int *)(param_1 + 0x28);
    }
    else if (*local_28 == 4) {
      *(int *)(param_1 + 0x2c) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_00032728) {
      *(int *)(param_1 + 0x30) = local_28[1] + iVar2;
    }
  }
LAB_000325c4:
  if (*(int *)(param_1 + 0x24) != 0) {
    local_2c = *(int *)(param_1 + 0x24);
    while( true ) {
      local_30 = (int *)(local_2c + *(int *)(local_2c + 0xc));
      if ((*(ushort *)(local_2c + 2) & 1) != 0) {
        *(int *)(param_1 + 0x38) = *(int *)(param_1 + 0x1c) + *local_30;
        *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(local_2c + 8);
        return;
      }
      for (; local_30[1] != 0; local_30 = (int *)((int)local_30 + local_30[1])) {
      }
      if (*(int *)(local_2c + 0x10) == 0) break;
      local_2c = local_2c + *(int *)(local_2c + 0x10);
    }
  }
  if (*(int *)(param_1 + 0x38) == 0) {
    local_34 = strrchr((char *)(param_1 + 0x3d),0x2f);
    if (local_34 == (char *)0x0) {
      local_34 = (char *)(param_1 + 0x3d);
    }
    else {
      local_34 = local_34 + 1;
    }
    *(char **)(param_1 + 0x38) = local_34;
    uVar3 = FUN_000315d0(*(undefined4 *)(param_1 + 0x38));
    *(undefined4 *)(param_1 + 0x34) = uVar3;
  }
  return;
}

