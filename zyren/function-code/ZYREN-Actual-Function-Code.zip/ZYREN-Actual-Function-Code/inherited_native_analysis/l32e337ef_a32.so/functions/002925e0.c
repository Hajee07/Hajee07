/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002925e0 __aeabi_memclr8 */

void __aeabi_memclr8(void)

{
  (*(code *)PTR___aeabi_memclr8_00307d74)();
  return;
}

