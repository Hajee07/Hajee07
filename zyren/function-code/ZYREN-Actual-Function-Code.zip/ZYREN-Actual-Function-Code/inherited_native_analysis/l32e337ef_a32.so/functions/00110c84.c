/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110c84 FUN_00110c84 */

uint FUN_00110c84(uint *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  uint uVar5;
  byte *pbVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  byte *param_5;
  uint param_6;
  
  uVar5 = ~*param_1;
  if (param_6 < 4) {
    uVar7 = param_6;
    if (param_6 == 0) goto LAB_00110d74;
  }
  else {
    uVar8 = param_6 - 4 & 0xfffffffc;
    iVar9 = DAT_00110d8c + 0x110ccc;
    pbVar6 = param_5;
    uVar7 = param_6;
    do {
      bVar4 = *pbVar6;
      pbVar1 = pbVar6 + 1;
      uVar7 = uVar7 - 4;
      pbVar2 = pbVar6 + 2;
      pbVar3 = pbVar6 + 3;
      pbVar6 = pbVar6 + 4;
      uVar5 = *(uint *)(iVar9 + (uVar5 & 0xff ^ (uint)bVar4) * 4) ^ uVar5 >> 8;
      uVar5 = *(uint *)(iVar9 + (uVar5 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar5 >> 8;
      uVar5 = *(uint *)(iVar9 + (uVar5 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar5 >> 8;
      uVar5 = *(uint *)(iVar9 + (uVar5 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar5 >> 8;
    } while (3 < uVar7);
    uVar7 = (param_6 - 4) - uVar8;
    param_5 = param_5 + uVar8 + 4;
    if (uVar7 == 0) goto LAB_00110d74;
  }
  do {
    uVar7 = uVar7 - 1;
    uVar5 = *(uint *)(DAT_00110d88 + 0x110d5c + (uVar5 & 0xff ^ (uint)*param_5) * 4) ^ uVar5 >> 8;
    param_5 = param_5 + 1;
  } while (uVar7 != 0);
LAB_00110d74:
  *param_1 = ~uVar5;
  return param_6;
}

