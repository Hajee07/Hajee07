/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d4fc FUN_0021d4fc */

int FUN_0021d4fc(int param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  
  if (param_3 != 0) {
    iVar2 = 0;
    do {
      cVar1 = *(char *)(param_2 + iVar2);
      *(char *)(param_1 + iVar2) = cVar1;
      if (cVar1 == '\0') {
        if (param_3 + -1 == iVar2) {
          return param_1;
        }
        __aeabi_memclr(param_1 + iVar2 + 1);
        return param_1;
      }
      iVar2 = iVar2 + 1;
    } while (param_3 != iVar2);
  }
  return param_1;
}

