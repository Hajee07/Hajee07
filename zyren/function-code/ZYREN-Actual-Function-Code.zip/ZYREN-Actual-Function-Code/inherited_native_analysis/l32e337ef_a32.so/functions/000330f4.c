/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000330f4 FUN_000330f4 */

void FUN_000330f4(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  int iVar6;
  
  iVar3 = 0;
  *param_1 = 0;
  param_1[1] = 0;
  do {
    *(char *)((int)param_1 + iVar3 + 8) = (char)iVar3;
    iVar3 = iVar3 + 1;
  } while (iVar3 != 0x100);
  iVar4 = 0;
  iVar6 = DAT_00033170 + 0x3312c;
  bVar5 = 0;
  iVar3 = 0;
  do {
    cVar2 = *(char *)((int)param_1 + iVar4 + 8);
    bVar5 = cVar2 + bVar5 + *(char *)(iVar6 + iVar3);
    *(undefined *)((int)param_1 + iVar4 + 8) = *(undefined *)((int)param_1 + bVar5 + 8);
    *(char *)((int)param_1 + bVar5 + 8) = cVar2;
    bVar1 = 0xe < iVar3;
    iVar3 = iVar3 + 1;
    if (bVar1) {
      iVar3 = 0;
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 != 0x100);
  return;
}

