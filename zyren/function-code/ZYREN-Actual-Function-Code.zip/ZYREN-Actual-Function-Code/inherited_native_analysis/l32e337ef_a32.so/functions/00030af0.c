/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030af0 FUN_00030af0 */

void ** FUN_00030af0(char *param_1)

{
  char cVar1;
  int iVar2;
  void **__s;
  long lVar3;
  void *pvVar4;
  uint uVar5;
  ushort uVar6;
  void **ppvVar7;
  int iVar8;
  void *__dest;
  uint *puVar9;
  bool bVar10;
  
  __s = (void **)malloc(0x60);
  ppvVar7 = (void **)0x0;
  memset(__s,0,0x60);
  lVar3 = sysconf(0x27);
  if (*param_1 == '\x7f') {
    cVar1 = param_1[1];
    bVar10 = cVar1 == 'E';
    if (bVar10) {
      cVar1 = param_1[2];
    }
    if (bVar10 && cVar1 == 'L') {
      cVar1 = param_1[3];
      bVar10 = cVar1 == 'F';
      if (bVar10) {
        cVar1 = param_1[4];
      }
      if (bVar10 && cVar1 == '\x01') {
        FUN_00031324(param_1,lVar3,__s);
        iVar8 = *(int *)(param_1 + 0x1c);
        uVar6 = 0;
        pvVar4 = mmap((void *)0x0,(size_t)__s[1],0,0x22,0,0);
        *__s = pvVar4;
        if (*(short *)(param_1 + 0x2c) != 0) {
          do {
            if (*(int *)(param_1 + (uint)uVar6 * 0x20 + iVar8) == 1) {
              iVar2 = (uint)uVar6 * 0x20 + iVar8;
              puVar9 = (uint *)(param_1 + iVar2 + 0x14);
              __dest = (void *)((int)*__s + (*(int *)(param_1 + iVar2 + 8) - (int)__s[2]));
              pvVar4 = (void *)((uint)__dest & -lVar3);
              mprotect(pvVar4,(int)__dest + (*puVar9 - (int)pvVar4),3);
              memcpy(__dest,param_1 + *(int *)(param_1 + iVar2 + 4),
                     *(size_t *)(param_1 + iVar2 + 0x10));
              uVar5 = *(uint *)(param_1 + iVar2 + 0x10);
              if (uVar5 < *puVar9) {
                memset((void *)((int)__dest + uVar5),0,*puVar9 - uVar5);
              }
              uVar5 = *(uint *)(param_1 + iVar2 + 0x18);
              mprotect(pvVar4,(int)__dest + (*puVar9 - (int)pvVar4),
                       (uVar5 << 0x1d) >> 0x1f | uVar5 & 2 | (uVar5 & 1) << 2);
            }
            uVar6 = uVar6 + 1;
          } while (uVar6 != *(ushort *)(param_1 + 0x2c));
        }
        FUN_0003052c(__s);
        ppvVar7 = __s;
      }
    }
  }
  return ppvVar7;
}

