/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9b0c FUN_001f9b0c */

void FUN_001f9b0c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
                    /* WARNING: Could not recover jumptable at 0x001f9bac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_001f9b54 + DAT_001f9b54))(param_1,param_2,param_3,param_4);
  return;
}

