/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030c94 FUN_00030c94 */

void FUN_00030c94(int param_1)

{
  int iVar1;
  void *pvVar2;
  int iVar3;
  char *__s;
  int *piVar4;
  
  piVar4 = *(int **)(param_1 + 0xc);
  iVar1 = 0;
  do {
    if (*piVar4 == 1) {
      iVar1 = iVar1 + 1;
    }
    else if (*piVar4 == 0) {
      *(int *)(param_1 + 0x5c) = iVar1;
      pvVar2 = malloc(iVar1 << 2);
      *(void **)(param_1 + 0x58) = pvVar2;
      if (pvVar2 == (void *)0x0) {
        __android_log_print(4,DAT_00030d64 + 0x30d50,DAT_00030d68 + 0x30d58);
                    /* WARNING: Subroutine does not return */
        exit(0xdf);
      }
      piVar4 = (int *)(*(int *)(param_1 + 0xc) + 4);
      iVar1 = 0;
      do {
        if (piVar4[-1] == 1) {
          iVar3 = dlopen(*(int *)(param_1 + 0x28) + *piVar4,0);
          if (iVar3 == 0) {
            __s = (char *)dlerror();
            puts(__s);
          }
          *(int *)(*(int *)(param_1 + 0x58) + iVar1 * 4) = iVar3;
          iVar1 = iVar1 + 1;
        }
        else if (piVar4[-1] == 0) {
          return;
        }
        piVar4 = piVar4 + 2;
      } while( true );
    }
    piVar4 = piVar4 + 2;
  } while( true );
}

