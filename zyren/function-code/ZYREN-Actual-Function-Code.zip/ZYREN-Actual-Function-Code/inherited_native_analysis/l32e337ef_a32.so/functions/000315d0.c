/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000315d0 FUN_000315d0 */

uint FUN_000315d0(byte *param_1)

{
  uint uVar1;
  uint local_8;
  byte *local_4;
  
  local_8 = 0;
  local_4 = param_1;
  while (*local_4 != 0) {
    local_8 = local_8 * 0x10 + (uint)*local_4;
    uVar1 = local_8 & 0xf0000000;
    if (uVar1 != 0) {
      local_8 = local_8 ^ uVar1 >> 0x18;
    }
    local_8 = local_8 & (uVar1 ^ 0xffffffff);
    local_4 = local_4 + 1;
  }
  return local_8;
}

