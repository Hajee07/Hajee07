/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032014 FUN_00032014 */

undefined4 FUN_00032014(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  size_t local_3c;
  undefined4 *local_2c;
  ushort local_22;
  int local_20;
  int local_1c;
  
  if ((*(short *)(param_1 + 3) != 0) && (param_1[2] != 0)) {
    local_1c = 0;
    local_20 = 0;
    for (local_22 = 0; local_22 != *(ushort *)(param_1 + 3); local_22 = local_22 + 1) {
      if (*(int *)(param_1[2] + (uint)local_22 * 0x20) == 1) {
        if (local_20 == 0) {
          local_20 = *(int *)(param_1[2] + (uint)local_22 * 0x20 + 8) + *param_1;
        }
        if ((*(uint *)(param_1[2] + (uint)local_22 * 0x20 + 4) <= *(uint *)(local_20 + 0x1c)) &&
           (iVar2 = param_1[2] + (uint)local_22 * 0x20,
           *(uint *)(local_20 + 0x1c) < (uint)(*(int *)(iVar2 + 4) + *(int *)(iVar2 + 0x10)))) {
          iVar2 = param_1[2] + (uint)local_22 * 0x20;
          local_1c = (*(int *)(local_20 + 0x1c) - *(int *)(iVar2 + 4)) +
                     *(int *)(iVar2 + 8) + *param_1;
          break;
        }
      }
    }
    if ((local_20 != 0) && (local_1c != 0)) {
      for (local_2c = (undefined4 *)*param_3; local_2c != param_3;
          local_2c = (undefined4 *)*local_2c) {
        if (local_2c[2] == local_20) {
          return 0;
        }
      }
      if (param_1[1] == 0) {
        local_3c = 0;
      }
      else {
        local_3c = strlen((char *)param_1[1]);
      }
      puVar1 = (undefined4 *)calloc(1,local_3c + 0x40);
      puVar1[2] = local_20;
      if (param_1[1] != 0) {
        strcpy((char *)((int)puVar1 + 0x3d),(char *)param_1[1]);
      }
      FUN_000322ec(puVar1,local_1c,*(undefined2 *)(local_20 + 0x2c));
      *puVar1 = param_3;
      puVar1[1] = param_3[1];
      *(undefined4 **)puVar1[1] = puVar1;
      param_3[1] = puVar1;
    }
  }
  return 0;
}

