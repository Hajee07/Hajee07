/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011ba88 FUN_0011ba88 */

/* WARNING: Type propagation algorithm not settling */

code * FUN_0011ba88(byte *param_1)

{
  byte bVar1;
  byte *pbVar2;
  undefined4 uVar3;
  code *pcVar4;
  void *******pppppppvVar5;
  void ******ppppppvVar6;
  uint uVar7;
  int iVar8;
  void *******pppppppvVar9;
  void ******ppppppvVar10;
  int extraout_r1;
  int extraout_r1_00;
  int extraout_r1_01;
  void ********__ptr;
  void ********ppppppppvVar11;
  uint uVar12;
  void ******ppppppvVar13;
  code *pcVar14;
  void ******ppppppvVar15;
  void *******pppppppvVar16;
  void ********local_2c;
  void ********local_28;
  
  local_2c = &local_2c;
  local_28 = &local_2c;
  uVar3 = dlopen(DAT_0011bda8 + 0x11baac,0);
  pcVar4 = (code *)dlsym(uVar3,DAT_0011bdac + 0x11bac8);
  dlclose(uVar3);
  pcVar14 = (code *)(DAT_0011bdb0 + 0x11baec);
  if (pcVar4 != (code *)0x0) {
    pcVar14 = pcVar4;
  }
  (*pcVar14)(DAT_0011bdb4 + 0x11baf0,&local_2c);
  __ptr = local_2c;
  if ((void *********)local_2c == &local_2c) {
    return (code *)0x0;
  }
  ppppppppvVar11 = local_2c;
joined_r0x0011bb14:
  if (ppppppppvVar11 != (void ********)0x0) {
    pppppppvVar16 = ppppppppvVar11[0xb];
    if (pppppppvVar16 == (void *******)0x0) {
      pppppppvVar16 = ppppppppvVar11[10];
      if (pppppppvVar16 != (void *******)0x0) {
        pppppppvVar9 = ppppppppvVar11[5];
        pppppppvVar5 = ppppppppvVar11[6];
        bVar1 = *param_1;
        uVar12 = 0;
        pbVar2 = param_1 + 1;
        while (bVar1 != 0) {
          uVar12 = uVar12 * 0x10 + (uint)bVar1;
          bVar1 = *pbVar2;
          uVar7 = uVar12 & 0xf0000000;
          if (uVar7 != 0) {
            uVar12 = uVar12 ^ uVar7 >> 0x18;
          }
          uVar12 = uVar12 & ~uVar7;
          pbVar2 = pbVar2 + 1;
        }
        ppppppvVar6 = *pppppppvVar16;
        __aeabi_uidivmod(uVar12,ppppppvVar6);
        for (ppppppvVar15 = pppppppvVar16[extraout_r1_01 + 2]; ppppppvVar15 != (void ******)0x0;
            ppppppvVar15 = pppppppvVar16[(int)ppppppvVar15 + (int)ppppppvVar6 + 2]) {
          if ((*(short *)((int)pppppppvVar9 + (int)ppppppvVar15 * 0x10 + 0xe) != 0) &&
             (iVar8 = strcmp((char *)((int)pppppppvVar5 + (int)pppppppvVar9[(int)ppppppvVar15 * 4]),
                             (char *)param_1), iVar8 == 0)) goto LAB_0011bcf8;
        }
      }
    }
    else {
      pppppppvVar5 = ppppppppvVar11[6];
      uVar12 = 0x1505;
      pppppppvVar9 = ppppppppvVar11[5];
      bVar1 = *param_1;
      pbVar2 = param_1 + 1;
      while (bVar1 != 0) {
        uVar12 = uVar12 * 0x21 + (uint)bVar1;
        bVar1 = *pbVar2;
        pbVar2 = pbVar2 + 1;
      }
      ppppppvVar6 = pppppppvVar16[2];
      ppppppvVar10 = *pppppppvVar16;
      ppppppvVar13 = pppppppvVar16[1];
      __aeabi_uidivmod(uVar12);
      ppppppvVar15 = pppppppvVar16[(int)ppppppvVar6 + extraout_r1 + 4];
      if ((ppppppvVar13 <= ppppppvVar15) &&
         (__aeabi_uidivmod(uVar12 >> 5,ppppppvVar6),
         uVar7 = 1 << (uVar12 >> ((uint)pppppppvVar16[3] & 0xff) & 0x1f) | 1 << (uVar12 & 0x1f),
         (uVar7 & (uint)pppppppvVar16[extraout_r1_00 + 4]) == uVar7)) {
        pppppppvVar16 =
             pppppppvVar16 +
             (int)ppppppvVar15 + (int)ppppppvVar6 + (int)ppppppvVar10 + (4 - (int)ppppppvVar13);
        ppppppvVar6 = *pppppppvVar16;
        while( true ) {
          if ((((uint)ppppppvVar6 ^ uVar12) < 2) &&
             (iVar8 = strcmp((char *)((int)pppppppvVar5 + (int)pppppppvVar9[(int)ppppppvVar15 * 4]),
                             (char *)param_1), iVar8 == 0)) goto LAB_0011bcf8;
          if (((uint)ppppppvVar6 & 1) != 0) break;
          pppppppvVar16 = pppppppvVar16 + 1;
          ppppppvVar15 = (void ******)((int)ppppppvVar15 + 1);
          ppppppvVar6 = *pppppppvVar16;
        }
      }
    }
  }
  goto LAB_0011bb18;
LAB_0011bcf8:
  if ((ppppppvVar15 != (void ******)0x0) &&
     (*(short *)((int)pppppppvVar9 + (int)ppppppvVar15 * 0x10 + 0xe) != 0)) {
    pcVar14 = (code *)((int)ppppppppvVar11[9] + (int)pppppppvVar9[(int)ppppppvVar15 * 4 + 1]);
    if ((*(byte *)(pppppppvVar9 + (int)ppppppvVar15 * 4 + 3) & 0xf) != 10) goto LAB_0011bd54;
    pcVar14 = (code *)(*pcVar14)(pcVar14);
    __ptr = local_2c;
    if ((void *********)local_2c == &local_2c || local_2c == (void ********)0x0) {
      return pcVar14;
    }
    goto LAB_0011bd74;
  }
LAB_0011bb18:
  ppppppppvVar11 = (void ********)*ppppppppvVar11;
  if ((void *********)ppppppppvVar11 == &local_2c) {
    pcVar14 = (code *)0x0;
LAB_0011bd54:
    if ((void *********)__ptr != &local_2c && __ptr != (void ********)0x0) {
LAB_0011bd74:
      do {
        ppppppppvVar11 = (void ********)*__ptr;
        pppppppvVar16 = __ptr[1];
        ppppppppvVar11[1] = pppppppvVar16;
        *pppppppvVar16 = ppppppppvVar11;
        free(__ptr);
        if ((void *********)ppppppppvVar11 == &local_2c) {
          return pcVar14;
        }
        __ptr = ppppppppvVar11;
      } while (ppppppppvVar11 != (void ********)0x0);
    }
    return pcVar14;
  }
  goto joined_r0x0011bb14;
}

