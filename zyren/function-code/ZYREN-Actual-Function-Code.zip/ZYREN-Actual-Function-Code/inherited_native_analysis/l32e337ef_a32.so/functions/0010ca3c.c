/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010ca3c FUN_0010ca3c */

uint FUN_0010ca3c(uint *param_1,undefined4 param_2,uint param_3,uint param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = *param_1;
  uVar3 = param_1[1];
  uVar2 = 0;
  if (param_4 <= uVar3 && (uint)(uVar4 <= param_3) <= param_4 - uVar3) {
    uVar1 = uVar4 - param_3;
    uVar3 = uVar3 - (param_4 + (uVar4 < param_3));
    param_4 = uVar3 - (param_6 > uVar1);
    uVar2 = param_6;
    if (uVar3 == 0 && (param_6 <= uVar1) <= uVar3) {
      uVar2 = uVar1;
    }
  }
  __aeabi_memcpy(param_5,*(int *)(param_1[0x12] + 0x48) + param_3,uVar2,param_4);
  return uVar2;
}

