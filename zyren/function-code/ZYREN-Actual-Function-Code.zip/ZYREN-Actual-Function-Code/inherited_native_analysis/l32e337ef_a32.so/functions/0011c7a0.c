/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c7a0 FUN_0011c7a0 */

char * FUN_0011c7a0(char *param_1)

{
  char *pcVar1;
  
  if (param_1 != (char *)0x0) {
    pcVar1 = strrchr(param_1,0x2f);
    if (pcVar1 != (char *)0x0) {
      param_1 = pcVar1 + 1;
    }
    return param_1;
  }
  return (char *)0x0;
}

