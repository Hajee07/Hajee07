/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010c8a4 FUN_0010c8a4 */

undefined4 FUN_0010c8a4(uint *param_1,int param_2,uint param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  code *pcVar3;
  code *pcVar4;
  undefined4 uVar5;
  bool bVar6;
  
  if (param_2 == 0) {
    uVar5 = 0;
    if (param_1 != (uint *)0x0) {
LAB_0010c90c:
      param_1[7] = 0x18;
      return 0;
    }
  }
  else {
    uVar5 = 0;
    if (param_3 < 0x16) {
      if (param_1 != (uint *)0x0) {
        param_1[7] = 8;
        return 0;
      }
    }
    else if (param_1 != (uint *)0x0) {
      uVar1 = param_1[0x12];
      bVar6 = uVar1 == 0;
      if (bVar6) {
        uVar1 = param_1[5];
      }
      if (!bVar6 || uVar1 != 0) goto LAB_0010c90c;
      pcVar3 = (code *)param_1[10];
      pcVar4 = pcVar3;
      if (pcVar3 == (code *)0x0) {
        pcVar4 = DAT_0010ca2c;
      }
      uVar5 = 1;
      if (pcVar3 == (code *)0x0) {
        pcVar4 = pcVar4 + 0x10c948;
        param_1[10] = (uint)pcVar4;
      }
      if (param_1[0xb] == 0) {
        param_1[0xb] = DAT_0010ca30 + 0x10c95c;
      }
      if (param_1[0xc] == 0) {
        param_1[0xc] = DAT_0010ca34 + 0x10c970;
      }
      param_1[7] = 0;
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      uVar1 = (*pcVar4)(param_1[0xd],1,0x58);
      param_1[0x12] = uVar1;
      if (uVar1 == 0) {
        param_1[7] = 0x10;
        return 0;
      }
      __aeabi_memclr8(uVar1,0x58);
      iVar2 = DAT_0010ca38;
      uVar1 = param_1[0x12];
      *(undefined4 *)(uVar1 + 0x2c) = 4;
      *(undefined4 *)(uVar1 + 0x30) = param_4;
      *(undefined4 *)(uVar1 + 0x34) = 0;
      *(undefined4 *)(uVar1 + 0x38) = 0;
      *(undefined4 *)(uVar1 + 0x1c) = 4;
      *(undefined4 *)(uVar1 + 0xc) = 1;
      *param_1 = param_3;
      param_1[1] = 0;
      param_1[5] = 1;
      param_1[6] = 2;
      param_1[0xe] = iVar2 + 0x10c9c0;
      param_1[0x10] = 0;
      param_1[0x11] = (uint)param_1;
      *(int *)(uVar1 + 0x48) = param_2;
      *(uint *)(uVar1 + 0x4c) = param_3;
      iVar2 = FUN_0010bbd0(param_1,param_4);
      if (iVar2 == 0) {
        uVar5 = 0;
        FUN_0010b938(param_1,0);
      }
    }
  }
  return uVar5;
}

