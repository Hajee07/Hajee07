/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c06c FUN_0011c06c */

undefined4 FUN_0011c06c(int *param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  size_t sVar3;
  int iVar4;
  int **ppiVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  char *__s;
  uint uVar13;
  int iVar14;
  int *unaff_r10;
  bool bVar15;
  
  uVar10 = (uint)*(ushort *)(param_1 + 3);
  piVar2 = param_1;
  if (uVar10 != 0) {
    piVar2 = (int *)param_1[2];
    unaff_r10 = param_1;
  }
  if (uVar10 == 0 || piVar2 == (int *)0x0) {
    return 0;
  }
  __s = (char *)unaff_r10[1];
  if (__s == (char *)0x0) {
    piVar2 = (int *)calloc(1,0x3c);
  }
  else {
    sVar3 = strlen(__s);
    piVar2 = (int *)calloc(1,sVar3 + 0x3c);
    strcpy((char *)(piVar2 + 0xe),__s);
    uVar10 = (uint)*(ushort *)(unaff_r10 + 3);
    if (uVar10 == 0) {
LAB_0011c184:
      if (piVar2 == (int *)0x0) {
        return 0;
      }
      goto LAB_0011c1ac;
    }
  }
  piVar8 = (int *)0x0;
  iVar9 = 0;
  piVar7 = (int *)unaff_r10[2] + 2;
  if (*(int *)unaff_r10[2] == 1) goto LAB_0011c12c;
LAB_0011c10c:
  do {
    do {
      piVar8 = (int *)((int)piVar8 + 1);
      piVar6 = piVar7 + 8;
      if (((uint)piVar8 & 0xffff) == uVar10) goto LAB_0011c184;
      piVar1 = piVar7 + 6;
      piVar7 = piVar6;
    } while (*piVar1 != 1);
LAB_0011c12c:
    iVar4 = piVar2[2];
    if (iVar4 == 0) {
      iVar4 = *unaff_r10 + *piVar7;
      piVar2[2] = iVar4;
      uVar13 = piVar7[-1];
      uVar11 = *(uint *)(iVar4 + 0x1c);
      iVar9 = iVar4;
      if (uVar11 < uVar13) goto LAB_0011c10c;
    }
    else {
      uVar13 = piVar7[-1];
      uVar11 = *(uint *)(iVar9 + 0x1c);
      if (uVar11 < uVar13) goto LAB_0011c10c;
    }
  } while (piVar7[2] + uVar13 <= uVar11);
  bVar15 = iVar9 == 0;
  if (!bVar15) {
    piVar8 = (int *)(*piVar7 + (uVar11 - uVar13) + *unaff_r10);
    bVar15 = piVar8 == (int *)0x0;
  }
  if (!bVar15) {
    uVar10 = (uint)*(ushort *)(iVar9 + 0x2c);
    if (uVar10 != 0) {
      bVar15 = true;
      iVar9 = 0;
      iVar12 = *piVar8;
      while( true ) {
        if (iVar12 == 1) {
          iVar12 = piVar8[iVar9 * 8 + 2];
          if (bVar15) {
            iVar14 = iVar4 - iVar12;
            piVar2[9] = iVar14;
          }
          else {
            iVar14 = piVar2[9];
          }
          piVar2[4] = (iVar14 + iVar12) - iVar4;
          bVar15 = false;
        }
        if (uVar10 == (iVar9 + 1U & 0xffff)) break;
        iVar9 = iVar9 + 1;
        iVar12 = piVar8[iVar9 * 8];
      }
      if (uVar10 != 0) {
        iVar9 = piVar2[9];
        piVar8 = piVar8 + 2;
        do {
          if (piVar8[-2] == 2) {
            iVar4 = *(int *)(*piVar8 + iVar9);
            piVar7 = (int *)(*piVar8 + iVar9) + 1;
            goto joined_r0x0011c288;
          }
          uVar10 = uVar10 - 1;
          piVar8 = piVar8 + 8;
        } while (uVar10 != 0);
      }
    }
switchD_0011c2bc_caseD_0:
    iVar9 = piVar2[8];
    if (iVar9 != 0) {
      if ((*(byte *)(iVar9 + 2) & 1) == 0) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      piVar2[0xd] = piVar2[6] + *(int *)(iVar9 + *(int *)(iVar9 + 0xc));
      piVar2[0xc] = *(int *)(iVar9 + 8);
    }
    ppiVar5 = *(int ***)(param_3 + 4);
    *piVar2 = param_3;
    piVar2[1] = (int)ppiVar5;
    *ppiVar5 = piVar2;
    *(int **)(param_3 + 4) = piVar2;
    return 0;
  }
LAB_0011c1ac:
  free(piVar2);
  return 0;
joined_r0x0011c288:
  if (iVar4 < 0x6ffffef5) goto LAB_0011c2ac;
LAB_0011c318:
  if (iVar4 == 0x6ffffef5) {
    piVar2[0xb] = *piVar7 + iVar9;
    goto switchD_0011c2bc_caseD_1;
  }
  if (iVar4 != 0x6ffffff0) {
    if (iVar4 == 0x6ffffffc) {
      piVar2[8] = *piVar7 + iVar9;
      iVar4 = piVar7[1];
      piVar7 = piVar7 + 2;
      goto joined_r0x0011c288;
    }
switchD_0011c2bc_caseD_1:
    iVar4 = piVar7[1];
    do {
      piVar7 = piVar7 + 2;
      if (0x6ffffef4 < iVar4) goto LAB_0011c318;
LAB_0011c2ac:
      switch(iVar4) {
      case 0:
        goto switchD_0011c2bc_caseD_0;
      default:
        goto switchD_0011c2bc_caseD_1;
      case 4:
        piVar2[10] = *piVar7 + iVar9;
        iVar4 = piVar7[1];
        goto joined_r0x0011c388;
      case 5:
        piVar2[6] = *piVar7 + iVar9;
        iVar4 = piVar7[1];
        break;
      case 6:
        piVar2[5] = *piVar7 + iVar9;
        iVar4 = piVar7[1];
        goto joined_r0x0011c388;
      }
    } while( true );
  }
  piVar2[7] = *piVar7 + iVar9;
  iVar4 = piVar7[1];
joined_r0x0011c388:
  piVar7 = piVar7 + 2;
  goto joined_r0x0011c288;
}

