/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010ac08 FUN_0010ac08 */

undefined4
FUN_0010ac08(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_20;
  undefined4 local_1c;
  int local_18;
  undefined4 local_14;
  
  local_14 = 0;
  local_20 = 0;
  uVar2 = 0;
  if (param_1 != 0) {
    local_1c = param_2;
    local_18 = param_1;
    iVar1 = FUN_0010a934(param_3,param_4,DAT_0010ac74 + 0x10ac44,&local_20,param_5);
    if (iVar1 != 0) {
      uVar2 = local_20;
    }
  }
  return uVar2;
}

