/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031a84 FUN_00031a84 */

undefined4 FUN_00031a84(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_c;
  
  iVar1 = FUN_00031adc(param_1,param_2);
  if (iVar1 == 0) {
    local_c = 0;
  }
  else {
    local_c = *(undefined4 *)(iVar1 + 8);
  }
  return local_c;
}

