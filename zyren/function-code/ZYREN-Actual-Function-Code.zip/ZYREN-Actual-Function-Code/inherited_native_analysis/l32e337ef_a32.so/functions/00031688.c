/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031688 FUN_00031688 */

undefined *
FUN_00031688(undefined *param_1,int param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  undefined *local_2c;
  undefined *local_28;
  int local_24;
  
  *param_3 = 0;
  *param_4 = 0;
  *param_6 = 0;
  *param_5 = 0;
  local_24 = 0;
  local_28 = (undefined *)0x0;
  local_2c = param_1;
  do {
    if (param_1 + param_2 <= local_2c) {
      return (undefined *)0x0;
    }
    switch(*local_2c) {
    case 9:
    case 0x20:
      local_28 = (undefined *)0x0;
      break;
    case 10:
    case 0xd:
      *local_2c = 0;
      return local_2c + (1 - (int)param_1);
    default:
switchD_00031720_caseD_b:
      if (local_28 == (undefined *)0x0) {
        local_28 = local_2c;
        switch(local_24) {
        case 0:
          *param_3 = local_2c;
          break;
        case 1:
          *param_4 = local_2c;
          break;
        case 2:
          if (param_1 + param_2 < local_2c + 4) {
            return (undefined *)0x0;
          }
          *param_5 = local_2c;
          break;
        case 6:
          *param_6 = local_2c;
        }
        local_24 = local_24 + 1;
      }
      break;
    case 0x2d:
      if (local_24 != 1) goto switchD_00031720_caseD_b;
      local_28 = (undefined *)0x0;
    }
    local_2c = local_2c + 1;
  } while( true );
}

