/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010e3c0 FUN_0010e3c0 */

undefined4
FUN_0010e3c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_24;
  
  uVar2 = 0;
  iVar1 = FUN_0010d5e8(param_1,param_2,0,param_5,&local_24);
  if (iVar1 != 0) {
    uVar2 = FUN_0010dc40(param_1,local_24,param_3,param_4,param_5,param_6,param_7,0);
  }
  return uVar2;
}

