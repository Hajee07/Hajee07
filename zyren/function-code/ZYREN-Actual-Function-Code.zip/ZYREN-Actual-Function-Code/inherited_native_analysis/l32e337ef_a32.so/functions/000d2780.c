/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000d2780 FUN_000d2780 */

undefined4 FUN_000d2780(int **param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  int **local_2c;
  ushort local_26;
  int **local_18;
  
  bVar4 = *(int *)(DAT_000d2a3c + 0xd27b0) == 0;
  if (bVar4) {
    thunk_FUN_001a3eec(param_1);
  }
  else {
    dl_iterate_phdr(DAT_000d2a30 + 0xd27c4,param_1);
  }
  local_18 = (int **)*param_1;
  do {
    if (local_18 == param_1) {
      if (bVar4) {
        FUN_0003272c(param_1);
      }
      local_18 = (int **)*param_1;
      while( true ) {
        if (local_18 != param_1) {
          local_2c = (int **)*local_18;
        }
        if (local_18 == param_1 || local_18 == (int **)0x0) break;
        if (((local_18[6] == (int *)0x0) || (local_18[7] == (int *)0x0)) ||
           ((local_18[0xb] == (int *)0x0 && (local_18[0xc] == (int *)0x0)))) {
          piVar1 = *local_18;
          piVar3 = local_18[1];
          piVar1[1] = (int)piVar3;
          *piVar3 = (int)piVar1;
          free(local_18);
        }
        local_18 = local_2c;
      }
      return 0;
    }
    if ((*(byte *)(local_18 + 0xf) & 1) == 0) {
      piVar1 = local_18[2];
      if ((int *)piVar1[7] < local_18[3]) {
        iVar2 = (int)local_18[2] + piVar1[7];
        for (local_26 = 0; local_26 != *(ushort *)(piVar1 + 0xb); local_26 = local_26 + 1) {
          if (*(int *)(iVar2 + (uint)local_26 * 0x20) == 1) {
            local_18[10] = (int *)((int)local_18[2] - *(int *)(iVar2 + (uint)local_26 * 0x20 + 8));
            break;
          }
        }
        FUN_000322ec(local_18,iVar2,*(undefined2 *)(piVar1 + 0xb));
      }
      else {
        __android_log_print(4,DAT_000d2a34 + 0xd28d8,DAT_000d2a38 + 0xd28e0,(int)local_18 + 0x3d);
      }
    }
    local_18 = (int **)*local_18;
  } while( true );
}

