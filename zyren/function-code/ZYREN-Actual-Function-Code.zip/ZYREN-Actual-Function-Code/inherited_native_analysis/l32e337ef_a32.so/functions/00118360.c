/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00118360 FUN_00118360 */

undefined4 FUN_00118360(int param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  stat sStack_2090;
  undefined auStack_2028 [8200];
  
  if (param_1 == 0) {
    uVar5 = 0xffffffff;
  }
  else {
    __aeabi_memclr8(auStack_2028,0x2000);
    __aeabi_memclr8(&sStack_2090,0x68);
    iVar1 = stat(param_2,&sStack_2090);
    uVar5 = 0xfffffffd;
    if (iVar1 == 0) {
      uVar3 = sStack_2090.st_mode & 0xf000;
      uVar4 = sStack_2090.st_mode & 0xfff;
      if (uVar3 == 0x4000) {
        uVar4 = uVar4 | 0x4000;
      }
      if (uVar3 == 0x8000) {
        uVar4 = uVar4 | 0xffff8000;
      }
      if (uVar3 == 0xa000) {
        uVar4 = uVar4 | 0xffffa000;
      }
      if (uVar3 == 0x6000) {
        uVar4 = uVar4 | 0x6000;
      }
      if (uVar3 == 0x2000) {
        uVar4 = uVar4 | 0x2000;
      }
      if (uVar3 == 0x1000) {
        uVar4 = uVar4 | 0x1000;
      }
      if (uVar3 == 0xc000) {
        uVar4 = uVar4 | 0xc000;
      }
      uVar5 = 0;
      uVar4 = ((sStack_2090.st_mode << 0x18) >> 0x1f | uVar4 << 0x10) ^ 1;
      if (uVar3 == 0x4000) {
        uVar4 = uVar4 | 0x10;
      }
      *(uint *)(&DAT_0004e008 + param_1) = uVar4;
      *(ulong *)(&DAT_0004e00c + param_1) = sStack_2090.__unused4;
      iVar1 = FUN_001201d4(param_2,0);
      if (iVar1 < 0) {
        return 0xfffffff0;
      }
      if (iVar1 != 0) {
        iVar2 = FUN_001203a4(iVar1,auStack_2028,0x2000);
        uVar5 = 0;
        if (iVar2 != 0) {
          do {
            iVar2 = FUN_0011819c(param_1,auStack_2028,iVar2);
            if (iVar2 < 0) {
              uVar5 = 0xfffffff8;
              break;
            }
            iVar2 = FUN_001203a4(iVar1,auStack_2028,0x2000);
          } while (iVar2 != 0);
        }
        FUN_00120238(iVar1);
        return uVar5;
      }
    }
  }
  return uVar5;
}

