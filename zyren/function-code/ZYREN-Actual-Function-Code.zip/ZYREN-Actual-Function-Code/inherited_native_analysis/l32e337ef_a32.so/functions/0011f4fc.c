/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011f4fc FUN_0011f4fc */

void FUN_0011f4fc(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar1 = *(uint *)(param_1 + 0x14);
  uVar3 = uVar1 + param_3 * 8;
  iVar2 = *(int *)(param_1 + 0x18);
  *(uint *)(param_1 + 0x14) = uVar3;
  if (uVar3 < uVar1) {
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 0x18) = iVar2;
  }
  *(uint *)(param_1 + 0x18) = iVar2 + (param_3 >> 0x1d);
  uVar1 = (uVar1 << 0x17) >> 0x1a;
  if (uVar1 + param_3 < 0x40) {
    iVar2 = 0;
  }
  else {
    __aeabi_memcpy(param_1 + 0x1c + uVar1,param_2,0x40 - uVar1);
    FUN_0011e070(param_1,param_1 + 0x1c);
    uVar3 = uVar1 ^ 0x7f;
    iVar2 = 0x40 - uVar1;
    while (uVar1 = 0, uVar3 < param_3) {
      FUN_0011e070(param_1,param_2 + iVar2);
      uVar3 = iVar2 + 0x7f;
      iVar2 = iVar2 + 0x40;
    }
  }
  __aeabi_memcpy(param_1 + uVar1 + 0x1c,param_2 + iVar2,param_3 - iVar2);
  return;
}

