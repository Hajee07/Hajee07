/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031da0 FUN_00031da0 */

byte FUN_00031da0(int param_1,undefined4 param_2,undefined4 param_3,code **param_4)

{
  int iVar1;
  code *local_34;
  code *local_2c;
  int local_24;
  byte local_1d;
  code **local_1c;
  undefined4 local_18;
  undefined4 local_14;
  int local_10;
  byte local_9;
  
  local_1d = 0;
  local_24 = 0;
  local_1c = param_4;
  local_18 = param_3;
  local_14 = param_2;
  local_10 = param_1;
  iVar1 = FUN_0003299c(param_1,param_3,&local_24);
  if (iVar1 < 0) {
    *local_1c = *(code **)(DAT_00032010 + iVar1 * -0xc + 0x31e00);
    local_9 = 1;
  }
  else {
    if (iVar1 != 0) {
      local_2c = (code *)(*(int *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 4) +
                         *(int *)(local_10 + 0x28));
      if ((*(byte *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 0xc) & 0xf) == 10) {
        local_2c = (code *)(*local_2c)(local_2c);
      }
      if ((int)(uint)*(byte *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 0xc) >> 4 != 2) {
        if (*local_1c == (code *)0x0) {
          *local_1c = local_2c;
        }
        return 1;
      }
      if (local_1c[2] == (code *)0x0) {
        local_1c[2] = local_2c;
      }
      local_1d = 1;
    }
    if (local_24 != 0) {
      local_34 = (code *)(*(int *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 4) +
                         *(int *)(local_10 + 0x28));
      if ((*(byte *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 0xc) & 0xf) == 10) {
        local_34 = (code *)(*local_34)(local_34);
      }
      if ((int)(uint)*(byte *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 0xc) >> 4 == 2) {
        if (local_1c[2] == (code *)0x0) {
          local_1c[2] = local_34;
        }
      }
      else if (local_1c[1] == (code *)0x0) {
        local_1c[1] = local_34;
      }
      local_1d = 1;
    }
    local_9 = local_1d & 1;
  }
  return local_9;
}

