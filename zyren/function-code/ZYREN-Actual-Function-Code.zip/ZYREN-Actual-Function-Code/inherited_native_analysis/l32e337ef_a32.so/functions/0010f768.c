/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010f768 FUN_0010f768 */

uint FUN_0010f768(int *param_1,byte *param_2,uint param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  int *piVar5;
  uint *puVar6;
  uint *puVar7;
  uint uVar8;
  byte *pbVar9;
  int iVar10;
  undefined4 uVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  uint *puVar17;
  int *unaff_r6;
  uint *puVar18;
  uint uVar19;
  byte *pbVar20;
  uint *puVar21;
  int iVar22;
  uint local_2c;
  uint local_28;
  
  uVar15 = 0;
  piVar5 = param_1;
  if (param_1 != (int *)0x0) {
    piVar5 = (int *)*param_1;
    unaff_r6 = param_1;
  }
  if (param_1 != (int *)0x0 && piVar5 != (int *)0x0) {
    pbVar9 = param_2;
    if (param_2 != (byte *)0x0) {
      pbVar9 = (byte *)piVar5[0x12];
    }
    if (param_2 != (byte *)0x0 && pbVar9 != (byte *)0x0) {
      puVar18 = (uint *)(unaff_r6 + 0xc);
      puVar17 = (uint *)(unaff_r6 + 10);
      puVar21 = (uint *)(unaff_r6 + 0xe);
      if (((*(byte *)((int)unaff_r6 + 5) & 4) != 0) || (*(short *)((int)unaff_r6 + 0x56) == 0)) {
        uVar8 = *puVar17;
        uVar15 = uVar8;
        if ((uint)(uVar8 <= param_3) <= (uint)-unaff_r6[0xb]) {
          uVar15 = param_3;
        }
        if (*(int *)(pbVar9 + 0x48) == 0) {
          uVar8 = (*(code *)piVar5[0xe])
                            (piVar5[0x11],(code *)piVar5[0xe],*puVar21,unaff_r6[0xf],param_2,uVar15)
          ;
          if (uVar8 != uVar15) {
            uVar15 = 0;
            if (*unaff_r6 != 0) {
              *(undefined4 *)(*unaff_r6 + 0x1c) = 0x14;
            }
            unaff_r6[2] = -1;
          }
          bVar4 = *(byte *)((int)unaff_r6 + 5);
        }
        else {
          __aeabi_memcpy(param_2,unaff_r6[0x124],uVar15,-(unaff_r6[0xb] + (uint)(uVar8 > param_3)));
          unaff_r6[0x124] = unaff_r6[0x124] + uVar15;
          bVar4 = *(byte *)((int)unaff_r6 + 5);
        }
        if ((bVar4 & 4) == 0) {
          uVar8 = ~unaff_r6[3];
          uVar12 = uVar15;
          if (3 < uVar15) {
            uVar19 = uVar15 - 4 & 0xfffffffc;
            iVar22 = DAT_0010fd1c + 0x10fbd4;
            pbVar9 = param_2;
            do {
              bVar4 = *pbVar9;
              pbVar20 = pbVar9 + 1;
              uVar12 = uVar12 - 4;
              pbVar1 = pbVar9 + 2;
              pbVar2 = pbVar9 + 3;
              pbVar9 = pbVar9 + 4;
              uVar8 = *(uint *)(iVar22 + (uVar8 & 0xff ^ (uint)bVar4) * 4) ^ uVar8 >> 8;
              uVar8 = *(uint *)(iVar22 + (uVar8 & 0xff ^ (uint)*pbVar20) * 4) ^ uVar8 >> 8;
              uVar8 = *(uint *)(iVar22 + (uVar8 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar8 >> 8;
              uVar8 = *(uint *)(iVar22 + (uVar8 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar8 >> 8;
            } while (3 < uVar12);
            param_2 = param_2 + uVar19 + 4;
            uVar12 = (uVar15 - 4) - uVar19;
          }
          if (uVar12 != 0) {
            do {
              uVar12 = uVar12 - 1;
              uVar8 = *(uint *)(DAT_0010fd18 + 0x10fc70 + (uVar8 & 0xff ^ (uint)*param_2) * 4) ^
                      uVar8 >> 8;
              param_2 = param_2 + 1;
            } while (uVar12 != 0);
          }
          unaff_r6[3] = ~uVar8;
        }
        uVar8 = *puVar21;
        *puVar21 = uVar8 + uVar15;
        unaff_r6[0xf] = unaff_r6[0xf] + (uint)CARRY4(uVar8,uVar15);
        uVar8 = *puVar18;
        *puVar18 = uVar8 + uVar15;
        unaff_r6[0xd] = unaff_r6[0xd] + (uint)CARRY4(uVar8,uVar15);
        uVar8 = *puVar17;
        *puVar17 = uVar8 - uVar15;
        unaff_r6[0xb] = unaff_r6[0xb] - (uint)(uVar8 < uVar15);
        return uVar15;
      }
      puVar6 = (uint *)(unaff_r6 + 6);
      puVar7 = (uint *)(unaff_r6 + 8);
      uVar15 = 0;
      iVar22 = DAT_0010fd14 + 0x10f820;
      do {
        iVar14 = unaff_r6[0x125];
        pbVar9 = (byte *)(iVar14 + (*puVar18 & 0x7fff));
        local_2c = 0x8000 - (*puVar18 & 0x7fff);
        uVar8 = unaff_r6[0x126];
        if (unaff_r6[0x126] == 0) {
          uVar8 = *puVar7;
          if ((uVar8 | unaff_r6[9]) == 0) {
            iVar10 = *unaff_r6;
            uVar8 = 0;
            if (*(int *)(*(int *)(iVar10 + 0x48) + 0x48) != 0) goto LAB_0010f910;
            uVar8 = unaff_r6[0xb];
            uVar19 = unaff_r6[5];
            uVar12 = *puVar17;
            if (uVar19 <= uVar8 && (uint)(*puVar17 <= (uint)unaff_r6[4]) <= uVar19 - uVar8) {
              uVar12 = unaff_r6[4];
              uVar8 = uVar19;
            }
            *puVar7 = uVar12;
            unaff_r6[9] = uVar8;
            uVar8 = (**(code **)(iVar10 + 0x38))
                              (*(undefined4 *)(iVar10 + 0x44),unaff_r6[0x124],*puVar21,unaff_r6[0xf]
                               ,unaff_r6[0x124],uVar12);
            if ((*puVar7 ^ uVar8 | unaff_r6[9]) == 0) {
              uVar12 = *puVar21;
              *puVar21 = uVar12 + uVar8;
              unaff_r6[0xf] = unaff_r6[0xf] + (uint)CARRY4(uVar12,uVar8);
              uVar12 = *puVar17;
              *puVar17 = uVar12 - uVar8;
              unaff_r6[0xb] = unaff_r6[0xb] - (uint)(uVar12 < uVar8);
              *puVar6 = 0;
              unaff_r6[7] = 0;
              iVar14 = unaff_r6[0x125];
              goto LAB_0010f910;
            }
            iVar22 = *unaff_r6;
            if (iVar22 == 0) goto LAB_0010fce8;
            uVar11 = 0x14;
            goto LAB_0010fce4;
          }
LAB_0010f910:
          uVar12 = *puVar17 | unaff_r6[0xb];
          if (uVar12 != 0) {
            uVar12 = 1;
          }
          local_28 = uVar8;
          iVar14 = FUN_001081f0(unaff_r6 + 0x127,unaff_r6[0x124] + *puVar6,&local_28,iVar14,pbVar9,
                                &local_2c,uVar12 << 1);
          unaff_r6[2] = iVar14;
          uVar8 = *puVar7;
          *puVar7 = uVar8 - local_28;
          unaff_r6[9] = unaff_r6[9] - (uint)(uVar8 < local_28);
          uVar8 = *puVar6;
          uVar12 = uVar8 + local_28;
          *puVar6 = uVar12;
          unaff_r6[7] = unaff_r6[7] + (uint)CARRY4(uVar8,local_28);
          unaff_r6[0x126] = local_2c;
          uVar8 = local_2c;
          if (local_2c != 0) goto LAB_0010f998;
        }
        else {
LAB_0010f998:
          if (param_3 - uVar15 < uVar8) {
            uVar8 = param_3 - uVar15;
          }
          __aeabi_memcpy(param_2 + uVar15,pbVar9,uVar8);
          uVar12 = ~unaff_r6[3];
          uVar19 = uVar8;
          if (3 < uVar8) {
            uVar13 = uVar8 - 4 & 0xfffffffc;
            pbVar20 = pbVar9;
            do {
              bVar4 = *pbVar20;
              pbVar1 = pbVar20 + 1;
              uVar19 = uVar19 - 4;
              pbVar2 = pbVar20 + 2;
              pbVar3 = pbVar20 + 3;
              pbVar20 = pbVar20 + 4;
              uVar12 = *(uint *)(iVar22 + (uVar12 & 0xff ^ (uint)bVar4) * 4) ^ uVar12 >> 8;
              uVar12 = *(uint *)(iVar22 + (uVar12 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar12 >> 8;
              uVar12 = *(uint *)(iVar22 + (uVar12 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar12 >> 8;
              uVar12 = *(uint *)(iVar22 + (uVar12 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar12 >> 8;
            } while (3 < uVar19);
            uVar19 = (uVar8 - 4) - uVar13;
            pbVar9 = pbVar9 + uVar13 + 4;
          }
          for (; uVar19 != 0; uVar19 = uVar19 - 1) {
            uVar12 = *(uint *)(iVar22 + (uVar12 & 0xff ^ (uint)*pbVar9) * 4) ^ uVar12 >> 8;
            pbVar9 = pbVar9 + 1;
          }
          unaff_r6[3] = ~uVar12;
          unaff_r6[0x126] = unaff_r6[0x126] - uVar8;
          uVar12 = *puVar18;
          uVar16 = uVar12 + uVar8;
          *puVar18 = uVar16;
          uVar19 = unaff_r6[0xd] + (uint)CARRY4(uVar12,uVar8);
          unaff_r6[0xd] = uVar19;
          uVar13 = unaff_r6[0x1b];
          uVar12 = uVar13 - (uVar19 + (uVar16 > (uint)unaff_r6[0x1a]));
          if (uVar13 <= uVar19 && (uint)(uVar16 <= (uint)unaff_r6[0x1a]) <= uVar13 - uVar19) {
            iVar22 = *unaff_r6;
            if (iVar22 == 0) goto LAB_0010fce8;
            uVar11 = 0xb;
LAB_0010fce4:
            *(undefined4 *)(iVar22 + 0x1c) = uVar11;
LAB_0010fce8:
            unaff_r6[2] = -1;
            return uVar15;
          }
          uVar15 = uVar8 + uVar15;
        }
        if (uVar15 < param_3) {
          uVar12 = unaff_r6[2] - 1;
        }
      } while (uVar15 < param_3 && uVar12 < 2);
    }
  }
  return uVar15;
}

