/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030380 FUN_00030380 */

int FUN_00030380(int param_1,int param_2,int param_3,int *param_4,char *param_5)

{
  uint uVar1;
  uint uVar2;
  int extraout_r1;
  int extraout_r1_00;
  uint uVar3;
  int *piVar4;
  uint *puVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  
  uVar1 = FUN_00030e78(param_5);
  iVar6 = *param_4;
  uVar7 = param_4[1];
  iVar8 = param_4[2];
  FUN_00033508(uVar1,iVar6);
  uVar3 = param_4[iVar8 + extraout_r1 + 4];
  if ((uVar7 <= uVar3) &&
     (FUN_00033508(uVar1 >> 5,iVar8),
     uVar2 = 1 << (uVar1 >> (param_4[3] & 0xffU) & 0x1f) | 1 << (uVar1 & 0x1f),
     (uVar2 & param_4[extraout_r1_00 + 4]) == uVar2)) {
    piVar4 = (int *)(param_2 + uVar3 * 0x10 + 4);
    puVar5 = (uint *)(param_4 + ((uVar3 + iVar8 + iVar6 + 4) - uVar7));
    while( true ) {
      uVar3 = *puVar5;
      if (((uVar3 ^ uVar1) < 2) &&
         (iVar6 = strcmp((char *)(param_3 + piVar4[-1]),param_5), iVar6 == 0)) {
        return *piVar4 + param_1;
      }
      if ((uVar3 & 1) != 0) break;
      puVar5 = puVar5 + 1;
      piVar4 = piVar4 + 4;
    }
  }
  return 0;
}

