/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011550c FUN_0011550c */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 FUN_0011550c(uint *param_1,int param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  code *pcVar13;
  short *psVar14;
  int iVar15;
  code *pcVar16;
  code *pcVar17;
  code *pcVar18;
  uint uVar19;
  short *psVar20;
  uint uVar21;
  uint uVar22;
  int *piVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  code *pcVar27;
  bool bVar28;
  uint local_14f8;
  uint local_14ec;
  int local_14e8;
  uint local_14e4;
  code *local_14dc;
  uint local_14d8;
  code *local_14d4;
  undefined auStack_14d0 [32];
  uint local_14b0;
  int iStack_14ac;
  undefined4 local_14a8;
  undefined4 uStack_14a4;
  uint local_1498;
  int local_1494;
  undefined auStack_1080 [20];
  undefined4 local_106c;
  undefined4 local_1068;
  undefined2 local_1062;
  uint local_1056;
  int local_104c;
  byte local_1046;
  int iStack_103a;
  int local_1036;
  ushort local_1032;
  ushort local_1030;
  uint local_102c;
  undefined *local_1028;
  undefined local_1024;
  undefined local_1023;
  undefined local_1022;
  undefined local_1021;
  undefined local_1020;
  undefined local_101f;
  undefined local_101e;
  undefined local_101d;
  undefined local_101c;
  undefined local_101b;
  undefined local_101a;
  undefined local_1019;
  undefined local_1018;
  undefined local_1017;
  undefined local_1016;
  undefined local_1015;
  undefined local_1014;
  undefined local_1013;
  undefined local_1012;
  undefined local_1011;
  undefined local_1010;
  undefined local_100f;
  undefined local_100e;
  undefined local_100d;
  
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  piVar23 = (int *)param_1[0x12];
  if (((piVar23 != (int *)0x0) && (param_1[5] == 2)) && (*(int *)(param_2 + 0x38) != 0)) {
    piVar1 = *(int **)(param_2 + 0x48);
    uVar11 = piVar1[0xd];
    if ((uVar11 == 0) || (uVar11 = piVar23[0xd], uVar11 != 0)) {
      bVar28 = piVar1 != (int *)0x0;
      if (bVar28) {
        uVar11 = *(uint *)(param_2 + 0x10);
      }
      if (((!bVar28 || param_3 <= uVar11) && (bVar28 && uVar11 != param_3)) &&
         (piVar1 = (int *)(*piVar1 + *(int *)(piVar1[4] + param_3 * 4)), piVar1 != (int *)0x0)) {
        if (*piVar1 != 0x2014b50) {
LAB_00115808:
          uVar11 = 9;
          goto LAB_00115584;
        }
        uVar11 = (uint)*(ushort *)(piVar1 + 7);
        uVar24 = (uint)*(ushort *)(piVar1 + 8);
        pcVar16 = (code *)(uint)*(ushort *)((int)piVar1 + 0x1e);
        pcVar18 = pcVar16 + uVar24 + uVar11;
        if (pcVar18 + piVar23[1] == (code *)0xffffffb1) {
          uVar11 = 0xf;
          goto LAB_00115584;
        }
        uVar2 = param_1[8];
        if ((uVar2 | param_1[9]) == 0) {
          uVar21 = 0;
          uVar2 = param_1[4];
          if (piVar23[0xd] != 0) goto LAB_0011564c;
LAB_00115810:
          if (uVar2 != 0xffff) {
LAB_00115654:
            iVar3 = FUN_001107b8(param_2,param_3,piVar1,auStack_14d0,0);
            iVar6 = local_1494;
            uVar2 = local_1498;
            if (iVar3 == 0) {
              return 0;
            }
            uVar12 = *param_1;
            uVar4 = param_1[1];
            iVar3 = (**(code **)(param_2 + 0x38))
                              (*(undefined4 *)(param_2 + 0x44),*(code **)(param_2 + 0x38),local_1498
                               ,local_1494,&local_104c,0x1e);
            if (iVar3 != 0x1e) {
              uVar11 = 0x14;
              goto LAB_00115584;
            }
            if (local_104c != 0x4034b50) goto LAB_00115808;
            uVar5 = uVar2 + 0x1e;
            iVar6 = iVar6 + (uint)(0xffffffe1 < uVar2);
            uVar25 = (uint)local_1030;
            uVar7 = uVar25 + local_1032;
            uVar2 = local_14b0 + uVar7;
            uVar7 = iStack_14ac + (uint)CARRY4(local_14b0,uVar7);
            if (uVar25 != 0) {
              bVar28 = local_1036 != -1;
              if (bVar28) {
                local_1036 = iStack_103a;
              }
              if (bVar28 && local_1036 != -1) goto LAB_00115840;
              piVar8 = (int *)(*(code *)param_1[0xc])(param_1[0xd],0,1,uVar25);
              if (piVar8 == (int *)0x0) {
LAB_00115cc0:
                uVar11 = 0x10;
                goto LAB_00115584;
              }
              uVar22 = local_1032 + 0x1e;
              uVar22 = (**(code **)(param_2 + 0x38))
                                 (*(undefined4 *)(param_2 + 0x44),*(code **)(param_2 + 0x38),
                                  local_1498 + uVar22,local_1494 + (uint)CARRY4(local_1498,uVar22),
                                  piVar8,uVar25);
              piVar10 = piVar8;
              if (uVar22 == uVar25) {
                do {
                  if (uVar25 < 4) {
LAB_001158bc:
                    (*(code *)param_1[0xb])(param_1[0xd],piVar8);
                    uVar11 = 9;
                    goto LAB_00115820;
                  }
                  uVar22 = *(ushort *)((int)piVar10 + 2) + 4;
                  if (uVar25 < uVar22) goto LAB_001158bc;
                  if (*(short *)piVar10 == 1) {
                    local_14ec = 1;
                    if (*(ushort *)((int)piVar10 + 2) < 0x10) goto LAB_001158bc;
                    goto LAB_001158d0;
                  }
                  uVar25 = uVar25 - uVar22;
                  piVar10 = (int *)((int)piVar10 + uVar22);
                } while (uVar25 != 0);
                local_14ec = 0;
LAB_001158d0:
                (*(code *)param_1[0xb])(param_1[0xd]);
                iVar3 = piVar23[0xd];
                goto joined_r0x001158f4;
              }
              pcVar16 = (code *)param_1[0xb];
              uVar11 = param_1[0xd];
LAB_00115f00:
              (*pcVar16)(uVar11,piVar8);
              uVar11 = 0x14;
              goto LAB_00115820;
            }
LAB_00115840:
            iVar3 = piVar23[0xd];
            local_14ec = 0;
joined_r0x001158f4:
            if ((iVar3 == 0) &&
               (pcVar17 = pcVar18 + 0xb2, pcVar27 = pcVar17 + uVar21, pcVar13 = pcVar27 + uVar12,
               uVar25 = CARRY4((uint)pcVar17,uVar21) + uVar4 + (uint)CARRY4((uint)pcVar27,uVar12) +
                        uVar7 + (uint)CARRY4((uint)pcVar13,uVar2) +
                        (uint)CARRY4((uint)(pcVar13 + uVar2),piVar23[1]),
               uVar25 != 0 || uVar25 < ((code *)0xfffffffe < pcVar13 + uVar2 + piVar23[1]))) {
              uVar11 = 0x1d;
              goto LAB_00115584;
            }
            uVar25 = 0x1000;
            if (uVar21 < 0x1000) {
              uVar25 = uVar21;
            }
            __aeabi_memclr8(&local_1028,uVar25);
            uVar25 = uVar12;
            uVar22 = uVar4;
            for (uVar26 = uVar21; uVar26 != 0; uVar26 = uVar26 - uVar19) {
              uVar19 = 0x1000;
              if (uVar26 < 0x1000) {
                uVar19 = uVar26;
              }
              uVar9 = (*(code *)param_1[0xf])
                                (param_1[0x11],(code *)param_1[0xf],uVar25,uVar22,&local_1028,uVar19
                                );
              if (uVar9 != uVar19) goto LAB_001162d8;
              bVar28 = CARRY4(uVar25,uVar19);
              uVar25 = uVar25 + uVar19;
              uVar22 = uVar22 + bVar28;
            }
            uVar25 = uVar12 + uVar21;
            uVar4 = uVar4 + CARRY4(uVar12,uVar21);
            iVar3 = (*(code *)param_1[0xf])
                              (param_1[0x11],(code *)param_1[0xf],uVar25,uVar4,&local_104c,0x1e);
            if (iVar3 != 0x1e) {
LAB_001162d8:
              uVar11 = 0x13;
              goto LAB_00115820;
            }
            uVar12 = uVar2;
            uVar21 = uVar7;
            if (uVar7 != 0 || uVar7 < (0x1fff < uVar2)) {
              uVar12 = 0x2000;
              uVar21 = 0;
            }
            if (-uVar21 < (uint)(uVar12 < 0x21)) {
              uVar12 = 0x20;
            }
            piVar8 = (int *)(*(code *)param_1[10])(param_1[0xd],1,uVar12);
            local_14d8 = uVar25 + 0x1e;
            local_14e4 = uVar4 + (0xffffffe1 < uVar25);
            if (piVar8 == (int *)0x0) goto LAB_00115cc0;
            uVar21 = uVar2 | uVar7;
            while (uVar21 != 0) {
              uVar21 = (uint)(uVar7 == 0 && (0x1fff < uVar2) <= uVar7);
              uVar12 = uVar2;
              if (uVar21 == 0) {
                uVar12 = 0x2000;
              }
              uVar22 = (**(code **)(param_2 + 0x38))(*(undefined4 *)(param_2 + 0x44));
              if (uVar21 != 0) {
                uVar21 = uVar7;
              }
              local_102c = uVar12;
              if (uVar22 != uVar12) {
                pcVar16 = (code *)param_1[0xb];
                uVar11 = param_1[0xd];
                goto LAB_00115f00;
              }
              uVar22 = (*(code *)param_1[0xf])
                                 (param_1[0x11],(code *)param_1[0xf],local_14d8,local_14e4,piVar8,
                                  uVar12);
              if (uVar22 != uVar12) goto LAB_001162c8;
              bVar28 = uVar2 < uVar12;
              uVar2 = uVar2 - uVar12;
              uVar7 = uVar7 - (uVar21 + bVar28);
              bVar28 = CARRY4(uVar12,local_14d8);
              local_14d8 = uVar12 + local_14d8;
              local_14e4 = uVar21 + local_14e4 + (uint)bVar28;
              bVar28 = CARRY4(uVar12,uVar5);
              uVar5 = uVar12 + uVar5;
              iVar6 = uVar21 + iVar6 + (uint)bVar28;
              uVar21 = uVar2 | uVar7;
            }
            if ((local_1046 & 8) != 0) {
              pcVar17 = *(code **)(param_2 + 0x38);
              if ((*(uint *)(*(int *)(param_2 + 0x48) + 0x34) | local_14ec) == 0) {
                iVar6 = (*pcVar17)(*(undefined4 *)(param_2 + 0x44),pcVar17,uVar5,iVar6,piVar8,0x10);
                if (iVar6 != 0x10) goto LAB_00115ef4;
                if (*(int *)(param_1[0x12] + 0x34) == 0) {
                  uVar2 = 0xc;
                  if (*piVar8 == 0x8074b50) {
                    uVar2 = 0x10;
                  }
                }
                else {
                  piVar10 = piVar8;
                  if (*piVar8 == 0x8074b50) {
                    piVar10 = piVar8 + 1;
                  }
                  iVar3 = *piVar10;
                  iVar15 = piVar10[1];
                  iVar6 = piVar10[2];
                  piVar8[5] = 0;
                  *(char *)(piVar8 + 4) = (char)iVar6;
                  piVar8[3] = 0;
                  *(char *)(piVar8 + 2) = (char)iVar15;
                  *(char *)(piVar8 + 1) = (char)iVar3;
                  *piVar8 = 0x8074b50;
                  *(char *)((int)piVar8 + 0x13) = (char)((uint)iVar6 >> 0x18);
                  *(char *)((int)piVar8 + 0x12) = (char)((uint)iVar6 >> 0x10);
                  *(char *)((int)piVar8 + 0x11) = (char)((uint)iVar6 >> 8);
                  *(char *)((int)piVar8 + 0xb) = (char)((uint)iVar15 >> 0x18);
                  *(char *)((int)piVar8 + 10) = (char)((uint)iVar15 >> 0x10);
                  *(char *)((int)piVar8 + 9) = (char)((uint)iVar15 >> 8);
                  *(char *)((int)piVar8 + 7) = (char)((uint)iVar3 >> 0x18);
                  *(char *)((int)piVar8 + 6) = (char)((uint)iVar3 >> 0x10);
                  *(char *)((int)piVar8 + 5) = (char)((uint)iVar3 >> 8);
                  uVar2 = 0x18;
                }
              }
              else {
                iVar6 = (*pcVar17)(*(undefined4 *)(param_2 + 0x44),pcVar17,uVar5,iVar6,piVar8,0x18);
                if (iVar6 != 0x18) {
LAB_00115ef4:
                  pcVar16 = (code *)param_1[0xb];
                  uVar11 = param_1[0xd];
                  goto LAB_00115f00;
                }
                uVar2 = 0x14;
                if (*piVar8 == 0x8074b50) {
                  uVar2 = 0x18;
                }
              }
              local_102c = uVar2;
              uVar21 = (*(code *)param_1[0xf])
                                 (param_1[0x11],(code *)param_1[0xf],local_14d8,local_14e4,piVar8,
                                  uVar2);
              if (uVar21 != uVar2) {
LAB_001162c8:
                (*(code *)param_1[0xb])(param_1[0xd],piVar8);
                goto LAB_001162d8;
              }
              bVar28 = CARRY4(local_14d8,uVar2);
              local_14d8 = local_14d8 + uVar2;
              local_14e4 = local_14e4 + bVar28;
            }
            (*(code *)param_1[0xb])(param_1[0xd],piVar8);
            uVar2 = piVar23[1];
            __aeabi_memcpy(auStack_1080,piVar1,0x2e);
            if (piVar23[0xd] == 0) {
              if ((local_14e4 != 0) || (uVar4 != 0 || uVar4 < (0xfffffffe < uVar25))) {
                uVar11 = 0x1d;
                goto LAB_00115820;
              }
              uVar11 = piVar23[2];
              uVar24 = uVar2 + 0x2e;
              local_1056 = uVar25;
              if (uVar24 <= uVar11) {
                iVar6 = *piVar23;
LAB_001162e4:
                piVar23[1] = uVar24;
                __aeabi_memcpy(piVar23[3] * uVar2 + iVar6,auStack_1080,piVar23[3] * 0x2e);
                iVar6 = piVar23[1];
                pcVar16 = (code *)piVar23[2];
                pcVar17 = pcVar18 + iVar6;
                if (pcVar17 <= pcVar16) {
LAB_00116364:
                  piVar23[1] = (int)pcVar17;
                  if (pcVar18 != (code *)0x0) {
                    __aeabi_memcpy(piVar23[3] * iVar6 + *piVar23,(int)piVar1 + 0x2e,
                                   piVar23[3] * (int)pcVar18);
                    goto LAB_00116394;
                  }
                  goto LAB_00116398;
                }
                if (pcVar16 == (code *)0x0) {
                  pcVar16 = (code *)0x1;
                }
                do {
                  pcVar27 = pcVar16;
                  pcVar16 = (code *)((int)pcVar27 << 1);
                } while (pcVar27 < pcVar17);
                iVar3 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],pcVar27);
                if (iVar3 != 0) {
                  piVar23[2] = (int)pcVar27;
                  *piVar23 = iVar3;
                  goto LAB_00116364;
                }
                goto LAB_0011622c;
              }
              if (uVar11 == 0) {
                uVar11 = 1;
              }
              do {
                uVar21 = uVar11;
                uVar11 = uVar21 << 1;
              } while (uVar21 < uVar24);
              iVar6 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],uVar21);
              if (iVar6 != 0) {
                piVar23[2] = uVar21;
                *piVar23 = iVar6;
                goto LAB_001162e4;
              }
            }
            else {
              local_1068 = 0xffffffff;
              local_106c = 0xffffffff;
              local_1056 = 0xffffffff;
              pcVar17 = pcVar16 + 0x40;
              pcVar18 = (code *)param_1[0xc];
              local_14e8 = (*pcVar18)(param_1[0xd],0,1,pcVar17);
              local_14f8 = 0x10;
              if (local_14e8 == 0) {
                local_14e8 = 0;
LAB_00115f8c:
                param_1[7] = local_14f8;
                (*(code *)param_1[0xb])(param_1[0xd],local_14e8);
                return 0;
              }
              psVar14 = (short *)((int)piVar1 + 0x2e + uVar11);
              local_1020 = (undefined)uStack_14a4;
              local_1024 = (undefined)local_14a8;
              local_101f = (undefined)((uint)uStack_14a4 >> 8);
              local_101e = (undefined)((uint)uStack_14a4 >> 0x10);
              local_101d = (undefined)((uint)uStack_14a4 >> 0x18);
              local_1021 = (undefined)((uint)local_14a8 >> 0x18);
              local_1022 = (undefined)((uint)local_14a8 >> 0x10);
              local_1023 = (undefined)((uint)local_14a8 >> 8);
              local_100d = (undefined)(uVar4 >> 0x18);
              local_100e = (undefined)(uVar4 >> 0x10);
              local_100f = (undefined)(uVar4 >> 8);
              local_1010 = (undefined)uVar4;
              local_1011 = (undefined)(uVar25 >> 0x18);
              local_1012 = (undefined)(uVar25 >> 0x10);
              local_1013 = (undefined)(uVar25 >> 8);
              local_1014 = (undefined)uVar25;
              local_1018 = (undefined)iStack_14ac;
              local_101c = (undefined)local_14b0;
              local_1028 = &UNK_00180001;
              local_1015 = (undefined)((uint)iStack_14ac >> 0x18);
              local_1016 = (undefined)((uint)iStack_14ac >> 0x10);
              local_1017 = (undefined)((uint)iStack_14ac >> 8);
              local_1019 = (undefined)(local_14b0 >> 0x18);
              local_101a = (undefined)(local_14b0 >> 0x10);
              local_101b = (undefined)(local_14b0 >> 8);
              local_14dc = (code *)0x1c;
              __aeabi_memcpy(local_14e8,&local_1028,0x1c);
              if (pcVar16 != (code *)0x0) {
                local_14dc = (code *)0x1c;
                psVar20 = psVar14;
                local_14d4 = pcVar16;
                do {
                  if (local_14d4 >= (code *)0x4) {
                    pcVar18 = (code *)((ushort)psVar20[1] + 4);
                  }
                  if (local_14d4 < (code *)0x4 || local_14d4 < pcVar18) {
                    local_14f8 = 9;
                    goto LAB_00115f8c;
                  }
                  if (*psVar20 != 1) {
                    pcVar27 = pcVar18 + (int)local_14dc;
                    iVar6 = local_14e8;
                    if (pcVar17 < pcVar27) {
                      pcVar13 = pcVar17;
                      if (pcVar17 == (code *)0x0) {
                        pcVar13 = (code *)0x1;
                      }
                      do {
                        pcVar17 = pcVar13;
                        pcVar13 = (code *)((int)pcVar17 << 1);
                      } while (pcVar17 < pcVar27);
                      iVar6 = (*(code *)param_1[0xc])(param_1[0xd],local_14e8,1,pcVar17);
                      if (iVar6 == 0) goto LAB_00115f8c;
                    }
                    __aeabi_memcpy(local_14dc + iVar6,psVar20,pcVar18);
                    local_14e8 = iVar6;
                    local_14dc = pcVar27;
                  }
                  psVar20 = (short *)((int)psVar20 + (int)pcVar18);
                  local_14d4 = local_14d4 + -(int)pcVar18;
                } while (local_14d4 != (code *)0x0);
              }
              local_1062 = SUB42(local_14dc,0);
              iVar6 = piVar23[1];
              uVar21 = piVar23[2];
              uVar4 = iVar6 + 0x2e;
              if (uVar21 < uVar4) {
                if (uVar21 == 0) {
                  uVar21 = 1;
                }
                do {
                  uVar12 = uVar21;
                  uVar21 = uVar12 << 1;
                } while (uVar12 < uVar4);
                iVar3 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],uVar12);
                if (iVar3 == 0) {
                  (*(code *)param_1[0xb])(param_1[0xd],local_14e8);
                  uVar11 = 0x10;
                  goto LAB_00115820;
                }
                piVar23[2] = uVar12;
                *piVar23 = iVar3;
              }
              else {
                iVar3 = *piVar23;
              }
              piVar23[1] = uVar4;
              __aeabi_memcpy(piVar23[3] * iVar6 + iVar3,auStack_1080,piVar23[3] * 0x2e);
              iVar6 = piVar23[1];
              pcVar18 = (code *)piVar23[2];
              pcVar17 = (code *)(iVar6 + uVar11);
              if (pcVar18 < pcVar17) {
                pcVar27 = pcVar18;
                if (pcVar18 == (code *)0x0) {
                  pcVar27 = (code *)0x1;
                }
                do {
                  pcVar18 = pcVar27;
                  pcVar27 = (code *)((int)pcVar18 << 1);
                } while (pcVar18 < pcVar17);
                iVar3 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],pcVar18);
                if (iVar3 != 0) {
                  piVar23[2] = (int)pcVar18;
                  *piVar23 = iVar3;
                  piVar23[1] = (int)pcVar17;
                  goto joined_r0x001160b8;
                }
LAB_0011621c:
                (*(code *)param_1[0xb])(param_1[0xd],local_14e8);
              }
              else {
                piVar23[1] = (int)pcVar17;
joined_r0x001160b8:
                if (uVar11 != 0) {
                  __aeabi_memcpy(piVar23[3] * iVar6 + *piVar23,(int)piVar1 + 0x2e,
                                 piVar23[3] * uVar11);
                  pcVar17 = (code *)piVar23[1];
                  pcVar18 = (code *)piVar23[2];
                }
                pcVar27 = pcVar17 + (int)local_14dc;
                if (pcVar18 < pcVar27) {
                  pcVar13 = pcVar18;
                  if (pcVar18 == (code *)0x0) {
                    pcVar13 = (code *)0x1;
                  }
                  do {
                    pcVar18 = pcVar13;
                    pcVar13 = (code *)((int)pcVar18 << 1);
                  } while (pcVar18 < pcVar27);
                  iVar6 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],pcVar18);
                  if (iVar6 == 0) goto LAB_0011621c;
                  piVar23[2] = (int)pcVar18;
                  *piVar23 = iVar6;
                  piVar23[1] = (int)pcVar27;
                }
                else {
                  piVar23[1] = (int)pcVar27;
                }
                if (local_14dc != (code *)0x0) {
                  __aeabi_memcpy(piVar23[3] * (int)pcVar17 + *piVar23,local_14e8,
                                 piVar23[3] * (int)local_14dc);
                  pcVar27 = (code *)piVar23[1];
                  pcVar18 = (code *)piVar23[2];
                }
                pcVar17 = pcVar27 + uVar24;
                if (pcVar18 < pcVar17) {
                  if (pcVar18 == (code *)0x0) {
                    pcVar18 = (code *)0x1;
                  }
                  do {
                    pcVar13 = pcVar18;
                    pcVar18 = (code *)((int)pcVar13 << 1);
                  } while (pcVar13 < pcVar17);
                  iVar6 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],pcVar13);
                  if (iVar6 == 0) goto LAB_0011621c;
                  piVar23[2] = (int)pcVar13;
                  *piVar23 = iVar6;
                }
                piVar23[1] = (int)pcVar17;
                if (uVar24 != 0) {
                  __aeabi_memcpy(piVar23[3] * (int)pcVar27 + *piVar23,
                                 (code *)((int)psVar14 + (int)pcVar16),piVar23[3] * uVar24);
                }
                (*(code *)param_1[0xb])(param_1[0xd],local_14e8);
LAB_00116394:
                pcVar17 = (code *)piVar23[1];
LAB_00116398:
                if (pcVar17 == (code *)0xffffffff) {
                  if ((uint)piVar23[2] < uVar2) {
                    iVar6 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],uVar2);
                    if (iVar6 != 0) {
                      piVar23[2] = uVar2;
                      *piVar23 = iVar6;
                      goto LAB_00116440;
                    }
                  }
                  else {
LAB_00116440:
                    piVar23[1] = uVar2;
                  }
                  uVar11 = 0xf;
                  goto LAB_00115820;
                }
                iVar6 = piVar23[5];
                uVar11 = piVar23[6];
                uVar24 = iVar6 + 1;
                local_102c = uVar2;
                if (uVar24 <= uVar11) {
                  iVar3 = piVar23[4];
LAB_00116454:
                  piVar23[5] = uVar24;
                  __aeabi_memcpy(piVar23[7] * iVar6 + iVar3,&local_102c);
                  *param_1 = local_14d8;
                  param_1[1] = local_14e4;
                  param_1[4] = param_1[4] + 1;
                  return 1;
                }
                if (uVar11 == 0) {
                  uVar11 = 1;
                }
                do {
                  uVar21 = uVar11;
                  uVar11 = uVar21 << 1;
                } while (uVar21 < uVar24);
                iVar3 = (*(code *)param_1[0xc])(param_1[0xd],piVar23[4],piVar23[7],uVar21);
                if (iVar3 != 0) {
                  piVar23[6] = uVar21;
                  piVar23[4] = iVar3;
                  goto LAB_00116454;
                }
              }
LAB_0011622c:
              if ((uint)piVar23[2] < uVar2) {
                iVar6 = (*(code *)param_1[0xc])(param_1[0xd],*piVar23,piVar23[3],uVar2);
                if (iVar6 == 0) goto LAB_00116270;
                piVar23[2] = uVar2;
                *piVar23 = iVar6;
              }
              piVar23[1] = uVar2;
            }
LAB_00116270:
            uVar11 = 0x10;
            goto LAB_00115820;
          }
        }
        else {
          uVar21 = uVar2 - (*param_1 & uVar2 - 1) & uVar2 - 1;
          uVar2 = param_1[4];
          if (piVar23[0xd] == 0) goto LAB_00115810;
LAB_0011564c:
          if (uVar2 != 0xffffffff) goto LAB_00115654;
        }
        uVar11 = 2;
LAB_00115820:
        param_1[7] = uVar11;
        return 0;
      }
    }
  }
  uVar11 = 0x18;
LAB_00115584:
  param_1[7] = uVar11;
  return 0;
}

