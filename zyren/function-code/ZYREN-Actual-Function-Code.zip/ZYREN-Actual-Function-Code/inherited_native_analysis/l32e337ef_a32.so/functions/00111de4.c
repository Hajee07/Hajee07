/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00111de4 FUN_00111de4 */

undefined4 FUN_00111de4(int param_1,char *param_2,uint param_3,uint param_4,uint param_5)

{
  char *pcVar1;
  char **ppcVar2;
  char *pcVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  undefined auStack_1028 [4100];
  
  iVar5 = DAT_00111f70 + 0x111e10;
  *(int *)(param_1 + 0x3c) = iVar5;
  *(undefined4 *)(param_1 + 0x40) = 0;
  if ((param_5 & 0x8000) != 0) {
    iVar5 = DAT_00111f74 + 0x111e34;
    *(int *)(param_1 + 0x38) = iVar5;
  }
  *(int *)(param_1 + 0x44) = param_1;
  iVar5 = FUN_00111500(param_1,iVar5,param_3,param_4,param_5);
  if (iVar5 != 0) {
    pcVar1 = (char *)FUN_001201d4(param_2,0);
    if (-1 < (int)pcVar1) {
      ppcVar2 = (char **)malloc(0xc);
      pcVar3 = strdup(param_2);
      *ppcVar2 = pcVar3;
      ppcVar2[1] = (char *)0x0;
      ppcVar2[2] = pcVar1;
      if (ppcVar2 != (char **)0x0) {
        *(char ***)(*(int *)(param_1 + 0x48) + 0x3c) = ppcVar2;
        *(undefined4 *)(param_1 + 0x18) = 4;
        if ((param_3 | param_4) == 0) {
          return 1;
        }
        __aeabi_memclr8(auStack_1028,0x1000);
        uVar6 = 0;
        iVar5 = 0;
        while( true ) {
          uVar7 = (uint)(param_4 == 0 && (0xfff < param_3) <= param_4);
          uVar8 = 0x1000;
          if (uVar7 != 0) {
            uVar8 = param_3;
          }
          uVar4 = (**(code **)(param_1 + 0x3c))
                            (*(undefined4 *)(param_1 + 0x44),*(code **)(param_1 + 0x3c),uVar6,iVar5,
                             auStack_1028,uVar8);
          if (uVar7 != 0) {
            uVar7 = param_4;
          }
          if (uVar4 != uVar8) break;
          bVar9 = param_3 < uVar8;
          param_3 = param_3 - uVar8;
          param_4 = param_4 - (uVar7 + bVar9);
          bVar9 = CARRY4(uVar8,uVar6);
          uVar6 = uVar8 + uVar6;
          iVar5 = uVar7 + iVar5 + (uint)bVar9;
          if ((param_3 | param_4) == 0) {
            return 1;
          }
        }
        FUN_00111a30(param_1,1);
        *(undefined4 *)(param_1 + 0x1c) = 0x13;
        return 0;
      }
    }
    FUN_00111a30(param_1,1);
    *(undefined4 *)(param_1 + 0x1c) = 0x11;
    return 0;
  }
  return 0;
}

