/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021daf4 FUN_0021daf4 */

void FUN_0021daf4(undefined4 param_1,int param_2)

{
  if (param_2 != 0) {
    FUN_0021d908();
    return;
  }
  raise(8);
  return;
}

