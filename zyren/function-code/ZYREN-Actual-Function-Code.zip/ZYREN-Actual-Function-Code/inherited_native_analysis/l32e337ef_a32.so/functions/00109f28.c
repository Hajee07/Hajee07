/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00109f28 FUN_00109f28 */

code * FUN_00109f28(code **param_1,int param_2)

{
  byte bVar1;
  bool bVar2;
  code *pcVar3;
  int iVar4;
  undefined4 uVar5;
  code *pcVar6;
  code *pcVar7;
  code *pcVar8;
  code *pcVar9;
  code *pcVar10;
  code **ppcVar11;
  code **ppcVar12;
  
  bVar2 = false;
  if (((*(byte *)((int)param_1 + 10) & 8) != 0) &&
     (bVar2 = false, param_1[7] + -(int)param_1[0x10] <= param_1[9])) {
    bVar2 = true;
  }
  if ((*param_1 == (code *)0x0) && (0x14ccb < (uint)(*(int *)param_1[0x1f] - (int)param_1[0x23]))) {
    pcVar10 = param_1[0x1d] + (int)param_1[0x23];
  }
  else {
    pcVar10 = (code *)((int)param_1 + 0x39272);
  }
  param_1[0x16] = (code *)0x0;
  param_1[0x17] = (code *)0x0;
  param_1[0xc] = pcVar10;
  param_1[0xd] = pcVar10 + 0x14cbc;
  *param_1[0xb] = (code)((byte)*param_1[0xb] >> ((uint)param_1[0xe] & 0xff));
  pcVar3 = param_1[10];
  if (param_1[0xe] == (code *)0x8) {
    pcVar3 = pcVar3 + -1;
  }
  param_1[10] = pcVar3;
  if (((*(byte *)((int)param_1 + 9) & 0x10) != 0) && (param_1[0x19] == (code *)0x0)) {
    pcVar3 = param_1[0x11];
    pcVar7 = pcVar3 + 8;
    param_1[0x11] = pcVar7;
    pcVar3 = (code *)((uint)param_1[0x12] | 0x78 << ((uint)pcVar3 & 0xff));
    param_1[0x12] = pcVar3;
    while ((code *)0x7 < pcVar7) {
      pcVar8 = param_1[0xc];
      if (pcVar8 < param_1[0xd]) {
        param_1[0xc] = pcVar8 + 1;
        *pcVar8 = SUB41(pcVar3,0);
        pcVar7 = param_1[0x11];
        pcVar3 = param_1[0x12];
      }
      pcVar7 = pcVar7 + -8;
      pcVar3 = (code *)((uint)pcVar3 >> 8);
      param_1[0x11] = pcVar7;
      param_1[0x12] = pcVar3;
    }
    pcVar8 = pcVar7 + 8;
    pcVar3 = (code *)((uint)pcVar3 | 1 << ((uint)pcVar7 & 0xff));
    param_1[0x11] = pcVar8;
    param_1[0x12] = pcVar3;
    pcVar7 = param_1[0xc];
    if (pcVar7 < param_1[0xd]) goto LAB_0010a0bc;
    while( true ) {
      pcVar8 = pcVar8 + -8;
      pcVar3 = (code *)((uint)pcVar3 >> 8);
      param_1[0x11] = pcVar8;
      param_1[0x12] = pcVar3;
      if (pcVar8 < (code *)0x8) break;
      pcVar7 = param_1[0xc];
      if (pcVar7 < param_1[0xd]) {
LAB_0010a0bc:
        param_1[0xc] = pcVar7 + 1;
        *pcVar7 = SUB41(pcVar3,0);
        pcVar8 = param_1[0x11];
        pcVar3 = param_1[0x12];
      }
    }
  }
  ppcVar12 = param_1 + 0x11;
  pcVar3 = *ppcVar12;
  pcVar7 = pcVar3 + 1;
  *ppcVar12 = pcVar7;
  pcVar8 = param_1[0xc];
  ppcVar11 = param_1 + 0x12;
  pcVar3 = (code *)((uint)*ppcVar11 | (uint)(param_2 == 4) << ((uint)pcVar3 & 0xff));
  *ppcVar11 = pcVar3;
  while ((code *)0x7 < pcVar7) {
    if (pcVar8 < param_1[0xd]) {
      param_1[0xc] = pcVar8 + 1;
      *pcVar8 = SUB41(pcVar3,0);
      pcVar8 = param_1[0xc];
      pcVar7 = param_1[0x11];
      pcVar3 = param_1[0x12];
    }
    pcVar7 = pcVar7 + -8;
    pcVar3 = (code *)((uint)pcVar3 >> 8);
    *ppcVar11 = pcVar3;
    *ppcVar12 = pcVar7;
  }
  iVar4 = 0;
  if (!bVar2) {
    uVar5 = 1;
    if (((*(byte *)((int)param_1 + 10) & 4) == 0) && (uVar5 = 0, param_1[0xf] < (code *)0x30)) {
      uVar5 = 1;
    }
    iVar4 = FUN_0011a0f8(param_1,uVar5);
    if ((param_1[0xf] == (code *)0x0) || (param_1[0xc] + (1 - (int)pcVar8) < param_1[0xf])) {
LAB_0010a17c:
      if (iVar4 == 0) {
        param_1[0xc] = pcVar8;
        param_1[0x11] = pcVar7;
        param_1[0x12] = pcVar3;
        FUN_0011a0f8(param_1,1);
      }
LAB_0010a42c:
      if (param_2 != 0) {
        if (param_2 != 4) {
          pcVar3 = *ppcVar12 + 3;
          *ppcVar12 = pcVar3;
          while ((code *)0x7 < pcVar3) {
            pcVar7 = param_1[0xc];
            if (pcVar7 < param_1[0xd]) {
              param_1[0xc] = pcVar7 + 1;
              *pcVar7 = SUB41(param_1[0x12],0);
              pcVar3 = param_1[0x11];
            }
            pcVar3 = pcVar3 + -8;
            *ppcVar11 = (code *)((uint)*ppcVar11 >> 8);
            *ppcVar12 = pcVar3;
          }
          if (pcVar3 == (code *)0x0) {
            pcVar3 = *ppcVar11;
            pcVar7 = (code *)0x10;
          }
          else {
            *ppcVar12 = (code *)0x8;
            pcVar3 = param_1[0xc];
            pcVar7 = (code *)0x8;
            if (pcVar3 < param_1[0xd]) goto LAB_0010a504;
            while( true ) {
              pcVar8 = pcVar7 + -8;
              pcVar3 = (code *)((uint)*ppcVar11 >> 8);
              *ppcVar11 = pcVar3;
              *ppcVar12 = pcVar8;
              if (pcVar8 < (code *)0x8) break;
              pcVar3 = param_1[0xc];
              pcVar7 = pcVar8;
              if (pcVar3 < param_1[0xd]) {
LAB_0010a504:
                param_1[0xc] = pcVar3 + 1;
                *pcVar3 = SUB41(param_1[0x12],0);
                pcVar7 = param_1[0x11];
              }
            }
            pcVar7 = pcVar7 + 8;
          }
          *ppcVar11 = pcVar3;
          *ppcVar12 = pcVar7;
          pcVar8 = param_1[0xc];
          if (param_1[0xd] <= pcVar8) goto LAB_0010a73c;
          do {
            param_1[0xc] = pcVar8 + 1;
            *pcVar8 = SUB41(pcVar3,0);
            pcVar3 = param_1[0x12];
            pcVar7 = param_1[0x11];
LAB_0010a73c:
            do {
              pcVar6 = pcVar7 + -8;
              pcVar3 = (code *)((uint)pcVar3 >> 8);
              *ppcVar11 = pcVar3;
              *ppcVar12 = pcVar6;
              if (pcVar6 < (code *)0x8) {
                pcVar3 = (code *)((uint)pcVar3 | 0xffff << ((uint)pcVar6 & 0xff));
                pcVar7 = pcVar7 + 8;
                *ppcVar11 = pcVar3;
                *ppcVar12 = pcVar7;
                while ((code *)0x7 < pcVar7) {
                  pcVar8 = param_1[0xc];
                  if (pcVar8 < param_1[0xd]) {
                    param_1[0xc] = pcVar8 + 1;
                    *pcVar8 = SUB41(pcVar3,0);
                    pcVar7 = param_1[0x11];
                    pcVar3 = param_1[0x12];
                  }
                  pcVar7 = pcVar7 + -8;
                  pcVar3 = (code *)((uint)pcVar3 >> 8);
                  *ppcVar11 = pcVar3;
                  *ppcVar12 = pcVar7;
                }
                goto LAB_0010a7cc;
              }
              pcVar8 = param_1[0xc];
              pcVar7 = pcVar6;
            } while (param_1[0xd] <= pcVar8);
          } while( true );
        }
        if (*ppcVar12 == (code *)0x0) {
          pcVar3 = (code *)0x0;
        }
        else {
          pcVar3 = (code *)0x8;
          *ppcVar12 = (code *)0x8;
          pcVar7 = param_1[0xc];
          if (pcVar7 < param_1[0xd]) goto LAB_0010a48c;
          while( true ) {
            pcVar3 = pcVar3 + -8;
            *ppcVar11 = (code *)((uint)*ppcVar11 >> 8);
            *ppcVar12 = pcVar3;
            if (pcVar3 < (code *)0x8) break;
            pcVar7 = param_1[0xc];
            if (pcVar7 < param_1[0xd]) {
LAB_0010a48c:
              param_1[0xc] = pcVar7 + 1;
              *pcVar7 = SUB41(param_1[0x12],0);
              pcVar3 = param_1[0x11];
            }
          }
        }
        if ((*(byte *)((int)param_1 + 9) & 0x10) != 0) {
          pcVar8 = param_1[6];
          param_1[0x11] = pcVar3 + 8;
          pcVar7 = (code *)((uint)param_1[0x12] | ((uint)pcVar8 >> 0x18) << ((uint)pcVar3 & 0xff));
          param_1[0x12] = pcVar7;
          pcVar6 = param_1[0xc];
          pcVar3 = pcVar3 + 8;
          if (param_1[0xd] <= pcVar6) goto LAB_0010a5b8;
          do {
            param_1[0xc] = pcVar6 + 1;
            *pcVar6 = SUB41(pcVar7,0);
            pcVar7 = param_1[0x12];
            pcVar3 = param_1[0x11];
LAB_0010a5b8:
            do {
              pcVar9 = pcVar3 + -8;
              pcVar7 = (code *)((uint)pcVar7 >> 8);
              *ppcVar11 = pcVar7;
              *ppcVar12 = pcVar9;
              if (pcVar9 < (code *)0x8) {
                pcVar7 = (code *)((uint)pcVar7 |
                                 ((uint)((int)pcVar8 << 8) >> 0x18) << ((uint)pcVar9 & 0xff));
                *ppcVar11 = pcVar7;
                *ppcVar12 = pcVar3;
                while ((code *)0x7 < pcVar3) {
                  pcVar6 = param_1[0xc];
                  if (pcVar6 < param_1[0xd]) {
                    param_1[0xc] = pcVar6 + 1;
                    *pcVar6 = SUB41(pcVar7,0);
                    pcVar3 = param_1[0x11];
                    pcVar7 = param_1[0x12];
                  }
                  pcVar3 = pcVar3 + -8;
                  pcVar7 = (code *)((uint)pcVar7 >> 8);
                  *ppcVar11 = pcVar7;
                  *ppcVar12 = pcVar3;
                }
                pcVar7 = (code *)((uint)pcVar7 |
                                 ((uint)((int)pcVar8 << 0x10) >> 0x18) << ((uint)pcVar3 & 0xff));
                pcVar3 = pcVar3 + 8;
                *ppcVar11 = pcVar7;
                *ppcVar12 = pcVar3;
                while ((code *)0x7 < pcVar3) {
                  pcVar6 = param_1[0xc];
                  if (pcVar6 < param_1[0xd]) {
                    param_1[0xc] = pcVar6 + 1;
                    *pcVar6 = SUB41(pcVar7,0);
                    pcVar3 = param_1[0x11];
                    pcVar7 = param_1[0x12];
                  }
                  pcVar3 = pcVar3 + -8;
                  pcVar7 = (code *)((uint)pcVar7 >> 8);
                  *ppcVar11 = pcVar7;
                  *ppcVar12 = pcVar3;
                }
                pcVar7 = (code *)((uint)pcVar7 | ((uint)pcVar8 & 0xff) << ((uint)pcVar3 & 0xff));
                pcVar3 = pcVar3 + 8;
                *ppcVar11 = pcVar7;
                *ppcVar12 = pcVar3;
                pcVar8 = param_1[0xc];
                if (pcVar8 < param_1[0xd]) goto LAB_0010a6f0;
                while( true ) {
                  pcVar3 = pcVar3 + -8;
                  pcVar7 = (code *)((uint)pcVar7 >> 8);
                  *ppcVar11 = pcVar7;
                  *ppcVar12 = pcVar3;
                  if (pcVar3 < (code *)0x8) break;
                  pcVar8 = param_1[0xc];
                  if (pcVar8 < param_1[0xd]) {
LAB_0010a6f0:
                    param_1[0xc] = pcVar8 + 1;
                    *pcVar8 = SUB41(pcVar7,0);
                    pcVar3 = param_1[0x11];
                    pcVar7 = param_1[0x12];
                  }
                }
                goto LAB_0010a7cc;
              }
              pcVar6 = param_1[0xc];
              pcVar3 = pcVar9;
            } while (param_1[0xd] <= pcVar6);
          } while( true );
        }
      }
LAB_0010a7cc:
      __aeabi_memclr((int)param_1 + 0x8192,0x280);
      pcVar3 = param_1[0xf];
      param_1[10] = (code *)((int)param_1 + 0x9273);
      pcVar7 = param_1[0xc] + -(int)pcVar10;
      param_1[0xb] = (code *)((int)param_1 + 0x9272);
      param_1[0xe] = (code *)0x8;
      param_1[0xf] = (code *)0x0;
      param_1[0x10] = param_1[0x10] + (int)pcVar3;
      param_1[0x19] = param_1[0x19] + 1;
      if (pcVar7 != (code *)0x0) {
        pcVar3 = *param_1;
        if (pcVar3 == (code *)0x0) {
          if (pcVar10 == (code *)((int)param_1 + 0x39272)) {
            pcVar10 = (code *)(*(int *)param_1[0x1f] - (int)param_1[0x23]);
            if (pcVar7 < pcVar10) {
              pcVar10 = pcVar7;
            }
            __aeabi_memcpy(param_1[0x1d] + (int)param_1[0x23],(code *)((int)param_1 + 0x39272),
                           pcVar10);
            param_1[0x23] = param_1[0x23] + (int)pcVar10;
            if (pcVar7 + -(int)pcVar10 != (code *)0x0) {
              param_1[0x16] = pcVar10;
              param_1[0x17] = pcVar7 + -(int)pcVar10;
            }
            return param_1[0x17];
          }
          param_1[0x23] = param_1[0x23] + (int)pcVar7;
          return param_1[0x17];
        }
        *(int *)param_1[0x1e] = (int)param_1[0x21] - (int)param_1[0x1c];
        iVar4 = (*pcVar3)(&UNK_00039272 + (int)param_1,pcVar7,param_1[1]);
        if (iVar4 == 0) {
          param_1[0x1b] = (code *)0xffffffff;
          return (code *)0xffffffff;
        }
      }
      return param_1[0x17];
    }
  }
  if (param_1[7] + -(int)param_1[0x10] <= param_1[9]) {
    pcVar7 = pcVar7 + 2;
    param_1[0xc] = pcVar8;
    param_1[0x11] = pcVar7;
    param_1[0x12] = pcVar3;
    if ((code *)0x7 < pcVar7) {
      if (param_1[0xd] <= pcVar8) goto LAB_0010a218;
      do {
        param_1[0xc] = pcVar8 + 1;
        *pcVar8 = SUB41(pcVar3,0);
        pcVar7 = param_1[0x11];
        pcVar3 = param_1[0x12];
LAB_0010a218:
        do {
          pcVar7 = pcVar7 + -8;
          pcVar3 = (code *)((uint)pcVar3 >> 8);
          *ppcVar11 = pcVar3;
          *ppcVar12 = pcVar7;
          if (pcVar7 < (code *)0x8) {
            if (pcVar7 != (code *)0x0) goto LAB_0010a24c;
            pcVar7 = (code *)0x0;
            goto LAB_0010a2a8;
          }
          pcVar8 = param_1[0xc];
        } while (param_1[0xd] <= pcVar8);
      } while( true );
    }
LAB_0010a24c:
    pcVar7 = (code *)0x8;
    *ppcVar12 = (code *)0x8;
    pcVar8 = param_1[0xc];
    if (pcVar8 < param_1[0xd]) goto LAB_0010a28c;
    while( true ) {
      pcVar7 = pcVar7 + -8;
      pcVar3 = (code *)((uint)pcVar3 >> 8);
      *ppcVar11 = pcVar3;
      *ppcVar12 = pcVar7;
      if (pcVar7 < (code *)0x8) break;
      pcVar8 = param_1[0xc];
      if (pcVar8 < param_1[0xd]) {
LAB_0010a28c:
        param_1[0xc] = pcVar8 + 1;
        *pcVar8 = SUB41(pcVar3,0);
        pcVar7 = param_1[0x11];
        pcVar3 = param_1[0x12];
      }
    }
LAB_0010a2a8:
    param_1[0x11] = pcVar7 + 0x10;
    pcVar3 = (code *)((uint)pcVar3 | (uint)*(ushort *)(param_1 + 0xf) << ((uint)pcVar7 & 0xff));
    param_1[0x12] = pcVar3;
    pcVar8 = param_1[0xc];
    pcVar7 = pcVar7 + 0x10;
    if (param_1[0xd] <= pcVar8) goto LAB_0010a2e0;
LAB_0010a2cc:
    param_1[0xc] = pcVar8 + 1;
    *pcVar8 = SUB41(pcVar3,0);
    pcVar3 = param_1[0x12];
    pcVar7 = param_1[0x11];
LAB_0010a2e0:
    pcVar6 = pcVar7 + -8;
    pcVar3 = (code *)((uint)pcVar3 >> 8);
    *ppcVar11 = pcVar3;
    *ppcVar12 = pcVar6;
    if ((code *)0x7 < pcVar6) goto code_r0x0010a2f8;
    pcVar8 = param_1[0xf];
    pcVar7 = pcVar7 + 8;
    param_1[0xf] = (code *)((uint)pcVar8 ^ 0xffff);
    param_1[0x11] = pcVar7;
    pcVar3 = (code *)((uint)pcVar3 |
                     ((uint)(code *)((uint)pcVar8 ^ 0xffff) & 0xffff) << ((uint)pcVar6 & 0xff));
    param_1[0x12] = pcVar3;
    if (pcVar7 < (code *)0x8) {
      param_1[0xf] = pcVar8;
    }
    else {
      do {
        pcVar8 = param_1[0xc];
        if (pcVar8 < param_1[0xd]) {
          param_1[0xc] = pcVar8 + 1;
          *pcVar8 = SUB41(pcVar3,0);
          pcVar7 = param_1[0x11];
          pcVar3 = param_1[0x12];
        }
        pcVar7 = pcVar7 + -8;
        pcVar3 = (code *)((uint)pcVar3 >> 8);
        *ppcVar11 = pcVar3;
        *ppcVar12 = pcVar7;
      } while ((code *)0x7 < pcVar7);
      pcVar8 = (code *)((uint)param_1[0xf] ^ 0xffff);
      param_1[0xf] = pcVar8;
    }
    if (pcVar8 != (code *)0x0) {
      pcVar8 = (code *)0x0;
      do {
        bVar1 = *(byte *)((int)param_1 + ((uint)(param_1[0x10] + (int)pcVar8) & 0x7fff) + 0x90);
        param_1[0x11] = pcVar7 + 8;
        pcVar3 = (code *)((uint)pcVar3 | (uint)bVar1 << ((uint)pcVar7 & 0xff));
        param_1[0x12] = pcVar3;
        pcVar6 = param_1[0xc];
        pcVar7 = pcVar7 + 8;
        if (pcVar6 < param_1[0xd]) goto LAB_0010a414;
        while( true ) {
          pcVar7 = pcVar7 + -8;
          pcVar3 = (code *)((uint)pcVar3 >> 8);
          *ppcVar11 = pcVar3;
          *ppcVar12 = pcVar7;
          if (pcVar7 < (code *)0x8) break;
          pcVar6 = param_1[0xc];
          if (pcVar6 < param_1[0xd]) {
LAB_0010a414:
            param_1[0xc] = pcVar6 + 1;
            *pcVar6 = SUB41(pcVar3,0);
            pcVar7 = param_1[0x11];
            pcVar3 = param_1[0x12];
          }
        }
        pcVar8 = pcVar8 + 1;
      } while (pcVar8 < param_1[0xf]);
    }
    goto LAB_0010a42c;
  }
  goto LAB_0010a17c;
code_r0x0010a2f8:
  pcVar8 = param_1[0xc];
  pcVar7 = pcVar6;
  if (pcVar8 < param_1[0xd]) goto LAB_0010a2cc;
  goto LAB_0010a2e0;
}

