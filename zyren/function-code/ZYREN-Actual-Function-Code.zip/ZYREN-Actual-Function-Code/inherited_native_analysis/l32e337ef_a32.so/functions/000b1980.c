/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000b1980 FUN_000b1980 */

void FUN_000b1980(undefined4 param_1,undefined4 param_2)

{
  int unaff_r4;
  code *UNRECOVERED_JUMPTABLE;
  
  if (unaff_r4 != DAT_000b1994) {
    UNRECOVERED_JUMPTABLE = (code *)((int)&DAT_000b19b8 + DAT_000b19b8);
  }
                    /* WARNING: Could not recover jumptable at 0x000b19dc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(param_1,param_2);
  return;
}

