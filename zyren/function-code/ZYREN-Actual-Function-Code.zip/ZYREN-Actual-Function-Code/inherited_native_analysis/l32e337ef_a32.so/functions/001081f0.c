/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001081f0 FUN_001081f0 */

int FUN_001081f0(uint *param_1,ushort *param_2,int *param_3,byte *param_4,byte *param_5,
                uint *param_6,uint param_7)

{
  uint uVar1;
  byte bVar2;
  ushort uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  short *psVar13;
  byte *pbVar14;
  int iVar15;
  byte *pbVar16;
  undefined uVar17;
  ushort *puVar18;
  byte *pbVar19;
  int iVar20;
  int iVar21;
  uint uVar22;
  uint uVar23;
  byte *pbVar24;
  uint uVar25;
  uint uVar26;
  ushort *puVar27;
  ushort *puVar28;
  int iVar29;
  uint uVar30;
  uint uVar31;
  byte *pbVar32;
  int iVar33;
  bool bVar34;
  int local_108;
  int local_104;
  int local_100;
  int local_fc;
  int local_f8;
  int local_f4;
  int local_f0;
  uint local_e8;
  uint local_d0;
  uint local_c4;
  byte *local_bc;
  uint local_b8;
  uint local_b4;
  int aiStack_b0 [4];
  int local_a0;
  int local_9c;
  int local_98;
  int local_94;
  int local_90;
  int local_8c;
  int local_88;
  int local_84;
  int local_80;
  int local_7c;
  int local_78;
  int local_74;
  uint local_6c [5];
  int local_58;
  int local_54;
  int local_50;
  int local_4c;
  int local_48;
  int local_44;
  int local_40;
  int local_3c;
  int local_38;
  int local_34;
  int local_30;
  int local_2c;
  
  pbVar24 = (byte *)0xffffffff;
  uVar22 = param_7 & 4;
  uVar4 = param_7;
  if (uVar22 == 0) {
    uVar4 = ~(uint)param_4;
  }
  iVar33 = *param_3;
  if (uVar22 == 0) {
    pbVar24 = param_5 + *param_6 + uVar4;
  }
  if ((param_5 < param_4) || (((uint)(pbVar24 + 1) & (uint)pbVar24) != 0)) {
    *param_6 = 0;
    *param_3 = 0;
    return -3;
  }
  local_b8 = param_1[8];
  uVar5 = *param_1;
  uVar30 = param_1[1];
  local_c4 = param_1[10];
  local_e8 = param_1[0xe];
  uVar4 = param_1[9];
  local_d0 = param_1[0xf];
  local_b4 = uVar4;
  puVar27 = param_2;
  if (0x35 < uVar5) {
    local_bc = param_5;
    iVar20 = -1;
    goto switchD_001082a8_caseD_4;
  }
  puVar18 = (ushort *)((int)param_2 + iVar33);
  pbVar19 = param_5 + *param_6;
  local_bc = param_5;
  iVar20 = -1;
  puVar28 = param_2;
  switch(uVar5) {
  case 0:
    local_e8 = 0;
    param_1[7] = 1;
    uVar30 = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 1;
    local_c4 = 0;
    local_b4 = 0;
    local_b8 = 0;
    if ((param_7 & 1) != 0) goto switchD_001082a8_caseD_1;
    local_c4 = 0;
    uVar4 = 0;
    uVar30 = 0;
    local_b8 = 0;
    goto joined_r0x00108600;
  case 1:
switchD_001082a8_caseD_1:
    if (iVar33 < 1) {
      *param_1 = 1;
      goto LAB_001085b8;
    }
    puVar28 = (ushort *)((int)param_2 + 1);
    param_1[2] = (uint)*(byte *)param_2;
  case 2:
    if (puVar18 <= puVar28) {
      *param_1 = 2;
      local_bc = param_5;
      puVar27 = puVar28;
LAB_001088fc:
      iVar20 = 1;
      if ((param_7 & 2) == 0) {
        iVar20 = -4;
      }
      goto switchD_001082a8_caseD_4;
    }
    uVar5 = param_1[2];
    puVar27 = (ushort *)((int)puVar28 + 1);
    uVar4 = (uint)*(byte *)puVar28;
    param_1[3] = uVar4;
    uVar4 = uVar5 & 0xf ^ 8 | (uVar4 | uVar5 << 8) % 0x1f | uVar4 & 0x20;
    if (uVar4 != 0) {
      uVar4 = 1;
    }
    if (uVar22 == 0) {
      uVar4 = (0x8000 < (uint)(0x100 << (uVar5 >> 4 & 0xff)) ||
              pbVar24 + 1 < (byte *)(0x100 << (uVar5 >> 4 & 0xff))) | uVar4;
    }
    if (uVar4 == 0) {
      uVar4 = 0;
joined_r0x00108600:
      do {
        for (; local_b4 = uVar4, uVar30 < 3; uVar30 = uVar30 + 8) {
LAB_00108608:
          if (puVar18 <= puVar27) {
            uVar4 = 3;
            goto LAB_001088ec;
          }
          local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
          uVar4 = local_b4;
          puVar27 = (ushort *)((int)puVar27 + 1);
        }
        uVar25 = local_e8 & 7;
        uVar30 = uVar30 - 3;
        local_b4 = 0;
        local_e8 = local_e8 >> 3;
        uVar5 = uVar25 >> 1;
        param_1[5] = uVar25;
        param_1[6] = uVar5;
        if (uVar25 >> 1 == 0) {
LAB_00108670:
          uVar4 = uVar30 & 7;
          uVar5 = 0;
          uVar30 = uVar30 - uVar4;
          local_e8 = local_e8 >> uVar4;
          do {
            while (local_b4 = uVar5, uVar30 != 0) {
              puVar28 = puVar27;
              if (uVar30 < 8) {
LAB_00108858:
                do {
                  if (puVar18 <= puVar28) {
                    uVar4 = 6;
                    puVar27 = puVar28;
                    goto LAB_001088ec;
                  }
                  puVar27 = (ushort *)((int)puVar28 + 1);
                  local_e8 = local_e8 | (uint)*(byte *)puVar28 << (uVar30 & 0xff);
                  bVar34 = 0xfffffff7 < uVar30;
                  uVar30 = uVar30 + 8;
                  puVar28 = puVar27;
                } while (bVar34);
              }
              uVar30 = uVar30 - 8;
              uVar5 = local_b4 + 1;
              *(char *)((int)param_1 + local_b4 + 0x2920) = (char)local_e8;
              local_e8 = local_e8 >> 8;
              if (3 < uVar5) goto LAB_00108898;
            }
            uVar30 = 0;
            puVar28 = puVar27;
switchD_001082a8_caseD_7:
            if (puVar18 <= puVar28) {
              uVar4 = 7;
              puVar27 = puVar28;
              goto LAB_001088ec;
            }
            puVar27 = (ushort *)((int)puVar28 + 1);
            uVar5 = local_b4 + 1;
            *(byte *)((int)param_1 + local_b4 + 0x2920) = *(byte *)puVar28;
          } while (uVar5 < 4);
LAB_00108898:
          local_b4 = (uint)*(ushort *)(param_1 + 0xa48);
          if (local_b4 != (*(ushort *)((int)param_1 + 0x2922) ^ 0xffff))
          goto switchD_001082a8_caseD_27;
          for (; local_b4 != 0 && uVar30 != 0; local_b4 = local_b4 - 1) {
            puVar28 = puVar27;
            if (uVar30 < 8) {
LAB_00108b3c:
              do {
                if (puVar18 <= puVar28) {
                  uVar4 = 0x33;
                  puVar27 = puVar28;
                  goto LAB_001088ec;
                }
                puVar27 = (ushort *)((int)puVar28 + 1);
                local_e8 = local_e8 | (uint)*(byte *)puVar28 << (uVar30 & 0xff);
                bVar34 = 0xfffffff7 < uVar30;
                uVar30 = uVar30 + 8;
                puVar28 = puVar27;
              } while (bVar34);
            }
            uVar30 = uVar30 - 8;
            local_b8 = local_e8 & 0xff;
            local_e8 = local_e8 >> 8;
switchD_001082a8_caseD_34:
            if (pbVar19 <= local_bc) {
              iVar20 = 2;
              uVar5 = 0x34;
              goto switchD_001082a8_caseD_24;
            }
            *local_bc = (byte)local_b8;
            local_bc = local_bc + 1;
          }
          for (; uVar4 = 0, uVar5 = uVar30, local_b4 != 0; local_b4 = local_b4 - uVar4) {
switchD_001082a8_caseD_9:
            if (pbVar19 <= local_bc) {
              iVar20 = 2;
              uVar5 = 9;
              goto switchD_001082a8_caseD_24;
            }
switchD_001082a8_caseD_26:
            if (puVar18 <= puVar27) {
              uVar4 = 0x26;
              goto LAB_001088ec;
            }
            uVar4 = (int)puVar18 - (int)puVar27;
            if ((uint)((int)pbVar19 - (int)local_bc) < (uint)((int)puVar18 - (int)puVar27)) {
              uVar4 = (int)pbVar19 - (int)local_bc;
            }
            if (local_b4 <= uVar4) {
              uVar4 = local_b4;
            }
            __aeabi_memcpy(local_bc,puVar27,uVar4);
            local_bc = local_bc + uVar4;
            puVar27 = (ushort *)((int)puVar27 + uVar4);
          }
        }
        else {
          if (uVar5 == 1) {
            param_1[0xb] = 0x120;
            param_1[0xc] = 0x20;
            param_1[0x378] = 0x5050505;
            param_1[0x379] = 0x5050505;
            param_1[0x37a] = 0x5050505;
            param_1[0x37b] = 0x5050505;
            param_1[0x37c] = 0x5050505;
            param_1[0x37d] = 0x5050505;
            param_1[0x37e] = 0x5050505;
            param_1[0x37f] = 0x5050505;
            __aeabi_memset(param_1 + 0x10,0x90,8);
            __aeabi_memset(param_1 + 0x34,0x70,9);
            param_1[0x57] = 0x8080808;
            param_1[0x56] = 0x8080808;
            param_1[0x55] = 0x7070707;
            param_1[0x54] = 0x7070707;
            param_1[0x53] = 0x7070707;
            param_1[0x52] = 0x7070707;
            param_1[0x51] = 0x7070707;
            param_1[0x50] = 0x7070707;
          }
          else {
            if (uVar5 == 3) goto switchD_001082a8_caseD_a;
            for (; local_b4 < 3; local_b4 = local_b4 + 1) {
              uVar4 = (uint)*(byte *)(DAT_00109c30 + 0x108c48 + local_b4);
              if (uVar30 < uVar4) {
switchD_001082a8_caseD_b:
                puVar28 = puVar27;
                do {
                  if (puVar18 <= puVar28) {
                    uVar4 = 0xb;
                    puVar27 = puVar28;
                    goto LAB_001088ec;
                  }
                  puVar27 = (ushort *)((int)puVar28 + 1);
                  uVar4 = (uint)*(byte *)(DAT_00109c34 + 0x108c64 + local_b4);
                  local_e8 = local_e8 | (uint)*(byte *)puVar28 << (uVar30 & 0xff);
                  uVar30 = uVar30 + 8;
                  puVar28 = puVar27;
                } while (uVar30 < uVar4);
              }
              uVar5 = local_e8 & ~(-1 << uVar4);
              uVar30 = uVar30 - uVar4;
              local_e8 = local_e8 >> uVar4;
              param_1[local_b4 + 0xb] = uVar5 + *(int *)(DAT_00109c84 + 0x108c9c + local_b4 * 4);
            }
            __aeabi_memclr4(param_1 + 0x6e0,0x120);
            uVar4 = 0;
            if (param_1[0xd] != 0) {
              do {
                for (; puVar28 = puVar27, local_b4 = uVar4, uVar30 < 3; uVar30 = uVar30 + 8) {
LAB_00108d20:
                  if (puVar18 <= puVar28) {
                    uVar4 = 0xe;
                    puVar27 = puVar28;
                    goto LAB_001088ec;
                  }
                  puVar27 = (ushort *)((int)puVar28 + 1);
                  local_e8 = local_e8 | (uint)*(byte *)puVar28 << (uVar30 & 0xff);
                  uVar4 = local_b4;
                }
                bVar2 = (byte)local_e8;
                uVar30 = uVar30 - 3;
                local_e8 = local_e8 >> 3;
                pbVar32 = (byte *)(DAT_00109c88 + 0x108d54 + uVar4);
                uVar4 = uVar4 + 1;
                *(byte *)((int)param_1 + *pbVar32 + 0x1b80) = bVar2 & 7;
              } while (uVar4 < param_1[0xd]);
            }
            param_1[0xd] = 0x13;
          }
          uVar5 = param_1[6];
          local_b4 = uVar4;
          pbVar32 = local_bc;
          while (-1 < (int)uVar5) {
            __aeabi_memclr8(aiStack_b0,0x40);
            __aeabi_memclr(param_1 + uVar5 * 0x368 + 0x58,0xc80);
            uVar4 = param_1[6];
            uVar25 = param_1[uVar4 + 0xb];
            local_104 = 0;
            local_fc = 0;
            local_f0 = 0;
            local_f4 = 0;
            local_f8 = 0;
            local_108 = 0;
            local_100 = 0;
            iVar33 = 0;
            iVar20 = 0;
            iVar6 = 0;
            iVar7 = 0;
            iVar8 = 0;
            iVar9 = 0;
            iVar15 = 0;
            if (uVar25 != 0) {
              uVar31 = 0;
              do {
                bVar2 = *(byte *)((int)param_1 + uVar31 + uVar5 * 0xda0 + 0x40);
                uVar31 = uVar31 + 1;
                aiStack_b0[bVar2] = aiStack_b0[bVar2] + 1;
              } while (uVar31 < uVar25);
              local_104 = local_7c;
              local_fc = local_84;
              local_f8 = local_90;
              local_f0 = local_88;
              local_108 = local_94;
              local_f4 = local_8c;
              local_100 = local_98;
              iVar33 = aiStack_b0[1];
              iVar20 = local_78;
              iVar6 = local_a0;
              iVar7 = local_9c;
              iVar8 = aiStack_b0[2];
              iVar9 = aiStack_b0[3];
              iVar15 = local_80;
            }
            local_6c[0] = 0;
            local_6c[1] = 0;
            local_6c[2] = iVar33 << 1;
            iVar21 = iVar8 + iVar33 * 2;
            iVar29 = iVar9 + iVar21 * 2;
            local_6c[3] = iVar21 * 2;
            iVar21 = iVar6 + iVar29 * 2;
            local_6c[4] = iVar29 * 2;
            iVar29 = iVar7 + iVar21 * 2;
            local_58 = iVar21 * 2;
            iVar21 = local_100 + iVar29 * 2;
            local_54 = iVar29 * 2;
            iVar29 = local_108 + iVar21 * 2;
            local_50 = iVar21 * 2;
            iVar21 = local_f8 + iVar29 * 2;
            local_4c = iVar29 * 2;
            iVar29 = local_f4 + iVar21 * 2;
            local_48 = iVar21 * 2;
            iVar21 = local_f0 + iVar29 * 2;
            local_44 = iVar29 * 2;
            iVar29 = local_fc + iVar21 * 2;
            local_40 = iVar21 * 2;
            iVar21 = iVar15 + iVar29 * 2;
            local_3c = iVar29 * 2;
            iVar29 = local_104 + iVar21 * 2;
            local_38 = iVar21 * 2;
            iVar21 = iVar20 + iVar29 * 2;
            local_34 = iVar29 * 2;
            local_30 = iVar21 * 2;
            local_2c = (local_74 + iVar21 * 2) * 2;
            local_bc = pbVar32;
            if ((1 < (uint)(local_74 +
                           iVar20 + local_104 +
                                    iVar15 + local_fc +
                                             local_f0 +
                                             local_f4 +
                                             local_f8 +
                                             local_108 +
                                             local_100 + iVar7 + iVar6 + iVar9 + iVar8 + iVar33)) &&
               (local_2c != 0x10000)) goto switchD_001082a8_caseD_23;
            if (uVar25 != 0) {
              iVar33 = -1;
              iVar20 = 0;
              bVar2 = *(byte *)(param_1 + uVar5 * 0x368 + 0x10);
              while( true ) {
                uVar31 = (uint)bVar2;
                if (uVar31 != 0) {
                  uVar23 = local_6c[uVar31];
                  local_6c[uVar31] = uVar23 + 1;
                  uVar12 = 0;
                  uVar26 = uVar31;
                  do {
                    uVar10 = uVar12;
                    uVar11 = uVar23 & 1;
                    uVar1 = uVar10 << 1;
                    uVar12 = uVar11 | uVar1;
                    uVar26 = uVar26 - 1;
                    uVar23 = uVar23 >> 1;
                  } while (uVar26 != 0);
                  if (uVar31 < 0xb) {
                    if (uVar1 >> 10 == 0) {
                      puVar28 = (ushort *)((int)param_1 + uVar12 * 2 + uVar5 * 0xda0 + 0x160);
                      do {
                        uVar12 = uVar12 + (1 << uVar31);
                        *puVar28 = (ushort)iVar20 | (ushort)bVar2 << 9;
                        puVar28 = puVar28 + (1 << uVar31);
                      } while (uVar12 < 0x400);
                    }
                  }
                  else {
                    psVar13 = (short *)((int)param_1 +
                                       (uVar11 | uVar1 & 0x3ff) * 2 + uVar5 * 0xda0 + 0x160);
                    iVar6 = (int)*psVar13;
                    if (iVar6 == 0) {
                      *psVar13 = (short)iVar33;
                      iVar6 = iVar33;
                      iVar33 = iVar33 + -2;
                    }
                    uVar23 = iVar6 + ((int)(uVar10 << 0x16) >> 0x1f);
                    if (0xb < uVar31) {
                      uVar12 = uVar10 >> 9 & 0x3fffff;
                      do {
                        psVar13 = (short *)((int)param_1 + ~uVar23 * 2 + uVar5 * 0xda0 + 0x960);
                        iVar6 = (int)*psVar13;
                        if (iVar6 == 0) {
                          *psVar13 = (short)iVar33;
                          iVar6 = iVar33;
                          iVar33 = iVar33 + -2;
                        }
                        uVar31 = uVar31 - 1;
                        uVar23 = iVar6 + ((int)(uVar12 << 0x1e) >> 0x1f);
                        uVar12 = uVar12 >> 1;
                      } while (0xb < uVar31);
                    }
                    *(ushort *)((int)param_1 + ~uVar23 * 2 + uVar5 * 0xda0 + 0x960) = (ushort)iVar20
                    ;
                  }
                }
                if (iVar20 + 1U == uVar25) break;
                iVar20 = iVar20 + 1;
                bVar2 = *(byte *)((int)param_1 + iVar20 + uVar5 * 0xda0 + 0x40);
              }
            }
            uVar5 = 0;
            if (uVar4 == 2) {
              while( true ) {
                uVar31 = param_1[0xb];
                uVar25 = param_1[0xc];
                uVar4 = uVar25 + uVar31;
                local_b4 = uVar5;
                if (uVar4 <= uVar5) break;
                if (uVar30 < 0xf) {
                  if ((int)puVar18 - (int)puVar27 < 2) {
                    do {
                      uVar4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0x1ca0);
                      if ((int)uVar4 < 0) {
                        if (10 < uVar30) {
                          uVar5 = 10;
                          do {
                            uVar4 = (uint)*(short *)((int)param_1 +
                                                    ((local_e8 >> (uVar5 & 0xff) & 1) + ~uVar4) * 2
                                                    + 0x24a0);
                            if (uVar4 != 0xffffffff && (int)(uVar4 + 1) < 0 == SCARRY4(uVar4,1))
                            goto LAB_00109384;
                            uVar25 = uVar5 + 2;
                            uVar5 = uVar5 + 1;
                          } while (uVar25 <= uVar30);
                        }
                      }
                      else if (((int)uVar4 >> 9) - 1U < uVar30) break;
switchD_001082a8_caseD_10:
                      if (puVar18 <= puVar27) {
                        uVar4 = 0x10;
                        goto LAB_001088ec;
                      }
                      puVar28 = (ushort *)((int)puVar27 + 1);
                      local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
                      uVar30 = uVar30 + 8;
                      puVar27 = puVar28;
                    } while (uVar30 < 0xf);
                  }
                  else {
                    bVar2 = *(byte *)puVar27;
                    pbVar32 = (byte *)((int)puVar27 + 1);
                    puVar27 = puVar27 + 1;
                    uVar4 = uVar30 & 0xff;
                    uVar5 = uVar30 + 8;
                    uVar30 = uVar30 + 0x10;
                    local_e8 = local_e8 | (uint)bVar2 << uVar4 | (uint)*pbVar32 << (uVar5 & 0xff);
                  }
                }
LAB_00109384:
                local_b8 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0x1ca0);
                if ((int)local_b8 < 0) {
                  uVar4 = 10;
                  do {
                    uVar5 = uVar4 & 0xff;
                    uVar4 = uVar4 + 1;
                    local_b8 = (uint)*(short *)((int)param_1 +
                                               ((local_e8 >> uVar5 & 1) + ~local_b8) * 2 + 0x24a0);
                  } while ((int)local_b8 < 0);
                }
                else {
                  uVar4 = (int)local_b8 >> 9;
                  local_b8 = local_b8 & 0x1ff;
                }
                uVar30 = uVar30 - uVar4;
                local_e8 = local_e8 >> (uVar4 & 0xff);
                if (local_b8 < 0x10) {
                  uVar5 = local_b4 + 1;
                  *(char *)((int)param_1 + local_b4 + 0x2924) = (char)local_b8;
                }
                else {
                  if (local_b4 == 0 && local_b8 == 0x10) {
                    local_b8 = 0x10;
                    local_b4 = 0;
                    goto switchD_001082a8_caseD_11;
                  }
                  iVar33 = local_b8 - 0x10;
                  local_c4 = (uint)*(byte *)(DAT_00109c8c + 0x10943c + iVar33);
                  if (uVar30 < local_c4) {
LAB_00109458:
                    do {
                      if (puVar18 <= puVar27) {
                        uVar4 = 0x12;
                        goto LAB_001088ec;
                      }
                      puVar28 = (ushort *)((int)puVar27 + 1);
                      local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
                      uVar30 = uVar30 + 8;
                      puVar27 = puVar28;
                    } while (uVar30 < local_c4);
                    iVar33 = local_b8 - 0x10;
                  }
                  uVar17 = 0;
                  uVar30 = uVar30 - local_c4;
                  uVar4 = local_e8 & ~(-1 << (local_c4 & 0xff));
                  local_e8 = local_e8 >> (local_c4 & 0xff);
                  iVar33 = uVar4 + *(byte *)(DAT_00109c90 + 0x10948c + iVar33);
                  if (local_b8 == 0x10) {
                    uVar17 = *(undefined *)((int)param_1 + local_b4 + 0x2923);
                  }
                  __aeabi_memset((int)param_1 + local_b4 + 0x2924,iVar33,uVar17);
                  uVar5 = iVar33 + local_b4;
                }
              }
              if (uVar4 != uVar5) goto switchD_001082a8_caseD_15;
              __aeabi_memcpy4(param_1 + 0x10,param_1 + 0xa49,uVar31);
              __aeabi_memcpy(param_1 + 0x378,(int)(param_1 + 0xa49) + uVar31,uVar25);
            }
            uVar5 = param_1[6] - 1;
            param_1[6] = uVar5;
            pbVar32 = local_bc;
          }
LAB_00109510:
          for (; (local_bc = pbVar32, 3 < (int)puVar18 - (int)puVar27 &&
                 (1 < (int)pbVar19 - (int)pbVar32)); pbVar32 = pbVar32 + 2) {
            if (uVar30 < 0xf) {
              uVar3 = *puVar27;
              puVar27 = puVar27 + 1;
              local_e8 = local_e8 | (uint)uVar3 << (uVar30 & 0xff);
              uVar30 = uVar30 + 0x10;
            }
            local_b4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0x160);
            if ((int)local_b4 < 0) {
              uVar4 = 10;
              do {
                uVar5 = uVar4 & 0xff;
                uVar4 = uVar4 + 1;
                local_b4 = (uint)*(short *)((int)param_1 +
                                           ((local_e8 >> uVar5 & 1) + ~local_b4) * 2 + 0x960);
              } while ((int)local_b4 < 0);
            }
            else {
              uVar4 = (int)local_b4 >> 9;
            }
            uVar30 = uVar30 - uVar4;
            local_e8 = local_e8 >> (uVar4 & 0xff);
            if ((local_b4 & 0x100) != 0) goto LAB_001097bc;
            if (uVar30 < 0xf) {
              uVar3 = *puVar27;
              puVar27 = puVar27 + 1;
              local_e8 = local_e8 | (uint)uVar3 << (uVar30 & 0xff);
              uVar30 = uVar30 + 0x10;
            }
            uVar4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0x160);
            if ((int)uVar4 < 0) {
              uVar5 = 10;
              do {
                uVar25 = uVar5 & 0xff;
                uVar5 = uVar5 + 1;
                uVar4 = (uint)*(short *)((int)param_1 +
                                        ((local_e8 >> uVar25 & 1) + ~uVar4) * 2 + 0x960);
              } while ((int)uVar4 < 0);
            }
            else {
              uVar5 = (int)uVar4 >> 9;
            }
            uVar30 = uVar30 - uVar5;
            local_e8 = local_e8 >> (uVar5 & 0xff);
            *pbVar32 = (byte)local_b4;
            if ((uVar4 & 0x100) != 0) {
              local_bc = pbVar32 + 1;
              local_b4 = uVar4;
              goto LAB_001097bc;
            }
            pbVar32[1] = (byte)uVar4;
          }
          if (uVar30 < 0xf) {
            if ((int)puVar18 - (int)puVar27 < 2) {
              do {
                uVar4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0x160);
                if ((int)uVar4 < 0) {
                  if (10 < uVar30) {
                    uVar5 = 10;
                    do {
                      uVar4 = (uint)*(short *)((int)param_1 +
                                              ((local_e8 >> (uVar5 & 0xff) & 1) + ~uVar4) * 2 +
                                              0x960);
                      if (uVar4 != 0xffffffff && (int)(uVar4 + 1) < 0 == SCARRY4(uVar4,1))
                      goto LAB_00109744;
                      uVar25 = uVar5 + 2;
                      uVar5 = uVar5 + 1;
                    } while (uVar25 <= uVar30);
                  }
                }
                else if (((int)uVar4 >> 9) - 1U < uVar30) break;
switchD_001082a8_caseD_17:
                if (puVar18 <= puVar27) {
                  uVar4 = 0x17;
                  goto LAB_001088ec;
                }
                puVar28 = (ushort *)((int)puVar27 + 1);
                local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
                uVar30 = uVar30 + 8;
                puVar27 = puVar28;
              } while (uVar30 < 0xf);
            }
            else {
              uVar5 = uVar30 + 8;
              uVar4 = uVar30 & 0xff;
              uVar30 = uVar30 + 0x10;
              local_e8 = local_e8 | (uint)*(byte *)puVar27 << uVar4 |
                         (uint)*(byte *)((int)puVar27 + 1) << (uVar5 & 0xff);
              puVar27 = puVar27 + 1;
            }
          }
LAB_00109744:
          local_b4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0x160);
          if ((int)local_b4 < 0) {
            uVar4 = 10;
            do {
              uVar5 = uVar4 & 0xff;
              uVar4 = uVar4 + 1;
              local_b4 = (uint)*(short *)((int)param_1 +
                                         ((local_e8 >> uVar5 & 1) + ~local_b4) * 2 + 0x960);
            } while ((int)local_b4 < 0);
          }
          else {
            uVar4 = (int)local_b4 >> 9;
            local_b4 = local_b4 & 0x1ff;
          }
          uVar30 = uVar30 - uVar4;
          local_e8 = local_e8 >> (uVar4 & 0xff);
          if (local_b4 < 0x100) {
switchD_001082a8_caseD_18:
            if (pbVar19 <= local_bc) {
              iVar20 = 2;
              uVar5 = 0x18;
              goto switchD_001082a8_caseD_24;
            }
            pbVar32 = local_bc + 1;
            *local_bc = (byte)local_b4;
            goto LAB_00109510;
          }
LAB_001097bc:
          uVar4 = 0x100;
          uVar25 = local_b4 & 0x1ff;
          uVar5 = uVar30;
          if (uVar25 != 0x100) {
            iVar33 = uVar25 * 4 + -0x404;
            local_c4 = 0;
            local_b4 = *(uint *)(DAT_00109c94 + 0x10981c + iVar33);
            if (uVar25 - 0x109 < 0x14) {
              local_c4 = *(uint *)(DAT_00109c98 + 0x109840 + iVar33);
              puVar28 = puVar27;
              if (uVar30 < local_c4) {
LAB_0010985c:
                do {
                  if (puVar18 <= puVar27) {
                    uVar4 = 0x19;
                    goto LAB_001088ec;
                  }
                  puVar28 = (ushort *)((int)puVar27 + 1);
                  local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
                  uVar30 = uVar30 + 8;
                  puVar27 = puVar28;
                } while (uVar30 < local_c4);
              }
              uVar30 = uVar30 - local_c4;
              uVar4 = local_e8 & ~(-1 << (local_c4 & 0xff));
              local_e8 = local_e8 >> (local_c4 & 0xff);
              local_b4 = uVar4 + local_b4;
              puVar27 = puVar28;
            }
            if (uVar30 < 0xf) {
              if ((int)puVar18 - (int)puVar27 < 2) {
                do {
                  uVar4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0xf00);
                  if ((int)uVar4 < 0) {
                    if (10 < uVar30) {
                      uVar5 = 10;
                      do {
                        uVar4 = (uint)*(short *)((int)param_1 +
                                                ((local_e8 >> (uVar5 & 0xff) & 1) + ~uVar4) * 2 +
                                                0x1700);
                        if (uVar4 != 0xffffffff && (int)(uVar4 + 1) < 0 == SCARRY4(uVar4,1))
                        goto LAB_001099c4;
                        uVar25 = uVar5 + 2;
                        uVar5 = uVar5 + 1;
                      } while (uVar25 <= uVar30);
                    }
                  }
                  else if (((int)uVar4 >> 9) - 1U < uVar30) break;
switchD_001082a8_caseD_1a:
                  if (puVar18 <= puVar27) {
                    uVar4 = 0x1a;
                    goto LAB_001088ec;
                  }
                  puVar28 = (ushort *)((int)puVar27 + 1);
                  local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
                  uVar30 = uVar30 + 8;
                  puVar27 = puVar28;
                } while (uVar30 < 0xf);
              }
              else {
                bVar2 = *(byte *)puVar27;
                uVar5 = uVar30 + 8;
                pbVar32 = (byte *)((int)puVar27 + 1);
                puVar27 = puVar27 + 1;
                uVar4 = uVar30 & 0xff;
                uVar30 = uVar30 + 0x10;
                local_e8 = local_e8 | (uint)bVar2 << uVar4 | (uint)*pbVar32 << (uVar5 & 0xff);
              }
            }
LAB_001099c4:
            uVar4 = (uint)*(short *)((int)param_1 + (local_e8 & 0x3ff) * 2 + 0xf00);
            if ((int)uVar4 < 0) {
              uVar5 = 10;
              do {
                uVar25 = uVar5 & 0xff;
                uVar5 = uVar5 + 1;
                uVar4 = (uint)*(short *)((int)param_1 +
                                        ((local_e8 >> uVar25 & 1) + ~uVar4) * 2 + 0x1700);
              } while ((int)uVar4 < 0);
            }
            else {
              uVar5 = (int)uVar4 >> 9;
              uVar4 = uVar4 & 0x1ff;
            }
            uVar30 = uVar30 - uVar5;
            local_e8 = local_e8 >> (uVar5 & 0xff);
            local_c4 = 0;
            local_b8 = *(uint *)(DAT_00109c9c + 0x109a44 + uVar4 * 4);
            if (uVar4 - 4 < 0x1a) {
              local_c4 = *(uint *)(DAT_00109ca0 + 0x109a64 + uVar4 * 4);
              puVar28 = puVar27;
              if (uVar30 < local_c4) {
LAB_00109a78:
                do {
                  if (puVar18 <= puVar28) {
                    uVar4 = 0x1b;
                    puVar27 = puVar28;
                    goto LAB_001088ec;
                  }
                  puVar27 = (ushort *)((int)puVar28 + 1);
                  local_e8 = local_e8 | (uint)*(byte *)puVar28 << (uVar30 & 0xff);
                  uVar30 = uVar30 + 8;
                  puVar28 = puVar27;
                } while (uVar30 < local_c4);
              }
              uVar30 = uVar30 - local_c4;
              uVar4 = local_e8 & ~(-1 << (local_c4 & 0xff));
              local_e8 = local_e8 >> (local_c4 & 0xff);
              local_b8 = local_b8 + uVar4;
            }
            local_d0 = (int)local_bc - (int)param_4;
            if (local_b8 == 0) {
              if (uVar22 != 0) {
                local_b8 = 0;
                goto switchD_001082a8_caseD_25;
              }
            }
            else {
              uVar4 = local_d0;
              if (local_d0 != 0) {
                uVar4 = 1;
              }
              if (((uVar4 & local_b8 <= local_d0) == 0) && (uVar22 != 0))
              goto switchD_001082a8_caseD_25;
            }
            pbVar14 = param_4 + (local_d0 - local_b8 & (uint)pbVar24);
            pbVar16 = pbVar14;
            if (pbVar14 < local_bc) {
              pbVar16 = local_bc;
            }
            pbVar32 = local_bc;
            if (pbVar19 < pbVar16 + local_b4) {
              while (local_b4 != 0) {
                local_b4 = local_b4 - 1;
                local_bc = pbVar32;
switchD_001082a8_caseD_35:
                if (pbVar19 <= local_bc) {
                  iVar20 = 2;
                  uVar5 = 0x35;
                  goto switchD_001082a8_caseD_24;
                }
                uVar4 = local_d0 - local_b8;
                local_d0 = local_d0 + 1;
                *local_bc = param_4[uVar4 & (uint)pbVar24];
                pbVar32 = local_bc + 1;
              }
              local_b4 = 0xffffffff;
            }
            else {
              for (; 2 < local_b4; local_b4 = local_b4 - 3) {
                *pbVar32 = *pbVar14;
                pbVar32[1] = pbVar14[1];
                pbVar16 = pbVar14 + 2;
                pbVar14 = pbVar14 + 3;
                pbVar32[2] = *pbVar16;
                pbVar32 = pbVar32 + 3;
              }
              if (local_b4 != 0) {
                *pbVar32 = *pbVar14;
                if (local_b4 != 1) {
                  pbVar32[1] = pbVar14[1];
                }
                pbVar32 = pbVar32 + local_b4;
              }
            }
            goto LAB_00109510;
          }
        }
        uVar30 = uVar5;
      } while ((*(byte *)(param_1 + 5) & 1) == 0);
LAB_001084d4:
      uVar22 = uVar5 & 7;
      uVar30 = uVar5 - uVar22;
      if ((param_2 < puVar27) && (7 < uVar30)) {
        uVar30 = (uVar5 - uVar22) - 8;
        pbVar24 = (byte *)((int)puVar27 + ~(uint)param_2);
        if ((byte *)(uVar30 >> 3) < pbVar24) {
          pbVar24 = (byte *)(uVar30 >> 3);
        }
        uVar30 = uVar30 + (int)pbVar24 * -8;
        puVar27 = (ushort *)((int)puVar27 + ~(uint)pbVar24);
      }
      uVar5 = -1 << (uVar30 & 0xff);
      local_b4 = 0;
      if (-1 < (int)(uVar30 - 0x20)) {
        uVar5 = 0;
      }
      local_e8 = local_e8 >> uVar22 & ~uVar5;
      if ((param_7 & 1) != 0) {
        for (; uVar4 = local_b4, local_b4 < 4; local_b4 = local_b4 + 1) {
          if (uVar30 == 0) {
            uVar30 = 0;
switchD_001082a8_caseD_2a:
            if (puVar27 < puVar18) {
              uVar4 = (uint)*(byte *)puVar27;
              puVar27 = (ushort *)((int)puVar27 + 1);
              goto LAB_001087d0;
            }
            uVar4 = 0x2a;
LAB_001088ec:
            *param_1 = uVar4;
            goto LAB_001088fc;
          }
          puVar28 = puVar27;
          if (uVar30 < 8) {
LAB_001087a4:
            do {
              if (puVar18 <= puVar27) {
                uVar4 = 0x29;
                goto LAB_001088ec;
              }
              puVar28 = (ushort *)((int)puVar27 + 1);
              local_e8 = local_e8 | (uint)*(byte *)puVar27 << (uVar30 & 0xff);
              bVar34 = 0xfffffff7 < uVar30;
              uVar30 = uVar30 + 8;
              puVar27 = puVar28;
            } while (bVar34);
          }
          uVar4 = local_e8 & 0xff;
          uVar30 = uVar30 - 8;
          local_e8 = local_e8 >> 8;
          puVar27 = puVar28;
LAB_001087d0:
          param_1[4] = uVar4 | param_1[4] << 8;
        }
      }
switchD_001082a8_caseD_22:
      local_b4 = uVar4;
      iVar20 = 0;
      uVar5 = 0x22;
    }
    else {
      iVar20 = -1;
      local_b4 = 1;
      uVar5 = 0x24;
      local_bc = param_5;
    }
    break;
  case 3:
    goto LAB_00108608;
  default:
    goto switchD_001082a8_caseD_4;
  case 5:
    if (0 < iVar33) {
      puVar27 = (ushort *)((int)param_2 + 1);
      local_e8 = local_e8 | (uint)*(byte *)param_2 << (uVar30 & 0xff);
      uVar30 = uVar30 + 8;
      goto LAB_00108670;
    }
    uVar4 = 5;
LAB_001085b0:
    *param_1 = uVar4;
LAB_001085b8:
    local_bc = param_5;
    goto LAB_001088fc;
  case 6:
    goto LAB_00108858;
  case 7:
    goto switchD_001082a8_caseD_7;
  case 9:
    goto switchD_001082a8_caseD_9;
  case 10:
switchD_001082a8_caseD_a:
    local_b4 = uVar4;
    iVar20 = -1;
    uVar5 = 10;
    break;
  case 0xb:
    goto switchD_001082a8_caseD_b;
  case 0xe:
    goto LAB_00108d20;
  case 0x10:
    goto switchD_001082a8_caseD_10;
  case 0x11:
switchD_001082a8_caseD_11:
    iVar20 = -1;
    uVar5 = 0x11;
    break;
  case 0x12:
    goto LAB_00109458;
  case 0x15:
switchD_001082a8_caseD_15:
    iVar20 = -1;
    uVar5 = 0x15;
    break;
  case 0x17:
    goto switchD_001082a8_caseD_17;
  case 0x18:
    goto switchD_001082a8_caseD_18;
  case 0x19:
    goto LAB_0010985c;
  case 0x1a:
    goto switchD_001082a8_caseD_1a;
  case 0x1b:
    goto LAB_00109a78;
  case 0x20:
    if (iVar33 < 1) {
      uVar4 = 0x20;
      goto LAB_001085b0;
    }
    local_bc = param_5;
    puVar27 = (ushort *)((int)param_2 + 1);
    local_e8 = local_e8 | (uint)*(byte *)param_2 << (uVar30 & 0xff);
    uVar5 = uVar30 + 8;
    goto LAB_001084d4;
  case 0x22:
    goto switchD_001082a8_caseD_22;
  case 0x23:
switchD_001082a8_caseD_23:
    iVar20 = -1;
    uVar5 = 0x23;
    break;
  case 0x24:
    break;
  case 0x25:
switchD_001082a8_caseD_25:
    iVar20 = -1;
    uVar5 = 0x25;
    break;
  case 0x26:
    goto switchD_001082a8_caseD_26;
  case 0x27:
switchD_001082a8_caseD_27:
    iVar20 = -1;
    uVar5 = 0x27;
    break;
  case 0x29:
    goto LAB_001087a4;
  case 0x2a:
    goto switchD_001082a8_caseD_2a;
  case 0x33:
    goto LAB_00108b3c;
  case 0x34:
    goto switchD_001082a8_caseD_34;
  case 0x35:
    goto switchD_001082a8_caseD_35;
  }
switchD_001082a8_caseD_24:
  *param_1 = uVar5;
  if ((param_2 < puVar27) && (7 < uVar30)) {
    uVar30 = uVar30 - 8;
    pbVar24 = (byte *)((int)puVar27 + ~(uint)param_2);
    if ((byte *)(uVar30 >> 3) < pbVar24) {
      pbVar24 = (byte *)(uVar30 >> 3);
    }
    uVar30 = uVar30 + (int)pbVar24 * -8;
    puVar27 = (ushort *)((int)puVar27 + ~(uint)pbVar24);
  }
switchD_001082a8_caseD_4:
  param_1[1] = uVar30;
  param_1[8] = local_b8;
  param_1[9] = local_b4;
  param_1[10] = local_c4;
  uVar4 = -1 << (uVar30 & 0xff);
  if (-1 < (int)(uVar30 - 0x20)) {
    uVar4 = 0;
  }
  param_1[0xe] = local_e8 & ~uVar4;
  param_1[0xf] = local_d0;
  *param_3 = (int)puVar27 - (int)param_2;
  uVar4 = (int)local_bc - (int)param_5;
  *param_6 = uVar4;
  if (((param_7 & 9) != 0) && (-1 < iVar20)) {
    uVar22 = param_1[7] >> 0x10;
    uVar30 = param_1[7] & 0xffff;
    if (uVar4 != 0) {
      uVar25 = uVar4 % 0x15b0;
      uVar5 = 0;
      if (uVar25 < 8) goto LAB_00108a98;
      do {
        uVar31 = uVar25 - 8 & 0xfffffff8;
        iVar33 = 0;
        do {
          pbVar24 = param_5 + iVar33;
          iVar21 = uVar30 + *pbVar24;
          iVar29 = iVar21 + (uint)pbVar24[1];
          iVar15 = iVar29 + (uint)pbVar24[2];
          iVar6 = iVar15 + (uint)pbVar24[3];
          iVar7 = iVar6 + (uint)pbVar24[4];
          iVar8 = iVar7 + (uint)pbVar24[5];
          iVar9 = iVar8 + (uint)pbVar24[6];
          uVar30 = iVar9 + (uint)pbVar24[7];
          uVar5 = iVar33 + 0xf;
          uVar22 = iVar21 + uVar22 + iVar29 + iVar15 + iVar6 + iVar7 + iVar8 + iVar9 + uVar30;
          iVar33 = iVar33 + 8;
        } while (uVar5 < uVar25);
        uVar5 = uVar31 + 8;
        param_5 = param_5 + uVar31 + 8;
LAB_00108a98:
        if (uVar5 < uVar25) {
          iVar33 = uVar25 - uVar5;
          pbVar24 = param_5;
          do {
            iVar33 = iVar33 + -1;
            uVar30 = uVar30 + *pbVar24;
            uVar22 = uVar30 + uVar22;
            pbVar24 = pbVar24 + 1;
          } while (iVar33 != 0);
          param_5 = param_5 + (uVar25 - uVar5);
        }
        uVar4 = uVar4 - uVar25;
        uVar25 = 0x15b0;
        uVar22 = uVar22 % 0xfff1;
        uVar30 = uVar30 % 0xfff1;
      } while (uVar4 != 0);
    }
    uVar30 = uVar30 | uVar22 << 0x10;
    param_1[7] = uVar30;
    if ((iVar20 == 0) && (iVar20 = 0, (param_7 & 1) != 0)) {
      iVar33 = uVar30 - param_1[4];
      if (iVar33 != 0) {
        iVar33 = -2;
      }
      return iVar33;
    }
  }
  return iVar20;
}

