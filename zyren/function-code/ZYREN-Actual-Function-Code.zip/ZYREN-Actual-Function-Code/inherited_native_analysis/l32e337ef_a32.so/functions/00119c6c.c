/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00119c6c FUN_00119c6c */

size_t FUN_00119c6c(size_t *param_1,void **param_2,size_t *param_3)

{
  FILE *__stream;
  int __fd;
  void *pvVar1;
  size_t __size;
  
  if (param_1 != (size_t *)0x0) {
    FUN_001164ac();
    __size = *param_1;
    if ((((param_1[0xf] != DAT_00119d1c + 0x119ca0U) || (*(int *)(param_1[0x12] + 0x48) == 0)) &&
        (param_1[5] == 3)) && (__stream = *(FILE **)(param_1[0x12] + 0x3c), __stream != (FILE *)0x0)
       ) {
      __fd = fileno(__stream);
      ftruncate(__fd,__size);
      __size = *param_1;
    }
    if (param_3 != (size_t *)0x0) {
      *param_3 = __size;
    }
    pvVar1 = calloc(1,__size);
    *param_2 = pvVar1;
    __aeabi_memcpy(pvVar1,*(undefined4 *)(param_1[0x12] + 0x48),__size);
    return __size;
  }
  return 0xffffffff;
}

