/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010cac4 FUN_0010cac4 */

undefined4
FUN_0010cac4(uint *param_1,char *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint param_7,uint param_8)

{
  uint uVar1;
  char *pcVar2;
  char **__ptr;
  char *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  code *pcVar7;
  char *unaff_r5;
  bool bVar8;
  
  if (param_1 != (uint *)0x0) {
    unaff_r5 = param_2;
  }
  if (param_1 != (uint *)0x0 && param_2 != (char *)0x0) {
    if (param_8 != (param_7 == 0) || param_8 - (param_7 == 0) < (uint)(0x14 < param_7 - 1)) {
      pcVar2 = (char *)FUN_001201d4(unaff_r5,0);
      if ((int)pcVar2 < 0) {
LAB_0010cbc4:
        param_1[7] = 0x11;
        return 0;
      }
      __ptr = (char **)malloc(0xc);
      pcVar3 = strdup(unaff_r5);
      *__ptr = pcVar3;
      __ptr[1] = (char *)0x0;
      __ptr[2] = pcVar2;
      if (__ptr == (char **)0x0) goto LAB_0010cbc4;
      if ((param_7 | param_8) != 0) goto LAB_0010cb80;
      if (pcVar2 != (char *)0x0) {
        iVar5 = FUN_00120364(pcVar2,0,2);
        pcVar2 = __ptr[2];
        if (iVar5 != -1) {
          if (pcVar2 == (char *)0x0) {
            param_7 = 0xffffffff;
            param_8 = 0xffffffff;
LAB_0010cb80:
            uVar1 = param_1[0x12];
            bVar8 = uVar1 == 0;
            if (bVar8) {
              uVar1 = param_1[5];
            }
            if (bVar8 && uVar1 == 0) {
              pcVar7 = (code *)param_1[10];
              if (pcVar7 == (code *)0x0) {
                pcVar7 = (code *)(DAT_0010cdb4 + 0x10cc94);
                param_1[10] = (uint)pcVar7;
              }
              if (param_1[0xb] == 0) {
                param_1[0xb] = DAT_0010cdb8 + 0x10cca8;
              }
              if (param_1[0xc] == 0) {
                param_1[0xc] = DAT_0010cdbc + 0x10ccbc;
              }
              param_1[7] = 0;
              *param_1 = 0;
              param_1[1] = 0;
              param_1[2] = 0;
              param_1[3] = 0;
              param_1[4] = 0;
              uVar1 = (*pcVar7)(param_1[0xd],1,0x58);
              param_1[0x12] = uVar1;
              if (uVar1 != 0) {
                __aeabi_memclr8(uVar1,0x58);
                uVar1 = param_1[0x12];
                uVar6 = DAT_0010cdc0 + 0x10cd04;
                *(undefined4 *)(uVar1 + 0x38) = 0;
                *(undefined4 *)(uVar1 + 0x34) = 0;
                *(undefined4 *)(uVar1 + 0x30) = param_3;
                *(undefined4 *)(uVar1 + 0x2c) = 4;
                *(undefined4 *)(uVar1 + 0x1c) = 4;
                *(undefined4 *)(uVar1 + 0xc) = 1;
                param_1[0xe] = uVar6;
                param_1[5] = 1;
                param_1[6] = 4;
                param_1[0x11] = (uint)param_1;
                *(char ***)(uVar1 + 0x3c) = __ptr;
                *param_1 = param_7;
                param_1[1] = param_8;
                *(undefined4 *)(uVar1 + 0x44) = param_6;
                *(undefined4 *)(uVar1 + 0x40) = param_5;
                iVar5 = FUN_0010bbd0(param_1,param_3);
                if (iVar5 == 0) {
                  FUN_0010b938(param_1,0);
                  return 0;
                }
                return 1;
              }
              uVar1 = 0x10;
            }
            else {
              uVar1 = 0x18;
            }
            param_1[7] = uVar1;
            if (__ptr[2] != (char *)0x0) {
              FUN_00120238();
              free(__ptr);
              return 0;
            }
            return 0;
          }
          uVar4 = FUN_00120364(pcVar2,0,1);
          param_7 = FUN_00120364(__ptr[2],0,2);
          FUN_00120364(__ptr[2],uVar4,0);
          if (0x15 < param_7) {
            param_8 = (int)param_7 >> 0x1f;
            goto LAB_0010cb80;
          }
          if (__ptr[2] != (char *)0x0) {
            FUN_00120238();
            free(__ptr);
          }
          uVar1 = 8;
          goto LAB_0010cb1c;
        }
        if (pcVar2 != (char *)0x0) {
          FUN_00120238();
          free(__ptr);
        }
      }
      uVar1 = 0x16;
      goto LAB_0010cb1c;
    }
  }
  else if (param_1 == (uint *)0x0) {
    return 0;
  }
  uVar1 = 0x18;
LAB_0010cb1c:
  param_1[7] = uVar1;
  return 0;
}

