/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00292844 ceilf */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float ceilf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_ceilf_00307e40)();
  return fVar1;
}

