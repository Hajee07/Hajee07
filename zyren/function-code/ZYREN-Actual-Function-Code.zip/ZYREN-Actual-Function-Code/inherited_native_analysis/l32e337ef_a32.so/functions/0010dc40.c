/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010dc40 FUN_0010dc40 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

bool FUN_0010dc40(uint *param_1,uint param_2,byte *param_3,uint param_4,uint param_5,uint param_6,
                 uint param_7,int param_8)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  undefined4 uVar10;
  uint uVar11;
  byte *pbVar12;
  uint uVar13;
  bool bVar14;
  int local_2fb8;
  uint local_2fb4;
  uint local_2fb0;
  uint local_2fac;
  uint local_2fa8;
  uint local_2f9c;
  uint local_2f98;
  uint local_2f94;
  uint local_2f90;
  uint local_2f8c;
  undefined4 local_2f88 [2748];
  int local_498 [6];
  ushort local_47e;
  ushort local_47c;
  undefined auStack_478 [20];
  byte local_464;
  ushort local_462;
  uint local_45c;
  uint local_458;
  uint uStack_454;
  uint local_450;
  uint uStack_44c;
  uint local_440;
  int local_43c;
  int local_434;
  
  if (param_1 == (uint *)0x0) {
    return false;
  }
  piVar5 = (int *)param_1[0x12];
  if ((((piVar5 == (int *)0x0) || ((param_3 == (byte *)0x0 && (param_4 != 0)))) ||
      ((param_6 == 0 && (param_7 != 0)))) || (param_1[0xe] == 0)) {
    uVar6 = 0x18;
    goto LAB_0010dcdc;
  }
  if (param_8 == 0) {
    iVar7 = 0;
    if (param_2 < param_1[4]) {
      iVar7 = *piVar5 + *(int *)(piVar5[4] + param_2 * 4);
    }
    iVar7 = FUN_001107b8(param_1,param_2,iVar7,auStack_478,0);
    uVar6 = local_440;
    local_2fb8 = local_43c;
    if (iVar7 == 0) {
      return false;
    }
  }
  else {
    __aeabi_memcpy8(auStack_478,param_8,0x450);
    uVar6 = local_440;
    local_2fb8 = local_43c;
  }
  if (local_434 != 0) {
    return true;
  }
  if ((local_458 | uStack_454) == 0) {
    return true;
  }
  if ((local_464 & 0x61) != 0) {
    uVar6 = 5;
    goto LAB_0010dcdc;
  }
  param_5 = param_5 & 0x400;
  if ((param_5 == 0) && ((local_462 | 8) != 8)) {
    uVar6 = 4;
    goto LAB_0010dcdc;
  }
  uVar13 = uStack_44c;
  uVar11 = local_450;
  if (param_5 != 0) {
    uVar13 = uStack_454;
    uVar11 = local_458;
  }
  if ((uint)(uVar11 <= param_4) <= -uVar13) {
    uVar6 = 0x1a;
    goto LAB_0010dcdc;
  }
  iVar7 = (*(code *)param_1[0xe])
                    (param_1[0x11],(code *)param_1[0xe],uVar6,local_2fb8,local_498,0x1e);
  if (iVar7 != 0x1e) {
LAB_0010e17c:
    uVar6 = 0x14;
    goto LAB_0010dcdc;
  }
  if (local_498[0] == 0x4034b50) {
    uVar8 = (uint)local_47e + (uint)local_47c + 0x1e;
    local_2fb0 = uVar6 + uVar8;
    local_2fb8 = local_2fb8 + (uint)CARRY4(uVar6,uVar8);
    uVar6 = local_2fb8 + uStack_454 + (uint)CARRY4(local_2fb0,local_458);
    if (uVar6 < param_1[1] || param_1[1] - uVar6 < (uint)(local_2fb0 + local_458 <= *param_1)) {
      if ((param_5 != 0) || (local_462 == 0)) {
        uVar6 = (*(code *)param_1[0xe])
                          (param_1[0x11],(code *)param_1[0xe],local_2fb0,local_2fb8,param_3,uVar11);
        if ((uVar11 ^ uVar6 | uVar13) == 0) {
          if (param_5 != 0) {
            return true;
          }
          uVar6 = 0xffffffff;
          if (3 < local_450) {
            uVar11 = local_450 - 4;
            uVar13 = uVar11 & 0xfffffffc;
            uVar6 = 0xffffffff;
            iVar7 = DAT_0010e3b0 + 0x10e0cc;
            pbVar12 = param_3;
            do {
              bVar4 = *pbVar12;
              pbVar1 = pbVar12 + 1;
              local_450 = local_450 - 4;
              pbVar2 = pbVar12 + 2;
              pbVar3 = pbVar12 + 3;
              pbVar12 = pbVar12 + 4;
              uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)bVar4) * 4) ^ uVar6 >> 8;
              uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar6 >> 8;
              uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar6 >> 8;
              uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar6 >> 8;
            } while (3 < local_450);
            local_450 = uVar11 - uVar13;
            param_3 = param_3 + uVar13 + 4;
          }
          if (local_450 != 0) {
            do {
              local_450 = local_450 - 1;
              uVar6 = *(uint *)(DAT_0010e3b4 + 0x10e14c + (uVar6 & 0xff ^ (uint)*param_3) * 4) ^
                      uVar6 >> 8;
              param_3 = param_3 + 1;
            } while (local_450 != 0);
          }
          if (local_45c == ~uVar6) {
            return true;
          }
          uVar6 = 0xe;
          goto LAB_0010dcdc;
        }
        goto LAB_0010e17c;
      }
      local_2f88[0] = 0;
      local_2f98 = 0;
      if (*(int *)(param_1[0x12] + 0x48) == 0) {
        if (param_6 == 0) {
          local_2f9c = 0;
          local_2fb4 = local_458;
          local_2fac = uStack_454;
          if (uStack_454 != 0 || uStack_454 < (0x1fff < local_458)) {
            local_2fb4 = 0x2000;
            local_2fac = 0;
          }
          local_2fa8 = (*(code *)param_1[10])(param_1[0xd],1);
          if (local_2fa8 == 0) {
            uVar6 = 0x10;
            goto LAB_0010dcdc;
          }
          uVar6 = 0;
          local_2f98 = local_458;
          local_2f94 = uStack_454;
        }
        else {
          if (param_7 == 0) {
            return false;
          }
          uVar6 = 0;
          local_2f9c = 0;
          local_2fb4 = param_7;
          local_2fac = 0;
          local_2fa8 = param_6;
          local_2f98 = local_458;
          local_2f94 = uStack_454;
        }
      }
      else {
        local_2fa8 = *(int *)(param_1[0x12] + 0x48) + local_2fb0;
        local_2f94 = 0;
        uVar6 = uStack_454;
        local_2fb4 = local_458;
        local_2fac = uStack_454;
        local_2f9c = local_458;
      }
      uVar13 = 0;
      uVar11 = 0;
      iVar7 = 0;
      do {
        local_2f90 = local_450 - uVar13;
        if ((local_2f9c | uVar6) == 0) {
          local_2f9c = 0;
          if (*(int *)(param_1[0x12] + 0x48) == 0) {
            bVar14 = (uint)(local_2f98 <= local_2fb4) <= local_2fac - local_2f94;
            local_2f9c = local_2f98;
            if (local_2fac <= local_2f94 && bVar14) {
              local_2f9c = local_2fb4;
            }
            uVar8 = (*(code *)param_1[0xe])
                              (param_1[0x11],(code *)param_1[0xe],local_2fb0,local_2fb8,local_2fa8,
                               local_2f9c);
            uVar6 = local_2f94;
            if (local_2fac <= local_2f94 && bVar14) {
              uVar6 = local_2fac;
            }
            if ((local_2f9c ^ uVar8 | uVar6) != 0) {
              uVar6 = 0xb;
              goto LAB_0010e35c;
            }
            bVar14 = local_2f98 < local_2f9c;
            local_2f98 = local_2f98 - local_2f9c;
            local_2f94 = local_2f94 - (uVar6 + bVar14);
            bVar14 = CARRY4(local_2f9c,local_2fb0);
            local_2fb0 = local_2f9c + local_2fb0;
            local_2fb8 = uVar6 + local_2fb8 + (uint)bVar14;
            iVar7 = 0;
          }
          else {
            uVar6 = 0;
          }
        }
        uVar10 = 6;
        if ((local_2f98 | local_2f94) == 0) {
          uVar10 = 4;
        }
        local_2f8c = local_2f9c;
        iVar9 = FUN_001081f0(local_2f88,local_2fa8 + iVar7,&local_2f8c,param_3,param_3 + uVar13,
                             &local_2f90,uVar10);
        bVar14 = CARRY4(uVar13,local_2f90);
        uVar13 = uVar13 + local_2f90;
        uVar11 = uVar11 + bVar14;
        iVar7 = iVar7 + local_2f8c;
        bVar14 = local_2f9c < local_2f8c;
        local_2f9c = local_2f9c - local_2f8c;
        uVar6 = uVar6 - bVar14;
      } while (iVar9 == 1);
      if (iVar9 != 0) {
        uVar6 = *(uint *)(param_1[0x12] + 0x48);
        goto joined_r0x0010e2a0;
      }
      if ((uVar13 ^ local_450 | uVar11 ^ uStack_44c) == 0) {
        uVar6 = 0xffffffff;
        if (3 < uVar13) {
          uVar11 = uVar13 - 4;
          uVar8 = uVar11 & 0xfffffffc;
          uVar6 = 0xffffffff;
          iVar7 = DAT_0010e3b8 + 0x10e1dc;
          pbVar12 = param_3;
          do {
            bVar4 = *pbVar12;
            pbVar1 = pbVar12 + 1;
            uVar13 = uVar13 - 4;
            pbVar2 = pbVar12 + 2;
            pbVar3 = pbVar12 + 3;
            pbVar12 = pbVar12 + 4;
            uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)bVar4) * 4) ^ uVar6 >> 8;
            uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar6 >> 8;
            uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar6 >> 8;
            uVar6 = *(uint *)(iVar7 + (uVar6 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar6 >> 8;
          } while (3 < uVar13);
          uVar13 = uVar11 - uVar8;
          param_3 = param_3 + uVar8 + 4;
        }
        if (uVar13 != 0) {
          do {
            uVar13 = uVar13 - 1;
            uVar6 = *(uint *)(DAT_0010e3bc + 0x10e25c + (uVar6 & 0xff ^ (uint)*param_3) * 4) ^
                    uVar6 >> 8;
            param_3 = param_3 + 1;
          } while (uVar13 != 0);
        }
        iVar9 = 0;
        if (local_45c != ~uVar6) {
          uVar6 = 0xe;
          goto LAB_0010e35c;
        }
      }
      else {
        uVar6 = 0xd;
LAB_0010e35c:
        param_1[7] = uVar6;
        iVar9 = -1;
      }
      uVar6 = *(uint *)(param_1[0x12] + 0x48);
joined_r0x0010e2a0:
      if ((param_6 | uVar6) == 0) {
        (*(code *)param_1[0xb])(param_1[0xd],local_2fa8);
      }
      return iVar9 == 0;
    }
  }
  uVar6 = 9;
LAB_0010dcdc:
  param_1[7] = uVar6;
  return false;
}

