/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001184dc FUN_001184dc */

uint FUN_001184dc(int param_1,int *param_2,uint *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_478 [40];
  uint local_450;
  uint local_44c;
  
  if (param_1 == 0) {
    uVar5 = 0xffffffff;
  }
  else {
    uVar5 = 0xfffffffd;
    if ((*(int *)(param_1 + 0x14) == 1) && (uVar6 = *(uint *)(param_1 + 0x58), -1 < (int)uVar6)) {
      piVar1 = *(int **)(param_1 + 0x48);
      if (piVar1 == (int *)0x0) {
        iVar4 = 0;
        *(undefined4 *)(param_1 + 0x1c) = 0x18;
      }
      else {
        if ((uVar6 < *(uint *)(param_1 + 0x10)) &&
           (iVar4 = *piVar1 + *(int *)(piVar1[4] + uVar6 * 4), iVar4 != 0)) {
          if ((*(ushort *)(iVar4 + 0x1c) != 0) &&
             (*(char *)(iVar4 + (uint)*(ushort *)(iVar4 + 0x1c) + 0x2d) == '/')) {
            return 0xffffffef;
          }
          if ((*(byte *)(iVar4 + 0x26) & 0x10) != 0) {
            return 0xffffffef;
          }
        }
        else {
          *(undefined4 *)(param_1 + 0x1c) = 0x18;
        }
        iVar4 = 0;
        if (uVar6 < *(uint *)(param_1 + 0x10)) {
          iVar4 = *piVar1 + *(int *)(piVar1[4] + uVar6 * 4);
        }
      }
      iVar4 = FUN_001107b8(param_1,uVar6,iVar4,auStack_478,0);
      if (iVar4 != 0) {
        if (local_44c == 0 && (0x7fffffff < local_450) <= local_44c) {
          iVar4 = (**(code **)(param_1 + 0x28))(*(undefined4 *)(param_1 + 0x34),1,local_450);
          if (iVar4 != 0) {
            iVar3 = FUN_0010dc40(param_1,uVar6,iVar4,local_450,0,0,0,auStack_478);
            if (iVar3 != 0) {
              *param_2 = iVar4;
              if (param_3 != (uint *)0x0) {
                *param_3 = local_450;
              }
              return local_450;
            }
            (**(code **)(param_1 + 0x2c))(*(undefined4 *)(param_1 + 0x34),iVar4);
            goto LAB_001186a0;
          }
          uVar2 = 0x10;
        }
        else {
          uVar2 = 0x1b;
        }
        *(undefined4 *)(param_1 + 0x1c) = uVar2;
        *param_2 = 0;
        return 0;
      }
LAB_001186a0:
      *param_2 = 0;
      return 0;
    }
  }
  return uVar5;
}

