/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011f5b4 FUN_0011f5b4 */

void FUN_0011f5b4(undefined *param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  bool bVar5;
  undefined local_29;
  uint local_28;
  uint local_24;
  
  uVar1 = param_2[5];
  uVar3 = param_2[6];
  uVar4 = uVar1 + 8;
  local_28 = uVar3 << 0x18 | (uVar3 >> 8 & 0xff) << 0x10 | (uVar3 >> 0x10 & 0xff) << 8 |
             uVar3 >> 0x18;
  if (0xfffffff7 < uVar1) {
    uVar3 = uVar3 + 1;
  }
  local_29 = 0x80;
  local_24 = uVar1 << 0x18 | (uVar1 >> 8 & 0xff) << 0x10 | (uVar1 >> 0x10 & 0xff) << 8 |
             uVar1 >> 0x18;
  param_2[5] = uVar4;
  if (0xfffffff7 < uVar1) {
    param_2[6] = uVar3;
  }
  param_2[6] = uVar3;
  uVar1 = (uVar1 << 0x17) >> 0x1a;
  bVar5 = uVar1 == 0x3f;
  if (bVar5) {
    *(undefined *)((int)param_2 + 0x5b) = 0x80;
    FUN_0011e070(param_2,param_2 + 7);
    uVar4 = param_2[5];
    uVar1 = 0;
  }
  uVar3 = (uint)bVar5;
  __aeabi_memcpy((int)param_2 + uVar1 + 0x1c,&local_29 + uVar3,uVar3 ^ 1);
  if ((uVar4 & 0x1f8) != 0x1c0) {
    uVar1 = uVar4;
    do {
      local_29 = 0;
      iVar2 = param_2[6];
      uVar4 = uVar1 + 8;
      param_2[5] = uVar4;
      if (0xfffffff7 < uVar1) {
        iVar2 = iVar2 + 1;
        param_2[6] = iVar2;
      }
      param_2[6] = iVar2;
      uVar1 = (uVar1 << 0x17) >> 0x1a;
      bVar5 = uVar1 == 0x3f;
      if (bVar5) {
        *(undefined *)((int)param_2 + 0x5b) = 0;
        FUN_0011e070(param_2,param_2 + 7);
        uVar4 = param_2[5];
        uVar1 = 0;
      }
      uVar3 = (uint)bVar5;
      __aeabi_memcpy((int)param_2 + uVar1 + 0x1c,&local_29 + uVar3,uVar3 ^ 1);
      uVar1 = uVar4;
    } while ((uVar4 & 0x1f8) != 0x1c0);
  }
  iVar2 = param_2[6];
  param_2[5] = uVar4 + 0x40;
  if (0xffffffbf < uVar4) {
    iVar2 = iVar2 + 1;
    param_2[6] = iVar2;
  }
  param_2[6] = iVar2;
  uVar1 = (uVar4 << 0x17) >> 0x1a;
  if (uVar1 < 0x38) {
    iVar2 = 0;
  }
  else {
    iVar2 = 0x40 - uVar1;
    __aeabi_memcpy((int)(param_2 + 7) + uVar1,&local_28,iVar2);
    FUN_0011e070(param_2,param_2 + 7);
    uVar1 = 0;
  }
  __aeabi_memcpy((int)param_2 + uVar1 + 0x1c,(int)&local_28 + iVar2,8 - iVar2);
  *param_1 = *(undefined *)((int)param_2 + 3);
  param_1[1] = (char)*(undefined2 *)((int)param_2 + 2);
  param_1[2] = (char)((uint)*param_2 >> 8);
  param_1[3] = (char)*param_2;
  param_1[4] = *(undefined *)((int)param_2 + 7);
  param_1[5] = (char)*(undefined2 *)((int)param_2 + 6);
  param_1[6] = (char)((uint)param_2[1] >> 8);
  param_1[7] = (char)param_2[1];
  param_1[8] = *(undefined *)((int)param_2 + 0xb);
  param_1[9] = (char)*(undefined2 *)((int)param_2 + 10);
  param_1[10] = (char)((uint)param_2[2] >> 8);
  param_1[0xb] = (char)param_2[2];
  param_1[0xc] = *(undefined *)((int)param_2 + 0xf);
  param_1[0xd] = (char)*(undefined2 *)((int)param_2 + 0xe);
  param_1[0xe] = (char)((uint)param_2[3] >> 8);
  param_1[0xf] = (char)param_2[3];
  param_1[0x10] = *(undefined *)((int)param_2 + 0x13);
  param_1[0x11] = (char)*(undefined2 *)((int)param_2 + 0x12);
  param_1[0x12] = (char)((uint)param_2[4] >> 8);
  param_1[0x13] = (char)param_2[4];
  __aeabi_memclr4(param_2,0x5c);
  return;
}

