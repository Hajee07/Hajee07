/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011f9ec FUN_0011f9ec */

byte * FUN_0011f9ec(byte *param_1,int param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  byte *pbVar6;
  uint uVar7;
  byte *pbVar8;
  int iVar9;
  
  pbVar8 = param_1 + param_2;
  do {
    iVar9 = 1;
    pbVar6 = param_1 + 1;
    uVar4 = (uint)*param_1;
    if ((uVar4 & 0x1f) == 0x1f) {
      iVar9 = -1;
      uVar4 = 0;
      do {
        if (iVar9 == -5) {
          return (byte *)0x0;
        }
        iVar2 = -iVar9;
        iVar9 = iVar9 + -1;
        uVar4 = (uint)param_1[iVar2] | uVar4 << 8;
      } while ((param_1[iVar2] & 0x80) != 0);
      pbVar6 = param_1 + -iVar9;
      iVar9 = -iVar9;
    }
    bVar1 = *pbVar6;
    uVar3 = (uint)bVar1;
    if ((bVar1 & 0x80) != 0) {
      uVar5 = uVar3 & 0x7f;
      if (4 < uVar5) {
        return (byte *)0x0;
      }
      if ((bVar1 & 0x7f) == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = 0;
        uVar7 = uVar5;
        do {
          pbVar6 = pbVar6 + 1;
          uVar7 = uVar7 - 1;
          uVar3 = (uint)*pbVar6 | uVar3 << 8;
        } while (uVar7 != 0);
      }
      iVar9 = iVar9 + uVar5;
    }
    iVar9 = iVar9 + 1;
    if (iVar9 == 0) {
      return (byte *)0x0;
    }
    if (uVar4 == param_3) {
      if (pbVar8 < param_1 + uVar3 + iVar9) {
        param_1 = (byte *)0x0;
      }
      return param_1;
    }
    param_1 = param_1 + iVar9 + uVar3;
  } while (param_1 < pbVar8);
  return (byte *)0x0;
}

