/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a3eec FUN_001a3eec */

void FUN_001a3eec(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
                    /* WARNING: Could not recover jumptable at 0x001a3f88. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_001a3f38 + DAT_001a3f38))(param_1,param_2,param_3,param_4);
  return;
}

