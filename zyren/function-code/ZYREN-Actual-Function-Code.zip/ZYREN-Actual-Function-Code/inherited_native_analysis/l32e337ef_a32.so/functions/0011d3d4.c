/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011d3d4 FUN_0011d3d4 */

void FUN_0011d3d4(void)

{
  int *piVar1;
  int iVar2;
  undefined *__useconds;
  undefined4 local_14;
  
  local_14 = 0;
  piVar1 = *(int **)(DAT_0011d7a0 + 0x11d40c);
  if ((piVar1 != (int *)0x0) &&
     (iVar2 = (**(code **)(*piVar1 + 0x10))(piVar1,&local_14,0), iVar2 == 0)) {
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    usleep(500000);
    thunk_FUN_00226c08(local_14);
    __useconds = &LAB_0007a120;
    do {
      usleep((__useconds_t)__useconds);
      thunk_FUN_00226c08(local_14);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      usleep(100000);
      __useconds = (undefined *)0x186a0;
    } while( true );
  }
  return;
}

