/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031564 FUN_00031564 */

int FUN_00031564(byte *param_1,byte *param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (uint)*param_1;
  if (uVar2 != 0) {
    iVar1 = 0;
    do {
      if (((uVar2 != param_2[iVar1]) || (param_3 <= iVar1)) || (param_2[iVar1] == 0)) {
        param_2 = param_2 + iVar1;
        goto LAB_000315c0;
      }
      uVar2 = (uint)param_1[iVar1 + 1];
      iVar1 = iVar1 + 1;
    } while (uVar2 != 0);
    param_2 = param_2 + iVar1;
  }
  uVar2 = 0;
LAB_000315c0:
  return uVar2 - *param_2;
}

