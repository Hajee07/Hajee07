/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011d968 FUN_0011d968 */

void FUN_0011d968(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *unaff_r4;
  int unaff_r8;
  bool bVar5;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined local_24;
  
  piVar1 = param_1;
  if (param_4 != 0) {
    unaff_r8 = DAT_0011da50 + 0x11d988;
    piVar1 = *(int **)(DAT_0011da50 + 0x11d9d4);
    unaff_r4 = param_1;
  }
  if (param_4 != 0 && piVar1 != (int *)0x0) {
    local_24 = 0;
    local_28 = 0;
    local_2c = 0;
    local_30 = 0;
    thunk_FUN_000f41c4(&local_30,DAT_0011da54 + 0x11d9b0,0xd);
    uVar2 = (**(code **)(*unaff_r4 + 0x7c))(unaff_r4,param_4);
    uVar3 = (**(code **)(*unaff_r4 + 0x84))(unaff_r4,uVar2,&local_30,DAT_0011da58 + 0x11d9fc);
    iVar4 = (**(code **)(*unaff_r4 + 0x94))(unaff_r4,param_4,uVar3,4);
    bVar5 = iVar4 != 0;
    if (bVar5) {
      iVar4 = *(int *)(unaff_r8 + 0x4c);
    }
    if (bVar5 && iVar4 != 0) {
      thunk_FUN_0022edb0(0xdead9030);
    }
    (**(code **)(*unaff_r4 + 0x5c))(unaff_r4,uVar2);
    return;
  }
  return;
}

