/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011caec FUN_0011caec */

undefined4
FUN_0011caec(int param_1,uint param_2,void **param_3,int param_4,int param_5,int *param_6)

{
  bool bVar1;
  uint uVar2;
  void **ppvVar3;
  int iVar4;
  void *pvVar5;
  int iVar6;
  int iVar7;
  void *pvVar8;
  int *unaff_r7;
  int iVar9;
  int iVar10;
  
  if ((param_4 - 1U < 10) && (param_1 != 0)) {
    if (param_3 != (void **)0x0) {
      unaff_r7 = param_6;
    }
    if (param_3 != (void **)0x0 && unaff_r7 != (int *)0x0) {
      __aeabi_memclr4(unaff_r7,0x34);
      if (param_5 == 0) {
        iVar6 = 0;
        pvVar8 = *param_3;
        while( true ) {
          if ((pvVar8 == (void *)0x0) || (uVar2 = FUN_0011c904(pvVar8), uVar2 == 0)) {
            return 0xffffffff;
          }
          if (param_2 < uVar2) {
            unaff_r7[iVar6 + 3] = 0;
          }
          else {
            iVar7 = 0;
            iVar9 = 0;
            do {
              iVar10 = memcmp((void *)(param_1 + iVar9),pvVar8,uVar2);
              iVar9 = iVar9 + 1;
              if (iVar10 == 0) {
                iVar7 = iVar7 + 1;
              }
            } while (uVar2 + iVar9 <= param_2);
            param_6[iVar6 + 3] = iVar7;
            param_6[1] = param_6[1] + iVar7;
            unaff_r7 = param_6;
            if (iVar7 != 0) {
              iVar7 = *param_6;
              param_6[2] = param_6[2] + 1;
              pvVar8 = param_3[iVar6 * 2 + 1];
              *param_6 = iVar7 + (int)pvVar8;
              if (100 < iVar7 + (int)pvVar8) {
                return 0;
              }
            }
          }
          iVar6 = iVar6 + 1;
          if (iVar6 == param_4) break;
          pvVar8 = param_3[iVar6 * 2];
        }
        return 0;
      }
      iVar6 = 0;
      pvVar8 = *param_3;
      do {
        if (pvVar8 == (void *)0x0) {
          return 0xffffffff;
        }
        uVar2 = FUN_0011c904(pvVar8);
        if (uVar2 == 0) {
          return 0xffffffff;
        }
        ppvVar3 = param_3 + iVar6 * 2 + 1;
        pvVar5 = *ppvVar3;
        if ((int)pvVar5 < 1) {
          if (param_2 < uVar2) {
            unaff_r7[iVar6 + 3] = 0;
          }
          else {
            iVar9 = 0;
            iVar7 = 0;
            do {
              iVar10 = memcmp((void *)(param_1 + iVar7),pvVar8,uVar2);
              iVar7 = iVar7 + 1;
              if (iVar10 == 0) {
                iVar9 = iVar9 + 1;
              }
            } while (uVar2 + iVar7 <= param_2);
            param_6[iVar6 + 3] = iVar9;
            param_6[1] = param_6[1] + iVar9;
            unaff_r7 = param_6;
            if (iVar9 != 0) {
              param_6[2] = param_6[2] + 1;
              iVar7 = (int)*ppvVar3 * iVar9 + *param_6;
              *param_6 = iVar7;
              goto joined_r0x0011cd60;
            }
          }
        }
        else {
          if (param_2 < uVar2) {
            unaff_r7[iVar6 + 3] = 0;
            iVar7 = *unaff_r7;
          }
          else {
            iVar9 = 0;
            iVar10 = 0;
            iVar7 = 100 - *unaff_r7;
            do {
              iVar4 = memcmp((void *)(param_1 + iVar10),pvVar8,uVar2);
              if (iVar4 == 0) {
                iVar7 = iVar7 - (int)pvVar5;
                iVar9 = iVar9 + 1;
                if (iVar7 < 0) {
                  bVar1 = true;
                  goto LAB_0011cc6c;
                }
              }
              iVar10 = iVar10 + 1;
            } while (uVar2 + iVar10 <= param_2);
            bVar1 = false;
LAB_0011cc6c:
            if (iVar9 < 0) {
              return 0xffffffff;
            }
            param_6[iVar6 + 3] = iVar9;
            param_6[1] = param_6[1] + iVar9;
            if (iVar9 != 0) {
              param_6[2] = param_6[2] + 1;
              *param_6 = (int)*ppvVar3 * iVar9 + *param_6;
            }
            if (bVar1) {
              return 0;
            }
            iVar7 = *param_6;
            unaff_r7 = param_6;
          }
joined_r0x0011cd60:
          if (100 < iVar7) {
            return 0;
          }
        }
        if (iVar6 + 1 == param_4) {
          return 0;
        }
        iVar6 = iVar6 + 1;
        pvVar8 = param_3[iVar6 * 2];
      } while( true );
    }
  }
  return 0xffffffff;
}

