/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002751ec FUN_002751ec */

void FUN_002751ec(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  byte bVar7;
  byte bVar8;
  
  bVar3 = (byte)param_1;
  bVar4 = (byte)((uint)param_1 >> 8);
  bVar5 = (byte)((uint)param_1 >> 0x10);
  bVar1 = (byte)((uint)param_1 >> 0x18);
  bVar6 = (byte)param_2;
  bVar7 = (byte)((uint)param_2 >> 8);
  bVar8 = (byte)((uint)param_2 >> 0x10);
  bVar2 = (byte)((uint)param_2 >> 0x18);
                    /* WARNING: Could not recover jumptable at 0x00275270. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_0027522c + DAT_0027522c))
            ((uint)(byte)((((((((bVar1 >> 7) << 1 | bVar1 >> 6 & 1) << 1 | bVar1 >> 5 & 1) << 1 |
                             bVar1 >> 4 & 1) << 1 | bVar1 >> 3 & 1) << 1 | bVar1 >> 2 & 1) << 1 |
                          bVar1 >> 1 & 1) << 1 | bVar1 & 1) << 0x18 |
             (uint)(byte)((((((((bVar5 >> 7) << 1 | bVar5 >> 6 & 1) << 1 | bVar5 >> 5 & 1) << 1 |
                             bVar5 >> 4 & 1) << 1 | bVar5 >> 3 & 1) << 1 | bVar5 >> 2 & 1) << 1 |
                          bVar5 >> 1 & 1) << 1 | bVar5 & 1) << 0x10 |
             (uint)(byte)((((((((bVar4 >> 7) << 1 | bVar4 >> 6 & 1) << 1 | bVar4 >> 5 & 1) << 1 |
                             bVar4 >> 4 & 1) << 1 | bVar4 >> 3 & 1) << 1 | bVar4 >> 2 & 1) << 1 |
                          bVar4 >> 1 & 1) << 1 | bVar4 & 1) << 8 |
             (uint)(byte)((((((((bVar3 >> 7) << 1 | bVar3 >> 6 & 1) << 1 | bVar3 >> 5 & 1) << 1 |
                             bVar3 >> 4 & 1) << 1 | bVar3 >> 3 & 1) << 1 | bVar3 >> 2 & 1) << 1 |
                          bVar3 >> 1 & 1) << 1 | bVar3 & 1),
             (uint)(byte)((((((((bVar2 >> 7) << 1 | bVar2 >> 6 & 1) << 1 | bVar2 >> 5 & 1) << 1 |
                             bVar2 >> 4 & 1) << 1 | bVar2 >> 3 & 1) << 1 | bVar2 >> 2 & 1) << 1 |
                          bVar2 >> 1 & 1) << 1 | bVar2 & 1) << 0x18 |
             (uint)(byte)((((((((bVar8 >> 7) << 1 | bVar8 >> 6 & 1) << 1 | bVar8 >> 5 & 1) << 1 |
                             bVar8 >> 4 & 1) << 1 | bVar8 >> 3 & 1) << 1 | bVar8 >> 2 & 1) << 1 |
                          bVar8 >> 1 & 1) << 1 | bVar8 & 1) << 0x10 |
             (uint)(byte)((((((((bVar7 >> 7) << 1 | bVar7 >> 6 & 1) << 1 | bVar7 >> 5 & 1) << 1 |
                             bVar7 >> 4 & 1) << 1 | bVar7 >> 3 & 1) << 1 | bVar7 >> 2 & 1) << 1 |
                          bVar7 >> 1 & 1) << 1 | bVar7 & 1) << 8 |
             (uint)(byte)((((((((bVar6 >> 7) << 1 | bVar6 >> 6 & 1) << 1 | bVar6 >> 5 & 1) << 1 |
                             bVar6 >> 4 & 1) << 1 | bVar6 >> 3 & 1) << 1 | bVar6 >> 2 & 1) << 1 |
                          bVar6 >> 1 & 1) << 1 | bVar6 & 1),param_3,param_4);
  return;
}

