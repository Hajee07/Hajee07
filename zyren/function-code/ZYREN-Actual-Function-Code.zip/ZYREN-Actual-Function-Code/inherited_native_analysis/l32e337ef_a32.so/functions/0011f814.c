/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011f814 FUN_0011f814 */

void FUN_0011f814(undefined4 param_1,undefined *param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  uint local_68;
  int local_64;
  undefined auStack_60 [63];
  undefined local_21;
  
  local_7c = 0x67452301;
  local_78 = 0xefcdab89;
  local_74 = 0x98badcfe;
  local_70 = 0x10325476;
  local_6c = 0xc3d2e1f0;
  local_64 = 0;
  local_68 = 0;
  if (param_3 != 0) {
    param_3 = param_3 + -1;
    local_68 = 0;
    local_64 = 0;
    while( true ) {
      uVar2 = local_68 + 8;
      if (0xfffffff7 < local_68) {
        local_64 = local_64 + 1;
      }
      uVar1 = (local_68 << 0x17) >> 0x1a;
      bVar3 = uVar1 == 0x3f;
      local_68 = uVar2;
      if (bVar3) {
        local_21 = *param_2;
        FUN_0011e070(&local_7c,auStack_60);
        uVar1 = 0;
      }
      uVar2 = (uint)bVar3;
      __aeabi_memcpy(auStack_60 + uVar1,param_2 + uVar2,uVar2 ^ 1);
      if (param_3 == 0) break;
      param_2 = param_2 + 1;
      param_3 = param_3 + -1;
    }
  }
  FUN_0011f5b4(param_1,&local_7c);
  return;
}

