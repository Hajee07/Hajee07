/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110040 FUN_00110040 */

undefined4 FUN_00110040(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined auStack_470 [68];
  int local_42c;
  int local_424;
  
  iVar3 = 0;
  if (param_1 != 0) {
    piVar1 = *(int **)(param_1 + 0x48);
    iVar3 = 0;
    if ((piVar1 != (int *)0x0) && (iVar3 = 0, param_2 < *(uint *)(param_1 + 0x10))) {
      iVar3 = *piVar1 + *(int *)(piVar1[4] + param_2 * 4);
    }
  }
  iVar3 = FUN_001107b8(param_1,param_2,iVar3,auStack_470,0);
  if (iVar3 != 0) {
    if ((local_42c == 0) && (local_424 != 0)) {
      uVar2 = FUN_0010e71c(param_1,param_2,DAT_00110118 + 0x110104,param_3,param_4);
      return uVar2;
    }
    if (param_1 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 6;
    }
  }
  return 0;
}

