/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00113dc8 FUN_00113dc8 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4
FUN_00113dc8(uint *param_1,char *param_2,code *param_3,undefined4 param_4,uint param_5,uint param_6,
            uint *param_7,int param_8,uint param_9,uint param_10,undefined4 param_11,
            undefined4 param_12,uint param_13,undefined4 param_14,uint param_15)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  undefined uVar4;
  undefined2 uVar9;
  undefined uVar10;
  short sVar11;
  size_t sVar12;
  tm *ptVar13;
  size_t sVar14;
  byte *pbVar15;
  int *piVar16;
  int iVar17;
  byte bVar18;
  uint uVar19;
  uint uVar20;
  uint *puVar21;
  undefined *puVar22;
  uint *puVar23;
  undefined uVar24;
  uint uVar25;
  int iVar26;
  uint uVar27;
  uint uVar28;
  uint *puVar29;
  byte *pbVar30;
  uint *puVar31;
  uint uVar32;
  uint uVar33;
  uint uVar34;
  uint uVar35;
  undefined2 uVar36;
  char *unaff_r7;
  uint uVar37;
  uint uVar38;
  uint uVar39;
  bool bVar40;
  uint local_10b0;
  uint local_10a4;
  uint local_1094;
  uint local_1090;
  uint local_108c;
  uint local_1088;
  int local_1084;
  uint *local_1080;
  undefined local_107c;
  undefined local_107b;
  undefined local_107a;
  undefined local_1079;
  uint local_1078;
  undefined4 local_1074;
  uint local_1070;
  undefined4 local_106c;
  undefined4 local_1068;
  undefined4 local_1064;
  undefined4 local_1060;
  undefined local_105c;
  undefined uStack_105b;
  undefined uStack_105a;
  undefined uStack_1059;
  undefined local_1058;
  undefined uStack_1057;
  undefined uStack_1056;
  undefined uStack_1055;
  undefined local_1054;
  undefined uStack_1053;
  undefined uStack_1052;
  undefined uStack_1051;
  undefined local_1050;
  undefined uStack_104f;
  undefined uStack_104e;
  undefined uStack_104d;
  short local_104c;
  uint local_1048;
  uint local_1044;
  uint local_1040;
  uint local_103c;
  uint local_1038;
  uint local_1034;
  uint local_1030;
  undefined local_102c;
  undefined local_102b;
  undefined local_102a;
  undefined local_1029;
  undefined local_1028;
  undefined local_1027;
  undefined local_1026;
  undefined local_1025;
  undefined auStack_1024 [4088];
  uint local_2c [2];
  undefined uVar5;
  undefined uVar6;
  undefined uVar7;
  undefined uVar8;
  
  local_103c = 0;
  uVar32 = ~(param_10 >> 0xe) & 8;
  local_1040 = 0;
  if ((param_10 & 0x10000) == 0) {
    uVar32 = uVar32 | 0x800;
  }
  if ((int)param_10 < 0) {
    param_10 = 6;
  }
  local_1044 = 0;
  local_1048 = 0;
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  uVar33 = param_1[0x12];
  if (uVar33 != 0) {
    unaff_r7 = param_2;
  }
  if ((uVar33 == 0 || param_2 == (char *)0x0) || (param_1[5] != 2)) {
LAB_00113e28:
    param_1[7] = 0x18;
    return 0;
  }
  uVar19 = param_9;
  if (param_9 != 0) {
    uVar19 = 1;
  }
  if (((param_8 == 0 & uVar19) != 0) || (uVar19 = param_10 & 0xf, 10 < uVar19)) goto LAB_00113e28;
  uVar38 = *param_1;
  uVar37 = param_1[1];
  local_1084 = *(int *)(uVar33 + 0x34);
  if ((param_6 != 0) && (local_1084 == 0)) {
    local_1084 = 1;
    *(undefined4 *)(uVar33 + 0x34) = 1;
  }
  if ((param_10 & 0x400) != 0) goto LAB_00113e28;
  if (*unaff_r7 == '/') {
LAB_00113f18:
    param_1[7] = 0x19;
    return 0;
  }
  if (local_1084 == 0) {
    local_1084 = 0;
    if (param_1[4] == 0xffff) {
      local_1084 = 1;
      *(undefined4 *)(uVar33 + 0x34) = 1;
    }
  }
  else if (param_1[4] == 0xffffffff) {
    param_1[7] = 2;
    return 0;
  }
  sVar12 = strlen(unaff_r7);
  if (0xffff < sVar12) goto LAB_00113f18;
  uVar25 = param_1[8];
  uVar34 = 0;
  uVar20 = uVar25 | param_1[9];
  bVar40 = uVar20 != 0;
  uVar39 = *(uint *)(uVar33 + 4);
  if (bVar40) {
    uVar20 = uVar25 - 1;
    uVar25 = uVar25 - (uVar20 & uVar38);
  }
  iVar26 = -1;
  if (bVar40) {
    uVar34 = uVar25 & uVar20;
  }
  uVar20 = param_9 + sVar12 + uVar39;
  bVar18 = CARRY4(param_9,sVar12) + CARRY4(param_9 + sVar12,uVar39) + (0xffffffb5 < uVar20);
  if (bVar18 != 0 || bVar18 < (0xfffffffe < uVar20 + 0x4a)) {
    uVar32 = 0xf;
LAB_00113f88:
    param_1[7] = uVar32;
    return 0;
  }
  if (local_1084 == 0) {
    uVar20 = param_9 + param_13 + param_15;
    uVar25 = uVar20 + uVar38;
    uVar27 = uVar25 + sVar12 * 2;
    uVar28 = uVar27 + uVar34;
    uVar35 = uVar28 + uVar39;
    iVar26 = uVar35 + 0x472;
    local_1084 = (((uint)CARRY4(param_9,param_13) + (uint)CARRY4(param_9 + param_13,param_15) +
                   uVar37 + (uint)CARRY4(uVar20,uVar38)) - ((int)sVar12 >> 0x1f)) +
                 (uint)CARRY4(uVar25,sVar12 * 2) + (uint)CARRY4(uVar27,uVar34) +
                 (uint)CARRY4(uVar28,uVar39) + (uint)(0xfffffb8d < uVar35);
    if (local_1084 != 0) {
      local_1084 = 1;
      *(undefined4 *)(uVar33 + 0x34) = 1;
    }
  }
  if (param_7 == (uint *)0x0) {
    local_10a4 = 0;
    sVar11 = 0;
  }
  else {
    local_1030 = *param_7;
    ptVar13 = localtime((time_t *)&local_1030);
    iVar26 = ptVar13->tm_hour;
    local_1084 = ptVar13->tm_min * 0x20 + iVar26 * 0x800;
    local_10a4 = local_1084 + ((uint)ptVar13->tm_sec >> 1);
    sVar11 = (short)ptVar13->tm_year * 0x200 + (short)ptVar13->tm_mon * 0x20 +
             (short)ptVar13->tm_mday + 0x6020;
  }
  uVar20 = 0x1000;
  if (uVar34 < 0x1000) {
    uVar20 = uVar34;
  }
  __aeabi_memclr8(&local_1030,uVar20,local_1084,iVar26);
  uVar20 = uVar38;
  uVar25 = uVar37;
  uVar39 = uVar34;
  if (param_6 == 0 && (3 < param_5) <= param_6) {
    uVar19 = 0;
  }
  for (; uVar39 != 0; uVar39 = uVar39 - uVar27) {
    uVar27 = 0x1000;
    if (uVar39 < 0x1000) {
      uVar27 = uVar39;
    }
    uVar28 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar20,uVar25,&local_1030,uVar27);
    if (uVar28 != uVar27) {
      uVar32 = 0x13;
      goto LAB_0011424c;
    }
    bVar40 = CARRY4(uVar20,uVar27);
    uVar20 = uVar20 + uVar27;
    uVar25 = uVar25 + bVar40;
  }
  puVar29 = (uint *)0x0;
  uVar38 = uVar38 + uVar34;
  uVar37 = uVar37 + CARRY4(uVar38,uVar34);
  uVar25 = param_5 | param_6;
  local_1068 = 0;
  local_1064 = 0;
  local_1060 = 0;
  uVar20 = uVar25;
  if (uVar25 != 0) {
    uVar20 = 1;
  }
  uVar34 = uVar19;
  if (uVar19 != 0) {
    uVar34 = 1;
  }
  uVar20 = uVar20 & uVar34;
  uVar36 = (undefined2)uVar20;
  local_105c = 0;
  uStack_105b = 0;
  uStack_105a = 0;
  uStack_1059 = 0;
  local_1058 = 0;
  uStack_1057 = 0;
  uStack_1056 = 0;
  uStack_1055 = 0;
  local_1054 = 0;
  uStack_1053 = 0;
  uStack_1052 = 0;
  uStack_1051 = 0;
  if (uVar20 != 0) {
    uVar36 = 8;
  }
  local_1050 = 0;
  uStack_104f = 0;
  uStack_104e = 0;
  uStack_104d = 0;
  local_104c = 0;
  uVar9 = local_104c;
  uVar10 = (undefined)sVar11;
  uVar4 = (undefined)((ushort)sVar11 >> 8);
  uVar5 = (undefined)(local_10a4 >> 8);
  uVar6 = (undefined)(uVar32 >> 8);
  uVar7 = (undefined)sVar12;
  uVar8 = (undefined)(sVar12 >> 8);
  local_104c = (short)param_13;
  sVar11 = local_104c;
  local_1038 = uVar38;
  local_1034 = uVar37;
  if (*(int *)(uVar33 + 0x34) == 0) {
    if ((local_1044 | uVar37) != 0) {
      uVar32 = 0x1d;
      goto LAB_00113f88;
    }
    local_1068 = 0x4034b50;
    uStack_105a = 0;
    uStack_1059 = 0;
    local_1058 = 0;
    uStack_1057 = 0;
    local_1060 = (local_10a4 & 0xff) << 0x10;
    local_1060 = CONCAT31(local_1060._1_3_,(char)uVar36);
    local_1064 = (uVar32 & 0xff) << 0x10;
    uStack_1056 = 0;
    uStack_1055 = 0;
    local_1054 = 0;
    uStack_1053 = 0;
    uStack_1052 = 0;
    uStack_1051 = 0;
    local_1050 = 0;
    uStack_104f = 0;
    local_1060 = CONCAT13(uVar5,(undefined3)local_1060);
    local_1064 = CONCAT13(uVar6,(undefined3)local_1064);
    uVar33 = uVar20;
    if (uVar20 != 0) {
      uVar33 = 0x14;
    }
    local_1064 = CONCAT31(local_1064._1_3_,(char)uVar33);
    local_105c = uVar10;
    uStack_105b = uVar4;
    uStack_104e = uVar7;
    uStack_104d = uVar8;
    iVar26 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar38,uVar37,&local_1068,0x1e);
    if (iVar26 != 0x1e) goto LAB_00114814;
    uVar38 = uVar38 + 0x1e;
    iVar26 = uVar37 + (0xffffffe1 < uVar38);
    sVar14 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar38,iVar26,unaff_r7,sVar12);
    if (sVar14 != sVar12) goto LAB_00114814;
    local_1088 = uVar38 + sVar12;
    puVar29 = (uint *)0x0;
    local_10b0 = iVar26 + (uint)CARRY4(uVar38,sVar12);
    local_1090 = 0;
  }
  else {
    if (((uint)(param_5 != 0xffffffff) <= -param_6) ||
       (local_1090 = 0, uVar37 != 0 || uVar37 < (0xfffffffe < uVar38))) {
      if ((param_10 & 0x20000) == 0) {
        puVar29 = &local_1030;
        if (uVar37 == 0 && (0xfffffffe < uVar38) <= uVar37) {
          puVar22 = &local_102c;
          uVar24 = 0;
        }
        else {
          local_102c = (undefined)uVar38;
          local_1028 = (undefined)uVar37;
          local_1029 = (undefined)(uVar38 >> 0x18);
          local_102a = (undefined)(uVar38 >> 0x10);
          local_102b = (undefined)(uVar38 >> 8);
          local_1025 = (undefined)(uVar37 >> 0x18);
          local_1026 = (undefined)(uVar37 >> 0x10);
          local_1027 = (undefined)(uVar37 >> 8);
          puVar22 = auStack_1024;
          uVar24 = 8;
        }
        local_1090 = (int)puVar22 - (int)puVar29;
        local_1030 = (uint)CONCAT12(uVar24,1);
      }
      else {
        puVar21 = &local_1040;
        puVar23 = &local_1048;
        if (-param_6 < (uint)(param_5 != 0xffffffff)) {
          puVar23 = (uint *)0x0;
          puVar21 = (uint *)0x0;
        }
        puVar29 = &local_1030;
        puVar31 = &local_1038;
        if (-uVar37 < (uint)(uVar38 != 0xffffffff)) {
          puVar31 = (uint *)0x0;
        }
        local_104c = uVar9;
        local_1090 = FUN_0011365c(puVar29,puVar21,puVar23,puVar31);
      }
    }
    local_1068 = 0x4034b50;
    uStack_105a = 0;
    uStack_1059 = 0;
    local_1058 = 0;
    uStack_1057 = 0;
    local_104c = (short)local_1090 + sVar11;
    uStack_1056 = 0;
    uStack_1055 = 0;
    local_1054 = 0;
    uStack_1053 = 0;
    uStack_1052 = 0;
    uStack_1051 = 0;
    local_1050 = 0;
    uStack_104f = 0;
    local_1060 = CONCAT13(uVar5,(int3)CONCAT31((int3)(((local_10a4 & 0xff) << 0x10) >> 8),
                                               (char)uVar36));
    uVar33 = uVar20;
    if (uVar20 != 0) {
      uVar33 = 0x14;
    }
    local_1064 = CONCAT31((int3)(CONCAT13(uVar6,(int3)((uVar32 & 0xff) << 0x10)) >> 8),(char)uVar33)
    ;
    local_105c = uVar10;
    uStack_105b = uVar4;
    uStack_104e = uVar7;
    uStack_104d = uVar8;
    iVar26 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar38,uVar37,&local_1068,0x1e);
    if (iVar26 != 0x1e) {
LAB_00114814:
      param_1[7] = 0x13;
      return 0;
    }
    uVar38 = uVar38 + 0x1e;
    iVar26 = uVar37 + (0xffffffe1 < uVar38);
    sVar14 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar38,iVar26,unaff_r7,sVar12);
    if (sVar14 != sVar12) goto LAB_00114814;
    uVar37 = uVar38 + sVar12;
    iVar26 = iVar26 + (uint)CARRY4(uVar38,sVar12);
    uVar33 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar37,iVar26,&local_1030,local_1090);
    if (uVar33 != local_1090) goto LAB_00114814;
    local_1088 = uVar37 + local_1090;
    local_10b0 = iVar26 + (uint)CARRY4(uVar37,local_1090);
  }
  if (param_13 != 0) {
    uVar33 = (*(code *)param_1[0xf])(param_1[0x11],param_12,local_1088,local_10b0,param_12,param_13)
    ;
    if (uVar33 != param_13) {
      uVar32 = 0x13;
      goto LAB_00113f88;
    }
    bVar40 = CARRY4(local_1088,param_13);
    local_1088 = local_1088 + param_13;
    local_10b0 = local_10b0 + bVar40;
  }
  if (uVar25 == 0) {
    local_1094 = 0;
    if ((param_10 & 0x20000) != 0) goto LAB_00114d78;
LAB_001149f8:
    uVar32 = local_1070;
    local_107c = (undefined)local_1094;
    local_1080 = (uint *)0x8074b50;
    local_1079 = (undefined)(local_1094 >> 0x18);
    local_107a = (undefined)(local_1094 >> 0x10);
    local_107b = (undefined)(local_1094 >> 8);
    uVar10 = (undefined)(local_1040 >> 0x18);
    local_1070._0_2_ = (undefined2)local_1040;
    if (puVar29 == (uint *)0x0) {
      if (local_1044 != 0) {
        uVar32 = 0x1d;
LAB_0011424c:
        param_1[7] = uVar32;
        return 0;
      }
      uVar33 = 0x10;
      local_1074 = CONCAT22(CONCAT11(local_1074._3_1_,(char)(local_1040 >> 0x10)),
                            (undefined2)local_1070);
      iVar26 = 0xf;
      local_1070 = uVar32;
    }
    else {
      uVar33 = 0x18;
      local_1074 = local_1044;
      local_106c = CONCAT22(CONCAT11(local_106c._3_1_,(char)(local_103c >> 0x10)),(short)local_103c)
      ;
      local_1070 = local_1040;
      uVar10 = (undefined)(local_103c >> 0x18);
      iVar26 = 0x17;
    }
    local_1078 = local_1048;
    *(undefined *)((int)&local_1080 + iVar26) = uVar10;
    uVar32 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],local_1088,local_10b0,&local_1080,uVar33)
    ;
    if (uVar32 != uVar33) {
      return 0;
    }
    bVar40 = CARRY4(local_1088,uVar33);
    local_1088 = local_1088 + uVar33;
    local_10b0 = local_10b0 + bVar40;
    if (puVar29 == (uint *)0x0) goto LAB_001150e4;
  }
  else {
    pbVar15 = (byte *)(*(code *)param_1[10])(param_1[0xd],1,0x2000);
    if (pbVar15 == (byte *)0x0) {
      uVar32 = 0x10;
      goto LAB_00113f88;
    }
    iVar26 = DAT_001151f4 + 0x1145d4;
    if (uVar19 == 0) {
      local_108c = 0;
      uVar33 = (*param_3)(param_4,param_3,0,0,pbVar15,0x2000);
      if (uVar33 == 0) {
        uVar19 = 0;
        local_1094 = 0;
      }
      else {
        local_1094 = 0;
        uVar19 = 0;
        local_108c = 0;
        do {
          if (0x2000 < uVar33) {
LAB_001151c4:
            (*(code *)param_1[0xb])(param_1[0xd],pbVar15);
            uVar32 = 0x14;
            goto LAB_00113f88;
          }
          bVar40 = CARRY4(local_108c,uVar33);
          local_108c = local_108c + uVar33;
          uVar19 = uVar19 + bVar40;
          if (param_6 <= uVar19 && (uint)(local_108c <= param_5) <= param_6 - uVar19)
          goto LAB_001151c4;
          uVar38 = (*(code *)param_1[0xf])
                             (param_1[0x11],(code *)param_1[0xf],local_1088,local_10b0,pbVar15,
                              uVar33);
          if (uVar38 != uVar33) {
            (*(code *)param_1[0xb])(param_1[0xd],pbVar15);
            uVar32 = 0x13;
            goto LAB_00113f88;
          }
          local_1094 = ~local_1094;
          pbVar30 = pbVar15;
          uVar38 = uVar33;
          if (uVar33 < 4) {
LAB_00114c10:
            do {
              uVar38 = uVar38 - 1;
              local_1094 = *(uint *)(iVar26 + (local_1094 & 0xff ^ (uint)*pbVar30) * 4) ^
                           local_1094 >> 8;
              pbVar30 = pbVar30 + 1;
            } while (uVar38 != 0);
          }
          else {
            uVar37 = uVar33 - 4 & 0xfffffffc;
            do {
              bVar18 = *pbVar30;
              pbVar1 = pbVar30 + 1;
              uVar38 = uVar38 - 4;
              pbVar2 = pbVar30 + 2;
              pbVar3 = pbVar30 + 3;
              pbVar30 = pbVar30 + 4;
              uVar25 = *(uint *)(iVar26 + (local_1094 & 0xff ^ (uint)bVar18) * 4) ^ local_1094 >> 8;
              uVar25 = *(uint *)(iVar26 + (uVar25 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar25 >> 8;
              uVar25 = *(uint *)(iVar26 + (uVar25 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar25 >> 8;
              local_1094 = *(uint *)(iVar26 + (uVar25 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar25 >> 8;
            } while (3 < uVar38);
            uVar38 = (uVar33 - 4) - uVar37;
            if (uVar38 != 0) {
              pbVar30 = pbVar15 + uVar37 + 4;
              goto LAB_00114c10;
            }
          }
          uVar38 = (*param_3)(param_4,param_3,local_108c,uVar19,pbVar15,0x2000);
          local_1094 = ~local_1094;
          bVar40 = CARRY4(local_1088,uVar33);
          local_1088 = local_1088 + uVar33;
          local_10b0 = local_10b0 + bVar40;
          uVar33 = uVar38;
        } while (uVar38 != 0);
      }
      local_1048 = local_108c;
      local_1040 = local_108c;
      local_1044 = uVar19;
      local_103c = uVar19;
    }
    else {
      piVar16 = (int *)(*(code *)param_1[10])(param_1[0xd],1,&DAT_0004df40);
      if (piVar16 == (int *)0x0) {
        (*(code *)param_1[0xb])(param_1[0xd],pbVar15);
        uVar32 = 0x10;
        goto LAB_00113f88;
      }
      uVar33 = uVar19;
      if (9 < uVar19) {
        uVar33 = 10;
      }
      uVar38 = *(uint *)(DAT_001151f8 + 0x114620 + uVar33 * 4);
      uVar33 = uVar38;
      if (uVar19 < 4) {
        uVar33 = uVar38 | 0x4000;
      }
      local_1070 = 0;
      local_106c = 0;
      *piVar16 = DAT_001151fc + 0x114670;
      piVar16[1] = (int)&local_1080;
      piVar16[2] = uVar33;
      piVar16[5] = (uVar33 << 0x11) >> 0x1f;
      piVar16[3] = ((uVar38 & 0xfff) + 2) / 3 + 1;
      piVar16[4] = (((uVar38 & 0xfff) >> 2) + 2) / 3 + 1;
      local_1080 = param_1;
      local_1078 = local_1088;
      local_1074 = local_10b0;
      __aeabi_memclr(&DAT_00029272 + (int)piVar16,0x10000);
      *(undefined *)((int)piVar16 + 0x9272) = 0;
      piVar16[8] = 0;
      piVar16[9] = 0;
      piVar16[0xf] = 0;
      piVar16[7] = 0;
      piVar16[0x10] = 0;
      piVar16[0x11] = 0;
      piVar16[0x12] = 0;
      piVar16[0x16] = 0;
      piVar16[0x17] = 0;
      piVar16[0x18] = 0;
      piVar16[0x19] = 0;
      piVar16[0x1a] = 0;
      piVar16[10] = (int)piVar16 + 0x9273;
      piVar16[0xe] = 8;
      piVar16[0x1b] = 0;
      piVar16[0xd] = (int)(&UNK_00039272 + (int)piVar16);
      piVar16[0xc] = (int)(&UNK_00039272 + (int)piVar16);
      piVar16[0xb] = (int)(undefined *)((int)piVar16 + 0x9272);
      piVar16[0x14] = 0;
      piVar16[0x15] = 0;
      piVar16[0x13] = 0;
      piVar16[6] = 1;
      __aeabi_memclr((int)piVar16 + 0x8192,0x280);
      __aeabi_memclr4(piVar16 + 0x1c,0x8121);
      local_1094 = 0;
      local_1088 = 0;
      uVar33 = 0;
      do {
        uVar19 = (*param_3)(param_4,param_3,local_1088,uVar33,pbVar15,0x2000);
        uVar38 = 0x14;
        if (0x2000 < uVar19) goto LAB_00114c90;
        uVar37 = local_1088 + uVar19;
        uVar25 = uVar33 + CARRY4(local_1088,uVar19);
        if (param_6 <= uVar25 && (uint)(uVar37 <= param_5) <= param_6 - uVar25) goto LAB_00114c90;
        local_1094 = ~local_1094;
        pbVar30 = pbVar15;
        uVar33 = uVar19;
        if (3 < uVar19) {
          uVar38 = uVar19 - 4 & 0xfffffffc;
          do {
            bVar18 = *pbVar30;
            pbVar1 = pbVar30 + 1;
            uVar33 = uVar33 - 4;
            pbVar2 = pbVar30 + 2;
            pbVar3 = pbVar30 + 3;
            pbVar30 = pbVar30 + 4;
            uVar34 = *(uint *)(iVar26 + (local_1094 & 0xff ^ (uint)bVar18) * 4) ^ local_1094 >> 8;
            uVar34 = *(uint *)(iVar26 + (uVar34 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar34 >> 8;
            uVar34 = *(uint *)(iVar26 + (uVar34 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar34 >> 8;
            local_1094 = *(uint *)(iVar26 + (uVar34 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar34 >> 8;
          } while (3 < uVar33);
          uVar33 = (uVar19 - 4) - uVar38;
          pbVar30 = pbVar15 + uVar38 + 4;
        }
        for (; uVar33 != 0; uVar33 = uVar33 - 1) {
          local_1094 = *(uint *)(iVar26 + (local_1094 & 0xff ^ (uint)*pbVar30) * 4) ^
                       local_1094 >> 8;
          pbVar30 = pbVar30 + 1;
        }
        if ((code *)param_1[0x10] == (code *)0x0) {
          iVar17 = 0;
        }
        else {
          iVar17 = (*(code *)param_1[0x10])(param_1[0x11]);
          if (iVar17 != 0) {
            iVar17 = 3;
          }
        }
        local_2c[0] = uVar19;
        if (uVar19 == 0) {
          local_2c[0] = 0;
          iVar17 = 4;
        }
        iVar17 = FUN_001067f4(piVar16,pbVar15,local_2c,0,0,iVar17);
        local_1094 = ~local_1094;
        local_1088 = uVar37;
        uVar33 = uVar25;
      } while (iVar17 == 0);
      uVar38 = 0xc;
      if (iVar17 == 1) {
        bVar40 = false;
      }
      else {
LAB_00114c90:
        bVar40 = true;
        param_1[7] = uVar38;
      }
      (*(code *)param_1[0xb])(param_1[0xd],piVar16);
      if (bVar40) {
        (*(code *)param_1[0xb])(param_1[0xd],pbVar15);
        return 0;
      }
      local_1040 = local_1088;
      local_1048 = local_1070;
      local_1088 = local_1078;
      local_10b0 = local_1074;
      local_1044 = local_106c;
      local_103c = uVar33;
    }
    (*(code *)param_1[0xb])(param_1[0xd],pbVar15);
    if ((param_10 & 0x20000) == 0) goto LAB_001149f8;
LAB_00114d78:
    if (puVar29 != (uint *)0x0) {
      puVar21 = &local_1048;
      puVar23 = &local_1040;
      if (-param_6 < (uint)(param_5 != 0xffffffff)) {
        puVar23 = (uint *)0x0;
        puVar21 = (uint *)0x0;
      }
      puVar31 = &local_1038;
      if (-local_1034 < (uint)(local_1038 != 0xffffffff)) {
        puVar31 = (uint *)0x0;
      }
      local_1090 = FUN_0011365c(&local_1030,puVar23,puVar21,puVar31);
    }
    uVar19 = local_1034;
    uVar33 = local_1038;
    local_1068 = 0x4034b50;
    uStack_105a = (undefined)local_1094;
    uStack_1057 = (undefined)(local_1094 >> 0x18);
    local_1058 = (undefined)(local_1094 >> 0x10);
    uStack_1059 = (undefined)(local_1094 >> 8);
    local_104c = (short)local_1090 + sVar11;
    local_1060 = CONCAT13(uVar5,CONCAT12((char)local_10a4,uVar36));
    if (uVar20 != 0) {
      uVar20 = 0x14;
    }
    local_1064 = CONCAT31((int3)(CONCAT13(uVar6,(int3)((uVar32 & 0xff) << 0x10)) >> 8),(char)uVar20)
    ;
    bVar40 = (uint)(param_5 != 0xffffffff) <= -param_6;
    uVar38 = local_1040;
    uVar32 = local_103c;
    if (bVar40) {
      uVar32 = 0;
      uVar38 = 0xffffffff;
    }
    if (uVar32 != 0 || uVar32 < (0xfffffffe < uVar38)) {
      uVar38 = 0xffffffff;
    }
    uVar37 = local_1048;
    uVar32 = local_1044;
    if (bVar40) {
      uVar32 = 0;
      uVar37 = 0xffffffff;
    }
    uStack_1052 = (undefined)uVar38;
    if (uVar32 != 0 || uVar32 < (0xfffffffe < uVar37)) {
      uVar37 = 0xffffffff;
    }
    uStack_1056 = (undefined)uVar37;
    uStack_104f = (undefined)(uVar38 >> 0x18);
    local_1050 = (undefined)(uVar38 >> 0x10);
    uStack_1051 = (undefined)(uVar38 >> 8);
    uStack_1053 = (undefined)(uVar37 >> 0x18);
    local_1054 = (undefined)(uVar37 >> 0x10);
    uStack_1055 = (undefined)(uVar37 >> 8);
    local_105c = uVar10;
    uStack_105b = uVar4;
    uStack_104e = uVar7;
    uStack_104d = uVar8;
    iVar26 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],local_1038,local_1034,&local_1068,0x1e);
    if (iVar26 != 0x1e) {
LAB_00114fec:
      param_1[7] = 0x13;
      return 0;
    }
    if (puVar29 == (uint *)0x0) goto LAB_001150e4;
    uVar32 = uVar33 + 0x1e;
    iVar26 = uVar19 + (0xffffffe1 < uVar33);
    sVar14 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar32,iVar26,unaff_r7,sVar12);
    if ((sVar14 != sVar12) ||
       (uVar32 = (*(code *)param_1[0xf])
                           (param_1[0x11],(code *)param_1[0xf],uVar32 + sVar12,
                            iVar26 + (uint)CARRY4(uVar32,sVar12),&local_1030,local_1090),
       uVar32 != local_1090)) goto LAB_00114fec;
  }
  puVar23 = &local_1048;
  puVar21 = &local_1040;
  if (-local_103c < (uint)(local_1040 != 0xffffffff)) {
    puVar23 = (uint *)0x0;
    puVar21 = (uint *)0x0;
  }
  puVar31 = &local_1038;
  if (-local_1034 < (uint)(local_1038 != 0xffffffff)) {
    puVar31 = (uint *)0x0;
  }
  local_1090 = FUN_0011365c(&local_1030,puVar21,puVar23,puVar31);
LAB_001150e4:
  iVar26 = FUN_001137d8(param_1,unaff_r7,sVar12 & 0xffff,puVar29,local_1090 & 0xffff,param_8,param_9
                       );
  if (iVar26 == 0) {
    return 0;
  }
  *param_1 = local_1088;
  param_1[1] = local_10b0;
  param_1[4] = param_1[4] + 1;
  return 1;
}

