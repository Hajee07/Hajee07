/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00105de4 FUN_00105de4 */

undefined4
FUN_00105de4(int param_1,int param_2,int param_3,int param_4,int param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  code *pcVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = param_2;
  if (9 < param_2) {
    iVar5 = 10;
  }
  if (param_2 == -1 || param_2 + 1 < 0 != SCARRY4(param_2,1)) {
    iVar5 = 6;
  }
  uVar4 = *(uint *)(DAT_0010607c + 0x105e0c + iVar5 * 4);
  if (param_2 < 4) {
    uVar4 = uVar4 | 0x4000;
  }
  if (0 < param_4) {
    uVar4 = uVar4 | 0x1000;
  }
  if (param_2 == 0) {
    uVar4 = uVar4 | 0x80000;
  }
  else {
    switch(param_6) {
    case 1:
      uVar4 = uVar4 | 0x20000;
      break;
    case 2:
      uVar4 = uVar4 & 0xfffff000;
      break;
    case 3:
      uVar4 = uVar4 | 0x10000;
      break;
    case 4:
      uVar4 = uVar4 | 0x40000;
    }
  }
  if (param_1 != 0) {
    uVar1 = 0xffffd8f0;
    if (((param_3 == 8) && (param_5 - 1U < 9)) && (param_4 == 0xf || param_4 == -0xf)) {
      pcVar3 = *(code **)(param_1 + 0x20);
      *(undefined4 *)(param_1 + 0x2c) = 0;
      *(undefined4 *)(param_1 + 0x30) = 1;
      *(undefined4 *)(param_1 + 0x34) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0;
      *(undefined4 *)(param_1 + 0x18) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
      if (pcVar3 == (code *)0x0) {
        pcVar3 = (code *)(DAT_00106080 + 0x105ed0);
        *(code **)(param_1 + 0x20) = pcVar3;
      }
      if (*(int *)(param_1 + 0x24) == 0) {
        *(int *)(param_1 + 0x24) = DAT_00106084 + 0x105ee4;
      }
      puVar2 = (undefined4 *)(*pcVar3)(*(undefined4 *)(param_1 + 0x28),1,&DAT_0004df40);
      if (puVar2 == (undefined4 *)0x0) {
        return 0xfffffffc;
      }
      *(undefined4 **)(param_1 + 0x1c) = puVar2;
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar2[2] = uVar4 | 0x2000;
      puVar2[3] = ((uVar4 & 0xfff) + 2) / 3 + 1;
      puVar2[4] = (((uVar4 & 0xfff) >> 2) + 2) / 3 + 1;
      puVar2[5] = (uVar4 << 0x11) >> 0x1f;
      if ((uVar4 & 0x8000) == 0) {
        __aeabi_memclr(&DAT_00029272 + (int)puVar2,0x10000);
      }
      puVar2[8] = 0;
      puVar2[9] = 0;
      puVar2[0xf] = 0;
      puVar2[7] = 0;
      puVar2[0x10] = 0;
      puVar2[0x11] = 0;
      puVar2[0x12] = 0;
      puVar2[0x16] = 0;
      puVar2[0x17] = 0;
      puVar2[0x18] = 0;
      puVar2[0x19] = 0;
      puVar2[0x1a] = 0;
      *(undefined *)((int)puVar2 + 0x9272) = 0;
      puVar2[0xb] = (undefined *)((int)puVar2 + 0x9272);
      puVar2[10] = (int)puVar2 + 0x9273;
      puVar2[0xe] = 8;
      puVar2[0x1b] = 0;
      puVar2[0xd] = &UNK_00039272 + (int)puVar2;
      puVar2[0xc] = &UNK_00039272 + (int)puVar2;
      puVar2[0x14] = 0;
      puVar2[0x15] = 0;
      puVar2[0x13] = 0;
      puVar2[0x1c] = 0;
      puVar2[6] = 1;
      puVar2[0x1d] = 0;
      puVar2[0x1e] = 0;
      puVar2[0x1f] = 0;
      puVar2[0x20] = 0;
      puVar2[0x21] = 0;
      puVar2[0x22] = 0;
      puVar2[0x23] = 0;
      if ((uVar4 & 0x8000) == 0) {
        __aeabi_memclr4(puVar2 + 0x24,0x8101);
      }
      __aeabi_memclr((int)puVar2 + 0x8192,0x280);
      uVar1 = 0;
    }
    return uVar1;
  }
  return 0xfffffffe;
}

