/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011b384 FUN_0011b384 */

void FUN_0011b384(int param_1,int param_2,int param_3,uint param_4,int param_5)

{
  bool bVar1;
  int iVar2;
  byte *pbVar3;
  ushort *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  ushort *puVar8;
  int *piVar9;
  uint *puVar10;
  int *piVar11;
  uint uVar12;
  uint uVar13;
  ushort uVar14;
  int iVar15;
  uint uVar16;
  ushort *unaff_r7;
  int iVar17;
  ushort *puVar18;
  ushort uVar19;
  int iVar20;
  int iVar21;
  ushort local_15b0 [576];
  ushort local_1130 [576];
  int aiStack_cb0 [34];
  int local_c28 [256];
  uint local_828 [256];
  int local_428;
  
  __aeabi_memclr8(aiStack_cb0,0x84);
  if (param_5 != 0) {
    if (0 < param_3) {
      pbVar3 = (byte *)(param_1 + param_2 * 0x120 + 0x8f12);
      iVar6 = param_3;
      do {
        iVar6 = iVar6 + -1;
        aiStack_cb0[*pbVar3] = aiStack_cb0[*pbVar3] + 1;
        pbVar3 = pbVar3 + 1;
      } while (iVar6 != 0);
    }
    local_828[1] = 0;
    goto joined_r0x0011b990;
  }
  if (param_3 < 1) {
    iVar6 = 0;
  }
  else {
    iVar6 = 0;
    puVar4 = (ushort *)(param_1 + param_2 * 0x240 + 0x8192);
    iVar7 = 0;
    do {
      uVar14 = *puVar4;
      puVar4 = puVar4 + 1;
      if (uVar14 != 0) {
        unaff_r7 = local_1130 + iVar6 * 2;
        local_1130[iVar6 * 2 + 1] = (ushort)iVar7;
        iVar6 = iVar6 + 1;
      }
      iVar7 = iVar7 + 1;
      if (uVar14 != 0) {
        *unaff_r7 = uVar14;
      }
    } while (param_3 != iVar7);
  }
  puVar10 = local_828;
  __aeabi_memclr8(puVar10,0x800);
  if (iVar6 == 0) {
    iVar7 = 1;
LAB_0011b568:
    puVar10 = local_828;
    iVar20 = 0;
    puVar4 = local_15b0;
    puVar8 = local_1130;
    do {
      puVar18 = puVar4;
      iVar5 = 0;
      iVar15 = 0;
      do {
        uVar16 = puVar10[iVar15];
        local_c28[iVar15] = iVar5;
        iVar15 = iVar15 + 1;
        iVar5 = uVar16 + iVar5;
      } while (iVar15 != 0x100);
      iVar20 = iVar20 + 1;
      puVar10 = puVar10 + 0x100;
      puVar4 = puVar8;
      puVar8 = puVar18;
    } while (iVar20 != iVar7);
  }
  else {
    puVar4 = local_1130;
    iVar7 = iVar6;
    do {
      iVar7 = iVar7 + -1;
      uVar12 = *puVar4 & 0xff;
      uVar16 = *puVar4 >> 6 & 0xfffffffc | 0x400;
      puVar10[uVar12] = puVar10[uVar12] + 1;
      *(int *)((int)puVar10 + uVar16) = *(int *)((int)puVar10 + uVar16) + 1;
      puVar4 = puVar4 + 2;
    } while (iVar7 != 0);
    iVar7 = 2;
    if (local_428 == iVar6) {
      iVar7 = 1;
    }
    if (iVar6 == 0) goto LAB_0011b568;
    uVar16 = 0;
    iVar20 = 0;
    puVar4 = local_1130;
    puVar8 = local_15b0;
    do {
      puVar18 = puVar8;
      puVar8 = puVar4;
      iVar15 = 0;
      iVar5 = 0;
      do {
        uVar12 = puVar10[iVar5];
        local_c28[iVar5] = iVar15;
        iVar5 = iVar5 + 1;
        iVar15 = uVar12 + iVar15;
      } while (iVar5 != 0x100);
      iVar5 = 0;
      do {
        uVar12 = puVar8[iVar5 * 2] >> (uVar16 & 0xff) & 0xff;
        iVar17 = local_c28[uVar12];
        local_c28[uVar12] = iVar17 + 1;
        iVar15 = iVar5 * 2;
        iVar5 = iVar5 + 1;
        *(undefined4 *)(puVar18 + iVar17 * 2) = *(undefined4 *)(puVar8 + iVar15);
      } while (iVar6 != iVar5);
      iVar20 = iVar20 + 1;
      puVar10 = puVar10 + 0x100;
      uVar16 = uVar16 + 8;
      puVar4 = puVar18;
    } while (iVar20 != iVar7);
  }
  if (iVar6 != 0) {
    puVar4 = puVar18;
    iVar7 = iVar6;
    if (iVar6 != 1) {
      uVar14 = *puVar18 + puVar18[2];
      iVar20 = iVar6 + -1;
      *puVar18 = uVar14;
      if (1 < iVar20) {
        puVar8 = puVar18 + 2;
        iVar5 = 0;
        iVar15 = 2;
        iVar21 = 3;
        iVar17 = 1;
        if (iVar6 < 3) goto LAB_0011b62c;
        do {
          iVar2 = iVar15 * 2;
          if (puVar18[iVar2] <= uVar14) {
            iVar15 = iVar15 + 1;
            *puVar8 = puVar18[iVar2];
            if (iVar15 < iVar6) goto LAB_0011b644;
            goto LAB_0011b678;
          }
LAB_0011b62c:
          do {
            iVar2 = iVar5 * 2;
            *puVar8 = uVar14;
            iVar5 = iVar5 + 1;
            puVar18[iVar2] = (ushort)iVar17;
            if (iVar15 < iVar6) {
LAB_0011b644:
              if (iVar5 < iVar17) {
                uVar19 = puVar18[iVar15 * 2];
                uVar14 = puVar18[iVar5 * 2];
                if (uVar14 < uVar19) goto LAB_0011b680;
              }
              else {
                uVar19 = puVar18[iVar15 * 2];
              }
              iVar15 = iVar15 + 1;
              *puVar8 = *puVar8 + uVar19;
              iVar17 = iVar21;
            }
            else {
LAB_0011b678:
              uVar14 = puVar18[iVar5 * 2];
LAB_0011b680:
              *puVar8 = *puVar8 + uVar14;
              iVar2 = iVar5 * 2;
              iVar5 = iVar5 + 1;
              puVar18[iVar2] = (ushort)iVar17;
              iVar17 = iVar21;
            }
            if (iVar6 == iVar17) goto LAB_0011b6e0;
            iVar21 = iVar17 + 1;
            puVar8 = puVar8 + 2;
            uVar14 = puVar18[iVar5 * 2];
            iVar17 = iVar17 + -1;
          } while (iVar6 <= iVar15);
        } while( true );
      }
LAB_0011b6e0:
      iVar5 = iVar6 + -2;
      uVar16 = 0;
      puVar18[iVar5 * 2] = 0;
      if (-1 < iVar6 + -3) {
        iVar15 = iVar6 + -2;
        puVar8 = puVar18 + iVar6 * 2 + -6;
        do {
          iVar15 = iVar15 + -1;
          *puVar8 = puVar18[(uint)*puVar8 * 2] + 1;
          puVar8 = puVar8 + -2;
        } while (0 < iVar15);
      }
      iVar15 = 1;
      if (-1 < iVar5) goto LAB_0011b754;
LAB_0011b790:
      iVar17 = 0;
      if (iVar15 < 1) goto LAB_0011b73c;
      do {
        puVar8 = puVar18 + iVar20 * 2;
        do {
          iVar15 = iVar15 + -1;
          *puVar8 = (ushort)uVar16;
          iVar20 = iVar20 + -1;
          puVar8 = puVar8 + -2;
        } while (iVar17 < iVar15);
LAB_0011b73c:
        do {
          uVar16 = uVar16 + 1;
          iVar15 = iVar17 << 1;
          if (iVar17 < 1) {
            if (iVar6 < 1) goto LAB_0011b8f0;
            goto LAB_0011b7dc;
          }
          if (iVar5 < 0) goto LAB_0011b790;
LAB_0011b754:
          puVar8 = puVar18 + iVar5 * 2;
          iVar17 = 0;
          iVar21 = iVar5;
          do {
            iVar5 = iVar21;
            if (uVar16 != *puVar8) break;
            iVar5 = iVar21 + -1;
            puVar8 = puVar8 + -2;
            iVar17 = iVar17 + 1;
            bVar1 = 0 < iVar21;
            iVar21 = iVar5;
          } while (bVar1);
        } while (iVar15 <= iVar17);
      } while( true );
    }
    *puVar18 = 1;
LAB_0011b7dc:
    do {
      iVar7 = iVar7 + -1;
      aiStack_cb0[*puVar4] = aiStack_cb0[*puVar4] + 1;
      puVar4 = puVar4 + 2;
    } while (iVar7 != 0);
    if (1 < iVar6) {
      if ((int)(param_4 + 1) < 0x21) {
        iVar7 = aiStack_cb0[param_4];
        uVar16 = param_4;
        do {
          iVar20 = uVar16 * 4;
          uVar16 = uVar16 + 1;
          iVar7 = *(int *)(((uint)aiStack_cb0 | 4) + iVar20) + iVar7;
          aiStack_cb0[param_4] = iVar7;
        } while (uVar16 != 0x20);
        if (0 < (int)param_4) goto LAB_0011b838;
        iVar7 = 0;
      }
      else {
LAB_0011b838:
        uVar12 = 0;
        iVar7 = 0;
        uVar16 = param_4;
        do {
          piVar9 = aiStack_cb0 + uVar16;
          uVar16 = uVar16 - 1;
          iVar7 = iVar7 + (*piVar9 << (uVar12 & 0xff));
          uVar12 = uVar12 + 1;
        } while (0 < (int)uVar16);
        if (iVar7 == 1 << (param_4 & 0xff)) goto LAB_0011b8f0;
      }
      do {
        aiStack_cb0[param_4] = aiStack_cb0[param_4] + -1;
        piVar9 = aiStack_cb0 + param_4 + 1;
        uVar16 = param_4;
        do {
          piVar11 = piVar9;
          uVar16 = uVar16 - 1;
          if ((int)uVar16 < 1) goto LAB_0011b894;
          piVar9 = piVar11 + -1;
        } while (piVar11[-2] == 0);
        piVar11[-2] = piVar11[-2] + -1;
        *piVar9 = *piVar9 + 2;
LAB_0011b894:
        iVar7 = iVar7 + -1;
      } while (iVar7 != 1 << (param_4 & 0xff));
    }
  }
LAB_0011b8f0:
  iVar7 = param_1 + param_2 * 0x120;
  __aeabi_memclr(iVar7 + 0x8f12,0x120);
  __aeabi_memclr(param_1 + param_2 * 0x240 + 0x8852,0x240);
  if (0 < (int)param_4) {
    uVar16 = 1;
    while( true ) {
      if (0 < aiStack_cb0[1]) {
        puVar4 = puVar18 + iVar6 * 2 + -1;
        do {
          aiStack_cb0[1] = aiStack_cb0[1] + -1;
          iVar6 = iVar6 + -1;
          *(char *)(iVar7 + (uint)*puVar4 + 0x8f12) = (char)uVar16;
          puVar4 = puVar4 + -2;
        } while (0 < aiStack_cb0[1]);
      }
      if (uVar16 == param_4) break;
      aiStack_cb0[1] = aiStack_cb0[uVar16 + 1];
      uVar16 = uVar16 + 1;
    }
  }
  local_828[1] = 0;
joined_r0x0011b990:
  if (1 < (int)param_4) {
    uVar16 = 0;
    iVar6 = param_4 - 1;
    piVar9 = (int *)((uint)aiStack_cb0 | 4);
    puVar10 = local_828 + 2;
    do {
      iVar6 = iVar6 + -1;
      uVar16 = (*piVar9 + uVar16) * 2;
      *puVar10 = uVar16;
      piVar9 = piVar9 + 1;
      puVar10 = puVar10 + 1;
    } while (iVar6 != 0);
  }
  if (0 < param_3) {
    iVar6 = 0;
    do {
      uVar16 = (uint)*(byte *)(param_1 + param_2 * 0x120 + iVar6 + 0x8f12);
      if (uVar16 != 0) {
        uVar12 = local_828[uVar16];
        local_828[uVar16] = uVar12 + 1;
        uVar13 = 0;
        do {
          uVar16 = uVar16 - 1;
          uVar13 = uVar12 & 1 | uVar13 << 1;
          uVar12 = uVar12 >> 1;
        } while (0 < (int)uVar16);
        *(short *)(param_1 + param_2 * 0x240 + iVar6 * 2 + 0x8852) = (short)uVar13;
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 != param_3);
  }
  return;
}

