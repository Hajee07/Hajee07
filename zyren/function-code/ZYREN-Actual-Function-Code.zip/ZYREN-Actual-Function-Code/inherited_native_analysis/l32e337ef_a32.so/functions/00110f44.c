/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110f44 FUN_00110f44 */

undefined4 FUN_00110f44(int param_1,code *param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  code *unaff_r6;
  void *pvVar5;
  bool bVar6;
  undefined auStack_78 [20];
  int local_64;
  int local_60;
  int local_5c;
  int local_50;
  code *local_4c;
  undefined4 local_44;
  undefined4 *local_30;
  
  if (param_1 != 0) {
    unaff_r6 = param_2;
  }
  if (param_1 == 0 || param_2 == (code *)0x0) {
    if (param_4 != (int *)0x0) {
      *param_4 = 0x18;
    }
    return 0;
  }
  __aeabi_memclr8(auStack_78,0x50);
  iVar2 = FUN_0010c8a4(auStack_78,param_1,unaff_r6,param_3);
  if (iVar2 == 0) {
    if (param_4 != (int *)0x0) {
      *param_4 = local_5c;
    }
    return 0;
  }
  iVar3 = FUN_00110d90(auStack_78,param_3);
  puVar1 = local_30;
  iVar2 = local_5c;
  if (iVar3 == 0) {
    if ((((local_30 != (undefined4 *)0x0) && (local_50 != 0)) && (local_4c != (code *)0x0)) &&
       (local_64 == 1)) {
      uVar4 = 0;
      local_30 = (undefined4 *)0x0;
      (*local_4c)(local_44,*puVar1);
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      (*local_4c)(local_44,puVar1[4]);
      puVar1[4] = 0;
      puVar1[5] = 0;
      puVar1[6] = 0;
      puVar1[7] = 0;
      (*local_4c)(local_44,puVar1[8]);
      puVar1[8] = 0;
      puVar1[9] = 0;
      puVar1[10] = 0;
      puVar1[0xb] = 0;
      pvVar5 = (void *)puVar1[0xf];
      if (pvVar5 != (void *)0x0) {
        bVar6 = true;
        if (local_60 == 4) {
          if (*(int *)((int)pvVar5 + 8) == 0) goto LAB_001111c8;
          iVar3 = FUN_00120238();
          free(pvVar5);
          bVar6 = iVar3 != -1;
        }
        goto LAB_001111cc;
      }
      bVar6 = true;
LAB_001111dc:
      (*local_4c)(local_44,puVar1);
      if (bVar6) goto LAB_0011120c;
    }
    uVar4 = 0;
    if (iVar2 != 0) goto LAB_0011120c;
  }
  else {
    if (local_30 != (undefined4 *)0x0) {
      if (local_50 != 0) {
        unaff_r6 = local_4c;
      }
      if ((local_50 != 0 && unaff_r6 != (code *)0x0) && (local_64 == 1)) {
        iVar2 = 0;
        local_30 = (undefined4 *)0x0;
        (*unaff_r6)(local_44,*puVar1);
        *puVar1 = 0;
        puVar1[1] = 0;
        puVar1[2] = 0;
        puVar1[3] = 0;
        (*local_4c)(local_44,puVar1[4]);
        puVar1[4] = 0;
        puVar1[5] = 0;
        puVar1[6] = 0;
        puVar1[7] = 0;
        (*local_4c)(local_44,puVar1[8]);
        puVar1[8] = 0;
        uVar4 = 1;
        puVar1[9] = 0;
        bVar6 = true;
        puVar1[10] = 0;
        puVar1[0xb] = 0;
        pvVar5 = (void *)puVar1[0xf];
        if (pvVar5 == (void *)0x0) goto LAB_001111dc;
        bVar6 = true;
        if (local_60 == 4) {
          if (*(int *)((int)pvVar5 + 8) != 0) {
            iVar3 = FUN_00120238();
            free(pvVar5);
            if (iVar3 != -1) goto LAB_001111cc;
          }
          local_5c = 0x15;
LAB_001111c8:
          bVar6 = false;
        }
LAB_001111cc:
        puVar1[0xf] = 0;
        goto LAB_001111dc;
      }
    }
    local_5c = 0x18;
  }
  uVar4 = 0;
  iVar2 = local_5c;
LAB_0011120c:
  if (param_4 != (int *)0x0) {
    *param_4 = iVar2;
  }
  return uVar4;
}

