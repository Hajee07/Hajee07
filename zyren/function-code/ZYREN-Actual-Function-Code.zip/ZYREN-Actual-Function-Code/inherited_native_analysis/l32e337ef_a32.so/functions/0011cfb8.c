/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011cfb8 FUN_0011cfb8 */

int FUN_0011cfb8(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 local_90;
  undefined4 local_8c;
  undefined4 local_88;
  undefined4 local_84;
  undefined4 local_80;
  undefined4 uStack_7c;
  uint uStack_78;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined2 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined2 local_20;
  
  iVar5 = 0;
  uStack_78 = uStack_78 & 0xff000000;
  uStack_7c = 0;
  local_80 = 0;
  local_84 = 0;
  local_88 = 0;
  local_8c = 0;
  local_90 = 0;
  thunk_FUN_000f41c4(&local_90,DAT_0011d1e4 + 0x11cfdc,0x1b);
  uStack_98 = (uint)uStack_98._3_1_ << 0x18;
  uStack_9c = 0;
  local_a0 = 0;
  local_a4 = 0;
  local_a8 = 0;
  thunk_FUN_000f41c4(&local_a8,DAT_0011d1e8 + 0x11d027,0x13);
  iVar1 = (**(code **)(*param_1 + 0x18))(param_1,&local_90);
  if (((iVar1 != 0) &&
      (iVar2 = (**(code **)(*param_1 + 0x1c4))(param_1,iVar1,&local_a8,DAT_0011d1ec + 0x11d06c),
      iVar2 != 0)) && (iVar5 = (**(code **)(*param_1 + 0x1c8))(param_1,iVar1,iVar2), iVar5 == 0)) {
    local_20 = 0;
    local_24 = 0;
    local_28 = 0;
    thunk_FUN_000f41c4(&local_28,DAT_0011d1f0 + 0x11d0da,10);
    local_2c = 0;
    local_30 = 0;
    thunk_FUN_000f41c4(&local_30,DAT_0011d1f4 + 0x11d0e4,8);
    local_38 = 0;
    local_3c = 0;
    local_40 = 0;
    thunk_FUN_000f41c4(&local_40,DAT_0011d1f8 + 0x11d150,0xc);
    local_44 = 0;
    local_48 = 0;
    local_4c = 0;
    local_50 = 0;
    thunk_FUN_000f41c4(&local_50,DAT_0011d1fc + 0x11d166,0xe);
    local_54 = 0;
    local_58 = 0;
    local_5c = 0;
    local_60 = 0;
    local_64 = 0;
    local_68 = 0;
    local_6c = 0;
    local_70 = 0;
    iVar1 = *(int *)(DAT_0011d200 + 0x11d164);
    if (iVar1 == 0) {
      sprintf((char *)&local_70,(char *)&local_28,&local_30);
    }
    else {
      sprintf((char *)&local_70,(char *)&local_40,iVar1,iVar1);
    }
    uVar3 = (**(code **)(*param_1 + 0x18))(param_1,&local_70);
    uVar4 = (**(code **)(*param_1 + 0x1c4))(param_1,uVar3,&local_50,DAT_0011d204 + 0x11d1bc);
    iVar1 = (**(code **)(*param_1 + 0x1c8))(param_1,uVar3,uVar4);
    return iVar1;
  }
  return iVar5;
}

