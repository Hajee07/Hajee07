/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0004cc00 thunk_FUN_00150308 */

void thunk_FUN_00150308(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
                    /* WARNING: Could not recover jumptable at 0x00150394. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_00150348 + DAT_00150348))
            (param_1,param_2,param_3,
             param_4 & 0xff000000 | (param_4 >> 0x10 & 0xff) << 0x10 | (param_4 >> 8 & 0xff) << 8 |
             param_4 & 0xff);
  return;
}

