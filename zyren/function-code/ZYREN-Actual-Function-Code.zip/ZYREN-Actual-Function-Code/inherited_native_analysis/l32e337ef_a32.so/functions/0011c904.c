/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c904 FUN_0011c904 */

void FUN_0011c904(char *param_1)

{
  int iVar1;
  int iVar2;
  
  if (*param_1 != '\0') {
    iVar2 = 0;
    do {
      iVar1 = iVar2 + 1;
      iVar2 = iVar2 + 1;
    } while (param_1[iVar1] != '\0');
    return;
  }
  return;
}

