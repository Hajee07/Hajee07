/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001169e4 FUN_001169e4 */

int FUN_001169e4(char *param_1,char *param_2,int param_3,int param_4,int param_5,uint param_6,
                code *param_7,int *param_8)

{
  bool bVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  code *pcVar6;
  int iVar7;
  void *__ptr;
  stat sStack_e0;
  undefined auStack_78 [20];
  int local_64;
  int local_60;
  int local_5c;
  int local_50;
  code *local_4c;
  undefined4 local_44;
  undefined4 *local_30;
  
  __aeabi_memclr8(auStack_78,0x50);
  if ((int)param_7 < 0) {
    param_7 = (code *)0x6;
  }
  if ((param_1 != (char *)0x0 && param_2 != (char *)0x0) && ((param_3 != 0 || (param_4 == 0)))) {
    uVar3 = param_6;
    if (param_6 != 0) {
      uVar3 = 1;
    }
    if (((param_5 == 0 & uVar3) == 0) && (((uint)param_7 & 0xf) < 0xb)) {
      if (*param_2 == '/') {
        if (param_8 != (int *)0x0) {
          *param_8 = 0x19;
        }
        return 0;
      }
      iVar4 = stat(param_1,&sStack_e0);
      if (iVar4 == 0) {
        iVar4 = FUN_0010cac4(auStack_78,param_1,(uint)param_7 | 0x800);
        if (iVar4 == 0) {
LAB_00116c18:
          if (param_8 != (int *)0x0) {
            *param_8 = local_5c;
          }
          return 0;
        }
        bVar1 = false;
        pcVar6 = param_7;
        iVar4 = FUN_00112190(auStack_78,param_1);
        puVar2 = local_30;
        if (iVar4 == 0) {
          if (param_8 != (int *)0x0) {
            *param_8 = local_5c;
          }
          if (local_30 == (undefined4 *)0x0) {
            return 0;
          }
          if (local_50 != 0) {
            pcVar6 = local_4c;
          }
          if (local_50 == 0 || pcVar6 == (code *)0x0) {
            return 0;
          }
          if (local_64 != 1) {
            return 0;
          }
          local_30 = (undefined4 *)0x0;
          (*pcVar6)(local_44,*puVar2);
          *puVar2 = 0;
          puVar2[1] = 0;
          puVar2[2] = 0;
          puVar2[3] = 0;
          (*local_4c)(local_44,puVar2[4]);
          puVar2[4] = 0;
          puVar2[5] = 0;
          puVar2[6] = 0;
          puVar2[7] = 0;
          (*local_4c)(local_44,puVar2[8]);
          __ptr = (void *)puVar2[0xf];
          puVar2[8] = 0;
          puVar2[9] = 0;
          puVar2[10] = 0;
          puVar2[0xb] = 0;
          if (__ptr != (void *)0x0) {
            if ((local_60 == 4) && (*(int *)((int)__ptr + 8) != 0)) {
              FUN_00120238();
              free(__ptr);
            }
            puVar2[0xf] = 0;
          }
          (*local_4c)(local_44,puVar2);
          return 0;
        }
      }
      else {
        iVar4 = FUN_00111de4(auStack_78,param_1,0,0,param_7);
        bVar1 = true;
        if (iVar4 == 0) goto LAB_00116c18;
      }
      iVar4 = FUN_001125a4(auStack_78,param_2,param_3,param_4,param_5,param_6,param_7);
      iVar7 = local_5c;
      iVar5 = FUN_001164ac(auStack_78);
      if ((iVar5 == 0) && (iVar4 = 0, iVar7 == 0)) {
        iVar7 = local_5c;
      }
      iVar5 = FUN_00111a30(auStack_78,iVar4);
      if (iVar5 == 0) {
        if (iVar7 != 0) {
          local_5c = iVar7;
        }
        iVar4 = 0;
        iVar7 = local_5c;
      }
      if ((bVar1) && (iVar4 == 0)) {
        remove(param_1);
      }
      if (param_8 != (int *)0x0) {
        *param_8 = iVar7;
      }
      return iVar4;
    }
  }
  if (param_8 != (int *)0x0) {
    *param_8 = 0x18;
  }
  return 0;
}

