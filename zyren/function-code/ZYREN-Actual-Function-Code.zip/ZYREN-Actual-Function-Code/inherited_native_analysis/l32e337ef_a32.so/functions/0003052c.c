/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003052c FUN_0003052c */

void FUN_0003052c(int *param_1)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  
  iVar1 = *param_1;
  iVar6 = iVar1 - param_1[2];
  if (*(short *)(iVar1 + 0x2c) != 0) {
    iVar3 = iVar1 + *(int *)(iVar1 + 0x1c);
    uVar4 = 0;
    do {
      if (*(int *)(iVar3 + (uint)uVar4 * 0x20) == 2) {
        param_1[3] = *(int *)(iVar3 + (uint)uVar4 * 0x20 + 8) + iVar6;
        break;
      }
      uVar4 = uVar4 + 1;
    } while (uVar4 != *(ushort *)(iVar1 + 0x2c));
  }
  puVar2 = (uint *)(param_1[3] + 4);
LAB_000305cc:
  uVar5 = puVar2[-1];
  switch(uVar5) {
  case 0:
    return;
  case 1:
  case 3:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x18:
    goto switchD_000305e8_caseD_1;
  case 2:
    param_1[0x14] = *puVar2 >> 3;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 4:
    param_1[0x10] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 5:
    param_1[10] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 6:
    param_1[0xb] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0xc:
    param_1[4] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x11:
    param_1[0x11] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x12:
    param_1[0x12] = *puVar2 >> 3;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x17:
    param_1[0x13] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x19:
    param_1[5] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x1a:
    param_1[8] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x1b:
    param_1[6] = *puVar2 >> 2;
  case 0xd:
    param_1[7] = *puVar2 + iVar6;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  case 0x1c:
    param_1[9] = *puVar2 >> 2;
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  default:
    if (uVar5 == 0x6ffffef5) break;
    if (uVar5 == 0x6ffffff0) {
      param_1[0xe] = *puVar2 + iVar6;
      goto switchD_000305e8_caseD_1;
    }
    if (uVar5 == 0x6ffffffe) {
      param_1[0xc] = *puVar2 + iVar6;
      puVar2 = puVar2 + 2;
      goto LAB_000305cc;
    }
switchD_000305e8_caseD_1:
    puVar2 = puVar2 + 2;
    goto LAB_000305cc;
  }
  param_1[0xf] = *puVar2 + iVar6;
  puVar2 = puVar2 + 2;
  goto LAB_000305cc;
}

