/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011185c FUN_0011185c */

undefined4 FUN_0011185c(int param_1,uint param_2,uint param_3,uint param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = 0;
  *(int *)(param_1 + 0x3c) = DAT_0011193c + 0x111880;
  *(undefined4 *)(param_1 + 0x40) = 0;
  if ((param_4 & 0x8000) != 0) {
    *(int *)(param_1 + 0x38) = DAT_00111940 + 0x11189c;
  }
  *(int *)(param_1 + 0x44) = param_1;
  iVar1 = FUN_00111500(param_1,param_2,param_2,0,param_4);
  if (iVar1 != 0) {
    if (param_2 < param_3) {
      param_2 = param_3;
    }
    *(undefined4 *)(param_1 + 0x18) = 3;
    if (param_2 == 0) {
      return 1;
    }
    uVar3 = 1;
    iVar1 = (**(code **)(param_1 + 0x28))(*(undefined4 *)(param_1 + 0x34),1,param_2);
    iVar2 = *(int *)(param_1 + 0x48);
    *(int *)(iVar2 + 0x48) = iVar1;
    if (iVar1 == 0) {
      FUN_00111a30(param_1,0);
      *(undefined4 *)(param_1 + 0x1c) = 0x10;
      return 0;
    }
    *(uint *)(iVar2 + 0x50) = param_2;
  }
  return uVar3;
}

