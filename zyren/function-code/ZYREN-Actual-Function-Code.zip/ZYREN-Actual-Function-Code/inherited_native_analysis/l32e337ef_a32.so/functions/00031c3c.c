/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031c3c FUN_00031c3c */

int FUN_00031c3c(undefined4 *param_1,char **param_2)

{
  uint uVar1;
  int local_30;
  int local_2c;
  int local_28;
  undefined4 local_24;
  undefined4 *local_20;
  undefined4 *local_1c;
  undefined4 *local_18;
  char **local_14;
  undefined4 *local_10;
  int local_c;
  
  if (**param_2 == '\0') {
    local_c = 0;
  }
  else {
    local_20 = (undefined4 *)0x0;
    local_24 = 0;
    local_18 = param_1;
    local_14 = param_2;
    local_10 = param_1;
    memset(&local_30,0,0xc);
    for (local_1c = (undefined4 *)*local_18; local_1c != local_18;
        local_1c = (undefined4 *)*local_1c) {
      if (((local_1c != local_20) &&
          (uVar1 = FUN_00031da0(local_1c,local_10 + 2,local_14,&local_30), (uVar1 & 1) != 0)) &&
         (local_30 != 0)) {
        return local_30;
      }
    }
    if (local_2c == 0) {
      if (local_28 == 0) {
        local_c = dlsym(0xffffffff,*local_14);
        if (local_c == 0) {
          local_c = 0;
        }
      }
      else {
        local_c = local_28;
      }
    }
    else {
      local_c = local_2c;
    }
  }
  return local_c;
}

