/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00105ca8 FUN_00105ca8 */

uint FUN_00105ca8(uint param_1,byte *param_2,uint param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  uint uVar5;
  byte *pbVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  param_1 = ~param_1;
  if (param_3 < 4) {
    if (param_3 == 0) goto LAB_00105d74;
  }
  else {
    uVar8 = param_3 - 4;
    uVar9 = uVar8 & 0xfffffffc;
    iVar7 = DAT_00105d80 + 0x105cd4;
    pbVar6 = param_2 + uVar9 + 4;
    do {
      bVar4 = *param_2;
      pbVar1 = param_2 + 1;
      param_3 = param_3 - 4;
      pbVar2 = param_2 + 2;
      pbVar3 = param_2 + 3;
      param_2 = param_2 + 4;
      uVar5 = *(uint *)(iVar7 + (param_1 & 0xff ^ (uint)bVar4) * 4) ^ param_1 >> 8;
      uVar5 = *(uint *)(iVar7 + (uVar5 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar5 >> 8;
      uVar5 = *(uint *)(iVar7 + (uVar5 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar5 >> 8;
      param_1 = *(uint *)(iVar7 + (uVar5 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar5 >> 8;
    } while (3 < param_3);
    param_3 = uVar8 - uVar9;
    param_2 = pbVar6;
    if (param_3 == 0) goto LAB_00105d74;
  }
  do {
    param_3 = param_3 - 1;
    param_1 = *(uint *)(DAT_00105d7c + 0x105d5c + (param_1 & 0xff ^ (uint)*param_2) * 4) ^
              param_1 >> 8;
    param_2 = param_2 + 1;
  } while (param_3 != 0);
LAB_00105d74:
  return ~param_1;
}

