/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010ab6c FUN_0010ab6c */

undefined4 FUN_0010ab6c(undefined4 param_1,int param_2,uint *param_3)

{
  size_t sVar1;
  uint __size;
  void *pvVar2;
  uint uVar3;
  uint uVar4;
  
  uVar3 = *param_3;
  __size = param_3[1];
  uVar4 = uVar3 + param_2;
  if (__size < uVar4) {
    if (param_3[3] == 0) {
      return 0;
    }
    do {
      sVar1 = 0x80;
      if (0x80 < __size * 2) {
        sVar1 = __size << 1;
      }
      __size = sVar1;
    } while (__size < uVar4);
    pvVar2 = realloc((void *)param_3[2],__size);
    if (pvVar2 == (void *)0x0) {
      return 0;
    }
    uVar3 = *param_3;
    param_3[1] = __size;
    param_3[2] = (uint)pvVar2;
  }
  else {
    pvVar2 = (void *)param_3[2];
  }
  __aeabi_memcpy((int)pvVar2 + uVar3,param_1,param_2);
  *param_3 = uVar4;
  return 1;
}

