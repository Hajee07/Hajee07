/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00120280 FUN_00120280 */

char FUN_00120280(void)

{
  int iVar1;
  char cVar2;
  int __fd;
  ssize_t sVar3;
  char *pcVar4;
  bool bVar5;
  undefined auStack_50 [18];
  short local_3e;
  
  iVar1 = DAT_0012033c;
  pcVar4 = (char *)(DAT_0012033c + 0x120298);
  if (*pcVar4 == '\x01') {
    cVar2 = *(char *)(DAT_0012033c + 0x120299);
    if (cVar2 != '\0') {
      cVar2 = '\x01';
    }
    return cVar2;
  }
  bVar5 = false;
  __fd = open((char *)(DAT_00120340 + 0x1202c8),0);
  __aeabi_memclr8(auStack_50,0x34);
  sVar3 = read(__fd,auStack_50,0x34);
  if (-1 < sVar3) {
    bVar5 = local_3e == 3 || local_3e == 0x3e;
  }
  *(bool *)(iVar1 + 0x120299) = bVar5;
  close(__fd);
  cVar2 = *(char *)(iVar1 + 0x120299);
  *pcVar4 = '\x01';
  if (cVar2 != '\0') {
    cVar2 = '\x01';
  }
  return cVar2;
}

