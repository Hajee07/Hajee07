/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d65c FUN_0021d65c */

undefined * FUN_0021d65c(undefined *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  char local_21;
  
  if (param_1 != (undefined *)0x0) {
    iVar2 = param_2 + -1;
    if (1 < param_2) {
      iVar3 = 0;
      do {
        iVar1 = iVar2;
        if (iVar2 == iVar3) break;
        iVar1 = thunk_FUN_0005b70c(param_3,&local_21,1);
        if (iVar1 == -1) {
          return (undefined *)0x0;
        }
        if (iVar1 == 0) {
          iVar1 = iVar3;
          if (iVar3 == 0) {
            return (undefined *)0x0;
          }
          break;
        }
        param_1[iVar3] = local_21;
        iVar3 = iVar3 + 1;
        iVar1 = iVar3;
      } while (local_21 != '\n');
      param_1[iVar1] = 0;
      return param_1;
    }
    if (iVar2 == 0) {
      *param_1 = 0;
      return param_1;
    }
  }
  return (undefined *)0x0;
}

