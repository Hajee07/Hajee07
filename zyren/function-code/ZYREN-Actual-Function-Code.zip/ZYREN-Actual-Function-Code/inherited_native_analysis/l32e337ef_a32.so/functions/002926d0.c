/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002926d0 pwrite */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ssize_t pwrite(int __fd,void *__buf,size_t __n,__off_t __offset)

{
  ssize_t sVar1;
  
  sVar1 = (*(code *)PTR_pwrite_00307dc4)();
  return sVar1;
}

