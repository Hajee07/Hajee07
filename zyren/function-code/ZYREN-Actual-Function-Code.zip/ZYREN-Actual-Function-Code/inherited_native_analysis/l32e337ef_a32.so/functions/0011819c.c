/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011819c FUN_0011819c */

undefined4 FUN_0011819c(int param_1,byte *param_2,uint param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  uint *puVar9;
  uint uVar10;
  uint unaff_r9;
  uint local_28;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  local_28 = unaff_r9;
  if (param_2 != (byte *)0x0) {
    local_28 = param_3;
  }
  if (param_2 == (byte *)0x0 || param_3 == 0) {
    return 0;
  }
  uVar6 = *(uint *)(param_1 + 0x60);
  *(uint *)(param_1 + 0x60) = uVar6 + local_28;
  *(uint *)(param_1 + 100) = *(int *)(param_1 + 100) + (uint)CARRY4(uVar6,local_28);
  uVar7 = ~*(uint *)(param_1 + 0x70);
  iVar5 = DAT_0011835c + 0x118204;
  uVar6 = local_28;
  pbVar8 = param_2;
  if (3 < local_28) {
    uVar10 = local_28 - 4 & 0xfffffffc;
    do {
      bVar4 = *pbVar8;
      pbVar1 = pbVar8 + 1;
      uVar6 = uVar6 - 4;
      pbVar2 = pbVar8 + 2;
      pbVar3 = pbVar8 + 3;
      pbVar8 = pbVar8 + 4;
      uVar7 = *(uint *)(iVar5 + (uVar7 & 0xff ^ (uint)bVar4) * 4) ^ uVar7 >> 8;
      uVar7 = *(uint *)(iVar5 + (uVar7 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar7 >> 8;
      uVar7 = *(uint *)(iVar5 + (uVar7 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar7 >> 8;
      uVar7 = *(uint *)(iVar5 + (uVar7 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar7 >> 8;
    } while (3 < uVar6);
    uVar6 = (local_28 - 4) - uVar10;
    if (uVar6 == 0) goto LAB_001182bc;
    pbVar8 = param_2 + uVar10 + 4;
  }
  do {
    uVar6 = uVar6 - 1;
    uVar7 = *(uint *)(iVar5 + (uVar7 & 0xff ^ (uint)*pbVar8) * 4) ^ uVar7 >> 8;
    pbVar8 = pbVar8 + 1;
  } while (uVar6 != 0);
LAB_001182bc:
  *(uint *)(param_1 + 0x70) = ~uVar7;
  if ((*(byte *)(param_1 + 0x50) & 0xf) != 0) {
    uVar6 = FUN_001067f4(param_1 + 200,param_2,&local_28,0,0,0);
    if (uVar6 < 2) {
      return 0;
    }
    return 0xfffffff4;
  }
  puVar9 = (uint *)(param_1 + 0x78);
  uVar6 = (**(code **)(param_1 + 0x3c))
                    (*(undefined4 *)(param_1 + 0x44),param_2,*puVar9,*(undefined4 *)(param_1 + 0x7c)
                     ,param_2,local_28);
  if (uVar6 == local_28) {
    uVar6 = *puVar9;
    *puVar9 = uVar6 + local_28;
    *(uint *)(param_1 + 0x7c) = *(int *)(param_1 + 0x7c) + (uint)CARRY4(uVar6,local_28);
    uVar6 = *(uint *)(param_1 + 0x68);
    *(uint *)(param_1 + 0x68) = uVar6 + local_28;
    *(uint *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + (uint)CARRY4(uVar6,local_28);
    return 0;
  }
  return 0xfffffff8;
}

