/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010a934 FUN_0010a934 */

bool FUN_0010a934(int param_1,uint param_2,int param_3,int param_4,uint param_5)

{
  uint uVar1;
  int *__ptr;
  int iVar2;
  bool bVar3;
  uint local_28;
  
  uVar1 = param_2;
  if (param_2 != 0) {
    uVar1 = 1;
  }
  bVar3 = false;
  if ((((param_1 == 0 & uVar1) == 0) && (param_3 != 0)) &&
     (__ptr = (int *)malloc(0x4df40), __ptr != (int *)0x0)) {
    *__ptr = param_3;
    __ptr[1] = param_4;
    __ptr[2] = param_5;
    __ptr[3] = ((param_5 & 0xfff) + 2) / 3 + 1;
    __ptr[4] = (((param_5 & 0xfff) >> 2) + 2) / 3 + 1;
    __ptr[5] = (param_5 << 0x11) >> 0x1f;
    if ((param_5 & 0x8000) == 0) {
      __aeabi_memclr(&DAT_00029272 + (int)__ptr,0x10000);
    }
    __ptr[8] = 0;
    __ptr[9] = 0;
    __ptr[0xf] = 0;
    __ptr[7] = 0;
    __ptr[0x10] = 0;
    __ptr[0x11] = 0;
    __ptr[0x12] = 0;
    __ptr[0x16] = 0;
    __ptr[0x17] = 0;
    __ptr[0x18] = 0;
    __ptr[0x19] = 0;
    __ptr[0x1a] = 0;
    *(undefined *)((int)__ptr + 0x9272) = 0;
    __ptr[0xb] = (int)(undefined *)((int)__ptr + 0x9272);
    __ptr[10] = (int)__ptr + 0x9273;
    __ptr[0xe] = 8;
    __ptr[0x1b] = 0;
    __ptr[0xd] = (int)(&UNK_00039272 + (int)__ptr);
    __ptr[0xc] = (int)(&UNK_00039272 + (int)__ptr);
    __ptr[0x14] = 0;
    __ptr[0x15] = 0;
    __ptr[0x13] = 0;
    __ptr[0x1c] = 0;
    __ptr[6] = 1;
    __ptr[0x1d] = 0;
    __ptr[0x1e] = 0;
    __ptr[0x1f] = 0;
    __ptr[0x20] = 0;
    __ptr[0x21] = 0;
    __ptr[0x22] = 0;
    __ptr[0x23] = 0;
    if ((param_5 & 0x8000) == 0) {
      __aeabi_memclr4(__ptr + 0x24,0x8101);
    }
    __aeabi_memclr((int)__ptr + 0x8192,0x280);
    local_28 = param_2;
    iVar2 = FUN_001067f4(__ptr,param_1,&local_28,0,0,4);
    free(__ptr);
    bVar3 = iVar2 == 1;
  }
  return bVar3;
}

