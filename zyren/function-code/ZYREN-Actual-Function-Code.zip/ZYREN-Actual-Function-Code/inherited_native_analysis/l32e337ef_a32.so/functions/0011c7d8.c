/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c7d8 FUN_0011c7d8 */

undefined4 FUN_0011c7d8(undefined4 param_1)

{
  FILE *__stream;
  char *pcVar1;
  int iVar2;
  undefined4 uVar3;
  ulonglong uVar4;
  undefined4 local_430;
  undefined4 local_42c;
  undefined4 local_428;
  undefined4 local_424;
  char acStack_420 [1024];
  
  __aeabi_memclr8(acStack_420,0x400);
  uVar3 = 0;
  local_424 = 0;
  local_428 = 0;
  local_42c = 0;
  local_430 = 0;
  thunk_FUN_000f41c4(&local_430,DAT_0011c8fc + 0x11c81f,0x10);
  __stream = fopen((char *)&local_430,(char *)(DAT_0011c900 + 0x11c838));
  pcVar1 = fgets(acStack_420,0x400,__stream);
  if (pcVar1 != (char *)0x0) {
    iVar2 = FUN_0011c904(acStack_420);
    if (iVar2 != 0) goto LAB_0011c890;
    do {
      do {
        pcVar1 = fgets(acStack_420,0x400,__stream);
        if (pcVar1 == (char *)0x0) goto LAB_0011c8e0;
        iVar2 = FUN_0011c904(acStack_420);
      } while (iVar2 == 0);
LAB_0011c890:
      pcVar1 = strrchr(acStack_420,0x2f);
    } while ((pcVar1 == (char *)0x0) || (iVar2 = FUN_0011c930(pcVar1,param_1), iVar2 == 0));
    pcVar1 = strchr(acStack_420,0x2d);
    *pcVar1 = '\0';
    uVar4 = strtoull(acStack_420,(char **)0x0,0x10);
    uVar3 = (undefined4)uVar4;
  }
LAB_0011c8e0:
  if (__stream != (FILE *)0x0) {
    fclose(__stream);
  }
  return uVar3;
}

