/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001170fc FUN_001170fc */

int FUN_001170fc(int param_1,uint param_2,undefined *param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  uint unaff_r5;
  uint uVar4;
  bool bVar5;
  
  if (param_1 != 0) {
    piVar3 = *(int **)(param_1 + 0x48);
    bVar5 = piVar3 == (int *)0x0;
    if (!bVar5) {
      unaff_r5 = *(uint *)(param_1 + 0x10);
    }
    if (((bVar5 || param_2 <= unaff_r5) && (!bVar5 && unaff_r5 != param_2)) &&
       (iVar2 = *piVar3 + *(int *)(piVar3[4] + param_2 * 4), iVar2 != 0)) {
      uVar1 = (uint)*(ushort *)(iVar2 + 0x1c);
      if (param_4 != 0) {
        uVar4 = param_4 - 1U;
        if (uVar1 < param_4 - 1U) {
          uVar4 = uVar1;
        }
        __aeabi_memcpy(param_3,iVar2 + 0x2e,uVar4);
        param_3[uVar4] = 0;
        uVar1 = uVar4;
      }
      return uVar1 + 1;
    }
  }
  if (param_4 != 0) {
    *param_3 = 0;
  }
  if (param_1 == 0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0x1c) = 0x18;
  return 0;
}

