/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010e4e4 FUN_0010e4e4 */

int FUN_0010e4e4(int param_1,uint param_2,uint *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  undefined auStack_478 [32];
  uint auStack_458 [2];
  uint auStack_450 [267];
  
  if (param_3 != (uint *)0x0) {
    *param_3 = 0;
  }
  iVar4 = 0;
  if (param_1 != 0) {
    piVar1 = *(int **)(param_1 + 0x48);
    iVar4 = 0;
    if ((piVar1 != (int *)0x0) && (iVar4 = 0, param_2 < *(uint *)(param_1 + 0x10))) {
      iVar4 = *piVar1 + *(int *)(piVar1[4] + param_2 * 4);
    }
  }
  iVar4 = FUN_001107b8(param_1,param_2,iVar4,auStack_478,0);
  if (iVar4 != 0) {
    puVar3 = auStack_458;
    if ((param_4 & 0x400) == 0) {
      puVar3 = auStack_450;
    }
    uVar5 = *puVar3;
    if (puVar3[1] == 0 && (uint)(0x7fffffff < uVar5) <= puVar3[1]) {
      iVar4 = (**(code **)(param_1 + 0x28))(*(undefined4 *)(param_1 + 0x34),1,uVar5);
      if (iVar4 == 0) {
        *(undefined4 *)(param_1 + 0x1c) = 0x10;
        return 0;
      }
      iVar2 = FUN_0010dc40(param_1,param_2,iVar4,uVar5,param_4,0,0,auStack_478);
      if (iVar2 == 0) {
        (**(code **)(param_1 + 0x2c))(*(undefined4 *)(param_1 + 0x34),iVar4);
        return 0;
      }
      if (param_3 != (uint *)0x0) {
        *param_3 = uVar5;
      }
      return iVar4;
    }
    if (param_1 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 0x1b;
    }
  }
  return 0;
}

