/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011535c FUN_0011535c */

undefined4
FUN_0011535c(int param_1,undefined4 param_2,char *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  char *pcVar2;
  char **__ptr;
  char *pcVar3;
  undefined4 uVar4;
  int iVar5;
  ulong local_94;
  stat sStack_90;
  
  local_94 = 0;
  iVar1 = stat(param_3,&sStack_90);
  if (iVar1 != 0) {
    if (param_1 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 0x17;
    }
    return 0;
  }
  local_94 = sStack_90.__unused4;
  pcVar2 = (char *)FUN_001201d4(param_3,0);
  if (-1 < (int)pcVar2) {
    __ptr = (char **)malloc(0xc);
    pcVar3 = strdup(param_3);
    *__ptr = pcVar3;
    __ptr[1] = (char *)0x0;
    __ptr[2] = pcVar2;
    if (__ptr != (char **)0x0) {
      iVar1 = -1;
      if (pcVar2 == (char *)0x0) {
        iVar5 = -1;
      }
      else {
        FUN_00120364(pcVar2,0,2);
        iVar5 = -1;
        if (__ptr[2] != (char *)0x0) {
          uVar4 = FUN_00120364(__ptr[2],0,1);
          iVar1 = FUN_00120364(__ptr[2],0,2);
          FUN_00120364(__ptr[2],uVar4,0);
          iVar5 = iVar1 >> 0x1f;
          if (__ptr[2] != (char *)0x0) {
            FUN_00120364(__ptr[2],0,0);
          }
        }
      }
      uVar4 = FUN_00113dc8(param_1,param_2,DAT_00115508 + 0x1154ac,__ptr,iVar1,iVar5,&local_94,
                           param_4,param_5,param_6,param_7,0,0,0,0);
      if (__ptr[2] != (char *)0x0) {
        FUN_00120238();
        free(__ptr);
      }
      return uVar4;
    }
  }
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x1c) = 0x11;
  }
  return 0;
}

