/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00113770 FUN_00113770 */

bool FUN_00113770(undefined4 param_1,uint param_2,int *param_3)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint *puVar5;
  
  puVar5 = (uint *)(param_3 + 2);
  uVar3 = *(undefined4 *)(*param_3 + 0x44);
  uVar1 = (**(code **)(*param_3 + 0x3c))(uVar3,uVar3,*puVar5,param_3[3],param_1,param_2);
  if (uVar1 == param_2) {
    uVar2 = *puVar5;
    uVar4 = param_3[4];
    *puVar5 = uVar2 + param_2;
    param_3[3] = param_3[3] + ((int)param_2 >> 0x1f) + (uint)CARRY4(uVar2,param_2);
    param_3[4] = uVar4 + param_2;
    param_3[5] = param_3[5] + ((int)param_2 >> 0x1f) + (uint)CARRY4(uVar4,param_2);
  }
  return uVar1 == param_2;
}

