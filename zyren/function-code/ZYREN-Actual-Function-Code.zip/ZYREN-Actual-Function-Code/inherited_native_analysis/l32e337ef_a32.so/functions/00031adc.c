/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031adc FUN_00031adc */

undefined4 * FUN_00031adc(undefined4 *param_1,uint param_2)

{
  undefined4 *local_14;
  
  local_14 = (undefined4 *)*param_1;
  while( true ) {
    if (local_14 == param_1) {
      return (undefined4 *)0x0;
    }
    if (((uint)local_14[2] <= param_2) && (param_2 < (uint)(local_14[2] + local_14[4]))) break;
    local_14 = (undefined4 *)*local_14;
  }
  return local_14;
}

