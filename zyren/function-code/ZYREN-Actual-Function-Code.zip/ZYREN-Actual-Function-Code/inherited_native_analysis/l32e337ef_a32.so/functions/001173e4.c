/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001173e4 FUN_001173e4 */

undefined4 FUN_001173e4(uint *param_1,char *param_2,int param_3)

{
  short sVar1;
  short sVar2;
  uint uVar3;
  size_t sVar4;
  void *pvVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  tm *ptVar10;
  undefined *puVar11;
  uint uVar12;
  uint uVar13;
  size_t sVar14;
  char cVar15;
  undefined uVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  undefined4 uVar20;
  uint uVar21;
  uint uVar22;
  uint *puVar23;
  bool bVar24;
  uint *puVar25;
  undefined auStack_1480 [8];
  uint local_1478;
  uint uStack_1474;
  undefined2 local_146a;
  uint local_1468;
  uint local_1464;
  uint local_1460;
  uint uStack_145c;
  uint local_1458;
  uint uStack_1454;
  uint local_144c;
  uint local_1448;
  uint uStack_1444;
  uint local_1030;
  undefined local_102c;
  undefined local_102b;
  undefined local_102a;
  undefined local_1029;
  undefined local_1028;
  undefined local_1027;
  undefined local_1026;
  undefined local_1025;
  undefined auStack_1024 [4088];
  uint local_2c [2];
  
  if (param_1 == (uint *)0x0) {
    return 0xffffffff;
  }
  uVar3 = *param_1;
  uVar12 = param_1[1];
  if (param_2 == (char *)0x0) {
    return 0xfffffffe;
  }
  sVar4 = strlen(param_2);
  if (sVar4 == 0) {
    return 0xfffffffe;
  }
  if ((void *)param_1[0x17] != (void *)0x0) {
    free((void *)param_1[0x17]);
    param_1[0x17] = 0;
  }
  pvVar5 = calloc(sVar4 + 1,1);
  if (pvVar5 == (void *)0x0) {
    param_1[0x17] = 0;
    return 0xfffffffe;
  }
  puVar25 = param_1 + 0x28;
  puVar23 = param_1 + 0x1e;
  sVar14 = 0;
  cVar15 = *param_2;
  do {
    if (cVar15 == '\\') {
      cVar15 = '/';
    }
    else if (cVar15 == '\0') break;
    *(char *)((int)pvVar5 + sVar14) = cVar15;
    sVar14 = sVar14 + 1;
    if (sVar4 == sVar14) break;
    cVar15 = param_2[sVar14];
  } while( true );
  param_1[0x17] = (uint)pvVar5;
  if (pvVar5 == (void *)0x0) {
    return 0xfffffffe;
  }
  if (param_1[5] == 1) {
    if (param_3 != 0) {
      param_3 = 1;
    }
    uVar3 = 0;
    iVar18 = 0;
    iVar6 = FUN_0010d5e8(param_1,pvVar5,0,param_3 << 8,&local_1030);
    uVar12 = local_1030;
    if (iVar6 == 0) {
      uVar12 = 0xffffffff;
    }
    uVar20 = 0xfffffffd;
    param_1[0x16] = uVar12;
    if (-1 < (int)uVar12) {
      piVar7 = (int *)param_1[0x12];
      bVar24 = piVar7 == (int *)0x0;
      if (!bVar24) {
        uVar3 = param_1[4];
      }
      if ((bVar24 || uVar12 <= uVar3) && (!bVar24 && uVar3 != uVar12)) {
        iVar18 = *piVar7 + *(int *)(piVar7[4] + uVar12 * 4);
      }
      iVar6 = FUN_001107b8(param_1,uVar12,iVar18,auStack_1480,0);
      if (iVar6 != 0) {
        param_1[0x1a] = local_1460;
        param_1[0x1b] = uStack_145c;
        param_1[0x18] = local_1458;
        param_1[0x19] = uStack_1454;
        param_1[0x1c] = local_1464;
        *puVar23 = local_1478;
        param_1[0x1f] = uStack_1474;
        *puVar25 = local_1448;
        param_1[0x29] = uStack_1444;
        *(undefined2 *)(param_1 + 0x2a) = local_146a;
        param_1[0x13802] = local_144c;
        param_1[0x13803] = local_1468;
        return 0;
      }
    }
  }
  else {
    uVar22 = 0;
    uVar19 = *param_1;
    uVar21 = param_1[1];
    param_1[0x18] = 0;
    uVar13 = param_1[0x14] & 0xf;
    param_1[0x19] = 0;
    param_1[0x1a] = 0;
    param_1[0x1b] = 0;
    param_1[0x1c] = 0;
    param_1[0x16] = param_1[4];
    *puVar23 = uVar19;
    param_1[0x1f] = uVar21;
    uVar17 = uVar13;
    if (uVar13 != 0) {
      uVar17 = 1;
    }
    *puVar25 = uVar19;
    param_1[0x29] = uVar21;
    param_1[0x20] = 0;
    *(undefined2 *)(param_1 + 0x27) = 0;
    *(short *)(param_1 + 0x2a) = (short)(uVar17 << 3);
    param_1[0x21] = 0;
    param_1[0x22] = 0;
    param_1[0x23] = 0;
    param_1[0x24] = 0;
    param_1[0x25] = 0;
    param_1[0x26] = 0;
    param_1[0x13802] = 0;
    uVar8 = param_1[8];
    uVar17 = uVar8 | param_1[9];
    bVar24 = uVar17 != 0;
    if (bVar24) {
      uVar17 = uVar8 - 1;
      uVar8 = uVar8 - (uVar19 & uVar17);
    }
    uVar20 = 0xfffffffc;
    if (bVar24) {
      uVar22 = uVar8 & uVar17;
    }
    if (((param_1[5] == 2) && (param_1[0x12] != 0)) &&
       (uVar20 = 0xfffffffb, (param_1[0x14] & 0x400) == 0)) {
      uVar17 = 0x1000;
      if (uVar22 < 0x1000) {
        uVar17 = uVar22;
      }
      __aeabi_memclr8(&local_1030,uVar17);
      for (uVar17 = uVar22; uVar17 != 0; uVar17 = uVar17 - uVar8) {
        uVar8 = 0x1000;
        if (uVar17 < 0x1000) {
          uVar8 = uVar17;
        }
        uVar9 = (*(code *)param_1[0xf])
                          (param_1[0x11],(code *)param_1[0xf],uVar19,uVar21,&local_1030,uVar8);
        if (uVar9 != uVar8) {
          uVar20 = 0xfffffff9;
          param_1[7] = 0x13;
          goto LAB_00117ac0;
        }
        bVar24 = CARRY4(uVar19,uVar8);
        uVar19 = uVar19 + uVar8;
        uVar21 = uVar21 + bVar24;
      }
      uVar19 = uVar3 + uVar22;
      uVar12 = uVar12 + CARRY4(uVar3,uVar22);
      local_2c[0] = time((time_t *)0x0);
      param_1[0x13803] = local_2c[0];
      ptVar10 = localtime((time_t *)local_2c);
      iVar18 = ptVar10->tm_min * 0x20 + ptVar10->tm_hour * 0x800 + ((uint)ptVar10->tm_sec >> 1);
      iVar6 = ptVar10->tm_year * 0x200 + ptVar10->tm_mon * 0x20 + ptVar10->tm_mday + 0x6020;
      if (uVar12 == 0 && (0xfffffffe < uVar19) <= uVar12) {
        uVar16 = 0;
        puVar11 = &local_102c;
      }
      else {
        local_102c = (undefined)uVar19;
        local_1028 = (undefined)uVar12;
        uVar16 = 8;
        local_1029 = (undefined)(uVar19 >> 0x18);
        local_102a = (undefined)(uVar19 >> 0x10);
        local_102b = (undefined)(uVar19 >> 8);
        local_1025 = (undefined)(uVar12 >> 0x18);
        local_1026 = (undefined)(uVar12 >> 0x10);
        local_1027 = (undefined)(uVar12 >> 8);
        puVar11 = auStack_1024;
      }
      uVar3 = (int)puVar11 - (int)&local_1030;
      local_1030 = (uint)CONCAT12(uVar16,1);
      *(undefined4 *)((int)param_1 + 0x8e) = 0;
      *(char *)((int)param_1 + 0x8d) = (char)((uint)iVar6 >> 8);
      *(char *)(param_1 + 0x23) = (char)iVar6;
      *(char *)((int)param_1 + 0x8b) = (char)((uint)iVar18 >> 8);
      *(char *)((int)param_1 + 0x8a) = (char)iVar18;
      *(undefined *)((int)param_1 + 0x87) = 8;
      *(undefined2 *)((int)param_1 + 0x85) = 0x800;
      param_1[0x20] = 0x4034b50;
      *(undefined4 *)((int)param_1 + 0x92) = 0;
      *(undefined4 *)((int)param_1 + 0x96) = 0;
      *(char *)(param_1 + 0x27) = (char)uVar3;
      sVar1 = *(short *)(param_1 + 0x2a);
      *(char *)((int)param_1 + 0x9b) = (char)(sVar4 >> 8);
      *(char *)((int)param_1 + 0x9a) = (char)sVar4;
      *(char *)(param_1 + 0x22) = (char)sVar1;
      *(char *)((int)param_1 + 0x9d) = (char)(uVar3 >> 8);
      sVar2 = sVar1;
      if (sVar1 != 0) {
        sVar2 = 0x14;
      }
      *(char *)((int)param_1 + 0x89) = (char)((ushort)sVar1 >> 8);
      *(char *)(param_1 + 0x21) = (char)sVar2;
      *puVar25 = *puVar23 + uVar22;
      param_1[0x29] = param_1[0x1f] + (uint)CARRY4(*puVar23,uVar22);
      iVar6 = (*(code *)param_1[0xf])(param_1[0x11]);
      uVar20 = 0xfffffff9;
      if (iVar6 == 0x1e) {
        uVar12 = *puVar23;
        *puVar23 = uVar12 + uVar22 + 0x1e;
        param_1[0x1f] = param_1[0x1f] + (uint)CARRY4(uVar12,uVar22 + 0x1e);
        sVar14 = (*(code *)param_1[0xf])(param_1[0x11]);
        uVar20 = 0xfffffff8;
        if (sVar14 == sVar4) {
          uVar12 = *puVar23;
          puVar25 = &local_1030;
          *puVar23 = uVar12 + sVar4;
          param_1[0x1f] = param_1[0x1f] + (uint)CARRY4(uVar12,sVar4);
          uVar12 = uVar3;
          uVar19 = (*(code *)param_1[0xf])(param_1[0x11]);
          if (uVar19 == uVar3) {
            uVar19 = *puVar23 + uVar3;
            uVar3 = param_1[0x1f] + (uint)CARRY4(*puVar23,uVar3);
            *puVar23 = uVar19;
            param_1[0x1f] = uVar3;
            if (uVar13 == 0) {
              return 0;
            }
            iVar6 = DAT_00117af8 + 0x117988;
            uVar21 = uVar13;
            if (9 < uVar13) {
              uVar21 = 10;
            }
            param_1[0x2c] = (uint)param_1;
            uVar17 = *(uint *)(iVar6 + uVar21 * 4);
            uVar21 = uVar17;
            if (uVar13 < 4) {
              uVar21 = uVar17 | 0x4000;
            }
            uVar17 = uVar17 & 0xfff;
            uVar13 = DAT_00117afc + 0x1179c4;
            param_1[0x2e] = uVar19;
            param_1[0x2f] = uVar3;
            param_1[0x30] = 0;
            param_1[0x31] = 0;
            param_1[0x33] = (uint)(param_1 + 0x2c);
            param_1[0x32] = uVar13;
            param_1[0x34] = uVar21;
            param_1[0x37] = (uVar21 << 0x11) >> 0x1f;
            param_1[0x35] = (uVar17 + 2) / 3 + 1;
            param_1[0x36] = ((uVar17 >> 2) + 2) / 3 + 1;
            __aeabi_memclr(&UNK_0002933a + (int)param_1,0x10000,uVar21,uVar17,puVar25,uVar12);
            *(undefined *)((int)param_1 + 0x933a) = 0;
            param_1[0x48] = 0;
            param_1[0x49] = 0;
            param_1[0x4a] = 0;
            param_1[0x4b] = 0;
            param_1[0x4c] = 0;
            param_1[0x4d] = 0;
            param_1[0x42] = 0;
            param_1[0x43] = 0;
            param_1[0x44] = 0;
            param_1[0x45] = 0;
            param_1[0x46] = 0;
            param_1[0x47] = 0;
            param_1[0x38] = 1;
            param_1[0x39] = 0;
            param_1[0x3a] = 0;
            param_1[0x3b] = 0;
            param_1[0x3c] = (int)param_1 + 0x933b;
            param_1[0x3d] = (uint)(undefined *)((int)param_1 + 0x933a);
            param_1[0x3e] = (uint)(&UNK_0003933a + (int)param_1);
            param_1[0x3f] = (uint)(&UNK_0003933a + (int)param_1);
            param_1[0x40] = 8;
            param_1[0x41] = 0;
            __aeabi_memclr((int)param_1 + 0x825a,0x280);
            __aeabi_memclr4(param_1 + 0x4e,0x8121);
            return 0;
          }
        }
      }
    }
  }
LAB_00117ac0:
  if ((void *)param_1[0x17] != (void *)0x0) {
    free((void *)param_1[0x17]);
    param_1[0x17] = 0;
  }
  return uVar20;
}

