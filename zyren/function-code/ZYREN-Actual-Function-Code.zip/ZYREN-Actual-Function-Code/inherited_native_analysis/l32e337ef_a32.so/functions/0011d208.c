/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011d208 FUN_0011d208 */

void FUN_0011d208(char *param_1,char *param_2)

{
  char cVar1;
  
  do {
    cVar1 = *param_1;
    if (cVar1 != *param_2) {
      return;
    }
    param_1 = param_1 + 1;
    if (cVar1 == '\0') {
      param_1 = (char *)0x0;
    }
    param_2 = param_2 + 1;
  } while (cVar1 != '\0');
  return;
}

