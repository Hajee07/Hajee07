/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00116d28 FUN_00116d28 */

int FUN_00116d28(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4,uint param_5,
                undefined4 *param_6)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  void *__ptr;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined auStack_78 [20];
  int local_64;
  int local_60;
  undefined4 local_5c;
  int local_50;
  undefined4 *local_4c;
  undefined4 local_44;
  undefined4 *local_30;
  undefined4 local_28;
  
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = 0;
  }
  if (param_1 == 0 || param_2 == 0) {
    if (param_6 == (undefined4 *)0x0) {
      return 0;
    }
    *param_6 = 0x18;
    return 0;
  }
  __aeabi_memclr8(auStack_78,0x50);
  iVar3 = 0;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0;
  iVar2 = FUN_0010cac4(auStack_78,param_1,param_5 | 0x800);
  if (iVar2 == 0) {
    iVar3 = 0;
    if (param_6 == (undefined4 *)0x0) {
      return 0;
    }
    goto LAB_00116e50;
  }
  iVar2 = FUN_0010d5e8(auStack_78,param_2,param_3,param_5,&local_28,uVar4,uVar5,uVar6);
  if (iVar2 != 0) {
    iVar3 = FUN_0010e4e4(auStack_78,local_28,param_4,param_5);
    param_3 = param_4;
  }
  puVar1 = local_30;
  if (local_30 == (undefined4 *)0x0) {
LAB_00116e1c:
    if (iVar3 != 0) {
      local_5c = 0x18;
    }
  }
  else {
    if (local_50 != 0) {
      param_3 = local_4c;
    }
    if ((local_50 == 0 || param_3 == (undefined4 *)0x0) || (local_64 != 1)) goto LAB_00116e1c;
    local_30 = (undefined4 *)0x0;
    (*(code *)param_3)(local_44,*puVar1);
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    (*(code *)local_4c)(local_44,puVar1[4]);
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    (*(code *)local_4c)(local_44,puVar1[8]);
    __ptr = (void *)puVar1[0xf];
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    puVar1[0xb] = 0;
    if (__ptr != (void *)0x0) {
      if (local_60 == 4) {
        if (*(int *)((int)__ptr + 8) != 0) {
          iVar2 = FUN_00120238();
          free(__ptr);
          if (iVar2 != -1) goto LAB_00116f1c;
        }
        if (iVar3 != 0) {
          local_5c = 0x15;
        }
      }
LAB_00116f1c:
      puVar1[0xf] = 0;
    }
    (*(code *)local_4c)(local_44,puVar1);
  }
  if (param_6 == (undefined4 *)0x0) {
    return iVar3;
  }
LAB_00116e50:
  *param_6 = local_5c;
  return iVar3;
}

