/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031a10 FUN_00031a10 */

void FUN_00031a10(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  *(int *)param_1 = param_1;
  *(int *)(param_1 + 4) = param_1;
  FUN_000d2780(param_1);
  iVar1 = DAT_00031a78;
  iVar2 = DAT_00031a74 + 0x31a4c;
  uVar3 = *(undefined4 *)(DAT_00031a7c + 0x31a5c);
  *(undefined4 *)(DAT_00031a78 + 0x31a68) = *(undefined4 *)(DAT_00031a80 + 0x31a64);
  *(undefined4 *)((int)&DAT_00031a74 + iVar1) = uVar3;
  *(int *)((int)&DAT_00031a80 + iVar1) = iVar2;
  return;
}

