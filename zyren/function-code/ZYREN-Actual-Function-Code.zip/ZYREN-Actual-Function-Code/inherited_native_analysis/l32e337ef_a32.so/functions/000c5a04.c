/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000c5a04 thunk_FUN_0022edb0 */

void thunk_FUN_0022edb0(void)

{
  thunk_FUN_00150308();
                    /* WARNING: Could not recover jumptable at 0x0022eddc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_0022edc4 + *(int *)(&UNK_0022f090 + DAT_0022edc4) + DAT_0022edc4))();
  return;
}

