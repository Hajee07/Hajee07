/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011dc54 FUN_0011dc54 */

undefined4 FUN_0011dc54(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined2 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined2 local_28;
  
  local_28 = 0;
  local_2c = 0;
  local_30 = 0;
  local_34 = 0;
  local_38 = 0;
  thunk_FUN_000f41c4(&local_38,DAT_0011de1c + 0x11dc8a,0x12);
  local_3c = 0;
  local_40 = 0;
  thunk_FUN_000f41c4(&local_40,DAT_0011de20 + 0x11dd0d,6);
  local_44 = 0;
  local_48 = 0;
  local_4c = 0;
  local_50 = 0;
  local_54 = 0;
  local_58 = 0;
  local_5c = 0;
  local_60 = 0;
  if (*(int *)(DAT_0011de24 + 0x11dce4) == 0) {
    sprintf((char *)&local_60,(char *)&local_38);
  }
  else {
    sprintf((char *)&local_60,(char *)&local_40);
  }
  iVar1 = (**(code **)(*param_1 + 0x18))(param_1,&local_60);
  iVar2 = (**(code **)(*param_1 + 0x390))(param_1);
  if (iVar2 != 0) {
    (**(code **)(*param_1 + 0x44))(param_1);
  }
  uVar6 = 0;
  if (iVar1 != 0) {
    uVar3 = FUN_0011cfb8(param_1);
    uVar4 = (**(code **)(*param_1 + 0x7c))(param_1,uVar3);
    iVar2 = (**(code **)(*param_1 + 0x18))(param_1,&local_60);
    uVar6 = 0xffffffff;
    if (iVar2 != 0) {
      iVar5 = (**(code **)(*param_1 + 0x35c))(param_1,iVar2,DAT_0011de28 + 0x11ddb0,6);
      (**(code **)(*param_1 + 0x5c))(param_1,iVar2);
      if (-1 < iVar5) {
        (**(code **)(*param_1 + 0x5c))(param_1,iVar1);
        (**(code **)(*param_1 + 0x5c))(param_1,uVar4);
        (**(code **)(*param_1 + 0x5c))(param_1,uVar3);
        uVar6 = 0;
      }
    }
  }
  return uVar6;
}

