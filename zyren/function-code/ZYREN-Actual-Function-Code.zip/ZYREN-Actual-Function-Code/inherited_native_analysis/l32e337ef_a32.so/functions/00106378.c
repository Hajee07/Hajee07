/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00106378 FUN_00106378 */

undefined4 FUN_00106378(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 *unaff_r4;
  bool bVar3;
  
  if (param_1 != 0) {
    unaff_r4 = *(undefined4 **)(param_1 + 0x1c);
  }
  if (param_1 != 0 && unaff_r4 != (undefined4 *)0x0) {
    iVar2 = *(int *)(param_1 + 0x20);
    bVar3 = iVar2 != 0;
    if (bVar3) {
      iVar2 = *(int *)(param_1 + 0x24);
    }
    if (bVar3 && iVar2 != 0) {
      *(undefined4 *)(param_1 + 8) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0;
      uVar1 = unaff_r4[2];
      *unaff_r4 = 0;
      unaff_r4[1] = 0;
      unaff_r4[3] = ((uVar1 & 0xfff) + 2) / 3 + 1;
      unaff_r4[4] = (((uVar1 & 0xfff) >> 2) + 2) / 3 + 1;
      unaff_r4[5] = (uVar1 << 0x11) >> 0x1f;
      if ((uVar1 & 0x8000) == 0) {
        __aeabi_memclr(&DAT_00029272 + (int)unaff_r4,0x10000);
      }
      *(undefined *)((int)unaff_r4 + 0x9272) = 0;
      unaff_r4[8] = 0;
      unaff_r4[9] = 0;
      unaff_r4[0xf] = 0;
      unaff_r4[7] = 0;
      unaff_r4[0x10] = 0;
      unaff_r4[0x11] = 0;
      unaff_r4[0x12] = 0;
      unaff_r4[0x16] = 0;
      unaff_r4[0x17] = 0;
      unaff_r4[0x18] = 0;
      unaff_r4[0x19] = 0;
      unaff_r4[0x1a] = 0;
      unaff_r4[10] = (int)unaff_r4 + 0x9273;
      unaff_r4[0xe] = 8;
      unaff_r4[0x1b] = 0;
      unaff_r4[0xd] = &UNK_00039272 + (int)unaff_r4;
      unaff_r4[0xc] = &UNK_00039272 + (int)unaff_r4;
      unaff_r4[0xb] = (undefined *)((int)unaff_r4 + 0x9272);
      unaff_r4[0x14] = 0;
      unaff_r4[0x15] = 0;
      unaff_r4[0x13] = 0;
      unaff_r4[0x1c] = 0;
      unaff_r4[6] = 1;
      unaff_r4[0x1d] = 0;
      unaff_r4[0x1e] = 0;
      unaff_r4[0x1f] = 0;
      unaff_r4[0x20] = 0;
      unaff_r4[0x21] = 0;
      unaff_r4[0x22] = 0;
      unaff_r4[0x23] = 0;
      if ((uVar1 & 0x8000) == 0) {
        __aeabi_memclr4(unaff_r4 + 0x24,0x8101);
      }
      __aeabi_memclr((int)unaff_r4 + 0x8192,0x280);
      return 0;
    }
  }
  return 0xfffffffe;
}

