/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c738 FUN_0011c738 */

undefined4 FUN_0011c738(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (0x17 < *(int *)(DAT_0011c79c + 0x11c76c)) {
    uVar2 = FUN_0011ba88(param_2);
    return uVar2;
  }
  iVar1 = dlopen(param_1,4);
  if (iVar1 != 0) {
    uVar2 = dlsym(iVar1,param_2);
    dlclose(iVar1);
    return uVar2;
  }
  return 0;
}

