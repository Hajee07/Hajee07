/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b7c0 FUN_0010b7c0 */

char ** FUN_0010b7c0(char *param_1,undefined4 param_2,void *param_3)

{
  char *pcVar1;
  char *pcVar2;
  void *unaff_r5;
  char **ppcVar3;
  
  pcVar1 = param_1;
  if (param_3 != (void *)0x0) {
    pcVar1 = *(char **)((int)param_3 + 8);
    unaff_r5 = param_3;
  }
  if (param_3 != (void *)0x0 && pcVar1 != (char *)0x0) {
    FUN_00120238();
    free(unaff_r5);
  }
  ppcVar3 = (char **)0x0;
  pcVar1 = (char *)FUN_001201d4(param_1,0);
  if (-1 < (int)pcVar1) {
    ppcVar3 = (char **)malloc(0xc);
    pcVar2 = strdup(param_1);
    *ppcVar3 = pcVar2;
    ppcVar3[1] = (char *)0x0;
    ppcVar3[2] = pcVar1;
  }
  return ppcVar3;
}

