/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011d234 FUN_0011d234 */

undefined4 FUN_0011d234(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = dlopen(DAT_0011d284 + 0x11d24c,2);
  uVar3 = 0;
  if ((iVar1 != 0) && (iVar2 = dlsym(iVar1,DAT_0011d288 + 0x11d268), iVar2 != 0)) {
    dlclose(iVar1);
    uVar3 = 1;
  }
  return uVar3;
}

