/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001125a4 FUN_001125a4 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4
FUN_001125a4(uint *param_1,char *param_2,byte *param_3,uint param_4,int param_5,uint param_6,
            uint param_7,undefined4 param_8,uint param_9,uint param_10,uint param_11,
            time_t *param_12,undefined4 param_13,uint param_14,undefined4 param_15,uint param_16)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  undefined uVar4;
  undefined2 uVar8;
  short sVar9;
  undefined uVar10;
  tm *ptVar11;
  int iVar12;
  uint uVar13;
  byte bVar14;
  uint *puVar15;
  uint uVar16;
  byte *pbVar17;
  uint uVar18;
  int iVar19;
  uint *puVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  int *piVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  int *piVar28;
  uint *puVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  bool bVar34;
  uint local_10b8;
  time_t *local_1098;
  uint *local_1080;
  undefined local_107c;
  undefined local_107b;
  undefined local_107a;
  undefined local_1079;
  uint local_1078;
  undefined4 local_1074;
  uint local_1070;
  undefined4 local_106c;
  time_t local_1068;
  undefined4 local_1064;
  undefined4 local_1060;
  undefined local_105c;
  undefined uStack_105b;
  undefined2 uStack_105a;
  undefined2 local_1058;
  undefined2 uStack_1056;
  undefined2 local_1054;
  undefined2 uStack_1052;
  undefined2 local_1050;
  undefined uStack_104e;
  undefined uStack_104d;
  short local_104c;
  uint local_1048;
  uint local_1044;
  uint local_1040;
  uint local_103c;
  uint local_1038;
  uint local_1034;
  uint local_102c;
  time_t local_1028 [1025];
  undefined uVar5;
  undefined uVar6;
  undefined uVar7;
  
  uVar30 = 0;
  if ((int)param_7 < 0) {
    param_7 = 6;
  }
  local_1034 = param_10;
  local_1038 = param_9;
  local_1044 = 0;
  local_1048 = 0;
  if ((param_9 | param_10) == 0) {
    uVar32 = param_7 & 0x400;
    if ((param_4 != 0) && (uVar21 = uVar30, uVar32 == 0)) goto LAB_0011260c;
  }
  else {
    uVar21 = param_7 & 0x400;
LAB_0011260c:
    uVar30 = 8;
    uVar32 = uVar21;
  }
  if ((param_7 & 0x10000) == 0) {
    uVar30 = uVar30 | 0x800;
  }
  uVar21 = uVar32;
  if (uVar32 != 0) {
    uVar21 = 1;
  }
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  piVar24 = (int *)param_1[0x12];
  if ((piVar24 == (int *)0x0) || (param_1[5] != 2)) {
LAB_001126e0:
    param_1[7] = 0x18;
    return 0;
  }
  pbVar17 = param_3;
  if (param_3 != (byte *)0x0) {
    pbVar17 = (byte *)0x1;
  }
  if ((param_2 == (char *)0x0) || (((uint)pbVar17 | (uint)(param_4 == 0)) == 0)) goto LAB_001126e0;
  uVar18 = param_6;
  if (param_6 != 0) {
    uVar18 = 1;
  }
  if (((param_5 == 0 & uVar18) != 0) || (param_7 = param_7 & 0xf, 10 < param_7)) goto LAB_001126e0;
  uVar22 = *param_1;
  uVar18 = param_1[1];
  if (piVar24[0xd] == 0) {
    if ((param_10 != 0) || (param_1[4] == 0xffff)) {
      piVar24[0xd] = 1;
    }
  }
  else if (param_1[4] == 0xffffffff) {
    uVar30 = 2;
    goto LAB_00112724;
  }
  if (((param_9 | param_10) != 0) && (uVar32 == 0)) {
    uVar30 = 0x18;
LAB_00112724:
    param_1[7] = uVar30;
    return 0;
  }
  if (*param_2 == '/') {
    param_1[7] = 0x19;
    return 0;
  }
  local_1040 = uVar22;
  local_103c = uVar18;
  if (param_12 == (time_t *)0x0) {
    time(&local_1068);
  }
  else {
    local_1068 = *param_12;
  }
  local_1028[0] = local_1068;
  ptVar11 = localtime(local_1028);
  uVar16 = ptVar11->tm_min * 0x20 + ptVar11->tm_hour * 0x800 + ((uint)ptVar11->tm_sec >> 1);
  iVar12 = ptVar11->tm_year * 0x200 + ptVar11->tm_mon * 0x20 + ptVar11->tm_mday + 0x6020;
  if (uVar32 == 0) {
    bVar34 = param_7 == 0;
    param_11 = 0xffffffff;
    uVar13 = param_4;
    pbVar17 = param_3;
    if (3 < param_4) {
      uVar23 = param_4 - 4 & 0xfffffffc;
      param_11 = 0xffffffff;
      iVar19 = DAT_0011364c + 0x112874;
      do {
        bVar14 = *pbVar17;
        pbVar1 = pbVar17 + 1;
        uVar13 = uVar13 - 4;
        pbVar2 = pbVar17 + 2;
        pbVar3 = pbVar17 + 3;
        pbVar17 = pbVar17 + 4;
        uVar31 = *(uint *)(iVar19 + (param_11 & 0xff ^ (uint)bVar14) * 4) ^ param_11 >> 8;
        uVar31 = *(uint *)(iVar19 + (uVar31 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar31 >> 8;
        uVar31 = *(uint *)(iVar19 + (uVar31 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar31 >> 8;
        param_11 = *(uint *)(iVar19 + (uVar31 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar31 >> 8;
      } while (3 < uVar13);
      uVar13 = (param_4 - 4) - uVar23;
      pbVar17 = param_3 + uVar23 + 4;
    }
    if (uVar13 != 0) {
      do {
        uVar13 = uVar13 - 1;
        param_11 = *(uint *)(DAT_00113650 + 0x112910 + (param_11 & 0xff ^ (uint)*pbVar17) * 4) ^
                   param_11 >> 8;
        pbVar17 = pbVar17 + 1;
      } while (uVar13 != 0);
    }
    if (param_4 < 4) {
      param_7 = 0;
    }
    local_1034 = 0;
    uVar21 = (uint)(param_4 < 4) | bVar34 | uVar21;
    param_11 = ~param_11;
    local_1038 = param_4;
    uVar13 = strlen(param_2);
  }
  else {
    uVar21 = 1;
    uVar13 = strlen(param_2);
  }
  if (0xffff < uVar13) {
    uVar30 = 0x19;
    goto LAB_00112808;
  }
  uVar31 = 0;
  uVar23 = param_1[8];
  if ((uVar23 | param_1[9]) != 0) {
    uVar31 = uVar23 - (*param_1 & uVar23 - 1) & uVar23 - 1;
  }
  uVar33 = piVar24[1];
  uVar23 = param_6 + uVar13 + uVar33;
  bVar14 = CARRY4(param_6,uVar13) + CARRY4(param_6 + uVar13,uVar33) + (0xffffffb5 < uVar23);
  if (bVar14 != 0 || bVar14 < (0xfffffffe < uVar23 + 0x4a)) {
    uVar30 = 0xf;
    goto LAB_00113098;
  }
  uVar23 = piVar24[0xd];
  if ((uVar23 == 0) &&
     (uVar23 = param_6 + param_14 + param_16, uVar25 = uVar23 + uVar13 * 2, uVar26 = uVar25 + uVar31
     , uVar27 = uVar26 + uVar33,
     bVar34 = (((uint)CARRY4(param_6,param_14) + (uint)CARRY4(param_6 + param_14,param_16)) -
              ((int)uVar13 >> 0x1f)) + (uint)CARRY4(uVar23,uVar13 * 2) + (uint)CARRY4(uVar25,uVar31)
              + (uint)CARRY4(uVar26,uVar33) + param_1[1] + (uint)CARRY4(uVar27,*param_1) +
              (uint)(0xffffff8d < uVar27 + *param_1) != 0, uVar23 = (uint)bVar34, bVar34)) {
    piVar24[0xd] = uVar23;
  }
  if ((uVar13 != 0) && (param_2[uVar13 - 1] == '/')) {
    bVar34 = param_4 == 0;
    if (bVar34) {
      bVar34 = (local_1038 | local_1034) == 0;
    }
    if (!bVar34) {
      uVar30 = 0x18;
      goto LAB_00113098;
    }
  }
  iVar19 = param_6 + uVar13 + uVar33;
  uVar33 = piVar24[2];
  uVar25 = iVar19 + 0x4a;
  if (uVar23 == 0) {
    uVar25 = iVar19 + 0x2e;
  }
  if (uVar33 < uVar25) {
    if (uVar33 == 0) {
      uVar33 = 1;
    }
    do {
      uVar23 = uVar33;
      uVar33 = uVar23 << 1;
    } while (uVar23 < uVar25);
    iVar19 = (*(code *)param_1[0xc])(param_1[0xd],*piVar24,piVar24[3],uVar23);
    if (iVar19 != 0) {
      piVar24[2] = uVar23;
      *piVar24 = iVar19;
      goto LAB_00112af4;
    }
LAB_00112cb0:
    uVar30 = 0x10;
    goto LAB_00113098;
  }
LAB_00112af4:
  uVar23 = piVar24[6];
  if (uVar23 < piVar24[5] + 1U) {
    if (uVar23 == 0) {
      uVar23 = 1;
    }
    do {
      uVar33 = uVar23;
      uVar23 = uVar33 << 1;
    } while (uVar33 < piVar24[5] + 1U);
    iVar19 = (*(code *)param_1[0xc])(param_1[0xd],piVar24[4],piVar24[7],uVar33);
    if (iVar19 == 0) goto LAB_00112cb0;
    piVar24[6] = uVar33;
    piVar24[4] = iVar19;
  }
  piVar28 = (int *)0x0;
  if ((param_4 != 0 && (uVar21 ^ 1) != 0) &&
     (piVar28 = (int *)(*(code *)param_1[10])(param_1[0xd],1,&DAT_0004df40), piVar28 == (int *)0x0))
  {
    uVar30 = 0x10;
    goto LAB_00112808;
  }
  uVar23 = 0x1000;
  if (uVar31 < 0x1000) {
    uVar23 = uVar31;
  }
  __aeabi_memclr8(local_1028,uVar23);
  uVar23 = uVar22;
  uVar33 = uVar18;
  for (uVar25 = uVar31; uVar25 != 0; uVar25 = uVar25 - uVar26) {
    uVar26 = 0x1000;
    if (uVar25 < 0x1000) {
      uVar26 = uVar25;
    }
    uVar27 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],uVar23,uVar33,local_1028,uVar26);
    if (uVar27 != uVar26) {
      param_1[7] = 0x13;
      (*(code *)param_1[0xb])(param_1[0xd],piVar28);
      return 0;
    }
    bVar34 = CARRY4(uVar23,uVar26);
    uVar23 = uVar23 + uVar26;
    uVar33 = uVar33 + bVar34;
  }
  local_1068 = 0;
  local_1064 = 0;
  local_1060 = 0;
  local_105c = 0;
  uStack_105b = 0;
  uStack_105a = 0;
  local_1058 = 0;
  uStack_1056 = 0;
  local_1054 = 0;
  uStack_1052 = 0;
  local_1050 = 0;
  uStack_104e = 0;
  uStack_104d = 0;
  local_104c = 0;
  uVar8 = local_104c;
  bVar34 = CARRY4(local_1040,uVar31);
  local_1040 = local_1040 + uVar31;
  local_103c = local_103c + bVar34;
  uVar22 = uVar22 + uVar31;
  uVar18 = uVar18 + CARRY4(uVar22,uVar31);
  if (uVar32 != 0) {
    uVar32 = 1;
  }
  uVar32 = uVar32 | uVar21 ^ 1;
  uVar23 = uVar32;
  if (uVar32 != 0) {
    uVar23 = 8;
  }
  uVar10 = (undefined)(uVar30 >> 8);
  uVar4 = (undefined)iVar12;
  uVar5 = (undefined)((uint)iVar12 >> 8);
  uVar6 = (undefined)(uVar16 >> 8);
  uVar7 = (undefined)(uVar13 >> 8);
  local_104c = (short)param_14;
  sVar9 = local_104c;
  if (piVar24[0xd] == 0) {
    if ((local_1044 | uVar18) != 0) {
      uVar30 = 0x1d;
      goto LAB_00113098;
    }
    if (uVar32 != 0) {
      uVar32 = 0x14;
    }
    local_1068 = 0x4034b50;
    uStack_105a = 0;
    local_1058 = 0;
    local_1060 = (uVar16 & 0xff) << 0x10;
    local_1060 = CONCAT31(local_1060._1_3_,(char)uVar23);
    local_1064 = (uVar30 & 0xff) << 0x10;
    uStack_1056 = 0;
    local_1054 = 0;
    uStack_1052 = 0;
    local_1050 = 0;
    local_1060 = CONCAT13(uVar6,(undefined3)local_1060);
    local_1064 = CONCAT13(uVar10,(undefined3)local_1064);
    local_1064 = CONCAT31(local_1064._1_3_,(char)uVar32);
    local_105c = uVar4;
    uStack_105b = uVar5;
    uStack_104e = (char)uVar13;
    uStack_104d = uVar7;
    iVar12 = (*(code *)param_1[0xf])(param_1[0x11]);
    if (iVar12 == 0x1e) {
      uVar32 = uVar22 + 0x1e;
      iVar12 = uVar18 + (0xffffffe1 < uVar22);
      uVar30 = (*(code *)param_1[0xf])
                         (param_1[0x11],(code *)param_1[0xf],uVar32,iVar12,param_2,uVar13);
      if (uVar30 == uVar13) {
        uVar30 = uVar32 + uVar13;
        uVar32 = iVar12 + (uint)CARRY4(uVar32,uVar13);
        local_1098 = (time_t *)0x0;
        local_10b8 = 0;
        goto joined_r0x00112fec;
      }
      goto LAB_00113080;
    }
  }
  else {
    if ((-local_103c < (uint)(local_1040 != 0xffffffff)) &&
       (local_1034 == 0 && (0xfffffffe < local_1038) <= local_1034)) {
      local_10b8 = 0;
      local_1098 = (time_t *)0x0;
    }
    else {
      puVar29 = &local_1048;
      puVar15 = &local_1038;
      if (-local_1034 < (uint)(local_1038 != 0xffffffff)) {
        puVar15 = (uint *)0x0;
        puVar29 = (uint *)0x0;
      }
      puVar20 = &local_1040;
      if (-local_103c < (uint)(local_1040 != 0xffffffff)) {
        puVar20 = (uint *)0x0;
      }
      local_1098 = local_1028;
      local_104c = uVar8;
      local_10b8 = FUN_0011365c(local_1098,puVar15,puVar29,puVar20);
    }
    local_1068 = 0x4034b50;
    if (uVar32 != 0) {
      uVar32 = 0x14;
    }
    uStack_105a = 0;
    local_1058 = 0;
    uStack_1056 = 0;
    local_1054 = 0;
    uStack_1052 = 0;
    local_1050 = 0;
    local_104c = (short)local_10b8 + sVar9;
    local_1060 = CONCAT13(uVar6,(int3)CONCAT31((int3)(((uVar16 & 0xff) << 0x10) >> 8),(char)uVar23))
    ;
    local_1064 = CONCAT31((int3)(CONCAT13(uVar10,(int3)((uVar30 & 0xff) << 0x10)) >> 8),(char)uVar32
                         );
    local_105c = uVar4;
    uStack_105b = uVar5;
    uStack_104e = (char)uVar13;
    uStack_104d = uVar7;
    iVar12 = (*(code *)param_1[0xf])
                       (param_1[0x11],(code *)param_1[0xf],local_1040,local_103c,&local_1068,0x1e);
    if (iVar12 == 0x1e) {
      uVar32 = uVar22 + 0x1e;
      iVar12 = uVar18 + (0xffffffe1 < uVar22);
      uVar30 = (*(code *)param_1[0xf])
                         (param_1[0x11],(code *)param_1[0xf],uVar32,iVar12,param_2,uVar13);
      if (uVar30 == uVar13) {
        uVar30 = uVar32 + uVar13;
        uVar32 = iVar12 + (uint)CARRY4(uVar32,uVar13);
        if (local_1098 != (time_t *)0x0) {
          uVar18 = (*(code *)param_1[0xf])
                             (param_1[0x11],(code *)param_1[0xf],uVar30,uVar32,local_1028,local_10b8
                             );
          if (uVar18 == local_10b8) {
            bVar34 = CARRY4(uVar30,local_10b8);
            uVar30 = uVar30 + local_10b8;
            uVar32 = uVar32 + bVar34;
            goto joined_r0x00112fec;
          }
LAB_001130ac:
          uVar30 = 0x13;
          goto LAB_00112808;
        }
        local_1098 = (time_t *)0x0;
joined_r0x00112fec:
        if (param_14 != 0) {
          uVar18 = (*(code *)param_1[0xf])(param_1[0x11],param_13,uVar30,uVar32,param_13,param_14);
          if (uVar18 != param_14) goto LAB_001130ac;
          bVar34 = CARRY4(uVar30,param_14);
          uVar30 = uVar30 + param_14;
          uVar32 = uVar32 + bVar34;
        }
        if (uVar21 == 0) {
          if (param_4 != 0) {
            uVar21 = param_7;
            if (9 < param_7) {
              uVar21 = 10;
            }
            uVar21 = *(uint *)(DAT_00113654 + 0x1130d8 + uVar21 * 4);
            iVar12 = DAT_00113658 + 0x1130fc;
            if (param_7 < 4) {
              uVar21 = uVar21 | 0x4000;
            }
            if (param_7 == 0) {
              uVar21 = uVar21 | 0x80000;
            }
            local_1070 = 0;
            local_106c = 0;
            piVar28[1] = (int)&local_1080;
            *piVar28 = iVar12;
            piVar28[2] = uVar21;
            piVar28[5] = (uVar21 << 0x11) >> 0x1f;
            piVar28[3] = ((uVar21 & 0xfff) + 2) / 3 + 1;
            piVar28[4] = (((uVar21 & 0xfff) >> 2) + 2) / 3 + 1;
            local_1080 = param_1;
            local_1078 = uVar30;
            local_1074 = uVar32;
            if ((uVar21 & 0x8000) == 0) {
              __aeabi_memclr(&DAT_00029272 + (int)piVar28,0x10000);
            }
            *(undefined *)((int)piVar28 + 0x9272) = 0;
            piVar28[8] = 0;
            piVar28[9] = 0;
            piVar28[0xf] = 0;
            piVar28[7] = 0;
            piVar28[0x10] = 0;
            piVar28[0x11] = 0;
            piVar28[0x12] = 0;
            piVar28[0x16] = 0;
            piVar28[0x17] = 0;
            piVar28[0x18] = 0;
            piVar28[0x19] = 0;
            piVar28[0x1a] = 0;
            piVar28[10] = (int)piVar28 + 0x9273;
            piVar28[0xe] = 8;
            piVar28[0x1b] = 0;
            piVar28[0xd] = (int)(&UNK_00039272 + (int)piVar28);
            piVar28[0xc] = (int)(&UNK_00039272 + (int)piVar28);
            piVar28[0xb] = (int)(undefined *)((int)piVar28 + 0x9272);
            piVar28[0x14] = 0;
            piVar28[0x15] = 0;
            piVar28[0x13] = 0;
            piVar28[0x1c] = 0;
            piVar28[6] = 1;
            piVar28[0x1d] = 0;
            piVar28[0x1e] = 0;
            piVar28[0x1f] = 0;
            piVar28[0x20] = 0;
            piVar28[0x21] = 0;
            piVar28[0x22] = 0;
            piVar28[0x23] = 0;
            if ((uVar21 & 0x8000) == 0) {
              __aeabi_memclr4(piVar28 + 0x24,0x8101);
            }
            __aeabi_memclr((int)piVar28 + 0x8192,0x280);
            local_102c = param_4;
            iVar12 = FUN_001067f4(piVar28,param_3,&local_102c,0,0,4);
            if (iVar12 != 1) {
              (*(code *)param_1[0xb])(param_1[0xd],piVar28);
              uVar30 = 0xc;
              goto LAB_00113098;
            }
            local_1048 = local_1070;
            local_1044 = local_106c;
            uVar30 = local_1078;
            uVar32 = local_1074;
          }
        }
        else {
          uVar21 = (*(code *)param_1[0xf])
                             (param_1[0x11],(code *)param_1[0xf],uVar30,uVar32,param_3,param_4);
          if (uVar21 != param_4) goto LAB_00113080;
          local_1044 = 0;
          uVar30 = uVar30 + param_4;
          uVar32 = uVar32 + CARRY4(uVar30,param_4);
          local_1048 = param_4;
        }
        (*(code *)param_1[0xb])(param_1[0xd],piVar28);
        uVar21 = local_1070;
        if ((local_1038 | local_1034) != 0) {
          local_107c = (undefined)param_11;
          local_1080 = (uint *)0x8074b50;
          local_1079 = (undefined)(param_11 >> 0x18);
          local_107a = (undefined)(param_11 >> 0x10);
          local_107b = (undefined)(param_11 >> 8);
          uVar10 = (undefined)(local_1038 >> 0x18);
          local_1070._0_2_ = (undefined2)local_1038;
          if (local_1098 == (time_t *)0x0) {
            if (local_1044 != 0) {
              uVar30 = 0x1d;
LAB_00112808:
              param_1[7] = uVar30;
              return 0;
            }
            uVar18 = 0x10;
            local_1074 = CONCAT22(CONCAT11(local_1074._3_1_,(char)(local_1038 >> 0x10)),
                                  (undefined2)local_1070);
            iVar12 = 0xf;
            local_1070 = uVar21;
          }
          else {
            local_1070 = local_1038;
            local_106c = CONCAT22(CONCAT11(local_106c._3_1_,(char)(local_1034 >> 0x10)),
                                  (short)local_1034);
            local_1074 = local_1044;
            uVar10 = (undefined)(local_1034 >> 0x18);
            uVar18 = 0x18;
            iVar12 = 0x17;
          }
          local_1078 = local_1048;
          *(undefined *)((int)&local_1080 + iVar12) = uVar10;
          uVar21 = (*(code *)param_1[0xf])
                             (param_1[0x11],(code *)param_1[0xf],uVar30,uVar32,&local_1080,uVar18);
          if (uVar21 != uVar18) {
            return 0;
          }
          bVar34 = CARRY4(uVar30,uVar18);
          uVar30 = uVar30 + uVar18;
          uVar32 = uVar32 + bVar34;
        }
        if (local_1098 != (time_t *)0x0) {
          puVar15 = &local_1048;
          puVar29 = &local_1038;
          if (-local_1034 < (uint)(local_1038 != 0xffffffff)) {
            puVar15 = (uint *)0x0;
            puVar29 = (uint *)0x0;
          }
          puVar20 = &local_1040;
          if (-local_103c < (uint)(local_1040 != 0xffffffff)) {
            puVar20 = (uint *)0x0;
          }
          local_10b8 = FUN_0011365c(local_1028,puVar29,puVar15,puVar20);
        }
        iVar12 = FUN_001137d8(param_1,param_2,uVar13 & 0xffff,local_1098,local_10b8 & 0xffff,param_5
                              ,param_6);
        if (iVar12 == 0) {
          return 0;
        }
        *param_1 = uVar30;
        param_1[1] = uVar32;
        param_1[4] = param_1[4] + 1;
        return 1;
      }
LAB_00113080:
      (*(code *)param_1[0xb])(param_1[0xd],piVar28);
    }
  }
  uVar30 = 0x13;
LAB_00113098:
  param_1[7] = uVar30;
  return 0;
}

