/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001065d0 FUN_001065d0 */

undefined4 FUN_001065d0(int *param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int local_2c;
  int local_28;
  
  if ((((param_1 == (int *)0x0) || (4 < param_2)) || (iVar1 = param_1[7], iVar1 == 0)) ||
     (iVar7 = param_1[3], iVar7 == 0)) {
    return 0xfffffffe;
  }
  iVar10 = param_1[4];
  if (iVar10 == 0) {
    uVar4 = 0xfffffffb;
  }
  else {
    if (param_2 == 1) {
      param_2 = 2;
    }
    if (*(int *)(iVar1 + 0x6c) == 1) {
      uVar4 = 0xfffffffb;
      if (param_2 == 4) {
        uVar4 = 1;
      }
      return uVar4;
    }
    iVar3 = *param_1;
    iVar11 = param_1[1];
    if (param_2 == 4) {
      do {
        local_2c = iVar10;
        local_28 = iVar11;
        iVar2 = FUN_001067f4(iVar1,iVar3,&local_28,iVar7,&local_2c,4);
        iVar1 = param_1[7];
        iVar11 = param_1[1] - local_28;
        iVar3 = *param_1 + local_28;
        param_1[2] = param_1[2] + local_28;
        param_1[1] = iVar11;
        *param_1 = iVar3;
        param_1[0xc] = *(int *)(iVar1 + 0x18);
        param_1[5] = param_1[5] + local_2c;
        iVar7 = param_1[3] + local_2c;
        param_1[3] = iVar7;
        iVar10 = param_1[4] - local_2c;
        param_1[4] = iVar10;
        if (iVar2 < 0) {
          return 0xfffffffe;
        }
        if (iVar2 == 1) {
          return 1;
        }
        uVar4 = 0;
      } while (iVar10 != 0);
    }
    else {
      uVar5 = param_1[2];
      uVar6 = param_1[5];
      do {
        local_2c = iVar10;
        local_28 = iVar11;
        iVar2 = FUN_001067f4(iVar1,iVar3,&local_28,iVar7,&local_2c,param_2);
        iVar8 = param_1[2];
        iVar11 = param_1[1] - local_28;
        iVar1 = param_1[7];
        param_1[1] = iVar11;
        param_1[2] = iVar8 + local_28;
        iVar3 = *param_1 + local_28;
        *param_1 = iVar3;
        param_1[0xc] = *(int *)(iVar1 + 0x18);
        iVar9 = param_1[5];
        iVar10 = param_1[4] - local_2c;
        iVar7 = param_1[3] + local_2c;
        param_1[5] = iVar9 + local_2c;
        param_1[3] = iVar7;
        param_1[4] = iVar10;
        if (iVar2 < 0) {
          return 0xfffffffe;
        }
        if (iVar2 == 1) {
          return 1;
        }
        uVar4 = 0;
        if (iVar10 == 0) {
          return 0;
        }
      } while (iVar11 != 0);
      if (param_2 == 0) {
        uVar4 = 0;
        if ((iVar8 + local_28 ^ uVar5 | iVar9 + local_2c ^ uVar6) == 0) {
          uVar4 = 0xfffffffb;
        }
        return uVar4;
      }
    }
  }
  return uVar4;
}

