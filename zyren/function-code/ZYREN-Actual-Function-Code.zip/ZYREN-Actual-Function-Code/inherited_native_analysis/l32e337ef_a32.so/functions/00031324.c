/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031324 FUN_00031324 */

void FUN_00031324(int param_1,int param_2,int *param_3)

{
  ushort uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  param_3[2] = -1;
  param_3[0x15] = param_1;
  if (*(short *)(param_1 + 0x2c) != 0) {
    iVar2 = param_1 + *(int *)(param_1 + 0x1c);
    uVar1 = *(ushort *)(param_1 + 0x2c);
    uVar3 = 0;
    do {
      if (*(int *)(iVar2 + uVar3 * 0x20) == 1) {
        iVar5 = iVar2 + uVar3 * 0x20;
        iVar4 = *(int *)(iVar5 + 8);
        if (param_3[2] == 0xffffffff) {
          param_3[2] = iVar4;
        }
        else {
          param_3[1] = ~param_3[2] + param_2 + iVar4 + *(int *)(iVar5 + 0x14) & -param_2;
        }
      }
      uVar3 = uVar3 + 1;
    } while ((uint)uVar1 != (uVar3 & 0xffff));
  }
  *param_3 = param_1;
  return;
}

