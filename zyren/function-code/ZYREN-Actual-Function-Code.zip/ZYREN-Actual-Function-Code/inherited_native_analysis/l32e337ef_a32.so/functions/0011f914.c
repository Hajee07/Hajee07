/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011f914 FUN_0011f914 */

int FUN_0011f914(byte *param_1,uint *param_2,uint *param_3,uint *param_4)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  byte *pbVar6;
  uint uVar7;
  
  *param_4 = ((uint)*param_1 << 0x1a) >> 0x1f;
  pbVar6 = param_1 + 1;
  if ((*param_1 & 0x1f) == 0x1f) {
    iVar5 = -1;
    uVar7 = 0;
    do {
      if (iVar5 == -5) {
        return 0;
      }
      iVar2 = -iVar5;
      iVar5 = iVar5 + -1;
      uVar7 = (uint)param_1[iVar2] | uVar7 << 8;
    } while ((param_1[iVar2] & 0x80) != 0);
    *param_2 = uVar7;
    pbVar6 = param_1 + -iVar5;
    iVar5 = -iVar5;
    bVar1 = *pbVar6;
  }
  else {
    *param_2 = (uint)*param_1;
    iVar5 = 1;
    bVar1 = *pbVar6;
  }
  if ((bVar1 & 0x80) != 0) {
    uVar7 = bVar1 & 0x7f;
    iVar2 = 0;
    if (uVar7 < 5) {
      if ((bVar1 & 0x7f) == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = 0;
        uVar4 = uVar7;
        do {
          pbVar6 = pbVar6 + 1;
          uVar4 = uVar4 - 1;
          uVar3 = (uint)*pbVar6 | uVar3 << 8;
        } while (uVar4 != 0);
      }
      *param_3 = uVar3;
      iVar2 = iVar5 + uVar7 + 1;
    }
    return iVar2;
  }
  *param_3 = (uint)bVar1;
  return iVar5 + 1;
}

