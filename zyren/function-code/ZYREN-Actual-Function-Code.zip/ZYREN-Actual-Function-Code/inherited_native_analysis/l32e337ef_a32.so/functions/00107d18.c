/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00107d18 FUN_00107d18 */

uint FUN_00107d18(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int unaff_r5;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  int *piVar8;
  uint uVar9;
  uint local_2c;
  int local_28;
  
  if (param_1 != (int *)0x0) {
    unaff_r5 = param_1[7];
  }
  uVar1 = 0xfffffffe;
  if (param_1 != (int *)0x0 && unaff_r5 != 0) {
    if (param_2 == 1) {
      param_2 = 2;
    }
    if ((param_2 < 5) && ((1 << (param_2 & 0xff) & 0x15U) != 0)) {
      iVar3 = *(int *)(unaff_r5 + 11000);
      local_28 = param_1[1];
      *(int *)(unaff_r5 + 11000) = 0;
      uVar9 = 8;
      piVar8 = (int *)(unaff_r5 + 0xab04);
      if (0 < *(int *)(unaff_r5 + 0x2b00)) {
        uVar9 = 9;
      }
      if (*piVar8 < 0) {
        return 0xfffffffd;
      }
      uVar5 = *(uint *)(unaff_r5 + 0x2afc);
      if (param_2 == 4 || uVar5 == 0) {
        if (param_2 == 4) {
          uVar5 = uVar5 | 1;
        }
        *(uint *)(unaff_r5 + 0x2afc) = uVar5;
        if ((param_2 != 4) || (iVar3 == 0)) {
          puVar6 = (uint *)(unaff_r5 + 0x2af4);
          uVar1 = *puVar6;
          if (param_2 != 4) {
            uVar9 = uVar9 | 2;
          }
          if (uVar1 == 0) {
            puVar7 = (uint *)(unaff_r5 + 0x2af0);
            uVar5 = *puVar7;
            if (local_28 == 0) {
              local_28 = 0;
              do {
                while( true ) {
                  local_2c = 0x8000 - uVar5;
                  iVar3 = FUN_001081f0(unaff_r5,*param_1,&local_28,unaff_r5 + 0x2b04,
                                       unaff_r5 + 0x2b04 + uVar5,&local_2c,uVar9);
                  *piVar8 = iVar3;
                  *param_1 = *param_1 + local_28;
                  param_1[1] = param_1[1] - local_28;
                  param_1[2] = param_1[2] + local_28;
                  param_1[0xc] = *(int *)(unaff_r5 + 0x1c);
                  *puVar6 = local_2c;
                  uVar1 = param_1[4];
                  if (local_2c < (uint)param_1[4]) {
                    uVar1 = local_2c;
                  }
                  __aeabi_memcpy(param_1[3],unaff_r5 + 0x2b04 + *puVar7,uVar1);
                  iVar4 = param_1[4] - uVar1;
                  param_1[3] = param_1[3] + uVar1;
                  param_1[4] = iVar4;
                  param_1[5] = param_1[5] + uVar1;
                  uVar2 = *puVar6 - uVar1;
                  *puVar6 = uVar2;
                  uVar5 = *puVar7 + uVar1 & 0x7fff;
                  *puVar7 = uVar5;
                  if (iVar3 < 0) {
                    return 0xfffffffd;
                  }
                  if (iVar3 == 1) {
                    return 0xfffffffb;
                  }
                  if (param_2 != 4) break;
                  if (iVar3 == 0) goto LAB_001081dc;
                  if (iVar4 == 0) {
                    return 0xfffffffb;
                  }
                  local_28 = param_1[1];
                }
                if (iVar3 == 0) goto LAB_00107f0c;
                uVar1 = 0;
                if (uVar2 != 0) {
                  return 0;
                }
                local_28 = 0;
                if (iVar4 != 0) {
                  local_28 = param_1[1];
                }
              } while (iVar4 != 0 && local_28 != 0);
            }
            else {
              do {
                while( true ) {
                  local_2c = 0x8000 - uVar5;
                  iVar3 = FUN_001081f0(unaff_r5,*param_1,&local_28,unaff_r5 + 0x2b04,
                                       unaff_r5 + 0x2b04 + uVar5,&local_2c,uVar9);
                  *piVar8 = iVar3;
                  *param_1 = *param_1 + local_28;
                  param_1[1] = param_1[1] - local_28;
                  param_1[2] = param_1[2] + local_28;
                  param_1[0xc] = *(int *)(unaff_r5 + 0x1c);
                  *puVar6 = local_2c;
                  uVar1 = param_1[4];
                  if (local_2c < (uint)param_1[4]) {
                    uVar1 = local_2c;
                  }
                  __aeabi_memcpy(param_1[3],unaff_r5 + 0x2b04 + *puVar7,uVar1);
                  iVar4 = param_1[4] - uVar1;
                  param_1[3] = param_1[3] + uVar1;
                  param_1[4] = iVar4;
                  param_1[5] = param_1[5] + uVar1;
                  uVar2 = *puVar6 - uVar1;
                  *puVar6 = uVar2;
                  uVar5 = *puVar7 + uVar1 & 0x7fff;
                  *puVar7 = uVar5;
                  if (iVar3 < 0) {
                    return 0xfffffffd;
                  }
                  if (param_2 != 4) break;
                  if (iVar3 == 0) {
LAB_001081dc:
                    uVar1 = 0xfffffffb;
                    if (uVar2 == 0) {
                      uVar1 = 1;
                    }
                    return uVar1;
                  }
                  if (iVar4 == 0) {
                    return 0xfffffffb;
                  }
                  local_28 = param_1[1];
                }
                if (iVar3 == 0) goto LAB_00107f0c;
                uVar1 = 0;
              } while (((uVar2 == 0) && (iVar4 != 0)) && (local_28 = param_1[1], local_28 != 0));
            }
          }
          else {
            puVar7 = (uint *)(unaff_r5 + 0x2af0);
            uVar9 = param_1[4];
            if (uVar1 < (uint)param_1[4]) {
              uVar9 = uVar1;
            }
            __aeabi_memcpy(param_1[3],unaff_r5 + *puVar7 + 0x2b04,uVar9);
            param_1[3] = param_1[3] + uVar9;
            param_1[4] = param_1[4] - uVar9;
            param_1[5] = param_1[5] + uVar9;
            uVar2 = *puVar6 - uVar9;
            *puVar6 = uVar2;
            *puVar7 = *puVar7 + uVar9 & 0x7fff;
            uVar1 = 0;
            if (*piVar8 == 0) {
LAB_00107f0c:
              return (uint)(uVar2 == 0);
            }
          }
        }
        else {
          local_2c = param_1[4];
          iVar3 = FUN_001081f0(unaff_r5,*param_1,&local_28,param_1[3],param_1[3],&local_2c,uVar9 | 4
                              );
          *piVar8 = iVar3;
          uVar1 = 0xfffffffd;
          *param_1 = *param_1 + local_28;
          param_1[1] = param_1[1] - local_28;
          param_1[2] = param_1[2] + local_28;
          param_1[0xc] = *(int *)(unaff_r5 + 0x1c);
          param_1[5] = param_1[5] + local_2c;
          param_1[4] = param_1[4] - local_2c;
          param_1[3] = param_1[3] + local_2c;
          if (-1 < iVar3) {
            if (iVar3 != 0) {
              *piVar8 = -1;
              return 0xfffffffb;
            }
            return 1;
          }
        }
      }
    }
  }
  return uVar1;
}

