/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010cdc4 FUN_0010cdc4 */

undefined4
FUN_0010cdc4(int param_1,undefined4 param_2,uint param_3,int param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  bool bVar9;
  
  iVar5 = *(int *)(param_1 + 0x48);
  iVar8 = *(int *)(iVar5 + 0x3c);
  uVar7 = 0xffffffff;
  uVar6 = 0xffffffff;
  iVar1 = param_1;
  if (iVar8 != 0) {
    iVar1 = *(int *)(iVar8 + 8);
  }
  if (iVar8 != 0 && iVar1 != 0) {
    uVar2 = FUN_00120364(iVar1,0,1);
    uVar6 = FUN_00120364(*(undefined4 *)(iVar8 + 8),0,2);
    FUN_00120364(*(undefined4 *)(iVar8 + 8),uVar2,0);
    uVar7 = (int)uVar6 >> 0x1f;
    iVar5 = *(int *)(param_1 + 0x48);
  }
  uVar4 = *(uint *)(iVar5 + 0x40) + param_3;
  uVar3 = *(int *)(iVar5 + 0x44) + param_4 + (uint)CARRY4(*(uint *)(iVar5 + 0x40),param_3);
  if (-1 < (int)uVar3) {
    if ((uVar4 ^ uVar6 | uVar3 ^ uVar7) != 0) {
      iVar1 = *(int *)(iVar5 + 0x3c);
      bVar9 = iVar1 != 0;
      if (bVar9) {
        iVar1 = *(int *)(iVar1 + 8);
      }
      if (!bVar9 || iVar1 == 0) {
        return 0;
      }
      iVar1 = FUN_00120364(iVar1,uVar4,0);
      if (iVar1 == -1) {
        return 0;
      }
      iVar5 = *(int *)(param_1 + 0x48);
    }
    iVar1 = *(int *)(iVar5 + 0x3c);
    bVar9 = iVar1 != 0;
    if (bVar9) {
      iVar1 = *(int *)(iVar1 + 8);
    }
    if (bVar9 && iVar1 != 0) {
      uVar2 = FUN_001203a4(iVar1,param_5,param_6);
      return uVar2;
    }
  }
  return 0;
}

