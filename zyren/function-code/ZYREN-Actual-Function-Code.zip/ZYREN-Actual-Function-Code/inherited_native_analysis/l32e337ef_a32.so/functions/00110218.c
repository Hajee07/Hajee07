/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110218 FUN_00110218 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 FUN_00110218(uint *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  size_t sVar2;
  uint uVar3;
  uint uVar4;
  short *psVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  int *piVar12;
  uint uVar13;
  bool bVar14;
  undefined4 uVar15;
  uint local_4c8;
  short *local_4c4;
  int local_4c0;
  int aiStack_4bc [7];
  int local_4a0;
  int local_49c;
  byte local_496;
  int local_48e;
  uint local_48a;
  uint local_486;
  undefined local_482;
  undefined local_481;
  undefined local_480;
  undefined local_47f;
  undefined4 local_47c;
  undefined auStack_478 [22];
  ushort local_462;
  int local_45c;
  uint local_458;
  uint uStack_454;
  uint local_450;
  uint uStack_44c;
  uint local_440;
  int iStack_43c;
  int local_434;
  int local_430;
  int local_42c;
  char acStack_428 [1028];
  
  local_47c = 0;
  local_4a0 = 0;
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  piVar12 = (int *)param_1[0x12];
  if (piVar12 == (int *)0x0) {
LAB_00110260:
    param_1[7] = 0x18;
    return 0;
  }
  uVar1 = param_1[10];
  bVar14 = uVar1 != 0;
  if (bVar14) {
    uVar1 = param_1[0xb];
  }
  if (((!bVar14 || uVar1 == 0) || (param_1[0xe] == 0)) || (param_1[4] < param_2)) goto LAB_00110260;
  iVar6 = 0;
  if (param_2 < param_1[4]) {
    iVar6 = *piVar12 + *(int *)(piVar12[4] + param_2 * 4);
  }
  iVar6 = FUN_001107b8(param_1,param_2,iVar6,auStack_478,&local_47c);
  if (iVar6 == 0) {
    return 0;
  }
  if (local_434 != 0) {
    return 1;
  }
  if ((local_450 | uStack_44c) == 0) {
    return 1;
  }
  if (local_430 != 0) {
    uVar1 = 5;
    goto LAB_00110308;
  }
  if ((local_462 | 8) != 8) {
    uVar1 = 4;
    goto LAB_00110308;
  }
  if (local_42c == 0) {
    uVar1 = 6;
    goto LAB_00110308;
  }
  piVar11 = &local_49c;
  uVar15 = 0x1e;
  iVar6 = (*(code *)param_1[0xe])(param_1[0x11]);
  if (iVar6 != 0x1e) {
    uVar1 = 0x14;
    goto LAB_00110308;
  }
  if (local_49c == 0x4034b50) {
    uVar1 = (uint)CONCAT11(local_481,local_482);
    sVar2 = strlen(acStack_428);
    if (uVar1 == sVar2) {
      uVar9 = (uint)CONCAT11(local_47f,local_480);
      uVar3 = local_440 + 0x1e;
      iVar7 = iStack_43c + (uint)(0xffffffe1 < local_440);
      uVar4 = uVar3 + uVar1;
      iVar8 = iVar7 + (uint)CARRY4(uVar3,uVar1);
      uVar10 = uVar4 + uVar9;
      iVar6 = iVar8 + (uint)CARRY4(uVar4,uVar9);
      uVar13 = uStack_454 + iVar6 + (uint)CARRY4(local_458,uVar10);
      if (uVar13 < param_1[1] || param_1[1] - uVar13 < (uint)(local_458 + uVar10 <= *param_1)) {
        uVar13 = uVar9;
        if (uVar9 < uVar1) {
          uVar13 = uVar1;
        }
        if (uVar13 == 0) {
          local_4c4 = (short *)0x0;
        }
        else {
          local_4c4 = (short *)(*(code *)param_1[0xc])(param_1[0xd],0,1,uVar13,piVar11,uVar15);
          if (local_4c4 == (short *)0x0) {
            param_1[7] = 0x10;
            local_4c4 = (short *)0x0;
            goto LAB_0011073c;
          }
        }
        if (uVar1 == 0) {
LAB_00110508:
          if (uVar9 != 0) {
            uVar1 = local_48a;
            if (local_48a != 0xffffffff) {
              uVar1 = local_486;
            }
            if (local_48a == 0xffffffff || uVar1 == 0xffffffff) {
              uVar1 = (*(code *)param_1[0xe])
                                (param_1[0x11],(code *)param_1[0xe],uVar4,iVar8,local_4c4,uVar9);
              psVar5 = local_4c4;
              if (uVar1 != uVar9) goto LAB_0011065c;
              do {
                if (uVar9 < 4) {
LAB_001106bc:
                  uVar1 = 9;
                  goto LAB_00110738;
                }
                uVar1 = (ushort)psVar5[1] + 4;
                if (uVar9 < uVar1) goto LAB_001106bc;
                if (*psVar5 == 1) {
                  if ((ushort)psVar5[1] < 0x10) goto LAB_001106bc;
                  local_486 = *(uint *)(psVar5 + 2);
                  local_48a = *(uint *)(psVar5 + 6);
                  uVar1 = *(uint *)(psVar5 + 4);
                  uVar3 = *(uint *)(psVar5 + 8);
                  local_4c8 = 1;
                  goto joined_r0x001106ec;
                }
                uVar9 = uVar9 - uVar1;
                psVar5 = (short *)((int)psVar5 + uVar1);
              } while (uVar9 != 0);
            }
          }
          uVar1 = 0;
          uVar3 = 0;
          local_4c8 = 0;
joined_r0x001106ec:
          if (((local_48e == 0) && ((local_496 & 8) != 0)) && ((local_48a | uVar3) == 0)) {
            iVar7 = 0x18;
            piVar11 = &local_4c0;
            if ((piVar12[0xd] | local_4c8) == 0) {
              iVar7 = 0x10;
            }
            iVar6 = (*(code *)param_1[0xe])
                              (param_1[0x11],iVar6,local_458 + uVar10,
                               uStack_454 + iVar6 + (uint)CARRY4(local_458,uVar10),piVar11,iVar7);
            uVar1 = 0x14;
            if (iVar6 == iVar7) {
              if (local_4c0 == 0x8074b50) {
                piVar11 = aiStack_4bc;
              }
              if ((piVar12[0xd] | local_4c8) == 0) {
                uVar4 = 0;
                uVar9 = 0;
                uVar3 = piVar11[2];
              }
              else {
                uVar9 = piVar11[4];
                uVar3 = piVar11[3];
                uVar4 = piVar11[2];
              }
              uVar1 = 0x1e;
              bVar14 = *piVar11 == local_45c;
              if (bVar14) {
                bVar14 = (piVar11[1] ^ local_458 | uVar4 ^ uStack_454) == 0;
              }
              if ((bVar14) && ((uVar3 ^ local_450 | uVar9 ^ uStack_44c) == 0)) goto LAB_0011075c;
            }
            param_1[7] = uVar1;
            goto LAB_0011073c;
          }
          if (local_48e == local_45c) {
            bVar14 = (local_48a ^ local_458 | uVar3 ^ uStack_454) == 0;
            if (bVar14) {
              bVar14 = (local_486 ^ local_450 | uVar1 ^ uStack_44c) == 0;
            }
            if (bVar14) {
LAB_0011075c:
              (*(code *)param_1[0xb])(param_1[0xd],local_4c4);
              if ((param_3 & 0x2000) != 0) {
                return 1;
              }
              iVar6 = FUN_0010e71c(param_1,param_2,DAT_001107b4 + 0x11078c,&local_4a0,0);
              if (iVar6 == 0) {
                return 0;
              }
              if (local_4a0 == local_45c) {
                return 1;
              }
              uVar1 = 0x1e;
              goto LAB_00110308;
            }
          }
LAB_00110734:
          uVar1 = 0x1e;
        }
        else {
          uVar3 = (*(code *)param_1[0xe])
                            (param_1[0x11],(code *)param_1[0xe],uVar3,iVar7,local_4c4,uVar1);
          if (uVar3 == uVar1) {
            iVar7 = memcmp(acStack_428,local_4c4,uVar1);
            if (iVar7 == 0) goto LAB_00110508;
            goto LAB_00110734;
          }
LAB_0011065c:
          uVar1 = 0x14;
        }
LAB_00110738:
        param_1[7] = uVar1;
LAB_0011073c:
        (*(code *)param_1[0xb])(param_1[0xd],local_4c4);
        return 0;
      }
    }
  }
  uVar1 = 9;
LAB_00110308:
  param_1[7] = uVar1;
  return 0;
}

