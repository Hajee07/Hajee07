/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030488 FUN_00030488 */

int FUN_00030488(int param_1,int param_2,int param_3,int *param_4,char *param_5)

{
  undefined4 uVar1;
  int iVar2;
  int extraout_r1;
  int iVar3;
  int iVar4;
  int iVar5;
  
  uVar1 = FUN_00030eac(param_5);
  iVar3 = *param_4;
  FUN_00033508(uVar1,iVar3);
  iVar4 = param_4[extraout_r1 + 2];
  while( true ) {
    if (iVar4 == 0) {
      return 0;
    }
    iVar5 = param_2 + iVar4 * 0x10;
    if ((*(short *)(iVar5 + 0xe) != 0) &&
       (iVar2 = strcmp((char *)(param_3 + *(int *)(param_2 + iVar4 * 0x10)),param_5), iVar2 == 0))
    break;
    iVar4 = param_4[iVar4 + iVar3 + 2];
  }
  return *(int *)(iVar5 + 4) + param_1;
}

