/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c9a4 FUN_0011c9a4 */

bool FUN_0011c9a4(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  
  uVar1 = FUN_0011c904(param_2);
  bVar4 = true;
  if (((uVar1 != 0) && (uVar2 = FUN_0011c904(param_1), uVar2 != 0)) &&
     (bVar4 = false, uVar1 <= uVar2)) {
    iVar3 = FUN_0011e028(param_1,param_2,uVar1);
    bVar4 = iVar3 == 0;
  }
  return bVar4;
}

