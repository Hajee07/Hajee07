/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00120238 FUN_00120238 */

uint FUN_00120238(void)

{
  uint uVar1;
  
  uVar1 = FUN_00120344();
  if ((~uVar1 | **(uint **)(DAT_00120264 + 0x120254) ^ 4) == 0) {
    uVar1 = 0;
  }
  return uVar1;
}

