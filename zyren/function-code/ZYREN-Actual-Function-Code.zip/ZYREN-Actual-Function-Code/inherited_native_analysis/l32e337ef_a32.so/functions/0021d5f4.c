/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d5f4 FUN_0021d5f4 */

void FUN_0021d5f4(undefined4 param_1,uint param_2,undefined2 param_3)

{
  undefined2 uVar1;
  
  uVar1 = param_3;
  if (((param_2 & 0x404000) != 0x404000) && (uVar1 = 0, (param_2 & 0x40) != 0)) {
    uVar1 = param_3;
  }
  thunk_FUN_000bd950(0xffffff9c,param_1,param_2 | 0x20000,uVar1);
  return;
}

