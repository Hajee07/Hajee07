/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00117cdc FUN_00117cdc */

undefined4 FUN_00117cdc(uint *param_1)

{
  undefined2 uVar1;
  uint uVar2;
  size_t sVar3;
  int iVar4;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  undefined4 uVar9;
  uint *puVar10;
  uint *puVar11;
  bool bVar12;
  undefined4 local_58;
  uint local_54;
  undefined local_50;
  undefined local_4f;
  undefined local_4e;
  undefined local_4d;
  undefined local_4c;
  undefined local_4b;
  undefined local_4a;
  undefined local_49;
  undefined local_48;
  undefined local_47;
  undefined local_46;
  undefined local_45;
  undefined local_44;
  undefined local_43;
  undefined local_42;
  undefined local_41;
  uint local_40 [7];
  
  if (param_1 == (uint *)0x0) {
    return 0xffffffff;
  }
  uVar9 = 0;
  if (param_1[5] != 1) {
    puVar8 = param_1 + 0x1a;
    puVar11 = param_1 + 0x1e;
    if ((*(byte *)(param_1 + 0x14) & 0xf) != 0) {
      local_40[0] = 0;
      uVar2 = FUN_001067f4(param_1 + 0x32,DAT_0011807c + 0x117d3c,local_40,0,0,4);
      uVar9 = 0xfffffff4;
      if (1 < uVar2) goto LAB_00118054;
      *puVar8 = param_1[0x30];
      param_1[0x1b] = param_1[0x31];
      *puVar11 = param_1[0x2e];
      param_1[0x1f] = param_1[0x2f];
      *(undefined2 *)(param_1 + 0x2a) = 8;
    }
    puVar10 = param_1 + 0x18;
    sVar3 = strlen((char *)param_1[0x17]);
    local_40[0] = param_1[0x13803];
    localtime((time_t *)local_40);
    local_58 = 0x8074b50;
    local_54 = param_1[0x1c];
    uVar2 = *puVar8;
    uVar5 = param_1[0x1b];
    local_49 = (undefined)(uVar5 >> 0x18);
    local_4a = (undefined)(uVar5 >> 0x10);
    local_4b = (undefined)(uVar5 >> 8);
    local_4d = (undefined)(uVar2 >> 0x18);
    local_4c = (undefined)uVar5;
    local_50 = (undefined)uVar2;
    local_4e = (undefined)(uVar2 >> 0x10);
    local_4f = (undefined)(uVar2 >> 8);
    uVar2 = *puVar10;
    uVar5 = param_1[0x19];
    local_41 = (undefined)(uVar5 >> 0x18);
    local_42 = (undefined)(uVar5 >> 0x10);
    local_43 = (undefined)(uVar5 >> 8);
    local_45 = (undefined)(uVar2 >> 0x18);
    local_44 = (undefined)uVar5;
    local_48 = (undefined)uVar2;
    local_46 = (undefined)(uVar2 >> 0x10);
    local_47 = (undefined)(uVar2 >> 8);
    iVar4 = (*(code *)param_1[0xf])
                      (param_1[0x11],(code *)param_1[0xf],*puVar11,param_1[0x1f],&local_58,0x18);
    uVar9 = 0xfffffff2;
    if (iVar4 == 0x18) {
      uVar2 = *puVar11;
      *puVar11 = uVar2 + 0x18;
      param_1[0x1f] = param_1[0x1f] + (uint)(0xffffffe7 < uVar2);
      puVar6 = (uint *)(uint)((uint)(*puVar10 != 0xffffffff) <= -param_1[0x19]);
      if (puVar6 != (uint *)0x0) {
        puVar6 = puVar10;
      }
      puVar7 = (uint *)(uint)((uint)(*puVar8 != 0xffffffff) <= -param_1[0x1b]);
      if (puVar7 != (uint *)0x0) {
        puVar7 = puVar8;
      }
      puVar8 = (uint *)(uint)((uint)(param_1[0x28] != 0xffffffff) <= -param_1[0x29]);
      if (puVar8 != (uint *)0x0) {
        puVar8 = param_1 + 0x28;
      }
      uVar1 = FUN_0011365c(local_40,puVar6,puVar7,puVar8);
      uVar2 = sVar3 & 0xffff;
      if (uVar2 != 0) {
        bVar12 = *(char *)(uVar2 + param_1[0x17] + -1) == '/';
        if (bVar12) {
          bVar12 = (*puVar10 | param_1[0x19]) == 0;
        }
        if (bVar12) {
          param_1[0x13802] = param_1[0x13802] | 0x10;
        }
      }
      iVar4 = FUN_001137d8(param_1,param_1[0x17],uVar2,local_40,uVar1,DAT_00118080 + 0x11800c,0);
      if (iVar4 == 0) {
        uVar9 = 0xfffffff1;
      }
      else {
        uVar9 = 0;
        param_1[4] = param_1[4] + 1;
        *param_1 = *puVar11;
        param_1[1] = param_1[0x1f];
      }
    }
  }
LAB_00118054:
  param_1[0x13803] = 0;
  if ((void *)param_1[0x17] != (void *)0x0) {
    free((void *)param_1[0x17]);
    param_1[0x17] = 0;
  }
  return uVar9;
}

