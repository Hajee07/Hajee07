/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010f710 FUN_0010f710 */

undefined4 FUN_0010f710(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_1c;
  
  uVar2 = 0;
  iVar1 = FUN_0010d5e8(param_1,param_2,0,param_3,&local_1c);
  if (iVar1 != 0) {
    uVar2 = FUN_0010f3d8(param_1,local_1c,param_3);
  }
  return uVar2;
}

