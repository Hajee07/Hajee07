/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00119648 FUN_00119648 */

undefined4 FUN_00119648(int param_1,char *param_2,code *param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  size_t __n;
  uint uVar3;
  int iVar4;
  size_t sVar5;
  int *piVar6;
  int iVar7;
  uint extraout_r1;
  uint uVar8;
  uint uVar9;
  int iVar10;
  char cVar11;
  int iVar12;
  undefined4 uVar13;
  char *pcVar14;
  bool bVar15;
  uint local_ab8;
  undefined auStack_a90 [17];
  byte local_a7f;
  uint local_a68;
  int iStack_a64;
  uint local_a5c;
  char local_a40 [1024];
  char acStack_640 [519];
  char acStack_439 [521];
  byte local_230 [524];
  
  __aeabi_memclr8(acStack_439 + 1,0x201);
  __aeabi_memclr8(acStack_640,0x201);
  uVar2 = strlen(param_2);
  if (0x200 < uVar2 + 1) {
    return 0xfffffffe;
  }
  __aeabi_memclr8(auStack_a90,0x450);
  strcpy(acStack_439 + 1,param_2);
  if (acStack_439[uVar2] != '/' && acStack_439[uVar2] != '\\') {
    (acStack_439 + 1)[uVar2] = '/';
    uVar2 = uVar2 + 1;
  }
  __n = 0x200 - uVar2;
  if (0x1ff < __n) {
    __n = 0x200;
  }
  uVar13 = 0;
  uVar3 = __n;
  if (param_1 != 0) {
    uVar3 = *(uint *)(param_1 + 0x10);
    local_ab8 = uVar3;
  }
  if (param_1 != 0 && uVar3 != 0) {
    uVar3 = 0;
joined_r0x00119770:
    iVar4 = 0;
    if (param_1 != 0) {
      piVar6 = *(int **)(param_1 + 0x48);
      iVar4 = 0;
      if ((piVar6 != (int *)0x0) && (iVar4 = 0, uVar3 < *(uint *)(param_1 + 0x10))) {
        iVar4 = *piVar6 + *(int *)(piVar6[4] + uVar3 * 4);
      }
    }
    iVar4 = FUN_001107b8(param_1,uVar3,iVar4,auStack_a90,0);
    if (iVar4 == 0) {
      uVar13 = 0xfffffffd;
    }
    else {
      sVar5 = strlen(local_a40);
      pcVar14 = local_a40;
      if (sVar5 != 0) {
        do {
          pcVar14 = pcVar14 + 1;
          cVar11 = pcVar14[-1];
        } while (cVar11 == '/' || cVar11 == '\\');
        iVar4 = 0;
        iVar7 = 0;
        iVar12 = 0;
        if (cVar11 != '\\' && cVar11 != '/') goto LAB_001198a0;
LAB_00119834:
        iVar10 = 0;
        iVar1 = iVar12;
        if (iVar4 != 0) {
          iVar12 = strcmp(local_a40 + iVar7,(char *)(DAT_00119b98 + 0x119858));
          if ((iVar12 != 0) &&
             (iVar12 = strcmp(local_a40 + iVar7,(char *)(DAT_00119b9c + 0x119874)), iVar12 != 0)) {
            local_a40[iVar7 + iVar4] = cVar11;
            iVar7 = iVar7 + iVar4 + 1;
          }
        }
        do {
          iVar4 = iVar10;
          if (sVar5 - 1 == iVar1) {
            if (iVar4 == 0) {
LAB_00119940:
              local_a40[iVar7] = '\0';
            }
            else {
              iVar4 = strcmp(local_a40 + iVar7,(char *)(DAT_00119ba0 + 0x119914));
              if ((iVar4 == 0) ||
                 (iVar4 = strcmp(local_a40 + iVar7,(char *)(DAT_00119ba4 + 0x119934)), iVar4 == 0))
              goto LAB_00119940;
            }
            strncpy(acStack_439 + uVar2 + 1,local_a40,__n);
            __aeabi_memclr8(local_230,0x201);
            pcVar14 = acStack_439 + 1;
            uVar8 = extraout_r1;
            if (acStack_439[1] == '\0') goto LAB_001199f4;
            uVar9 = 0;
            cVar11 = acStack_439[1];
            goto LAB_0011998c;
          }
          iVar12 = iVar1 + 1;
          cVar11 = pcVar14[iVar1];
          if (cVar11 == '\\' || cVar11 == '/') goto LAB_00119834;
LAB_001198a0:
          local_a40[iVar7 + iVar4] = cVar11;
          iVar10 = iVar4 + 1;
          iVar1 = iVar12;
        } while( true );
      }
      uVar13 = 0xfffffffe;
    }
  }
LAB_00119714:
  iVar4 = FUN_0010b938(param_1,1);
  if (iVar4 == 0) {
    uVar13 = 0xffffffe7;
  }
  return uVar13;
LAB_0011998c:
  do {
    if ((cVar11 == '\\' || cVar11 == '/') && (uVar9 != 0)) {
      if (cVar11 == '\\') {
        pcVar14[uVar9] = '/';
      }
      iVar4 = mkdir((char *)local_230,0x1ed);
      if ((iVar4 == -1) && (piVar6 = (int *)__errno(), *piVar6 != 0x11)) {
        uVar13 = 0xffffffe9;
        goto LAB_00119714;
      }
    }
    uVar8 = (uint)(byte)pcVar14[uVar9];
    local_230[uVar9] = pcVar14[uVar9];
    cVar11 = acStack_439[uVar9 + 2];
  } while ((uVar9 + 1 >> 9 == 0) && (uVar9 = uVar9 + 1, cVar11 != '\0'));
LAB_001199f4:
  if (((local_a7f | 0x10) == 0x13) && ((local_a5c & 0x20000000) != 0)) {
    uVar13 = 0xffffffee;
    if ((uint)(local_a68 < 0x201) <= (uint)-iStack_a64) goto LAB_00119714;
    iVar4 = FUN_0010dc40(param_1,uVar3,acStack_640,0x200,0,0,0,0);
    if (iVar4 == 0) goto LAB_00119714;
    acStack_640[local_a68] = '\0';
    iVar4 = symlink(acStack_640,acStack_439 + 1);
    if (iVar4 != 0) {
      uVar13 = 0xffffffe8;
      goto LAB_00119714;
    }
    goto LAB_00119af8;
  }
  if (param_1 == 0) {
LAB_00119a3c:
    iVar4 = FUN_0010fe18(param_1,uVar3,pcVar14,0);
    if (iVar4 == 0) {
      uVar13 = 0xffffffed;
      goto LAB_00119714;
    }
  }
  else {
    piVar6 = *(int **)(param_1 + 0x48);
    bVar15 = piVar6 != (int *)0x0;
    if (bVar15) {
      uVar8 = *(uint *)(param_1 + 0x10);
    }
    if ((bVar15 && uVar8 < uVar3 || (!bVar15 || uVar8 == uVar3)) ||
       (iVar4 = *piVar6 + *(int *)(piVar6[4] + uVar3 * 4), iVar4 == 0)) {
      *(undefined4 *)(param_1 + 0x1c) = 0x18;
      goto LAB_00119a3c;
    }
    if (((*(ushort *)(iVar4 + 0x1c) == 0) ||
        (*(char *)(iVar4 + (uint)*(ushort *)(iVar4 + 0x1c) + 0x2d) != '/')) &&
       ((*(byte *)(iVar4 + 0x26) & 0x10) == 0)) goto LAB_00119a3c;
  }
  if ((local_a5c >> 0x10 != 0) && (iVar4 = chmod(pcVar14,local_a5c >> 0x10), iVar4 < 0)) {
    uVar13 = 0xffffffec;
    goto LAB_00119714;
  }
LAB_00119af8:
  if (((param_3 != (code *)0x0) && (iVar4 = (*param_3)(acStack_439 + 1,param_4), iVar4 < 0)) ||
     (uVar3 = uVar3 + 1, uVar3 == local_ab8)) goto LAB_00119b68;
  goto joined_r0x00119770;
LAB_00119b68:
  uVar13 = 0;
  goto LAB_00119714;
}

