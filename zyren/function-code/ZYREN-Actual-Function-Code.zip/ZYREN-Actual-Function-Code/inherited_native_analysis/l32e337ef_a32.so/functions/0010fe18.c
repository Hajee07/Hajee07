/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010fe18 FUN_0010fe18 */

int FUN_0010fe18(int param_1,uint param_2,char *param_3,undefined4 param_4)

{
  int *piVar1;
  char *pcVar2;
  char **__ptr;
  char *pcVar3;
  int iVar4;
  int iVar5;
  undefined auStack_480 [24];
  __time_t local_468;
  int local_43c;
  int local_434;
  utimbuf local_30;
  
  iVar5 = 0;
  if (param_1 != 0) {
    piVar1 = *(int **)(param_1 + 0x48);
    iVar5 = 0;
    if ((piVar1 != (int *)0x0) && (iVar5 = 0, param_2 < *(uint *)(param_1 + 0x10))) {
      iVar5 = *piVar1 + *(int *)(piVar1[4] + param_2 * 4);
    }
  }
  iVar5 = FUN_001107b8(param_1,param_2,iVar5,auStack_480,0);
  if (iVar5 != 0) {
    if ((local_43c == 0) && (local_434 != 0)) {
      pcVar2 = (char *)FUN_001201d4(param_3,0);
      if (-1 < (int)pcVar2) {
        __ptr = (char **)malloc(0xc);
        pcVar3 = strdup(param_3);
        *__ptr = pcVar3;
        __ptr[1] = (char *)0x0;
        __ptr[2] = pcVar2;
        if (__ptr != (char **)0x0) {
          iVar5 = FUN_0010e71c(param_1,param_2,DAT_0010ffc0 + 0x10ff18,__ptr,param_4);
          if (__ptr[2] != (char *)0x0) {
            iVar4 = FUN_00120238();
            free(__ptr);
            if (iVar4 != -1) {
              if (iVar5 != 0) {
                local_30.modtime = local_468;
                local_30.actime = local_468;
                utime(param_3,&local_30);
                return iVar5;
              }
              return 0;
            }
          }
          if (param_1 == 0) {
            return 0;
          }
          if (iVar5 != 0) {
            *(undefined4 *)(param_1 + 0x1c) = 0x15;
          }
          return 0;
        }
      }
      if (param_1 != 0) {
        *(undefined4 *)(param_1 + 0x1c) = 0x11;
      }
      return 0;
    }
    if (param_1 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 6;
    }
  }
  return 0;
}

