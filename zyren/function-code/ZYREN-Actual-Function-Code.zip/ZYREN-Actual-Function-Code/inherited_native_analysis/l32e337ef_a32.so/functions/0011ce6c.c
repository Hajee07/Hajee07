/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011ce6c FUN_0011ce6c */

void FUN_0011ce6c(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = (**(code **)(*param_1 + 0x3c))(param_1);
  if (iVar1 != 0) {
    (**(code **)(*param_1 + 0x44))(param_1);
    uVar2 = (**(code **)(*param_1 + 0x7c))(param_1,iVar1);
    uVar3 = (**(code **)(*param_1 + 0x84))
                      (param_1,uVar2,DAT_0011cf84 + 0x11ced8,DAT_0011cf88 + 0x11cedc);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar2);
    uVar2 = (**(code **)(*param_1 + 0x88))(param_1,iVar1,uVar3);
    uVar3 = (**(code **)(*param_1 + 0x2a4))(param_1,uVar2,0);
    (**(code **)(*param_1 + 0x2a8))(param_1,uVar2,uVar3);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar2);
    (**(code **)(*param_1 + 0x5c))(param_1,iVar1);
                    /* WARNING: Could not recover jumptable at 0x0011cf7c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x44))(param_1);
    return;
  }
  return;
}

