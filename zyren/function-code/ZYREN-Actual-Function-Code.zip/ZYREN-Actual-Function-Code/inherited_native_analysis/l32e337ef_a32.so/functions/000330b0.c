/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000330b0 FUN_000330b0 */

undefined4 FUN_000330b0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_128 [264];
  
  FUN_000330f4(auStack_128);
  FUN_00033174(auStack_128,param_1,param_2,param_3);
  return param_2;
}

