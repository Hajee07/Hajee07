/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002927fc __aeabi_memcpy8 */

void __aeabi_memcpy8(void)

{
  (*(code *)PTR___aeabi_memcpy8_00307e28)();
  return;
}

