/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00107834 FUN_00107834 */

int FUN_00107834(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 *local_3c;
  int local_38;
  code *local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  
  local_30 = 0;
  local_3c = (undefined4 *)0x0;
  local_48 = *param_2;
  local_50 = 0;
  local_38 = DAT_00107acc + 0x10787c;
  local_44 = 0;
  local_34 = (code *)(DAT_00107ad0 + 0x107884);
  local_40 = 0;
  local_24 = 0;
  local_2c = 0;
  local_28 = 1;
  local_58 = param_3;
  uStack_54 = param_4;
  local_4c = param_1;
  puVar1 = (undefined4 *)malloc(0x4df40);
  if (puVar1 == (undefined4 *)0x0) {
    return -4;
  }
  *puVar1 = 0;
  puVar1[1] = 0;
  puVar1[2] = 0x7080;
  puVar1[3] = 0x2c;
  puVar1[4] = 0xc;
  puVar1[5] = 1;
  local_3c = puVar1;
  __aeabi_memclr(&DAT_00029272 + (int)puVar1,0x10000);
  *(undefined *)((int)puVar1 + 0x9272) = 0;
  puVar1[8] = 0;
  puVar1[9] = 0;
  puVar1[0xf] = 0;
  puVar1[7] = 0;
  puVar1[0x10] = 0;
  puVar1[0x11] = 0;
  puVar1[0x12] = 0;
  puVar1[0x16] = 0;
  puVar1[0x17] = 0;
  puVar1[0x18] = 0;
  puVar1[0x19] = 0;
  puVar1[0x1a] = 0;
  puVar1[10] = (int)puVar1 + 0x9273;
  puVar1[0xe] = 8;
  puVar1[0x1b] = 0;
  puVar1[0xd] = &UNK_00039272 + (int)puVar1;
  puVar1[0xc] = &UNK_00039272 + (int)puVar1;
  puVar1[0xb] = (undefined *)((int)puVar1 + 0x9272);
  puVar1[0x14] = 0;
  puVar1[0x15] = 0;
  puVar1[0x13] = 0;
  puVar1[6] = 1;
  __aeabi_memclr((int)puVar1 + 0x8192,0x280);
  __aeabi_memclr4(puVar1 + 0x1c,0x8121);
  iVar2 = FUN_001065d0(&local_58,4);
  if (iVar2 == 1) {
    *param_2 = local_44;
    if (local_3c != (undefined4 *)0x0) {
      (*local_34)(local_30);
      return 0;
    }
    return 0;
  }
  if (local_3c != (undefined4 *)0x0) {
    (*local_34)(local_30);
  }
  if (iVar2 == 0) {
    iVar2 = -5;
  }
  return iVar2;
}

