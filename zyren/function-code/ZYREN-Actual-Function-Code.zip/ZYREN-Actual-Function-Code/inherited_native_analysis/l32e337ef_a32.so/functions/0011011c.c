/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011011c FUN_0011011c */

undefined4 FUN_0011011c(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  uint local_474;
  undefined auStack_470 [68];
  int local_42c;
  int local_424;
  
  iVar1 = FUN_0010d5e8(param_1,param_2,0,param_4,&local_474);
  if (iVar1 != 0) {
    iVar1 = 0;
    if (param_1 != 0) {
      piVar2 = *(int **)(param_1 + 0x48);
      iVar1 = 0;
      if ((piVar2 != (int *)0x0) && (iVar1 = 0, local_474 < *(uint *)(param_1 + 0x10))) {
        iVar1 = *piVar2 + *(int *)(piVar2[4] + local_474 * 4);
      }
    }
    iVar1 = FUN_001107b8(param_1,local_474,iVar1,auStack_470,0);
    if (iVar1 != 0) {
      if ((local_42c == 0) && (local_424 != 0)) {
        uVar3 = FUN_0010e71c(param_1,local_474,DAT_00110214 + 0x110200,param_3,param_4);
        return uVar3;
      }
      if (param_1 != 0) {
        *(undefined4 *)(param_1 + 0x1c) = 6;
      }
    }
  }
  return 0;
}

