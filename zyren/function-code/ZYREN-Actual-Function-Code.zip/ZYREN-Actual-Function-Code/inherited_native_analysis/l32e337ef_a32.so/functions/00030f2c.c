/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030f2c FUN_00030f2c */

int FUN_00030f2c(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  char *__s;
  
  iVar1 = dlopen(param_1,0);
  if (iVar1 == 0) {
    __s = (char *)dlerror();
    puts(__s);
    return 0;
  }
  iVar2 = dlsym(iVar1,param_2);
  dlclose(iVar1);
  if (iVar2 != 0) {
    return iVar2;
  }
  iVar1 = FUN_00031010(param_1);
  if (iVar1 != 0) {
    iVar1 = FUN_000311a0(iVar1,param_2);
    return iVar1;
  }
  return 0;
}

