/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001186b0 FUN_001186b0 */

undefined4 FUN_001186b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  uVar1 = 0xfffffffd;
  if ((*(int *)(param_1 + 0x14) == 1) && (-1 < *(int *)(param_1 + 0x58))) {
    iVar2 = FUN_0010dc40(param_1,*(int *)(param_1 + 0x58),param_2,param_3,0,0,0,0);
    if (iVar2 == 0) {
      return 0xffffffee;
    }
    uVar1 = *(undefined4 *)(param_1 + 0x60);
  }
  return uVar1;
}

