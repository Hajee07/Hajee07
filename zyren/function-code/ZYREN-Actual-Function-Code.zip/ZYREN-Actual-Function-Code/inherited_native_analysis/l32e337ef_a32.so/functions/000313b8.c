/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000313b8 FUN_000313b8 */

undefined4 FUN_000313b8(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  
  uVar5 = param_1[8];
  *param_2 = 0x40;
  param_2[8] = *param_1;
  param_2[5] = param_1[3];
  param_2[7] = param_1[1];
  param_2[6] = param_1[2];
  uVar4 = param_1[4];
  param_2[4] = uVar4;
  param_2[3] = param_1[5];
  param_2[2] = param_1[6];
  uVar3 = param_1[7];
  param_2[0x12] = 0;
  param_2[0x13] = 0;
  param_2[1] = uVar3;
  param_2[10] = uVar5 << 0x14;
  param_2[0xb] = uVar5 << 0x18;
  param_2[0xc] = uVar5 << 0x19;
  param_2[0xd] = uVar5 << 0x1f;
  param_2[0xe] = uVar5 >> 2;
  param_2[0xf] = uVar5 >> 4;
  param_2[0x10] = param_3 + -0x40;
  param_2[0x11] = uVar4;
  param_3 = param_3 + -0x50;
  if (0 < param_3) {
    puVar1 = (undefined *)param_1[4];
    puVar2 = param_2 + 0x14;
    do {
      *(undefined *)puVar2 = *puVar1;
      param_3 = param_3 + -1;
      puVar1 = puVar1 + 1;
      puVar2 = (undefined4 *)((int)puVar2 + 1);
    } while (param_3 != 0);
  }
  return 0;
}

