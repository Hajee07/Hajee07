/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011ba3c FUN_0011ba3c */

void FUN_0011ba3c(int **param_1)

{
  int **__ptr;
  int **ppiVar1;
  int **ppiVar2;
  
  __ptr = (int **)*param_1;
  if (__ptr != param_1 && __ptr != (int **)0x0) {
    do {
      ppiVar2 = (int **)*__ptr;
      ppiVar1 = (int **)__ptr[1];
      ppiVar2[1] = (int *)ppiVar1;
      *ppiVar1 = (int *)ppiVar2;
      free(__ptr);
      if (ppiVar2 == param_1) {
        return;
      }
      __ptr = ppiVar2;
    } while (ppiVar2 != (int **)0x0);
  }
  return;
}

