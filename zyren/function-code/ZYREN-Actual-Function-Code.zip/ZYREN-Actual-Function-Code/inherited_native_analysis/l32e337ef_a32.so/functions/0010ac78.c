/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010ac78 FUN_0010ac78 */

int * FUN_0010ac78(int param_1,uint param_2,uint param_3,int param_4,uint *param_5,uint param_6,
                  int param_7)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  size_t sVar5;
  int *__ptr;
  int iVar6;
  int iVar7;
  int *piVar8;
  byte *pbVar9;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  uint uVar13;
  int *piVar14;
  undefined4 *puVar15;
  uint uVar16;
  uint uVar17;
  int local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 local_54;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined uStack_48;
  undefined local_47;
  undefined local_46;
  undefined local_45;
  undefined4 local_44;
  undefined local_40;
  int local_38;
  uint local_34;
  size_t local_30;
  int *local_2c;
  int local_28;
  
  __ptr = (int *)malloc(0x4df40);
  *param_5 = 0;
  if (__ptr != (int *)0x0) {
    iVar6 = param_4 * param_2;
    uVar11 = 0;
    local_28 = 1;
    local_34 = 0;
    iVar7 = (iVar6 + 1) * param_3;
    uVar13 = iVar7 + 0x39;
    if (iVar7 < 0x40) {
      uVar13 = 0x79;
    }
    local_30 = uVar13;
    local_2c = (int *)malloc(uVar13);
    if (local_2c != (int *)0x0) {
      local_38 = 0x29;
      uVar16 = 1;
      iVar7 = local_38;
      sVar5 = local_30;
      piVar8 = local_2c;
      if (uVar13 != 0) goto LAB_0010ad90;
LAB_0010ad4c:
      iVar7 = local_38;
      if (local_28 != 0) {
        do {
          sVar5 = 0x80;
          if (0x80 < uVar13 * 2) {
            sVar5 = uVar13 << 1;
          }
          uVar13 = sVar5;
        } while (uVar13 < uVar16);
        piVar8 = (int *)realloc(local_2c,uVar13);
        sVar5 = uVar13;
        if (piVar8 != (int *)0x0) goto LAB_0010ad90;
      }
joined_r0x0010ad2c:
      uVar13 = local_30;
      iVar7 = iVar7 + -1;
      local_38 = iVar7;
      local_30 = uVar13;
      if (iVar7 == 0) {
        if (9 < param_6) {
          param_6 = 10;
        }
        uVar11 = *(uint *)(DAT_0010b41c + 0x10adc0 + param_6 * 4);
        iVar7 = DAT_0010b420 + 0x10adf4;
        __ptr[1] = (int)&local_34;
        *__ptr = iVar7;
        __ptr[2] = uVar11 | 0x1000;
        __ptr[5] = (uVar11 << 0x11) >> 0x1f;
        __ptr[3] = ((uVar11 & 0xfff) + 2) / 3 + 1;
        __ptr[4] = (((uVar11 & 0xfff) >> 2) + 2) / 3 + 1;
        __aeabi_memclr(&DAT_00029272 + (int)__ptr,0x10000);
        *(undefined *)((int)__ptr + 0x9272) = 0;
        __ptr[8] = 0;
        __ptr[9] = 0;
        __ptr[0xf] = 0;
        __ptr[7] = 0;
        __ptr[0x10] = 0;
        __ptr[0x11] = 0;
        __ptr[0x12] = 0;
        __ptr[0x16] = 0;
        __ptr[0x17] = 0;
        __ptr[0x18] = 0;
        __ptr[0x19] = 0;
        __ptr[0x1a] = 0;
        __ptr[10] = (int)__ptr + 0x9273;
        __ptr[0xe] = 8;
        __ptr[0x1b] = 0;
        __ptr[0xd] = (int)(&UNK_00039272 + (int)__ptr);
        __ptr[0xc] = (int)(&UNK_00039272 + (int)__ptr);
        __ptr[0xb] = (int)(undefined *)((int)__ptr + 0x9272);
        __ptr[0x14] = 0;
        __ptr[0x15] = 0;
        __ptr[0x13] = 0;
        __ptr[6] = 1;
        __aeabi_memclr((int)__ptr + 0x8192,0x280);
        __aeabi_memclr4(__ptr + 0x1c,0x8121);
        if (0 < (int)param_3) {
          if (param_7 == 0) {
            uVar11 = param_3;
            do {
              local_68 = 1;
              FUN_001067f4(__ptr,&local_38,&local_68,0,0,0);
              local_68 = iVar6;
              FUN_001067f4(__ptr,param_1,&local_68,0,0,0);
              param_1 = param_1 + iVar6;
              uVar11 = uVar11 - 1;
            } while (uVar11 != 0);
          }
          else {
            param_1 = iVar6 * (param_3 - 1) + param_1;
            uVar11 = param_3;
            do {
              local_68 = 1;
              FUN_001067f4(__ptr,&local_38,&local_68,0,0,0);
              local_68 = iVar6;
              FUN_001067f4(__ptr,param_1,&local_68,0,0,0);
              param_1 = param_1 - iVar6;
              uVar11 = uVar11 - 1;
            } while (uVar11 != 0);
          }
        }
        local_68 = 0;
        iVar7 = FUN_001067f4(__ptr,0,&local_68,0,0,4);
        piVar8 = local_2c;
        iVar6 = DAT_0010b428;
        if (iVar7 == 1) {
          iVar7 = DAT_0010b424 + 0x10b0c4;
          uVar11 = *(uint *)(iVar7 + ((param_2 << 0x10) >> 0x18 ^ 0xc4) * 4);
          uVar16 = local_34 - 0x29;
          piVar14 = (int *)(DAT_0010b428 + 0x10b0e8);
          *param_5 = uVar16;
          uVar11 = uVar11 ^ 0x75a723;
          uVar11 = *(uint *)(iVar7 + ((uVar11 ^ param_2) & 0xff) * 4) ^ uVar11 >> 8;
          uVar11 = *(uint *)(iVar7 + (uVar11 & 0xff) * 4) ^ uVar11 >> 8;
          uVar11 = *(uint *)(iVar7 + (uVar11 & 0xff) * 4) ^ uVar11 >> 8;
          uVar11 = *(uint *)(iVar7 + ((uVar11 ^ param_3 >> 8) & 0xff) * 4) ^ uVar11 >> 8;
          local_68 = *piVar14;
          uStack_64 = *(undefined4 *)(iVar6 + 0x10b0ec);
          uStack_60 = *(undefined4 *)(iVar6 + 0x10b0f0);
          uStack_5c = *(undefined4 *)(iVar6 + 0x10b0f4);
          uVar13 = *(uint *)(iVar6 + 0x10b100);
          local_40 = *(undefined *)(iVar6 + 0x10b110);
          local_45 = (undefined)(uVar16 >> 8);
          uVar11 = *(uint *)(iVar7 + ((uVar11 ^ param_3) & 0xff) * 4) ^ uVar11 >> 8;
          local_46 = (undefined)(uVar16 >> 0x10);
          local_44 = CONCAT31((int3)((uint)*(undefined4 *)(iVar6 + 0x10b10c) >> 8),(char)uVar16);
          bVar4 = *(byte *)(DAT_0010b42c + 0x10b178 + param_4);
          uVar11 = *(uint *)(iVar7 + (uVar11 & 0xff ^ 8) * 4) ^ uVar11 >> 8;
          local_47 = (undefined)(uVar16 >> 0x18);
          uVar11 = *(uint *)(iVar7 + (uVar11 & 0xff ^ (uint)bVar4) * 4) ^ uVar11 >> 8;
          uVar11 = *(uint *)(iVar7 + (uVar11 & 0xff) * 4) ^ uVar11 >> 8;
          local_54 = CONCAT13((char)param_3,
                              CONCAT12((char)(param_3 >> 8),(short)*(undefined4 *)(iVar6 + 0x10b0fc)
                                      ));
          uVar11 = *(uint *)(iVar7 + (uVar11 & 0xff ^ uVar13 >> 0x18) * 4) ^ uVar11 >> 8;
          uStack_58 = CONCAT13((char)param_2,
                               CONCAT12((char)(param_2 >> 8),
                                        (short)*(undefined4 *)(iVar6 + 0x10b0f8)));
          uVar11 = ~(*(uint *)(iVar7 + (uVar11 & 0xff ^ *(uint *)(iVar6 + 0x10b104) & 0xff) * 4) ^
                    uVar11 >> 8);
          uStack_48 = (undefined)uVar11;
          __aeabi_memcpy(local_2c,&local_68,0x29);
          uVar11 = local_34;
          uVar16 = local_34 + 0x10;
          uVar13 = local_30;
          piVar14 = local_2c;
          if (local_30 < uVar16) {
            if (local_28 != 0) {
              do {
                uVar10 = 0x80;
                if (0x80 < uVar13 * 2) {
                  uVar10 = uVar13 << 1;
                }
                uVar13 = uVar10;
              } while (uVar13 < uVar16);
              piVar8 = (int *)realloc(piVar8,uVar13);
              piVar14 = piVar8;
              if (piVar8 != (int *)0x0) goto LAB_0010b294;
            }
            *param_5 = 0;
            free(__ptr);
            free(local_2c);
            return (int *)0x0;
          }
LAB_0010b294:
          local_2c = piVar14;
          local_30 = uVar13;
          uVar10 = 0xffffffff;
          puVar15 = (undefined4 *)((int)piVar8 + local_34);
          *puVar15 = 0;
          puVar15[3] = 0x826042ae;
          puVar15[1] = 0;
          puVar15[2] = 0x444e4549;
          uVar17 = *param_5;
          pbVar12 = (byte *)((int)local_2c + 0x25);
          uVar13 = uVar17 + 4;
          if (3 < uVar13) {
            uVar10 = 0xffffffff;
            pbVar9 = pbVar12;
            do {
              bVar4 = *pbVar9;
              pbVar1 = pbVar9 + 1;
              uVar13 = uVar13 - 4;
              pbVar2 = pbVar9 + 2;
              pbVar3 = pbVar9 + 3;
              pbVar9 = pbVar9 + 4;
              uVar10 = *(uint *)(iVar7 + (uVar10 & 0xff ^ (uint)bVar4) * 4) ^ uVar10 >> 8;
              uVar10 = *(uint *)(iVar7 + (uVar10 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar10 >> 8;
              uVar10 = *(uint *)(iVar7 + (uVar10 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar10 >> 8;
              uVar10 = *(uint *)(iVar7 + (uVar10 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar10 >> 8;
            } while (3 < uVar13);
            uVar13 = uVar17 - (uVar17 & 0xfffffffc);
            pbVar12 = pbVar12 + (uVar17 & 0xfffffffc) + 4;
          }
          for (; uVar13 != 0; uVar13 = uVar13 - 1) {
            uVar10 = *(uint *)(iVar7 + (uVar10 & 0xff ^ (uint)*pbVar12) * 4) ^ uVar10 >> 8;
            pbVar12 = pbVar12 + 1;
          }
          uVar10 = ~uVar10;
          *(char *)((int)local_2c + uVar11) = (char)(uVar10 >> 0x18);
          *(char *)((int)local_2c + uVar11 + 1) = (char)(uVar10 >> 0x10);
          *(char *)((int)local_2c + uVar11 + 2) = (char)(uVar10 >> 8);
          *(char *)((int)local_2c + uVar11 + 3) = (char)uVar10;
          *param_5 = *param_5 + 0x39;
          local_34 = uVar16;
          free(__ptr);
          return local_2c;
        }
        free(__ptr);
        __ptr = local_2c;
        goto LAB_0010b27c;
      }
      uVar16 = uVar11 + 1;
      sVar5 = uVar13;
      piVar8 = local_2c;
      if (uVar16 <= uVar13) goto LAB_0010ad90;
      goto LAB_0010ad4c;
    }
LAB_0010b27c:
    free(__ptr);
  }
  return (int *)0x0;
LAB_0010ad90:
  local_2c = piVar8;
  local_30 = sVar5;
  *(char *)((int)local_2c + uVar11) = (char)iVar7;
  uVar11 = uVar16;
  local_34 = uVar16;
  iVar7 = local_38;
  goto joined_r0x0010ad2c;
}

