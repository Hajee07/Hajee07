/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011a0f8 FUN_0011a0f8 */

/* WARNING: Removing unreachable block (ram,0x0011a2ec) */
/* WARNING: Type propagation algorithm not settling */

void FUN_0011a0f8(int param_1,int param_2)

{
  byte bVar1;
  ushort uVar2;
  char cVar3;
  ushort uVar4;
  undefined uVar5;
  short *psVar6;
  uint uVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  short *psVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  undefined *puVar16;
  uint uVar17;
  undefined *puVar18;
  uint uVar19;
  byte *pbVar20;
  uint uVar21;
  byte *pbVar22;
  byte *pbVar23;
  uint uVar24;
  bool bVar25;
  undefined4 local_2a8;
  uint local_2a4 [4];
  int local_294;
  int local_290;
  int local_28c;
  int local_288;
  int local_284;
  int local_280;
  int local_27c;
  int local_278;
  int local_274;
  int local_270;
  int local_26c;
  undefined4 local_168;
  int local_164;
  int iStack_160;
  int iStack_15c;
  int iStack_158;
  int local_154;
  int local_150;
  int local_14c;
  int local_148;
  int local_144;
  int local_140;
  int local_13c;
  int local_138;
  int local_134;
  int local_130;
  undefined auStack_4a [38];
  
  if (param_2 != 0) {
    __aeabi_memset(param_1 + 0x8f12,0x90,8);
    __aeabi_memset(param_1 + 0x8fa2,0x70,9);
    *(undefined4 *)(param_1 + 0x9026) = 0x7070707;
    *(undefined4 *)(param_1 + 0x9022) = 0x7070707;
    *(undefined4 *)(param_1 + 0x901e) = 0x7070707;
    *(undefined4 *)(param_1 + 0x901a) = 0x7070707;
    *(undefined4 *)(param_1 + 0x9016) = 0x7070707;
    *(undefined4 *)(param_1 + 0x9012) = 0x7070707;
    *(undefined4 *)(param_1 + 0x902e) = 0x8080808;
    *(undefined4 *)(param_1 + 0x902a) = 0x8080808;
    *(undefined4 *)(param_1 + 0x9032) = 0x5050505;
    *(undefined4 *)(param_1 + 0x9036) = 0x5050505;
    *(undefined4 *)(param_1 + 0x903a) = 0x5050505;
    *(undefined4 *)(param_1 + 0x903e) = 0x5050505;
    *(undefined4 *)(param_1 + 0x9042) = 0x5050505;
    *(undefined4 *)(param_1 + 0x9046) = 0x5050505;
    *(undefined4 *)(param_1 + 0x904a) = 0x5050505;
    *(undefined4 *)(param_1 + 0x904e) = 0x5050505;
    __aeabi_memclr8(&local_168,0x84);
    local_148 = 1;
    iVar9 = -0x11f;
    do {
      iVar13 = param_1 + iVar9;
      bVar25 = iVar9 != -1;
      iVar9 = iVar9 + 1;
      uVar14 = (uint)*(byte *)(iVar13 + 0x9032);
      *(int *)((int)&local_168 + uVar14 * 4) = *(int *)((int)&local_168 + uVar14 * 4) + 1;
    } while (bVar25);
    iVar9 = iStack_160 + local_164 * 2;
    local_2a4[1] = local_164 << 1;
    iVar13 = iStack_15c + iVar9 * 2;
    local_2a4[2] = iVar9 * 2;
    iVar15 = iStack_158 + iVar13 * 2;
    local_2a4[3] = iVar13 * 2;
    iVar13 = local_154 + iVar15 * 2;
    iVar9 = 0;
    local_2a4[0] = 0;
    iVar10 = local_150 + iVar13 * 2;
    local_294 = iVar15 * 2;
    local_290 = iVar13 * 2;
    iVar13 = local_14c + iVar10 * 2;
    local_28c = iVar10 * 2;
    iVar10 = local_148 + iVar13 * 2;
    local_288 = iVar13 * 2;
    iVar13 = local_144 + iVar10 * 2;
    local_284 = iVar10 * 2;
    local_280 = iVar13 * 2;
    iVar13 = local_140 + iVar13 * 2;
    iVar10 = local_13c + iVar13 * 2;
    local_27c = iVar13 * 2;
    iVar13 = local_138 + iVar10 * 2;
    local_278 = iVar10 * 2;
    iVar10 = local_134 + iVar13 * 2;
    local_274 = iVar13 * 2;
    local_270 = iVar10 * 2;
    local_26c = (local_130 + iVar10 * 2) * 2;
    uVar14 = 8;
LAB_0011a304:
    uVar21 = (&local_2a8)[uVar14];
    (&local_2a8)[uVar14] = uVar21 + 1;
    uVar19 = 0;
    do {
      uVar14 = uVar14 - 1;
      uVar19 = uVar21 & 1 | uVar19 << 1;
      uVar21 = uVar21 >> 1;
    } while (0 < (int)uVar14);
    *(short *)(param_1 + iVar9 * 2 + 0x8852) = (short)uVar19;
LAB_0011a334:
    iVar9 = iVar9 + 1;
    if (iVar9 != 0x120) goto LAB_0011a2f0;
    __aeabi_memclr8(&local_168,0x84);
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9032) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9032) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9033) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9033) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9034) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9034) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9035) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9035) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9036) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9036) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9037) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9037) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9038) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9038) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9039) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9039) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903a) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903a) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903b) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903b) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903c) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903c) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903d) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903d) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903e) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903e) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903f) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x903f) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9040) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9040) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9041) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9041) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9042) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9042) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9043) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9043) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9044) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9044) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9045) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9045) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9046) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9046) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9047) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9047) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9048) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9048) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9049) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9049) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904a) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904a) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904b) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904b) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904c) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904c) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904d) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904d) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904e) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904e) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904f) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x904f) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9050) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9050) * 4) + 1;
    *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9051) * 4) =
         *(int *)((int)&local_168 + (uint)*(byte *)(param_1 + 0x9051) * 4) + 1;
    iVar9 = 0;
    local_2a4[0] = 0;
    iStack_160 = iStack_160 + local_164 * 2;
    local_2a4[1] = local_164 << 1;
    iStack_15c = iStack_15c + iStack_160 * 2;
    local_2a4[2] = iStack_160 * 2;
    iStack_158 = iStack_158 + iStack_15c * 2;
    local_2a4[3] = iStack_15c * 2;
    local_154 = local_154 + iStack_158 * 2;
    local_150 = local_150 + local_154 * 2;
    local_294 = iStack_158 * 2;
    local_14c = local_14c + local_150 * 2;
    local_290 = local_154 * 2;
    local_28c = local_150 * 2;
    local_148 = local_148 + local_14c * 2;
    local_288 = local_14c * 2;
    local_144 = local_144 + local_148 * 2;
    local_284 = local_148 * 2;
    local_280 = local_144 * 2;
    local_140 = local_140 + local_144 * 2;
    local_27c = local_140 * 2;
    local_13c = local_13c + local_140 * 2;
    local_278 = local_13c * 2;
    local_138 = local_138 + local_13c * 2;
    local_274 = local_138 * 2;
    local_134 = local_134 + local_138 * 2;
    local_270 = local_134 * 2;
    local_26c = (local_130 + local_134 * 2) * 2;
    bVar1 = *(byte *)(param_1 + 0x9032);
    while( true ) {
      uVar14 = (uint)bVar1;
      if (uVar14 != 0) {
        uVar21 = (&local_2a8)[uVar14];
        (&local_2a8)[uVar14] = uVar21 + 1;
        uVar19 = 0;
        do {
          uVar14 = uVar14 - 1;
          uVar19 = uVar21 & 1 | uVar19 << 1;
          uVar21 = uVar21 >> 1;
        } while (0 < (int)uVar14);
        *(short *)(param_1 + iVar9 * 2 + 0x8a92) = (short)uVar19;
      }
      iVar9 = iVar9 + 1;
      if (iVar9 == 0x20) break;
      bVar1 = *(byte *)(param_1 + iVar9 + 0x9032);
    }
    uVar14 = *(uint *)(param_1 + 0x44);
    uVar21 = uVar14 + 2;
    *(uint *)(param_1 + 0x44) = uVar21;
    uVar14 = *(uint *)(param_1 + 0x48) | 1 << (uVar14 & 0xff);
    *(uint *)(param_1 + 0x48) = uVar14;
    while (7 < uVar21) {
      puVar18 = *(undefined **)(param_1 + 0x30);
      if (puVar18 < *(undefined **)(param_1 + 0x34)) {
        *(undefined **)(param_1 + 0x30) = puVar18 + 1;
        *puVar18 = (char)uVar14;
        uVar21 = *(uint *)(param_1 + 0x44);
        uVar14 = *(uint *)(param_1 + 0x48);
      }
      uVar21 = uVar21 - 8;
      uVar14 = uVar14 >> 8;
      *(uint *)(param_1 + 0x44) = uVar21;
      *(uint *)(param_1 + 0x48) = uVar14;
    }
    if (*(uint *)(param_1 + 0x28) <= param_1 + 0x9272U) goto LAB_0011b2d4;
    goto LAB_0011affc;
  }
  psVar11 = (short *)(param_1 + 0x8612);
  *(undefined2 *)(param_1 + 0x8392) = 1;
  FUN_0011b384(param_1,0,0x120,0xf,0);
  FUN_0011b384(param_1,1,0x20,0xf,0);
  iVar9 = 0;
  do {
    iVar13 = iVar9;
    if (iVar13 + 0x11eU >> 1 < 0x81) break;
    iVar9 = iVar13 + -1;
  } while (*(char *)(param_1 + 0x902f + iVar13) == '\0');
  iVar9 = 0;
  do {
    iVar10 = iVar9;
    if (iVar10 + 0x1eU < 2) break;
    iVar9 = iVar10 + -1;
  } while (*(char *)(param_1 + 0x904f + iVar10) == '\0');
  pbVar23 = (byte *)&local_168;
  __aeabi_memcpy(pbVar23,param_1 + 0x8f12,iVar13 + 0x11e);
  __aeabi_memcpy(auStack_4a + iVar13,param_1 + 0x9032,iVar10 + 0x1eU);
  __aeabi_memclr(psVar11,0x26);
  uVar19 = 0;
  if (iVar13 + iVar10 == -0x13c) {
LAB_0011abac:
    FUN_0011b384(param_1,2,0x13,7,0);
    uVar14 = *(uint *)(param_1 + 0x44);
    uVar21 = uVar14 + 2;
    *(uint *)(param_1 + 0x44) = uVar21;
    uVar14 = *(uint *)(param_1 + 0x48) | 2 << (uVar14 & 0xff);
    *(uint *)(param_1 + 0x48) = uVar14;
    while (7 < uVar21) {
      puVar18 = *(undefined **)(param_1 + 0x30);
      if (puVar18 < *(undefined **)(param_1 + 0x34)) {
        *(undefined **)(param_1 + 0x30) = puVar18 + 1;
        *puVar18 = (char)uVar14;
        uVar21 = *(uint *)(param_1 + 0x44);
        uVar14 = *(uint *)(param_1 + 0x48);
      }
      uVar21 = uVar21 - 8;
      uVar14 = uVar14 >> 8;
      *(uint *)(param_1 + 0x44) = uVar21;
      *(uint *)(param_1 + 0x48) = uVar14;
    }
    uVar12 = uVar21 + 5;
    *(uint *)(param_1 + 0x44) = uVar12;
    uVar14 = uVar14 | iVar13 + 0x1d << (uVar21 & 0xff);
    *(uint *)(param_1 + 0x48) = uVar14;
    while (7 < uVar12) {
      puVar18 = *(undefined **)(param_1 + 0x30);
      if (puVar18 < *(undefined **)(param_1 + 0x34)) {
        *(undefined **)(param_1 + 0x30) = puVar18 + 1;
        *puVar18 = (char)uVar14;
        uVar12 = *(uint *)(param_1 + 0x44);
        uVar14 = *(uint *)(param_1 + 0x48);
      }
      uVar12 = uVar12 - 8;
      uVar14 = uVar14 >> 8;
      *(uint *)(param_1 + 0x44) = uVar12;
      *(uint *)(param_1 + 0x48) = uVar14;
    }
    uVar24 = uVar12 + 5;
    *(uint *)(param_1 + 0x44) = uVar24;
    uVar14 = uVar14 | iVar10 + 0x1d << (uVar12 & 0xff);
    *(uint *)(param_1 + 0x48) = uVar14;
    while (7 < uVar24) {
      puVar18 = *(undefined **)(param_1 + 0x30);
      if (puVar18 < *(undefined **)(param_1 + 0x34)) {
        *(undefined **)(param_1 + 0x30) = puVar18 + 1;
        *puVar18 = (char)uVar14;
        uVar24 = *(uint *)(param_1 + 0x44);
        uVar14 = *(uint *)(param_1 + 0x48);
      }
      uVar24 = uVar24 - 8;
      uVar14 = uVar14 >> 8;
      *(uint *)(param_1 + 0x44) = uVar24;
      *(uint *)(param_1 + 0x48) = uVar14;
    }
    iVar9 = 0x12;
    if (((((*(char *)(param_1 + 0x9161) == '\0') &&
          (iVar9 = 0x11, *(char *)(param_1 + 0x9153) == '\0')) &&
         (iVar9 = 0x10, *(char *)(param_1 + 0x9160) == '\0')) &&
        (((iVar9 = 0xf, *(char *)(param_1 + 0x9154) == '\0' &&
          (iVar9 = 0xe, *(char *)(param_1 + 0x915f) == '\0')) &&
         ((iVar9 = 0xd, *(char *)(param_1 + 0x9155) == '\0' &&
          ((iVar9 = 0xc, *(char *)(param_1 + 0x915e) == '\0' &&
           (iVar9 = 0xb, *(char *)(param_1 + 0x9156) == '\0')))))))) &&
       ((iVar9 = 10, *(char *)(param_1 + 0x915d) == '\0' &&
        (((((iVar9 = 9, *(char *)(param_1 + 0x9157) == '\0' &&
            (iVar9 = 8, *(char *)(param_1 + 0x915c) == '\0')) &&
           (iVar9 = 7, *(char *)(param_1 + 0x9158) == '\0')) &&
          ((iVar9 = 6, *(char *)(param_1 + 0x915b) == '\0' &&
           (iVar9 = 5, *(char *)(param_1 + 0x9159) == '\0')))) &&
         (iVar9 = 4, *(char *)(param_1 + 0x915a) == '\0')))))) {
      iVar9 = 3;
    }
    uVar21 = uVar24 + 4;
    *(uint *)(param_1 + 0x44) = uVar21;
    uVar14 = uVar14 | iVar9 + -3 << (uVar24 & 0xff);
    *(uint *)(param_1 + 0x48) = uVar14;
    while (7 < uVar21) {
      puVar18 = *(undefined **)(param_1 + 0x30);
      if (puVar18 < *(undefined **)(param_1 + 0x34)) {
        *(undefined **)(param_1 + 0x30) = puVar18 + 1;
        *puVar18 = (char)uVar14;
        uVar21 = *(uint *)(param_1 + 0x44);
        uVar14 = *(uint *)(param_1 + 0x48);
      }
      uVar21 = uVar21 - 8;
      uVar14 = uVar14 >> 8;
      *(uint *)(param_1 + 0x44) = uVar21;
      *(uint *)(param_1 + 0x48) = uVar14;
    }
    iVar10 = DAT_0011b37c + 0x11ae50;
    iVar13 = 0;
    do {
      bVar1 = *(byte *)(param_1 + (uint)*(byte *)(iVar10 + iVar13) + 0x9152);
      *(uint *)(param_1 + 0x44) = uVar21 + 3;
      uVar14 = uVar14 | (uint)bVar1 << (uVar21 & 0xff);
      *(uint *)(param_1 + 0x48) = uVar14;
      uVar21 = uVar21 + 3;
      iVar15 = DAT_0011b380;
      while (DAT_0011b380 = iVar15, 7 < uVar21) {
        puVar18 = *(undefined **)(param_1 + 0x30);
        if (puVar18 < *(undefined **)(param_1 + 0x34)) {
          *(undefined **)(param_1 + 0x30) = puVar18 + 1;
          *puVar18 = (char)uVar14;
          uVar21 = *(uint *)(param_1 + 0x44);
          uVar14 = *(uint *)(param_1 + 0x48);
        }
        uVar21 = uVar21 - 8;
        uVar14 = uVar14 >> 8;
        *(uint *)(param_1 + 0x44) = uVar21;
        *(uint *)(param_1 + 0x48) = uVar14;
        iVar15 = DAT_0011b380;
      }
      bVar25 = iVar13 != iVar9;
      iVar13 = iVar13 + 1;
    } while (bVar25);
    if (uVar19 != 0) {
      uVar12 = 0;
      do {
        uVar7 = (uint)*(byte *)((int)&local_2a8 + uVar12);
        uVar2 = *(ushort *)(param_1 + uVar7 * 2 + 0x8cd2);
        uVar24 = uVar21 + *(byte *)(param_1 + uVar7 + 0x9152);
        *(uint *)(param_1 + 0x44) = uVar24;
        uVar14 = uVar14 | (uint)uVar2 << (uVar21 & 0xff);
        *(uint *)(param_1 + 0x48) = uVar14;
        uVar21 = uVar24;
        while (7 < uVar21) {
          puVar18 = *(undefined **)(param_1 + 0x30);
          if (puVar18 < *(undefined **)(param_1 + 0x34)) {
            *(undefined **)(param_1 + 0x30) = puVar18 + 1;
            *puVar18 = (char)uVar14;
            uVar21 = *(uint *)(param_1 + 0x44);
            uVar14 = *(uint *)(param_1 + 0x48);
          }
          uVar21 = uVar21 - 8;
          uVar14 = uVar14 >> 8;
          *(uint *)(param_1 + 0x44) = uVar21;
          *(uint *)(param_1 + 0x48) = uVar14;
        }
        uVar24 = uVar12 + 1;
        if (0xf < uVar7) {
          uVar24 = uVar12 + 2;
          uVar7 = uVar21 + *(byte *)(uVar7 + iVar15 + 0x11aee0);
          uVar14 = uVar14 | (uint)*(byte *)((int)&local_2a8 + uVar12 + 1) << (uVar21 & 0xff);
          *(uint *)(param_1 + 0x44) = uVar7;
          *(uint *)(param_1 + 0x48) = uVar14;
          uVar21 = uVar7;
          while (7 < uVar21) {
            puVar18 = *(undefined **)(param_1 + 0x30);
            if (puVar18 < *(undefined **)(param_1 + 0x34)) {
              *(undefined **)(param_1 + 0x30) = puVar18 + 1;
              *puVar18 = (char)uVar14;
              uVar21 = *(uint *)(param_1 + 0x44);
              uVar14 = *(uint *)(param_1 + 0x48);
            }
            uVar21 = uVar21 - 8;
            uVar14 = uVar14 >> 8;
            *(uint *)(param_1 + 0x44) = uVar21;
            *(uint *)(param_1 + 0x48) = uVar14;
          }
        }
        uVar12 = uVar24;
      } while (uVar24 < uVar19);
    }
    if (param_1 + 0x9272U < *(uint *)(param_1 + 0x28)) {
LAB_0011affc:
      pbVar23 = (byte *)(param_1 + 0x9272);
      uVar19 = 1;
      iVar9 = DAT_0011b360 + 0x11b014;
      do {
        pbVar22 = pbVar23;
        if (uVar19 == 1) {
          pbVar22 = pbVar23 + 1;
          uVar19 = *pbVar23 | 0x100;
        }
        if ((uVar19 & 1) == 0) {
          pbVar23 = pbVar22 + 1;
          uVar2 = *(ushort *)(param_1 + (uint)*pbVar22 * 2 + 0x8852);
          uVar12 = uVar21 + *(byte *)(param_1 + (uint)*pbVar22 + 0x8f12);
          *(uint *)(param_1 + 0x44) = uVar12;
          uVar14 = uVar14 | (uint)uVar2 << (uVar21 & 0xff);
          *(uint *)(param_1 + 0x48) = uVar14;
          uVar21 = uVar12;
          while (7 < uVar21) {
            puVar18 = *(undefined **)(param_1 + 0x30);
            if (puVar18 < *(undefined **)(param_1 + 0x34)) {
              *(undefined **)(param_1 + 0x30) = puVar18 + 1;
              *puVar18 = (char)uVar14;
              uVar21 = *(uint *)(param_1 + 0x44);
              uVar14 = *(uint *)(param_1 + 0x48);
            }
            uVar21 = uVar21 - 8;
            uVar14 = uVar14 >> 8;
            *(uint *)(param_1 + 0x44) = uVar21;
            *(uint *)(param_1 + 0x48) = uVar14;
          }
        }
        else {
          uVar24 = (uint)*pbVar22;
          bVar1 = pbVar22[2];
          uVar4 = *(ushort *)(pbVar22 + 1);
          uVar12 = (uint)*(ushort *)(DAT_0011b364 + 0x11b0c4 + uVar24 * 2);
          uVar2 = *(ushort *)(param_1 + uVar12 * 2 + 0x8852);
          uVar12 = uVar21 + *(byte *)(param_1 + uVar12 + 0x8f12);
          *(uint *)(param_1 + 0x44) = uVar12;
          uVar14 = uVar14 | (uint)uVar2 << (uVar21 & 0xff);
          *(uint *)(param_1 + 0x48) = uVar14;
          while (7 < uVar12) {
            puVar18 = *(undefined **)(param_1 + 0x30);
            if (puVar18 < *(undefined **)(param_1 + 0x34)) {
              *(undefined **)(param_1 + 0x30) = puVar18 + 1;
              *puVar18 = (char)uVar14;
              uVar12 = *(uint *)(param_1 + 0x44);
              uVar14 = *(uint *)(param_1 + 0x48);
            }
            uVar12 = uVar12 - 8;
            uVar14 = uVar14 >> 8;
            *(uint *)(param_1 + 0x44) = uVar12;
            *(uint *)(param_1 + 0x48) = uVar14;
          }
          uVar7 = (uint)uVar4;
          uVar17 = (uint)*(byte *)(DAT_0011b368 + 0x11b148 + uVar24);
          uVar21 = uVar12 + uVar17;
          *(uint *)(param_1 + 0x44) = uVar21;
          uVar14 = uVar14 | (*(uint *)(iVar9 + uVar17 * 4) & uVar24) << (uVar12 & 0xff);
          *(uint *)(param_1 + 0x48) = uVar14;
          iVar13 = DAT_0011b378;
          while (DAT_0011b378 = iVar13, 7 < uVar21) {
            puVar18 = *(undefined **)(param_1 + 0x30);
            if (puVar18 < *(undefined **)(param_1 + 0x34)) {
              *(undefined **)(param_1 + 0x30) = puVar18 + 1;
              *puVar18 = (char)uVar14;
              uVar21 = *(uint *)(param_1 + 0x44);
              uVar14 = *(uint *)(param_1 + 0x48);
            }
            uVar21 = uVar21 - 8;
            uVar14 = uVar14 >> 8;
            *(uint *)(param_1 + 0x44) = uVar21;
            *(uint *)(param_1 + 0x48) = uVar14;
            iVar13 = DAT_0011b378;
          }
          pbVar23 = (byte *)(DAT_0011b36c + 0x11b1c4 + (uint)bVar1);
          if (uVar7 < 0x200) {
            pbVar23 = (byte *)(DAT_0011b370 + 0x11b1cc + uVar7);
          }
          uVar12 = uVar21 + *(byte *)(param_1 + (uint)*pbVar23 + 0x9032);
          pbVar20 = (byte *)(DAT_0011b374 + 0x11b1f0 + (uint)bVar1);
          uVar2 = *(ushort *)(param_1 + (uint)*pbVar23 * 2 + 0x8a92);
          *(uint *)(param_1 + 0x44) = uVar12;
          uVar14 = uVar14 | (uint)uVar2 << (uVar21 & 0xff);
          if (uVar7 < 0x200) {
            pbVar20 = (byte *)(iVar13 + 0x11b20c + uVar7);
          }
          *(uint *)(param_1 + 0x48) = uVar14;
          bVar1 = *pbVar20;
          while (7 < uVar12) {
            puVar18 = *(undefined **)(param_1 + 0x30);
            if (puVar18 < *(undefined **)(param_1 + 0x34)) {
              *(undefined **)(param_1 + 0x30) = puVar18 + 1;
              *puVar18 = (char)uVar14;
              uVar12 = *(uint *)(param_1 + 0x44);
              uVar14 = *(uint *)(param_1 + 0x48);
            }
            uVar12 = uVar12 - 8;
            uVar14 = uVar14 >> 8;
            *(uint *)(param_1 + 0x44) = uVar12;
            *(uint *)(param_1 + 0x48) = uVar14;
          }
          uVar24 = *(uint *)(iVar9 + (uint)bVar1 * 4);
          uVar21 = uVar12 + bVar1;
          pbVar23 = pbVar22 + 3;
          *(uint *)(param_1 + 0x44) = uVar21;
          uVar14 = uVar14 | (uVar24 & uVar7) << (uVar12 & 0xff);
          *(uint *)(param_1 + 0x48) = uVar14;
          while (7 < uVar21) {
            puVar18 = *(undefined **)(param_1 + 0x30);
            if (puVar18 < *(undefined **)(param_1 + 0x34)) {
              *(undefined **)(param_1 + 0x30) = puVar18 + 1;
              *puVar18 = (char)uVar14;
              uVar21 = *(uint *)(param_1 + 0x44);
              uVar14 = *(uint *)(param_1 + 0x48);
            }
            uVar21 = uVar21 - 8;
            uVar14 = uVar14 >> 8;
            *(uint *)(param_1 + 0x44) = uVar21;
            *(uint *)(param_1 + 0x48) = uVar14;
          }
        }
        uVar19 = uVar19 >> 1;
      } while (pbVar23 < *(byte **)(param_1 + 0x28));
    }
LAB_0011b2d4:
    puVar18 = *(undefined **)(param_1 + 0x34);
    puVar16 = *(undefined **)(param_1 + 0x30);
    uVar19 = uVar21 + *(byte *)(param_1 + 0x9012);
    uVar14 = uVar14 | (uint)*(ushort *)(param_1 + 0x8a52) << (uVar21 & 0xff);
    bVar25 = puVar18 <= puVar16;
    *(uint *)(param_1 + 0x44) = uVar19;
    *(uint *)(param_1 + 0x48) = uVar14;
    while (7 < uVar19) {
      if (!bVar25) {
        *(undefined **)(param_1 + 0x30) = puVar16 + 1;
        *puVar16 = (char)uVar14;
        puVar16 = *(undefined **)(param_1 + 0x30);
        puVar18 = *(undefined **)(param_1 + 0x34);
        uVar19 = *(uint *)(param_1 + 0x44);
        uVar14 = *(uint *)(param_1 + 0x48);
      }
      uVar19 = uVar19 - 8;
      bVar25 = puVar18 <= puVar16;
      uVar14 = uVar14 >> 8;
      *(uint *)(param_1 + 0x44) = uVar19;
      *(uint *)(param_1 + 0x48) = uVar14;
    }
    return;
  }
  iVar9 = iVar13 + iVar10 + 0x13c;
  uVar19 = 0;
  uVar21 = 0;
  uVar14 = 0;
  uVar24 = 0xff;
  uVar12 = (uint)(byte)local_168;
  if (uVar12 != 0) goto LAB_0011a8ac;
  do {
    uVar7 = uVar19;
    if (uVar14 != 0) {
      if (uVar14 < 3) {
        psVar6 = (short *)(param_1 + uVar24 * 2 + 0x8612);
        *psVar6 = *psVar6 + (short)uVar14;
        __aeabi_memset((int)&local_2a8 + uVar19,uVar14);
        uVar7 = uVar14 + uVar19;
      }
      else {
        *(short *)(param_1 + 0x8632) = *(short *)(param_1 + 0x8632) + 1;
        *(undefined *)((int)&local_2a8 + uVar19) = 0x10;
        *(char *)((int)&local_2a8 + uVar19 + 1) = (char)uVar14 + -3;
        uVar7 = uVar19 + 2;
      }
    }
    if (uVar21 == 0x89) {
      *(short *)(param_1 + 0x8636) = *(short *)(param_1 + 0x8636) + 1;
      uVar5 = 0x12;
      cVar8 = '\x7f';
      goto LAB_0011aa10;
    }
    uVar14 = 0;
    uVar21 = uVar21 + 1;
    uVar24 = uVar12;
    uVar19 = uVar7;
    while( true ) {
      iVar9 = iVar9 + -1;
      if (iVar9 == 0) {
        if (uVar14 == 0) {
          if (uVar21 != 0) {
            if (uVar21 < 3) {
              *psVar11 = *psVar11 + (short)uVar21;
              __aeabi_memclr((int)&local_2a8 + uVar19,uVar21);
              uVar19 = uVar21 + uVar19;
            }
            else {
              if (uVar21 < 0xb) {
                *(short *)(param_1 + 0x8634) = *(short *)(param_1 + 0x8634) + 1;
                uVar5 = 0x11;
                cVar8 = -3;
              }
              else {
                *(short *)(param_1 + 0x8636) = *(short *)(param_1 + 0x8636) + 1;
                uVar5 = 0x12;
                cVar8 = -0xb;
              }
              *(undefined *)((int)&local_2a8 + uVar19) = uVar5;
              *(char *)((int)&local_2a8 + uVar19 + 1) = (char)uVar21 + cVar8;
              uVar19 = uVar19 + 2;
            }
          }
        }
        else if (uVar14 < 3) {
          psVar11 = (short *)(param_1 + uVar24 * 2 + 0x8612);
          *psVar11 = *psVar11 + (short)uVar14;
          __aeabi_memset((int)&local_2a8 + uVar19,uVar14,uVar24);
          uVar19 = uVar14 + uVar19;
        }
        else {
          *(short *)(param_1 + 0x8632) = *(short *)(param_1 + 0x8632) + 1;
          *(undefined *)((int)&local_2a8 + uVar19) = 0x10;
          *(char *)((int)&local_2a8 + uVar19 + 1) = (char)uVar14 + -3;
          uVar19 = uVar19 + 2;
        }
        goto LAB_0011abac;
      }
      pbVar23 = pbVar23 + 1;
      uVar12 = (uint)*pbVar23;
      if (uVar12 == 0) break;
LAB_0011a8ac:
      cVar8 = (char)uVar14;
      uVar7 = uVar19;
      if (uVar21 == 0) {
LAB_0011a8e8:
        if (uVar12 == uVar24) goto LAB_0011a8f4;
LAB_0011aa58:
        uVar21 = uVar7;
        if (uVar14 != 0) {
          if (uVar14 < 3) {
            psVar6 = (short *)(param_1 + uVar24 * 2 + 0x8612);
            *psVar6 = *psVar6 + (short)uVar14;
            __aeabi_memset((int)&local_2a8 + uVar7,uVar14);
            uVar21 = uVar7 + uVar14;
          }
          else {
            *(short *)(param_1 + 0x8632) = *(short *)(param_1 + 0x8632) + 1;
            *(undefined *)((int)&local_2a8 + uVar7) = 0x10;
            uVar21 = uVar7 + 2;
            *(char *)((int)&local_2a8 + uVar7 + 1) = cVar8 + -3;
          }
        }
        psVar6 = (short *)(param_1 + uVar12 * 2 + 0x8612);
        *psVar6 = *psVar6 + 1;
        *(char *)((int)&local_2a8 + uVar21) = (char)uVar12;
        uVar21 = uVar21 + 1;
LAB_0011a888:
        uVar14 = 0;
        uVar7 = uVar21;
      }
      else {
        if (uVar21 < 3) {
          *psVar11 = *psVar11 + (short)uVar21;
          __aeabi_memclr((int)&local_2a8 + uVar19,uVar21);
          uVar7 = uVar21 + uVar19;
          goto LAB_0011a8e8;
        }
        if (uVar21 < 0xb) {
          *(short *)(param_1 + 0x8634) = *(short *)(param_1 + 0x8634) + 1;
          uVar5 = 0x11;
          cVar3 = -3;
        }
        else {
          *(short *)(param_1 + 0x8636) = *(short *)(param_1 + 0x8636) + 1;
          uVar5 = 0x12;
          cVar3 = -0xb;
        }
        *(undefined *)((int)&local_2a8 + uVar19) = uVar5;
        uVar7 = uVar19 + 2;
        *(char *)((int)&local_2a8 + uVar19 + 1) = (char)uVar21 + cVar3;
        if (uVar12 != uVar24) goto LAB_0011aa58;
LAB_0011a8f4:
        uVar14 = uVar14 + 1;
        if (uVar14 == 6) {
          *(short *)(param_1 + 0x8632) = *(short *)(param_1 + 0x8632) + 1;
          uVar5 = 0x10;
          cVar8 = cVar8 + -2;
LAB_0011aa10:
          *(undefined *)((int)&local_2a8 + uVar7) = uVar5;
          uVar21 = uVar7 + 2;
          *(char *)((int)&local_2a8 + uVar7 + 1) = cVar8;
          goto LAB_0011a888;
        }
      }
      uVar21 = 0;
      uVar24 = uVar12;
      uVar19 = uVar7;
    }
  } while( true );
LAB_0011a2f0:
  uVar14 = (uint)*(byte *)(param_1 + iVar9 + 0x8f12);
  if (uVar14 != 0) goto LAB_0011a304;
  goto LAB_0011a334;
}

