/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000fd6c0 thunk_FUN_0005b70c */

void thunk_FUN_0005b70c(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  
  bVar2 = (byte)param_1;
  bVar3 = (byte)((uint)param_1 >> 8);
  bVar4 = (byte)((uint)param_1 >> 0x10);
  bVar1 = (byte)((uint)param_1 >> 0x18);
                    /* WARNING: Could not recover jumptable at 0x0005b794. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_0005b754 + DAT_0005b754))
            ((uint)(byte)((((((((bVar1 >> 7) << 1 | bVar1 >> 6 & 1) << 1 | bVar1 >> 5 & 1) << 1 |
                             bVar1 >> 4 & 1) << 1 | bVar1 >> 3 & 1) << 1 | bVar1 >> 2 & 1) << 1 |
                          bVar1 >> 1 & 1) << 1 | bVar1 & 1) << 0x18 |
             (uint)(byte)((((((((bVar4 >> 7) << 1 | bVar4 >> 6 & 1) << 1 | bVar4 >> 5 & 1) << 1 |
                             bVar4 >> 4 & 1) << 1 | bVar4 >> 3 & 1) << 1 | bVar4 >> 2 & 1) << 1 |
                          bVar4 >> 1 & 1) << 1 | bVar4 & 1) << 0x10 |
             (uint)(byte)((((((((bVar3 >> 7) << 1 | bVar3 >> 6 & 1) << 1 | bVar3 >> 5 & 1) << 1 |
                             bVar3 >> 4 & 1) << 1 | bVar3 >> 3 & 1) << 1 | bVar3 >> 2 & 1) << 1 |
                          bVar3 >> 1 & 1) << 1 | bVar3 & 1) << 8 |
             (uint)(byte)((((((((bVar2 >> 7) << 1 | bVar2 >> 6 & 1) << 1 | bVar2 >> 5 & 1) << 1 |
                             bVar2 >> 4 & 1) << 1 | bVar2 >> 3 & 1) << 1 | bVar2 >> 2 & 1) << 1 |
                          bVar2 >> 1 & 1) << 1 | bVar2 & 1),param_2,param_3);
  return;
}

