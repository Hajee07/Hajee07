/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010d1dc FUN_0010d1dc */

undefined4 FUN_0010d1dc(uint *param_1,int param_2,uint param_3,uint param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  code *pcVar3;
  int unaff_r5;
  int iVar4;
  uint uVar5;
  uint uVar6;
  bool bVar7;
  
  if (param_1 != (uint *)0x0) {
    unaff_r5 = param_2;
  }
  if (param_1 == (uint *)0x0 || param_2 == 0) {
    if (param_1 != (uint *)0x0) {
      param_1[7] = 0x11;
    }
    return 0;
  }
  uVar5 = 0xffffffff;
  uVar6 = 0xffffffff;
  iVar4 = -1;
  if (*(int *)(unaff_r5 + 8) != 0) {
    uVar1 = FUN_00120364(*(int *)(unaff_r5 + 8),0,1);
    uVar6 = FUN_00120364(*(undefined4 *)(unaff_r5 + 8),0,2);
    FUN_00120364(*(undefined4 *)(unaff_r5 + 8),uVar1,0);
    iVar4 = (int)uVar6 >> 0x1f;
  }
  if ((param_3 | param_4) == 0) {
    if ((*(int *)(unaff_r5 + 8) == 0) ||
       (iVar2 = FUN_00120364(*(int *)(unaff_r5 + 8),0,2), iVar2 == -1)) {
      uVar6 = 0x16;
      goto LAB_0010d31c;
    }
    iVar2 = -1;
    if (*(int *)(unaff_r5 + 8) != 0) {
      uVar1 = FUN_00120364(*(int *)(unaff_r5 + 8),0,1);
      uVar5 = FUN_00120364(*(undefined4 *)(unaff_r5 + 8),0,2);
      FUN_00120364(*(undefined4 *)(unaff_r5 + 8),uVar1,0);
      iVar2 = (int)uVar5 >> 0x1f;
    }
    param_3 = uVar5 - uVar6;
    param_4 = iVar2 - (iVar4 + (uint)(uVar5 < uVar6));
    if (-param_4 < (uint)(param_3 < 0x16)) {
      uVar6 = 8;
      goto LAB_0010d31c;
    }
  }
  uVar5 = param_1[0x12];
  bVar7 = uVar5 == 0;
  if (bVar7) {
    uVar5 = param_1[5];
  }
  if (bVar7 && uVar5 == 0) {
    pcVar3 = (code *)param_1[10];
    if (pcVar3 == (code *)0x0) {
      pcVar3 = (code *)(DAT_0010d43c + 0x10d350);
      param_1[10] = (uint)pcVar3;
    }
    if (param_1[0xb] == 0) {
      param_1[0xb] = DAT_0010d440 + 0x10d364;
    }
    if (param_1[0xc] == 0) {
      param_1[0xc] = DAT_0010d444 + 0x10d378;
    }
    param_1[7] = 0;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    uVar5 = (*pcVar3)(param_1[0xd],1,0x58);
    param_1[0x12] = uVar5;
    if (uVar5 != 0) {
      __aeabi_memclr8(uVar5,0x58);
      iVar2 = DAT_0010d448;
      uVar5 = param_1[0x12];
      *(undefined4 *)(uVar5 + 0x38) = 0;
      *(undefined4 *)(uVar5 + 0x34) = 0;
      *(undefined4 *)(uVar5 + 0x30) = param_5;
      *(undefined4 *)(uVar5 + 0x2c) = 4;
      *(undefined4 *)(uVar5 + 0x1c) = 4;
      *(undefined4 *)(uVar5 + 0xc) = 1;
      param_1[0xe] = iVar2 + 0x10d3cc;
      param_1[5] = 1;
      param_1[6] = 5;
      param_1[0x11] = (uint)param_1;
      *(int *)(uVar5 + 0x3c) = unaff_r5;
      *param_1 = param_3;
      param_1[1] = param_4;
      *(int *)(uVar5 + 0x44) = iVar4;
      *(uint *)(uVar5 + 0x40) = uVar6;
      iVar4 = FUN_0010bbd0(param_1);
      if (iVar4 != 0) {
        return 1;
      }
      FUN_0010b938(param_1,0);
      return 0;
    }
    uVar6 = 0x10;
  }
  else {
    uVar6 = 0x18;
  }
LAB_0010d31c:
  param_1[7] = uVar6;
  return 0;
}

