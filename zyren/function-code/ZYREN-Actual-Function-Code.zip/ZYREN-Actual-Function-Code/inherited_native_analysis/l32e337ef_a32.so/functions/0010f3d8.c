/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010f3d8 FUN_0010f3d8 */

uint ** FUN_0010f3d8(uint *param_1,uint param_2,uint *param_3)

{
  uint *puVar1;
  uint **ppuVar2;
  uint uVar3;
  uint *puVar4;
  int *piVar5;
  uint uVar6;
  uint *puVar7;
  int iVar8;
  code *pcVar9;
  uint *puVar10;
  uint *unaff_r5;
  uint **ppuVar11;
  uint *puVar12;
  undefined4 uVar13;
  int local_44 [6];
  ushort local_2a;
  ushort local_28;
  
  puVar1 = param_1;
  if (param_1 != (uint *)0x0) {
    puVar1 = (uint *)param_1[0x12];
    unaff_r5 = param_1;
  }
  if (param_1 == (uint *)0x0 || puVar1 == (uint *)0x0) {
    return (uint **)0x0;
  }
  ppuVar2 = (uint **)(*(code *)unaff_r5[10])(unaff_r5[0xd],1,0x2f90);
  if (ppuVar2 == (uint **)0x0) {
    unaff_r5[7] = 0x10;
    return (uint **)0x0;
  }
  piVar5 = (int *)unaff_r5[0x12];
  iVar8 = 0;
  if ((piVar5 != (int *)0x0) && (iVar8 = 0, param_2 < unaff_r5[4])) {
    iVar8 = *piVar5 + *(int *)(piVar5[4] + param_2 * 4);
  }
  iVar8 = FUN_001107b8(unaff_r5,param_2,iVar8,ppuVar2 + 0x10,0);
  if (iVar8 == 0) {
LAB_0010f6dc:
    pcVar9 = (code *)unaff_r5[0xb];
    uVar3 = unaff_r5[0xd];
  }
  else {
    if ((*(byte *)(ppuVar2 + 0x15) & 0x61) != 0) {
      pcVar9 = (code *)unaff_r5[0xb];
      uVar3 = unaff_r5[0xd];
      unaff_r5[7] = 5;
      goto LAB_0010f6e4;
    }
    uVar3 = (uint)param_3 & 0x400;
    if ((uVar3 == 0) && ((*(ushort *)((int)ppuVar2 + 0x56) | 8) != 8)) {
      pcVar9 = (code *)unaff_r5[0xb];
      uVar3 = unaff_r5[0xd];
      unaff_r5[7] = 4;
      goto LAB_0010f6e4;
    }
    *ppuVar2 = unaff_r5;
    ppuVar2[1] = param_3;
    piVar5 = local_44;
    ppuVar2[2] = (uint *)0x0;
    ppuVar2[3] = (uint *)0x0;
    ppuVar2[0xc] = (uint *)0x0;
    ppuVar2[0xd] = (uint *)0x0;
    ppuVar2[6] = (uint *)0x0;
    ppuVar2[7] = (uint *)0x0;
    ppuVar2[0x124] = (uint *)0x0;
    ppuVar2[0x125] = (uint *)0x0;
    ppuVar2[0x126] = (uint *)0x0;
    ppuVar11 = ppuVar2 + 0xe;
    *ppuVar11 = ppuVar2[0x1e];
    ppuVar2[0xf] = ppuVar2[0x1f];
    uVar13 = 0x1e;
    iVar8 = (*(code *)unaff_r5[0xe])(unaff_r5[0x11]);
    if (iVar8 != 0x1e) {
      pcVar9 = (code *)unaff_r5[0xb];
      uVar3 = unaff_r5[0xd];
      unaff_r5[7] = 0x14;
      goto LAB_0010f6e4;
    }
    if (local_44[0] == 0x4034b50) {
      uVar6 = (uint)local_2a + (uint)local_28 + 0x1e;
      puVar4 = (uint *)((int)*ppuVar11 + uVar6);
      puVar7 = (uint *)((int)ppuVar2[0xf] + (uint)CARRY4((uint)*ppuVar11,uVar6));
      *ppuVar11 = puVar4;
      ppuVar2[0xf] = puVar7;
      puVar1 = ppuVar2[0x18];
      puVar10 = ppuVar2[0x19];
      uVar6 = (int)puVar7 + (int)puVar10 + (uint)CARRY4((uint)puVar4,(uint)puVar1);
      if (uVar6 < unaff_r5[1] ||
          unaff_r5[1] - uVar6 < (uint)((uint)((int)puVar4 + (int)puVar1) <= *unaff_r5)) {
        puVar7 = puVar10;
        puVar12 = puVar1;
        if (*(int *)(unaff_r5[0x12] + 0x48) == 0) {
          if ((uVar3 == 0) && (*(short *)((int)ppuVar2 + 0x56) != 0)) {
            if (puVar10 != (uint *)0x0 || puVar10 < (uint *)(uint)((uint *)0x1fff < puVar1)) {
              puVar1 = (uint *)0x2000;
              puVar10 = (uint *)0x0;
            }
            ppuVar2[4] = puVar1;
            ppuVar2[5] = puVar10;
            puVar1 = (uint *)(*(code *)unaff_r5[10])
                                       (unaff_r5[0xd],1,puVar1,(code *)unaff_r5[10],piVar5,uVar13);
            ppuVar2[0x124] = puVar1;
            if (puVar1 == (uint *)0x0) {
              pcVar9 = (code *)unaff_r5[0xb];
              uVar3 = unaff_r5[0xd];
              unaff_r5[7] = 0x10;
              goto LAB_0010f6e4;
            }
            puVar7 = ppuVar2[0x19];
            puVar12 = ppuVar2[0x18];
          }
          else {
            ppuVar2[4] = (uint *)0x0;
            ppuVar2[5] = (uint *)0x0;
          }
          puVar1 = (uint *)0x0;
          iVar8 = 0x20;
          puVar10 = (uint *)0x0;
        }
        else {
          ppuVar2[0x124] = (uint *)(*(int *)(unaff_r5[0x12] + 0x48) + (int)puVar4);
          ppuVar2[8] = puVar1;
          iVar8 = 0x10;
          ppuVar2[9] = puVar10;
        }
        *(uint **)((int)ppuVar2 + iVar8) = puVar1;
        ((uint **)((int)ppuVar2 + iVar8))[1] = puVar10;
        ppuVar2[10] = puVar12;
        ppuVar2[0xb] = puVar7;
        if (uVar3 != 0) {
          return ppuVar2;
        }
        if (*(short *)((int)ppuVar2 + 0x56) == 0) {
          return ppuVar2;
        }
        ppuVar2[0x127] = (uint *)0x0;
        puVar1 = (uint *)(*(code *)unaff_r5[10])(unaff_r5[0xd],1,0x8000);
        ppuVar2[0x125] = puVar1;
        if (puVar1 != (uint *)0x0) {
          return ppuVar2;
        }
        unaff_r5[7] = 0x10;
        if (ppuVar2[0x124] != (uint *)0x0) {
          (*(code *)unaff_r5[0xb])(unaff_r5[0xd]);
        }
        goto LAB_0010f6dc;
      }
    }
    pcVar9 = (code *)unaff_r5[0xb];
    uVar3 = unaff_r5[0xd];
    unaff_r5[7] = 9;
  }
LAB_0010f6e4:
  (*pcVar9)(uVar3,ppuVar2);
  return (uint **)0x0;
}

