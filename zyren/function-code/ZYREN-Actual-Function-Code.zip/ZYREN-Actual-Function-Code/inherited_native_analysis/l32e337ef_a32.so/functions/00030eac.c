/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030eac FUN_00030eac */

void FUN_00030eac(byte *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = (uint)*param_1;
  if (uVar2 != 0) {
    uVar1 = 0;
    do {
      param_1 = param_1 + 1;
      uVar1 = uVar1 * 0x10 + uVar2;
      uVar2 = (uint)*param_1;
      uVar3 = uVar1 & 0xf0000000;
      if (uVar3 != 0) {
        uVar1 = uVar1 ^ uVar3 >> 0x18;
      }
      uVar1 = uVar1 & ~uVar3;
    } while (uVar2 != 0);
    return;
  }
  return;
}

