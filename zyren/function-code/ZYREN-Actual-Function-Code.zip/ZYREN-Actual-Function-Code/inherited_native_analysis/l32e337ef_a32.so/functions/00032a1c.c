/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032a1c FUN_00032a1c */

uint FUN_00032a1c(int param_1,char **param_2,uint *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char *pcVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int extraout_r1;
  uint uVar9;
  uint uVar10;
  int extraout_r1_00;
  uint local_3c;
  
  iVar1 = *(int *)(param_1 + 0x18);
  iVar2 = *(int *)(param_1 + 0x1c);
  piVar3 = *(int **)(param_1 + 0x30);
  pcVar4 = *param_2;
  *param_3 = 0;
  uVar5 = FUN_00032ee8(pcVar4);
  iVar7 = piVar3[2];
  iVar8 = *piVar3;
  FUN_00033508(uVar5,*piVar3);
  local_3c = piVar3[iVar7 + extraout_r1 + 4];
  uVar9 = piVar3[1];
  if ((uVar9 <= local_3c) &&
     (uVar10 = piVar3[3], FUN_00033508(uVar5 >> 5,piVar3[2],extraout_r1),
     uVar10 = 1 << (uVar5 & 0x1f) | 1 << (uVar5 >> (uVar10 & 0xff) & 0x1f),
     (piVar3[extraout_r1_00 + 4] & uVar10) == uVar10)) {
    while( true ) {
      if ((((uVar5 & 0xfffffffe) == (piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] & 0xfffffffeU))
          && (*(short *)(iVar1 + local_3c * 0x10 + 0xe) != 0)) &&
         (iVar6 = strcmp((char *)(iVar2 + *(int *)(iVar1 + local_3c * 0x10)),*param_2), iVar6 == 0))
      {
        if (param_2[1] == (char *)0x0) {
          return local_3c;
        }
        uVar10 = FUN_00032f54(param_1,param_2,local_3c);
        if ((uVar10 & 1) != 0) {
          return local_3c;
        }
        *param_3 = local_3c;
      }
      if (((piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] & 1U) != 0) &&
         (piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] !=
          piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 5])) break;
      local_3c = local_3c + 1;
    }
  }
  return 0;
}

