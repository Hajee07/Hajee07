/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031660 FUN_00031660 */

void FUN_00031660(int param_1,__sighandler_t param_2)

{
  bsd_signal(param_1,param_2);
  return;
}

