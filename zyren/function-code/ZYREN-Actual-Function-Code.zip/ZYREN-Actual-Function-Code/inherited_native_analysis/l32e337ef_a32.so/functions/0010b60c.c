/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b60c FUN_0010b60c */

uint FUN_0010b60c(int param_1,int *param_2,code *param_3,undefined4 param_4,uint param_5)

{
  int iVar1;
  void *__ptr;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int local_2b20;
  int local_2b1c;
  undefined4 local_2b18 [2749];
  
  __ptr = malloc(0x8000);
  if (__ptr == (void *)0x0) {
    return 0xffffffff;
  }
  iVar5 = 0;
  uVar4 = 0;
  local_2b18[0] = 0;
  while( true ) {
    local_2b1c = *param_2 - iVar5;
    local_2b20 = 0x8000 - uVar4;
    iVar2 = FUN_001081f0(local_2b18,param_1 + iVar5,&local_2b1c,__ptr,(int)__ptr + uVar4,&local_2b20
                         ,param_5 & 0xfffffff9);
    iVar1 = local_2b20;
    iVar5 = local_2b1c + iVar5;
    if ((local_2b20 != 0) && (iVar3 = (*param_3)((int)__ptr + uVar4,local_2b20,param_4), iVar3 == 0)
       ) break;
    if (iVar2 != 2) {
      uVar4 = (uint)(iVar2 == 0);
LAB_0010b6fc:
      free(__ptr);
      *param_2 = iVar5;
      return uVar4;
    }
    uVar4 = iVar1 + uVar4 & 0x7fff;
  }
  uVar4 = 0;
  goto LAB_0010b6fc;
}

