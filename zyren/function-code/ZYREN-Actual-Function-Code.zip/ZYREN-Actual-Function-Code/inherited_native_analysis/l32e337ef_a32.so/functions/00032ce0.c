/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032ce0 FUN_00032ce0 */

int FUN_00032ce0(int param_1,char **param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char *__s2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int extraout_r1;
  int local_34;
  int local_2c;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  iVar2 = *(int *)(param_1 + 0x18);
  __s2 = *param_2;
  iVar3 = FUN_000315d0(__s2);
  FUN_00033508(iVar3,*piVar1);
  *param_3 = 0;
  for (local_34 = 0; local_34 != 4; local_34 = local_34 + 1) {
    if ((iVar3 == *(int *)(DAT_00032ee0 + local_34 * 0xc + 0x32d70)) &&
       (iVar4 = strcmp(__s2,*(char **)(DAT_00032ee4 + 0x32d94 + local_34 * 0xc)), iVar4 == 0)) {
      return -local_34;
    }
  }
  local_2c = piVar1[extraout_r1 + 2];
  do {
    if (local_2c == 0) {
      return 0;
    }
    if ((*(short *)(iVar2 + local_2c * 0x10 + 0xe) != 0) &&
       (iVar3 = strcmp((char *)(*(int *)(param_1 + 0x1c) + *(int *)(iVar2 + local_2c * 0x10)),__s2),
       iVar3 == 0)) {
      if (param_2[1] == (char *)0x0) {
        return local_2c;
      }
      uVar5 = FUN_00032f54(param_1,param_2,local_2c);
      if ((uVar5 & 1) != 0) {
        return local_2c;
      }
      *param_3 = local_2c;
    }
    local_2c = piVar1[*piVar1 + local_2c + 2];
  } while( true );
}

