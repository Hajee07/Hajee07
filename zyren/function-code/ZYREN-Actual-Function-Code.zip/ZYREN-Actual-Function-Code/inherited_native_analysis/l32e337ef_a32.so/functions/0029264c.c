/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0029264c AAsset_isAllocated */

void AAsset_isAllocated(void)

{
  (*(code *)PTR_AAsset_isAllocated_00307d98)();
  return;
}

