/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b8dc FUN_0010b8dc */

int FUN_0010b8dc(int param_1)

{
  int iVar1;
  bool bVar2;
  
  bVar2 = param_1 != 0;
  if (bVar2) {
    param_1 = *(int *)(param_1 + 8);
  }
  if (!bVar2 || param_1 == 0) {
    return -1;
  }
  iVar1 = FUN_00120364(param_1);
  if (iVar1 != -1) {
    iVar1 = 0;
  }
  return iVar1;
}

