/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b938 FUN_0010b938 */

undefined4 FUN_0010b938(int param_1,int param_2,code *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *__ptr;
  bool bVar4;
  
  if (param_1 == 0) {
    return 0;
  }
  puVar2 = *(undefined4 **)(param_1 + 0x48);
  if (puVar2 == (undefined4 *)0x0) {
LAB_0010b978:
    if (param_2 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 0x18;
    }
    return 0;
  }
  bVar4 = *(int *)(param_1 + 0x28) != 0;
  if (bVar4) {
    param_3 = *(code **)(param_1 + 0x2c);
  }
  if ((!bVar4 || param_3 == (code *)0x0) || (*(int *)(param_1 + 0x14) != 1)) goto LAB_0010b978;
  *(undefined4 *)(param_1 + 0x48) = 0;
  (*param_3)(*(undefined4 *)(param_1 + 0x34),*puVar2);
  *puVar2 = 0;
  puVar2[1] = 0;
  puVar2[2] = 0;
  puVar2[3] = 0;
  (**(code **)(param_1 + 0x2c))(*(undefined4 *)(param_1 + 0x34),puVar2[4]);
  puVar2[4] = 0;
  puVar2[5] = 0;
  puVar2[6] = 0;
  puVar2[7] = 0;
  (**(code **)(param_1 + 0x2c))(*(undefined4 *)(param_1 + 0x34),puVar2[8]);
  puVar2[8] = 0;
  puVar2[9] = 0;
  puVar2[10] = 0;
  puVar2[0xb] = 0;
  __ptr = (void *)puVar2[0xf];
  if (__ptr == (void *)0x0) {
    uVar3 = 1;
    goto LAB_0010ba60;
  }
  uVar3 = 1;
  if (*(int *)(param_1 + 0x18) == 4) {
    if (*(int *)((int)__ptr + 8) != 0) {
      iVar1 = FUN_00120238();
      free(__ptr);
      if (iVar1 != -1) goto LAB_0010ba50;
    }
    uVar3 = 0;
    if (param_2 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 0x15;
    }
  }
LAB_0010ba50:
  puVar2[0xf] = 0;
LAB_0010ba60:
  (**(code **)(param_1 + 0x2c))(*(undefined4 *)(param_1 + 0x34),puVar2);
  *(undefined4 *)(param_1 + 0x14) = 0;
  return uVar3;
}

