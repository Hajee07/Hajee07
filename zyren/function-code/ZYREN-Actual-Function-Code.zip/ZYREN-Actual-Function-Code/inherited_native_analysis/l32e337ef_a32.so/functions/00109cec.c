/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00109cec FUN_00109cec */

uint FUN_00109cec(undefined4 param_1,undefined4 *param_2,undefined4 param_3,uint *param_4)

{
  uint uVar1;
  undefined4 local_50;
  uint local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 *local_34;
  int local_30;
  code *local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  
  local_28 = 0;
  local_34 = (undefined4 *)0x0;
  local_4c = *param_4;
  local_40 = *param_2;
  local_20 = 0;
  local_2c = (code *)(DAT_00109e60 + 0x109d3c);
  local_24 = 0;
  local_30 = DAT_00109e64 + 0x109d44;
  local_38 = 0;
  local_1c = 0;
  local_3c = 0;
  local_48 = 0;
  local_50 = param_3;
  local_44 = param_1;
  local_34 = (undefined4 *)malloc(0xab08);
  if (local_34 == (undefined4 *)0x0) {
    return 0xfffffffc;
  }
  *local_34 = 0;
  local_34[0x2ac1] = 1;
  local_34[0xabc] = 0;
  local_34[0xabd] = 0;
  local_34[0xabe] = 1;
  local_34[0xabf] = 0;
  local_34[0xac0] = 0xf;
  uVar1 = FUN_00107d18(&local_50,4);
  *param_4 = *param_4 - local_4c;
  if (uVar1 == 1) {
    *param_2 = local_3c;
    if (local_34 != (undefined4 *)0x0) {
      (*local_2c)(local_28);
      return 0;
    }
    return 0;
  }
  if (local_34 != (undefined4 *)0x0) {
    (*local_2c)(local_28);
  }
  if ((uVar1 ^ 0xfffffffb | local_4c) == 0) {
    uVar1 = 0xfffffffd;
  }
  return uVar1;
}

