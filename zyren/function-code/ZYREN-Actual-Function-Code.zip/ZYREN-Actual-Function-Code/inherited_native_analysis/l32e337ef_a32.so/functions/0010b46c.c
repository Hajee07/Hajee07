/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010b46c FUN_0010b46c */

void * FUN_0010b46c(int param_1,int param_2,int *param_3,uint param_4)

{
  int iVar1;
  size_t sVar2;
  void *pvVar3;
  int iVar4;
  uint uVar5;
  void *__ptr;
  size_t __size;
  int iVar6;
  int local_2b20;
  int local_2b1c;
  undefined4 local_2b18 [2749];
  
  *param_3 = 0;
  local_2b18[0] = 0;
  uVar5 = param_4 & 0xfffffff9 | 4;
  iVar4 = 0;
  iVar6 = 0;
  __size = 0;
  __ptr = (void *)0x0;
  while( true ) {
    local_2b1c = param_2 - iVar6;
    local_2b20 = __size - iVar4;
    if (__ptr == (void *)0x0) {
      iVar4 = FUN_001081f0(local_2b18,param_1 + iVar6,&local_2b1c,0,0,&local_2b20,uVar5);
      iVar1 = local_2b1c;
    }
    else {
      iVar4 = FUN_001081f0(local_2b18,param_1 + iVar6,&local_2b1c,__ptr,(int)__ptr + iVar4,
                           &local_2b20,uVar5);
      iVar1 = local_2b1c;
    }
    local_2b1c = iVar1;
    if ((iVar4 < 0) || (iVar4 == 1)) break;
    *param_3 = *param_3 + local_2b20;
    if (iVar4 == 0) {
      return __ptr;
    }
    sVar2 = 0x80;
    if (0x80 < __size * 2) {
      sVar2 = __size << 1;
    }
    __size = sVar2;
    pvVar3 = realloc(__ptr,__size);
    if (pvVar3 == (void *)0x0) break;
    iVar6 = iVar1 + iVar6;
    iVar4 = *param_3;
    __ptr = pvVar3;
  }
  free(__ptr);
  *param_3 = 0;
  return (void *)0x0;
}

