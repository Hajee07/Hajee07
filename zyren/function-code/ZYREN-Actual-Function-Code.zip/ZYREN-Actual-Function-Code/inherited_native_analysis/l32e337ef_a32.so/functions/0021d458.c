/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d458 FUN_0021d458 */

int FUN_0021d458(byte *param_1,byte *param_2)

{
  byte *pbVar1;
  uint uVar2;
  
  uVar2 = (uint)*param_1;
  if (uVar2 != 0) {
    pbVar1 = param_1 + 1;
    do {
      if (uVar2 != *param_2) {
        return uVar2 - *param_2;
      }
      uVar2 = (uint)*pbVar1;
      param_2 = param_2 + 1;
      pbVar1 = pbVar1 + 1;
    } while (uVar2 != 0);
  }
  return -(uint)*param_2;
}

