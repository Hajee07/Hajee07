/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030a20 FUN_00030a20 */

int FUN_00030a20(undefined4 param_1,size_t *param_2)

{
  void *pvVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  size_t __size;
  undefined auStack_128 [264];
  
  __size = *param_2;
  pvVar1 = malloc(__size);
  thunk_FUN_001f9b0c(auStack_128,param_2 + 2,0x10);
  thunk_FUN_001e824c(auStack_128,param_2 + 6,pvVar1,__size);
  iVar2 = FUN_00030af0((int)pvVar1 + 8);
  if (iVar2 != 0) {
    FUN_00030c94();
    FUN_00030794(iVar2);
    if (*(code **)(iVar2 + 0x10) != (code *)0x0) {
      (**(code **)(iVar2 + 0x10))();
    }
    if (*(int *)(iVar2 + 0x18) != 0) {
      iVar4 = 0;
      do {
        pcVar3 = *(code **)(*(int *)(iVar2 + 0x14) + iVar4 * 4);
        if ((code *)0x1 < pcVar3 + 1) {
          (*pcVar3)();
        }
        iVar4 = iVar4 + 1;
      } while (iVar4 != *(int *)(iVar2 + 0x18));
    }
    return iVar2;
  }
                    /* WARNING: Subroutine does not return */
  exit(0xde);
}

