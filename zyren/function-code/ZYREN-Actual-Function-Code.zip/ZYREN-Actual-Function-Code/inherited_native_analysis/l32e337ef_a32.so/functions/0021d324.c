/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d324 FUN_0021d324 */

int FUN_0021d324(int param_1,int param_2,int param_3,int *param_4,byte *param_5)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int extraout_r1;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar3 = (uint)*param_5;
  uVar1 = 0;
  if (uVar3 != 0) {
    uVar1 = 0;
    pbVar4 = param_5 + 1;
    do {
      uVar1 = uVar1 * 0x10 + uVar3;
      uVar3 = (uint)*pbVar4;
      uVar5 = uVar1 & 0xf0000000;
      if (uVar5 != 0) {
        uVar1 = uVar1 ^ uVar5 >> 0x18;
      }
      uVar1 = uVar1 & ~uVar5;
      pbVar4 = pbVar4 + 1;
    } while (uVar3 != 0);
  }
  iVar6 = *param_4;
  FUN_0021daf4(uVar1,iVar6);
  iVar7 = param_4[extraout_r1 + 2];
  if (iVar7 == 0) {
    return 0;
  }
  while ((iVar8 = param_2 + iVar7 * 0x10, *(short *)(iVar8 + 0xe) == 0 ||
         (iVar2 = FUN_0021d458(param_3 + *(int *)(param_2 + iVar7 * 0x10),param_5), iVar2 != 0))) {
    iVar7 = param_4[iVar7 + iVar6 + 2];
    if (iVar7 == 0) {
      return 0;
    }
  }
  return *(int *)(iVar8 + 4) + param_1;
}

