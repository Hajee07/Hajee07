/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00200abc FUN_00200abc */

undefined8 FUN_00200abc(undefined4 param_1,undefined4 param_2)

{
  return CONCAT44(param_2,param_1);
}

