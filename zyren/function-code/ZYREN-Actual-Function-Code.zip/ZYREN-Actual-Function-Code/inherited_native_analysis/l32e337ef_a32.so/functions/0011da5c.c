/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011da5c FUN_0011da5c */

void FUN_0011da5c(void)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 local_1c;
  
  iVar1 = DAT_0011dbd0;
  local_1c = 0;
  piVar2 = *(int **)(DAT_0011dbd0 + 0x11da94);
  if ((piVar2 != (int *)0x0) &&
     (iVar3 = (**(code **)(*piVar2 + 0x10))(piVar2,&local_1c,0), iVar3 == 0)) {
    do {
      do {
        do {
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          usleep(100000);
          iVar3 = thunk_FUN_00170fcc(local_1c);
        } while (iVar3 == 0);
      } while (*(int *)(iVar1 + 0x11dac8) == 0);
      thunk_FUN_0022edb0(0xdead9030);
    } while( true );
  }
  return;
}

