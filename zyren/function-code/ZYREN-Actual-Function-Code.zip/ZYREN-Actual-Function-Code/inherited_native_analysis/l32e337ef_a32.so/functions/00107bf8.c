/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00107bf8 FUN_00107bf8 */

undefined4 FUN_00107bf8(int param_1)

{
  undefined4 *puVar1;
  code *pcVar2;
  
  if (param_1 == 0) {
    return 0xfffffffe;
  }
  pcVar2 = *(code **)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (pcVar2 == (code *)0x0) {
    pcVar2 = (code *)(DAT_00107cb8 + 0x107c48);
    *(code **)(param_1 + 0x20) = pcVar2;
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    *(int *)(param_1 + 0x24) = DAT_00107cbc + 0x107c5c;
  }
  puVar1 = (undefined4 *)(*pcVar2)(*(undefined4 *)(param_1 + 0x28),1,0xab08);
  if (puVar1 == (undefined4 *)0x0) {
    return 0xfffffffc;
  }
  *(undefined4 **)(param_1 + 0x1c) = puVar1;
  *puVar1 = 0;
  puVar1[0x2ac1] = 1;
  puVar1[0xabc] = 0;
  puVar1[0xabd] = 0;
  puVar1[0xabe] = 1;
  puVar1[0xabf] = 0;
  puVar1[0xac0] = 0xf;
  return 0;
}

