/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0012009c FUN_0012009c */

bool FUN_0012009c(uint param_1,undefined4 param_2,uint param_3,int param_4)

{
  uint uVar1;
  FILE *__stream;
  char *pcVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  undefined4 local_238;
  undefined local_234;
  uint local_230;
  uint local_22c;
  char acStack_228 [516];
  
  param_4 = param_4 - (uint)(param_3 == 0);
  if (param_1 != 0) {
    bVar4 = (uint)-param_4 < (uint)(param_3 != 0);
    uVar1 = -(param_4 + (uint)(param_3 == 0));
    if (bVar4) {
      uVar1 = ~param_1;
    }
    if ((bVar4 && param_3 <= uVar1) &&
       (__stream = fopen((char *)(DAT_001201c8 + 0x1200f8),(char *)(DAT_001201cc + 0x1200fc)),
       __stream != (FILE *)0x0)) {
      pcVar2 = fgets(acStack_228,0x200,__stream);
      if (pcVar2 != (char *)0x0) {
        do {
          local_22c = 0;
          local_230 = 0;
          local_234 = 0;
          local_238 = 0;
          iVar3 = sscanf(acStack_228,(char *)(DAT_001201d0 + 0x120180),&local_22c,&local_230,
                         &local_238);
          if (iVar3 == 3) {
            bVar5 = param_1 <= local_22c;
            bVar4 = local_22c == param_1;
            if (!bVar5 || bVar4) {
              bVar5 = local_230 <= param_3 + param_1;
              bVar4 = param_3 + param_1 == local_230;
            }
            if (!bVar5 || bVar4) {
              bVar4 = (char)local_238 == 'r';
              goto LAB_001201b4;
            }
          }
          pcVar2 = fgets(acStack_228,0x200,__stream);
        } while (pcVar2 != (char *)0x0);
      }
      bVar4 = false;
LAB_001201b4:
      fclose(__stream);
      return bVar4;
    }
  }
  return false;
}

