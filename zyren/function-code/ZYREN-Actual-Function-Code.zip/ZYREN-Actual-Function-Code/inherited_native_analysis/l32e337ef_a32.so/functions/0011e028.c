/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011e028 FUN_0011e028 */

int FUN_0011e028(byte *param_1,byte *param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = 0;
  if (param_3 == 0) {
    return iVar1;
  }
  while( true ) {
    uVar2 = (uint)*param_1;
    if (uVar2 != *param_2) {
      return uVar2 - *param_2;
    }
    if (uVar2 == 0) break;
    param_3 = param_3 + -1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
    if (param_3 == 0) {
      return iVar1;
    }
  }
  return iVar1;
}

