/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00118734 FUN_00118734 */

undefined4 FUN_00118734(int param_1,char *param_2)

{
  int *piVar1;
  uint extraout_r1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  bool bVar6;
  undefined8 uVar7;
  undefined auStack_478 [52];
  uint local_444;
  
  if (param_1 == 0) {
    uVar4 = 0xffffffff;
  }
  else {
    __aeabi_memclr8(auStack_478,0x450);
    uVar4 = 0xfffffffd;
    if ((*(int *)(param_1 + 0x14) == 1) && (uVar3 = *(uint *)(param_1 + 0x58), -1 < (int)uVar3)) {
      piVar1 = *(int **)(param_1 + 0x48);
      bVar6 = piVar1 != (int *)0x0;
      uVar2 = extraout_r1;
      if (bVar6) {
        uVar2 = *(uint *)(param_1 + 0x10);
      }
      if ((bVar6 && uVar2 < uVar3 || (!bVar6 || uVar2 == uVar3)) ||
         (iVar5 = *piVar1 + *(int *)(piVar1[4] + uVar3 * 4), iVar5 == 0)) {
        *(undefined4 *)(param_1 + 0x1c) = 0x18;
      }
      else {
        if ((*(ushort *)(iVar5 + 0x1c) != 0) &&
           (*(char *)(iVar5 + (uint)*(ushort *)(iVar5 + 0x1c) + 0x2d) == '/')) {
          return 0xffffffef;
        }
        if ((*(byte *)(iVar5 + 0x26) & 0x10) != 0) {
          return 0xffffffef;
        }
      }
      iVar5 = 0;
      uVar7 = FUN_0010fe18(param_1,uVar3,param_2,0);
      uVar2 = (uint)((ulonglong)uVar7 >> 0x20);
      uVar4 = 0xffffffed;
      if ((int)uVar7 != 0) {
        piVar1 = *(int **)(param_1 + 0x48);
        bVar6 = piVar1 != (int *)0x0;
        if (bVar6) {
          uVar2 = *(uint *)(param_1 + 0x10);
        }
        if ((!bVar6 || uVar3 <= uVar2) && (bVar6 && uVar2 != uVar3)) {
          iVar5 = *piVar1 + *(int *)(piVar1[4] + uVar3 * 4);
        }
        iVar5 = FUN_001107b8(param_1,uVar3,iVar5,auStack_478,0);
        if (iVar5 != 0) {
          if ((local_444 >> 0x10 != 0) && (iVar5 = chmod(param_2,local_444 >> 0x10), iVar5 < 0)) {
            return 0xffffffec;
          }
          return 0;
        }
      }
    }
  }
  return uVar4;
}

