/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00105d90 FUN_00105d90 */

void FUN_00105d90(undefined4 param_1,void *param_2)

{
  free(param_2);
  return;
}

