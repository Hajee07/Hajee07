/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010e6a8 FUN_0010e6a8 */

undefined4
FUN_0010e6a8(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_1c;
  
  iVar1 = FUN_0010d5e8(param_1,param_2,0,param_4,&local_1c);
  if (iVar1 == 0) {
    if (param_3 != (undefined4 *)0x0) {
      *param_3 = 0;
    }
    return 0;
  }
  uVar2 = FUN_0010e4e4(param_1,local_1c,param_3,param_4);
  return uVar2;
}

