/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00111500 FUN_00111500 */

undefined4
FUN_00111500(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  code *pcVar4;
  uint uVar5;
  
  uVar5 = (param_5 << 0x11) >> 0x1f;
  if (param_1 == (undefined4 *)0x0) {
    return 0;
  }
  if ((((param_1[0x12] == 0) && (param_1[0xf] != 0)) && (param_1[5] == 0)) &&
     (((param_5 & 0x8000) == 0 || (param_1[0xe] != 0)))) {
    uVar1 = param_1[8];
    uVar3 = param_1[9];
    if (((uVar1 | uVar3) == 0) ||
       (uVar1 = uVar1 - (uVar1 >> 1 & 0x55555555),
       uVar1 = (uVar1 & 0x33333333) + (uVar1 >> 2 & 0x33333333),
       uVar3 = uVar3 - (uVar3 >> 1 & 0x55555555),
       uVar3 = (uVar3 & 0x33333333) + (uVar3 >> 2 & 0x33333333),
       ((uVar1 + (uVar1 >> 4) & 0xf0f0f0f) * 0x1010101 >> 0x18) +
       ((uVar3 + (uVar3 >> 4) & 0xf0f0f0f) * 0x1010101 >> 0x18) < 2)) {
      pcVar4 = (code *)param_1[10];
      if (pcVar4 == (code *)0x0) {
        pcVar4 = (code *)(DAT_001116b0 + 0x111604);
        param_1[10] = pcVar4;
      }
      if (param_1[0xb] == 0) {
        param_1[0xb] = DAT_001116b4 + 0x111618;
      }
      if (param_1[0xc] == 0) {
        param_1[0xc] = DAT_001116b8 + 0x111630;
      }
      *param_1 = param_3;
      param_1[1] = param_4;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      iVar2 = (*pcVar4)(param_1[0xd],1,0x58);
      param_1[0x12] = iVar2;
      if (iVar2 != 0) {
        __aeabi_memclr8(iVar2,0x58);
        iVar2 = param_1[0x12];
        *(uint *)(iVar2 + 0x34) = uVar5;
        *(uint *)(iVar2 + 0x38) = uVar5;
        *(undefined4 *)(iVar2 + 0x2c) = 4;
        *(undefined4 *)(iVar2 + 0x1c) = 4;
        *(undefined4 *)(iVar2 + 0xc) = 1;
        param_1[5] = 2;
        param_1[6] = 1;
        return 1;
      }
      param_1[7] = 0x10;
      return 0;
    }
  }
  param_1[7] = 0x18;
  return 0;
}

