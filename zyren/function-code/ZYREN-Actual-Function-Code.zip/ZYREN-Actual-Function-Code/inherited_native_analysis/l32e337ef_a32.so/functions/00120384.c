/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00120384 FUN_00120384 */

uint FUN_00120384(uint param_1)

{
  software_interrupt(0);
  if (param_1 < 0xfffff001) {
    return param_1;
  }
  *(uint *)(DAT_0012027c + 0x120274) = -param_1;
  return 0xffffffff;
}

