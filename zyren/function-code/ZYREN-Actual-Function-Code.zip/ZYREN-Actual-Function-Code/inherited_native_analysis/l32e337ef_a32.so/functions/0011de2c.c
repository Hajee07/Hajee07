/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011de2c FUN_0011de2c */

undefined *
FUN_0011de2c(undefined *param_1,int param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  undefined *puVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined *puVar6;
  undefined *puVar7;
  undefined *puVar8;
  
  *param_3 = 0;
  *param_4 = 0;
  *param_6 = 0;
  *param_5 = 0;
  if (0 < param_2) {
    puVar8 = param_1 + param_2;
    iVar5 = 0;
    puVar1 = param_1;
    puVar7 = (undefined *)0x0;
LAB_0011de88:
    do {
      puVar3 = puVar1;
      iVar2 = iVar5;
      puVar6 = (undefined *)0x0;
      switch(*puVar3) {
      case 10:
      case 0xd:
        *puVar3 = 0;
        return puVar3 + (1 - (int)param_1);
      case 0x2d:
        iVar2 = 1;
        puVar6 = (undefined *)0x0;
        if (iVar5 != 1) break;
      case 9:
      case 0x20:
switchD_0011deb0_caseD_9:
        iVar5 = iVar2;
        puVar1 = puVar3 + 1;
        puVar7 = puVar6;
        if (puVar8 <= puVar3 + 1) {
          return (undefined *)0x0;
        }
        goto LAB_0011de88;
      }
      iVar2 = iVar5;
      puVar6 = puVar7;
      if (puVar7 != (undefined *)0x0) goto switchD_0011deb0_caseD_9;
      puVar4 = param_3;
      switch(iVar5) {
      case 0:
        break;
      case 1:
        puVar4 = param_4;
        break;
      case 2:
        puVar4 = param_5;
        if (puVar8 < puVar3 + 4) {
          return (undefined *)0x0;
        }
        break;
      default:
        goto switchD_0011df70_caseD_3;
      case 6:
        puVar4 = param_6;
      }
      *puVar4 = puVar3;
switchD_0011df70_caseD_3:
      iVar5 = iVar5 + 1;
      puVar1 = puVar3 + 1;
      puVar7 = puVar3;
    } while (puVar3 + 1 < puVar8);
  }
  return (undefined *)0x0;
}

