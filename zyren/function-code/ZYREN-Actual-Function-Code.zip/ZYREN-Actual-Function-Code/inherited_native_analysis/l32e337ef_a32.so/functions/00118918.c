/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00118918 FUN_00118918 */

uint FUN_00118918(uint *param_1,int param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int *__ptr;
  size_t sVar3;
  char *__s2;
  int iVar4;
  char *pcVar5;
  int *piVar6;
  int *piVar7;
  void *__ptr_00;
  void *pvVar8;
  void *pvVar9;
  int iVar10;
  uint uVar11;
  char cVar12;
  uint *puVar13;
  int *piVar14;
  uint *puVar15;
  uint *puVar16;
  uint *puVar17;
  int *piVar18;
  uint uVar19;
  void **ppvVar20;
  undefined4 *puVar21;
  uint uVar22;
  uint uVar23;
  int iVar24;
  uint uVar25;
  uint *puVar26;
  undefined4 *puVar27;
  char *__s1;
  int iVar28;
  char *pcVar29;
  char *pcVar30;
  char *pcVar31;
  uint *__nmemb;
  bool bVar32;
  int local_498;
  uint local_48c;
  int local_488;
  undefined auStack_478 [56];
  uint local_440;
  uint uStack_43c;
  
  uVar2 = 0xffffffff;
  if (param_1 == (uint *)0x0) {
    return 0xffffffff;
  }
  if ((param_2 == 0) && (param_3 != 0)) {
    return 0xffffffff;
  }
  if (param_2 == 0) {
    uVar2 = 0;
  }
  if (param_2 == 0 && param_3 == 0) {
    return uVar2;
  }
  __nmemb = (uint *)param_1[4];
  __ptr = (int *)calloc((size_t)__nmemb,0x18);
  if (__ptr == (int *)0x0) {
    return 0xffffffeb;
  }
  param_1[5] = 1;
  if (param_2 == 0) {
    local_48c = 0xffffffff;
    goto LAB_00118f2c;
  }
  if (0 < (int)__nmemb) {
    if (param_3 == 0) {
      piVar6 = __ptr + 4;
      uVar25 = 0xffffffff;
      uVar2 = 0;
      puVar16 = (uint *)0x0;
      do {
        local_48c = FUN_00117b08(param_1,puVar16);
        if (local_48c != 0) goto LAB_00118cb8;
        iVar28 = 0;
        piVar6[-3] = 0;
        piVar7 = (int *)param_1[0x12];
        if ((piVar7 != (int *)0x0) && (puVar16 < (uint *)param_1[4])) {
          iVar28 = *piVar7 + *(int *)(piVar7[4] + (int)puVar16 * 4);
        }
        iVar28 = FUN_001107b8(param_1,puVar16,iVar28,auStack_478,0);
        if (iVar28 == 0) goto LAB_00118efc;
        FUN_00117cdc(param_1);
        piVar7 = piVar6 + -3;
        puVar16 = (uint *)((int)puVar16 + 1);
        piVar6[-4] = -1;
        *piVar6 = 0;
        piVar6[-1] = uStack_43c;
        piVar6[-2] = local_440;
        piVar6 = piVar6 + 6;
        if ((uStack_43c <= uVar2 && (uint)(uVar25 <= local_440) <= uStack_43c - uVar2) &&
            *piVar7 == 1) {
          uVar25 = local_440;
          uVar2 = uStack_43c;
        }
      } while (__nmemb != puVar16);
    }
    else {
      uVar25 = 0xffffffff;
      uVar2 = 0;
      puVar16 = (uint *)0x0;
      do {
        local_48c = FUN_00117b08(param_1);
        if (local_48c != 0) goto LAB_00118cb8;
        iVar28 = 0;
        do {
          pcVar29 = *(char **)(param_2 + iVar28 * 4);
          __s1 = (char *)param_1[0x17];
          sVar3 = strlen(pcVar29);
          __s2 = (char *)calloc(sVar3 + 1,1);
          if (sVar3 != 0 && __s2 != (char *)0x0) {
            pcVar30 = pcVar29 + 1;
            cVar12 = *pcVar29;
            pcVar29 = __s2;
            if (cVar12 != '\\') goto LAB_00118a84;
            do {
              cVar12 = '/';
              pcVar5 = pcVar29;
              pcVar31 = pcVar30;
              while( true ) {
                pcVar29 = pcVar5 + 1;
                *pcVar5 = cVar12;
                sVar3 = sVar3 - 1;
                if (sVar3 == 0) goto LAB_00118a2c;
                pcVar30 = pcVar31 + 1;
                cVar12 = *pcVar31;
                if (cVar12 == '\\') break;
LAB_00118a84:
                pcVar5 = pcVar29;
                pcVar31 = pcVar30;
                if (cVar12 == '\0') goto LAB_00118a2c;
              }
            } while( true );
          }
LAB_00118a2c:
          if (__s2 != (char *)0x0) {
            iVar4 = strcmp(__s1,__s2);
            free(__s2);
            if (iVar4 == 0) {
              iVar28 = 1;
              goto LAB_00118a9c;
            }
          }
          iVar28 = iVar28 + 1;
        } while (iVar28 != param_3);
        iVar28 = 0;
LAB_00118a9c:
        iVar4 = 0;
        __ptr[(int)puVar16 * 6 + 1] = iVar28;
        piVar6 = (int *)param_1[0x12];
        bVar32 = piVar6 == (int *)0x0;
        puVar13 = param_1;
        if (!bVar32) {
          puVar13 = (uint *)param_1[4];
        }
        if ((bVar32 || puVar16 <= puVar13) && (!bVar32 && puVar13 != puVar16)) {
          iVar4 = *piVar6 + *(int *)(piVar6[4] + (int)puVar16 * 4);
        }
        iVar28 = FUN_001107b8(param_1,puVar16,iVar4,auStack_478,0);
        if (iVar28 == 0) goto LAB_00118efc;
        FUN_00117cdc(param_1);
        puVar13 = (uint *)((int)puVar16 + 1);
        piVar6 = __ptr + (int)puVar16 * 6;
        *piVar6 = -1;
        piVar6[2] = local_440;
        piVar6[3] = uStack_43c;
        piVar6[4] = 0;
        if ((uStack_43c <= uVar2 && (uint)(uVar25 <= local_440) <= uStack_43c - uVar2) &&
            __ptr[(int)puVar16 * 6 + 1] == 1) {
          uVar25 = local_440;
          uVar2 = uStack_43c;
        }
        puVar16 = puVar13;
      } while (puVar13 != __nmemb);
    }
    piVar6 = __ptr + 1;
    puVar16 = __nmemb;
    do {
      if ((uVar2 <= (uint)piVar6[2] && (uint)((uint)piVar6[1] <= uVar25) <= uVar2 - piVar6[2]) &&
         (*piVar6 != 1)) {
        *piVar6 = 2;
      }
      puVar16 = (uint *)((int)puVar16 + -1);
      piVar6 = piVar6 + 6;
    } while (puVar16 != (uint *)0x0);
  }
LAB_00118cc8:
  piVar6 = (int *)calloc((size_t)__nmemb,8);
  local_48c = 0xffffffeb;
  if (piVar6 != (int *)0x0) {
    if (0 < (int)__nmemb) {
      puVar15 = (uint *)(piVar6 + -2);
      puVar13 = (uint *)0x1;
      puVar16 = (uint *)0x0;
      piVar7 = piVar6;
      do {
        uVar2 = __ptr[(int)puVar16 * 6 + 2];
        uVar25 = __ptr[(int)puVar16 * 6 + 3];
        piVar6[(int)puVar16 * 2] = uVar2;
        (piVar6 + (int)puVar16 * 2)[1] = uVar25;
        puVar26 = puVar15;
        puVar17 = puVar13;
        do {
          puVar17 = (uint *)((int)puVar17 + -1);
          if ((int)puVar17 < 1) {
            puVar17 = (uint *)0x0;
            bVar32 = false;
            iVar28 = -(int)puVar16;
            if (puVar16 != (uint *)0x0) goto LAB_00118d8c;
            goto LAB_00118d18;
          }
          uVar22 = *puVar26;
          puVar1 = puVar26 + 1;
          puVar26 = puVar26 + -2;
        } while (uVar25 < *puVar1 || *puVar1 - uVar25 < (uint)(uVar2 <= uVar22));
        bVar32 = SBORROW4((int)puVar17,(int)puVar16);
        iVar28 = (int)puVar17 - (int)puVar16;
        if (puVar17 != puVar16) {
LAB_00118d8c:
          piVar14 = piVar7;
          puVar26 = puVar16;
          if (iVar28 < 0 != bVar32) {
            do {
              puVar26 = (uint *)((int)puVar26 + -1);
              *piVar14 = piVar14[-2];
              piVar14[1] = piVar14[-1];
              piVar14 = piVar14 + -2;
            } while ((int)puVar17 < (int)puVar26);
          }
          piVar6[(int)puVar17 * 2] = uVar2;
          (piVar6 + (int)puVar17 * 2)[1] = uVar25;
          piVar14 = __ptr;
          for (puVar26 = puVar16; puVar26 != (uint *)0x0; puVar26 = (uint *)((int)puVar26 + -1)) {
            if ((int)puVar17 <= *piVar14) {
              *piVar14 = *piVar14 + 1;
            }
            piVar14 = piVar14 + 6;
          }
          __ptr[(int)puVar17 * 6] = (int)puVar16;
        }
LAB_00118d18:
        puVar26 = (uint *)((int)puVar16 + 1);
        piVar7 = piVar7 + 2;
        puVar15 = puVar15 + 2;
        puVar13 = (uint *)((int)puVar13 + 1);
        __ptr[(int)puVar16 * 6] = (int)puVar17;
        puVar16 = puVar26;
      } while (puVar26 != __nmemb);
    }
    piVar7 = (int *)calloc((size_t)__nmemb,4);
    if (piVar7 == (int *)0x0) {
      free(piVar6);
    }
    else {
      iVar28 = (int)__nmemb + -1;
      if (0 < iVar28) {
        iVar4 = iVar28;
        iVar10 = *piVar6;
        piVar14 = piVar7;
        piVar18 = piVar6;
        do {
          piVar18 = piVar18 + 2;
          iVar24 = *piVar18;
          iVar4 = iVar4 + -1;
          *piVar14 = iVar24 - iVar10;
          iVar10 = iVar24;
          piVar14 = piVar14 + 1;
        } while (iVar4 != 0);
      }
      piVar7[iVar28] = *param_1 - piVar6[iVar28 * 2];
      if (0 < (int)__nmemb) {
        piVar14 = __ptr + 4;
        puVar16 = __nmemb;
        do {
          puVar16 = (uint *)((int)puVar16 + -1);
          *piVar14 = piVar7[piVar14[-4]];
          piVar14 = piVar14 + 6;
        } while (puVar16 != (uint *)0x0);
      }
      free(piVar7);
      free(piVar6);
      __ptr_00 = calloc((size_t)__nmemb,4);
      if (__ptr_00 == (void *)0x0) {
        local_48c = 0xffffffeb;
      }
      else {
        ppvVar20 = (void **)param_1[0x12];
        param_1[5] = 2;
        pvVar8 = ppvVar20[0xf];
        bVar32 = pvVar8 != (void *)0x0;
        if (bVar32) {
          pvVar8 = *(void **)((int)pvVar8 + 8);
        }
        if ((bVar32 && pvVar8 != (void *)0x0) && (iVar28 = FUN_00120364(pvVar8,0,0), iVar28 != -1))
        {
          if (0 < (int)__nmemb) {
            local_488 = 0;
            iVar28 = 0;
            local_48c = 0;
            puVar16 = (uint *)0x0;
            uVar2 = 0;
            uVar25 = 0;
            if (-1 < -(int)__nmemb) goto LAB_00119050;
            do {
              if (__ptr[(int)puVar16 * 6 + 1] == 0) {
                piVar6 = __ptr + (int)puVar16 * 6 + 4;
                iVar28 = local_488;
                do {
                  iVar28 = iVar28 + *piVar6;
                  puVar13 = __nmemb;
                  local_488 = iVar28;
                  if ((uint *)((int)__nmemb + -1) == puVar16) goto LAB_00119118;
                  piVar7 = piVar6 + 3;
                  puVar16 = (uint *)((int)puVar16 + 1);
                  piVar6 = piVar6 + 6;
                } while (*piVar7 == 0);
              }
LAB_00119050:
              do {
                uVar22 = local_48c;
                if ((int)puVar16 < (int)__nmemb) {
                  iVar4 = local_48c - (int)puVar16;
                  piVar6 = __ptr + (int)puVar16 * 6 + 4;
                  do {
                    uVar22 = local_48c;
                    if (piVar6[-3] != 1) break;
                    local_48c = local_48c + 1;
                    *(undefined4 *)((int)__ptr_00 + (int)puVar16 * 4) = 1;
                    puVar16 = (uint *)((int)puVar16 + 1);
                    iVar28 = iVar28 + *piVar6;
                    uVar25 = *piVar6 + uVar25;
                    piVar6 = piVar6 + 6;
                    uVar22 = (int)__nmemb + iVar4;
                  } while (__nmemb != puVar16);
                }
                puVar13 = puVar16;
                local_48c = uVar22;
                if ((int)puVar16 < (int)__nmemb) {
                  piVar6 = __ptr + (int)puVar16 * 6 + 4;
                  do {
                    puVar13 = puVar16;
                    if (piVar6[-3] != 2) break;
                    iVar4 = (int)*ppvVar20 + *(int *)((int)ppvVar20[4] + (int)puVar16 * 4);
                    if (iVar4 == 0) {
                      free(__ptr_00);
                      local_48c = 0xfffffffd;
                      goto LAB_00118f2c;
                    }
                    puVar16 = (uint *)((int)puVar16 + 1);
                    uVar2 = *piVar6 + uVar2;
                    *(uint *)(iVar4 + 0x2a) = *(int *)(iVar4 + 0x2a) - uVar25;
                    piVar6 = piVar6 + 6;
                    puVar13 = __nmemb;
                  } while (__nmemb != puVar16);
                }
LAB_00119118:
                puVar16 = puVar13;
                pvVar8 = ppvVar20[0xf];
                pvVar9 = calloc(1,0x1000);
                if (pvVar9 == (void *)0x0) {
                  uVar22 = 0xffffffeb;
                  if (uVar2 != 0xffffffeb) goto LAB_001192f4;
                }
                else {
                  if (uVar2 == 0) {
                    uVar22 = 0;
                  }
                  else if (pvVar8 == (void *)0x0) {
LAB_0011926c:
                    uVar22 = 0xffffffe5;
                  }
                  else {
                    uVar22 = 0;
                    local_498 = local_488;
                    iVar4 = iVar28;
                    uVar19 = uVar2;
                    do {
                      uVar23 = 0x1000;
                      if (uVar19 < 0x1000) {
                        uVar23 = uVar19;
                      }
                      if ((*(int *)((int)pvVar8 + 8) == 0) ||
                         (iVar10 = FUN_00120364(*(int *)((int)pvVar8 + 8),iVar4,0), iVar10 == -1))
                      goto LAB_0011926c;
                      if (*(int *)((int)pvVar8 + 8) == 0) {
                        if (uVar23 != 0) goto LAB_001192a8;
                      }
                      else {
                        uVar11 = FUN_001203a4(*(int *)((int)pvVar8 + 8),pvVar9,uVar23);
                        if (uVar11 != uVar23) {
LAB_001192a8:
                          uVar22 = 0xffffffe4;
                          break;
                        }
                      }
                      if ((*(int *)((int)pvVar8 + 8) == 0) ||
                         (iVar10 = FUN_00120364(*(int *)((int)pvVar8 + 8),local_498,0), iVar10 == -1
                         )) goto LAB_0011926c;
                      if (*(int *)((int)pvVar8 + 8) == 0) {
                        uVar11 = 0;
                      }
                      else {
                        uVar11 = FUN_001203c4(*(int *)((int)pvVar8 + 8),pvVar9,uVar23);
                      }
                      if (uVar11 != uVar23) {
                        uVar22 = 0xffffffe3;
                        break;
                      }
                      iVar4 = iVar4 + uVar23;
                      uVar22 = uVar23 + uVar22;
                      local_498 = local_498 + uVar23;
                      uVar19 = uVar19 - uVar23;
                    } while (uVar19 != 0);
                  }
                  free(pvVar9);
                  if (uVar22 != uVar2) {
LAB_001192f4:
                    free(__ptr_00);
                    local_48c = uVar22;
                    goto LAB_00118f2c;
                  }
                }
                iVar28 = iVar28 + uVar2;
                local_488 = local_488 + uVar2;
                if ((int)__nmemb <= (int)puVar16) {
                  uVar2 = *param_1;
                  param_1[4] = (int)__nmemb - local_48c;
                  *param_1 = uVar2 - uVar25;
                  param_1[1] = param_1[1] - (uint)(uVar2 < uVar25);
                  if (0 < (int)__nmemb) {
                    puVar16 = (uint *)0x0;
                    if (0 < (int)__nmemb) goto LAB_00119374;
                    goto LAB_00119390;
                  }
                  iVar28 = 0;
                  goto LAB_001192dc;
                }
              } while ((int)__nmemb <= (int)puVar16);
            } while( true );
          }
          param_1[4] = (uint)__nmemb;
          iVar28 = 0;
          local_48c = 0;
LAB_001192dc:
          ppvVar20[5] = (void *)(((int)__nmemb - iVar28) * 4);
          free(__ptr_00);
        }
        else {
          free(__ptr_00);
          local_48c = 0xfffffffd;
        }
      }
    }
  }
LAB_00118f2c:
  free(__ptr);
  return local_48c;
LAB_00118cb8:
  if ((int)local_48c < 0) goto LAB_00118f2c;
  goto LAB_00118cc8;
LAB_00118efc:
  local_48c = 0xfffffffd;
  goto LAB_00118f2c;
LAB_00119390:
  bVar32 = false;
  puVar13 = puVar16;
  if ((int)puVar16 < (int)__nmemb) {
    puVar15 = puVar16;
    if (*(int *)((int)__ptr_00 + (int)puVar16 * 4) == 0) {
      bVar32 = true;
    }
    else {
      do {
        puVar15 = (uint *)((int)puVar15 + 1);
        puVar13 = __nmemb;
        if (__nmemb == puVar15) break;
        puVar13 = puVar15;
      } while (*(int *)((int)__ptr_00 + (int)puVar15 * 4) != 0);
      bVar32 = (int)puVar13 < (int)__nmemb;
    }
  }
  if (puVar16 != __nmemb) {
    sVar3 = 0;
    iVar28 = *(int *)((int)ppvVar20[4] + (int)puVar16 * 4);
    if (puVar13 != __nmemb) {
      iVar4 = *(int *)((int)ppvVar20[4] + (int)puVar13 * 4);
      pvVar8 = *ppvVar20;
      iVar10 = (int)pvVar8 + iVar4;
      sVar3 = (int)ppvVar20[1] - iVar4;
      iVar4 = iVar10 - ((int)pvVar8 + iVar28);
      if ((iVar28 == 0) && (iVar10 != 0)) {
        __aeabi_memmove(pvVar8,iVar10,sVar3);
        pvVar9 = realloc(*ppvVar20,sVar3);
        *ppvVar20 = pvVar9;
        if (bVar32) {
          iVar24 = (int)__nmemb - (int)puVar13;
          piVar6 = (int *)((int)ppvVar20[4] + (int)puVar13 * 4);
          do {
            iVar24 = iVar24 + -1;
            *piVar6 = *piVar6 - iVar4;
            piVar6 = piVar6 + 1;
          } while (iVar24 != 0);
        }
      }
      if ((sVar3 * iVar28 != 0 && iVar10 != 0) &&
         (__aeabi_memmove((int)pvVar8 + iVar28,iVar10,sVar3), bVar32)) {
        iVar10 = (int)__nmemb - (int)puVar13;
        piVar6 = (int *)((int)ppvVar20[4] + (int)puVar13 * 4);
        do {
          iVar10 = iVar10 + -1;
          *piVar6 = *piVar6 - iVar4;
          piVar6 = piVar6 + 1;
        } while (iVar10 != 0);
      }
    }
    ppvVar20[1] = (void *)(sVar3 + iVar28);
  }
  if ((int)__nmemb <= (int)puVar13) goto LAB_001194e4;
  puVar16 = puVar13;
  if ((int)puVar13 < (int)__nmemb) {
LAB_00119374:
    while (*(int *)((int)__ptr_00 + (int)puVar16 * 4) == 0) {
      puVar16 = (uint *)((int)puVar16 + 1);
      if (__nmemb == puVar16) goto LAB_001194e4;
    }
  }
  goto LAB_00119390;
LAB_001194e4:
  iVar28 = 0;
  puVar16 = (uint *)0x0;
  puVar13 = puVar16;
  if (-1 < -(int)__nmemb) goto LAB_00119510;
  do {
    while (puVar13 = puVar16, *(int *)((int)__ptr_00 + (int)puVar16 * 4) != 0) {
LAB_00119510:
      do {
        if (puVar13 == __nmemb) goto LAB_001192dc;
        puVar16 = puVar13;
        if ((int)puVar13 < (int)__nmemb) {
          while (*(int *)((int)__ptr_00 + (int)puVar16 * 4) != 0) {
            puVar16 = (uint *)((int)puVar16 + 1);
            puVar15 = __nmemb;
            if (__nmemb == puVar16) goto LAB_001195a4;
          }
        }
        puVar15 = puVar16;
        if ((int)__nmemb <= (int)puVar16) {
LAB_001195a4:
          iVar28 = (iVar28 - (int)puVar13) + (int)puVar15;
          goto LAB_001192dc;
        }
        puVar21 = (undefined4 *)((int)ppvVar20[4] + (int)puVar13 * 4);
        puVar27 = (undefined4 *)((int)ppvVar20[4] + (int)puVar16 * 4);
        puVar15 = __nmemb;
        do {
          puVar15 = (uint *)((int)puVar15 + -1);
          *puVar21 = *puVar27;
          puVar21 = puVar21 + 1;
          puVar27 = puVar27 + 1;
        } while (puVar16 != puVar15);
        iVar28 = (iVar28 - (int)puVar13) + (int)puVar16;
        puVar13 = puVar16;
      } while ((int)__nmemb <= (int)puVar16);
    }
    puVar16 = (uint *)((int)puVar16 + 1);
  } while (__nmemb != puVar16);
  goto LAB_001192dc;
}

