/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010bbd0 FUN_0010bbd0 */

undefined4 FUN_0010bbd0(uint *param_1,uint param_2)

{
  ushort *puVar1;
  int iVar2;
  short *__ptr;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  byte *pbVar7;
  byte bVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  int *piVar14;
  uint uVar15;
  byte *pbVar16;
  int iVar17;
  uint uVar18;
  int *piVar19;
  short *psVar20;
  byte bVar21;
  uint uVar22;
  uint uVar23;
  bool bVar24;
  undefined4 uVar25;
  uint local_107c;
  int local_1074;
  uint local_1070;
  int local_106c;
  uint local_1064;
  uint local_1060;
  uint local_105c;
  int iStack_1058;
  uint uStack_1054;
  int local_1050;
  uint local_104c;
  int local_1048;
  uint local_1044;
  uint local_1040;
  int local_103c [2];
  uint local_1034;
  uint local_1030;
  int local_102c;
  int local_1028;
  ushort local_1024;
  ushort local_1022;
  ushort local_1020;
  ushort local_101e;
  uint local_101c;
  uint local_1018;
  
  uVar9 = *param_1;
  uVar5 = param_1[1];
  if (-uVar5 < (uint)(uVar9 < 0x16)) {
LAB_0010bbfc:
    uVar5 = 8;
  }
  else {
    uVar13 = (uint)(0 < (int)(uVar5 + (0x1000 < uVar9)) !=
                   (SBORROW4(-uVar5,(uint)(0x1000 < uVar9)) != false));
    uVar18 = 0x1000;
    if (uVar13 != 0) {
      uVar18 = uVar9;
      uVar13 = uVar5;
    }
    uVar12 = uVar18 - 0x1000;
    uVar13 = uVar13 - (uVar18 < 0x1000);
    uVar18 = uVar9 - uVar12;
    uVar5 = uVar5 - (uVar13 + (uVar9 < uVar12));
    bVar24 = 0xfff < uVar18;
    if (uVar5 != 0 || uVar5 < bVar24) {
      uVar18 = 0x1000;
    }
    piVar19 = &local_1028;
    uVar5 = (*(code *)param_1[0xe])(param_1[0x11],uVar5 - !bVar24,uVar12,uVar13,piVar19,uVar18);
    if (uVar5 == uVar18) {
      param_2 = param_2 & 0x800;
      do {
        uVar5 = uVar18 - 4;
        if (-1 < (int)(uVar18 - 4)) {
          do {
            if (*(int *)((int)piVar19 + uVar5) == 0x6054b50) {
              uVar9 = uVar12 + uVar5;
              iVar11 = uVar13 + ((int)uVar5 >> 0x1f) + (uint)CARRY4(uVar12,uVar5);
              if ((uint)(*param_1 - uVar9 < 0x16) <=
                  -(param_1[1] - (iVar11 + (uint)(*param_1 < uVar9)))) {
                uVar25 = 0x16;
                iVar2 = (*(code *)param_1[0xe])
                                  (param_1[0x11],(code *)param_1[0xe],uVar9,iVar11,piVar19,0x16);
                if (iVar2 != 0x16) goto LAB_0010c88c;
                if (local_1028 != 0x6054b50) goto LAB_0010bbfc;
                if ((int)(iVar11 - (uint)(uVar9 < 0x4c)) < 0 ==
                    (SBORROW4(iVar11,(uint)(uVar9 < 0x4c)) != false)) {
                  piVar19 = local_103c;
                  uVar25 = 0x14;
                  iVar11 = (*(code *)param_1[0xe])
                                     (param_1[0x11],(code *)param_1[0xe],uVar9 - 0x14,
                                      iVar11 - (uint)(uVar9 < 0x14),piVar19,0x14);
                  if ((iVar11 == 0x14) && (local_103c[0] == 0x7064b50)) {
                    uVar5 = param_1[1] - (uint)(*param_1 < 0x38);
                    if (uVar5 <= local_1030 &&
                        (uint)(local_1034 <= *param_1 - 0x38) <= uVar5 - local_1030)
                    goto LAB_0010bbfc;
                    piVar19 = &local_1074;
                    uVar25 = 0x38;
                    iVar11 = (*(code *)param_1[0xe])(param_1[0x11]);
                    if ((iVar11 == 0x38) && (local_1074 == 0x6064b50)) {
                      *(undefined4 *)(param_1[0x12] + 0x34) = 1;
                    }
                  }
                }
                piVar14 = (int *)param_1[0x12];
                uVar5 = (uint)local_101e;
                param_1[4] = uVar5;
                if (piVar14[0xd] == 0) {
                  uVar12 = 0;
                  local_1060 = (uint)local_1022;
                  uVar13 = (uint)local_1024;
                  uVar9 = local_101c;
                  uVar18 = local_1018;
                  if (uVar5 == local_1020) {
LAB_0010beb8:
                    if (((uVar13 | local_1060) == 0) || (local_1060 == 1 && uVar13 == 1)) {
                      if ((uVar9 < uVar5 * 0x2e) ||
                         (uVar10 = uVar12 + CARRY4(uVar18,uVar9),
                         param_1[1] <= uVar10 &&
                         (uint)(uVar18 + uVar9 <= *param_1) <= param_1[1] - uVar10))
                      goto LAB_0010be68;
                      param_1[2] = uVar18;
                      param_1[3] = uVar12;
                      if (uVar5 == 0) {
                        return 1;
                      }
                      if ((uint)piVar14[2] < uVar9) {
                        iVar11 = (*(code *)param_1[0xc])
                                           (param_1[0xd],*piVar14,piVar14[3],uVar9,piVar19,uVar25);
                        if (iVar11 == 0) goto LAB_0010c310;
                        piVar14[2] = uVar9;
                        *piVar14 = iVar11;
                        uVar5 = param_1[4];
                      }
                      piVar14[1] = uVar9;
                      uVar10 = param_1[0x12];
                      if (*(uint *)(uVar10 + 0x18) < uVar5) {
                        iVar11 = (*(code *)param_1[0xc])
                                           (param_1[0xd],*(undefined4 *)(uVar10 + 0x10),
                                            *(undefined4 *)(uVar10 + 0x1c),uVar5);
                        if (iVar11 == 0) goto LAB_0010c310;
                        *(uint *)(uVar10 + 0x18) = uVar5;
                        *(int *)(uVar10 + 0x10) = iVar11;
                      }
                      *(uint *)(uVar10 + 0x14) = uVar5;
                      if (param_2 == 0) {
                        uVar5 = param_1[0x12];
                        uVar10 = param_1[4];
                        if (*(uint *)(uVar5 + 0x28) < uVar10) {
                          iVar11 = (*(code *)param_1[0xc])
                                             (param_1[0xd],*(undefined4 *)(uVar5 + 0x20),
                                              *(undefined4 *)(uVar5 + 0x2c),uVar10);
                          if (iVar11 == 0) goto LAB_0010c310;
                          *(uint *)(uVar5 + 0x28) = uVar10;
                          *(int *)(uVar5 + 0x20) = iVar11;
                        }
                        *(uint *)(uVar5 + 0x24) = uVar10;
                      }
                      uVar5 = (*(code *)param_1[0xe])
                                        (param_1[0x11],(code *)param_1[0xe],uVar18,uVar12,
                                         *(undefined4 *)param_1[0x12],uVar9);
                      if (uVar5 != uVar9) goto LAB_0010c88c;
                      if (param_1[4] != 0) {
                        uVar10 = 0;
                        piVar19 = *(int **)param_1[0x12];
                        goto LAB_0010c030;
                      }
                      uVar5 = 0;
                      goto LAB_0010c31c;
                    }
                  }
                }
                else {
                  if ((uint)-local_106c < (uint)(local_1070 < 0x2c)) goto LAB_0010be68;
                  if (local_102c == 1) {
                    if ((local_1050 != 0) || (param_1[4] = uStack_1054, iStack_1058 != 0)) {
                      uVar5 = 2;
                      goto LAB_0010c890;
                    }
                    if (local_1048 != 0) {
                      uVar5 = 0xf;
                      goto LAB_0010c890;
                    }
                    uVar9 = local_104c;
                    uVar13 = local_1064;
                    uVar5 = uStack_1054;
                    uVar18 = local_1044;
                    uVar12 = local_1040;
                    if (uStack_1054 == local_105c) goto LAB_0010beb8;
                  }
                }
                uVar5 = 10;
                goto LAB_0010c890;
              }
            }
            bVar24 = 0 < (int)uVar5;
            uVar5 = uVar5 - 1;
          } while (bVar24);
        }
        if ((uVar12 | uVar13) == 0) {
          if (param_1 == (uint *)0x0) {
            return 0;
          }
          break;
        }
        uVar9 = *param_1;
        uVar5 = param_1[1];
        if ((uint)(uVar9 - uVar12 < 0x10015) <= -(uVar5 - (uVar13 + (uVar9 < uVar12)))) break;
        if (-uVar13 < (uint)(uVar12 < 0xffe)) {
          uVar12 = 0xffd;
          uVar13 = 0;
        }
        bVar24 = uVar12 < 0xffd;
        uVar12 = uVar12 - 0xffd;
        uVar13 = uVar13 - bVar24;
        uVar18 = uVar9 - uVar12;
        uVar9 = uVar13 + (uVar9 < uVar12);
        if (uVar5 != uVar9 || uVar5 - uVar9 < (uint)(0xfff < uVar18)) {
          uVar18 = 0x1000;
        }
        uVar5 = (*(code *)param_1[0xe])(param_1[0x11],0x1000,uVar12,uVar13,piVar19,uVar18);
      } while (uVar5 == uVar18);
    }
    uVar5 = 7;
  }
LAB_0010c890:
  param_1[7] = uVar5;
  return 0;
LAB_0010c030:
  if ((uVar9 < 0x2e) || (*piVar19 != 0x2014b50)) goto LAB_0010be68;
  piVar14 = (int *)param_1[0x12];
  *(int *)(piVar14[4] + uVar10 * 4) = (int)piVar19 - *piVar14;
  if (param_2 == 0) {
    *(uint *)(piVar14[8] + uVar10 * 4) = uVar10;
  }
  uVar23 = piVar19[5];
  uVar5 = piVar19[6];
  if ((piVar14[0xe] == 0) && (uVar22 = (uint)*(ushort *)((int)piVar19 + 0x1e), uVar22 != 0)) {
    uVar15 = uVar5;
    if (uVar5 < uVar23) {
      uVar15 = uVar23;
    }
    if (uVar15 <= *(uint *)((int)piVar19 + 0x2a)) {
      uVar15 = *(uint *)((int)piVar19 + 0x2a);
    }
    if (uVar15 == 0xffffffff) {
      uVar15 = (uint)*(ushort *)(piVar19 + 7);
      if (uVar9 < uVar15 + uVar22 + 0x2e) {
        __ptr = (short *)malloc(uVar22);
        if (__ptr == (short *)0x0) goto LAB_0010c310;
        uVar15 = (*(code *)param_1[0xe])
                           (param_1[0x11],(code *)param_1[0xe],uVar18 + 0x2e + uVar15,
                            uVar12 + (0xffffffd1 < uVar18) + (uint)CARRY4(uVar18 + 0x2e,uVar15),
                            __ptr,uVar22);
        psVar20 = __ptr;
        if (uVar15 != uVar22) {
          free(__ptr);
LAB_0010c88c:
          uVar5 = 0x14;
          goto LAB_0010c890;
        }
      }
      else {
        psVar20 = (short *)((int)piVar19 + uVar15 + 0x2e);
        __ptr = (short *)0x0;
      }
      do {
        if (uVar22 < 4) {
LAB_0010c5b0:
          free(__ptr);
          goto LAB_0010c5b4;
        }
        puVar1 = (ushort *)(psVar20 + 1);
        uVar15 = *puVar1 + 4;
        if (uVar22 < uVar15) goto LAB_0010c5b0;
        if (*psVar20 == 1) {
          uVar22 = param_1[0x12];
          *(undefined4 *)(uVar22 + 0x34) = 1;
          *(undefined4 *)(uVar22 + 0x38) = 1;
          break;
        }
        psVar20 = (short *)((int)psVar20 + uVar15);
        uVar22 = (uVar22 - *puVar1) - 4;
      } while (uVar22 != 0);
      free(__ptr);
    }
  }
  if ((uVar23 != 0xffffffff && uVar5 != 0xffffffff) &&
     (((uVar5 != uVar23 && (*(int *)((int)piVar19 + 10) == 0)) || ((uVar23 == 0 && (uVar5 != 0))))))
  {
LAB_0010c5b4:
    if (param_1 != (uint *)0x0) {
      param_1[7] = 9;
    }
    return 0;
  }
  uVar5 = (uint)*(ushort *)((int)piVar19 + 0x22);
  if ((uVar5 == 0xffff) || (uVar5 != uVar13 && uVar5 != 1)) {
    if (param_1 != (uint *)0x0) {
      param_1[7] = 10;
    }
    return 0;
  }
  if ((uVar23 != 0xffffffff) &&
     (uVar5 = uVar23 + *(uint *)((int)piVar19 + 0x2a),
     uVar23 = (uint)CARRY4(uVar23,*(uint *)((int)piVar19 + 0x2a)) + (uint)(0xffffffe1 < uVar5),
     param_1[1] <= uVar23 && (uint)(uVar5 + 0x1e <= *param_1) <= param_1[1] - uVar23))
  goto LAB_0010be68;
  if ((*(byte *)((int)piVar19 + 9) & 0x20) != 0) {
    if (param_1 != (uint *)0x0) {
      param_1[7] = 5;
    }
    return 0;
  }
  uVar23 = (uint)*(ushort *)(piVar19 + 7) + (uint)*(ushort *)((int)piVar19 + 0x1e) +
           (uint)*(ushort *)(piVar19 + 8) + 0x2e;
  if (uVar9 < uVar23) goto LAB_0010c5b4;
  uVar5 = param_1[4];
  uVar10 = uVar10 + 1;
  piVar19 = (int *)((int)piVar19 + uVar23);
  uVar9 = uVar9 - uVar23;
  if (uVar5 <= uVar10) {
LAB_0010c31c:
    if (param_2 != 0) {
      return 1;
    }
    if (uVar5 < 2) {
      return 1;
    }
    piVar19 = (int *)param_1[0x12];
    piVar14 = (int *)piVar19[8];
    uVar9 = uVar5 - 2 >> 1;
    do {
      uVar13 = uVar9 << 1 | 1;
      if (-((int)uVar9 >> 0x1f) == 0 && (uint)(uVar5 <= uVar13) <= (uint)-((int)uVar9 >> 0x1f)) {
        uVar18 = uVar9 >> 0x1f;
        local_107c = uVar9;
        do {
          uVar12 = uVar18 + (0xfffffffe < uVar13);
          if (uVar12 == 0 && (uVar5 <= uVar13 + 1) <= uVar12) {
            iVar11 = *piVar19;
            iVar2 = piVar19[4];
            iVar3 = iVar11 + *(int *)(iVar2 + piVar14[uVar13 + 1] * 4);
            iVar6 = iVar11 + *(int *)(iVar2 + piVar14[uVar13] * 4);
            uVar10 = (uint)*(ushort *)(iVar3 + 0x1c);
            uVar23 = (uint)*(ushort *)(iVar6 + 0x1c);
            uVar12 = uVar10;
            if (uVar23 < uVar10) {
              uVar12 = uVar23;
            }
            pbVar16 = (byte *)(uVar12 + iVar6 + 0x2e);
            pbVar7 = (byte *)(iVar6 + 0x2e);
            if (uVar12 == 0) {
              bVar21 = 0;
              bVar8 = 0;
            }
            else {
              pbVar4 = (byte *)(iVar3 + 0x2e);
              do {
                bVar21 = *pbVar7;
                bVar8 = *pbVar4;
                if ((byte)(bVar21 + 0xbf) < 0x1a) {
                  bVar21 = bVar21 + 0x20;
                }
                if ((byte)(bVar8 + 0xbf) < 0x1a) {
                  bVar8 = bVar8 + 0x20;
                }
                if (bVar8 != bVar21) break;
                pbVar7 = pbVar7 + 1;
                pbVar4 = pbVar4 + 1;
              } while (pbVar7 < pbVar16);
            }
            uVar12 = (uint)(bVar21 < bVar8);
            if (pbVar7 == pbVar16) {
              uVar12 = (uint)(uVar23 < uVar10);
            }
          }
          else {
            iVar11 = *piVar19;
            iVar2 = piVar19[4];
            uVar12 = 0;
          }
          uVar22 = uVar13 + uVar12;
          iVar6 = piVar14[local_107c];
          iVar3 = iVar11 + *(int *)(iVar2 + piVar14[uVar22] * 4);
          iVar11 = iVar11 + *(int *)(iVar2 + iVar6 * 4);
          uVar15 = (uint)*(ushort *)(iVar3 + 0x1c);
          uVar23 = (uint)*(ushort *)(iVar11 + 0x1c);
          uVar10 = uVar15;
          if (uVar23 < uVar15) {
            uVar10 = uVar23;
          }
          pbVar16 = (byte *)(uVar10 + iVar11 + 0x2e);
          pbVar7 = (byte *)(iVar11 + 0x2e);
          if (uVar10 == 0) {
            bVar21 = 0;
            bVar8 = 0;
          }
          else {
            pbVar4 = (byte *)(iVar3 + 0x2e);
            do {
              bVar21 = *pbVar7;
              bVar8 = *pbVar4;
              if ((byte)(bVar21 + 0xbf) < 0x1a) {
                bVar21 = bVar21 + 0x20;
              }
              if ((byte)(bVar8 + 0xbf) < 0x1a) {
                bVar8 = bVar8 + 0x20;
              }
              if (bVar8 != bVar21) break;
              pbVar7 = pbVar7 + 1;
              pbVar4 = pbVar4 + 1;
            } while (pbVar7 < pbVar16);
          }
          bVar24 = bVar8 <= bVar21;
          if (pbVar7 == pbVar16) {
            bVar24 = uVar15 <= uVar23;
          }
          if (bVar24) break;
          piVar14[local_107c] = piVar14[uVar22];
          piVar14[uVar22] = iVar6;
          uVar18 = (uVar18 + CARRY4(uVar13,uVar12)) * 2 | uVar22 >> 0x1f;
          uVar13 = uVar22 * 2 | 1;
          local_107c = uVar22;
        } while (uVar18 == 0 && (uVar5 <= uVar13) <= uVar18);
      }
      bVar24 = uVar9 != 0;
      uVar9 = uVar9 - 1;
    } while (bVar24);
    uVar5 = uVar5 - 1;
    if (uVar5 == 0) {
      return 1;
    }
    do {
      iVar11 = piVar14[uVar5];
      piVar14[uVar5] = *piVar14;
      *piVar14 = iVar11;
      if (uVar5 < 2) {
        return 1;
      }
      uVar13 = 0;
      uVar9 = 1;
      local_107c = 0;
      do {
        uVar18 = uVar13 + (0xfffffffe < uVar9);
        if (uVar18 == 0 && (uVar5 <= uVar9 + 1) <= uVar18) {
          iVar2 = *piVar19;
          iVar3 = piVar19[4];
          iVar17 = iVar2 + *(int *)(iVar3 + piVar14[uVar9 + 1] * 4);
          iVar6 = iVar2 + *(int *)(iVar3 + piVar14[uVar9] * 4);
          pbVar7 = (byte *)(iVar6 + 0x2e);
          uVar12 = (uint)*(ushort *)(iVar17 + 0x1c);
          uVar10 = (uint)*(ushort *)(iVar6 + 0x1c);
          uVar18 = uVar12;
          if (uVar10 < uVar12) {
            uVar18 = uVar10;
          }
          pbVar16 = (byte *)(uVar18 + iVar6 + 0x2e);
          if (uVar18 == 0) {
            bVar21 = 0;
            bVar8 = 0;
          }
          else {
            pbVar4 = (byte *)(iVar17 + 0x2e);
            do {
              bVar21 = *pbVar7;
              bVar8 = *pbVar4;
              if ((byte)(bVar21 + 0xbf) < 0x1a) {
                bVar21 = bVar21 + 0x20;
              }
              if ((byte)(bVar8 + 0xbf) < 0x1a) {
                bVar8 = bVar8 + 0x20;
              }
              if (bVar8 != bVar21) break;
              pbVar7 = pbVar7 + 1;
              pbVar4 = pbVar4 + 1;
            } while (pbVar7 < pbVar16);
          }
          uVar18 = (uint)(bVar21 < bVar8);
          if (pbVar7 == pbVar16) {
            uVar18 = (uint)(uVar10 < uVar12);
          }
        }
        else {
          iVar2 = *piVar19;
          iVar3 = piVar19[4];
          uVar18 = 0;
        }
        uVar10 = uVar9 + uVar18;
        iVar6 = iVar2 + *(int *)(iVar3 + iVar11 * 4);
        iVar2 = iVar2 + *(int *)(iVar3 + piVar14[uVar10] * 4);
        uVar22 = (uint)*(ushort *)(iVar2 + 0x1c);
        uVar23 = (uint)*(ushort *)(iVar6 + 0x1c);
        uVar12 = uVar22;
        if (uVar23 < uVar22) {
          uVar12 = uVar23;
        }
        pbVar7 = (byte *)(uVar12 + iVar6 + 0x2e);
        pbVar16 = (byte *)(iVar6 + 0x2e);
        if (uVar12 == 0) {
          bVar21 = 0;
          bVar8 = 0;
        }
        else {
          pbVar4 = (byte *)(iVar2 + 0x2e);
          do {
            bVar21 = *pbVar16;
            bVar8 = *pbVar4;
            if ((byte)(bVar21 + 0xbf) < 0x1a) {
              bVar21 = bVar21 + 0x20;
            }
            if ((byte)(bVar8 + 0xbf) < 0x1a) {
              bVar8 = bVar8 + 0x20;
            }
            if (bVar8 != bVar21) break;
            pbVar16 = pbVar16 + 1;
            pbVar4 = pbVar4 + 1;
          } while (pbVar16 < pbVar7);
        }
        bVar24 = bVar8 <= bVar21;
        if (pbVar16 == pbVar7) {
          bVar24 = uVar22 <= uVar23;
        }
        if (bVar24) break;
        piVar14[local_107c] = piVar14[uVar10];
        piVar14[uVar10] = iVar11;
        uVar13 = (uVar13 + CARRY4(uVar9,uVar18)) * 2 | uVar10 >> 0x1f;
        uVar9 = uVar10 * 2 | 1;
        local_107c = uVar10;
      } while (uVar13 == 0 && (uVar5 <= uVar9) <= uVar13);
      uVar5 = uVar5 - 1;
      if (uVar5 == 0) {
        return 1;
      }
    } while( true );
  }
  goto LAB_0010c030;
LAB_0010c310:
  uVar5 = 0x10;
  goto LAB_0010c890;
LAB_0010be68:
  uVar5 = 9;
  goto LAB_0010c890;
}

