/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032f54 FUN_00032f54 */

undefined FUN_00032f54(int param_1,int param_2,int param_3)

{
  int iVar1;
  int local_20;
  
  if ((*(int *)(param_1 + 0x20) != 0) && (*(int *)(param_1 + 0x24) != 0)) {
    local_20 = *(int *)(param_1 + 0x24);
    while( true ) {
      if (((*(ushort *)(local_20 + 2) & 1) == 0) &&
         ((*(ushort *)(*(int *)(param_1 + 0x20) + param_3 * 2) & 0x7fff) ==
          *(ushort *)(local_20 + 4))) {
        if ((*(int *)(param_2 + 8) == *(int *)(local_20 + 8)) &&
           (iVar1 = strcmp(*(char **)(param_2 + 4),
                           (char *)(*(int *)(param_1 + 0x1c) +
                                   *(int *)(local_20 + *(int *)(local_20 + 0xc)))), iVar1 == 0)) {
          return 1;
        }
        return 0;
      }
      if (*(int *)(local_20 + 0x10) == 0) break;
      local_20 = local_20 + *(int *)(local_20 + 0x10);
    }
  }
  return 0;
}

