/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00111220 FUN_00111220 */

undefined4 FUN_00111220(int param_1,code *param_2,int *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  undefined4 uVar5;
  void *pvVar6;
  bool bVar7;
  undefined auStack_78 [20];
  int local_64;
  int local_60;
  int local_5c;
  int local_50;
  code *local_4c;
  undefined4 local_44;
  undefined4 *local_30;
  
  if (param_1 == 0) {
    if (param_3 != (int *)0x0) {
      *param_3 = 0x18;
    }
    return 0;
  }
  __aeabi_memclr8(auStack_78,0x50);
  pcVar4 = param_2;
  iVar2 = FUN_0010cac4(auStack_78,param_1,param_2,param_4,0,0,0,0);
  if (iVar2 == 0) {
    if (param_3 != (int *)0x0) {
      *param_3 = local_5c;
    }
    return 0;
  }
  iVar3 = FUN_00110d90(auStack_78,param_2);
  puVar1 = local_30;
  iVar2 = local_5c;
  if (iVar3 == 0) {
    if ((((local_30 != (undefined4 *)0x0) && (local_50 != 0)) && (local_4c != (code *)0x0)) &&
       (local_64 == 1)) {
      uVar5 = 0;
      local_30 = (undefined4 *)0x0;
      (*local_4c)(local_44,*puVar1);
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      (*local_4c)(local_44,puVar1[4]);
      puVar1[4] = 0;
      puVar1[5] = 0;
      puVar1[6] = 0;
      puVar1[7] = 0;
      (*local_4c)(local_44,puVar1[8]);
      puVar1[8] = 0;
      puVar1[9] = 0;
      puVar1[10] = 0;
      puVar1[0xb] = 0;
      pvVar6 = (void *)puVar1[0xf];
      if (pvVar6 != (void *)0x0) {
        bVar7 = true;
        if (local_60 == 4) {
          if (*(int *)((int)pvVar6 + 8) == 0) goto LAB_001114a8;
          iVar3 = FUN_00120238();
          free(pvVar6);
          bVar7 = iVar3 != -1;
        }
        goto LAB_001114ac;
      }
      bVar7 = true;
LAB_001114bc:
      (*local_4c)(local_44,puVar1);
      if (bVar7) goto LAB_001114ec;
    }
    uVar5 = 0;
    if (iVar2 != 0) goto LAB_001114ec;
  }
  else {
    if (local_30 != (undefined4 *)0x0) {
      if (local_50 != 0) {
        pcVar4 = local_4c;
      }
      if ((local_50 != 0 && pcVar4 != (code *)0x0) && (local_64 == 1)) {
        iVar2 = 0;
        local_30 = (undefined4 *)0x0;
        (*pcVar4)(local_44,*puVar1);
        *puVar1 = 0;
        puVar1[1] = 0;
        puVar1[2] = 0;
        puVar1[3] = 0;
        (*local_4c)(local_44,puVar1[4]);
        puVar1[4] = 0;
        puVar1[5] = 0;
        puVar1[6] = 0;
        puVar1[7] = 0;
        (*local_4c)(local_44,puVar1[8]);
        puVar1[8] = 0;
        uVar5 = 1;
        puVar1[9] = 0;
        bVar7 = true;
        puVar1[10] = 0;
        puVar1[0xb] = 0;
        pvVar6 = (void *)puVar1[0xf];
        if (pvVar6 == (void *)0x0) goto LAB_001114bc;
        bVar7 = true;
        if (local_60 == 4) {
          if (*(int *)((int)pvVar6 + 8) != 0) {
            iVar3 = FUN_00120238();
            free(pvVar6);
            if (iVar3 != -1) goto LAB_001114ac;
          }
          local_5c = 0x15;
LAB_001114a8:
          bVar7 = false;
        }
LAB_001114ac:
        puVar1[0xf] = 0;
        goto LAB_001114bc;
      }
    }
    local_5c = 0x18;
  }
  uVar5 = 0;
  iVar2 = local_5c;
LAB_001114ec:
  if (param_3 != (int *)0x0) {
    *param_3 = iVar2;
  }
  return uVar5;
}

