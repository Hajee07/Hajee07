/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010e71c FUN_0010e71c */

/* WARNING: Removing unreachable block (ram,0x0010ed38) */
/* WARNING: Removing unreachable block (ram,0x0010ec98) */

bool FUN_0010e71c(uint *param_1,uint param_2,code *param_3,undefined4 param_4,uint param_5)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte bVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  byte *pbVar11;
  int iVar12;
  uint uVar13;
  byte *pbVar14;
  bool bVar15;
  undefined8 uVar16;
  int local_2fd4;
  uint local_2fd0;
  uint local_2fcc;
  uint local_2fc8;
  uint local_2fc0;
  uint local_2fb8;
  int local_2fb0;
  uint local_2fa8;
  uint local_2fa4;
  byte *local_2fa0;
  uint local_2f9c;
  uint local_2f98;
  uint local_2f94;
  uint local_2f90;
  uint local_2f8c;
  undefined4 local_2f88 [2748];
  int local_498 [6];
  undefined local_47e;
  undefined local_47d;
  ushort local_47c;
  undefined auStack_478 [20];
  byte local_464;
  ushort local_462;
  uint local_45c;
  uint local_458;
  uint uStack_454;
  uint local_450;
  uint uStack_44c;
  uint local_440;
  int iStack_43c;
  int local_434;
  
  if (param_1 == (uint *)0x0) {
    return false;
  }
  puVar5 = param_1;
  if (param_3 != (code *)0x0) {
    puVar5 = (uint *)param_1[0x12];
  }
  if ((param_3 == (code *)0x0 || puVar5 == (uint *)0x0) || (param_1[0xe] == 0)) {
    param_1[7] = 0x18;
    return false;
  }
  iVar9 = 0;
  if (param_2 < param_1[4]) {
    iVar9 = *puVar5 + *(int *)(puVar5[4] + param_2 * 4);
  }
  iVar9 = FUN_001107b8(param_1,param_2,iVar9,auStack_478,0);
  if (iVar9 == 0) {
    return false;
  }
  if (local_434 != 0) {
    return true;
  }
  if ((local_458 | uStack_454) == 0) {
    return true;
  }
  if ((local_464 & 0x61) != 0) {
    uVar6 = 5;
    goto LAB_0010e7e4;
  }
  param_5 = param_5 & 0x400;
  if ((param_5 == 0) && ((local_462 | 8) != 8)) {
    uVar6 = 4;
    goto LAB_0010e7e4;
  }
  iVar9 = (*(code *)param_1[0xe])
                    (param_1[0x11],(code *)param_1[0xe],local_440,iStack_43c,local_498,0x1e);
  if (iVar9 != 0x1e) {
    uVar6 = 0x14;
    goto LAB_0010e7e4;
  }
  if (local_498[0] != 0x4034b50) {
LAB_0010e8cc:
    uVar6 = 9;
LAB_0010e7e4:
    param_1[7] = uVar6;
    return false;
  }
  uVar6 = (uint)CONCAT11(local_47d,local_47e) + (uint)local_47c + 0x1e;
  local_2fd0 = local_440 + uVar6;
  local_2fd4 = iStack_43c + (uint)CARRY4(local_440,uVar6);
  local_2fc0 = local_458;
  uVar6 = local_2fd4 + uStack_454 + (uint)CARRY4(local_2fd0,local_458);
  if (param_1[1] <= uVar6 && (uint)(local_2fd0 + local_458 <= *param_1) <= param_1[1] - uVar6)
  goto LAB_0010e8cc;
  if (*(int *)(param_1[0x12] + 0x48) == 0) {
    local_2fa8 = 0;
    local_2fcc = uStack_454;
    if (uStack_454 != 0 || uStack_454 < (0x1fff < local_458)) {
      local_2fc0 = 0x2000;
      local_2fcc = 0;
    }
    local_2fa0 = (byte *)(*(code *)param_1[10])(param_1[0xd],1);
    if (local_2fa0 == (byte *)0x0) {
      uVar6 = 0x10;
      goto LAB_0010e7e4;
    }
    local_2f94 = 0;
    local_2fa4 = local_458;
    local_2f9c = uStack_454;
  }
  else {
    local_2fa0 = (byte *)(*(int *)(param_1[0x12] + 0x48) + local_2fd0);
    local_2fa4 = 0;
    local_2fa8 = local_458;
    local_2fcc = uStack_454;
    local_2f9c = 0;
    local_2f94 = uStack_454;
  }
  if ((param_5 == 0) && (local_462 != 0)) {
    local_2f88[0] = 0;
    local_2fc8 = 0;
    iVar9 = (*(code *)param_1[10])(param_1[0xd],1,0x8000);
    if (iVar9 == 0) {
      uVar6 = 0xffffffff;
      param_1[7] = 0x10;
      local_2fc8 = 0;
      local_2f98 = 0;
      local_2fb8 = 0;
      param_5 = uVar6;
    }
    else {
      local_2f98 = 0;
      local_2fb0 = 0;
      iVar12 = DAT_0010f36c + 0x10ea08;
      local_2fb8 = 0;
      do {
        local_2f90 = 0x8000 - (local_2f98 & 0x7fff);
        if ((local_2fa8 | local_2f94) == 0) {
          local_2fa8 = 0;
          if (*(int *)(param_1[0x12] + 0x48) == 0) {
            bVar15 = (uint)(local_2fa4 <= local_2fc0) <= local_2fcc - local_2f9c;
            local_2fa8 = local_2fa4;
            if (local_2fcc <= local_2f9c && bVar15) {
              local_2fa8 = local_2fc0;
            }
            uVar6 = (*(code *)param_1[0xe])
                              (param_1[0x11],local_2fcc,local_2fd0,local_2fd4,local_2fa0,local_2fa8)
            ;
            local_2f94 = local_2f9c;
            if (local_2fcc <= local_2f9c && bVar15) {
              local_2f94 = local_2fcc;
            }
            if ((local_2fa8 ^ uVar6 | local_2f94) != 0) {
              param_1[7] = 0x14;
              uVar6 = 0xffffffff;
              param_5 = uVar6;
              break;
            }
            bVar15 = local_2fa4 < local_2fa8;
            local_2fa4 = local_2fa4 - local_2fa8;
            local_2f9c = local_2f9c - (local_2f94 + bVar15);
            bVar15 = CARRY4(local_2fd0,local_2fa8);
            local_2fd0 = local_2fd0 + local_2fa8;
            local_2fd4 = local_2fd4 + local_2f94 + (uint)bVar15;
            local_2fb0 = 0;
          }
          else {
            local_2f94 = 0;
          }
        }
        uVar6 = local_2fa4 | local_2f9c;
        if (uVar6 != 0) {
          uVar6 = 1;
        }
        pbVar14 = (byte *)(iVar9 + (local_2f98 & 0x7fff));
        local_2f8c = local_2fa8;
        uVar6 = FUN_001081f0(local_2f88,local_2fa0 + local_2fb0,&local_2f8c,iVar9,pbVar14,
                             &local_2f90,uVar6 << 1);
        uVar13 = local_2f90;
        local_2fb0 = local_2fb0 + local_2f8c;
        bVar15 = local_2fa8 < local_2f8c;
        local_2fa8 = local_2fa8 - local_2f8c;
        local_2f94 = local_2f94 - bVar15;
        if (local_2f90 != 0) {
          uVar7 = (*param_3)(param_4,local_2f94,local_2f98,local_2fb8,pbVar14,local_2f90);
          if (uVar7 == uVar13) {
            local_2fc8 = ~local_2fc8;
            uVar7 = uVar13;
            if (uVar13 < 4) {
LAB_0010ecbc:
              do {
                uVar7 = uVar7 - 1;
                local_2fc8 = *(uint *)(iVar12 + (local_2fc8 & 0xff ^ (uint)*pbVar14) * 4) ^
                             local_2fc8 >> 8;
                pbVar14 = pbVar14 + 1;
              } while (uVar7 != 0);
            }
            else {
              uVar10 = uVar13 - 4 & 0xfffffffc;
              pbVar11 = pbVar14;
              do {
                bVar4 = *pbVar11;
                pbVar1 = pbVar11 + 1;
                uVar7 = uVar7 - 4;
                pbVar2 = pbVar11 + 2;
                pbVar3 = pbVar11 + 3;
                pbVar11 = pbVar11 + 4;
                uVar8 = *(uint *)(iVar12 + (local_2fc8 & 0xff ^ (uint)bVar4) * 4) ^ local_2fc8 >> 8;
                uVar8 = *(uint *)(iVar12 + (uVar8 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar8 >> 8;
                uVar8 = *(uint *)(iVar12 + (uVar8 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar8 >> 8;
                local_2fc8 = *(uint *)(iVar12 + (uVar8 & 0xff ^ (uint)*pbVar3) * 4) ^ uVar8 >> 8;
              } while (3 < uVar7);
              uVar7 = (uVar13 - 4) - uVar10;
              if (uVar7 != 0) {
                pbVar14 = pbVar14 + uVar10 + 4;
                goto LAB_0010ecbc;
              }
            }
            local_2fc8 = ~local_2fc8;
            bVar15 = CARRY4(local_2f98,uVar13);
            local_2f98 = local_2f98 + uVar13;
            local_2fb8 = local_2fb8 + bVar15;
            if (local_2fb8 < uStack_44c || uStack_44c - local_2fb8 < (uint)(local_2f98 <= local_450)
               ) goto LAB_0010ed60;
            param_1[7] = 0xb;
          }
          else {
            param_1[7] = 0x1f;
          }
          uVar6 = 0xffffffff;
          param_5 = uVar6;
          break;
        }
LAB_0010ed60:
        param_5 = uVar6;
      } while (uVar6 - 1 < 2);
    }
joined_r0x0010f030:
    if (param_5 == 0) {
LAB_0010f298:
      if ((local_2f98 ^ local_450 | local_2fb8 ^ uStack_44c) == 0) {
        if (local_2fc8 == local_45c) goto LAB_0010f304;
        uVar6 = 0xb;
      }
      else {
        uVar6 = 0xd;
      }
      param_1[7] = uVar6;
      iVar12 = *(int *)(param_1[0x12] + 0x48);
      goto joined_r0x0010f2e0;
    }
    goto LAB_0010f304;
  }
  if (*(int *)(param_1[0x12] + 0x48) == 0) {
    if ((local_2fa4 | local_2f9c) != 0) {
      if (param_5 == 0) {
        local_2f98 = 0;
        iVar9 = DAT_0010f360 + 0x10f0a8;
        local_2fb8 = 0;
        local_2fc8 = 0;
        do {
          bVar15 = (uint)(local_2fa4 <= local_2fc0) <= local_2fcc - local_2f9c;
          uVar6 = local_2fa4;
          if (local_2fcc <= local_2f9c && bVar15) {
            uVar6 = local_2fc0;
          }
          uVar7 = (*(code *)param_1[0xe])(param_1[0x11]);
          uVar13 = local_2f9c;
          if (local_2fcc <= local_2f9c && bVar15) {
            uVar13 = local_2fcc;
          }
          if ((uVar6 ^ uVar7 | uVar13) != 0) goto LAB_0010f2e8;
          local_2fc8 = ~local_2fc8;
          uVar7 = uVar6;
          pbVar14 = local_2fa0;
          if (3 < uVar6) {
            uVar10 = uVar6 - 4 & 0xfffffffc;
            do {
              bVar4 = *pbVar14;
              pbVar11 = pbVar14 + 1;
              uVar7 = uVar7 - 4;
              pbVar1 = pbVar14 + 2;
              pbVar2 = pbVar14 + 3;
              pbVar14 = pbVar14 + 4;
              uVar8 = *(uint *)(iVar9 + (local_2fc8 & 0xff ^ (uint)bVar4) * 4) ^ local_2fc8 >> 8;
              uVar8 = *(uint *)(iVar9 + (uVar8 & 0xff ^ (uint)*pbVar11) * 4) ^ uVar8 >> 8;
              uVar8 = *(uint *)(iVar9 + (uVar8 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar8 >> 8;
              local_2fc8 = *(uint *)(iVar9 + (uVar8 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar8 >> 8;
            } while (3 < uVar7);
            uVar7 = (uVar6 - 4) - uVar10;
            pbVar14 = local_2fa0 + uVar10 + 4;
          }
          for (; uVar7 != 0; uVar7 = uVar7 - 1) {
            local_2fc8 = *(uint *)(iVar9 + (local_2fc8 & 0xff ^ (uint)*pbVar14) * 4) ^
                         local_2fc8 >> 8;
            pbVar14 = pbVar14 + 1;
          }
          uVar7 = (*param_3)(param_4,pbVar14,local_2f98,local_2fb8,local_2fa0,uVar6);
          if ((uVar6 ^ uVar7 | uVar13) != 0) goto LAB_0010f2f0;
          local_2fc8 = ~local_2fc8;
          bVar15 = local_2fa4 < uVar6;
          local_2fa4 = local_2fa4 - uVar6;
          local_2f9c = local_2f9c - (uVar13 + bVar15);
          bVar15 = CARRY4(uVar6,local_2f98);
          local_2f98 = uVar6 + local_2f98;
          local_2fb8 = uVar13 + local_2fb8 + (uint)bVar15;
        } while ((local_2fa4 | local_2f9c) != 0);
      }
      else {
        local_2f98 = 0;
        local_2fb8 = 0;
        do {
          bVar15 = (uint)(local_2fa4 <= local_2fc0) <= local_2fcc - local_2f9c;
          uVar6 = local_2fa4;
          if (local_2fcc <= local_2f9c && bVar15) {
            uVar6 = local_2fc0;
          }
          uVar16 = (*(code *)param_1[0xe])(param_1[0x11]);
          uVar13 = local_2f9c;
          if (local_2fcc <= local_2f9c && bVar15) {
            uVar13 = local_2fcc;
          }
          if ((uVar6 ^ (uint)uVar16 | uVar13) != 0) goto LAB_0010f2e8;
          uVar7 = (*param_3)(param_4,(int)((ulonglong)uVar16 >> 0x20),local_2f98,local_2fb8,
                             local_2fa0,uVar6);
          if ((uVar6 ^ uVar7 | uVar13) != 0) goto LAB_0010f2f0;
          bVar15 = local_2fa4 < uVar6;
          local_2fa4 = local_2fa4 - uVar6;
          local_2f9c = local_2f9c - (uVar13 + bVar15);
          bVar15 = CARRY4(uVar6,local_2f98);
          local_2f98 = uVar6 + local_2f98;
          local_2fb8 = uVar13 + local_2fb8 + (uint)bVar15;
        } while ((local_2fa4 | local_2f9c) != 0);
        local_2fc8 = 0;
      }
      iVar9 = 0;
      uVar6 = 0;
      goto joined_r0x0010f030;
    }
    local_2f98 = 0;
    local_2fc8 = 0;
    local_2fb8 = 0;
    iVar9 = 0;
    uVar6 = 0;
    if (param_5 != 0) goto LAB_0010f304;
    goto LAB_0010f298;
  }
  if (uStack_454 != 0) {
    uVar6 = 0x1b;
    goto LAB_0010e7e4;
  }
  iVar9 = 0;
  local_2f98 = (*param_3)(param_4,local_2fa0,0,0,local_2fa0,local_458);
  if ((local_458 ^ local_2f98 | uStack_454) == 0) {
    iVar9 = 0;
    uVar6 = 0;
    if (param_5 == 0) {
      local_2fc8 = 0xffffffff;
      uVar6 = local_2f98;
      pbVar14 = local_2fa0;
      if (3 < local_2f98) {
        uVar13 = local_2f98 - 4 & 0xfffffffc;
        local_2fc8 = 0xffffffff;
        iVar9 = DAT_0010f364 + 0x10ef34;
        do {
          bVar4 = *pbVar14;
          pbVar11 = pbVar14 + 1;
          uVar6 = uVar6 - 4;
          pbVar1 = pbVar14 + 2;
          pbVar2 = pbVar14 + 3;
          pbVar14 = pbVar14 + 4;
          uVar7 = *(uint *)(iVar9 + (local_2fc8 & 0xff ^ (uint)bVar4) * 4) ^ local_2fc8 >> 8;
          uVar7 = *(uint *)(iVar9 + (uVar7 & 0xff ^ (uint)*pbVar11) * 4) ^ uVar7 >> 8;
          uVar7 = *(uint *)(iVar9 + (uVar7 & 0xff ^ (uint)*pbVar1) * 4) ^ uVar7 >> 8;
          local_2fc8 = *(uint *)(iVar9 + (uVar7 & 0xff ^ (uint)*pbVar2) * 4) ^ uVar7 >> 8;
        } while (3 < uVar6);
        uVar6 = (local_2f98 - 4) - uVar13;
        pbVar14 = local_2fa0 + uVar13 + 4;
      }
      if (uVar6 != 0) {
        do {
          uVar6 = uVar6 - 1;
          local_2fc8 = *(uint *)(DAT_0010f368 + 0x10efb4 + (local_2fc8 & 0xff ^ (uint)*pbVar14) * 4)
                       ^ local_2fc8 >> 8;
          pbVar14 = pbVar14 + 1;
        } while (uVar6 != 0);
      }
      local_2fc8 = ~local_2fc8;
      local_2fb8 = 0;
      iVar9 = 0;
      uVar6 = 0;
      goto LAB_0010f298;
    }
    goto LAB_0010f304;
  }
  param_1[7] = 0x1f;
  iVar12 = *(int *)(param_1[0x12] + 0x48);
joined_r0x0010f2e0:
  uVar6 = 0xffffffff;
  if (iVar12 != 0) goto LAB_0010f32c;
  goto LAB_0010f314;
LAB_0010f2e8:
  uVar6 = 0x14;
  goto LAB_0010f2f4;
LAB_0010f2f0:
  uVar6 = 0x1f;
LAB_0010f2f4:
  param_1[7] = uVar6;
  uVar6 = 0xffffffff;
  iVar9 = 0;
LAB_0010f304:
  if (*(int *)(param_1[0x12] + 0x48) == 0) {
LAB_0010f314:
    (*(code *)param_1[0xb])(param_1[0xd],local_2fa0);
  }
LAB_0010f32c:
  if (iVar9 != 0) {
    (*(code *)param_1[0xb])(param_1[0xd],iVar9);
  }
  return uVar6 == 0;
}

