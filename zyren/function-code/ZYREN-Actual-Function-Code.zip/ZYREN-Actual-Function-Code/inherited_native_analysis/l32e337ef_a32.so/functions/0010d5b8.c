/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010d5b8 FUN_0010d5b8 */

undefined4 FUN_0010d5b8(void)

{
  int iVar1;
  undefined4 local_c;
  
  iVar1 = FUN_0010d5e8();
  if (iVar1 == 0) {
    local_c = 0xffffffff;
  }
  return local_c;
}

