/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010d44c FUN_0010d44c */

byte FUN_0010d44c(int param_1,uint param_2,undefined4 param_3,uint param_4)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  int *piVar4;
  bool bVar5;
  
  if (param_1 == 0) {
    return 0;
  }
  piVar4 = *(int **)(param_1 + 0x48);
  bVar5 = piVar4 == (int *)0x0;
  if (!bVar5) {
    param_4 = *(uint *)(param_1 + 0x10);
  }
  if (((bVar5 || param_2 <= param_4) && (!bVar5 && param_4 != param_2)) &&
     (iVar3 = *piVar4 + *(int *)(piVar4[4] + param_2 * 4), iVar3 != 0)) {
    bVar1 = *(byte *)(iVar3 + 8);
    bVar2 = bVar1 & 0x41;
    if ((bVar1 & 0x41) != 0) {
      bVar2 = 1;
    }
    return bVar2;
  }
  *(undefined4 *)(param_1 + 0x1c) = 0x18;
  return 0;
}

