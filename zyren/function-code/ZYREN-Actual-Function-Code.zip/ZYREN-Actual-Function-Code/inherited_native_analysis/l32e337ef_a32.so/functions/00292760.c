/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00292760 __aeabi_memcpy4 */

void __aeabi_memcpy4(void)

{
  (*(code *)PTR___aeabi_memcpy4_00307df4)();
  return;
}

