/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030794 FUN_00030794 */

void FUN_00030794(int *param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  void *__src;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  void **__dest;
  void *pvVar10;
  int iVar11;
  
  iVar6 = param_1[0x13];
  iVar7 = *param_1 - param_1[2];
  if (param_1[0x12] != 0) {
    iVar1 = param_1[0xb];
    iVar5 = param_1[0x11];
    iVar11 = 0;
    do {
      piVar2 = (int *)(iVar5 + iVar11 * 8);
      uVar3 = piVar2[1];
      __dest = (void **)(*piVar2 + iVar7);
      pvVar10 = *__dest;
      uVar8 = uVar3 & 0xff;
      if (uVar8 == 0x17) {
        *__dest = (void *)((int)pvVar10 + iVar7);
      }
      else {
        uVar3 = uVar3 >> 8;
        __src = (void *)FUN_00030920(param_1,uVar3);
        if (uVar8 == 0x15) {
          *__dest = __src;
        }
        else if (uVar8 == 0x14) {
          memcpy(__dest,__src,*(size_t *)(iVar1 + uVar3 * 0x10 + 8));
        }
        else if (uVar8 == 2) {
          *__dest = (void *)((int)__src + (int)pvVar10);
        }
        else {
          __android_log_print(4,DAT_00030918 + 0x3087c,DAT_0003091c + 0x30884,uVar8);
        }
      }
      iVar11 = iVar11 + 1;
    } while (iVar11 != param_1[0x12]);
  }
  if (param_1[0x14] != 0) {
    iVar1 = 0;
    iVar5 = DAT_00030910 + 0x308b0;
    iVar11 = DAT_00030914 + 0x308b8;
    do {
      piVar2 = (int *)(iVar6 + iVar1 * 8);
      iVar9 = *piVar2;
      uVar3 = piVar2[1];
      uVar8 = uVar3 & 0xff;
      uVar4 = FUN_00030920(param_1,uVar3 >> 8);
      if (uVar8 == 0x16) {
        *(undefined4 *)(iVar9 + iVar7) = uVar4;
      }
      else {
        __android_log_print(4,iVar5,iVar11,uVar8);
      }
      iVar1 = iVar1 + 1;
    } while (iVar1 != param_1[0x14]);
  }
  return;
}

