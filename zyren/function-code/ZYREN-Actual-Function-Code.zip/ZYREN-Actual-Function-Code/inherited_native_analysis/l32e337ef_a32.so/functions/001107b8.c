/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001107b8 FUN_001107b8 */

undefined4 FUN_001107b8(int param_1,uint param_2,int param_3,uint *param_4,undefined4 *param_5)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  short *psVar8;
  uint *puVar9;
  uint uVar10;
  uint *puVar11;
  uint uVar12;
  uint *puVar13;
  int iVar14;
  bool bVar15;
  tm local_50;
  
  if (param_5 != (undefined4 *)0x0) {
    *param_5 = 0;
  }
  if (param_3 == 0 || param_4 == (uint *)0x0) {
    if (param_1 == 0) {
      return 0;
    }
    *(undefined4 *)(param_1 + 0x1c) = 0x18;
    return 0;
  }
  *param_4 = param_2;
  uVar12 = 0;
  puVar13 = param_4 + 8;
  puVar11 = param_4 + 10;
  param_4[2] = *(uint *)(*(int *)(*(int *)(param_1 + 0x48) + 0x10) + param_2 * 4);
  param_4[3] = 0;
  *(undefined2 *)(param_4 + 4) = *(undefined2 *)(param_3 + 4);
  *(undefined2 *)((int)param_4 + 0x12) = *(undefined2 *)(param_3 + 6);
  *(undefined2 *)(param_4 + 5) = *(undefined2 *)(param_3 + 8);
  *(undefined2 *)((int)param_4 + 0x16) = *(undefined2 *)(param_3 + 10);
  local_50.tm_zone = (char *)0x0;
  local_50.tm_gmtoff = 0;
  local_50.tm_yday = 0;
  local_50.tm_wday = 0;
  local_50.tm_isdst = -1;
  local_50.tm_mday = *(byte *)(ushort *)(param_3 + 0xe) & 0x1f;
  local_50.tm_year = (*(byte *)(param_3 + 0xf) >> 1) + 0x50;
  local_50.tm_sec = (*(byte *)(ushort *)(param_3 + 0xc) & 0x1f) << 1;
  local_50.tm_hour = (int)(*(byte *)(param_3 + 0xd) >> 3);
  local_50.tm_min = ((uint)*(ushort *)(param_3 + 0xc) << 0x15) >> 0x1a;
  local_50.tm_mon = (((uint)*(ushort *)(param_3 + 0xe) << 0x17) >> 0x1c) - 1;
  uVar2 = mktime(&local_50);
  param_4[6] = uVar2;
  param_4[7] = *(uint *)(param_3 + 0x10);
  uVar3 = *(uint *)(param_3 + 0x14);
  *puVar13 = uVar3;
  param_4[9] = 0;
  iVar14 = param_3 + 0x2e;
  uVar2 = *(uint *)(param_3 + 0x18);
  *puVar11 = uVar2;
  param_4[0xb] = 0;
  *(undefined2 *)(param_4 + 0xc) = *(undefined2 *)(param_3 + 0x24);
  param_4[0xd] = *(uint *)(param_3 + 0x26);
  uVar4 = *(uint *)(param_3 + 0x2a);
  param_4[0xe] = uVar4;
  param_4[0xf] = 0;
  uVar10 = (uint)*(ushort *)(param_3 + 0x1c);
  if (0x1fe < uVar10) {
    uVar10 = 0x1ff;
  }
  __aeabi_memcpy(param_4 + 0x14,iVar14,uVar10);
  *(undefined *)((int)(param_4 + 0x14) + uVar10) = 0;
  uVar10 = 0x1ff;
  if (*(ushort *)(param_3 + 0x20) < 0x1ff) {
    uVar10 = (uint)*(ushort *)(param_3 + 0x20);
  }
  param_4[0x10] = uVar10;
  __aeabi_memcpy(param_4 + 0x94,
                 iVar14 + (uint)*(ushort *)(param_3 + 0x1c) + (uint)*(ushort *)(param_3 + 0x1e),
                 uVar10);
  *(undefined *)((int)(param_4 + 0x94) + uVar10) = 0;
  if (param_1 == 0) {
    param_4[0x11] = 0;
    param_4[0x12] = 0;
    goto LAB_00110af8;
  }
  piVar5 = *(int **)(param_1 + 0x48);
  if (piVar5 == (int *)0x0) {
    param_4[0x11] = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0x18;
    param_4[0x12] = 0;
LAB_00110ae8:
    uVar6 = 0x18;
  }
  else {
    if ((param_2 < *(uint *)(param_1 + 0x10)) &&
       (iVar7 = *piVar5 + *(int *)(piVar5[4] + param_2 * 4), iVar7 != 0)) {
      if ((*(ushort *)(iVar7 + 0x1c) == 0) ||
         (uVar10 = 1, *(char *)(iVar7 + (uint)*(ushort *)(iVar7 + 0x1c) + 0x2d) != '/')) {
        uVar10 = ((uint)*(byte *)(iVar7 + 0x26) << 0x1b) >> 0x1f;
      }
      param_4[0x11] = uVar10;
      if (*(uint *)(param_1 + 0x10) <= param_2) goto LAB_00110a78;
LAB_00110a54:
      iVar7 = *piVar5 + *(int *)(piVar5[4] + param_2 * 4);
      if (iVar7 == 0) goto LAB_00110a78;
      bVar1 = *(byte *)(iVar7 + 8);
      uVar10 = bVar1 & 0x41;
      if ((bVar1 & 0x41) != 0) {
        uVar10 = 1;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x1c) = 0x18;
      param_4[0x11] = 0;
      if (param_2 < *(uint *)(param_1 + 0x10)) goto LAB_00110a54;
LAB_00110a78:
      *(undefined4 *)(param_1 + 0x1c) = 0x18;
      uVar10 = 0;
    }
    param_4[0x12] = uVar10;
    if ((*(uint *)(param_1 + 0x10) <= param_2) ||
       (iVar7 = *piVar5 + *(int *)(piVar5[4] + param_2 * 4), iVar7 == 0)) goto LAB_00110ae8;
    if ((*(byte *)(iVar7 + 10) & 0xf7 | (uint)*(byte *)(iVar7 + 0xb) << 8) == 0) {
      bVar1 = *(byte *)(iVar7 + 8);
      uVar10 = (uint)bVar1;
      if ((bVar1 & 0x41) == 0) {
        bVar15 = (bVar1 & 0x20) == 0;
        if (!bVar15) {
          uVar10 = 6;
        }
        uVar12 = (uint)bVar15;
        if (!bVar15) {
          *(uint *)(param_1 + 0x1c) = uVar10;
        }
        goto LAB_00110af8;
      }
      uVar6 = 5;
    }
    else {
      uVar6 = 4;
    }
  }
  *(undefined4 *)(param_1 + 0x1c) = uVar6;
  uVar12 = 0;
LAB_00110af8:
  if (uVar2 < uVar3) {
    uVar2 = uVar3;
  }
  if (uVar2 <= uVar4) {
    uVar2 = uVar4;
  }
  param_4[0x13] = uVar12;
  if ((uVar2 == 0xffffffff) && (uVar2 = (uint)*(ushort *)(param_3 + 0x1e), uVar2 != 0)) {
    psVar8 = (short *)(iVar14 + (uint)*(ushort *)(param_3 + 0x1c));
    do {
      if (uVar2 < 4) {
LAB_00110c34:
        if (param_1 == 0) {
          return 0;
        }
        *(undefined4 *)(param_1 + 0x1c) = 9;
        return 0;
      }
      uVar3 = (uint)(ushort)psVar8[1];
      if (uVar2 < uVar3 + 4) goto LAB_00110c34;
      if (*psVar8 == 1) {
        if (param_5 != (undefined4 *)0x0) {
          *param_5 = 1;
        }
        if ((~*puVar11 | param_4[0xb]) == 0) {
          if (uVar3 < 8) goto LAB_00110c34;
          uVar2 = *(uint *)(psVar8 + 4);
          uVar3 = uVar3 - 8;
          puVar9 = (uint *)(psVar8 + 6);
          *puVar11 = *(uint *)(psVar8 + 2);
          param_4[0xb] = uVar2;
          uVar2 = ~*puVar13 | param_4[9];
        }
        else {
          puVar9 = (uint *)(psVar8 + 2);
          uVar2 = ~*puVar13 | param_4[9];
        }
        if (uVar2 == 0) {
          if (uVar3 < 8) goto LAB_00110c34;
          uVar10 = puVar9[1];
          uVar3 = uVar3 - 8;
          uVar2 = *puVar9;
          puVar9 = puVar9 + 2;
          *puVar13 = uVar2;
          param_4[9] = uVar10;
        }
        if (uVar4 != 0xffffffff) {
          return 1;
        }
        if (7 < uVar3) {
          uVar2 = puVar9[1];
          param_4[0xe] = *puVar9;
          param_4[0xf] = uVar2;
          return 1;
        }
        goto LAB_00110c34;
      }
      psVar8 = (short *)((int)psVar8 + uVar3 + 4);
      uVar2 = (uVar2 - uVar3) - 4;
    } while (uVar2 != 0);
  }
  return 1;
}

