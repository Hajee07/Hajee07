/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00115270 FUN_00115270 */

undefined4
FUN_00115270(int param_1,undefined4 param_2,uint param_3,uint param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = param_1;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 8);
  }
  uVar3 = 0xffffffff;
  uVar4 = 0xffffffff;
  if (param_1 != 0 && iVar1 != 0) {
    uVar2 = FUN_00120364(iVar1,0,1);
    uVar4 = FUN_00120364(*(undefined4 *)(param_1 + 8),0,2);
    FUN_00120364(*(undefined4 *)(param_1 + 8),uVar2,0);
    uVar3 = (int)uVar4 >> 0x1f;
  }
  if (-1 < (int)param_4) {
    uVar3 = uVar4 ^ param_3 | uVar3 ^ param_4;
    if (uVar3 == 0) {
      if (param_1 == 0) {
        return 0;
      }
    }
    else {
      if (param_1 != 0) {
        uVar3 = *(uint *)(param_1 + 8);
      }
      if (param_1 == 0 || uVar3 == 0) {
        return 0;
      }
      iVar1 = FUN_00120364(uVar3,param_3,0);
      if (iVar1 == -1) {
        return 0;
      }
    }
    if (*(int *)(param_1 + 8) != 0) {
      uVar2 = FUN_001203a4(*(int *)(param_1 + 8),param_5,param_6);
      return uVar2;
    }
  }
  return 0;
}

