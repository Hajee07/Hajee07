/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001120ac FUN_001120ac */

undefined4 FUN_001120ac(int param_1,int param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar3 = 0;
  *(int *)(param_1 + 0x3c) = DAT_00112188 + 0x1120d0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  if ((param_3 & 0x8000) != 0) {
    *(int *)(param_1 + 0x38) = DAT_0011218c + 0x1120e8;
  }
  *(int *)(param_1 + 0x44) = param_1;
  iVar1 = FUN_00111500(param_1,param_2,0,0,param_3);
  if (iVar1 != 0) {
    iVar2 = *(int *)(param_1 + 0x48);
    iVar1 = -1;
    *(int *)(iVar2 + 0x3c) = param_2;
    if (param_2 == 0) {
      iVar4 = -1;
    }
    else {
      iVar4 = -1;
      if (*(int *)(param_2 + 8) != 0) {
        uVar3 = FUN_00120364(*(int *)(param_2 + 8),0,1);
        iVar1 = FUN_00120364(*(undefined4 *)(param_2 + 8),0,2);
        FUN_00120364(*(undefined4 *)(param_2 + 8),uVar3,0);
        iVar2 = *(int *)(param_1 + 0x48);
        iVar4 = iVar1 >> 0x1f;
      }
    }
    uVar3 = 1;
    *(int *)(iVar2 + 0x40) = iVar1;
    *(int *)(iVar2 + 0x44) = iVar4;
    *(undefined4 *)(param_1 + 0x18) = 5;
  }
  return uVar3;
}

