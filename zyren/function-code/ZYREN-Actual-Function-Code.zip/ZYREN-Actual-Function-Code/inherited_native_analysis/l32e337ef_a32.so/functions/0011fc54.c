/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011fc54 FUN_0011fc54 */

undefined4 FUN_0011fc54(char *param_1,int *param_2,int *param_3)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  void *pvVar5;
  int *piVar6;
  uint uVar7;
  int *extraout_r1;
  int *extraout_r1_00;
  int iVar8;
  int *unaff_r4;
  int iVar9;
  char *pcVar10;
  int *piVar11;
  int *piVar12;
  uint uVar13;
  int iVar14;
  bool bVar15;
  undefined8 uVar16;
  
  if (param_1 != (char *)0x0) {
    if (param_2 != (int *)0x0) {
      unaff_r4 = param_3;
    }
    if (param_2 != (int *)0x0 && param_3 != (int *)0x0) {
      cVar1 = *param_1;
      bVar15 = cVar1 == '\x7f';
      if (bVar15) {
        cVar1 = param_1[1];
      }
      if (bVar15 && cVar1 == 'E') {
        cVar1 = param_1[2];
        bVar15 = cVar1 == 'L';
        if (bVar15) {
          cVar1 = param_1[3];
        }
        if (bVar15 && cVar1 == 'F') {
          uVar2 = (uint)*(ushort *)(param_1 + 0x2c);
          iVar14 = 0;
          piVar6 = param_2;
          if (uVar2 != 0) {
            piVar6 = *(int **)(param_1 + 0x1c);
          }
          if (uVar2 != 0 && piVar6 != (int *)0x0) {
            if (*(short *)(param_1 + 0x2a) != 0x20) {
              return 0;
            }
            if ((int *)~(uint)param_1 < piVar6) {
              return 0;
            }
            pcVar10 = (char *)((int)piVar6 + (int)param_1);
            uVar16 = FUN_0012009c(pcVar10,piVar6,uVar2 << 5,0);
            piVar6 = (int *)((ulonglong)uVar16 >> 0x20);
            if ((int)uVar16 == 0) {
              return 0;
            }
            if ((int *)(uint)*(ushort *)(param_1 + 0x2c) == (int *)0x0) {
              iVar14 = 0;
            }
            else {
              piVar6 = (int *)0x0;
              iVar14 = 0;
              do {
                if (*(int *)(pcVar10 + (int)piVar6 * 0x20) == 1) {
                  iVar14 = (int)param_1 - *(int *)(pcVar10 + (int)piVar6 * 0x20 + 8);
                  break;
                }
                piVar6 = (int *)((int)piVar6 + 1);
              } while (piVar6 < (int *)(uint)*(ushort *)(param_1 + 0x2c));
            }
          }
          uVar2 = (uint)*(ushort *)(param_1 + 0x30);
          if (uVar2 != 0) {
            piVar6 = *(int **)(param_1 + 0x20);
          }
          if (uVar2 != 0 && piVar6 != (int *)0x0) {
            if (*(short *)(param_1 + 0x2e) != 0x28) {
              return 0;
            }
            if ((int *)~(uint)param_1 < piVar6) {
              return 0;
            }
            pcVar10 = (char *)((int)piVar6 + (int)param_1);
            iVar8 = FUN_0012009c(pcVar10,piVar6,uVar2 * 0x28,0);
            if (iVar8 == 0) {
              return 0;
            }
            piVar12 = (int *)(uint)*(ushort *)(param_1 + 0x32);
            piVar6 = (int *)(uint)*(ushort *)(param_1 + 0x30);
            if (((piVar12 < piVar6) && (*(int *)(pcVar10 + (int)piVar12 * 0x28 + 4) == 3)) &&
               (iVar8 = *(int *)(pcVar10 + (int)piVar12 * 0x28 + 0xc) + iVar14, iVar8 != 0)) {
              uVar2 = 0;
              uVar16 = FUN_0012009c(iVar8,piVar6,*(int **)(pcVar10 + (int)piVar12 * 0x28 + 0x14));
              piVar6 = (int *)((ulonglong)uVar16 >> 0x20);
              bVar15 = (int)uVar16 != 0;
              if (bVar15) {
                uVar2 = (uint)*(ushort *)(param_1 + 0x30);
              }
              if (bVar15 && uVar2 != 0) {
                piVar11 = (int *)(pcVar10 + 0x14);
                uVar13 = 0;
                do {
                  piVar4 = (int *)piVar11[-5];
                  bVar15 = piVar4 != (int *)0x0;
                  if (bVar15) {
                    piVar6 = *(int **)(pcVar10 + (int)piVar12 * 0x28 + 0x14);
                  }
                  if ((!bVar15 || piVar4 <= piVar6) && (bVar15 && piVar6 != piVar4)) {
                    pvVar5 = memchr((char *)(iVar8 + (int)piVar4),0,(int)piVar6 - (int)piVar4);
                    piVar6 = extraout_r1;
                    if (((pvVar5 != (void *)0x0) &&
                        (iVar9 = strcmp((char *)(iVar8 + (int)piVar4),
                                        (char *)(DAT_00120098 + 0x120030)), piVar6 = extraout_r1_00,
                        iVar9 == 0)) && (*piVar11 != 0)) {
                      iVar9 = piVar11[-2] + iVar14;
                      uVar16 = FUN_0012009c(iVar9);
                      piVar6 = (int *)((ulonglong)uVar16 >> 0x20);
                      if ((int)uVar16 != 0) goto LAB_0011ffa4;
                      uVar2 = (uint)*(ushort *)(param_1 + 0x30);
                    }
                  }
                  piVar11 = piVar11 + 10;
                  uVar13 = uVar13 + 1;
                } while (uVar13 < (uVar2 & 0xffff));
              }
            }
          }
          uVar2 = (uint)*(ushort *)(param_1 + 0x2c);
          if (uVar2 != 0) {
            piVar6 = *(int **)(param_1 + 0x1c);
          }
          if (uVar2 != 0 && piVar6 != (int *)0x0) {
            if (*(short *)(param_1 + 0x2a) != 0x20) {
              return 0;
            }
            if ((int *)~(uint)param_1 < piVar6) {
              return 0;
            }
            piVar12 = (int *)((int)piVar6 + (int)param_1);
            uVar16 = FUN_0012009c(piVar12,piVar6,uVar2 << 5,0);
            piVar6 = (int *)((ulonglong)uVar16 >> 0x20);
            if ((int)uVar16 == 0) {
              return 0;
            }
            if ((int *)(uint)*(ushort *)(param_1 + 0x2c) != (int *)0x0) {
              iVar8 = 0;
              iVar9 = *piVar12;
              piVar6 = (int *)(uint)*(ushort *)(param_1 + 0x2c);
              do {
                if (((iVar9 == 1) && ((piVar12[iVar8 * 8 + 6] & 7U) == 4)) &&
                   (piVar12[iVar8 * 8 + 5] != 0)) {
                  iVar9 = piVar12[iVar8 * 8 + 2];
                  iVar3 = FUN_0012009c();
                  if (iVar3 != 0) {
                    *param_2 = iVar9 + iVar14;
                    iVar14 = piVar12[iVar8 * 8 + 5];
                    goto LAB_00120084;
                  }
                  piVar6 = (int *)(uint)*(ushort *)(param_1 + 0x2c);
                  if (piVar6 <= (int *)(iVar8 + 1)) break;
                }
                else if (piVar6 <= (int *)(iVar8 + 1)) break;
                iVar8 = iVar8 + 1;
                iVar9 = piVar12[iVar8 * 8];
              } while( true );
            }
          }
          uVar2 = (uint)*(ushort *)(param_1 + 0x30);
          if (uVar2 != 0) {
            piVar6 = *(int **)(param_1 + 0x20);
          }
          if (((uVar2 != 0 && piVar6 != (int *)0x0) && (*(short *)(param_1 + 0x2e) == 0x28)) &&
             (piVar6 <= (int *)~(uint)param_1)) {
            pcVar10 = (char *)((int)piVar6 + (int)param_1);
            uVar2 = FUN_0012009c(pcVar10,piVar6,uVar2 * 0x28,0);
            bVar15 = uVar2 != 0;
            if (bVar15) {
              uVar2 = (uint)*(ushort *)(param_1 + 0x30);
            }
            if (bVar15 && uVar2 != 0) {
              uVar13 = 0;
              uVar7 = *(uint *)(pcVar10 + 8);
              piVar11 = (int *)(pcVar10 + 0x14);
              do {
                if (((uVar7 & 3) == 2) && (uVar7 = piVar11[-4], uVar7 < 0x10)) {
                  iVar8 = 1;
                  bVar15 = (1 << (uVar7 & 0xff) & 0xc082U) != 0;
                  if (bVar15) {
                    iVar8 = *piVar11;
                  }
                  if (bVar15 && iVar8 != 0) {
                    iVar9 = piVar11[-2] + iVar14;
                    iVar8 = FUN_0012009c(iVar9,uVar7,iVar8,0);
                    if (iVar8 != 0) {
LAB_0011ffa4:
                      *param_2 = iVar9;
                      iVar14 = *piVar11;
LAB_00120084:
                      *unaff_r4 = iVar14;
                      unaff_r4[1] = 0;
                      return 1;
                    }
                    uVar2 = (uint)*(ushort *)(param_1 + 0x30);
                  }
                }
                uVar13 = uVar13 + 1;
                if ((uVar2 & 0xffff) <= uVar13) {
                  return 0;
                }
                uVar7 = piVar11[7];
                piVar11 = piVar11 + 10;
              } while( true );
            }
          }
        }
      }
    }
  }
  return 0;
}

