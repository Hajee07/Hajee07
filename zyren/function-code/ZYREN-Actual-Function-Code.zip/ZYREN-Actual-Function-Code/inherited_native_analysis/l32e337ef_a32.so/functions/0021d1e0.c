/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0021d1e0 FUN_0021d1e0 */

int FUN_0021d1e0(int param_1,int param_2,int param_3,int *param_4,byte *param_5)

{
  uint uVar1;
  byte *pbVar2;
  int extraout_r1;
  int extraout_r1_00;
  uint *puVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  
  if (*param_5 == 0) {
    uVar6 = 0x1505;
  }
  else {
    uVar6 = 0x1505;
    uVar4 = (uint)*param_5;
    pbVar2 = param_5;
    do {
      pbVar2 = pbVar2 + 1;
      uVar6 = uVar6 * 0x21 + uVar4;
      uVar4 = (uint)*pbVar2;
    } while (*pbVar2 != 0);
  }
  iVar7 = *param_4;
  uVar8 = param_4[1];
  iVar9 = param_4[2];
  FUN_0021daf4(uVar6,iVar7);
  uVar4 = param_4[iVar9 + extraout_r1 + 4];
  if ((uVar8 <= uVar4) &&
     (FUN_0021daf4(uVar6 >> 5,iVar9),
     uVar1 = 1 << (uVar6 >> (param_4[3] & 0xffU) & 0x1f) | 1 << (uVar6 & 0x1f),
     (uVar1 & param_4[extraout_r1_00 + 4]) == uVar1)) {
    piVar5 = (int *)(param_2 + uVar4 * 0x10 + 4);
    puVar3 = (uint *)(param_4 + ((uVar4 + iVar9 + iVar7 + 4) - uVar8));
    uVar4 = *puVar3;
    while( true ) {
      if (((uVar4 ^ uVar6) < 2) && (iVar7 = FUN_0021d458(param_3 + piVar5[-1],param_5), iVar7 == 0))
      {
        return *piVar5 + param_1;
      }
      if ((uVar4 & 1) != 0) break;
      puVar3 = puVar3 + 1;
      piVar5 = piVar5 + 4;
      uVar4 = *puVar3;
    }
  }
  return 0;
}

