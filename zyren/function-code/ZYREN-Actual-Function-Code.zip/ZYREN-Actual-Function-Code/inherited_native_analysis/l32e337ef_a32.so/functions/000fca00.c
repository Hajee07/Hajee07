/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000fca00 thunk_FUN_000a2650 */

void thunk_FUN_000a2650(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
                    /* WARNING: Could not recover jumptable at 0x000a26f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_000a2694 + DAT_000a2694))(param_1,param_2,param_3);
  return;
}

