/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031b7c FUN_00031b7c */

void FUN_00031b7c(int **param_1)

{
  int *piVar1;
  int **ppiVar2;
  int **local_18;
  int **local_14;
  
  local_14 = (int **)*param_1;
  while( true ) {
    if (local_14 != param_1) {
      local_18 = (int **)*local_14;
    }
    if (local_14 == param_1 || local_14 == (int **)0x0) break;
    piVar1 = *local_14;
    ppiVar2 = (int **)local_14[1];
    piVar1[1] = (int)ppiVar2;
    *ppiVar2 = piVar1;
    free(local_14);
    local_14 = local_18;
  }
  return;
}

