/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011365c FUN_0011365c */

int FUN_0011365c(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  short sVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = param_1 + 1;
  *param_1 = 1;
  if (param_2 == (undefined4 *)0x0) {
    sVar1 = 0;
  }
  else {
    uVar2 = *param_2;
    uVar3 = param_2[1];
    puVar4 = param_1 + 3;
    *(char *)(param_1 + 2) = (char)uVar3;
    *(char *)(param_1 + 1) = (char)uVar2;
    *(char *)((int)param_1 + 0xb) = (char)((uint)uVar3 >> 0x18);
    *(char *)((int)param_1 + 10) = (char)((uint)uVar3 >> 0x10);
    *(char *)((int)param_1 + 9) = (char)((uint)uVar3 >> 8);
    *(char *)((int)param_1 + 7) = (char)((uint)uVar2 >> 0x18);
    *(char *)((int)param_1 + 6) = (char)((uint)uVar2 >> 0x10);
    *(char *)((int)param_1 + 5) = (char)((uint)uVar2 >> 8);
    sVar1 = 8;
  }
  if (param_3 != (undefined4 *)0x0) {
    uVar2 = *param_3;
    uVar3 = param_3[1];
    sVar1 = sVar1 + 8;
    *(char *)(puVar4 + 1) = (char)uVar3;
    *(char *)puVar4 = (char)uVar2;
    *(char *)((int)puVar4 + 7) = (char)((uint)uVar3 >> 0x18);
    *(char *)((int)puVar4 + 6) = (char)((uint)uVar3 >> 0x10);
    *(char *)((int)puVar4 + 5) = (char)((uint)uVar3 >> 8);
    *(char *)((int)puVar4 + 3) = (char)((uint)uVar2 >> 0x18);
    *(char *)((int)puVar4 + 2) = (char)((uint)uVar2 >> 0x10);
    *(char *)((int)puVar4 + 1) = (char)((uint)uVar2 >> 8);
    puVar4 = puVar4 + 2;
  }
  if (param_4 != (undefined4 *)0x0) {
    uVar2 = *param_4;
    uVar3 = param_4[1];
    sVar1 = sVar1 + 8;
    *(char *)(puVar4 + 1) = (char)uVar3;
    *(char *)puVar4 = (char)uVar2;
    *(char *)((int)puVar4 + 7) = (char)((uint)uVar3 >> 0x18);
    *(char *)((int)puVar4 + 6) = (char)((uint)uVar3 >> 0x10);
    *(char *)((int)puVar4 + 5) = (char)((uint)uVar3 >> 8);
    *(char *)((int)puVar4 + 3) = (char)((uint)uVar2 >> 0x18);
    *(char *)((int)puVar4 + 2) = (char)((uint)uVar2 >> 0x10);
    *(char *)((int)puVar4 + 1) = (char)((uint)uVar2 >> 8);
    puVar4 = puVar4 + 2;
  }
  *(short *)((int)param_1 + 2) = sVar1;
  return (int)puVar4 - (int)param_1;
}

