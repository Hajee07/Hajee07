/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011c3e8 FUN_0011c3e8 */

undefined4 FUN_0011c3e8(int *param_1)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint *puVar6;
  uint uVar7;
  int *piVar8;
  
  if ((*param_1 == 0x464c457f) && (uVar1 = (uint)*(ushort *)(param_1 + 0xe), uVar1 != 0)) {
    piVar4 = (int *)((int)param_1 + param_1[8] + 0x10);
    uVar7 = uVar1;
    do {
      if (piVar4[-4] == 1) {
        piVar8 = (int *)((int)param_1 - *piVar4);
        break;
      }
      uVar7 = uVar7 - 1;
      piVar4 = piVar4 + 0xe;
      piVar8 = param_1;
    } while (uVar7 != 0);
    param_1 = (int *)((int)param_1 + param_1[8] + 0x10);
    do {
      if (param_1[-4] == 2) {
        puVar5 = (uint *)((int)piVar8 + *param_1);
        if (puVar5 == (uint *)0x0) {
          return 0;
        }
        iVar3 = 0;
        uVar1 = *puVar5;
        uVar7 = puVar5[1];
        puVar6 = puVar5;
        if (-uVar7 < (uint)(uVar1 < 7)) goto LAB_0011c4c8;
        goto LAB_0011c518;
      }
      uVar1 = uVar1 - 1;
      param_1 = param_1 + 0xe;
    } while (uVar1 != 0);
  }
  return 0;
LAB_0011c518:
  if ((uVar1 ^ 0x6ffffef5 | uVar7) == 0) {
    puVar5 = puVar6 + 4;
    iVar3 = (int)piVar8 + puVar6[2];
    uVar1 = *puVar5;
    uVar7 = puVar6[5];
    puVar6 = puVar5;
    if (-uVar7 < (uint)(uVar1 < 7)) goto LAB_0011c4c8;
    goto LAB_0011c518;
  }
  puVar5 = puVar6 + 4;
  uVar1 = *puVar5;
  uVar7 = puVar6[5];
  puVar6 = puVar5;
  if (-uVar7 < (uint)(uVar1 < 7)) {
LAB_0011c4c8:
                    /* WARNING: Could not recover jumptable at 0x0011c4d0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (*(code *)(&DAT_0011c4d4 + *(int *)(&DAT_0011c4d4 + uVar1 * 4)))
                      (*(int *)(&DAT_0011c4d4 + uVar1 * 4),iVar3,puVar5,0);
    return uVar2;
  }
  goto LAB_0011c518;
}

