/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010d5e8 FUN_0010d5e8 */

undefined4 FUN_0010d5e8(int param_1,byte *param_2,byte *param_3,uint param_4,uint *param_5)

{
  char cVar1;
  uint uVar2;
  size_t sVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  size_t sVar7;
  int iVar8;
  bool bVar9;
  byte *pbVar10;
  byte *pbVar11;
  int iVar12;
  byte *pbVar13;
  size_t sVar14;
  byte bVar15;
  uint uVar16;
  int iVar17;
  int *unaff_r4;
  uint uVar18;
  uint uVar19;
  int iVar20;
  uint uVar21;
  byte bVar22;
  int iVar23;
  bool bVar24;
  size_t local_2c;
  
  if (param_5 != (uint *)0x0) {
    *param_5 = 0;
  }
  if (param_1 == 0) {
    return 0;
  }
  if (param_2 != (byte *)0x0) {
    unaff_r4 = *(int **)(param_1 + 0x48);
  }
  if (param_2 != (byte *)0x0 && unaff_r4 != (int *)0x0) {
    uVar2 = (uint)*(byte *)((int)unaff_r4 + 0x31);
    bVar24 = (*(byte *)((int)unaff_r4 + 0x31) & 8) == 0;
    if (bVar24) {
      uVar2 = *(uint *)(param_1 + 0x14);
    }
    if (bVar24 && uVar2 == 1) {
      bVar24 = param_3 == (byte *)0x0;
      if (bVar24) {
        bVar24 = (param_4 & 0x300) == 0;
      }
      if ((bVar24) && (unaff_r4[9] != 0)) {
        iVar5 = unaff_r4[8];
        iVar23 = *(int *)(param_1 + 0x10);
        sVar3 = strlen((char *)param_2);
        if (param_5 != (uint *)0x0) {
          *param_5 = 0;
        }
        if (iVar23 != 0) {
          uVar2 = iVar23 - 1;
          uVar6 = 0;
          iVar12 = 0;
          iVar23 = -(uint)(iVar23 == 0);
          do {
            iVar8 = iVar23 - (iVar12 + (uint)(uVar2 < uVar6));
            uVar21 = (uint)((byte)iVar8 & 1) << 0x1f | uVar2 - uVar6 >> 1;
            uVar19 = uVar21 + uVar6;
            iVar20 = (iVar8 >> 1) + iVar12 + (uint)CARRY4(uVar21,uVar6);
            uVar18 = *(uint *)(iVar5 + uVar19 * 4);
            iVar8 = *unaff_r4 + *(int *)(unaff_r4[4] + uVar18 * 4);
            pbVar10 = (byte *)(iVar8 + 0x2e);
            uVar21 = (uint)*(ushort *)(iVar8 + 0x1c);
            sVar7 = sVar3;
            if (uVar21 < sVar3) {
              sVar7 = uVar21;
            }
            pbVar11 = (byte *)(sVar7 + iVar8 + 0x2e);
            pbVar13 = param_2;
            if (sVar7 == 0) {
              uVar16 = 0;
              uVar4 = 0;
            }
            else {
              do {
                bVar22 = *pbVar10;
                bVar15 = *pbVar13;
                if ((byte)(bVar22 + 0xbf) < 0x1a) {
                  bVar22 = bVar22 + 0x20;
                }
                if ((byte)(bVar15 + 0xbf) < 0x1a) {
                  bVar15 = bVar15 + 0x20;
                }
                if (bVar15 != bVar22) break;
                pbVar10 = pbVar10 + 1;
                pbVar13 = pbVar13 + 1;
              } while (pbVar10 < pbVar11);
              uVar4 = (uint)bVar15;
              uVar16 = (uint)bVar22;
            }
            iVar8 = uVar16 - uVar4;
            if (pbVar10 == pbVar11) {
              iVar8 = uVar21 - sVar3;
            }
            if (iVar8 == 0) {
              if (param_5 != (uint *)0x0) {
                *param_5 = uVar18;
              }
              return 1;
            }
            if (iVar8 < 0) {
              uVar6 = uVar19 + 1;
            }
            iVar17 = iVar20 - (uint)(uVar19 == 0);
            uVar21 = uVar19 - 1;
            if (iVar8 < 0) {
              iVar17 = iVar23;
              uVar21 = uVar2;
              iVar12 = iVar20 + (uint)(0xfffffffe < uVar19);
            }
            uVar2 = uVar21;
            iVar23 = iVar17;
          } while ((int)(iVar17 - (iVar12 + (uint)(uVar2 < uVar6))) < 0 ==
                   (SBORROW4(iVar17,iVar12) != SBORROW4(iVar17 - iVar12,(uint)(uVar2 < uVar6))));
        }
        goto LAB_0010dbb8;
      }
    }
    sVar3 = strlen((char *)param_2);
    if (0xffff < sVar3) {
      *(undefined4 *)(param_1 + 0x1c) = 0x18;
      return 0;
    }
    if (param_3 == (byte *)0x0) {
      local_2c = 0;
    }
    else {
      local_2c = strlen((char *)param_3);
      if (local_2c >> 0x10 != 0) goto LAB_0010d630;
    }
    uVar2 = *(uint *)(param_1 + 0x10);
    if (uVar2 != 0) {
      iVar5 = unaff_r4[4];
      uVar21 = 0;
      uVar6 = param_4 & 0x100;
      iVar23 = *unaff_r4;
      if (local_2c == 0) {
        do {
          iVar12 = iVar23 + *(int *)(iVar5 + uVar21 * 4);
          sVar7 = (size_t)*(ushort *)(iVar12 + 0x1c);
          if (sVar3 <= sVar7) {
            pbVar10 = (byte *)(iVar12 + 0x2e);
            if ((param_4 & 0x200) != 0 && sVar7 != 0) {
              iVar8 = sVar7 + 0x2d;
              do {
                cVar1 = *(char *)(iVar12 + iVar8);
                iVar20 = iVar8;
                if ((cVar1 == '/') || (cVar1 == ':' || cVar1 == '\\')) break;
                iVar20 = iVar8 + -1;
                iVar17 = iVar8 + -0x2e;
                iVar8 = iVar20;
              } while (0 < iVar17);
              sVar7 = sVar7 - (iVar20 + -0x2d);
              pbVar10 = pbVar10 + iVar20 + -0x2d;
            }
            if (sVar7 == sVar3) {
              if (uVar6 == 0) {
                bVar24 = true;
                pbVar13 = param_2;
                for (sVar7 = sVar3; sVar7 != 0; sVar7 = sVar7 - 1) {
                  uVar19 = (uint)*pbVar10;
                  uVar18 = (uint)*pbVar13;
                  if ((uVar19 - 0x41 & 0xff) < 0x1a) {
                    uVar19 = uVar19 + 0x20;
                  }
                  if ((uVar18 - 0x41 & 0xff) < 0x1a) {
                    uVar18 = uVar18 + 0x20;
                  }
                  if (uVar18 != uVar19) goto LAB_0010d89c;
                  pbVar13 = pbVar13 + 1;
                  pbVar10 = pbVar10 + 1;
                }
              }
              else {
                iVar12 = memcmp(param_2,pbVar10,sVar3);
                bVar24 = iVar12 == 0;
              }
              bVar9 = bVar24;
              if (bVar24) {
                bVar9 = true;
              }
              if ((bool)(bVar9 & param_5 != (uint *)0x0)) {
LAB_0010dbd4:
                *param_5 = uVar21;
                return 1;
              }
              if (bVar24) {
                return 1;
              }
            }
          }
LAB_0010d89c:
          uVar21 = uVar21 + 1;
        } while (uVar21 < uVar2);
      }
      else {
        do {
          iVar12 = iVar23 + *(int *)(iVar5 + uVar21 * 4);
          sVar7 = (size_t)*(ushort *)(iVar12 + 0x1c);
          if ((sVar3 <= sVar7) && (*(ushort *)(iVar12 + 0x20) == local_2c)) {
            pbVar10 = (byte *)(iVar12 + 0x2e);
            pbVar11 = pbVar10 + *(ushort *)(iVar12 + 0x1e) + sVar7;
            pbVar13 = param_3;
            sVar14 = local_2c;
            if (uVar6 == 0) {
              do {
                uVar18 = (uint)*pbVar11;
                uVar19 = (uint)*pbVar13;
                if ((uVar18 - 0x41 & 0xff) < 0x1a) {
                  uVar18 = uVar18 + 0x20;
                }
                if ((uVar19 - 0x41 & 0xff) < 0x1a) {
                  uVar19 = uVar19 + 0x20;
                }
                if (uVar19 != uVar18) goto LAB_0010d9fc;
                pbVar11 = pbVar11 + 1;
                sVar14 = sVar14 - 1;
                pbVar13 = pbVar13 + 1;
              } while (sVar14 != 0);
            }
            else {
              iVar8 = memcmp(param_3,pbVar11,local_2c);
              if (iVar8 != 0) goto LAB_0010d9fc;
            }
            if ((param_4 & 0x200) != 0 && sVar7 != 0) {
              iVar8 = sVar7 + 0x2d;
              do {
                cVar1 = *(char *)(iVar12 + iVar8);
                iVar20 = iVar8;
                if ((cVar1 == '/') || (cVar1 == ':' || cVar1 == '\\')) break;
                iVar20 = iVar8 + -1;
                iVar17 = iVar8 + -0x2e;
                iVar8 = iVar20;
              } while (0 < iVar17);
              sVar7 = sVar7 - (iVar20 + -0x2d);
              pbVar10 = pbVar10 + iVar20 + -0x2d;
            }
            if (sVar7 == sVar3) {
              if (uVar6 == 0) {
                bVar24 = true;
                pbVar13 = param_2;
                for (sVar7 = sVar3; sVar7 != 0; sVar7 = sVar7 - 1) {
                  uVar18 = (uint)*pbVar10;
                  uVar19 = (uint)*pbVar13;
                  if ((uVar18 - 0x41 & 0xff) < 0x1a) {
                    uVar18 = uVar18 + 0x20;
                  }
                  if ((uVar19 - 0x41 & 0xff) < 0x1a) {
                    uVar19 = uVar19 + 0x20;
                  }
                  if (uVar19 != uVar18) goto LAB_0010d9fc;
                  pbVar13 = pbVar13 + 1;
                  pbVar10 = pbVar10 + 1;
                }
              }
              else {
                iVar12 = memcmp(param_2,pbVar10,sVar3);
                bVar24 = iVar12 == 0;
              }
              if (!(bool)(bVar24 ^ 1U | param_5 == (uint *)0x0)) goto LAB_0010dbd4;
              if (bVar24) {
                return 1;
              }
            }
          }
LAB_0010d9fc:
          uVar21 = uVar21 + 1;
        } while (uVar21 < uVar2);
      }
    }
LAB_0010dbb8:
    *(undefined4 *)(param_1 + 0x1c) = 0x1c;
    return 0;
  }
LAB_0010d630:
  *(undefined4 *)(param_1 + 0x1c) = 0x18;
  return 0;
}

