/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00117b08 FUN_00117b08 */

undefined4 FUN_00117b08(int param_1,uint param_2)

{
  undefined4 uVar1;
  char *pcVar2;
  int *piVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  char cVar7;
  uint uVar8;
  int iVar9;
  undefined auStack_470 [8];
  undefined4 local_468;
  undefined4 uStack_464;
  undefined2 local_45a;
  undefined4 local_458;
  undefined4 local_454;
  undefined4 local_450;
  undefined4 uStack_44c;
  undefined4 local_448;
  undefined4 uStack_444;
  undefined4 local_43c;
  undefined4 local_438;
  undefined4 uStack_434;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  uVar1 = 0xfffffffc;
  if ((*(int *)(param_1 + 0x14) == 1) && (uVar1 = 0xfffffff6, param_2 < *(uint *)(param_1 + 0x10)))
  {
    iVar9 = **(int **)(param_1 + 0x48) + *(int *)((*(int **)(param_1 + 0x48))[4] + param_2 * 4);
    if (iVar9 == 0) {
      return 0xfffffff5;
    }
    uVar8 = (uint)*(ushort *)(iVar9 + 0x1c);
    if (*(void **)(param_1 + 0x5c) != (void *)0x0) {
      free(*(void **)(param_1 + 0x5c));
      *(undefined4 *)(param_1 + 0x5c) = 0;
    }
    pcVar2 = (char *)calloc(uVar8 + 1,1);
    if (uVar8 != 0 && pcVar2 != (char *)0x0) {
      pcVar4 = (char *)(iVar9 + 0x2f);
      cVar7 = *(char *)(iVar9 + 0x2e);
      pcVar6 = pcVar2;
      if (cVar7 != '\\') goto LAB_00117cc4;
      do {
        cVar7 = '/';
        pcVar5 = pcVar4;
        pcVar4 = pcVar6;
        while( true ) {
          pcVar6 = pcVar4 + 1;
          *pcVar4 = cVar7;
          uVar8 = uVar8 - 1;
          if (uVar8 == 0) goto LAB_00117b9c;
          pcVar4 = pcVar5 + 1;
          cVar7 = *pcVar5;
          if (cVar7 == '\\') break;
LAB_00117cc4:
          pcVar5 = pcVar4;
          pcVar4 = pcVar6;
          if (cVar7 == '\0') goto LAB_00117b9c;
        }
      } while( true );
    }
LAB_00117b9c:
    *(char **)(param_1 + 0x5c) = pcVar2;
    if (pcVar2 == (char *)0x0) {
      return 0xfffffffe;
    }
    piVar3 = *(int **)(param_1 + 0x48);
    iVar9 = 0;
    if ((piVar3 != (int *)0x0) && (iVar9 = 0, param_2 < *(uint *)(param_1 + 0x10))) {
      iVar9 = *piVar3 + *(int *)(piVar3[4] + param_2 * 4);
    }
    iVar9 = FUN_001107b8(param_1,param_2,iVar9,auStack_470,0);
    if (iVar9 == 0) {
      return 0xfffffffd;
    }
    *(uint *)(param_1 + 0x58) = param_2;
    *(undefined4 *)(param_1 + 0x68) = local_450;
    *(undefined4 *)(param_1 + 0x6c) = uStack_44c;
    *(undefined4 *)(param_1 + 0x60) = local_448;
    *(undefined4 *)(param_1 + 100) = uStack_444;
    *(undefined4 *)(param_1 + 0x70) = local_454;
    *(undefined4 *)(param_1 + 0x78) = local_468;
    *(undefined4 *)(param_1 + 0x7c) = uStack_464;
    *(undefined4 *)(param_1 + 0xa0) = local_438;
    *(undefined4 *)(param_1 + 0xa4) = uStack_434;
    *(undefined2 *)(param_1 + 0xa8) = local_45a;
    *(undefined4 *)(&DAT_0004e008 + param_1) = local_43c;
    *(undefined4 *)(&DAT_0004e00c + param_1) = local_458;
    uVar1 = 0;
  }
  return uVar1;
}

