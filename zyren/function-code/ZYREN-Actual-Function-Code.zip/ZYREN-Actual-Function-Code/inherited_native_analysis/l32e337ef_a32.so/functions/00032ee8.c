/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032ee8 FUN_00032ee8 */

int FUN_00032ee8(byte *param_1)

{
  int local_c;
  byte local_5;
  byte *local_4;
  
  local_c = 0x1505;
  local_5 = *param_1;
  local_4 = param_1;
  while (local_5 != 0) {
    local_c = local_c * 0x21 + (uint)local_5;
    local_5 = local_4[1];
    local_4 = local_4 + 1;
  }
  return local_c;
}

