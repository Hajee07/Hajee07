/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0009d6c0 thunk_FUN_000f41c4 */

void thunk_FUN_000f41c4(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
                    /* WARNING: Could not recover jumptable at 0x000f4260. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_000f4210 + DAT_000f4210))(param_1,param_2,param_3);
  return;
}

