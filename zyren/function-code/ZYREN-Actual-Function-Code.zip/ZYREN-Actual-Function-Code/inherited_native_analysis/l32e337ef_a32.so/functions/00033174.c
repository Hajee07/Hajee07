/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033174 FUN_00033174 */

void FUN_00033174(uint *param_1,byte *param_2,byte *param_3,int param_4)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = *param_1;
  uVar3 = param_1[1];
  if (0 < param_4) {
    do {
      uVar4 = uVar4 + 1 & 0xff;
      bVar1 = *(byte *)((int)param_1 + uVar4 + 8);
      uVar3 = bVar1 + uVar3 & 0xff;
      bVar2 = *(byte *)((int)param_1 + uVar3 + 8);
      *(byte *)((int)param_1 + uVar4 + 8) = bVar2;
      *(byte *)((int)param_1 + uVar3 + 8) = bVar1;
      *param_3 = *(byte *)((int)param_1 + ((uint)bVar2 + (uint)bVar1 & 0xff) + 8) ^ *param_2;
      param_4 = param_4 + -1;
      param_2 = param_2 + 1;
      param_3 = param_3 + 1;
    } while (param_4 != 0);
  }
  *param_1 = uVar4;
  param_1[1] = uVar3;
  return;
}

