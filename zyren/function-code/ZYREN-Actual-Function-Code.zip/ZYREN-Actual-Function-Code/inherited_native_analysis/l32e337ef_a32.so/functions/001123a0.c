/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001123a0 FUN_001123a0 */

undefined4 FUN_001123a0(uint *param_1,uint param_2,uint param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  bool bVar4;
  
  uVar1 = 0;
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  uVar3 = param_1[0x12];
  if ((uVar3 == 0) || (param_1[5] != 1)) goto LAB_001124e8;
  if ((param_3 & 0x4000) == 0) {
    uVar2 = param_1[4];
    if (*(int *)(uVar3 + 0x34) != 0) goto LAB_0011241c;
    if (uVar2 == 0xffff) goto LAB_00112458;
    if (param_1[1] + (uint)(0xffffffb3 < *param_1) != 0) {
      param_1[7] = 3;
      return uVar1;
    }
  }
  else {
    if (*(int *)(uVar3 + 0x34) == 0) goto LAB_001124e8;
    uVar2 = param_1[4];
LAB_0011241c:
    if (uVar2 == 0xffffffff) {
LAB_00112458:
      param_1[7] = 2;
      return uVar1;
    }
  }
  if (*(int *)(uVar3 + 0x3c) == 0) {
    if (*(int *)(uVar3 + 0x48) == 0) {
      if (param_1[0xf] == 0) goto LAB_001124e8;
      goto LAB_001124a8;
    }
    if ((uint *)param_1[0x11] != param_1) goto LAB_001124e8;
    uVar2 = DAT_001124f8 + 0x11248c;
    *(undefined4 *)(uVar3 + 0x50) = *(undefined4 *)(uVar3 + 0x4c);
  }
  else {
    if ((uint *)param_1[0x11] != param_1) {
LAB_001124e8:
      param_1[7] = 0x18;
      return uVar1;
    }
    bVar4 = param_2 == 0;
    if (bVar4) {
      param_2 = param_1[6];
    }
    uVar2 = DAT_001124f4 + 0x112450;
    if (bVar4 && param_2 == 4) goto LAB_001124e8;
  }
  param_1[0xf] = uVar2;
  param_1[0x10] = 0;
LAB_001124a8:
  *param_1 = param_1[2];
  param_1[1] = param_1[3];
  param_1[2] = 0;
  param_1[3] = 0;
  (*(code *)param_1[0xb])(param_1[0xd],*(undefined4 *)(uVar3 + 0x20));
  *(undefined4 *)(uVar3 + 0x20) = 0;
  *(undefined4 *)(uVar3 + 0x24) = 0;
  *(undefined4 *)(uVar3 + 0x28) = 0;
  *(undefined4 *)(uVar3 + 0x2c) = 0;
  param_1[5] = 2;
  return 1;
}

