/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030e78 FUN_00030e78 */

int FUN_00030e78(byte *param_1)

{
  int iVar1;
  uint uVar2;
  
  if (*param_1 != 0) {
    iVar1 = 0x1505;
    uVar2 = (uint)*param_1;
    do {
      param_1 = param_1 + 1;
      iVar1 = iVar1 * 0x21 + uVar2;
      uVar2 = (uint)*param_1;
    } while (*param_1 != 0);
    return iVar1;
  }
  return 0x1505;
}

