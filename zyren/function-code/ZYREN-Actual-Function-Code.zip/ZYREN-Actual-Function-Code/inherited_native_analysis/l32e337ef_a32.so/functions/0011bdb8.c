/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011bdb8 FUN_0011bdb8 */

undefined4 FUN_0011bdb8(code *param_1,undefined4 param_2)

{
  char cVar1;
  FILE *__stream;
  char *pcVar2;
  int iVar3;
  size_t sVar4;
  void *******pppppppvVar5;
  void ******ppppppvVar6;
  void *******pppppppvVar7;
  bool bVar8;
  void ******ppppppvVar9;
  void ******local_20c0;
  void *******local_20bc;
  int local_20b8;
  undefined2 local_20b4;
  undefined local_2080;
  undefined local_207f;
  undefined local_207e;
  char local_207d;
  undefined auStack_207c [4];
  int local_2078;
  void ******local_2074;
  char local_2070 [4096];
  char acStack_1070 [4160];
  void *******local_30;
  void *******local_2c;
  
  local_30 = &local_30;
  local_2c = &local_30;
  __stream = fopen((char *)(DAT_0011c058 + 0x11bde4),(char *)(DAT_0011c05c + 0x11bdec));
  pcVar2 = fgets(acStack_1070,0x1040,__stream);
  if (pcVar2 != (char *)0x0) {
    do {
      local_207d = '\0';
      local_207e = 0;
      local_207f = 0;
      local_2080 = 0;
      local_2070[0] = '\0';
      iVar3 = sscanf(pcVar2,(char *)(DAT_0011c060 + 0x11be98),&local_2074,&local_2078,&local_207d,
                     &local_207e,&local_207f,&local_2080,auStack_207c,&local_20c0,&local_20c0,
                     local_2070);
      if (iVar3 == 10) {
        cVar1 = local_207d;
        if (local_207d == 'r') {
          cVar1 = local_2070[0];
        }
        if (local_207d == 'r' && cVar1 == '/') {
          bVar8 = false;
          ppppppvVar6 = local_2074;
          for (pppppppvVar5 = local_30; local_2074 = ppppppvVar6,
              (void ********)pppppppvVar5 != &local_30; pppppppvVar5 = (void *******)*pppppppvVar5)
          {
            iVar3 = strcmp((char *)(pppppppvVar5 + 0xe),local_2070);
            if (iVar3 == 0) {
              bVar8 = true;
              pppppppvVar5[4] = (void ******)(local_2078 - (int)pppppppvVar5[2]);
            }
            ppppppvVar6 = local_2074;
          }
          ppppppvVar9 = (void ******)(local_2078 - (int)ppppppvVar6);
          if ((((4 < (int)ppppppvVar9) && (!bVar8)) &&
              (iVar3 = memcmp(local_2070,(void *)(DAT_0011c064 + 0x11bf30),5), iVar3 != 0)) &&
             (*ppppppvVar6 == (void *****)0x464c457f)) {
            sVar4 = strlen(local_2070);
            pppppppvVar5 = (void *******)calloc(1,sVar4 + 0x3c);
            pppppppvVar5[2] = ppppppvVar6;
            pcVar2 = strcpy((char *)(pppppppvVar5 + 0xe),local_2070);
            pppppppvVar5[3] = ppppppvVar9;
            pppppppvVar5[4] = ppppppvVar9;
            pcVar2 = strstr(pcVar2,(char *)(DAT_0011c068 + 0x11bf88));
            if (pcVar2 == (char *)0x0) {
              *pppppppvVar5 = &local_30;
              pppppppvVar5[1] = local_2c;
              *local_2c = pppppppvVar5;
              local_2c = pppppppvVar5;
            }
          }
        }
      }
      pcVar2 = fgets(acStack_1070,0x1040,__stream);
    } while (pcVar2 != (char *)0x0);
  }
  fclose(__stream);
  if ((void ********)local_30 != &local_30) {
    pppppppvVar5 = local_30;
    do {
      local_20c0 = pppppppvVar5[2];
      local_20b8 = (int)local_20c0 + (int)local_20c0[7];
      local_20b4 = *(undefined2 *)(local_20c0 + 0xb);
      local_20bc = pppppppvVar5 + 0xe;
      iVar3 = (*param_1)(&local_20c0,0x10,param_2);
      if (iVar3 != 0) break;
      pppppppvVar5 = (void *******)*pppppppvVar5;
    } while ((void ********)pppppppvVar5 != &local_30);
    pppppppvVar5 = local_30;
    if ((void ********)local_30 != &local_30 && local_30 != (void *******)0x0) {
      do {
        pppppppvVar7 = (void *******)*pppppppvVar5;
        ppppppvVar6 = pppppppvVar5[1];
        pppppppvVar7[1] = ppppppvVar6;
        *ppppppvVar6 = pppppppvVar7;
        free(pppppppvVar5);
        if ((void ********)pppppppvVar7 == &local_30) {
          return 0;
        }
        pppppppvVar5 = pppppppvVar7;
      } while (pppppppvVar7 != (void *******)0x0);
    }
  }
  return 0;
}

