/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0011faec FUN_0011faec */

char * FUN_0011faec(char *param_1,char *param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  char *pcVar4;
  
  cVar1 = *param_2;
  if (cVar1 == '\0') {
    return param_1;
  }
  uVar2 = FUN_0011fbe0(param_2 + 1);
  do {
    pcVar4 = param_1;
    param_1 = pcVar4 + 1;
    if (*pcVar4 == '\0') {
      return (char *)0x0;
    }
  } while ((*pcVar4 != cVar1) || (iVar3 = FUN_0011fc0c(param_1,param_2 + 1,uVar2), iVar3 != 0));
  return pcVar4;
}

