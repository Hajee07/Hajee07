/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010e644 FUN_0010e644 */

void FUN_0010e644(int param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = 0;
  if (param_1 != 0) {
    piVar2 = *(int **)(param_1 + 0x48);
    iVar1 = 0;
    if ((piVar2 != (int *)0x0) && (iVar1 = 0, param_2 < *(uint *)(param_1 + 0x10))) {
      iVar1 = *piVar2 + *(int *)(piVar2[4] + param_2 * 4);
    }
  }
  FUN_001107b8(param_1,param_2,iVar1,param_3,0);
  return;
}

