/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031480 FUN_00031480 */

undefined4 FUN_00031480(undefined4 *param_1,int param_2,int param_3)

{
  undefined *puVar1;
  undefined *puVar2;
  int iVar3;
  int iVar4;
  
  *param_1 = *(undefined4 *)(param_2 + 0x20);
  param_1[3] = *(undefined4 *)(param_2 + 0x14);
  param_1[1] = *(undefined4 *)(param_2 + 0x1c);
  param_1[2] = *(undefined4 *)(param_2 + 0x18);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = *(undefined4 *)(param_2 + 0xc);
  param_1[6] = *(undefined4 *)(param_2 + 8);
  param_1[7] = *(undefined4 *)(param_2 + 4);
  param_1[8] = (*(uint *)(param_2 + 0x3c) & 1) << 4 | (*(uint *)(param_2 + 0x38) & 1) << 2 |
               *(uint *)(param_2 + 0x34) >> 0x1f | *(uint *)(param_2 + 0x30) >> 0x19 & 0x40 |
               *(byte *)(param_2 + 0x2f) & 0x80 | *(uint *)(param_2 + 0x28) >> 0x14 & 0x800;
  iVar4 = *(int *)(param_2 + 0x10) - *(int *)(param_2 + 0x44);
  if (-1 < iVar4) {
    iVar3 = (param_3 - iVar4) + -0x50;
    if (0 < iVar3) {
      puVar1 = (undefined *)param_1[4];
      puVar2 = (undefined *)(param_2 + iVar4 + 0x50);
      do {
        *puVar1 = *puVar2;
        iVar3 = iVar3 + -1;
        puVar1 = puVar1 + 1;
        puVar2 = puVar2 + 1;
      } while (iVar3 != 0);
    }
    return 0;
  }
  return 0xffffffff;
}

