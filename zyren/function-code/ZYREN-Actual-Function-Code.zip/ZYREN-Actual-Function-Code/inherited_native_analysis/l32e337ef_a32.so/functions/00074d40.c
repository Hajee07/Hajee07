/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00074d40 FUN_00074d40 */

void FUN_00074d40(undefined4 param_1,undefined4 param_2)

{
  int unaff_r4;
  code *UNRECOVERED_JUMPTABLE;
  
  if (unaff_r4 != DAT_00074d54) {
    UNRECOVERED_JUMPTABLE = (code *)((int)&DAT_00074d78 + DAT_00074d78);
  }
                    /* WARNING: Could not recover jumptable at 0x00074d9c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(param_1,param_2);
  return;
}

