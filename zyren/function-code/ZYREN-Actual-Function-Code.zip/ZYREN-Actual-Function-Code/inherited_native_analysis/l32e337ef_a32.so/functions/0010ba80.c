/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0010ba80 FUN_0010ba80 */

undefined4
FUN_0010ba80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  code *pcVar2;
  bool bVar3;
  
  if (param_1 == (undefined4 *)0x0) {
    return 0;
  }
  if (param_1[0xe] != 0) {
    iVar1 = param_1[0x12];
    bVar3 = iVar1 == 0;
    if (bVar3) {
      iVar1 = param_1[5];
    }
    if (bVar3 && iVar1 == 0) {
      pcVar2 = (code *)param_1[10];
      if (pcVar2 == (code *)0x0) {
        pcVar2 = (code *)(DAT_0010bbc4 + 0x10baf4);
        param_1[10] = pcVar2;
      }
      if (param_1[0xb] == 0) {
        param_1[0xb] = DAT_0010bbc8 + 0x10bb08;
      }
      if (param_1[0xc] == 0) {
        param_1[0xc] = DAT_0010bbcc + 0x10bb1c;
      }
      param_1[7] = 0;
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      iVar1 = (*pcVar2)(param_1[0xd],1,0x58);
      param_1[0x12] = iVar1;
      if (iVar1 == 0) {
        param_1[7] = 0x10;
        return 0;
      }
      __aeabi_memclr8(iVar1,0x58);
      iVar1 = param_1[0x12];
      *(undefined4 *)(iVar1 + 0x2c) = 4;
      *(undefined4 *)(iVar1 + 0x30) = param_5;
      *(undefined4 *)(iVar1 + 0x34) = 0;
      *(undefined4 *)(iVar1 + 0x38) = 0;
      *(undefined4 *)(iVar1 + 0x1c) = 4;
      *(undefined4 *)(iVar1 + 0xc) = 1;
      *param_1 = param_3;
      param_1[1] = param_4;
      param_1[5] = 1;
      param_1[6] = 1;
      iVar1 = FUN_0010bbd0(param_1,param_5);
      if (iVar1 == 0) {
        FUN_0010b938(param_1,0);
        return 0;
      }
      return 1;
    }
  }
  param_1[7] = 0x18;
  return 0;
}

