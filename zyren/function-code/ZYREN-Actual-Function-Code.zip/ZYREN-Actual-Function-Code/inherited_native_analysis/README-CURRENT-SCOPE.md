# Earlier static native analysis

This directory retains the earlier recovered static decompiler files, summary/status tables and quality flags from the already published recovery ZIP. Many files concern protection/loader or library routines, and some analyze still-protected bytes. File/function counts do not measure complete original application recovery.

Treat source as inherited analysis, not newly verified original source. For the independently unpacked original menu/core memory images and newly recovered core dispatcher, use `../unpack/` and `../native_server/`. Their findings supersede earlier statements that those native snapshots or dispatcher bodies were unavailable.

Historical reports remain unchanged as provenance; read the top-level README for current limitations. Protected Java, the complete main-hook high-level code, real startup and live gameplay remain unresolved.
