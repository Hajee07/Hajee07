# Main native code index

These are inferred native representations, not recovered original Java or a complete project.

| Function | Initial status | Higher-limit retry |
|---|---|---|
| Java_com_NovaX_Menu_getMatchTimerStatus | [pseudocode_emitted](06_native_pseudocode/libNOVA_MENU.so/functions/1008cdb8.c) | No separate retry |
| Java_com_NovaX_Menu_imageBase64 | [pseudocode_emitted](06_native_pseudocode/libNOVA_MENU.so/functions/1008ce60.c) | No separate retry |
| Java_com_NovaX_Menu_Init | [pseudocode_emitted](06_native_pseudocode/libNOVA_MENU.so/functions/1008d290.c) | No separate retry |
| Java_com_NovaX_Menu_Functions | [failed](06_native_pseudocode/libNOVA_MENU.so/functions/1008d2a0.c) | [Pseudocode emitted](06_native_pseudocode/libNOVA_MENU.so/critical_retry/1008d2a0.c) |
| Java_com_NovaX_Menu_ChangesID | [failed](06_native_pseudocode/libNOVA_MENU.so/functions/10093100.c) | [Pseudocode emitted](06_native_pseudocode/libNOVA_MENU.so/critical_retry_extended/10093100.c) |
| Java_com_NovaX_Menu_LockPlayer | [pseudocode_emitted](06_native_pseudocode/libNOVA_MENU.so/functions/10098bb4.c) | No separate retry |
| Java_com_NovaX_Menu_getEnemyList | [pseudocode_emitted](06_native_pseudocode/libNOVA_MENU.so/functions/10099220.c) | No separate retry |
| Java_com_NovaX_Menu_OnDrawLoad | [failed](06_native_pseudocode/libNOVA_MENU.so/functions/1009941c.c) | [Pseudocode emitted](06_native_pseudocode/libNOVA_MENU.so/critical_retry_extended/1009941c.c) |

## Core startup retry outputs

- [ / 1010e708](06_native_pseudocode/libNOVAXITERS.so/critical_retry/retry_status.csv): pseudocode emitted = false
- [ / 10111bfc](06_native_pseudocode/libNOVAXITERS.so/critical_retry/retry_status.csv): pseudocode emitted = false
- [Recovered_raw_ctor_5 / 1010e708](06_native_pseudocode/libNOVAXITERS.so/critical_retry_raw_startup/1010e708.c): pseudocode emitted = false
- [Recovered_raw_ctor_7 / 10111bfc](06_native_pseudocode/libNOVAXITERS.so/critical_retry_raw_startup/10111bfc.c): pseudocode emitted = false

Full original `com.NovaX.MainActivity` and `com.NovaX.Menu` Java implementations remain unrecovered. See RECOVERY-REPORT.md for provenance and limitations.

All nine observed core initializer entry points also have decoded instruction and raw P-code exports under `06_native_pseudocode/libNOVAXITERS.so/raw_startup_instructions/`. The two large C decompilation failures are retained in the status files; their assembly/P-code is an intermediate representation, not recovered original C++.
