// Targeted analysis of freshly recovered bytes; not original source.
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.address.*;
import ghidra.program.model.lang.Register;
import ghidra.program.model.listing.*;
import ghidra.program.model.pcode.*;
import java.util.Iterator;
import ghidra.program.model.symbol.SourceType;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class TargetThread1Pcode extends GhidraScript {
    public void run() throws Exception {
        String[] args=getScriptArgs();
        Path out=Paths.get(args[0]); Files.createDirectories(out);
        DecompInterface di=new DecompInterface();
        di.toggleCCode(true); di.toggleSyntaxTree(true);
        di.setSimplificationStyle("firstpass");
        di.openProgram(currentProgram);
        String[][] targets={{"10177c20","core_thread_1","0","90"}};
        PrintWriter status=new PrintWriter(Files.newBufferedWriter(out.resolve("status.tsv"),StandardCharsets.UTF_8));
        status.println("address\tname\tmode\tcompleted\terror\tinstructions\tc_bytes");status.flush();
        for(String[] row:targets){
            Address entry=toAddr(row[0]); String name=row[1]; boolean thumb=row[2].equals("1");
            println("BEGIN_TARGET "+name+" "+entry+" mode="+(thumb?"Thumb":"ARM"));
            currentProgram.getProgramContext().setValue(currentProgram.getRegister("TMode"),entry,entry,thumb?BigInteger.ONE:BigInteger.ZERO);
            disassemble(entry);
            Function f=getFunctionAt(entry);
            if(f==null)f=createFunction(entry,name);
            if(f==null){status.println(row[0]+"\t"+name+"\t"+row[2]+"\tfalse\tcreateFunction failed\t0\t0");status.flush();continue;}
            f.setName(name,SourceType.ANALYSIS);
            PrintWriter asm=new PrintWriter(Files.newBufferedWriter(out.resolve(row[0]+".asm"),StandardCharsets.UTF_8));
            InstructionIterator it=currentProgram.getListing().getInstructions(f.getBody(),true);int count=0;
            while(it.hasNext()){Instruction ins=it.next();asm.println(ins.getAddress()+": "+ins);count++;}
            asm.close();
            DecompileResults result=di.decompileFunction(f,Integer.parseInt(row[3]),monitor);
            String c="";
            if(result.decompileCompleted()&&result.getDecompiledFunction()!=null){
                c="/* Fresh low-level Ghidra FIRSTPASS pseudocode (less optimization, no full recovered semantics) from original APK DT_INIT recovery.\n * NOT original source; no Android/game runtime validation.\n */\n\n"+result.getDecompiledFunction().getC();
                Files.write(out.resolve(row[0]+".c"),c.getBytes(StandardCharsets.UTF_8));
            }
            int pcodeCount=0;
            if(result.getHighFunction()!=null){
                PrintWriter pc=new PrintWriter(Files.newBufferedWriter(out.resolve(row[0]+".pcode"),StandardCharsets.UTF_8));
                pc.println("# Low-level Ghidra FIRSTPASS IR from fresh recovered original native bytes.");
                pc.println("# NOT high-level original source or verified gameplay semantics; unresolved-instruction warnings retained in logs.");
                Iterator<PcodeOpAST> ops=result.getHighFunction().getPcodeOps();
                while(ops.hasNext()){PcodeOpAST op=ops.next();pc.println(op.getSeqnum()+" "+op);pcodeCount++;}
                pc.close();
            }
            println("PCODE_COUNT "+name+" "+pcodeCount);
            String error=result.getErrorMessage().replace('\n',' ').replace('\t',' ');
            status.println(row[0]+"\t"+name+"\t"+row[2]+"\t"+result.decompileCompleted()+"\t"+error+"\t"+count+"\t"+c.length());status.flush();
            println("END_TARGET "+name+" completed="+result.decompileCompleted()+" instructions="+count+" error="+error);
            di.flushCache();
        }
        status.close();di.dispose();
    }
}
