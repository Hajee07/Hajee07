"""Extract evidence references, not a fabricated gameplay implementation."""
from pathlib import Path
import json,re,struct

ROOT=Path(__file__).resolve().parent
source=ROOT/'targeted/1012d110.c'
text=source.read_text();lines=text.splitlines()
snapshot=Path('/workspace/scratch/zyren-recovery-next/unpack/libNOVAXITERS.so.dt_init_memory.bin').read_bytes()
def resolve(literal,pc):
    return (struct.unpack_from('<I',snapshot,int(literal,16)-0x10000000)[0]+int(pc,16))&0xffffffff
spec={
102:(1425,1427,'Set one server state byte from request offset4.'),
3:(1397,1399,'Set one server state byte from request offset4.'),
1049:(612,614,'Set one server state byte from request offset4.'),
1048:(609,611,'Set one server state byte from request offset4.'),
104:(1428,1430,'Decompiler represents request offset8 as signed integer converted to float; wire-type consistency is unverified.'),
517:(1188,1190,'Set server state byte in fallback switch.'),
1099:(1115,1121,'Set server flag; clear adjacent state on disable.'),
507:(1167,1169,'Set server state byte in fallback switch.'),
34834:(1160,1164,'Set server state byte after exact-ID test.'),
7896:(1148,1153,'Set server state byte after exact-ID test.'),
33:(1409,1411,'Set server state byte from request offset4.'),
7100:(1368,1379,'Set Look Changer byte; normalize invalid stored index and mark dirty on enable.'),
7101:(1380,1386,'Set show-for-others byte and mark dirty if changer is enabled.'),
5194:(1142,1143,'Set Fly Lock server byte; selector test is source line1126 (request ID0x144a). Native menu supplies an XOR toggle result.'),
5657:(1437,1440,'Set Rise Up server byte via shared label.'),
5660:(660,684,'Clamp integer interpreted at request offset8 to15..100; optionally call game helpers; clear three state fields.'),
5198:(1127,1138,'When enabled and game helper succeeds, get three-component position, add1.5 to third field and store; clear another flag.'),
59910:(1388,1391,'Set TeleSpot manual server byte.'),
59912:(1392,1395,'Set TeleSpot auto server byte.'),
7003:(977,979,'Set Wide Camera server byte.'),
532:(942,944,'Set Invisible Kill server byte.'),
7001:(971,973,'Set Black Sky server byte.'),
504:(781,787,'Set four related server bytes from request offset4.'),
525:(793,926,'Select target using low32 bits at request offset24; complex game lookup/string-decrypt path remains inferred.'),
}
for oid in range(7102,7122):
    spec[oid]=(1096,1104,f'On nonzero request byte, enable/dirty Look state and store preset index {oid-7102}.')
rows=[]
for oid,(start,end,meaning) in sorted(spec.items()):
    excerpt='\n'.join(lines[start-1:end])
    references=[]
    for m in re.finditer(r'iRam([0-9a-f]+) \+ (0x[0-9a-f]+)',excerpt):
        references.append({'literal':hex(int(m[1],16)),'pc_base':m[2],
                           'resolved_snapshot_address':hex(resolve(m[1],m[2]))})
    rows.append({'request_id':oid,'request_id_hex':hex(oid),'source_file':str(source),
                 'source_lines':[start,end],'summary':meaning,'literal_references':references,
                 'source_excerpt':excerpt,'confidence':'fresh inferred dispatcher pseudocode; not verified game behavior'})
result={'entry':'0x1012d110','source_has_bad_instruction_warnings':True,
        'source_decompilation_completed':True,'full_gameplay_logic_recovered':False,
        'wire_offset4':'raw enable byte','wire_offset8':'payload field; inferred server type may disagree with menu float packing',
        'mapping':rows}
(ROOT/'server_dispatcher_mapping.json').write_text(json.dumps(result,indent=2)+'\n')
print('Wrote',len(rows),'request-ID mappings with exact source references and resolved snapshot pointers')
