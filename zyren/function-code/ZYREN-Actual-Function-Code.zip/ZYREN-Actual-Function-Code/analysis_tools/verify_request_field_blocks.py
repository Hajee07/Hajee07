"""Bounded checks of original recovered ARM field conversion instructions.

These checks do not start a server, app, game, syscall, or network connection.
Unicorn2.1.4 is required. Input is the fresh core snapshot at base0x10000000.
"""
from pathlib import Path
import argparse,json,struct
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM
from unicorn.arm_const import *

def check(snapshot,start,stop,word,literal,folded):
    engine=Uc(UC_ARCH_ARM,UC_MODE_ARM)
    engine.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_A15)
    engine.mem_map(0x10000000,(len(snapshot)+4095)&~4095)
    engine.mem_write(0x10000000,snapshot)
    engine.mem_map(0x20000000,0x10000)
    engine.reg_write(UC_ARM_REG_SP,0x20000000)
    engine.reg_write(UC_ARM_REG_C1_C0_2,0xf00000)
    engine.reg_write(UC_ARM_REG_FPEXC,0x40000000)
    engine.mem_write(0x20000108,struct.pack('<I',word))
    engine.emu_start(start,stop,count=20)
    assert engine.reg_read(UC_ARM_REG_PC)==stop
    pointer=(struct.unpack_from('<I',snapshot,literal-0x10000000)[0]+folded)&0xffffffff
    value=struct.unpack('<I',engine.mem_read(pointer,4))[0]
    return {'instruction_start':hex(start),'stop_before':hex(stop),'input_word':hex(word),
            'output_pointer':hex(pointer),'output_word':hex(value),
            'output_int':value if value<0x80000000 else value-0x100000000,
            'output_float':struct.unpack('<f',struct.pack('<I',value))[0]}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot',type=Path)
    parser.add_argument('--output',type=Path,default=Path('request_field_instruction_checks.json'))
    args=parser.parse_args();snapshot=args.snapshot.read_bytes();results=[]
    for word in (2000,0x44fa0000):
        results.append({'command_id':104,**check(snapshot,0x1012e348,0x1012e35c,word,0x1012f354,0x1012e37c)})
    for word in (15,0x41700000,100,0x42c80000):
        results.append({'command_id':5660,**check(snapshot,0x1012e544,0x1012e564,word,0x1012f4f0,0x1012e568)})
    assert results[0]['output_float']==2000.0
    assert results[1]['output_float']==1157234688.0
    assert [r['output_int'] for r in results[2:]]==[15,100,100,100]
    args.output.write_text(json.dumps({'scope':'Bounded real ARM blocks only; no live server/game execution',
                                      'results':results},indent=2)+'\n')
    print('PASS: six original ARM conversion/clamp vectors')

if __name__=='__main__':main()
