/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000183d4 FUN_000183d4 */

undefined4 FUN_000183d4(int *param_1)

{
  int iVar1;
  
  iVar1 = DAT_0001846c;
  param_1[0x170b] = 0;
  param_1[0x170c] = 0;
  param_1[0x170d] = 0;
  param_1[0x170e] = 0;
  param_1[0x170f] = 5;
  param_1[0x1733] = 0;
  param_1[0x1719] = 0;
  param_1[0x171a] = 0;
  param_1[0x171b] = 0;
  param_1[0x507] = 0xc00000c;
  FUN_00036044(param_1 + 0x1708,iVar1 + 0x18404,0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018470 FUN_00018470 */

int * FUN_00018470(int param_1,int param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar3 = (int *)0x0;
  if (((param_1 == 0) == (param_2 == 0)) &&
     (piVar2 = (int *)FUN_000243e8(0x25d50,param_1,param_2,param_3), iVar1 = DAT_00018594,
     piVar2 != (int *)0x0)) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = param_1;
    piVar2[0x1736] = param_2;
    piVar2[0x1737] = param_3;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    FUN_00036044(piVar2 + 0x1708,iVar1 + 0x184f8,0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    piVar3 = piVar2;
  }
  return piVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018598 FUN_00018598 */

int * FUN_00018598(int *param_1,uint param_2)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = DAT_00018678;
  piVar2 = (int *)0x0;
  if ((0x25d4f < param_2) && (((uint)param_1 & 7) == 0)) {
    param_1[0x170b] = 0;
    param_1[0x170c] = 0;
    param_1[0x170d] = 0;
    param_1[0x170e] = 0;
    param_1[0x170f] = 5;
    param_1[0x507] = 0xc00000c;
    param_1[0x1733] = 0;
    param_1[0x1719] = 0;
    param_1[0x171a] = 0;
    param_1[0x171b] = 0;
    FUN_00036044(param_1 + 0x1708,iVar1 + 0x185f4,0xc);
    *param_1 = (int)(param_1 + 4);
    param_1[1] = (int)(param_1 + 0x306);
    param_1[2] = (int)(param_1 + 0x205);
    param_1[3] = (int)(param_1 + 0x507);
    param_1[0x1741] = 0x8000001;
    param_1[0x1743] = 0;
    param_1[0x173a] = param_2;
    param_1[0x173b] = 0;
    param_1[0x173c] = 0;
    param_1[0x173d] = 0;
    param_1[0x173e] = (int)(param_1 + 0x9754);
    param_1[0x173f] = 0;
    piVar2 = param_1;
  }
  return piVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001867c FUN_0001867c */

int * FUN_0001867c(void)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)FUN_000243e8(0x25d50,0,0,0);
  iVar1 = DAT_00018774;
  piVar3 = (int *)0x0;
  if (piVar2 != (int *)0x0) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = 0;
    piVar2[0x1736] = 0;
    piVar2[0x1737] = 0;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    FUN_00036044(piVar2 + 0x1708,iVar1 + 0x186dc,0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    piVar3 = piVar2;
  }
  return piVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018778 FUN_00018778 */

undefined4 FUN_00018778(int param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  if (param_1 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = 0xffffffc0;
    if (*(int *)(param_1 + 0x5ce8) == 0) {
      puVar2 = *(undefined4 **)(param_1 + 0x5cec);
      uVar3 = *(undefined4 *)(param_1 + 0x5cd4);
      uVar4 = *(undefined4 *)(param_1 + 0x5cd8);
      uVar7 = *(undefined4 *)(param_1 + 0x5cdc);
      if (puVar2 != (undefined4 *)0x0) {
        uVar5 = puVar2[0x170d];
        uVar6 = puVar2[0x170e];
        uVar1 = puVar2[0x170c];
        FUN_00024454(*puVar2,uVar1,uVar5,uVar6);
        FUN_00024454(puVar2,uVar1,uVar5,uVar6);
      }
      uVar1 = 0;
      *(undefined4 *)(param_1 + 0x5cec) = 0;
      FUN_00024454(*(undefined4 *)(param_1 + 0x5cf8),uVar3,uVar4,uVar7);
      *(undefined4 *)(param_1 + 0x5cf8) = 0;
      FUN_00024454(param_1,uVar3,uVar4,uVar7);
    }
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018948 FUN_00018948 */

uint FUN_00018948(uint *param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  longlong lVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  
  uVar11 = 5;
  if (4 < param_3) {
    if (*param_2 == 0xfd2fb528) {
      bVar1 = *(byte *)(param_2 + 1);
      iVar9 = 6;
      if ((bVar1 & 0x20) != 0) {
        iVar9 = 5;
      }
      uVar11 = *(int *)(DAT_00018b8c + 0x1899c + (uint)(bVar1 >> 6) * 4) +
               *(int *)(DAT_00018b88 + 0x18994 + (bVar1 & 3) * 4) + iVar9 +
               ((uint)(bVar1 >> 6 == 0) & (bVar1 & 0x20) >> 5);
      if (uVar11 <= param_3) {
        param_1[5] = uVar11;
        uVar11 = 0xfffffff2;
        bVar1 = *(byte *)(param_2 + 1);
        if ((bVar1 & 8) == 0) {
          uVar11 = 0;
          if ((bVar1 & 0x20) == 0) {
            uVar8 = (uint)(*(byte *)((int)param_2 + 5) >> 3);
            uVar5 = uVar8 + 10;
            if (0x1b < uVar5) {
              return 0xfffffff0;
            }
            uVar4 = *(byte *)((int)param_2 + 5) & 7;
            uVar7 = 1 >> (0x20 - uVar5 & 0xff);
            uVar8 = uVar8 - 0x16;
            uVar5 = 1 << uVar5;
            if (-1 < (int)uVar8) {
              uVar5 = 0;
              uVar7 = 1 << (uVar8 & 0xff);
            }
            lVar2 = (ulonglong)uVar4 * (ulonglong)(uVar5 >> 3 | uVar7 << 0x1d);
            uVar8 = (uint)lVar2;
            uVar10 = uVar8 + uVar5;
            uVar8 = (uVar7 >> 3) * uVar4 + (int)((ulonglong)lVar2 >> 0x20) + uVar7 +
                    (uint)CARRY4(uVar8,uVar5);
            iVar9 = 6;
          }
          else {
            iVar9 = 5;
            uVar10 = 0;
            uVar8 = 0;
          }
          uVar5 = bVar1 & 3;
          bVar3 = bVar1 >> 6;
          if (uVar5 == 3) {
            uVar11 = *(uint *)((int)param_2 + iVar9);
            iVar9 = iVar9 + 4;
          }
          else if (uVar5 == 2) {
            puVar6 = (ushort *)((int)param_2 + iVar9);
            iVar9 = iVar9 + 2;
            uVar11 = (uint)*puVar6;
          }
          else if (uVar5 == 1) {
            uVar11 = (uint)*(byte *)((int)param_2 + iVar9);
            iVar9 = iVar9 + 1;
          }
          if (bVar3 == 1) {
            uVar7 = *(ushort *)((int)param_2 + iVar9) + 0x100;
            uVar5 = 0;
          }
          else if (bVar3 == 2) {
            uVar7 = *(uint *)((int)param_2 + iVar9);
            uVar5 = 0;
          }
          else if (bVar3 == 3) {
            uVar7 = *(uint *)((int)param_2 + iVar9);
            uVar5 = ((uint *)((int)param_2 + iVar9))[1];
          }
          else {
            uVar7 = 0xffffffff;
            uVar5 = 0xffffffff;
            if ((bVar1 & 0x20) != 0) {
              uVar7 = (uint)*(byte *)((int)param_2 + iVar9);
              uVar5 = 0;
            }
          }
          if ((bVar1 & 0x20) != 0) {
            uVar10 = uVar7;
          }
          if ((bVar1 & 0x20) != 0) {
            uVar8 = uVar5;
          }
          param_1[6] = uVar11;
          param_1[7] = ((uint)bVar1 << 0x1d) >> 0x1f;
          *param_1 = uVar7;
          param_1[1] = uVar5;
          param_1[2] = uVar10;
          param_1[3] = uVar8;
          param_1[4] = 0;
          return 0;
        }
      }
    }
    else {
      uVar11 = 0xfffffff6;
      if ((*param_2 >> 4 == 0x184d2a5) && (uVar11 = 8, 7 < param_3)) {
        FUN_00036050(param_1,0,0x20);
        *param_1 = param_2[1];
        param_1[1] = 0;
        param_1[2] = 0;
        param_1[3] = 0;
        param_1[4] = 1;
        return 0;
      }
    }
  }
  return uVar11;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018b90 FUN_00018b90 */

undefined8 FUN_00018b90(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 local_28;
  undefined4 uStack_24;
  int local_18;
  
  iVar1 = FUN_00018948(&local_28,param_1,param_2);
  if (iVar1 != 0) {
    return 0xfffffffffffffffe;
  }
  uVar2 = 0;
  uVar3 = 0;
  if (local_18 != 1) {
    uVar2 = local_28;
    uVar3 = uStack_24;
  }
  return CONCAT44(uVar3,uVar2);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018be0 FUN_00018be0 */

undefined8 FUN_00018be0(uint *param_1,uint param_2)

{
  bool bVar1;
  ushort uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  uint local_48;
  uint uStack_44;
  int local_38;
  int local_34;
  int local_2c;
  
  uVar8 = 0;
  if (param_2 < 5) {
    uVar7 = 0;
  }
  else {
    uVar8 = 0;
    uVar7 = 0;
    do {
      if ((*param_1 & 0xfffffff0) == 0x184d2a50) {
        if (param_2 < 8) {
          return 0xffffffb8;
        }
        uVar3 = param_1[1] + 8;
        if (param_2 < uVar3) {
          return 0xfffffffffffffffe;
        }
      }
      else {
        iVar4 = FUN_00018948(&local_48,param_1,param_2);
        if (iVar4 != 0) {
          return 0xfffffffffffffffe;
        }
        if (local_38 == 1) {
          uVar3 = 0;
          uVar5 = 0;
        }
        else {
          uVar3 = local_48;
          uVar5 = uStack_44;
          if (0xfffffffe < uStack_44 && (uint)(local_48 < 0xfffffffe) <= -uStack_44 - 1)
          goto LAB_00018dc0;
        }
        bVar9 = CARRY4(uVar3,uVar8);
        uVar8 = uVar3 + uVar8;
        uVar3 = uVar5 + uVar7;
        bVar1 = CARRY4(uVar5,uVar7);
        uVar7 = uVar5 + uVar7 + (uint)bVar9;
        if (bVar1 || CARRY4(uVar3,(uint)bVar9)) {
          return 0xfffffffffffffffe;
        }
        if ((param_2 < 8) || ((*param_1 & 0xfffffff0) != 0x184d2a50)) {
          uVar3 = FUN_00018948(&local_48,param_1,param_2);
          if (uVar3 < 0xffffff89) {
            if (uVar3 != 0) {
              return 0xfffffffffffffffe;
            }
            uVar5 = param_2 - local_34;
            puVar6 = (ushort *)((int)param_1 + local_34);
            do {
              if (uVar5 < 3) {
                return 0xfffffffffffffffe;
              }
              uVar2 = *puVar6;
              uVar3 = ((uint)uVar2 << 0x1d) >> 0x1e;
              if (uVar3 != 1) {
                if (uVar3 == 3) {
                  return 0xfffffffffffffffe;
                }
                uVar3 = (uint)(uint3)(CONCAT12(*(undefined *)(puVar6 + 1),uVar2) >> 3);
              }
              uVar3 = uVar3 + 3;
              if (uVar5 < uVar3) {
                return 0xfffffffffffffffe;
              }
              uVar5 = uVar5 - uVar3;
              puVar6 = (ushort *)((int)puVar6 + uVar3);
            } while ((uVar2 & 1) == 0);
            if (local_2c != 0) {
              uVar3 = 0xffffffb8;
              if (uVar5 < 4) goto joined_r0x00018d84;
              puVar6 = puVar6 + 2;
            }
            uVar3 = (int)puVar6 - (int)param_1;
          }
        }
        else {
          uVar3 = param_1[1] + 8;
        }
joined_r0x00018d84:
        if (0xffffff88 < uVar3) {
          return 0xfffffffffffffffe;
        }
      }
      param_2 = param_2 - uVar3;
      param_1 = (uint *)((int)param_1 + uVar3);
    } while (4 < param_2);
  }
  local_48 = 0xfffffffe;
  uStack_44 = 0xffffffff;
  if (param_2 == 0) {
    local_48 = uVar8;
    uStack_44 = uVar7;
  }
LAB_00018dc0:
  return CONCAT44(uStack_44,local_48);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018dd8 FUN_00018dd8 */

uint FUN_00018dd8(uint *param_1,uint param_2)

{
  ushort uVar1;
  uint uVar2;
  ushort *puVar3;
  undefined auStack_30 [20];
  int local_1c;
  int local_14;
  
  if ((7 < param_2) && (*param_1 >> 4 == 0x184d2a5)) {
    return param_1[1] + 8;
  }
  uVar2 = FUN_00018948(auStack_30,param_1,param_2);
  if (uVar2 < 0xffffff89) {
    if (uVar2 != 0) {
      return 0xffffffb8;
    }
    param_2 = param_2 - local_1c;
    puVar3 = (ushort *)((int)param_1 + local_1c);
    do {
      if (param_2 < 3) {
        return 0xffffffb8;
      }
      uVar1 = *puVar3;
      uVar2 = ((uint)uVar1 << 0x1d) >> 0x1e;
      if (uVar2 != 1) {
        if (uVar2 == 3) {
          return 0xffffffec;
        }
        uVar2 = (uint)(uint3)(CONCAT12(*(undefined *)(puVar3 + 1),uVar1) >> 3);
      }
      uVar2 = uVar2 + 3;
      if (param_2 < uVar2) {
        return 0xffffffb8;
      }
      param_2 = param_2 - uVar2;
      puVar3 = (ushort *)((int)puVar3 + uVar2);
    } while ((uVar1 & 1) == 0);
    if (local_14 != 0) {
      if (param_2 < 4) {
        return 0xffffffb8;
      }
      puVar3 = puVar3 + 2;
    }
    uVar2 = (int)puVar3 - (int)param_1;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018ecc FUN_00018ecc */

undefined8 FUN_00018ecc(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint local_28;
  int iStack_24;
  int local_18;
  
  iVar1 = FUN_00018948(&local_28,param_1,param_2);
  if ((iVar1 == 0) && (local_18 != 1)) {
    if ((uint)(0xfffffffd < local_28) <= iStack_24 + 1U) goto LAB_00018f1c;
  }
  local_28 = 0;
  iStack_24 = 0;
LAB_00018f1c:
  return CONCAT44(iStack_24,local_28);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018f74 FUN_00018f74 */

uint FUN_00018f74(int param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  bool bVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  uVar7 = 0xffffffec;
  if (param_3 < 3) {
    return 0xffffffec;
  }
  bVar1 = *(byte *)param_2;
  uVar3 = (uint)bVar1;
  uVar8 = uVar3 & 3;
  switch(uVar8) {
  case 0:
    uVar7 = (uVar3 << 0x1c) >> 0x1e;
    if (uVar7 == 1) {
      uVar7 = (uint)(*(ushort *)param_2 >> 4);
      iVar4 = 2;
    }
    else if (uVar7 == 3) {
      uVar7 = (uint)(*(uint3 *)param_2 >> 4);
      iVar4 = 3;
    }
    else {
      uVar7 = (uint)(bVar1 >> 3);
      iVar4 = 1;
    }
    uVar3 = iVar4 + uVar7;
    if (param_3 < uVar3 + 8) {
      if (param_3 < uVar3) {
        return 0xffffffec;
      }
      iVar6 = param_1 + 0x5d30;
      FUN_00036044(iVar6,(byte *)((int)param_2 + iVar4),uVar7);
      *(uint *)(param_1 + 0x5ce0) = uVar7;
      *(int *)(param_1 + 0x5cd0) = iVar6;
      FUN_00036050(iVar6 + uVar7,0,8);
      return uVar3;
    }
    *(uint *)(param_1 + 0x5ce0) = uVar7;
    *(byte **)(param_1 + 0x5cd0) = (byte *)((int)param_2 + iVar4);
    return uVar3;
  case 3:
    if (*(int *)(param_1 + 0x5c68) == 0) {
      return 0xffffffe2;
    }
  case 2:
    if (4 < param_3) {
      uVar9 = *param_2;
      uVar3 = (uVar3 << 0x1c) >> 0x1e;
      if (uVar3 == 2) {
        uVar5 = uVar9 >> 0x12;
        uVar10 = (uVar9 << 0xe) >> 0x12;
        bVar2 = false;
        iVar4 = 4;
      }
      else if (uVar3 == 3) {
        uVar10 = (uVar9 << 10) >> 0xe;
        if (0x20000 < uVar10) {
          return 0xffffffec;
        }
        bVar2 = false;
        uVar5 = (uint)*(byte *)(param_2 + 1) << 10 | uVar9 >> 0x16;
        iVar4 = 5;
      }
      else {
        uVar5 = (uVar9 << 8) >> 0x16;
        uVar10 = (uVar9 << 0x12) >> 0x16;
        bVar2 = uVar3 == 0;
        iVar4 = 3;
      }
      if (uVar5 + iVar4 <= param_3) {
        if (uVar8 == 3) {
          if (bVar2) {
            uVar3 = FUN_00021da0(param_1 + 0x5d30,uVar10,(byte *)((int)param_2 + iVar4),uVar5,
                                 *(undefined4 *)(param_1 + 0xc));
          }
          else {
            uVar3 = FUN_00021e20(param_1 + 0x5d30,uVar10,(byte *)((int)param_2 + iVar4),uVar5,
                                 *(undefined4 *)(param_1 + 0xc));
          }
        }
        else if (bVar2) {
          uVar3 = FUN_0001e164(param_1 + 0x141c,param_1 + 0x5d30,uVar10,
                               (byte *)((int)param_2 + iVar4),uVar5,param_1 + 0x5420,0x800);
        }
        else {
          uVar3 = FUN_0002218c(param_1 + 0x141c,param_1 + 0x5d30,uVar10,
                               (byte *)((int)param_2 + iVar4),uVar5,param_1 + 0x5420,0x800);
        }
        if (uVar3 < 0xffffff89) {
          *(uint *)(param_1 + 0x5ce0) = uVar10;
          *(int *)(param_1 + 0x5cd0) = param_1 + 0x5d30;
          *(int *)(param_1 + 0x5c68) = 1;
          if (uVar8 == 2) {
            *(int *)(param_1 + 0xc) = param_1 + 0x141c;
          }
          FUN_00036050(param_1 + uVar10 + 0x5d30,0,8);
          uVar7 = uVar5 + iVar4;
        }
      }
    }
    return uVar7;
  }
  uVar7 = (uVar3 << 0x1c) >> 0x1e;
  if (uVar7 == 1) {
    iVar4 = 2;
    uVar7 = (uint)(*(ushort *)param_2 >> 4);
  }
  else if (uVar7 == 3) {
    if (param_3 < 4) {
      return 0xffffffec;
    }
    if (0x20000f < *(uint3 *)param_2) {
      return 0xffffffec;
    }
    uVar7 = (uint)(*(uint3 *)param_2 >> 4);
    iVar4 = 3;
  }
  else {
    uVar7 = (uint)(bVar1 >> 3);
    iVar4 = 1;
  }
  FUN_00036050(param_1 + 0x5d30,*(byte *)((int)param_2 + iVar4),uVar7 + 8);
  *(uint *)(param_1 + 0x5ce0) = uVar7;
  *(int *)(param_1 + 0x5cd0) = param_1 + 0x5d30;
  return iVar4 + 1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00019278 FUN_00019278 */

byte * FUN_00019278(int **param_1,uint *param_2,byte *param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  int **ppiVar3;
  uint uVar4;
  int iVar5;
  byte *pbVar6;
  byte *pbVar7;
  int **ppiVar8;
  byte *pbVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_96 [106];
  uint local_2c;
  undefined4 local_28;
  
  if (param_4 == 0) {
    return (byte *)0xffffffb8;
  }
  pbVar6 = param_3 + 1;
  bVar1 = *param_3;
  uVar2 = (uint)bVar1;
  if (uVar2 == 0) {
    *param_2 = 0;
    return (byte *)0x1;
  }
  iVar5 = (int)(char)bVar1;
  if (iVar5 == -1 || iVar5 + 1 < 0 != SCARRY4(iVar5,1)) {
    if (iVar5 == -1) {
      if (param_4 < 3) {
        return (byte *)0xffffffb8;
      }
      pbVar6 = param_3 + 3;
      uVar2 = *(ushort *)(param_3 + 1) + 0x7f00;
    }
    else {
      if (param_4 < 2) {
        return (byte *)0xffffffb8;
      }
      pbVar6 = param_3 + 2;
      uVar2 = CONCAT11(bVar1,param_3[1]) - 0x8000;
    }
  }
  *param_2 = uVar2;
  pbVar9 = param_3 + param_4;
  if (pbVar9 < pbVar6 + 4) {
    return (byte *)0xffffffb8;
  }
  pbVar7 = pbVar6 + 1;
  bVar1 = *pbVar6;
  ppiVar8 = param_1 + 0x171b;
  local_28 = 0x23;
  uVar10 = ((uint)bVar1 << 0x1c) >> 0x1e;
  uVar11 = ((uint)bVar1 << 0x1a) >> 0x1e;
  uVar2 = (uint)(bVar1 >> 6);
  if (bVar1 >> 6 == 0) {
    *param_1 = (int *)(DAT_00019610 + 0x193a4);
LAB_0001942c:
    pbVar7 = pbVar7 + uVar2;
    local_28 = 0x1c;
    if (uVar11 == 0) {
      param_1[2] = (int *)(DAT_00019614 + 0x194a0);
      uVar2 = 0;
    }
    else if (uVar11 == 3) {
      uVar2 = 0;
      if (*ppiVar8 == (int *)0x0) goto LAB_00019598;
    }
    else {
      ppiVar3 = param_1 + 0x205;
      if (uVar11 == 1) {
        if (((int)pbVar9 - (int)pbVar7 == 0) || (0x1c < *pbVar7)) goto LAB_00019598;
        FUN_0001ca20();
        uVar2 = 1;
        param_1[2] = (int *)ppiVar3;
      }
      else {
        uVar11 = FUN_0001d7c8(auStack_96,&local_28,&local_2c,pbVar7,(int)pbVar9 - (int)pbVar7);
        uVar2 = 0xffffffec;
        if ((uVar11 < 0xffffff89) && (uVar2 = 0xffffffec, local_2c < 9)) {
          FUN_0001c858(ppiVar3,auStack_96,local_28);
          param_1[2] = (int *)ppiVar3;
          uVar2 = uVar11;
        }
        if (0xffffff88 < uVar2) {
          return (byte *)0xffffffec;
        }
      }
    }
    pbVar7 = pbVar7 + uVar2;
    local_28 = 0x34;
    if (uVar10 == 0) {
      param_1[1] = (int *)(DAT_00019618 + 0x19588);
      uVar2 = 0;
    }
    else if (uVar10 == 3) {
      uVar2 = 0;
      if (*ppiVar8 == (int *)0x0) goto LAB_00019598;
    }
    else {
      ppiVar8 = param_1 + 0x306;
      if (uVar10 == 1) {
        if (((int)pbVar9 - (int)pbVar7 == 0) || (0x34 < *pbVar7)) goto LAB_00019598;
        FUN_0001ca20(ppiVar8);
        uVar2 = 1;
        param_1[1] = (int *)ppiVar8;
      }
      else {
        uVar10 = FUN_0001d7c8(auStack_96,&local_28,&local_2c,pbVar7,(int)pbVar9 - (int)pbVar7);
        uVar2 = 0xffffffec;
        if ((uVar10 < 0xffffff89) && (uVar2 = 0xffffffec, local_2c < 10)) {
          FUN_0001c858(ppiVar8,auStack_96,local_28);
          param_1[1] = (int *)ppiVar8;
          uVar2 = uVar10;
        }
        if (0xffffff88 < uVar2) {
          return (byte *)0xffffffec;
        }
      }
    }
    pbVar7 = pbVar7 + (uVar2 - (int)param_3);
  }
  else {
    if (uVar2 != 3) {
      ppiVar3 = param_1 + 4;
      if (uVar2 == 1) {
        if (((int)pbVar9 - (int)pbVar7 == 0) || (0x23 < *pbVar7)) goto LAB_00019598;
        FUN_0001ca20();
        uVar2 = 1;
        *param_1 = (int *)ppiVar3;
      }
      else {
        uVar4 = FUN_0001d7c8(auStack_96,&local_28,&local_2c,pbVar7,(int)pbVar9 - (int)pbVar7);
        uVar2 = 0xffffffec;
        if ((uVar4 < 0xffffff89) && (uVar2 = 0xffffffec, local_2c < 10)) {
          FUN_0001c858(ppiVar3,auStack_96,local_28);
          *param_1 = (int *)ppiVar3;
          uVar2 = uVar4;
        }
        if (0xffffff88 < uVar2) {
          return (byte *)0xffffffec;
        }
      }
      goto LAB_0001942c;
    }
    uVar2 = 0;
    if (*ppiVar8 != (int *)0x0) goto LAB_0001942c;
LAB_00019598:
    pbVar7 = (byte *)0xffffffec;
  }
  return pbVar7;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001961c FUN_0001961c */

void FUN_0001961c(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)(param_1 + 0x5c2c);
  iVar1 = *piVar2;
  if (iVar1 != param_2) {
    *(int *)(param_1 + 0x5c38) = iVar1;
    iVar3 = *(int *)(param_1 + 0x5c30);
    *piVar2 = param_2;
    *(int *)(param_1 + 0x5c30) = param_2;
    *(int *)(param_1 + 0x5c34) = param_2 + (iVar3 - iVar1);
  }
  iVar1 = FUN_0001967c(param_1,param_2,param_3,param_4,param_5);
  *piVar2 = param_2 + iVar1;
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001967c FUN_0001967c */

uint FUN_0001967c(ushort **param_1,int param_2,int param_3,int param_4,uint param_5)

{
  uint uVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort *puVar4;
  ushort *puVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  undefined *puVar9;
  uint *puVar10;
  uint *puVar11;
  int iVar12;
  undefined *puVar13;
  uint uVar14;
  uint uVar15;
  ushort *puVar16;
  undefined *puVar17;
  uint uVar18;
  undefined *puVar19;
  ushort *puVar20;
  ushort *puVar21;
  undefined *puVar22;
  int iVar23;
  int iVar24;
  uint local_70;
  uint local_6c;
  uint *local_68;
  uint *local_64;
  uint *local_60;
  uint local_5c;
  ushort *local_58;
  uint local_54;
  ushort *local_50;
  uint local_4c;
  ushort *local_48;
  ushort *local_44 [6];
  int local_2c;
  ushort *local_28;
  
  if (param_5 >> 0x11 != 0) {
    return 0xffffffb8;
  }
  uVar1 = FUN_00018f74(param_1,param_4,param_5);
  if (0xffffff88 < uVar1) {
    return uVar1;
  }
  param_4 = param_4 + uVar1;
  puVar21 = param_1[0x1734];
  puVar2 = param_1[0x170c];
  puVar3 = param_1[0x170d];
  puVar4 = param_1[0x170e];
  puVar5 = param_1[0x1738];
  local_28 = puVar21;
  uVar6 = FUN_00019278(param_1,&local_2c,param_4,param_5 - uVar1);
  puVar7 = (uint *)(param_4 + uVar6);
  if (0xffffff88 < uVar6) {
    return uVar6;
  }
  puVar13 = (undefined *)(param_2 + param_3);
  puVar5 = (ushort *)((int)puVar21 + (int)puVar5);
  iVar24 = param_2;
  if (local_2c == 0) {
LAB_0001a22c:
    uVar1 = (int)puVar5 - (int)puVar21;
    if (uVar1 <= (uint)((int)puVar13 - iVar24)) {
      FUN_00036044(iVar24,puVar21,uVar1);
      return (iVar24 + uVar1) - param_2;
    }
    return 0xffffffba;
  }
  param_4 = param_4 + (param_5 - uVar1);
  param_1[0x171b] = (ushort *)0x1;
  local_44[0] = param_1[0x1708];
  local_44[1] = param_1[0x1709];
  local_44[2] = param_1[0x170a];
  uVar1 = param_4 - (int)puVar7;
  if (uVar1 == 0) {
    FUN_00036050(&local_70,0,0x14);
    return 0xffffffec;
  }
  local_60 = puVar7 + 1;
  if (uVar1 < 4) {
    local_70 = (uint)*(byte *)puVar7;
    if (uVar1 == 2) {
LAB_00019828:
      local_70 = local_70 + (uint)*(byte *)((int)puVar7 + 1) * 0x100;
    }
    else if (uVar1 == 3) {
      local_70 = local_70 | (uint)*(byte *)((int)puVar7 + 2) << 0x10;
      goto LAB_00019828;
    }
    uVar6 = (uint)*(byte *)((int)puVar7 + (uVar1 - 1));
    if (uVar6 == 0) {
      return 0xffffffec;
    }
    uVar6 = LZCOUNT(uVar6) + uVar1 * -8 + 9;
    local_68 = puVar7;
  }
  else {
    local_70 = *(uint *)(param_4 + -4);
    uVar6 = (uint)*(byte *)((int)puVar7 + (uVar1 - 1));
    if (uVar6 == 0) {
      return 0xffffffec;
    }
    uVar6 = LZCOUNT(uVar6) - 0x17;
    local_68 = (uint *)(param_4 + -4);
    if (0xffffff88 < uVar1) {
      return 0xffffffec;
    }
  }
  uVar8 = (uint)**param_1;
  uVar1 = uVar6 + uVar8;
  local_5c = ((local_70 << (uVar6 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f);
  puVar10 = local_68;
  if (uVar1 < 0x21) {
    if (local_68 < local_60) {
      puVar10 = puVar7;
      if (local_68 == puVar7) goto LAB_00019904;
      uVar6 = uVar1 >> 3;
      if ((uint *)((int)local_68 - (uVar1 >> 3)) < puVar7) {
        uVar6 = (int)local_68 - (int)puVar7;
      }
      uVar8 = uVar1 + uVar6 * -8;
      local_70 = *(uint *)((int)local_68 - uVar6);
    }
    else {
      uVar8 = uVar1 & 7;
      uVar6 = uVar1 >> 3;
      local_70 = *(uint *)((int)local_68 - (uVar1 >> 3));
    }
    local_68 = (uint *)((int)local_68 - uVar6);
    puVar10 = local_68;
    uVar1 = uVar8;
  }
LAB_00019904:
  local_58 = *param_1 + 2;
  uVar8 = (uint)*param_1[2];
  uVar6 = uVar1 + uVar8;
  local_54 = ((local_70 << (uVar1 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f);
  puVar11 = puVar10;
  if (uVar6 < 0x21) {
    if (puVar10 < local_60) {
      puVar11 = puVar7;
      if (puVar10 == puVar7) goto LAB_0001999c;
      uVar1 = uVar6 >> 3;
      if ((uint *)((int)puVar10 - (uVar6 >> 3)) < puVar7) {
        uVar1 = (int)puVar10 - (int)puVar7;
      }
      uVar8 = uVar6 + uVar1 * -8;
      local_70 = *(uint *)((int)puVar10 - uVar1);
    }
    else {
      uVar8 = uVar6 & 7;
      uVar1 = uVar6 >> 3;
      local_70 = *(uint *)((int)puVar10 - (uVar6 >> 3));
    }
    local_68 = (uint *)((int)puVar10 - uVar1);
    uVar6 = uVar8;
    puVar11 = local_68;
  }
LAB_0001999c:
  local_50 = param_1[2] + 2;
  uVar1 = (uint)*param_1[1];
  local_6c = uVar6 + uVar1;
  local_4c = ((local_70 << (uVar6 & 0x1f)) >> 1) >> (0x1f - uVar1 & 0x1f);
  if (local_6c < 0x21) {
    if (puVar11 < local_60) {
      if (puVar11 == puVar7) goto LAB_00019a30;
      uVar1 = local_6c >> 3;
      if ((uint *)((int)puVar11 - (local_6c >> 3)) < puVar7) {
        uVar1 = (int)puVar11 - (int)puVar7;
      }
      uVar6 = local_6c + uVar1 * -8;
      local_70 = *(uint *)((int)puVar11 - uVar1);
    }
    else {
      uVar6 = local_6c & 7;
      uVar1 = local_6c >> 3;
      local_70 = *(uint *)((int)puVar11 - (local_6c >> 3));
    }
    local_68 = (uint *)((int)puVar11 - uVar1);
    local_6c = uVar6;
  }
LAB_00019a30:
  local_48 = param_1[1] + 2;
  if (0x20 < local_6c) {
    return 0xffffffec;
  }
  puVar22 = puVar13 + -8;
  local_64 = puVar7;
  if (local_68 < local_60) goto LAB_00019a78;
LAB_00019a68:
  local_68 = (uint *)((int)local_68 - (local_6c >> 3));
  local_6c = local_6c & 7;
  do {
    local_70 = *local_68;
    do {
      puVar21 = local_28;
      if (local_2c == 0) {
LAB_0001a210:
        param_1[0x1708] = local_44[0];
        param_1[0x1709] = local_44[1];
        param_1[0x170a] = local_44[2];
        puVar21 = local_28;
        goto LAB_0001a22c;
      }
      local_2c = local_2c + -1;
      uVar8 = (uint)*(byte *)(local_58 + local_5c * 2 + 1);
      uVar6 = (uint)*(byte *)(local_48 + local_4c * 2 + 1);
      iVar23 = *(int *)(DAT_0001a26c + 0x19b0c + uVar8 * 4);
      iVar12 = *(int *)(DAT_0001a270 + 0x19b1c + uVar6 * 4);
      uVar1 = (uint)*(byte *)(local_50 + local_54 * 2 + 1);
      if (uVar1 == 0) {
        puVar16 = (ushort *)0x0;
LAB_00019bf4:
        if (uVar8 == 0) {
          puVar16 = (ushort *)((int)puVar16 + 1);
        }
        if (puVar16 != (ushort *)0x0) {
          if (puVar16 == (ushort *)0x3) {
            puVar20 = (ushort *)((int)local_44[0] + -1);
            if ((ushort *)((int)local_44[0] + -1) == (ushort *)0x0) {
              puVar20 = local_44[0];
            }
LAB_00019c64:
            local_44[2] = local_44[1];
          }
          else {
            puVar20 = local_44[(int)puVar16];
            if (puVar20 == (ushort *)0x0) {
              puVar20 = (ushort *)0x1;
            }
            if (puVar16 != (ushort *)0x1) goto LAB_00019c64;
          }
          local_44[1] = local_44[0];
          local_44[0] = puVar20;
        }
      }
      else {
        uVar15 = local_6c & 0x1f;
        local_6c = local_6c + uVar1;
        uVar15 = local_70 << uVar15;
        if (local_6c < 0x21) {
          if (local_68 < local_60) {
            if (local_68 == local_64) goto LAB_00019bd8;
            uVar18 = local_6c >> 3;
            if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
              uVar18 = (int)local_68 - (int)local_64;
            }
            uVar14 = local_6c + uVar18 * -8;
            local_70 = *(uint *)((int)local_68 - uVar18);
          }
          else {
            uVar14 = local_6c & 7;
            uVar18 = local_6c >> 3;
            local_70 = *(uint *)((int)local_68 - (local_6c >> 3));
          }
          local_68 = (uint *)((int)local_68 - uVar18);
          local_6c = uVar14;
        }
LAB_00019bd8:
        puVar16 = (ushort *)
                  (*(int *)(DAT_0001a274 + 0x19b5c + uVar1 * 4) + (uVar15 >> (-uVar1 & 0x1f)));
        if (uVar1 < 2) goto LAB_00019bf4;
        local_44[2] = local_44[1];
        local_44[1] = local_44[0];
        local_44[0] = puVar16;
      }
      puVar16 = local_44[0];
      uVar1 = 0;
      if (0x1f < uVar6) {
        uVar1 = local_6c & 0x1f;
        local_6c = local_6c + iVar12;
        uVar1 = (local_70 << uVar1) >> (-iVar12 & 0x1fU);
      }
      if ((0x18 < (uint)(iVar12 + iVar23)) && (local_6c < 0x21)) {
        if (local_68 < local_60) {
          if (local_68 == local_64) goto LAB_00019d30;
          uVar15 = local_6c >> 3;
          if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
            uVar15 = (int)local_68 - (int)local_64;
          }
          uVar18 = local_6c + uVar15 * -8;
          local_70 = *(uint *)((int)local_68 - uVar15);
        }
        else {
          uVar18 = local_6c & 7;
          uVar15 = local_6c >> 3;
          local_70 = *(uint *)((int)local_68 - (local_6c >> 3));
        }
        local_68 = (uint *)((int)local_68 - uVar15);
        local_6c = uVar18;
      }
LAB_00019d30:
      uVar15 = 0;
      if (0xf < uVar8) {
        uVar15 = (local_70 << (local_6c & 0x1f)) >> (-iVar23 & 0x1fU);
        local_6c = local_6c + iVar23;
      }
      if (local_6c < 0x21) {
        if (local_68 < local_60) {
          if (local_68 == local_64) goto LAB_00019de8;
          uVar18 = local_6c >> 3;
          if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
            uVar18 = (int)local_68 - (int)local_64;
          }
          uVar14 = local_6c + uVar18 * -8;
          local_70 = *(uint *)((int)local_68 - uVar18);
        }
        else {
          uVar14 = local_6c & 7;
          uVar18 = local_6c >> 3;
          local_70 = *(uint *)((int)local_68 - (local_6c >> 3));
        }
        local_68 = (uint *)((int)local_68 - uVar18);
        local_6c = uVar14;
      }
LAB_00019de8:
      uVar15 = uVar15 + *(int *)(DAT_0001a27c + 0x19d80 + uVar8 * 4);
      uVar1 = uVar1 + *(int *)(DAT_0001a278 + 0x19d74 + uVar6 * 4);
      uVar6 = (uint)*(byte *)((int)(local_58 + local_5c * 2) + 3);
      uVar18 = local_6c + uVar6;
      local_5c = (uint)local_58[local_5c * 2] +
                 (((local_70 << (local_6c & 0x1f)) >> 1) >> (0x1f - uVar6 & 0x1f));
      uVar8 = (uint)*(byte *)((int)(local_48 + local_4c * 2) + 3);
      uVar6 = uVar18 + uVar8;
      local_4c = (uint)local_48[local_4c * 2] +
                 (((local_70 << (uVar18 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f));
      if (uVar6 < 0x21) {
        if (local_68 < local_60) {
          if (local_68 == local_64) goto LAB_00019ecc;
          uVar8 = uVar6 >> 3;
          if ((uint *)((int)local_68 - (uVar6 >> 3)) < local_64) {
            uVar8 = (int)local_68 - (int)local_64;
          }
          uVar18 = uVar6 + uVar8 * -8;
          local_70 = *(uint *)((int)local_68 - uVar8);
        }
        else {
          uVar18 = uVar6 & 7;
          uVar8 = uVar6 >> 3;
          local_70 = *(uint *)((int)local_68 - (uVar6 >> 3));
        }
        local_68 = (uint *)((int)local_68 - uVar8);
        uVar6 = uVar18;
      }
LAB_00019ecc:
      uVar8 = (uint)*(byte *)((int)(local_50 + local_54 * 2) + 3);
      local_6c = uVar6 + uVar8;
      local_54 = (uint)local_50[local_54 * 2] +
                 (((local_70 << (uVar6 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f));
      uVar6 = uVar15 + uVar1;
      puVar9 = (undefined *)(iVar24 + uVar6);
      if (puVar13 < puVar9) {
        return 0xffffffba;
      }
      puVar20 = (ushort *)((int)local_28 + uVar15);
      if (puVar5 < puVar20) {
        return 0xffffffec;
      }
      puVar17 = (undefined *)(iVar24 + uVar15);
      if (puVar22 < puVar17) {
        uVar6 = FUN_0001c4e4(iVar24,puVar13,uVar15,uVar1,local_44[0],local_44[0],&local_28,puVar5,
                             puVar2,puVar3,puVar4);
      }
      else {
        FUN_00036044(iVar24,local_28,8);
        if (8 < uVar15) {
          puVar19 = (undefined *)(iVar24 + 8);
          do {
            puVar21 = puVar21 + 4;
            FUN_00036044(puVar19,puVar21,8);
            puVar19 = puVar19 + 8;
          } while (puVar19 < puVar17);
        }
        puVar21 = (ushort *)(puVar17 + -(int)puVar16);
        local_28 = puVar20;
        if (puVar17 + -(int)puVar2 < puVar16) {
          if (puVar17 + -(int)puVar3 < puVar16) {
            return 0xffffffec;
          }
          iVar23 = (int)puVar21 - (int)puVar2;
          iVar12 = (int)puVar4 + iVar23;
          if (puVar4 < (ushort *)(iVar12 + uVar1)) {
            FUN_0003605c(puVar17,iVar12,-iVar23);
            puVar17 = puVar17 + -iVar23;
            uVar1 = iVar23 + uVar1;
            puVar21 = puVar2;
            if ((puVar17 <= puVar22) && (2 < uVar1)) {
              if (puVar16 < (ushort *)0x8) goto LAB_0001a084;
              goto LAB_0001a064;
            }
            for (; uVar1 != 0; uVar1 = uVar1 - 1) {
              *puVar17 = *(undefined *)puVar21;
              puVar21 = (ushort *)((int)puVar21 + 1);
              puVar17 = puVar17 + 1;
            }
          }
          else {
            FUN_0003605c(puVar17,iVar12,uVar1);
          }
        }
        else {
          if (puVar16 < (ushort *)0x8) {
LAB_0001a084:
            *puVar17 = *(undefined *)puVar21;
            puVar17[1] = *(undefined *)((int)puVar21 + 1);
            iVar12 = DAT_0001a280;
            puVar17[2] = *(undefined *)(puVar21 + 1);
            puVar17[3] = *(undefined *)((int)puVar21 + 3);
            puVar19 = (undefined *)((int)puVar21 + *(int *)(iVar12 + 0x1a0ac + (int)puVar16 * 4));
            FUN_00036044(puVar17 + 4,puVar19,4);
            puVar21 = (ushort *)(puVar19 + -*(int *)(DAT_0001a284 + 0x1a0d0 + (int)puVar16 * 4));
          }
          else {
LAB_0001a064:
            FUN_00036044(puVar17,puVar21,8);
          }
          puVar21 = puVar21 + 4;
          puVar19 = puVar17 + 8;
          if (puVar13 + -0xd < puVar9) {
            puVar17 = puVar19;
            puVar16 = puVar21;
            if (puVar19 < puVar22) {
              do {
                FUN_00036044(puVar17,puVar16,8);
                puVar17 = puVar17 + 8;
                puVar16 = puVar16 + 4;
              } while (puVar17 < puVar22);
              puVar21 = (ushort *)((int)puVar21 + ((int)puVar22 - (int)puVar19));
              puVar19 = puVar22;
            }
            for (; puVar19 < puVar9; puVar19 = puVar19 + 1) {
              *puVar19 = *(undefined *)puVar21;
              puVar21 = (ushort *)((int)puVar21 + 1);
            }
          }
          else {
            do {
              FUN_00036044(puVar19,puVar21,8);
              puVar19 = puVar19 + 8;
              puVar21 = puVar21 + 4;
            } while (puVar19 < puVar17 + uVar1);
          }
        }
      }
      if (0xffffff88 < uVar6) {
        return uVar6;
      }
      iVar24 = iVar24 + uVar6;
      if (0x20 < local_6c) {
        if (local_2c != 0) {
          return 0xffffffec;
        }
        goto LAB_0001a210;
      }
      if (local_60 <= local_68) goto LAB_00019a68;
LAB_00019a78:
    } while (local_68 == local_64);
    uVar1 = local_6c >> 3;
    if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
      uVar1 = (int)local_68 - (int)local_64;
    }
    local_68 = (uint *)((int)local_68 - uVar1);
    local_6c = local_6c + uVar1 * -8;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001a2c4 FUN_0001a2c4 */

uint FUN_0001a2c4(undefined4 param_1,uint param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  
  uVar1 = 0xffffffba;
  if (param_4 <= param_2) {
    FUN_00036050(param_1,param_3,param_4);
    uVar1 = param_4;
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001a2f4 FUN_0001a2f4 */

void FUN_0001a2f4(void)

{
  FUN_0001a328();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001a328 FUN_0001a328 */

uint FUN_0001a328(int **param_1,int *param_2,int param_3,uint *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,int param_8)

{
  byte bVar1;
  ushort uVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  undefined *puVar9;
  uint uVar10;
  undefined8 uVar11;
  int local_48;
  int *local_28;
  
  if (param_8 != 0) {
    param_6 = *(undefined4 *)(param_8 + 4);
    param_7 = *(undefined4 *)(param_8 + 8);
  }
  local_28 = param_2;
  if (4 < param_5) {
    piVar3 = (int *)(param_1 + 0x171c);
    local_48 = param_3;
    do {
      uVar4 = *param_4;
      if (uVar4 == 0xfd2fb528) {
        if (param_8 == 0) {
          uVar4 = FUN_0001ae5c(param_1,param_6,param_7);
          if (0xffffff88 < uVar4) {
            return uVar4;
          }
          piVar5 = param_1[0x170b];
        }
        else {
          param_1[0x170b] = (int *)0x0;
          param_1[0x170c] = (int *)0x0;
          param_1[0x170d] = (int *)0x0;
          param_1[0x170e] = (int *)0x0;
          param_1[0x170f] = (int *)0x5;
          param_1[0x507] = (int *)0xc00000c;
          param_1[0x1733] = (int *)0x0;
          param_1[0x1719] = (int *)0x0;
          param_1[0x171a] = (int *)0x0;
          param_1[0x171b] = (int *)0x0;
          FUN_00036044(param_1 + 0x1708,DAT_0001a890 + 0x1a470,0xc);
          *param_1 = (int *)(param_1 + 4);
          param_1[1] = (int *)(param_1 + 0x306);
          param_1[2] = (int *)(param_1 + 0x205);
          param_1[3] = (int *)(param_1 + 0x507);
          param_1[0x1733] = *(int **)(param_8 + 0x5c28);
          piVar5 = *(int **)(param_8 + 4);
          param_1[0x170c] = piVar5;
          param_1[0x170d] = piVar5;
          piVar5 = (int *)((int)piVar5 + *(int *)(param_8 + 8));
          param_1[0x170e] = piVar5;
          param_1[0x170b] = piVar5;
          if (*(int *)(param_8 + 0x5c2c) == 0) {
            param_1[0x171a] = (int *)0x0;
            param_1[0x171b] = (int *)0x0;
          }
          else {
            param_1[0x171a] = (int *)0x1;
            param_1[0x171b] = (int *)0x1;
            *param_1 = (int *)(param_8 + 0xc);
            param_1[1] = (int *)(param_8 + 0xc14);
            param_1[2] = (int *)(param_8 + 0x810);
            param_1[3] = (int *)(param_8 + 0x1418);
            param_1[0x1708] = (int *)*(int *)(param_8 + 0x5c1c);
            param_1[0x1709] = *(int **)(param_8 + 0x5c20);
            param_1[0x170a] = *(int **)(param_8 + 0x5c24);
          }
        }
        if (piVar5 != local_28) {
          param_1[0x170e] = piVar5;
          piVar7 = param_1[0x170c];
          param_1[0x170b] = local_28;
          param_1[0x170c] = local_28;
          param_1[0x170d] = (int *)((int)local_28 + ((int)piVar7 - (int)piVar5));
        }
        if (param_5 < 9) {
          return 0xffffffb8;
        }
        bVar1 = *(byte *)(param_4 + 1);
        iVar8 = 6;
        if ((bVar1 & 0x20) != 0) {
          iVar8 = 5;
        }
        uVar4 = *(int *)(DAT_0001a898 + 0x1a5e4 + (uint)(bVar1 >> 6) * 4) +
                *(int *)(DAT_0001a894 + 0x1a5d0 + (bVar1 & 3) * 4) + iVar8 +
                ((uint)(bVar1 >> 6 == 0) & (bVar1 & 0x20) >> 5);
        if (0xffffff88 < uVar4) {
          return uVar4;
        }
        if (param_5 < uVar4 + 3) {
          return 0xffffffb8;
        }
        uVar11 = FUN_00018948(param_1 + 0x1710,param_4,uVar4);
        piVar5 = (int *)((ulonglong)uVar11 >> 0x20);
        uVar10 = (uint)uVar11;
        if (0xffffff88 < uVar10) {
          return uVar10;
        }
        if (uVar10 != 0) {
          return 0xffffffb8;
        }
        piVar7 = param_1[0x1716];
        if (piVar7 != (int *)0x0) {
          piVar5 = param_1[0x1733];
        }
        if (piVar7 != (int *)0x0 && piVar5 != piVar7) {
          return 0xffffffe0;
        }
        if (param_1[0x1717] != (int *)0x0) {
          FUN_000235a0(piVar3,piVar5,0,0);
        }
        param_5 = param_5 - uVar4;
        param_4 = (uint *)((int)param_4 + uVar4);
        piVar5 = local_28;
        if (param_5 < 3) {
          return 0xffffffb8;
        }
        while( true ) {
          uVar2 = *(ushort *)param_4;
          uVar4 = (uint)(*(uint3 *)param_4 >> 3);
          uVar6 = ((uint)uVar2 << 0x1d) >> 0x1e;
          uVar10 = uVar6;
          if ((uVar6 != 1) && (uVar10 = uVar4, uVar6 == 3)) {
            return 0xffffffec;
          }
          if (param_5 - 3 < uVar10) {
            return 0xffffffb8;
          }
          puVar9 = (undefined *)((int)param_4 + 3);
          if (uVar6 == 2) {
            uVar4 = FUN_0001967c(param_1,piVar5,(int)local_28 + (local_48 - (int)piVar5),puVar9,
                                 uVar10);
            if (0xffffff88 < uVar4) {
              return uVar4;
            }
          }
          else if (uVar6 == 1) {
            if ((uint)((int)local_28 + (local_48 - (int)piVar5)) < uVar4) {
              return 0xffffffba;
            }
            FUN_00036050(piVar5,*puVar9,uVar4);
          }
          else {
            if (uVar6 != 0) {
              return 0xffffffec;
            }
            if ((uint)((int)local_28 + (local_48 - (int)piVar5)) < uVar10) {
              return 0xffffffba;
            }
            FUN_00036044(piVar5,puVar9,uVar10);
            uVar4 = uVar10;
          }
          if (param_1[0x1717] != (int *)0x0) {
            FUN_000238ec(piVar3,piVar5,uVar4);
          }
          param_5 = (param_5 - 3) - uVar10;
          param_4 = (uint *)(puVar9 + uVar10);
          piVar5 = (int *)((int)piVar5 + uVar4);
          if ((uVar2 & 1) != 0) break;
          if (param_5 < 3) {
            return 0xffffffb8;
          }
        }
        if (param_1[0x1717] != (int *)0x0) {
          uVar4 = FUN_00023dc8(piVar3);
          if (param_5 < 4) {
            return 0xffffffea;
          }
          if (*param_4 != uVar4) {
            return 0xffffffea;
          }
          param_5 = param_5 - 4;
          param_4 = param_4 + 1;
        }
        uVar4 = (int)piVar5 - (int)local_28;
        if (0xffffff88 < uVar4) {
          return uVar4;
        }
        local_48 = local_48 - uVar4;
        local_28 = piVar5;
      }
      else {
        if (uVar4 >> 4 != 0x184d2a5) {
          return 0xfffffff6;
        }
        if (7 < param_5) {
          uVar4 = param_4[1] + 8;
        }
        if (7 >= param_5 || param_5 < uVar4) {
          return 0xffffffb8;
        }
        param_5 = param_5 - uVar4;
        param_4 = (uint *)((int)param_4 + uVar4);
      }
    } while (4 < param_5);
  }
  uVar4 = 0xffffffb8;
  if (param_5 == 0) {
    uVar4 = (int)local_28 - (int)param_2;
  }
  return uVar4;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001a89c FUN_0001a89c */

void FUN_0001a89c(void)

{
  FUN_0001a328();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001a8c8 FUN_0001a8c8 */

void FUN_0001a8c8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  code *UNRECOVERED_JUMPTABLE_00;
  
  piVar2 = (int *)FUN_000243e8(0x25d50,0,0,0);
  iVar1 = DAT_0001aa10;
  if (piVar2 != (int *)0x0) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = 0;
    piVar2[0x1736] = 0;
    piVar2[0x1737] = 0;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    FUN_00036044(piVar2 + 0x1708,iVar1 + 0x1a93c,0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    uVar3 = FUN_0001a328(piVar2,param_1,param_2,param_3,param_4,0,0,0);
    FUN_00018778(piVar2);
                    /* WARNING: Could not recover jumptable at 0x0001aa00. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(uVar3);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001aa0c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(0xffffffc0);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001aa4c FUN_0001aa4c */

uint FUN_0001aa4c(int param_1,int param_2,uint param_3,uint *param_4,uint param_5)

{
  byte bVar1;
  ushort uVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  bool bVar9;
  
  if (*(uint *)(param_1 + 0x5c3c) != param_5) {
    return 0xffffffb8;
  }
  iVar5 = 0x5c2c;
  piVar8 = (int *)(param_1 + 0x5c2c);
  if (param_3 != 0) {
    iVar5 = *piVar8;
  }
  if (param_3 != 0 && iVar5 != param_2) {
    *(int *)(param_1 + 0x5c38) = iVar5;
    iVar6 = *(int *)(param_1 + 0x5c30);
    *piVar8 = param_2;
    *(int *)(param_1 + 0x5c30) = param_2;
    *(int *)(param_1 + 0x5c34) = param_2 + (iVar6 - iVar5);
  }
  switch(*(undefined4 *)(param_1 + 0x5c64)) {
  case 0:
    if (param_5 != 5) {
      return 0xffffffb8;
    }
    if (*param_4 >> 4 != 0x184d2a5) {
      bVar1 = *(byte *)(param_4 + 1);
      iVar5 = 6;
      if ((bVar1 & 0x20) != 0) {
        iVar5 = 5;
      }
      uVar3 = *(int *)(DAT_0001ae58 + 0x1ad18 + (uint)(bVar1 >> 6) * 4) +
              *(int *)(DAT_0001ae54 + 0x1ad10 + (bVar1 & 3) * 4) + iVar5 +
              ((uint)(bVar1 >> 6 == 0) & (bVar1 & 0x20) >> 5);
      *(uint *)(param_1 + 0x5cc8) = uVar3;
      if (0xffffff88 < uVar3) {
        return uVar3;
      }
      FUN_00036044(param_1 + 0x25d38,param_4,5);
      if (5 < *(uint *)(param_1 + 0x5cc8)) {
        iVar5 = *(uint *)(param_1 + 0x5cc8) - 5;
        *(undefined4 *)(param_1 + 0x5c64) = 1;
        goto LAB_0001ae44;
      }
      param_5 = 0;
      *(undefined4 *)(param_1 + 0x5c3c) = 0;
      goto switchD_0001aacc_caseD_1;
    }
    FUN_00036044(param_1 + 0x25d38,param_4,5);
    uVar4 = 6;
    goto LAB_0001ae3c;
  case 1:
switchD_0001aacc_caseD_1:
    FUN_00036044(param_1 + 0x25d3d,param_4,param_5);
    iVar5 = *(int *)(param_1 + 0x5cc8);
    uVar3 = FUN_00018948(param_1 + 0x5c40,param_1 + 0x25d38);
    if ((0xffffff88 < uVar3) || (bVar9 = uVar3 != 0, uVar3 = 0xffffffb8, bVar9)) {
      return uVar3;
    }
    iVar6 = *(int *)(param_1 + 0x5c58);
    if (iVar6 != 0) {
      iVar5 = *(int *)(param_1 + 0x5ccc);
      uVar3 = 0xffffffe0;
    }
    if (iVar6 != 0 && iVar5 != iVar6) {
      return uVar3;
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      FUN_000235a0(param_1 + 0x5c70,iVar6,0,0);
    }
    break;
  case 2:
    uVar2 = *(ushort *)param_4;
    uVar7 = ((uint)uVar2 << 0x1d) >> 0x1e;
    uVar3 = uVar7;
    if ((uVar7 != 1) && (uVar3 = (uint)(*(uint3 *)param_4 >> 3), uVar7 == 3)) {
      return 0xffffffec;
    }
    *(uint *)(param_1 + 0x5ce4) = (uint)(*(uint3 *)param_4 >> 3);
    *(uint *)(param_1 + 0x5c60) = uVar7;
    *(uint *)(param_1 + 0x5c3c) = uVar3;
    if (uVar3 != 0) {
      uVar4 = 3;
      if ((uVar2 & 1) != 0) {
        uVar4 = 4;
      }
      *(undefined4 *)(param_1 + 0x5c64) = uVar4;
      return 0;
    }
    if ((uVar2 & 1) != 0) {
      if (*(int *)(param_1 + 0x5c5c) != 0) {
        *(undefined4 *)(param_1 + 0x5c64) = 5;
        iVar5 = 4;
        goto LAB_0001ae44;
      }
      goto switchD_0001aacc_caseD_7;
    }
    break;
  case 3:
  case 4:
    iVar5 = *(int *)(param_1 + 0x5c60);
    if (iVar5 == 0) {
      if (param_3 < param_5) {
        return 0xffffffba;
      }
      FUN_00036044(param_2,param_4,param_5);
      if (0xffffff88 < param_5) {
        return param_5;
      }
    }
    else {
      if (iVar5 == 1) {
        if (param_5 != 1) {
          return 0xffffffb8;
        }
        param_5 = *(uint *)(param_1 + 0x5ce4);
        if (param_3 < param_5) {
          return 0xffffffba;
        }
        FUN_00036050(param_2,*(undefined *)param_4,param_5);
      }
      else {
        if (iVar5 != 2) {
          return 0xffffffec;
        }
        param_5 = FUN_0001967c(param_1,param_2,param_3,param_4,param_5);
      }
      if (0xffffff88 < param_5) {
        return param_5;
      }
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      FUN_000238ec(param_1 + 0x5c70,param_2,param_5);
    }
    if (*(int *)(param_1 + 0x5c64) == 4) {
      if (*(int *)(param_1 + 0x5c5c) == 0) {
        uVar4 = 0;
        *(undefined4 *)(param_1 + 0x5c64) = 0;
      }
      else {
        *(undefined4 *)(param_1 + 0x5c64) = 5;
        uVar4 = 4;
      }
      *(undefined4 *)(param_1 + 0x5c3c) = uVar4;
    }
    else {
      *(undefined4 *)(param_1 + 0x5c3c) = 3;
      *(undefined4 *)(param_1 + 0x5c64) = 2;
      *piVar8 = param_2 + param_5;
    }
    return param_5;
  case 5:
    uVar3 = FUN_00023dc8(param_1 + 0x5c70);
    if (*param_4 != uVar3) {
      return 0xffffffea;
    }
  case 7:
switchD_0001aacc_caseD_7:
    *(undefined4 *)(param_1 + 0x5c64) = 0;
    *(undefined4 *)(param_1 + 0x5c3c) = 0;
    return 0;
  case 6:
    FUN_00036044(param_1 + 0x25d3d,param_4,param_5);
    *(undefined4 *)(param_1 + 0x5c3c) = *(undefined4 *)(param_1 + 0x25d3c);
    *(undefined4 *)(param_1 + 0x5c64) = 7;
    return 0;
  default:
    return 0xffffffff;
  }
  uVar4 = 2;
LAB_0001ae3c:
  *(undefined4 *)(param_1 + 0x5c64) = uVar4;
  iVar5 = 3;
LAB_0001ae44:
  *(int *)(param_1 + 0x5c3c) = iVar5;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001ae5c FUN_0001ae5c */

undefined4 FUN_0001ae5c(int *param_1,int *param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar2 = DAT_0001af98;
  piVar4 = param_1 + 0x170b;
  *piVar4 = 0;
  param_1[0x170c] = 0;
  param_1[0x170d] = 0;
  param_1[0x170e] = 0;
  param_1[0x170f] = 5;
  param_1[0x1733] = 0;
  param_1[0x1719] = 0;
  param_1[0x171a] = 0;
  param_1[0x171b] = 0;
  param_1[0x507] = 0xc00000c;
  FUN_00036044(param_1 + 0x1708,iVar2 + 0x1aea8,0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  if (param_2 != (int *)0x0 && param_3 != 0) {
    if ((param_3 < 8) || (*param_2 != -0x13cf5bc9)) {
      iVar2 = *piVar4;
      iVar3 = param_1[0x170c];
      *piVar4 = (int)param_2 + param_3;
      param_1[0x170c] = (int)param_2;
      param_1[0x170d] = (int)param_2 + (iVar3 - iVar2);
      param_1[0x170e] = iVar2;
    }
    else {
      param_1[0x1733] = param_2[1];
      uVar1 = FUN_0001c660(param_1 + 4,param_2,param_3);
      if (0xffffff88 < uVar1) {
        return 0xffffffe2;
      }
      iVar2 = *piVar4;
      iVar3 = param_1[0x170c];
      param_1[0x171a] = 1;
      param_1[0x171b] = 1;
      *piVar4 = (int)param_2 + param_3;
      param_1[0x170c] = (int)param_2 + uVar1;
      param_1[0x170d] = (int)param_2 + uVar1 + (iVar3 - iVar2);
      param_1[0x170e] = iVar2;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001af9c FUN_0001af9c */

undefined4 FUN_0001af9c(int *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = DAT_0001b0f8;
  param_1[0x1719] = 0;
  param_1[0x170f] = 5;
  param_1[0x170e] = 0;
  param_1[0x170d] = 0;
  param_1[0x170c] = 0;
  param_1[0x170b] = 0;
  param_1[0x171b] = 0;
  param_1[0x1733] = 0;
  param_1[0x171a] = 0;
  param_1[0x507] = 0xc00000c;
  FUN_00036044(param_1 + 0x1708,iVar1 + 0x1afd8,0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  if (param_2 != 0) {
    param_1[0x1733] = *(int *)(param_2 + 0x5c28);
    iVar1 = *(int *)(param_2 + 4);
    param_1[0x170d] = iVar1;
    param_1[0x170c] = iVar1;
    iVar1 = iVar1 + *(int *)(param_2 + 8);
    param_1[0x170b] = iVar1;
    param_1[0x170e] = iVar1;
    if (*(int *)(param_2 + 0x5c2c) != 0) {
      param_1[0x171a] = 1;
      param_1[0x171b] = 1;
      *param_1 = param_2 + 0xc;
      param_1[1] = param_2 + 0xc14;
      param_1[2] = param_2 + 0x810;
      param_1[3] = param_2 + 0x1418;
      param_1[0x1708] = *(int *)(param_2 + 0x5c1c);
      param_1[0x1709] = *(int *)(param_2 + 0x5c20);
      param_1[0x170a] = *(int *)(param_2 + 0x5c24);
      return 0;
    }
    param_1[0x171a] = 0;
    param_1[0x171b] = 0;
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b0fc FUN_0001b0fc */

undefined4 *
FUN_0001b0fc(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5,
            undefined4 param_6)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (((param_4 == 0) == (param_5 == 0)) &&
     (puVar1 = (undefined4 *)FUN_000243e8(0x5c3c,param_4,param_5,param_6),
     puVar1 != (undefined4 *)0x0)) {
    puVar1[0x170c] = param_4;
    puVar1[0x170d] = param_5;
    puVar1[0x170e] = param_6;
    uVar2 = FUN_0001b1c4(puVar1,param_1,param_2,param_3);
    if (uVar2 < 0xffffff89) {
      return puVar1;
    }
    iVar3 = puVar1[0x170c];
    uVar4 = puVar1[0x170d];
    uVar5 = puVar1[0x170e];
    FUN_00024454(*puVar1,iVar3,uVar4,uVar5);
    FUN_00024454(puVar1,iVar3,uVar4,uVar5);
  }
  return (undefined4 *)0x0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b1c4 FUN_0001b1c4 */

undefined4 FUN_0001b1c4(int *param_1,int param_2,uint param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int *piVar4;
  
  if ((param_3 == 0 || param_2 == 0) || (param_4 != 0)) {
    *param_1 = 0;
    param_1[1] = param_2;
  }
  else {
    iVar1 = FUN_000243e8(param_3,param_1[0x170c],param_1[0x170d],param_1[0x170e]);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    if (iVar1 == 0) {
      return 0xffffffc0;
    }
    FUN_00036044(iVar1,param_2,param_3);
  }
  param_1[2] = param_3;
  param_1[0x506] = 0xc00000c;
  uVar2 = 0;
  param_1[0x170a] = 0;
  param_1[0x170b] = 0;
  if ((7 < param_3) && (piVar4 = (int *)param_1[1], *piVar4 == -0x13cf5bc9)) {
    param_1[0x170a] = piVar4[1];
    uVar3 = FUN_0001c660(param_1 + 3,piVar4,param_3);
    uVar2 = 0xffffffe2;
    if (uVar3 < 0xffffff89) {
      param_1[0x170b] = 1;
      uVar2 = 0;
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b2ac FUN_0001b2ac */

undefined4 * FUN_0001b2ac(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  
  puVar1 = (undefined4 *)FUN_000243e8(0x5c3c,0,0,0);
  puVar5 = (undefined4 *)0x0;
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[0x170c] = 0;
    puVar1[0x170d] = 0;
    puVar1[0x170e] = 0;
    uVar2 = FUN_0001b1c4(puVar1,param_1,param_2,0);
    puVar5 = puVar1;
    if (0xffffff88 < uVar2) {
      uVar3 = puVar1[0x170d];
      uVar4 = puVar1[0x170e];
      uVar6 = puVar1[0x170c];
      FUN_00024454(*puVar1,uVar6,uVar3,uVar4);
      FUN_00024454(puVar1,uVar6,uVar3,uVar4);
      puVar5 = (undefined4 *)0x0;
    }
  }
  return puVar5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b354 FUN_0001b354 */

undefined4 * FUN_0001b354(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  
  puVar1 = (undefined4 *)FUN_000243e8(0x5c3c,0,0,0);
  puVar5 = (undefined4 *)0x0;
  if (puVar1 != (undefined4 *)0x0) {
    *puVar1 = 0;
    puVar1[1] = param_1;
    puVar1[2] = param_2;
    puVar1[0x506] = 0xc00000c;
    puVar1[0x170a] = 0;
    puVar1[0x170b] = 0;
    puVar1[0x170c] = 0;
    puVar1[0x170d] = 0;
    puVar1[0x170e] = 0;
    puVar5 = puVar1;
    if ((7 < param_2) && (*param_1 == -0x13cf5bc9)) {
      puVar1[0x170a] = param_1[1];
      uVar2 = FUN_0001c660(puVar1 + 3,param_1,param_2);
      if (uVar2 < 0xffffff89) {
        puVar1[0x170b] = 1;
        return puVar1;
      }
      uVar3 = puVar1[0x170c];
      uVar6 = puVar1[0x170d];
      uVar4 = puVar1[0x170e];
      FUN_00024454(*puVar1,uVar3,uVar6,uVar4);
      FUN_00024454(puVar1,uVar3,uVar6,uVar4);
      puVar5 = (undefined4 *)0x0;
    }
  }
  return puVar5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b458 FUN_0001b458 */

undefined4 * FUN_0001b458(undefined4 *param_1,uint param_2,int *param_3,uint param_4,int param_5)

{
  undefined4 *puVar1;
  uint uVar2;
  
  puVar1 = (undefined4 *)0x0;
  if (((uint)param_1 & 7) == 0) {
    uVar2 = param_4 + 0x5c3c;
    if (param_5 != 0) {
      uVar2 = 0x5c3c;
    }
    if (uVar2 <= param_2) {
      if (param_5 == 0) {
        FUN_00036044(param_1 + 0x170f,param_3,param_4);
        param_3 = param_1 + 0x170f;
      }
      *param_1 = 0;
      param_1[1] = param_3;
      param_1[2] = param_4;
      param_1[0x506] = 0xc00000c;
      param_1[0x170a] = 0;
      param_1[0x170b] = 0;
      puVar1 = param_1;
      if ((7 < param_4) && (*param_3 == -0x13cf5bc9)) {
        param_1[0x170a] = param_3[1];
        uVar2 = FUN_0001c660(param_1 + 3,param_3,param_4);
        puVar1 = (undefined4 *)(uint)(uVar2 < 0xffffff89);
        if (uVar2 < 0xffffff89) {
          param_1[0x170b] = (undefined4 *)(uint)(uVar2 < 0xffffff89);
          puVar1 = param_1;
        }
      }
    }
  }
  return puVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b5b4 FUN_0001b5b4 */

undefined4 FUN_0001b5b4(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_14 = 0;
  local_18 = 0;
  local_1c = 0;
  local_20 = 0;
  local_24 = 0;
  local_28 = 0;
  local_2c = 0;
  local_30 = 0;
  uVar1 = FUN_00018948(&local_30,param_1,param_2);
  if (0xffffff88 < uVar1) {
    local_18 = 0;
  }
  return local_18;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b60c FUN_0001b60c */

void FUN_0001b60c(void)

{
  FUN_0001a328();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b640 FUN_0001b640 */

int * FUN_0001b640(void)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)FUN_000243e8(0x25d50,0,0,0);
  iVar1 = DAT_0001b738;
  piVar3 = (int *)0x0;
  if (piVar2 != (int *)0x0) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = 0;
    piVar2[0x1736] = 0;
    piVar2[0x1737] = 0;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    FUN_00036044(piVar2 + 0x1708,iVar1 + 0x1b6a0,0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    piVar3 = piVar2;
  }
  return piVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b83c FUN_0001b83c */

undefined4 FUN_0001b83c(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  piVar2 = (int *)(param_1 + 0x5cec);
  puVar4 = (undefined4 *)*piVar2;
  puVar3 = (undefined4 *)0x0;
  *(undefined4 *)(param_1 + 0x5cf4) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d14) = 0;
  *(undefined4 *)(param_1 + 0x5d1c) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  if (puVar4 != (undefined4 *)0x0) {
    uVar5 = puVar4[0x170c];
    uVar7 = puVar4[0x170d];
    uVar6 = puVar4[0x170e];
    FUN_00024454(*puVar4,uVar5,uVar7,uVar6);
    FUN_00024454(puVar4,uVar5,uVar7,uVar6);
  }
  if ((param_2 != 0) && (7 < param_3)) {
    puVar3 = (undefined4 *)FUN_000243e8(0x5c3c,0,0,0);
    if (puVar3 != (undefined4 *)0x0) {
      puVar3[0x170c] = 0;
      puVar3[0x170d] = 0;
      puVar3[0x170e] = 0;
      uVar1 = FUN_0001b1c4(puVar3,param_2,param_3,0);
      if (uVar1 < 0xffffff89) goto LAB_0001b924;
      uVar5 = puVar3[0x170d];
      uVar6 = puVar3[0x170e];
      uVar7 = puVar3[0x170c];
      FUN_00024454(*puVar3,uVar7,uVar5,uVar6);
      FUN_00024454(puVar3,uVar7,uVar5,uVar6);
    }
    *piVar2 = 0;
    return 0xffffffc0;
  }
LAB_0001b924:
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  *(undefined4 *)(param_1 + 0x5d2c) = 0;
  *piVar2 = (int)puVar3;
  *(undefined4 **)(param_1 + 0x5cf0) = puVar3;
  return 5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001b984 FUN_0001b984 */

undefined4 FUN_0001b984(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(undefined4 *)(param_1 + 0x5cec);
  *(undefined4 *)(param_1 + 0x5cf4) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d14) = 0;
  *(undefined4 *)(param_1 + 0x5d1c) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = puVar1[0x170d];
    uVar3 = puVar1[0x170e];
    uVar4 = puVar1[0x170c];
    FUN_00024454(*puVar1,uVar4,uVar2,uVar3);
    FUN_00024454(puVar1,uVar4,uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  *(undefined4 *)(param_1 + 0x5d2c) = 0;
  *(undefined4 *)(param_1 + 0x5cec) = 0;
  *(undefined4 *)(param_1 + 0x5cf0) = 0;
  return 5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001ba0c FUN_0001ba0c */

undefined4 FUN_0001ba0c(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(undefined4 *)(param_1 + 0x5cec);
  *(undefined4 *)(param_1 + 0x5cf4) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d14) = 0;
  *(undefined4 *)(param_1 + 0x5d1c) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = puVar1[0x170c];
    uVar4 = puVar1[0x170d];
    uVar3 = puVar1[0x170e];
    FUN_00024454(*puVar1,uVar2,uVar4,uVar3);
    FUN_00024454(puVar1,uVar2,uVar4,uVar3);
  }
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  *(undefined4 *)(param_1 + 0x5d2c) = 0;
  *(undefined4 *)(param_1 + 0x5cec) = 0;
  *(undefined4 *)(param_1 + 0x5cf0) = param_2;
  return 5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001bb70 FUN_0001bb70 */

uint FUN_0001bb70(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_28 [8];
  uint local_20;
  int local_1c;
  
  uVar1 = FUN_00018948(auStack_28,param_1,param_2);
  uVar2 = uVar1;
  if ((uVar1 < 0xffffff89) && (uVar2 = 0xffffffb8, uVar1 == 0)) {
    uVar2 = 0xfffffff0;
    if ((uint)-local_1c < (uint)(local_20 < 0x8000001)) {
      uVar2 = local_20;
      if (0x1ffff < local_20) {
        uVar2 = 0x20000;
      }
      uVar2 = local_20 + uVar2 * 2 + 0x25d60;
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001bbdc FUN_0001bbdc */

uint FUN_0001bbdc(int *param_1,int *param_2,int *param_3)

{
  ushort uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  ushort *puVar6;
  int iVar7;
  int iVar8;
  uint *puVar9;
  uint *puVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  uint *puVar17;
  uint *puVar18;
  uint *puVar19;
  uint *puVar20;
  uint uVar21;
  bool bVar22;
  undefined8 uVar23;
  int local_70;
  undefined auStack_48 [20];
  int local_34;
  int local_2c;
  
  puVar9 = (uint *)(param_1 + 0x1710);
  puVar20 = (uint *)(param_1 + 0x1712);
  puVar10 = (uint *)(param_1 + 0x974e);
  iVar2 = *param_2;
  iVar16 = param_2[1];
  iVar11 = iVar2 + param_2[2];
  puVar17 = (uint *)(*param_3 + param_3[2]);
  puVar3 = (uint *)(*param_3 + param_3[1]);
  uVar4 = (int)puVar3 - (int)puVar17;
  local_70 = iVar11;
  puVar18 = puVar17;
LAB_0001bc9c:
  uVar5 = (iVar2 + iVar16) - local_70;
  puVar19 = puVar18;
LAB_0001bca8:
  puVar18 = puVar19;
  switch(param_1[0x173d]) {
  case 0:
    iVar7 = 0;
    param_1[0x173d] = 1;
    param_1[0x1744] = 0;
    param_1[0x1745] = 0;
    param_1[0x174a] = 0;
    param_1[0x174b] = 0;
    param_1[0x1747] = 0;
    param_1[0x1740] = 0;
    break;
  case 1:
    iVar7 = param_1[0x1747];
    break;
  case 2:
    goto switchD_0001bcbc_caseD_2;
  case 3:
    uVar13 = param_1[0x170f];
    goto LAB_0001c084;
  case 4:
    goto switchD_0001bcbc_caseD_4;
  default:
    return 0xffffffff;
  }
  uVar13 = FUN_00018948(puVar9,puVar10,iVar7);
  if (0xffffff88 < uVar13) {
    return uVar13;
  }
  if (uVar13 == 0) {
    bVar22 = (*puVar9 | param_1[0x1711]) == 0;
    if (!bVar22) {
      bVar22 = (*puVar20 | param_1[0x1713]) == 0;
    }
    if ((!bVar22) && ((uint)-param_1[0x1711] < (uint)(*puVar9 <= uVar5))) {
      if ((uVar4 < 8) || ((*puVar17 & 0xfffffff0) != 0x184d2a50)) {
        uVar13 = FUN_00018948(auStack_48,puVar17,uVar4);
        if (uVar13 < 0xffffff89) {
          if (uVar13 == 0) {
            uVar12 = uVar4 - local_34;
            puVar6 = (ushort *)((int)puVar17 + local_34);
            do {
              if (uVar12 < 3) {
LAB_0001c25c:
                uVar13 = 0xffffffb8;
                if (uVar4 < 0xffffffb8) goto LAB_0001bd94;
                goto LAB_0001c478;
              }
              uVar1 = *puVar6;
              uVar13 = ((uint)uVar1 << 0x1d) >> 0x1e;
              if (uVar13 != 1) {
                if (uVar13 == 3) {
                  uVar13 = 0xffffffec;
                  if (uVar4 < 0xffffffec) goto LAB_0001bd94;
                  goto LAB_0001c478;
                }
                uVar13 = (uint)(uint3)(CONCAT12(*(undefined *)(puVar6 + 1),uVar1) >> 3);
              }
              uVar13 = uVar13 + 3;
              if (uVar12 < uVar13) goto LAB_0001c25c;
              uVar12 = uVar12 - uVar13;
              puVar6 = (ushort *)((int)puVar6 + uVar13);
            } while ((uVar1 & 1) == 0);
            if (local_2c != 0) {
              uVar13 = 0xffffffb8;
              if (uVar12 < 4) goto joined_r0x0001c254;
              puVar6 = puVar6 + 2;
            }
            uVar13 = (int)puVar6 - (int)puVar17;
          }
          else {
            uVar13 = 0xffffffb8;
          }
        }
      }
      else {
        uVar13 = puVar17[1] + 8;
      }
joined_r0x0001c254:
      if (uVar13 <= uVar4) {
LAB_0001c478:
        uVar4 = FUN_0001a328(param_1,local_70,uVar5,puVar17,uVar13,0,0,param_1[0x173c]);
        if (0xffffff88 < uVar4) {
          return uVar4;
        }
        param_1[0x170f] = 0;
        local_70 = local_70 + uVar4;
        param_1[0x173d] = 0;
        puVar18 = (uint *)((int)puVar17 + uVar13);
        goto LAB_0001c394;
      }
    }
LAB_0001bd94:
    iVar7 = param_1[0x173c];
    param_1[0x170b] = 0;
    param_1[0x170c] = 0;
    param_1[0x170d] = 0;
    param_1[0x170e] = 0;
    param_1[0x170f] = 5;
    param_1[0x507] = 0xc00000c;
    param_1[0x1733] = 0;
    param_1[0x1719] = 0;
    param_1[0x171a] = 0;
    param_1[0x171b] = 0;
    FUN_00036044(param_1 + 0x1708,DAT_0001c4e0 + 0x1bde8,0xc);
    *param_1 = (int)(param_1 + 4);
    param_1[1] = (int)(param_1 + 0x306);
    param_1[2] = (int)(param_1 + 0x205);
    param_1[3] = (int)(param_1 + 0x507);
    if (iVar7 != 0) {
      param_1[0x1733] = *(int *)(iVar7 + 0x5c28);
      iVar8 = *(int *)(iVar7 + 4);
      param_1[0x170d] = iVar8;
      param_1[0x170c] = iVar8;
      iVar8 = iVar8 + *(int *)(iVar7 + 8);
      param_1[0x170b] = iVar8;
      param_1[0x170e] = iVar8;
      if (*(int *)(iVar7 + 0x5c2c) == 0) {
        param_1[0x171a] = 0;
        param_1[0x171b] = 0;
      }
      else {
        param_1[0x171a] = 1;
        param_1[0x171b] = 1;
        *param_1 = iVar7 + 0xc;
        param_1[1] = iVar7 + 0xc14;
        param_1[2] = iVar7 + 0x810;
        param_1[3] = iVar7 + 0x1418;
        param_1[0x1708] = *(int *)(iVar7 + 0x5c1c);
        param_1[0x1709] = *(int *)(iVar7 + 0x5c20);
        param_1[0x170a] = *(int *)(iVar7 + 0x5c24);
      }
    }
    if ((*puVar10 & 0xfffffff0) == 0x184d2a50) {
      iVar14 = param_1[0x974f];
      iVar8 = 7;
    }
    else {
      uVar23 = FUN_00018948(puVar9,puVar10,param_1[0x1747]);
      iVar7 = (int)((ulonglong)uVar23 >> 0x20);
      uVar13 = (uint)uVar23;
      if (0xffffff88 < uVar13) {
        return uVar13;
      }
      if (uVar13 != 0) {
        return 0xffffffb8;
      }
      iVar8 = param_1[0x1716];
      if (iVar8 != 0) {
        iVar7 = param_1[0x1733];
      }
      if (iVar8 != 0 && iVar7 != iVar8) {
        return 0xffffffe0;
      }
      iVar8 = 2;
      iVar14 = 3;
      if (param_1[0x1717] != 0) {
        FUN_000235a0(param_1 + 0x171c,iVar7,0,0);
      }
    }
    param_1[0x170f] = iVar14;
    uVar13 = *puVar20;
    uVar12 = param_1[0x1713];
    param_1[0x1719] = iVar8;
    if (-uVar12 < (uint)(uVar13 < 0x401)) {
      uVar13 = 0x400;
      uVar12 = 0;
    }
    *puVar20 = uVar13;
    param_1[0x1713] = uVar12;
    if ((uint)(uVar13 <= (uint)param_1[0x1741]) <= -uVar12) {
      return 0xfffffff0;
    }
    uVar21 = uVar13;
    if (uVar12 != 0 || uVar12 < (0x1ffff < uVar13)) {
      uVar21 = 0x20000;
    }
    uVar13 = uVar13 + uVar21;
    param_1[0x1746] = uVar21;
    uVar12 = uVar13 + 0x10;
    if (uVar21 <= (uint)param_1[0x173f]) {
      uVar13 = param_1[0x1743];
    }
    if (uVar21 > (uint)param_1[0x173f] || uVar13 < uVar12) {
      if (param_1[0x173a] == 0) {
        FUN_00024454(param_1[0x173e],param_1[0x1735],param_1[0x1736],param_1[0x1737]);
        param_1[0x1743] = 0;
        param_1[0x173f] = 0;
        iVar7 = FUN_000243e8(uVar12 + uVar21,param_1[0x1735],param_1[0x1736],param_1[0x1737]);
        param_1[0x173e] = iVar7;
        if (iVar7 == 0) {
          return 0xffffffc0;
        }
      }
      else {
        if (param_1[0x173a] - 0x25d50U < uVar12 + uVar21) {
          return 0xffffffc0;
        }
        iVar7 = param_1[0x173e];
      }
      param_1[0x1742] = iVar7 + uVar21;
      param_1[0x1743] = uVar12;
      param_1[0x173f] = uVar21;
    }
    param_1[0x173d] = 2;
switchD_0001bcbc_caseD_2:
    uVar13 = param_1[0x170f];
    if (uVar13 == 0) {
      param_1[0x173d] = 0;
      goto LAB_0001c394;
    }
    if ((uint)((int)puVar3 - (int)puVar19) < uVar13) {
      puVar18 = puVar3;
      if (puVar19 == puVar3) goto LAB_0001c394;
      param_1[0x173d] = 3;
LAB_0001c084:
      iVar7 = param_1[0x1740];
      uVar12 = uVar13 - iVar7;
      if ((uint)(param_1[0x173f] - iVar7) < uVar12) {
        return 0xffffffec;
      }
      uVar15 = (int)puVar3 - (int)puVar19;
      uVar21 = uVar15;
      if (uVar12 < uVar15) {
        uVar21 = uVar12;
      }
      FUN_00036044(param_1[0x173e] + iVar7,puVar19,uVar21);
      puVar18 = (uint *)((int)puVar19 + uVar21);
      param_1[0x1740] = param_1[0x1740] + uVar21;
      if (uVar15 < uVar12) goto LAB_0001c394;
      iVar7 = param_1[0x1719];
      uVar13 = FUN_0001aa4c(param_1,param_1[0x1742] + param_1[0x1744],
                            param_1[0x1743] - param_1[0x1744],param_1[0x173e],uVar13);
      if (0xffffff88 < uVar13) {
        return uVar13;
      }
      param_1[0x1740] = 0;
      uVar12 = uVar13;
      if (iVar7 == 7) {
        uVar12 = uVar13 | 1;
      }
      if (uVar12 != 0) {
        iVar7 = param_1[0x1744];
        param_1[0x173d] = 4;
        iVar8 = iVar7 + uVar13;
        param_1[0x1745] = iVar8;
        goto LAB_0001c29c;
      }
      param_1[0x173d] = 2;
      puVar19 = puVar18;
    }
    else {
      iVar8 = param_1[0x1719];
      iVar7 = 0;
      if (iVar8 != 7) {
        iVar7 = param_1[0x1743];
      }
      if (iVar8 != 7) {
        iVar7 = iVar7 - param_1[0x1744];
      }
      uVar12 = FUN_0001aa4c(param_1,param_1[0x1742] + param_1[0x1744],iVar7,puVar19,uVar13);
      if (0xffffff88 < uVar12) {
        return uVar12;
      }
      puVar19 = (uint *)((int)puVar19 + uVar13);
      if ((uVar12 | iVar8 == 7) != 0) {
        param_1[0x173d] = 4;
        param_1[0x1745] = param_1[0x1744] + uVar12;
      }
    }
  }
  else {
    iVar7 = param_1[0x1747];
    uVar12 = (int)puVar3 - (int)puVar19;
    uVar21 = uVar13 - iVar7;
    if (uVar12 < uVar21) {
      if (0 < (int)uVar12) {
        FUN_00036044((int)param_1 + iVar7 + 0x25d38,puVar19,uVar12);
        iVar7 = param_1[0x1747] + uVar12;
        param_1[0x1747] = iVar7;
      }
      if (uVar13 < 7) {
        uVar13 = 6;
      }
      param_3[2] = param_3[1];
      return (uVar13 - iVar7) + 3;
    }
    FUN_00036044((int)param_1 + iVar7 + 0x25d38,puVar19,uVar21);
    puVar19 = (uint *)((int)puVar19 + uVar21);
    param_1[0x1747] = uVar13;
  }
  goto LAB_0001bca8;
switchD_0001bcbc_caseD_4:
  iVar7 = param_1[0x1744];
  iVar8 = param_1[0x1745];
LAB_0001c29c:
  uVar12 = iVar8 - iVar7;
  uVar13 = uVar12;
  if (uVar5 < uVar12) {
    uVar13 = uVar5;
  }
  FUN_00036044(local_70,param_1[0x1742] + iVar7,uVar13);
  iVar7 = param_1[0x1744];
  local_70 = local_70 + uVar13;
  param_1[0x1744] = iVar7 + uVar13;
  if (uVar5 < uVar12) {
LAB_0001c394:
    uVar4 = (int)puVar18 + (param_3[2] - (int)puVar17);
    param_3[2] = uVar4;
    param_2[2] = (local_70 - iVar11) + param_2[2];
    uVar5 = param_1[0x170f];
    if (uVar5 != 0) {
      if (param_1[0x1719] == 3) {
        uVar5 = uVar5 + 3;
      }
      uVar4 = uVar5 - param_1[0x1740];
      if (uVar5 < (uint)param_1[0x1740]) {
        uVar4 = 0xffffffff;
      }
      return uVar4;
    }
    if (param_1[0x1745] == param_1[0x1744]) {
      uVar5 = 0;
      if (param_1[0x174b] != 0) {
        if (uVar4 < (uint)param_3[1]) {
          param_3[2] = uVar4 + 1;
        }
        else {
          uVar5 = 1;
          param_1[0x173d] = 2;
        }
      }
    }
    else {
      uVar5 = 1;
      if (param_1[0x174b] == 0) {
        uVar5 = 1;
        param_3[2] = uVar4 - 1;
        param_1[0x174b] = 1;
      }
    }
    return uVar5;
  }
  param_1[0x173d] = 2;
  if ((uint)param_1[0x1743] < param_1[0x1746] + iVar7 + uVar13) {
    param_1[0x1744] = 0;
    param_1[0x1745] = 0;
  }
  goto LAB_0001bc9c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001c4e4 FUN_0001c4e4 */

int FUN_0001c4e4(undefined *param_1,undefined *param_2,int param_3,int param_4,uint param_5,
                undefined4 param_6,int *param_7,undefined *param_8,undefined *param_9,int param_10,
                uint param_11)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  undefined *puVar5;
  undefined *puVar6;
  undefined *puVar7;
  int iVar8;
  
  iVar8 = param_3 + param_4;
  puVar4 = param_1 + iVar8;
  iVar2 = -0x46;
  if (puVar4 <= param_2) {
    puVar5 = (undefined *)*param_7;
    iVar2 = -0x14;
    if (puVar5 + param_3 <= param_8) {
      puVar7 = param_1 + param_3;
      param_2 = param_2 + -8;
      iVar2 = -1;
      if (param_2 < puVar7) {
        puVar6 = param_1;
        if (param_1 < param_2) {
          do {
            FUN_00036044(puVar6,puVar5,8);
            puVar6 = puVar6 + 8;
            puVar5 = puVar5 + 8;
          } while (puVar6 < param_2);
          puVar5 = param_2 + (*param_7 - (int)param_1);
          *param_7 = (int)puVar5;
          param_1 = param_2;
        }
        if (param_1 < puVar7) {
          *param_7 = (int)(puVar5 + 1);
          uVar1 = *puVar5;
          puVar5 = param_1;
          while( true ) {
            param_1 = puVar5 + 1;
            *puVar5 = uVar1;
            if (puVar7 <= param_1) break;
            puVar5 = (undefined *)*param_7;
            *param_7 = (int)(puVar5 + 1);
            uVar1 = *puVar5;
            puVar5 = param_1;
          }
        }
        puVar5 = puVar7 + -param_5;
        if ((uint)((int)puVar7 - (int)param_9) < param_5) {
          if ((uint)((int)puVar7 - param_10) < param_5) {
            return -0x14;
          }
          iVar3 = (int)puVar5 - (int)param_9;
          iVar2 = param_11 + iVar3;
          if ((uint)(iVar2 + param_4) <= param_11) {
            FUN_0003605c(puVar7,iVar2,param_4);
            return iVar8;
          }
          FUN_0003605c(puVar7,iVar2,-iVar3);
          param_1 = puVar7 + -iVar3;
          puVar5 = param_9;
        }
        iVar2 = iVar8;
        if (param_1 < puVar4) {
          do {
            puVar7 = param_1 + 1;
            *param_1 = *puVar5;
            param_1 = puVar7;
            puVar5 = puVar5 + 1;
          } while (puVar4 != puVar7);
        }
      }
    }
  }
  return iVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001c660 FUN_0001c660 */

int FUN_0001c660(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  uint *puVar7;
  bool bVar8;
  bool bVar9;
  undefined auStack_92 [106];
  uint uStack_28;
  undefined4 local_24;
  
  iVar6 = -0x1e;
  if (8 < param_3) {
    uVar1 = FUN_0001f8dc(param_1 + 0x140c,param_2 + 8,param_3 - 8,param_1 + 0x5410,0x800);
    if (uVar1 < 0xffffff89) {
      iVar4 = param_2 + 8 + uVar1;
      puVar7 = (uint *)(param_2 + param_3);
      local_24 = 0x1c;
      uVar1 = FUN_0001d7c8(auStack_92,&local_24,&uStack_28,iVar4,(int)puVar7 - iVar4);
      bVar8 = 0xffffff87 < uVar1;
      if (uVar1 < 0xffffff89) {
        bVar8 = 8 < uStack_28;
      }
      if ((!bVar8) &&
         (uVar2 = FUN_0001c858(param_1 + 0x804,auStack_92,local_24), uVar2 < 0xffffff89)) {
        iVar4 = iVar4 + uVar1;
        local_24 = 0x34;
        uVar1 = FUN_0001d7c8(auStack_92,&local_24,&uStack_28,iVar4,(int)puVar7 - iVar4);
        bVar8 = 0xffffff87 < uVar1;
        if (uVar1 < 0xffffff89) {
          bVar8 = 9 < uStack_28;
        }
        if ((!bVar8) &&
           (uVar2 = FUN_0001c858(param_1 + 0xc08,auStack_92,local_24), uVar2 < 0xffffff89)) {
          puVar5 = (uint *)(iVar4 + uVar1);
          local_24 = 0x23;
          uVar1 = FUN_0001d7c8(auStack_92,&local_24,&uStack_28,puVar5,(int)puVar7 - (int)puVar5);
          bVar8 = 0xffffff87 < uVar1;
          if (uVar1 < 0xffffff89) {
            bVar8 = 9 < uStack_28;
          }
          if (!bVar8) {
            puVar3 = (uint *)FUN_0001c858(param_1,auStack_92,local_24);
            if (puVar3 < (uint *)0xffffff89) {
              puVar5 = (uint *)((int)puVar5 + uVar1);
            }
            bVar9 = (uint *)0xffffff87 < puVar3;
            bVar8 = puVar3 == (uint *)0xffffff88;
            if (puVar3 < (uint *)0xffffff89) {
              puVar3 = puVar5 + 3;
              bVar9 = puVar7 <= puVar3;
              bVar8 = puVar3 == puVar7;
            }
            if (((!bVar9 || bVar8) && (uVar1 = *puVar5, uVar1 != 0)) &&
               (uVar2 = (int)puVar7 - (int)puVar3, uVar1 < uVar2)) {
              *(uint *)(param_1 + 0x5c10) = uVar1;
              uVar1 = puVar5[1];
              if ((uVar1 != 0) && (uVar1 < uVar2)) {
                *(uint *)(param_1 + 0x5c14) = uVar1;
                uVar1 = puVar5[2];
                if ((uVar1 != 0) && (uVar1 < uVar2)) {
                  *(uint *)(param_1 + 0x5c18) = uVar1;
                  iVar6 = (int)puVar5 + (0xc - param_2);
                }
              }
            }
          }
        }
      }
    }
  }
  return iVar6;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001c858 FUN_0001c858 */

undefined4 FUN_0001c858(int param_1,ushort *param_2,uint param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  ushort *puVar3;
  ushort *puVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  ushort uVar8;
  int iVar9;
  short *psVar10;
  int iVar11;
  bool bVar12;
  bool bVar13;
  undefined2 local_22c;
  undefined2 local_22a;
  ushort auStack_228 [258];
  
  uVar6 = 0xffffffd2;
  bVar13 = 0xfe < param_3;
  bVar12 = param_3 == 0xff;
  if (param_3 < 0x100) {
    uVar6 = 0xffffffd4;
    bVar13 = 0xb < param_4;
    bVar12 = param_4 == 0xc;
  }
  if (!bVar13 || bVar12) {
    psVar10 = (short *)(param_1 + 4);
    uVar1 = 1 << (param_4 & 0xff);
    local_22a = 1;
    local_22c = (undefined2)param_4;
    if (param_3 == 0xffffffff) {
      FUN_00036044(param_1,&local_22c,4);
    }
    else {
      uVar7 = (1 << (param_4 & 0xff)) - 1;
      iVar11 = 0;
      puVar3 = param_2;
      puVar4 = auStack_228;
      uVar5 = uVar7;
      do {
        uVar8 = *puVar3;
        if (uVar8 == 0xffff) {
          *(char *)(psVar10 + uVar5 * 2 + 1) = (char)iVar11;
          uVar8 = 1;
          uVar5 = uVar5 - 1;
        }
        else if ((0x10000 << (param_4 - 1 & 0xff)) >> 0x10 <= (int)(short)uVar8) {
          local_22a = 0;
        }
        *puVar4 = uVar8;
        puVar3 = puVar3 + 1;
        iVar11 = iVar11 + 1;
        puVar4 = puVar4 + 1;
      } while (param_3 + 1 != iVar11);
      FUN_00036044(param_1,&local_22c,4);
      if (param_3 != 0xffffffff) {
        iVar11 = 0;
        uVar2 = 0;
        do {
          uVar8 = param_2[iVar11];
          if (0 < (short)uVar8) {
            iVar9 = 0;
            do {
              *(char *)(psVar10 + uVar2 * 2 + 1) = (char)iVar11;
              do {
                uVar2 = (uVar1 >> 3) + (uVar1 >> 1) + 3 + uVar2 & uVar7;
              } while (uVar5 < uVar2);
              iVar9 = iVar9 + 1;
            } while (iVar9 < (short)uVar8);
          }
          iVar11 = iVar11 + 1;
        } while (iVar11 != param_3 + 1);
        if (uVar2 != 0) {
          return 0xffffffff;
        }
      }
    }
    uVar6 = 0;
    uVar5 = 0;
    do {
      uVar5 = uVar5 + 1;
      uVar8 = auStack_228[*(byte *)(psVar10 + 1)];
      auStack_228[*(byte *)(psVar10 + 1)] = uVar8 + 1;
      uVar7 = (param_4 - 0x1f) + LZCOUNT((uint)uVar8);
      *(char *)((int)psVar10 + 3) = (char)uVar7;
      *psVar10 = (uVar8 << (uVar7 & 0xff)) - (short)uVar1;
      psVar10 = psVar10 + 2;
    } while (uVar5 < uVar1);
  }
  return uVar6;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001ca20 FUN_0001ca20 */

undefined4 FUN_0001ca20(undefined4 *param_1,undefined param_2)

{
  *(undefined *)((int)param_1 + 7) = 0;
  *(undefined *)((int)param_1 + 6) = param_2;
  *(undefined2 *)(param_1 + 1) = 0;
  *param_1 = 0;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001ca84 FUN_0001ca84 */

undefined *
FUN_0001ca84(undefined *param_1,int param_2,uint *param_3,undefined *param_4,ushort *param_5)

{
  byte bVar1;
  byte bVar2;
  ushort uVar3;
  ushort uVar4;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  ushort *puVar8;
  uint *puVar9;
  int iVar10;
  uint uVar11;
  undefined *puVar12;
  uint uVar13;
  uint *puVar14;
  undefined *puVar15;
  uint uVar16;
  undefined *puVar17;
  bool bVar18;
  uint local_38 [2];
  uint *local_30;
  
  puVar15 = param_1;
  local_30 = param_3;
  if (param_5[1] == 0) {
    if (param_4 == (undefined *)0x0) goto LAB_0001cb60;
    puVar14 = param_3 + 1;
    if (param_4 < (undefined *)0x4) {
      local_38[0] = (uint)*(byte *)param_3;
      if (param_4 == (undefined *)0x2) {
LAB_0001cc38:
        local_38[0] = local_38[0] + (uint)*(byte *)((int)param_3 + 1) * 0x100;
      }
      else if (param_4 == (undefined *)0x3) {
        local_38[0] = local_38[0] | (uint)*(byte *)((int)param_3 + 2) << 0x10;
        goto LAB_0001cc38;
      }
      if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
        return (undefined *)0xffffffec;
      }
      puVar12 = (undefined *)0x0;
      uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) + (int)param_4 * -8 + 9;
    }
    else {
      puVar12 = param_4 + -4;
      local_30 = (uint *)((int)param_3 + (int)puVar12);
      local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
      if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
        return (undefined *)0xffffffff;
      }
      uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) - 0x17;
      if ((undefined *)0xffffff88 < param_4) {
        return param_4;
      }
    }
    uVar13 = (uint)*param_5;
    uVar5 = uVar11 + uVar13;
    uVar16 = 0x1f - uVar13 & 0x1f;
    uVar11 = ((local_38[0] << (uVar11 & 0x1f)) >> 1) >> uVar16;
    if (uVar5 < 0x21) {
      if ((int)puVar12 < 4) {
        if (puVar12 == (undefined *)0x0) {
          puVar12 = (undefined *)0x0;
          goto LAB_0001ce04;
        }
        puVar17 = puVar12;
        if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar5 >> 3)))) {
          puVar17 = (undefined *)(uVar5 >> 3);
        }
        uVar7 = uVar5 + (int)puVar17 * -8;
      }
      else {
        uVar7 = uVar5 & 7;
        puVar17 = (undefined *)(uVar5 >> 3);
      }
      puVar12 = puVar12 + -(int)puVar17;
      local_30 = (uint *)((int)param_3 + (int)puVar12);
      local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
      uVar5 = uVar7;
    }
LAB_0001ce04:
    uVar13 = uVar5 + uVar13;
    uVar5 = ((local_38[0] << (uVar5 & 0x1f)) >> 1) >> uVar16;
    if (uVar13 < 0x21) {
      if (3 < (int)puVar12) {
        local_30 = (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
        local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
        uVar13 = uVar13 & 7;
LAB_0001d25c:
        puVar17 = param_1 + 2;
        puVar12 = param_1;
        if (local_30 < puVar14) goto LAB_0001d280;
        do {
          puVar6 = (uint *)((int)local_30 - (uVar13 >> 3));
          uVar13 = uVar13 & 7;
          bVar18 = false;
          while( true ) {
            puVar15 = puVar17 + -2;
            local_38[0] = *puVar6;
            local_30 = puVar6;
            if ((param_1 + param_2 + -3 <= puVar15) || (bVar18)) goto LAB_0001ce38;
            puVar8 = param_5 + uVar11 * 2 + 2;
            uVar4 = *puVar8;
            bVar2 = *(byte *)((int)puVar8 + 3);
            uVar16 = uVar13 + bVar2;
            puVar17[-2] = *(undefined *)(puVar8 + 1);
            puVar8 = param_5 + uVar5 * 2 + 2;
            uVar3 = *puVar8;
            uVar11 = uVar13 & 0x1f;
            bVar1 = *(byte *)((int)puVar8 + 3);
            uVar13 = uVar16 + bVar1;
            puVar17[-1] = *(undefined *)(puVar8 + 1);
            uVar11 = (uint)uVar4 + (((local_38[0] << uVar11) >> 1) >> (0x1f - bVar2 & 0x1f));
            uVar5 = (uint)uVar3 + (((local_38[0] << (uVar16 & 0x1f)) >> 1) >> (0x1f - bVar1 & 0x1f))
            ;
            puVar15 = puVar17;
            if (0x20 < uVar13) goto LAB_0001ce38;
            if (puVar6 < puVar14) {
              if (puVar6 == param_3) goto LAB_0001ce38;
              puVar9 = (uint *)((int)puVar6 - (uVar13 >> 3));
              uVar16 = uVar13 >> 3;
              if (puVar9 < param_3) {
                uVar16 = (int)puVar6 - (int)param_3;
              }
              local_30 = (uint *)((int)puVar6 - uVar16);
              uVar13 = uVar13 + uVar16 * -8;
              local_38[0] = *(uint *)((int)puVar6 - uVar16);
              uVar16 = uVar13;
              if (puVar9 < param_3) goto LAB_0001ce38;
            }
            else {
              uVar16 = uVar13 & 7;
              local_30 = (uint *)((int)puVar6 - (uVar13 >> 3));
              local_38[0] = *(uint *)((int)puVar6 - (uVar13 >> 3));
            }
            puVar8 = param_5 + uVar11 * 2 + 2;
            uVar4 = *puVar8;
            bVar2 = *(byte *)((int)puVar8 + 3);
            uVar7 = uVar16 + bVar2;
            *puVar17 = *(undefined *)(puVar8 + 1);
            puVar8 = param_5 + uVar5 * 2 + 2;
            uVar3 = *puVar8;
            bVar1 = *(byte *)((int)puVar8 + 3);
            uVar13 = uVar7 + bVar1;
            puVar17[1] = *(undefined *)(puVar8 + 1);
            uVar11 = (uint)uVar4 +
                     (((local_38[0] << (uVar16 & 0x1f)) >> 1) >> (0x1f - bVar2 & 0x1f));
            uVar5 = (uint)uVar3 + (((local_38[0] << (uVar7 & 0x1f)) >> 1) >> (0x1f - bVar1 & 0x1f));
            if (0x20 < uVar13) {
              puVar15 = puVar17 + 2;
              goto LAB_0001ce38;
            }
            puVar12 = puVar12 + 4;
            puVar17 = puVar17 + 4;
            if (puVar14 <= local_30) break;
LAB_0001d280:
            puVar15 = puVar12;
            if (local_30 == param_3) goto LAB_0001ce38;
            uVar16 = uVar13 >> 3;
            bVar18 = (uint *)((int)local_30 - (uVar13 >> 3)) < param_3;
            if (bVar18) {
              uVar16 = (int)local_30 - (int)param_3;
            }
            puVar6 = (uint *)((int)local_30 - uVar16);
            uVar13 = uVar13 + uVar16 * -8;
          }
        } while( true );
      }
      if (puVar12 == (undefined *)0x0) goto LAB_0001d25c;
      puVar17 = puVar12;
      if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)))) {
        puVar17 = (undefined *)(uVar13 >> 3);
      }
      local_30 = (uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
      uVar13 = uVar13 + (int)puVar17 * -8;
      local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
      if (uVar13 < 0x21) goto LAB_0001d25c;
    }
LAB_0001ce38:
    uVar16 = local_38[0];
    while( true ) {
      if (param_1 + param_2 + -2 < puVar15) {
        return (undefined *)0xffffffba;
      }
      puVar8 = param_5 + uVar11 * 2 + 2;
      uVar4 = *puVar8;
      bVar2 = *(byte *)((int)puVar8 + 3);
      uVar7 = uVar13 + bVar2;
      *puVar15 = *(undefined *)(puVar8 + 1);
      if (0x20 < uVar7) break;
      if (local_30 < puVar14) {
        local_38[0] = uVar16;
        if (local_30 != param_3) {
          uVar11 = uVar7 >> 3;
          if ((uint *)((int)local_30 - (uVar7 >> 3)) < param_3) {
            uVar11 = (int)local_30 - (int)param_3;
          }
          uVar7 = uVar7 + uVar11 * -8;
          goto LAB_0001cec8;
        }
      }
      else {
        uVar11 = uVar7 >> 3;
        uVar7 = uVar7 & 7;
LAB_0001cec8:
        local_30 = (uint *)((int)local_30 - uVar11);
        local_38[0] = *local_30;
      }
      if (param_1 + param_2 + -2 < puVar15 + 1) {
        return (undefined *)0xffffffba;
      }
      uVar11 = (uint)uVar4 + (((uVar16 << (uVar13 & 0x1f)) >> 1) >> (0x1f - bVar2 & 0x1f));
      puVar8 = param_5 + uVar5 * 2 + 2;
      uVar4 = *puVar8;
      bVar2 = *(byte *)((int)puVar8 + 3);
      uVar13 = uVar7 + bVar2;
      puVar15[1] = *(undefined *)(puVar8 + 1);
      if (0x20 < uVar13) {
        puVar12 = puVar15 + 2;
        iVar10 = 3;
        uVar5 = uVar11;
        goto LAB_0001d240;
      }
      uVar5 = local_38[0] << (uVar7 & 0x1f);
      puVar15 = puVar15 + 2;
      if (local_30 < puVar14) {
        if (local_30 != param_3) {
          uVar16 = uVar13 >> 3;
          if ((uint *)((int)local_30 - (uVar13 >> 3)) < param_3) {
            uVar16 = (int)local_30 - (int)param_3;
          }
          uVar13 = uVar13 + uVar16 * -8;
          goto LAB_0001cf90;
        }
      }
      else {
        uVar16 = uVar13 >> 3;
        uVar13 = uVar13 & 7;
LAB_0001cf90:
        local_30 = (uint *)((int)local_30 - uVar16);
        local_38[0] = *local_30;
      }
      uVar5 = (uint)uVar4 + ((uVar5 >> 1) >> (0x1f - bVar2 & 0x1f));
      uVar16 = local_38[0];
    }
    puVar12 = puVar15 + 1;
    iVar10 = 2;
LAB_0001d240:
    param_5 = param_5 + uVar5 * 2 + 2;
    goto LAB_0001d628;
  }
  if (param_4 == (undefined *)0x0) {
LAB_0001cb60:
    FUN_00036050(local_38,0,0x14);
    return (undefined *)0xffffffb8;
  }
  puVar14 = param_3 + 1;
  if (param_4 < (undefined *)0x4) {
    local_38[0] = (uint)*(byte *)param_3;
    if (param_4 == (undefined *)0x2) {
LAB_0001cba0:
      local_38[0] = local_38[0] + (uint)*(byte *)((int)param_3 + 1) * 0x100;
    }
    else if (param_4 == (undefined *)0x3) {
      local_38[0] = local_38[0] | (uint)*(byte *)((int)param_3 + 2) << 0x10;
      goto LAB_0001cba0;
    }
    if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
      return (undefined *)0xffffffec;
    }
    puVar12 = (undefined *)0x0;
    uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) + (int)param_4 * -8 + 9;
  }
  else {
    puVar12 = param_4 + -4;
    local_30 = (uint *)((int)param_3 + (int)puVar12);
    local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
    if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
      return (undefined *)0xffffffff;
    }
    uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) - 0x17;
    if ((undefined *)0xffffff88 < param_4) {
      return param_4;
    }
  }
  uVar13 = (uint)*param_5;
  uVar5 = uVar11 + uVar13;
  uVar16 = 0x1f - uVar13 & 0x1f;
  uVar11 = ((local_38[0] << (uVar11 & 0x1f)) >> 1) >> uVar16;
  if (uVar5 < 0x21) {
    if ((int)puVar12 < 4) {
      if (puVar12 == (undefined *)0x0) {
        puVar12 = (undefined *)0x0;
        goto LAB_0001cd4c;
      }
      puVar17 = puVar12;
      if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar5 >> 3)))) {
        puVar17 = (undefined *)(uVar5 >> 3);
      }
      uVar7 = uVar5 + (int)puVar17 * -8;
    }
    else {
      uVar7 = uVar5 & 7;
      puVar17 = (undefined *)(uVar5 >> 3);
    }
    puVar12 = puVar12 + -(int)puVar17;
    local_30 = (uint *)((int)param_3 + (int)puVar12);
    local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
    uVar5 = uVar7;
  }
LAB_0001cd4c:
  uVar13 = uVar5 + uVar13;
  uVar5 = ((local_38[0] << (uVar5 & 0x1f)) >> 1) >> uVar16;
  if (uVar13 < 0x21) {
    if (3 < (int)puVar12) {
      local_30 = (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
      local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
      uVar13 = uVar13 & 7;
LAB_0001d024:
      puVar17 = param_1 + 2;
      puVar12 = param_1;
      if (local_30 < puVar14) goto LAB_0001d048;
      do {
        puVar6 = (uint *)((int)local_30 - (uVar13 >> 3));
        uVar13 = uVar13 & 7;
        bVar18 = false;
        while( true ) {
          puVar15 = puVar17 + -2;
          local_38[0] = *puVar6;
          local_30 = puVar6;
          if ((param_1 + param_2 + -3 <= puVar15) || (bVar18)) goto LAB_0001d488;
          puVar8 = param_5 + uVar11 * 2 + 2;
          uVar4 = *puVar8;
          bVar2 = *(byte *)((int)puVar8 + 3);
          uVar16 = uVar13 + bVar2;
          puVar17[-2] = *(undefined *)(puVar8 + 1);
          puVar8 = param_5 + uVar5 * 2 + 2;
          uVar3 = *puVar8;
          uVar11 = uVar13 & 0x1f;
          bVar1 = *(byte *)((int)puVar8 + 3);
          uVar13 = uVar16 + bVar1;
          puVar17[-1] = *(undefined *)(puVar8 + 1);
          uVar11 = (uint)uVar4 + ((local_38[0] << uVar11) >> (-(uint)bVar2 & 0x1f));
          uVar5 = (uint)uVar3 + ((local_38[0] << (uVar16 & 0x1f)) >> (-(uint)bVar1 & 0x1f));
          puVar15 = puVar17;
          if (0x20 < uVar13) goto LAB_0001d488;
          if (puVar6 < puVar14) {
            if (puVar6 == param_3) goto LAB_0001d488;
            puVar9 = (uint *)((int)puVar6 - (uVar13 >> 3));
            uVar16 = uVar13 >> 3;
            if (puVar9 < param_3) {
              uVar16 = (int)puVar6 - (int)param_3;
            }
            local_30 = (uint *)((int)puVar6 - uVar16);
            uVar13 = uVar13 + uVar16 * -8;
            local_38[0] = *(uint *)((int)puVar6 - uVar16);
            uVar16 = uVar13;
            if (puVar9 < param_3) goto LAB_0001d488;
          }
          else {
            uVar16 = uVar13 & 7;
            local_30 = (uint *)((int)puVar6 - (uVar13 >> 3));
            local_38[0] = *(uint *)((int)puVar6 - (uVar13 >> 3));
          }
          puVar8 = param_5 + uVar11 * 2 + 2;
          uVar4 = *puVar8;
          bVar2 = *(byte *)((int)puVar8 + 3);
          uVar7 = uVar16 + bVar2;
          *puVar17 = *(undefined *)(puVar8 + 1);
          puVar8 = param_5 + uVar5 * 2 + 2;
          uVar3 = *puVar8;
          bVar1 = *(byte *)((int)puVar8 + 3);
          uVar13 = uVar7 + bVar1;
          puVar17[1] = *(undefined *)(puVar8 + 1);
          uVar11 = (uint)uVar4 + ((local_38[0] << (uVar16 & 0x1f)) >> (-(uint)bVar2 & 0x1f));
          uVar5 = (uint)uVar3 + ((local_38[0] << (uVar7 & 0x1f)) >> (-(uint)bVar1 & 0x1f));
          if (0x20 < uVar13) {
            puVar15 = puVar17 + 2;
            goto LAB_0001d488;
          }
          puVar12 = puVar12 + 4;
          puVar17 = puVar17 + 4;
          if (puVar14 <= local_30) break;
LAB_0001d048:
          puVar15 = puVar12;
          if (local_30 == param_3) goto LAB_0001d488;
          uVar16 = uVar13 >> 3;
          bVar18 = (uint *)((int)local_30 - (uVar13 >> 3)) < param_3;
          if (bVar18) {
            uVar16 = (int)local_30 - (int)param_3;
          }
          puVar6 = (uint *)((int)local_30 - uVar16);
          uVar13 = uVar13 + uVar16 * -8;
        }
      } while( true );
    }
    if (puVar12 == (undefined *)0x0) goto LAB_0001d024;
    puVar17 = puVar12;
    if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)))) {
      puVar17 = (undefined *)(uVar13 >> 3);
    }
    local_30 = (uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
    uVar13 = uVar13 + (int)puVar17 * -8;
    local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
    if (uVar13 < 0x21) goto LAB_0001d024;
  }
LAB_0001d488:
  uVar16 = local_38[0];
  while( true ) {
    if (param_1 + param_2 + -2 < puVar15) {
      return (undefined *)0xffffffba;
    }
    puVar8 = param_5 + uVar11 * 2 + 2;
    uVar4 = *puVar8;
    bVar2 = *(byte *)((int)puVar8 + 3);
    uVar7 = uVar13 + bVar2;
    *puVar15 = *(undefined *)(puVar8 + 1);
    if (0x20 < uVar7) break;
    if (local_30 < puVar14) {
      local_38[0] = uVar16;
      if (local_30 != param_3) {
        uVar11 = uVar7 >> 3;
        if ((uint *)((int)local_30 - (uVar7 >> 3)) < param_3) {
          uVar11 = (int)local_30 - (int)param_3;
        }
        uVar7 = uVar7 + uVar11 * -8;
        goto LAB_0001d51c;
      }
    }
    else {
      uVar11 = uVar7 >> 3;
      uVar7 = uVar7 & 7;
LAB_0001d51c:
      local_30 = (uint *)((int)local_30 - uVar11);
      local_38[0] = *local_30;
    }
    if (param_1 + param_2 + -2 < puVar15 + 1) {
      return (undefined *)0xffffffba;
    }
    uVar11 = (uint)uVar4 + ((uVar16 << (uVar13 & 0x1f)) >> (-(uint)bVar2 & 0x1f));
    puVar8 = param_5 + uVar5 * 2 + 2;
    uVar4 = *puVar8;
    bVar2 = *(byte *)((int)puVar8 + 3);
    uVar13 = uVar7 + bVar2;
    puVar15[1] = *(undefined *)(puVar8 + 1);
    if (0x20 < uVar13) {
      puVar12 = puVar15 + 2;
      iVar10 = 3;
      param_5 = param_5 + uVar11 * 2 + 2;
      goto LAB_0001d628;
    }
    puVar15 = puVar15 + 2;
    uVar5 = local_38[0] << (uVar7 & 0x1f);
    if (local_30 < puVar14) {
      if (local_30 != param_3) {
        uVar16 = uVar13 >> 3;
        if ((uint *)((int)local_30 - (uVar13 >> 3)) < param_3) {
          uVar16 = (int)local_30 - (int)param_3;
        }
        uVar13 = uVar13 + uVar16 * -8;
        goto LAB_0001d5d8;
      }
    }
    else {
      uVar16 = uVar13 >> 3;
      uVar13 = uVar13 & 7;
LAB_0001d5d8:
      local_30 = (uint *)((int)local_30 - uVar16);
      local_38[0] = *local_30;
    }
    uVar5 = (uint)uVar4 + (uVar5 >> (-(uint)bVar2 & 0x1f));
    uVar16 = local_38[0];
  }
  puVar12 = puVar15 + 1;
  iVar10 = 2;
  param_5 = param_5 + uVar5 * 2 + 2;
LAB_0001d628:
  *puVar12 = *(undefined *)(param_5 + 1);
  return puVar15 + (iVar10 - (int)param_1);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001d668 FUN_0001d668 */

uint FUN_0001d668(undefined4 param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined4 local_22c;
  uint local_228;
  undefined auStack_224 [516];
  
  local_22c = 0xff;
  uVar1 = FUN_0001d7c8(auStack_224,&local_22c,&local_228,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_228 <= param_6) {
      uVar2 = FUN_0001c858(param_5,auStack_224,local_22c);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_0001ca84(param_1,param_2,param_3 + uVar1,param_4 - uVar1,param_5);
      }
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001d700 FUN_0001d700 */

uint FUN_0001d700(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_4230 [16388];
  undefined4 local_22c;
  uint local_228;
  undefined auStack_224 [516];
  
  local_22c = 0xff;
  uVar1 = FUN_0001d7c8(auStack_224,&local_22c,&local_228,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_228 < 0xd) {
      uVar2 = FUN_0001c858(auStack_4230,auStack_224,local_22c);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_0001ca84(param_1,param_2,param_3 + uVar1,param_4 - uVar1,auStack_4230);
      }
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001d7c8 FUN_0001d7c8 */

int FUN_0001d7c8(int param_1,uint *param_2,uint *param_3,uint *param_4,uint param_5)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  undefined2 *puVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint *puVar10;
  uint uVar11;
  uint uVar12;
  uint *puVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint *puVar17;
  uint uVar18;
  bool bVar19;
  bool bVar20;
  
  iVar1 = -0x48;
  if (3 < param_5) {
    uVar9 = *param_4;
    iVar1 = -0x2c;
    uVar11 = uVar9 & 0xf;
    if (uVar11 + 5 < 0x10) {
      *param_3 = uVar11 + 5;
      uVar7 = 0x20 << uVar11;
      iVar1 = -0x14;
      if (1 < uVar7) {
        uVar16 = uVar7 | 1;
        puVar13 = (uint *)((int)param_4 + (param_5 - 7));
        puVar17 = (uint *)((int)param_4 + (param_5 - 4));
        uVar2 = *param_2;
        iVar1 = uVar11 + 6;
        uVar9 = uVar9 >> 4;
        uVar11 = 4;
        bVar19 = false;
        uVar12 = 0;
        puVar10 = param_4;
        do {
          uVar15 = uVar12;
          if (bVar19) {
            while ((uVar9 & 0xffff) == 0xffff) {
              if (puVar10 < (uint *)((int)param_4 + (param_5 - 5))) {
                puVar10 = (uint *)((int)puVar10 + 2);
                uVar9 = *puVar10 >> (uVar11 & 0xff);
              }
              else {
                uVar11 = uVar11 + 0x10;
                uVar9 = uVar9 >> 0x10;
              }
              uVar15 = uVar15 + 0x18;
            }
            for (uVar18 = uVar9 & 3; uVar18 == 3; uVar18 = uVar18 >> 0x1e) {
              uVar18 = uVar9 << 0x1c;
              uVar11 = uVar11 + 2;
              uVar15 = uVar15 + 3;
              uVar9 = uVar9 >> 2;
            }
            uVar14 = uVar15 + uVar18;
            if (uVar2 < uVar14) {
              return -0x30;
            }
            if (uVar12 < uVar14) {
              iVar3 = (uVar15 + uVar18) - uVar12;
              puVar6 = (undefined2 *)(param_1 + uVar12 * 2);
              do {
                *puVar6 = 0;
                iVar3 = iVar3 + -1;
                puVar6 = puVar6 + 1;
                uVar12 = uVar14;
              } while (iVar3 != 0);
            }
            uVar11 = uVar11 + 2;
            bVar20 = puVar13 <= puVar10;
            bVar19 = puVar10 == puVar13;
            iVar3 = (int)uVar11 >> 3;
            if (bVar20 && !bVar19) {
              puVar4 = (uint *)((int)puVar10 + iVar3);
              bVar20 = puVar17 <= puVar4;
              bVar19 = puVar4 == puVar17;
            }
            uVar15 = uVar12;
            if (bVar20 && !bVar19) {
              uVar9 = uVar9 >> 2;
            }
            else {
              uVar11 = uVar11 & 7;
              puVar10 = (uint *)((int)puVar10 + iVar3);
              uVar9 = *puVar10 >> uVar11;
            }
          }
          uVar18 = uVar9 & uVar7 - 1;
          uVar14 = uVar7 * 2 - 1;
          uVar12 = uVar14 - uVar16;
          if (uVar18 < uVar12) {
            iVar3 = iVar1 + -1;
          }
          else {
            uVar18 = uVar9 & uVar14;
            iVar3 = iVar1;
            if ((int)uVar7 <= (int)uVar18) {
              uVar18 = uVar18 - uVar12;
            }
          }
          iVar8 = uVar18 - 1;
          iVar5 = iVar8;
          if ((int)uVar18 < 1) {
            iVar5 = 1 - uVar18;
          }
          uVar16 = uVar16 - iVar5;
          *(short *)(param_1 + uVar15 * 2) = (short)iVar8;
          for (; (int)uVar16 < (int)uVar7; uVar7 = (int)uVar7 >> 1) {
            iVar1 = iVar1 + -1;
          }
          uVar9 = iVar3 + uVar11;
          bVar20 = puVar13 <= puVar10;
          bVar19 = puVar10 == puVar13;
          if (bVar20 && !bVar19) {
            puVar4 = (uint *)((int)puVar10 + ((int)uVar9 >> 3));
            bVar20 = puVar17 <= puVar4;
            bVar19 = puVar4 == puVar17;
          }
          if (bVar20 && !bVar19) {
            uVar11 = uVar9 + ((int)puVar17 - (int)puVar10) * -8;
            puVar10 = puVar17;
          }
          else {
            uVar11 = uVar9 & 7;
            puVar10 = (uint *)((int)puVar10 + ((int)uVar9 >> 3));
          }
          if ((int)uVar16 < 2) break;
          uVar12 = uVar15 + 1;
          bVar19 = iVar8 == 0;
          uVar9 = *puVar10 >> (uVar11 & 0x1f);
        } while (uVar12 <= uVar2);
        if (uVar16 != 1) {
          return -0x14;
        }
        iVar1 = -0x14;
        if ((int)uVar11 < 0x21) {
          *param_2 = uVar15;
          iVar1 = (int)puVar10 + (((int)(uVar11 + 7) >> 3) - (int)param_4);
        }
      }
    }
  }
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001da84 FUN_0001da84 */

uint FUN_0001da84(byte *param_1,uint param_2,int param_3,int *param_4,uint *param_5,byte *param_6,
                 uint param_7)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_12c [264];
  
  if (param_7 == 0) {
    return 0xffffffb8;
  }
  iVar3 = (int)(char)*param_6;
  uVar8 = (uint)*param_6;
  if (iVar3 == -1 || iVar3 + 1 < 0 != SCARRY4(iVar3,1)) {
    if (param_7 <= uVar8 - 0x7e >> 1) {
      return 0xffffffb8;
    }
    uVar1 = uVar8 - 0x7f;
    if (param_2 <= uVar1) {
      return 0xffffffec;
    }
    if (uVar1 == 0) {
      FUN_00036050(param_3,0,0x34);
      return 0xffffffec;
    }
    uVar8 = uVar8 - 0x7e >> 1;
    uVar5 = 0;
    do {
      pbVar4 = param_1 + uVar5;
      *pbVar4 = param_6[(uVar5 >> 1) + 1] >> 4;
      uVar6 = uVar5 >> 1;
      uVar5 = uVar5 + 2;
      pbVar4[1] = param_6[uVar6 + 1] & 0xf;
    } while (uVar5 < uVar1);
  }
  else {
    if (param_7 <= uVar8) {
      return 0xffffffb8;
    }
    uVar1 = FUN_0001d668(param_1,param_2 - 1,param_6 + 1,uVar8,auStack_12c,6);
    if (0xffffff88 < uVar1) {
      return uVar1;
    }
  }
  uVar6 = 0;
  FUN_00036050(param_3,0,0x34);
  uVar7 = 0xffffffec;
  pbVar4 = param_1;
  uVar5 = uVar1;
  if (uVar1 != 0) {
    do {
      uVar2 = (uint)*pbVar4;
      if (0xb < uVar2) {
        return 0xffffffec;
      }
      uVar5 = uVar5 - 1;
      *(int *)(param_3 + uVar2 * 4) = *(int *)(param_3 + uVar2 * 4) + 1;
      uVar6 = uVar6 + ((1 << *pbVar4) >> 1);
      pbVar4 = pbVar4 + 1;
    } while (uVar5 != 0);
    if ((uVar6 != 0) && (uVar6 >> 0xc == 0)) {
      *param_5 = 0x20U - LZCOUNT(uVar6);
      uVar6 = (1 << (0x20U - LZCOUNT(uVar6) & 0xff)) - uVar6;
      iVar3 = LZCOUNT(uVar6);
      if (uVar6 == 0x80000000U >> iVar3) {
        iVar3 = 0x20 - iVar3;
        param_1[uVar1] = (byte)iVar3;
        *(int *)(param_3 + iVar3 * 4) = *(int *)(param_3 + iVar3 * 4) + 1;
        if ((1 < *(uint *)(param_3 + 4)) && ((*(uint *)(param_3 + 4) & 1) == 0)) {
          uVar7 = uVar8 + 1;
          *param_4 = uVar1 + 1;
        }
      }
    }
  }
  return uVar7;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001dc3c FUN_0001dc3c */

uint FUN_0001dc3c(int param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  
  local_2c = 0;
  local_30 = 0;
  uVar4 = 0xffffffd4;
  if (0x13f < param_5) {
    uVar2 = FUN_0001da84(param_4 + 0x40,0x100,param_4,&local_30,&local_2c,param_2,param_3);
    uVar4 = uVar2;
    if ((uVar2 < 0xffffff89) &&
       (FUN_00036044(&local_28,param_1,4), uVar4 = 0xffffffd4, local_2c <= (local_28 & 0xff) + 1)) {
      local_34._0_2_ = (undefined2)local_28;
      iVar7 = 0;
      local_34 = CONCAT22(local_34._2_2_,(undefined2)local_34) & 0xffff00ff;
      FUN_00036044(param_1,&local_34,4);
      local_2c = local_2c + 1;
      if (1 < local_2c) {
        uVar4 = 1;
        do {
          iVar3 = *(int *)(param_4 + uVar4 * 4);
          uVar5 = uVar4 - 1;
          *(int *)(param_4 + uVar4 * 4) = iVar7;
          uVar4 = uVar4 + 1;
          iVar7 = iVar7 + (iVar3 << (uVar5 & 0xff));
        } while (uVar4 < local_2c);
      }
      uVar4 = uVar2;
      if (local_30 != 0) {
        uVar5 = 0;
        do {
          bVar1 = *(byte *)(param_4 + 0x40 + uVar5);
          uVar8 = (uint)bVar1;
          uVar6 = *(uint *)(param_4 + uVar8 * 4);
          iVar7 = (1 << uVar8) >> 1;
          uVar4 = uVar6 + iVar7;
          if (uVar6 < uVar4) {
            do {
              iVar3 = param_1 + uVar6 * 2;
              uVar6 = uVar6 + 1;
              *(byte *)(iVar3 + 5) = (char)local_2c - bVar1;
              *(char *)(iVar3 + 4) = (char)uVar5;
              uVar4 = *(int *)(param_4 + uVar8 * 4) + iVar7;
            } while (uVar6 < uVar4);
          }
          uVar5 = uVar5 + 1;
          *(uint *)(param_4 + uVar8 * 4) = uVar4;
          uVar4 = uVar2;
        } while (uVar5 < local_30);
      }
    }
  }
  return uVar4;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001dd8c FUN_0001dd8c */

void FUN_0001dd8c(void)

{
  FUN_0001dc3c();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001ddb4 FUN_0001ddb4 */

undefined4
FUN_0001ddb4(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  FUN_00036044(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    return 0xffffffff;
  }
  uVar1 = FUN_0001de20(param_1,param_2,param_3,param_4,param_5);
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001de20 FUN_0001de20 */

uint FUN_0001de20(undefined *param_1,uint param_2,uint *param_3,uint param_4,int param_5)

{
  uint uVar1;
  undefined *puVar2;
  uint uVar3;
  uint *puVar4;
  undefined *puVar5;
  undefined *puVar6;
  bool bVar7;
  undefined4 local_34;
  uint local_30;
  uint *local_2c;
  
  FUN_00036044(&local_34,param_5,4);
  if (param_4 == 0) {
    FUN_00036050(&local_34,0,0x14);
    return 0xffffffb8;
  }
  uVar3 = (uint)local_34._2_2_;
  puVar4 = param_3 + 1;
  if (3 < param_4) {
    local_2c = (uint *)((int)param_3 + (param_4 - 4));
    local_34 = *(uint *)((int)param_3 + (param_4 - 4));
    uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
    if (uVar1 == 0) {
      return 0xffffffff;
    }
    local_30 = LZCOUNT(uVar1) - 0x17;
    if (0xffffff88 < param_4) {
      return param_4;
    }
    goto LAB_0001df14;
  }
  local_34 = (uint)*(byte *)param_3;
  if (param_4 == 2) {
LAB_0001dee8:
    local_34 = local_34 + (uint)*(byte *)((int)param_3 + 1) * 0x100;
  }
  else if (param_4 == 3) {
    local_34 = local_34 | (uint)*(byte *)((int)param_3 + 2) << 0x10;
    goto LAB_0001dee8;
  }
  uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
  if (uVar1 == 0) {
    return 0xffffffec;
  }
  local_30 = LZCOUNT(uVar1) + param_4 * -8 + 9;
  local_2c = param_3;
LAB_0001df14:
  puVar6 = param_1 + param_2;
  param_5 = param_5 + 4;
  uVar3 = -uVar3 & 0x1f;
  puVar5 = param_1;
  if (local_30 < 0x21) {
    if (puVar4 <= local_2c) goto LAB_0001df6c;
    do {
      puVar5 = param_1;
      if (local_2c == param_3) goto LAB_0001e058;
      uVar1 = local_30 >> 3;
      bVar7 = (uint *)((int)local_2c - (local_30 >> 3)) < param_3;
      if (bVar7) {
        uVar1 = (int)local_2c - (int)param_3;
      }
      local_2c = (uint *)((int)local_2c - uVar1);
      local_30 = local_30 + uVar1 * -8;
      while( true ) {
        local_34 = *local_2c;
        if ((puVar6 + -4 < param_1) || (bVar7)) goto LAB_0001e050;
        puVar5 = (undefined *)(param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2);
        local_30 = local_30 + (byte)puVar5[1];
        *param_1 = *puVar5;
        puVar5 = (undefined *)(param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2);
        local_30 = local_30 + (byte)puVar5[1];
        param_1[1] = *puVar5;
        param_1 = param_1 + 2;
        puVar5 = param_1;
        if (0x20 < local_30) goto joined_r0x0001e0cc;
        if (local_2c < puVar4) break;
LAB_0001df6c:
        local_2c = (uint *)((int)local_2c - (local_30 >> 3));
        local_30 = local_30 & 7;
        bVar7 = false;
      }
    } while( true );
  }
joined_r0x0001e0cc:
  if (puVar5 < puVar6) {
    puVar2 = (undefined *)(param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2);
    local_30 = local_30 + (byte)puVar2[1];
    *puVar5 = *puVar2;
    while (puVar5 = puVar5 + 1, puVar5 != puVar6) {
      puVar2 = (undefined *)(param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2);
      local_30 = local_30 + (byte)puVar2[1];
      *puVar5 = *puVar2;
    }
  }
  if (((uint)local_2c ^ (uint)param_3 | local_30 ^ 0x20) != 0) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_0001e050:
  puVar5 = param_1;
  if (0x20 < local_30) goto joined_r0x0001e0cc;
LAB_0001e058:
  if (local_2c < puVar4) {
    if (local_2c == param_3) goto joined_r0x0001e0cc;
    uVar1 = local_30 >> 3;
    bVar7 = (uint *)((int)local_2c - (local_30 >> 3)) < param_3;
    if (bVar7) {
      uVar1 = (int)local_2c - (int)param_3;
    }
    local_30 = local_30 + uVar1 * -8;
  }
  else {
    uVar1 = local_30 >> 3;
    local_30 = local_30 & 7;
    bVar7 = false;
  }
  local_2c = (uint *)((int)local_2c - uVar1);
  local_34 = *local_2c;
  if ((puVar6 <= puVar5) || (bVar7)) goto joined_r0x0001e0cc;
  puVar2 = (undefined *)(param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2);
  local_30 = local_30 + (byte)puVar2[1];
  param_1 = puVar5 + 1;
  *puVar5 = *puVar2;
  goto LAB_0001e050;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001e164 FUN_0001e164 */

uint FUN_0001e164(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_0001dc3c(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001de20(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001e1e0 FUN_0001e1e0 */

uint FUN_0001e1e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_0001dc3c(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001de20(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001e260 FUN_0001e260 */

uint FUN_0001e260(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_2824;
  undefined auStack_2820 [8192];
  undefined auStack_820 [2048];
  
  FUN_00036068(auStack_2820,0x2000);
  local_2824 = 0xb00000b;
  uVar1 = FUN_0001dc3c(&local_2824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001de20(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_2824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001e2fc FUN_0001e2fc */

undefined4
FUN_0001e2fc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  FUN_00036044(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    return 0xffffffff;
  }
  uVar1 = FUN_0001e368(param_1,param_2,param_3,param_4,param_5);
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001e368 FUN_0001e368 */

uint FUN_0001e368(undefined *param_1,uint param_2,ushort *param_3,uint param_4,int param_5)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  byte bVar4;
  undefined *puVar5;
  undefined *puVar6;
  undefined *puVar7;
  uint uVar8;
  undefined *puVar9;
  undefined *puVar10;
  byte bVar11;
  uint *puVar12;
  int iVar13;
  uint *puVar14;
  undefined *puVar15;
  uint *puVar16;
  undefined *puVar17;
  uint uVar18;
  uint uVar19;
  undefined *puVar20;
  undefined *puVar21;
  uint uVar22;
  uint uVar23;
  uint *puVar24;
  bool bVar25;
  byte bVar26;
  bool bVar27;
  uint local_8c;
  uint local_74;
  uint local_70;
  uint *local_6c;
  uint local_60;
  uint local_5c;
  uint *local_58;
  uint *local_54;
  uint *local_50;
  uint local_4c;
  uint local_48;
  uint *local_44;
  uint *local_40;
  uint *local_3c;
  uint local_38;
  uint local_34;
  uint *local_30;
  uint *local_2c;
  uint *local_28;
  
  if (param_4 < 10) {
    return 0xffffffec;
  }
  uVar23 = (uint)param_3[2];
  uVar22 = (uint)param_3[1];
  uVar18 = (uint)*param_3;
  FUN_00036044(&local_38,param_5,4);
  uVar2 = uVar18 + 6 + uVar22 + uVar23;
  uVar3 = param_4 - uVar2;
  if (param_4 < uVar2) {
    return 0xffffffec;
  }
  if (uVar18 == 0) {
    puVar16 = &local_38;
    goto LAB_0001e680;
  }
  uVar2 = local_38 >> 0x10;
  local_2c = (uint *)(param_3 + 3);
  local_28 = (uint *)(param_3 + 5);
  if (uVar18 < 4) {
    local_38 = (uint)*(byte *)local_2c;
    if (uVar18 == 2) {
LAB_0001e45c:
      local_38 = local_38 + (uint)*(byte *)((int)param_3 + 7) * 0x100;
    }
    else if (uVar18 == 3) {
      local_38 = local_38 | (uint)*(byte *)(param_3 + 4) << 0x10;
      goto LAB_0001e45c;
    }
    uVar8 = (uint)*(byte *)((int)local_2c + (uVar18 - 1));
    if (uVar8 == 0) {
      return 0xffffffec;
    }
    uVar19 = LZCOUNT(uVar8) + uVar18 * -8 + 9;
    uVar8 = 6;
    local_30 = local_2c;
  }
  else {
    uVar8 = uVar18 + 2;
    local_38 = *(uint *)((int)param_3 + uVar8);
    uVar19 = (uint)*(byte *)((int)local_2c + (uVar18 - 1));
    if (uVar19 == 0) {
      return 0xffffffff;
    }
    uVar19 = LZCOUNT(uVar19) - 0x17;
    local_30 = (uint *)((int)param_3 + uVar8);
  }
  local_34 = uVar19;
  if (uVar22 == 0) {
    puVar16 = &local_4c;
    goto LAB_0001e680;
  }
  local_40 = (uint *)((int)param_3 + uVar18 + 6);
  puVar24 = (uint *)((int)local_40 + uVar22);
  local_3c = local_40 + 1;
  if (uVar22 < 4) {
    local_4c = (uint)*(byte *)local_40;
    if (uVar22 == 2) {
LAB_0001e510:
      local_4c = local_4c + (uint)*(byte *)((int)local_40 + 1) * 0x100;
    }
    else if (uVar22 == 3) {
      local_4c = local_4c | (uint)*(byte *)((int)local_40 + 2) << 0x10;
      goto LAB_0001e510;
    }
    if (*(byte *)((int)puVar24 + -1) == 0) {
      return 0xffffffec;
    }
    uVar18 = 0;
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar24 + -1)) + uVar22 * -8 + 9;
    local_44 = local_40;
  }
  else {
    uVar18 = uVar22 - 4;
    local_4c = *(uint *)((int)local_40 + uVar18);
    if (*(byte *)((int)puVar24 + -1) == 0) {
      return 0xffffffff;
    }
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar24 + -1)) - 0x17;
    local_44 = (uint *)((int)local_40 + uVar18);
  }
  if (uVar23 == 0) {
    puVar16 = &local_60;
    goto LAB_0001e680;
  }
  puVar16 = (uint *)((int)puVar24 + uVar23);
  local_50 = puVar24 + 1;
  if (uVar23 < 4) {
    local_60 = (uint)*(byte *)puVar24;
    if (uVar23 == 2) {
LAB_0001e5d4:
      local_60 = local_60 + (uint)*(byte *)((int)puVar24 + 1) * 0x100;
    }
    else if (uVar23 == 3) {
      local_60 = local_60 | (uint)*(byte *)((int)puVar24 + 2) << 0x10;
      goto LAB_0001e5d4;
    }
    if (*(byte *)((int)puVar16 + -1) == 0) {
      return 0xffffffec;
    }
    local_5c = LZCOUNT((uint)*(byte *)((int)puVar16 + -1)) + uVar23 * -8 + 9;
    uVar23 = 0;
    local_58 = puVar24;
  }
  else {
    uVar23 = uVar23 - 4;
    local_60 = *(uint *)((int)puVar24 + uVar23);
    if (*(byte *)((int)puVar16 + -1) == 0) {
      return 0xffffffff;
    }
    local_5c = LZCOUNT((uint)*(byte *)((int)puVar16 + -1)) - 0x17;
    local_58 = (uint *)((int)puVar24 + uVar23);
  }
  if (uVar3 == 0) {
    puVar16 = &local_74;
    local_54 = puVar24;
LAB_0001e680:
    FUN_00036050(puVar16,0,0x14);
    return 0xffffffb8;
  }
  puVar12 = puVar16 + 1;
  if (3 < uVar3) {
    local_8c = uVar3 - 4;
    local_74 = *(uint *)((int)puVar16 + local_8c);
    uVar22 = (uint)*(byte *)((int)puVar16 + (uVar3 - 1));
    if (uVar22 == 0) {
      return 0xffffffff;
    }
    local_70 = LZCOUNT(uVar22) - 0x17;
    local_6c = (uint *)((int)puVar16 + local_8c);
    if (0xffffff88 < uVar3) {
      return uVar3;
    }
    goto LAB_0001e6f4;
  }
  local_74 = (uint)*(byte *)puVar16;
  if (uVar3 == 2) {
LAB_0001e6c0:
    local_74 = local_74 + (uint)*(byte *)((int)puVar16 + 1) * 0x100;
  }
  else if (uVar3 == 3) {
    local_74 = local_74 | (uint)*(byte *)((int)puVar16 + 2) << 0x10;
    goto LAB_0001e6c0;
  }
  uVar22 = (uint)*(byte *)((int)puVar16 + (uVar3 - 1));
  if (uVar22 == 0) {
    return 0xffffffec;
  }
  local_70 = LZCOUNT(uVar22) + uVar3 * -8 + 9;
  local_8c = 0;
  local_6c = puVar16;
LAB_0001e6f4:
  uVar3 = 3;
  if (uVar19 < 0x21) {
    if (uVar8 < 10) {
      if (uVar8 == 6) {
        uVar22 = 2;
        if (uVar19 < 0x20) {
          uVar22 = 1;
        }
      }
      else {
        iVar13 = uVar8 - (uVar19 >> 3);
        uVar22 = uVar19 >> 3;
        if (iVar13 < 6) {
          uVar22 = uVar8 - 6;
        }
        local_30 = (uint *)((int)param_3 + (uVar8 - uVar22));
        local_34 = uVar19 + uVar22 * -8;
        local_38 = *(uint *)((int)param_3 + (uVar8 - uVar22));
        uVar22 = 0;
        if (iVar13 < 6) {
          uVar22 = 1;
        }
      }
    }
    else {
      local_34 = uVar19 & 7;
      local_30 = (uint *)((int)param_3 + (uVar8 - (uVar19 >> 3)));
      local_38 = *(uint *)((int)param_3 + (uVar8 - (uVar19 >> 3)));
      uVar22 = 0;
    }
  }
  else {
    uVar22 = 3;
  }
  uVar8 = param_2 + 3;
  if (local_48 < 0x21) {
    if ((int)uVar18 < 4) {
      if (uVar18 == 0) {
        uVar3 = 2;
        bVar25 = 0x1f < local_48;
      }
      else {
        puVar14 = (uint *)((int)local_40 + (uVar18 - (local_48 >> 3)));
        uVar3 = uVar18;
        if (local_40 <= puVar14) {
          uVar3 = local_48 >> 3;
        }
        local_44 = (uint *)((int)local_40 + (uVar18 - uVar3));
        local_48 = local_48 + uVar3 * -8;
        local_4c = *(uint *)((int)local_40 + (uVar18 - uVar3));
        uVar3 = 0;
        bVar25 = local_40 <= puVar14;
      }
      if (!bVar25) {
        uVar3 = 1;
      }
    }
    else {
      local_44 = (uint *)((int)local_40 + (uVar18 - (local_48 >> 3)));
      local_4c = *(uint *)((int)local_40 + (uVar18 - (local_48 >> 3)));
      uVar3 = 0;
      local_48 = local_48 & 7;
    }
  }
  puVar17 = param_1 + (uVar8 >> 2);
  uVar18 = 3;
  uVar19 = 3;
  if (local_5c < 0x21) {
    if ((int)uVar23 < 4) {
      if (uVar23 == 0) {
        uVar19 = 2;
        bVar25 = 0x1f < local_5c;
      }
      else {
        puVar14 = (uint *)((int)puVar24 + (uVar23 - (local_5c >> 3)));
        uVar19 = uVar23;
        if (puVar24 <= puVar14) {
          uVar19 = local_5c >> 3;
        }
        local_58 = (uint *)((int)puVar24 + (uVar23 - uVar19));
        local_5c = local_5c + uVar19 * -8;
        local_60 = *(uint *)((int)puVar24 + (uVar23 - uVar19));
        uVar19 = 0;
        bVar25 = puVar24 <= puVar14;
      }
      if (!bVar25) {
        uVar19 = 1;
      }
    }
    else {
      local_58 = (uint *)((int)puVar24 + (uVar23 - (local_5c >> 3)));
      local_60 = *(uint *)((int)puVar24 + (uVar23 - (local_5c >> 3)));
      uVar19 = 0;
      local_5c = local_5c & 7;
    }
  }
  puVar20 = puVar17 + (uVar8 >> 2);
  if (local_70 < 0x21) {
    if ((int)local_8c < 4) {
      if (local_8c == 0) {
        uVar18 = 2;
        bVar25 = 0x1f < local_70;
      }
      else {
        puVar14 = (uint *)((int)puVar16 + (local_8c - (local_70 >> 3)));
        uVar23 = local_8c;
        if (puVar16 <= puVar14) {
          uVar23 = local_70 >> 3;
        }
        local_6c = (uint *)((int)puVar16 + (local_8c - uVar23));
        local_70 = local_70 + uVar23 * -8;
        bVar25 = puVar16 <= puVar14;
        local_74 = *(uint *)((int)puVar16 + (local_8c - uVar23));
        uVar18 = 0;
      }
      if (!bVar25) {
        uVar18 = 1;
      }
    }
    else {
      local_6c = (uint *)((int)puVar16 + (local_8c - (local_70 >> 3)));
      local_74 = *(uint *)((int)puVar16 + (local_8c - (local_70 >> 3)));
      uVar18 = 0;
      local_70 = local_70 & 7;
    }
  }
  puVar9 = param_1 + param_2;
  param_5 = param_5 + 4;
  puVar21 = puVar20 + (uVar8 >> 2);
  puVar10 = puVar21;
  puVar15 = puVar20;
  puVar5 = puVar17;
  if (((uVar3 | uVar22 | uVar19 | uVar18) == 0) && (puVar21 < puVar9 + -7)) {
    uVar8 = uVar8 >> 2;
    iVar13 = uVar8 * 3;
    uVar3 = -uVar2 & 0x1f;
    while( true ) {
      puVar5 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar3) * 2);
      local_34 = local_34 + (byte)puVar5[1];
      *param_1 = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar3) * 2);
      local_48 = local_48 + (byte)puVar5[1];
      param_1[uVar8] = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar3) * 2);
      local_5c = local_5c + (byte)puVar5[1];
      param_1[uVar8 * 2] = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar3) * 2);
      local_70 = local_70 + (byte)puVar5[1];
      param_1[iVar13] = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar3) * 2);
      local_34 = local_34 + (byte)puVar5[1];
      param_1[1] = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar3) * 2);
      local_48 = local_48 + (byte)puVar5[1];
      (param_1 + uVar8)[1] = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar3) * 2);
      local_5c = local_5c + (byte)puVar5[1];
      param_1[uVar8 * 2 + 1] = *puVar5;
      puVar5 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar3) * 2);
      local_70 = local_70 + (byte)puVar5[1];
      param_1[iVar13 + 1] = *puVar5;
      bVar4 = 3;
      if (local_34 < 0x21) {
        if (local_30 < local_28) {
          if (local_30 == local_2c) {
            bVar26 = 2;
            if (local_34 < 0x20) {
              bVar26 = 1;
            }
          }
          else {
            puVar14 = (uint *)((int)local_30 - (local_34 >> 3));
            uVar23 = local_34 >> 3;
            if (puVar14 < local_2c) {
              uVar23 = (int)local_30 - (int)local_2c;
            }
            local_34 = local_34 + uVar23 * -8;
            local_38 = *(uint *)((int)local_30 - uVar23);
            bVar26 = puVar14 < local_2c;
            local_30 = (uint *)((int)local_30 - uVar23);
          }
        }
        else {
          uVar23 = local_34 >> 3;
          local_38 = *(uint *)((int)local_30 - (local_34 >> 3));
          bVar26 = 0;
          local_34 = local_34 & 7;
          local_30 = (uint *)((int)local_30 - uVar23);
        }
      }
      else {
        bVar26 = 3;
      }
      if (local_48 < 0x21) {
        if (local_44 < local_3c) {
          if (local_44 == local_40) {
            bVar25 = 0x1f < local_48;
            bVar4 = 2;
          }
          else {
            puVar14 = (uint *)((int)local_44 - (local_48 >> 3));
            uVar23 = local_48 >> 3;
            if (puVar14 < local_40) {
              uVar23 = (int)local_44 - (int)local_40;
            }
            bVar25 = local_40 <= puVar14;
            local_48 = local_48 + uVar23 * -8;
            local_4c = *(uint *)((int)local_44 - uVar23);
            bVar4 = 0;
            local_44 = (uint *)((int)local_44 - uVar23);
          }
          if (!bVar25) {
            bVar4 = 1;
          }
        }
        else {
          uVar23 = local_48 >> 3;
          local_4c = *(uint *)((int)local_44 - (local_48 >> 3));
          bVar4 = 0;
          local_48 = local_48 & 7;
          local_44 = (uint *)((int)local_44 - uVar23);
        }
      }
      bVar1 = 3;
      bVar11 = 3;
      if (local_5c < 0x21) {
        if (local_58 < local_50) {
          if (local_58 == puVar24) {
            bVar25 = 0x1f < local_5c;
            bVar11 = 2;
          }
          else {
            puVar14 = (uint *)((int)local_58 - (local_5c >> 3));
            uVar23 = local_5c >> 3;
            if (puVar14 < puVar24) {
              uVar23 = (int)local_58 - (int)puVar24;
            }
            bVar25 = puVar24 <= puVar14;
            local_5c = local_5c + uVar23 * -8;
            local_60 = *(uint *)((int)local_58 - uVar23);
            bVar11 = 0;
            local_58 = (uint *)((int)local_58 - uVar23);
          }
          if (!bVar25) {
            bVar11 = 1;
          }
        }
        else {
          uVar23 = local_5c >> 3;
          local_60 = *(uint *)((int)local_58 - (local_5c >> 3));
          bVar11 = 0;
          local_5c = local_5c & 7;
          local_58 = (uint *)((int)local_58 - uVar23);
        }
      }
      if (local_70 < 0x21) {
        if (local_6c < puVar12) {
          if (local_6c == puVar16) {
            bVar25 = 0x1f < local_70;
            bVar1 = 2;
          }
          else {
            puVar14 = (uint *)((int)local_6c - (local_70 >> 3));
            uVar23 = local_70 >> 3;
            if (puVar14 < puVar16) {
              uVar23 = (int)local_6c - (int)puVar16;
            }
            bVar25 = puVar16 <= puVar14;
            local_70 = local_70 + uVar23 * -8;
            local_74 = *(uint *)((int)local_6c - uVar23);
            bVar1 = 0;
            local_6c = (uint *)((int)local_6c - uVar23);
          }
          if (!bVar25) {
            bVar1 = 1;
          }
        }
        else {
          uVar23 = local_70 >> 3;
          local_74 = *(uint *)((int)local_6c - (local_70 >> 3));
          bVar1 = 0;
          local_70 = local_70 & 7;
          local_6c = (uint *)((int)local_6c - uVar23);
        }
      }
      puVar10 = param_1 + iVar13 + 2;
      if (((byte)(bVar4 | bVar26 | bVar11 | bVar1) != 0) || (puVar9 + -7 <= puVar10)) break;
      param_1 = param_1 + 2;
    }
    puVar15 = param_1 + uVar8 * 2 + 2;
    puVar5 = param_1 + uVar8 + 2;
    param_1 = param_1 + 2;
  }
  bVar27 = puVar21 <= puVar15;
  bVar25 = puVar15 == puVar21;
  if (!bVar27 || bVar25) {
    bVar27 = puVar20 <= puVar5;
    bVar25 = puVar5 == puVar20;
  }
  if (bVar27 && !bVar25) {
    return 0xffffffec;
  }
  if (puVar17 < param_1) {
    return 0xffffffec;
  }
  uVar2 = -uVar2 & 0x1f;
  puVar6 = param_1;
  if (local_34 < 0x21) {
    do {
      if (local_30 < local_28) {
        puVar6 = param_1;
        if (local_30 == local_2c) goto LAB_0001f0b4;
        uVar3 = local_34 >> 3;
        bVar25 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
        if (bVar25) {
          uVar3 = (int)local_30 - (int)local_2c;
        }
        local_34 = local_34 + uVar3 * -8;
      }
      else {
        uVar3 = local_34 >> 3;
        local_34 = local_34 & 7;
        bVar25 = false;
      }
      local_30 = (uint *)((int)local_30 - uVar3);
      local_38 = *local_30;
      if ((puVar17 + -4 < param_1) || (bVar25)) goto LAB_0001f0ac;
      puVar6 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2);
      local_34 = local_34 + (byte)puVar6[1];
      *param_1 = *puVar6;
      puVar6 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2);
      local_34 = local_34 + (byte)puVar6[1];
      param_1[1] = *puVar6;
      param_1 = param_1 + 2;
      puVar6 = param_1;
    } while (local_34 < 0x21);
  }
joined_r0x0001f154:
  if (puVar6 < puVar17) {
    puVar7 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2);
    local_34 = local_34 + (byte)puVar7[1];
    *puVar6 = *puVar7;
    while (puVar6 = puVar6 + 1, puVar6 != puVar17) {
      puVar7 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2);
      local_34 = local_34 + (byte)puVar7[1];
      *puVar6 = *puVar7;
    }
  }
  if (local_48 < 0x21) {
    do {
      if (local_44 < local_3c) {
        puVar17 = puVar5;
        if (local_44 == local_40) goto LAB_0001f2c0;
        uVar3 = local_48 >> 3;
        bVar25 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
        if (bVar25) {
          uVar3 = (int)local_44 - (int)local_40;
        }
        local_48 = local_48 + uVar3 * -8;
      }
      else {
        uVar3 = local_48 >> 3;
        local_48 = local_48 & 7;
        bVar25 = false;
      }
      local_44 = (uint *)((int)local_44 - uVar3);
      local_4c = *local_44;
      if ((puVar20 + -4 < puVar5) || (bVar25)) goto LAB_0001f2b8;
      puVar17 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2);
      local_48 = local_48 + (byte)puVar17[1];
      *puVar5 = *puVar17;
      puVar17 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2);
      local_48 = local_48 + (byte)puVar17[1];
      puVar5[1] = *puVar17;
      puVar5 = puVar5 + 2;
    } while (local_48 < 0x21);
  }
joined_r0x0001f368:
  if (puVar5 < puVar20) {
    puVar17 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2);
    local_48 = local_48 + (byte)puVar17[1];
    *puVar5 = *puVar17;
    while (puVar5 = puVar5 + 1, puVar5 != puVar20) {
      puVar17 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2);
      local_48 = local_48 + (byte)puVar17[1];
      *puVar5 = *puVar17;
    }
  }
  if (local_5c < 0x21) {
    do {
      if (local_58 < local_50) {
        puVar17 = puVar15;
        if (local_58 == puVar24) goto LAB_0001f4cc;
        uVar3 = local_5c >> 3;
        bVar25 = (uint *)((int)local_58 - (local_5c >> 3)) < puVar24;
        if (bVar25) {
          uVar3 = (int)local_58 - (int)puVar24;
        }
        local_5c = local_5c + uVar3 * -8;
      }
      else {
        uVar3 = local_5c >> 3;
        local_5c = local_5c & 7;
        bVar25 = false;
      }
      local_58 = (uint *)((int)local_58 - uVar3);
      local_60 = *local_58;
      if ((puVar21 + -4 < puVar15) || (bVar25)) goto LAB_0001f4c4;
      puVar17 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2);
      local_5c = local_5c + (byte)puVar17[1];
      *puVar15 = *puVar17;
      puVar17 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2);
      local_5c = local_5c + (byte)puVar17[1];
      puVar15[1] = *puVar17;
      puVar15 = puVar15 + 2;
    } while (local_5c < 0x21);
  }
joined_r0x0001f574:
  if (puVar15 < puVar21) {
    puVar17 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2);
    local_5c = local_5c + (byte)puVar17[1];
    *puVar15 = *puVar17;
    while (puVar15 = puVar15 + 1, puVar15 != puVar21) {
      puVar17 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2);
      local_5c = local_5c + (byte)puVar17[1];
      *puVar15 = *puVar17;
    }
  }
  if (local_70 < 0x21) {
    do {
      if (local_6c < puVar12) {
        puVar17 = puVar10;
        if (local_6c == puVar16) goto LAB_0001f69c;
        uVar3 = local_70 >> 3;
        bVar25 = (uint *)((int)local_6c - (local_70 >> 3)) < puVar16;
        if (bVar25) {
          uVar3 = (int)local_6c - (int)puVar16;
        }
        local_70 = local_70 + uVar3 * -8;
      }
      else {
        uVar3 = local_70 >> 3;
        local_70 = local_70 & 7;
        bVar25 = false;
      }
      local_6c = (uint *)((int)local_6c - uVar3);
      local_74 = *local_6c;
      if ((puVar9 + -4 < puVar10) || (bVar25)) goto LAB_0001f694;
      puVar17 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2);
      local_70 = local_70 + (byte)puVar17[1];
      *puVar10 = *puVar17;
      puVar17 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2);
      local_70 = local_70 + (byte)puVar17[1];
      puVar10[1] = *puVar17;
      puVar10 = puVar10 + 2;
    } while (local_70 < 0x21);
  }
joined_r0x0001f73c:
  if (puVar10 < puVar9) {
    puVar17 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2);
    local_70 = local_70 + (byte)puVar17[1];
    *puVar10 = *puVar17;
    while (puVar10 = puVar10 + 1, puVar10 != puVar9) {
      puVar17 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2);
      local_70 = local_70 + (byte)puVar17[1];
      *puVar10 = *puVar17;
    }
  }
  if ((((local_44 != local_40 || local_48 != 0x20) || (local_30 != local_2c || local_34 != 0x20)) ||
      (local_58 != puVar24 || local_5c != 0x20)) || (local_6c != puVar16 || local_70 != 0x20)) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_0001f0ac:
  puVar6 = param_1;
  if (0x20 < local_34) goto joined_r0x0001f154;
LAB_0001f0b4:
  if (local_30 < local_28) {
    if (local_30 == local_2c) goto joined_r0x0001f154;
    uVar3 = local_34 >> 3;
    bVar25 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
    if (bVar25) {
      uVar3 = (int)local_30 - (int)local_2c;
    }
    local_34 = local_34 + uVar3 * -8;
  }
  else {
    uVar3 = local_34 >> 3;
    local_34 = local_34 & 7;
    bVar25 = false;
  }
  local_30 = (uint *)((int)local_30 - uVar3);
  local_38 = *local_30;
  if ((puVar17 <= puVar6) || (bVar25)) goto joined_r0x0001f154;
  puVar7 = (undefined *)(param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2);
  local_34 = local_34 + (byte)puVar7[1];
  param_1 = puVar6 + 1;
  *puVar6 = *puVar7;
  goto LAB_0001f0ac;
LAB_0001f2b8:
  puVar17 = puVar5;
  if (0x20 < local_48) goto joined_r0x0001f368;
LAB_0001f2c0:
  puVar5 = puVar17;
  if (local_44 < local_3c) {
    if (local_44 == local_40) goto joined_r0x0001f368;
    uVar3 = local_48 >> 3;
    bVar25 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
    if (bVar25) {
      uVar3 = (int)local_44 - (int)local_40;
    }
    local_48 = local_48 + uVar3 * -8;
  }
  else {
    uVar3 = local_48 >> 3;
    local_48 = local_48 & 7;
    bVar25 = false;
  }
  local_44 = (uint *)((int)local_44 - uVar3);
  local_4c = *local_44;
  if ((puVar20 <= puVar17) || (bVar25)) goto joined_r0x0001f368;
  puVar6 = (undefined *)(param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2);
  local_48 = local_48 + (byte)puVar6[1];
  puVar5 = puVar17 + 1;
  *puVar17 = *puVar6;
  goto LAB_0001f2b8;
LAB_0001f4c4:
  puVar17 = puVar15;
  if (0x20 < local_5c) goto joined_r0x0001f574;
LAB_0001f4cc:
  puVar15 = puVar17;
  if (local_58 < local_50) {
    if (local_58 == puVar24) goto joined_r0x0001f574;
    uVar3 = local_5c >> 3;
    bVar25 = (uint *)((int)local_58 - (local_5c >> 3)) < puVar24;
    if (bVar25) {
      uVar3 = (int)local_58 - (int)puVar24;
    }
    local_5c = local_5c + uVar3 * -8;
  }
  else {
    uVar3 = local_5c >> 3;
    local_5c = local_5c & 7;
    bVar25 = false;
  }
  local_58 = (uint *)((int)local_58 - uVar3);
  local_60 = *local_58;
  if ((puVar21 <= puVar17) || (bVar25)) goto joined_r0x0001f574;
  puVar20 = (undefined *)(param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2);
  local_5c = local_5c + (byte)puVar20[1];
  puVar15 = puVar17 + 1;
  *puVar17 = *puVar20;
  goto LAB_0001f4c4;
LAB_0001f694:
  puVar17 = puVar10;
  if (0x20 < local_70) goto joined_r0x0001f73c;
LAB_0001f69c:
  puVar10 = puVar17;
  if (local_6c < puVar12) {
    if (local_6c == puVar16) goto joined_r0x0001f73c;
    uVar3 = local_70 >> 3;
    bVar25 = (uint *)((int)local_6c - (local_70 >> 3)) < puVar16;
    if (bVar25) {
      uVar3 = (int)local_6c - (int)puVar16;
    }
    local_70 = local_70 + uVar3 * -8;
  }
  else {
    uVar3 = local_70 >> 3;
    local_70 = local_70 & 7;
    bVar25 = false;
  }
  local_6c = (uint *)((int)local_6c - uVar3);
  local_74 = *local_6c;
  if ((puVar9 <= puVar17) || (bVar25)) goto joined_r0x0001f73c;
  puVar20 = (undefined *)(param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2);
  local_70 = local_70 + (byte)puVar20[1];
  puVar10 = puVar17 + 1;
  *puVar17 = *puVar20;
  goto LAB_0001f694;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001f744 FUN_0001f744 */

uint FUN_0001f744(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_0001dc3c(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001e368(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001f7c0 FUN_0001f7c0 */

uint FUN_0001f7c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_0001dc3c(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001e368(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001f840 FUN_0001f840 */

uint FUN_0001f840(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_2824;
  undefined auStack_2820 [8192];
  undefined auStack_820 [2048];
  
  FUN_00036068(auStack_2820,0x2000);
  local_2824 = 0xb00000b;
  uVar1 = FUN_0001dc3c(&local_2824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001e368(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_2824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001f8dc FUN_0001f8dc */

uint FUN_0001f8dc(int param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  byte bVar1;
  undefined uVar2;
  uint uVar3;
  uint *puVar4;
  int iVar5;
  byte *pbVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  int iVar14;
  undefined *puVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint *puVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  int iVar23;
  int *piVar24;
  undefined4 local_98;
  uint local_94;
  uint local_90;
  uint auStack_8c [13];
  uint local_58 [13];
  
  FUN_00036044(local_58,param_1,4);
  uVar11 = 0xffffffd4;
  local_98 = local_58[0];
  uVar21 = uVar11;
  if (0x5db < param_5) {
    uVar20 = local_58[0] & 0xff;
    FUN_00036050(param_4 + 0x270,0,0x6c);
    if (uVar20 < 0xd) {
      uVar3 = FUN_0001da84(param_4 + 0x4dc,0x100,param_4 + 0x270,&local_94,&local_90,param_2,param_3
                          );
      uVar21 = uVar3;
      if ((uVar3 < 0xffffff89) && (uVar21 = uVar11, local_90 <= uVar20)) {
        iVar7 = param_4 + 0x2dc;
        piVar24 = (int *)(param_4 + 0x2a8);
        uVar21 = uVar20 + 1;
        iVar23 = 0;
        iVar5 = local_90 + 0x9c;
        iVar14 = -2;
        do {
          iVar10 = iVar14;
          iVar8 = iVar5;
          uVar21 = uVar21 - 1;
          iVar23 = iVar23 + 0x34;
          iVar5 = iVar8 + -1;
          iVar14 = iVar10 + 1;
        } while (*(int *)(param_4 + iVar8 * 4) == 0);
        uVar11 = iVar8 - 0x9b;
        iVar8 = iVar8 + -0x9c;
        iVar5 = 0;
        if (1 < uVar11) {
          iVar14 = 0;
          iVar5 = 0;
          do {
            iVar12 = param_4 + iVar14 * 4;
            iVar14 = iVar14 + 1;
            *(int *)(iVar12 + 0x2ac) = iVar5;
            iVar5 = *(int *)(iVar12 + 0x274) + iVar5;
          } while (iVar8 != iVar14);
        }
        *piVar24 = iVar5;
        if (local_94 != 0) {
          uVar13 = 0;
          do {
            bVar1 = *(byte *)(param_4 + 0x4dc + uVar13);
            iVar14 = piVar24[bVar1];
            piVar24[bVar1] = iVar14 + 1;
            puVar15 = (undefined *)(iVar7 + iVar14 * 2);
            *puVar15 = (char)uVar13;
            uVar13 = uVar13 + 1;
            puVar15[1] = bVar1;
          } while (uVar13 < local_94);
        }
        iVar14 = 0;
        *piVar24 = 0;
        if (1 < uVar11) {
          iVar12 = 0;
          do {
            iVar9 = param_4 + iVar14 * 4;
            uVar13 = (uVar20 - local_90) + iVar14;
            iVar14 = iVar14 + 1;
            *(int *)(iVar9 + 4) = iVar12;
            iVar12 = iVar12 + (*(int *)(iVar9 + 0x274) << (uVar13 & 0xff));
          } while (iVar8 != iVar14);
        }
        uVar13 = iVar10 + 3;
        if (uVar13 < uVar21) {
          uVar17 = uVar13;
          do {
            if (1 < uVar11) {
              iVar14 = 0;
              do {
                *(uint *)(param_4 + 4 + iVar23 + iVar14 * 4) =
                     *(uint *)(param_4 + 4 + iVar14 * 4) >> (uVar17 & 0xff);
                iVar14 = iVar14 + 1;
              } while (iVar8 != iVar14);
            }
            uVar17 = uVar17 + 1;
            iVar23 = iVar23 + 0x34;
          } while (uVar21 != uVar17);
        }
        FUN_00036044(auStack_8c,param_4,0x34);
        if (iVar5 != 0) {
          iVar23 = local_90 + 1;
          iVar14 = 0;
          do {
            pbVar6 = (byte *)(iVar7 + iVar14 * 2);
            bVar1 = *pbVar6;
            uVar17 = (uint)pbVar6[1];
            uVar22 = iVar23 - uVar17;
            uVar11 = auStack_8c[uVar17];
            uVar21 = uVar20 - uVar22;
            iVar8 = 1 << (uVar21 & 0xff);
            if (uVar21 < uVar13) {
              uVar21 = iVar8 + uVar11;
              if (uVar11 < uVar21) {
                puVar4 = (uint *)(param_1 + 4 + uVar11 * 4);
                do {
                  *puVar4 = (uint)bVar1 | (uVar22 & 0xff) << 0x10 | 0x1000000;
                  iVar8 = iVar8 + -1;
                  puVar4 = puVar4 + 1;
                } while (iVar8 != 0);
              }
            }
            else {
              iVar12 = uVar22 + (iVar23 - uVar20);
              iVar10 = 1;
              if (1 < iVar12) {
                iVar10 = iVar12;
              }
              iVar9 = *(int *)(param_4 + 0x2a4 + iVar10 * 4);
              FUN_00036044(local_58,uVar22 * 0x34 + param_4,0x34);
              puVar4 = (uint *)(param_1 + 4 + uVar11 * 4);
              if ((1 < iVar12) && (uVar11 = local_58[iVar10], uVar11 != 0)) {
                puVar19 = puVar4;
                do {
                  *puVar19 = (uint)bVar1 | (uVar22 & 0xff) << 0x10 | 0x1000000;
                  uVar11 = uVar11 - 1;
                  puVar19 = puVar19 + 1;
                } while (uVar11 != 0);
              }
              if (iVar5 != iVar9) {
                iVar10 = 0;
                do {
                  puVar15 = (undefined *)(iVar7 + iVar9 * 2 + iVar10 * 2);
                  uVar2 = *puVar15;
                  uVar11 = (uint)(byte)puVar15[1];
                  uVar16 = local_58[uVar11];
                  uVar18 = uVar16 + (1 << (uVar21 - (iVar23 - uVar11) & 0xff));
                  do {
                    puVar4[uVar16] =
                         (uint)CONCAT11(uVar2,bVar1) | ((iVar23 - uVar11) + uVar22 & 0xff) << 0x10 |
                         0x2000000;
                    uVar16 = uVar16 + 1;
                  } while (uVar16 < uVar18);
                  iVar10 = iVar10 + 1;
                  local_58[uVar11] = uVar18;
                } while (iVar10 != iVar5 - iVar9);
              }
              uVar21 = auStack_8c[uVar17] + iVar8;
            }
            iVar14 = iVar14 + 1;
            auStack_8c[uVar17] = uVar21;
          } while (iVar14 != iVar5);
        }
        local_98 = CONCAT22(CONCAT11(local_98._3_1_,(char)local_58[0]),
                            CONCAT11(1,(undefined)local_98));
        FUN_00036044(param_1,&local_98,4);
        uVar21 = uVar3;
      }
    }
  }
  return uVar21;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001fd24 FUN_0001fd24 */

void FUN_0001fd24(void)

{
  FUN_0001f8dc();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001fd4c FUN_0001fd4c */

undefined4
FUN_0001fd4c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  FUN_00036044(&uStack_24,param_5,4);
  uVar1 = 0xffffffff;
  if (local_23 == '\x01') {
    uVar1 = FUN_0001fdb0(param_1,param_2,param_3,param_4,param_5);
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001fdb0 FUN_0001fdb0 */

uint FUN_0001fdb0(uint param_1,uint param_2,uint *param_3,uint param_4,int param_5)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  uint local_3c;
  uint local_38;
  uint *local_34;
  uint *local_30;
  uint *local_2c;
  undefined auStack_28 [2];
  ushort local_26;
  
  if (param_4 == 0) {
    FUN_00036050(&local_3c,0,0x14);
    return 0xffffffb8;
  }
  local_2c = param_3 + 1;
  if (3 < param_4) {
    local_34 = (uint *)((int)param_3 + (param_4 - 4));
    local_3c = *(uint *)((int)param_3 + (param_4 - 4));
    uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
    if (uVar1 == 0) {
      return 0xffffffff;
    }
    local_38 = LZCOUNT(uVar1) - 0x17;
    if (0xffffff88 < param_4) {
      return param_4;
    }
    goto LAB_0001fe84;
  }
  local_3c = (uint)*(byte *)param_3;
  if (param_4 == 2) {
LAB_0001fe58:
    local_3c = local_3c + (uint)*(byte *)((int)param_3 + 1) * 0x100;
  }
  else if (param_4 == 3) {
    local_3c = local_3c | (uint)*(byte *)((int)param_3 + 2) << 0x10;
    goto LAB_0001fe58;
  }
  uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
  if (uVar1 == 0) {
    return 0xffffffec;
  }
  local_38 = LZCOUNT(uVar1) + param_4 * -8 + 9;
  local_34 = param_3;
LAB_0001fe84:
  local_30 = param_3;
  FUN_00036044(auStack_28,param_5,4);
  uVar1 = param_1 + param_2;
  param_5 = param_5 + 4;
  if (local_38 < 0x21) {
    uVar2 = -(uint)local_26 & 0x1f;
    do {
      if (local_34 < local_2c) {
        if (local_34 == local_30) goto LAB_0001fff4;
        uVar3 = local_38 >> 3;
        bVar6 = (uint *)((int)local_34 - (local_38 >> 3)) < local_30;
        if (bVar6) {
          uVar3 = (int)local_34 - (int)local_30;
        }
        local_38 = local_38 + uVar3 * -8;
      }
      else {
        uVar3 = local_38 >> 3;
        local_38 = local_38 & 7;
        bVar6 = false;
      }
      local_34 = (uint *)((int)local_34 - uVar3);
      local_3c = *local_34;
      if ((uVar1 - 3 <= param_1) || (bVar6)) goto LAB_0001ffec;
      iVar5 = param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar2) * 4;
      FUN_00036044(param_1,iVar5,2);
      local_38 = local_38 + *(byte *)(iVar5 + 2);
      iVar5 = param_1 + *(byte *)(iVar5 + 3);
      iVar4 = param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar2) * 4;
      FUN_00036044(iVar5,iVar4,2);
      local_38 = local_38 + *(byte *)(iVar4 + 2);
      param_1 = iVar5 + (uint)*(byte *)(iVar4 + 3);
    } while (local_38 < 0x21);
  }
  else {
    uVar2 = -(uint)local_26 & 0x1f;
  }
LAB_000200dc:
  for (; param_1 <= uVar1 - 2; param_1 = param_1 + *(byte *)(iVar5 + 3)) {
    iVar5 = param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar2) * 4;
    FUN_00036044(param_1,iVar5,2);
    local_38 = local_38 + *(byte *)(iVar5 + 2);
  }
  if (param_1 < uVar1) {
    param_5 = param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar2) * 4;
    FUN_00036044(param_1,param_5,1);
    if (*(char *)(param_5 + 3) == '\x01') {
      local_38 = local_38 + *(byte *)(param_5 + 2);
    }
    else if ((local_38 < 0x20) && (local_38 = local_38 + *(byte *)(param_5 + 2), 0x1f < local_38)) {
      local_38 = 0x20;
    }
  }
  if (((uint)local_34 ^ (uint)local_30 | local_38 ^ 0x20) != 0) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_0001ffec:
  if (0x20 < local_38) goto LAB_000200dc;
LAB_0001fff4:
  if (local_34 < local_2c) {
    if (local_34 == local_30) goto LAB_000200dc;
    uVar3 = local_38 >> 3;
    bVar6 = (uint *)((int)local_34 - (local_38 >> 3)) < local_30;
    if (bVar6) {
      uVar3 = (int)local_34 - (int)local_30;
    }
    local_38 = local_38 + uVar3 * -8;
  }
  else {
    uVar3 = local_38 >> 3;
    local_38 = local_38 & 7;
    bVar6 = false;
  }
  local_34 = (uint *)((int)local_34 - uVar3);
  local_3c = *local_34;
  if ((uVar1 - 2 < param_1) || (bVar6)) goto LAB_000200dc;
  iVar5 = param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar2) * 4;
  FUN_00036044(param_1,iVar5,2);
  local_38 = local_38 + *(byte *)(iVar5 + 2);
  param_1 = param_1 + *(byte *)(iVar5 + 3);
  goto LAB_0001ffec;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00020174 FUN_00020174 */

uint FUN_00020174(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_0001f8dc(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001fdb0(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000201f0 FUN_000201f0 */

uint FUN_000201f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_0001f8dc(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001fdb0(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00020270 FUN_00020270 */

uint FUN_00020270(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_4824;
  undefined auStack_4820 [16384];
  undefined auStack_820 [2048];
  
  FUN_00036068(auStack_4820,0x4000);
  local_4824 = 0xc00000c;
  uVar1 = FUN_0001f8dc(&local_4824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_0001fdb0(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_4824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002030c FUN_0002030c */

undefined4
FUN_0002030c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  FUN_00036044(&uStack_24,param_5,4);
  uVar1 = 0xffffffff;
  if (local_23 == '\x01') {
    uVar1 = FUN_00020370(param_1,param_2,param_3,param_4,param_5);
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00020370 FUN_00020370 */

uint FUN_00020370(uint param_1,uint param_2,ushort *param_3,uint param_4,int param_5)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  byte bVar10;
  byte bVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint *puVar15;
  int iVar16;
  uint uVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  uint uVar21;
  int iVar22;
  uint uVar23;
  uint uVar24;
  bool bVar25;
  byte bVar26;
  bool bVar27;
  uint local_90;
  uint local_84;
  uint local_80;
  uint local_7c;
  uint local_74;
  uint local_70;
  uint *local_6c;
  uint *local_68;
  uint *local_64;
  uint local_60;
  uint local_5c;
  uint *local_58;
  uint *local_54;
  uint *local_50;
  uint local_4c;
  uint local_48;
  uint *local_44;
  uint *local_40;
  uint *local_3c;
  uint local_38;
  uint local_34;
  uint *local_30;
  uint *local_2c;
  uint *local_28;
  
  if (param_4 < 10) {
    return 0xffffffec;
  }
  uVar24 = (uint)param_3[2];
  uVar23 = (uint)param_3[1];
  uVar14 = (uint)*param_3;
  FUN_00036044(&local_38,param_5,4);
  uVar5 = uVar14 + 6 + uVar23 + uVar24;
  uVar6 = param_4 - uVar5;
  if (param_4 < uVar5) {
    return 0xffffffec;
  }
  if (uVar14 == 0) {
    puVar15 = &local_38;
    goto LAB_0002071c;
  }
  uVar5 = local_38 >> 0x10;
  local_2c = (uint *)(param_3 + 3);
  local_28 = (uint *)(param_3 + 5);
  if (uVar14 < 4) {
    local_38 = (uint)*(byte *)local_2c;
    if (uVar14 == 2) {
LAB_00020464:
      local_38 = local_38 + (uint)*(byte *)((int)param_3 + 7) * 0x100;
    }
    else if (uVar14 == 3) {
      local_38 = local_38 | (uint)*(byte *)(param_3 + 4) << 0x10;
      goto LAB_00020464;
    }
    uVar8 = (uint)*(byte *)((int)local_2c + (uVar14 - 1));
    if (uVar8 == 0) {
      return 0xffffffec;
    }
    uVar21 = LZCOUNT(uVar8) + uVar14 * -8 + 9;
    uVar8 = 6;
    local_30 = local_2c;
  }
  else {
    uVar8 = uVar14 + 2;
    local_38 = *(uint *)((int)param_3 + uVar8);
    uVar21 = (uint)*(byte *)((int)local_2c + (uVar14 - 1));
    if (uVar21 == 0) {
      return 0xffffffff;
    }
    uVar21 = LZCOUNT(uVar21) - 0x17;
    local_30 = (uint *)((int)param_3 + uVar8);
  }
  local_34 = uVar21;
  if (uVar23 == 0) {
    puVar15 = &local_4c;
    goto LAB_0002071c;
  }
  local_40 = (uint *)((int)param_3 + uVar14 + 6);
  puVar15 = (uint *)((int)local_40 + uVar23);
  local_3c = local_40 + 1;
  if (uVar23 < 4) {
    local_4c = (uint)*(byte *)local_40;
    if (uVar23 == 2) {
LAB_00020564:
      local_4c = local_4c + (uint)*(byte *)((int)local_40 + 1) * 0x100;
    }
    else if (uVar23 == 3) {
      local_4c = local_4c | (uint)*(byte *)((int)local_40 + 2) << 0x10;
      goto LAB_00020564;
    }
    if (*(byte *)((int)puVar15 + -1) == 0) {
      return 0xffffffec;
    }
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar15 + -1)) + uVar23 * -8 + 9;
    uVar23 = 0;
    local_44 = local_40;
  }
  else {
    uVar23 = uVar23 - 4;
    local_4c = *(uint *)((int)local_40 + uVar23);
    if (*(byte *)((int)puVar15 + -1) == 0) {
      return 0xffffffff;
    }
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar15 + -1)) - 0x17;
    local_44 = (uint *)((int)local_40 + uVar23);
  }
  if (uVar24 == 0) {
    puVar15 = &local_60;
    goto LAB_0002071c;
  }
  local_68 = (uint *)((int)puVar15 + uVar24);
  local_50 = puVar15 + 1;
  if (uVar24 < 4) {
    local_60 = (uint)*(byte *)puVar15;
    if (uVar24 == 2) {
LAB_00020664:
      local_60 = local_60 + (uint)*(byte *)((int)puVar15 + 1) * 0x100;
    }
    else if (uVar24 == 3) {
      local_60 = local_60 | (uint)*(byte *)((int)puVar15 + 2) << 0x10;
      goto LAB_00020664;
    }
    if (*(byte *)((int)local_68 + -1) == 0) {
      return 0xffffffec;
    }
    uVar14 = 0;
    local_5c = LZCOUNT((uint)*(byte *)((int)local_68 + -1)) + uVar24 * -8 + 9;
    local_58 = puVar15;
  }
  else {
    uVar14 = uVar24 - 4;
    local_60 = *(uint *)((int)puVar15 + uVar14);
    if (*(byte *)((int)local_68 + -1) == 0) {
      return 0xffffffff;
    }
    local_5c = LZCOUNT((uint)*(byte *)((int)local_68 + -1)) - 0x17;
    local_58 = (uint *)((int)puVar15 + uVar14);
  }
  local_54 = puVar15;
  if (uVar6 == 0) {
    puVar15 = &local_74;
LAB_0002071c:
    FUN_00036050(puVar15,0,0x14);
    return 0xffffffb8;
  }
  local_64 = local_68 + 1;
  if (3 < uVar6) {
    local_90 = uVar6 - 4;
    local_74 = *(uint *)((int)local_68 + local_90);
    uVar24 = (uint)*(byte *)((int)local_68 + (uVar6 - 1));
    if (uVar24 == 0) {
      return 0xffffffff;
    }
    local_70 = LZCOUNT(uVar24) - 0x17;
    local_6c = (uint *)((int)local_68 + local_90);
    if (0xffffff88 < uVar6) {
      return uVar6;
    }
    goto LAB_000207c4;
  }
  local_74 = (uint)*(byte *)local_68;
  if (uVar6 == 2) {
LAB_00020788:
    local_74 = local_74 + (uint)*(byte *)((int)local_68 + 1) * 0x100;
  }
  else if (uVar6 == 3) {
    local_74 = local_74 | (uint)*(byte *)((int)local_68 + 2) << 0x10;
    goto LAB_00020788;
  }
  uVar24 = (uint)*(byte *)((int)local_68 + (uVar6 - 1));
  if (uVar24 == 0) {
    return 0xffffffec;
  }
  local_70 = LZCOUNT(uVar24) + uVar6 * -8 + 9;
  local_90 = 0;
  local_6c = local_68;
LAB_000207c4:
  uVar6 = 3;
  if (uVar21 < 0x21) {
    if (uVar8 < 10) {
      if (uVar8 == 6) {
        uVar24 = 2;
        if (uVar21 < 0x20) {
          uVar24 = 1;
        }
      }
      else {
        iVar18 = uVar8 - (uVar21 >> 3);
        uVar24 = uVar21 >> 3;
        if (iVar18 < 6) {
          uVar24 = uVar8 - 6;
        }
        local_30 = (uint *)((int)param_3 + (uVar8 - uVar24));
        local_34 = uVar21 + uVar24 * -8;
        local_38 = *(uint *)((int)param_3 + (uVar8 - uVar24));
        uVar24 = 0;
        if (iVar18 < 6) {
          uVar24 = 1;
        }
      }
    }
    else {
      local_34 = uVar21 & 7;
      local_30 = (uint *)((int)param_3 + (uVar8 - (uVar21 >> 3)));
      local_38 = *(uint *)((int)param_3 + (uVar8 - (uVar21 >> 3)));
      uVar24 = 0;
    }
  }
  else {
    uVar24 = 3;
  }
  uVar8 = param_2 + 3;
  if (local_48 < 0x21) {
    if ((int)uVar23 < 4) {
      if (uVar23 == 0) {
        uVar6 = 2;
        bVar25 = 0x1f < local_48;
      }
      else {
        puVar9 = (uint *)((int)local_40 + (uVar23 - (local_48 >> 3)));
        uVar6 = uVar23;
        if (local_40 <= puVar9) {
          uVar6 = local_48 >> 3;
        }
        local_44 = (uint *)((int)local_40 + (uVar23 - uVar6));
        local_48 = local_48 + uVar6 * -8;
        bVar25 = local_40 <= puVar9;
        local_4c = *(uint *)((int)local_40 + (uVar23 - uVar6));
        uVar6 = 0;
      }
      if (!bVar25) {
        uVar6 = 1;
      }
    }
    else {
      local_44 = (uint *)((int)local_40 + (uVar23 - (local_48 >> 3)));
      local_4c = *(uint *)((int)local_40 + (uVar23 - (local_48 >> 3)));
      uVar6 = 0;
      local_48 = local_48 & 7;
    }
  }
  uVar21 = param_1 + (uVar8 >> 2);
  uVar23 = 3;
  uVar12 = 3;
  if (local_5c < 0x21) {
    if ((int)uVar14 < 4) {
      if (uVar14 == 0) {
        uVar12 = 2;
        bVar25 = 0x1f < local_5c;
      }
      else {
        puVar9 = (uint *)((int)puVar15 + (uVar14 - (local_5c >> 3)));
        uVar12 = uVar14;
        if (puVar15 <= puVar9) {
          uVar12 = local_5c >> 3;
        }
        local_58 = (uint *)((int)puVar15 + (uVar14 - uVar12));
        local_5c = local_5c + uVar12 * -8;
        bVar25 = puVar15 <= puVar9;
        local_60 = *(uint *)((int)puVar15 + (uVar14 - uVar12));
        uVar12 = 0;
      }
      if (!bVar25) {
        uVar12 = 1;
      }
    }
    else {
      local_58 = (uint *)((int)puVar15 + (uVar14 - (local_5c >> 3)));
      local_60 = *(uint *)((int)puVar15 + (uVar14 - (local_5c >> 3)));
      uVar12 = 0;
      local_5c = local_5c & 7;
    }
  }
  uVar14 = uVar21 + (uVar8 >> 2);
  uVar17 = param_1 + param_2;
  if (local_70 < 0x21) {
    if ((int)local_90 < 4) {
      if (local_90 == 0) {
        uVar23 = 2;
        bVar25 = 0x1f < local_70;
      }
      else {
        puVar15 = (uint *)((int)local_68 + (local_90 - (local_70 >> 3)));
        uVar23 = local_90;
        if (local_68 <= puVar15) {
          uVar23 = local_70 >> 3;
        }
        local_6c = (uint *)((int)local_68 + (local_90 - uVar23));
        local_70 = local_70 + uVar23 * -8;
        bVar25 = local_68 <= puVar15;
        local_74 = *(uint *)((int)local_68 + (local_90 - uVar23));
        uVar23 = 0;
      }
      if (!bVar25) {
        uVar23 = 1;
      }
    }
    else {
      local_6c = (uint *)((int)local_68 + (local_90 - (local_70 >> 3)));
      local_74 = *(uint *)((int)local_68 + (local_90 - (local_70 >> 3)));
      uVar23 = 0;
      local_70 = local_70 & 7;
    }
  }
  uVar13 = uVar14 + (uVar8 >> 2);
  uVar7 = uVar17 - 3;
  param_5 = param_5 + 4;
  uVar8 = uVar14;
  local_84 = uVar21;
  local_80 = uVar13;
  if (((uVar6 | uVar24 | uVar12 | uVar23) == 0) && (uVar13 < uVar7)) {
    uVar6 = -uVar5 & 0x1f;
    do {
      iVar18 = param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(param_1,iVar18,2);
      local_34 = local_34 + *(byte *)(iVar18 + 2);
      bVar1 = *(byte *)(iVar18 + 3);
      iVar18 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(local_84,iVar18,2);
      local_48 = local_48 + *(byte *)(iVar18 + 2);
      bVar2 = *(byte *)(iVar18 + 3);
      iVar18 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
      FUN_00036044(uVar8,iVar18,2);
      local_5c = local_5c + *(byte *)(iVar18 + 2);
      bVar3 = *(byte *)(iVar18 + 3);
      iVar18 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(local_80,iVar18,2);
      local_70 = local_70 + *(byte *)(iVar18 + 2);
      bVar10 = *(byte *)(iVar18 + 3);
      iVar19 = param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4;
      iVar18 = param_1 + bVar1;
      FUN_00036044(iVar18,iVar19,2);
      local_34 = local_34 + *(byte *)(iVar19 + 2);
      bVar1 = *(byte *)(iVar19 + 3);
      iVar22 = local_84 + bVar2;
      iVar19 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(iVar22,iVar19,2);
      local_48 = local_48 + *(byte *)(iVar19 + 2);
      bVar2 = *(byte *)(iVar19 + 3);
      iVar20 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
      iVar19 = uVar8 + bVar3;
      FUN_00036044(iVar19,iVar20,2);
      local_5c = local_5c + *(byte *)(iVar20 + 2);
      iVar16 = local_80 + bVar10;
      bVar3 = *(byte *)(iVar20 + 3);
      iVar20 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(iVar16,iVar20,2);
      bVar10 = 3;
      local_70 = local_70 + *(byte *)(iVar20 + 2);
      if (local_34 < 0x21) {
        if (local_30 < local_28) {
          if (local_30 == local_2c) {
            bVar26 = 2;
            if (local_34 < 0x20) {
              bVar26 = 1;
            }
          }
          else {
            puVar15 = (uint *)((int)local_30 - (local_34 >> 3));
            uVar23 = local_34 >> 3;
            if (puVar15 < local_2c) {
              uVar23 = (int)local_30 - (int)local_2c;
            }
            local_34 = local_34 + uVar23 * -8;
            bVar26 = puVar15 < local_2c;
            local_38 = *(uint *)((int)local_30 - uVar23);
            local_30 = (uint *)((int)local_30 - uVar23);
          }
        }
        else {
          uVar23 = local_34 >> 3;
          local_38 = *(uint *)((int)local_30 - (local_34 >> 3));
          bVar26 = 0;
          local_34 = local_34 & 7;
          local_30 = (uint *)((int)local_30 - uVar23);
        }
      }
      else {
        bVar26 = 3;
      }
      if (local_48 < 0x21) {
        if (local_44 < local_3c) {
          if (local_44 == local_40) {
            bVar25 = 0x1f < local_48;
            bVar10 = 2;
          }
          else {
            puVar15 = (uint *)((int)local_44 - (local_48 >> 3));
            uVar23 = local_48 >> 3;
            if (puVar15 < local_40) {
              uVar23 = (int)local_44 - (int)local_40;
            }
            bVar25 = local_40 <= puVar15;
            local_48 = local_48 + uVar23 * -8;
            local_4c = *(uint *)((int)local_44 - uVar23);
            bVar10 = 0;
            local_44 = (uint *)((int)local_44 - uVar23);
          }
          if (!bVar25) {
            bVar10 = 1;
          }
        }
        else {
          uVar23 = local_48 >> 3;
          local_4c = *(uint *)((int)local_44 - (local_48 >> 3));
          bVar10 = 0;
          local_48 = local_48 & 7;
          local_44 = (uint *)((int)local_44 - uVar23);
        }
      }
      bVar11 = 3;
      bVar4 = 3;
      if (local_5c < 0x21) {
        if (local_58 < local_50) {
          if (local_58 == local_54) {
            bVar25 = 0x1f < local_5c;
            bVar4 = 2;
          }
          else {
            puVar15 = (uint *)((int)local_58 - (local_5c >> 3));
            uVar23 = local_5c >> 3;
            if (puVar15 < local_54) {
              uVar23 = (int)local_58 - (int)local_54;
            }
            local_5c = local_5c + uVar23 * -8;
            local_60 = *(uint *)((int)local_58 - uVar23);
            bVar25 = local_54 <= puVar15;
            bVar4 = 0;
            local_58 = (uint *)((int)local_58 - uVar23);
          }
          if (!bVar25) {
            bVar4 = 1;
          }
        }
        else {
          uVar23 = local_5c >> 3;
          local_60 = *(uint *)((int)local_58 - (local_5c >> 3));
          bVar4 = 0;
          local_5c = local_5c & 7;
          local_58 = (uint *)((int)local_58 - uVar23);
        }
      }
      if (local_70 < 0x21) {
        if (local_6c < local_64) {
          if (local_6c == local_68) {
            bVar25 = 0x1f < local_70;
            bVar11 = 2;
          }
          else {
            puVar15 = (uint *)((int)local_6c - (local_70 >> 3));
            uVar23 = local_70 >> 3;
            if (puVar15 < local_68) {
              uVar23 = (int)local_6c - (int)local_68;
            }
            bVar25 = local_68 <= puVar15;
            local_70 = local_70 + uVar23 * -8;
            local_74 = *(uint *)((int)local_6c - uVar23);
            bVar11 = 0;
            local_6c = (uint *)((int)local_6c - uVar23);
          }
          if (!bVar25) {
            bVar11 = 1;
          }
        }
        else {
          uVar23 = local_70 >> 3;
          local_74 = *(uint *)((int)local_6c - (local_70 >> 3));
          bVar11 = 0;
          local_70 = local_70 & 7;
          local_6c = (uint *)((int)local_6c - uVar23);
        }
      }
      param_1 = iVar18 + (uint)bVar1;
      local_84 = iVar22 + (uint)bVar2;
      uVar8 = iVar19 + (uint)bVar3;
      local_80 = iVar16 + (uint)*(byte *)(iVar20 + 3);
    } while (((byte)(bVar10 | bVar26 | bVar4 | bVar11) == 0) && (local_80 < uVar7));
  }
  bVar27 = uVar13 <= uVar8;
  bVar25 = uVar8 == uVar13;
  if (!bVar27 || bVar25) {
    bVar27 = uVar14 <= local_84;
    bVar25 = local_84 == uVar14;
  }
  if (bVar27 && !bVar25) {
    return 0xffffffec;
  }
  if (uVar21 < param_1) {
    return 0xffffffec;
  }
  if (local_34 < 0x21) {
    uVar6 = -uVar5 & 0x1f;
    do {
      if (local_30 < local_28) {
        if (local_30 == local_2c) goto LAB_0002137c;
        uVar23 = local_34 >> 3;
        bVar25 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
        if (bVar25) {
          uVar23 = (int)local_30 - (int)local_2c;
        }
        local_7c = local_34 + uVar23 * -8;
      }
      else {
        uVar23 = local_34 >> 3;
        local_7c = local_34 & 7;
        bVar25 = false;
      }
      local_30 = (uint *)((int)local_30 - uVar23);
      local_34 = local_7c;
      local_38 = *local_30;
      if ((uVar21 - 3 <= param_1) || (bVar25)) {
        if (local_7c < 0x21) goto LAB_0002137c;
        break;
      }
      iVar18 = param_5 + ((local_38 << (local_7c & 0x1f)) >> uVar6) * 4;
      FUN_00036044(param_1,iVar18,2);
      local_34 = local_34 + *(byte *)(iVar18 + 2);
      iVar18 = param_1 + *(byte *)(iVar18 + 3);
      iVar19 = param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(iVar18,iVar19,2);
      local_34 = local_34 + *(byte *)(iVar19 + 2);
      param_1 = iVar18 + (uint)*(byte *)(iVar19 + 3);
    } while (local_34 < 0x21);
  }
  else {
    uVar6 = -uVar5 & 0x1f;
  }
LAB_00021148:
  for (; param_1 <= uVar21 - 2; param_1 = param_1 + *(byte *)(iVar18 + 3)) {
    iVar18 = param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4;
    FUN_00036044(param_1,iVar18,2);
    local_34 = local_34 + *(byte *)(iVar18 + 2);
  }
  if (param_1 < uVar21) {
    iVar18 = param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4;
    FUN_00036044(param_1,iVar18,1);
    if (*(char *)(iVar18 + 3) == '\x01') {
      local_34 = local_34 + *(byte *)(iVar18 + 2);
    }
    else if ((local_34 < 0x20) && (local_34 = local_34 + *(byte *)(iVar18 + 2), 0x1f < local_34)) {
      local_34 = 0x20;
    }
  }
  if (local_48 < 0x21) {
    uVar6 = -uVar5 & 0x1f;
    do {
      if (local_44 < local_3c) {
        if (local_44 == local_40) goto LAB_00021464;
        uVar23 = local_48 >> 3;
        bVar25 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
        if (bVar25) {
          uVar23 = (int)local_44 - (int)local_40;
        }
        local_48 = local_48 + uVar23 * -8;
      }
      else {
        uVar23 = local_48 >> 3;
        local_48 = local_48 & 7;
        bVar25 = false;
      }
      local_44 = (uint *)((int)local_44 - uVar23);
      local_4c = *local_44;
      if ((uVar14 - 3 <= local_84) || (bVar25)) goto LAB_0002145c;
      iVar18 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(local_84,iVar18,2);
      local_48 = local_48 + *(byte *)(iVar18 + 2);
      iVar18 = local_84 + *(byte *)(iVar18 + 3);
      iVar19 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
      FUN_00036044(iVar18,iVar19,2);
      local_48 = local_48 + *(byte *)(iVar19 + 2);
      local_84 = iVar18 + (uint)*(byte *)(iVar19 + 3);
    } while (local_48 < 0x21);
  }
  else {
    uVar6 = -uVar5 & 0x1f;
  }
LAB_00021550:
  for (; local_84 <= uVar14 - 2; local_84 = local_84 + *(byte *)(iVar18 + 3)) {
    iVar18 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
    FUN_00036044(local_84,iVar18,2);
    local_48 = local_48 + *(byte *)(iVar18 + 2);
  }
  if (local_84 < uVar14) {
    iVar18 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
    FUN_00036044(local_84,iVar18,1);
    if (*(char *)(iVar18 + 3) == '\x01') {
      local_48 = local_48 + *(byte *)(iVar18 + 2);
    }
    else if ((local_48 < 0x20) && (local_48 = local_48 + *(byte *)(iVar18 + 2), 0x1f < local_48)) {
      local_48 = 0x20;
    }
  }
  if (local_5c < 0x21) {
    uVar6 = -uVar5 & 0x1f;
    do {
      if (local_58 < local_50) {
        if (local_58 != local_54) {
          uVar23 = local_5c >> 3;
          bVar25 = (uint *)((int)local_58 - (local_5c >> 3)) < local_54;
          if (bVar25) {
            uVar23 = (int)local_58 - (int)local_54;
          }
          local_5c = local_5c + uVar23 * -8;
          goto LAB_00021650;
        }
LAB_00021718:
        goto LAB_00021720;
      }
      uVar23 = local_5c >> 3;
      local_5c = local_5c & 7;
      bVar25 = false;
LAB_00021650:
      local_58 = (uint *)((int)local_58 - uVar23);
      local_60 = *local_58;
      if ((uVar13 - 3 <= uVar8) || (bVar25)) {
        if (local_5c < 0x21) goto LAB_00021718;
        break;
      }
      iVar18 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
      FUN_00036044(uVar8,iVar18,2);
      local_5c = local_5c + *(byte *)(iVar18 + 2);
      iVar18 = uVar8 + *(byte *)(iVar18 + 3);
      iVar19 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
      FUN_00036044(iVar18,iVar19,2);
      local_5c = local_5c + *(byte *)(iVar19 + 2);
      uVar8 = iVar18 + (uint)*(byte *)(iVar19 + 3);
    } while (local_5c < 0x21);
  }
  else {
    uVar6 = -uVar5 & 0x1f;
  }
LAB_00021818:
  for (; uVar8 <= uVar13 - 2; uVar8 = uVar8 + *(byte *)(iVar18 + 3)) {
    iVar18 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
    FUN_00036044(uVar8,iVar18,2);
    local_5c = local_5c + *(byte *)(iVar18 + 2);
  }
  if (uVar8 < uVar13) {
    iVar18 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
    FUN_00036044(uVar8,iVar18,1);
    if (*(char *)(iVar18 + 3) == '\x01') {
      local_5c = local_5c + *(byte *)(iVar18 + 2);
    }
    else if ((local_5c < 0x20) && (local_5c = local_5c + *(byte *)(iVar18 + 2), 0x1f < local_5c)) {
      local_5c = 0x20;
    }
  }
  if (local_70 < 0x21) {
    uVar5 = -uVar5 & 0x1f;
    do {
      if (local_6c < local_64) {
        if (local_6c == local_68) goto LAB_00021b50;
        uVar6 = local_70 >> 3;
        bVar25 = (uint *)((int)local_6c - (local_70 >> 3)) < local_68;
        if (bVar25) {
          uVar6 = (int)local_6c - (int)local_68;
        }
        local_70 = local_70 + uVar6 * -8;
      }
      else {
        uVar6 = local_70 >> 3;
        local_70 = local_70 & 7;
        bVar25 = false;
      }
      local_6c = (uint *)((int)local_6c - uVar6);
      local_74 = *local_6c;
      if ((uVar7 <= local_80) || (bVar25)) goto LAB_00021b48;
      iVar18 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4;
      FUN_00036044(local_80,iVar18,2);
      local_70 = local_70 + *(byte *)(iVar18 + 2);
      iVar18 = local_80 + *(byte *)(iVar18 + 3);
      iVar19 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4;
      FUN_00036044(iVar18,iVar19,2);
      local_70 = local_70 + *(byte *)(iVar19 + 2);
      local_80 = iVar18 + (uint)*(byte *)(iVar19 + 3);
    } while (local_70 < 0x21);
  }
  else {
    uVar5 = -uVar5 & 0x1f;
  }
LAB_000219cc:
  for (; local_80 <= uVar17 - 2; local_80 = local_80 + *(byte *)(iVar18 + 3)) {
    iVar18 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4;
    FUN_00036044(local_80,iVar18,2);
    local_70 = local_70 + *(byte *)(iVar18 + 2);
  }
  if (local_80 < uVar17) {
    param_5 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4;
    FUN_00036044(local_80,param_5,1);
    if (*(char *)(param_5 + 3) == '\x01') {
      local_70 = local_70 + *(byte *)(param_5 + 2);
    }
    else if ((local_70 < 0x20) && (local_70 = local_70 + *(byte *)(param_5 + 2), 0x1f < local_70)) {
      local_70 = 0x20;
    }
  }
  if ((((local_44 != local_40 || local_48 != 0x20) || (local_30 != local_2c || local_34 != 0x20)) ||
      (local_58 != local_54 || local_5c != 0x20)) ||
      ((uint)local_6c ^ (uint)local_68 | local_70 ^ 0x20) != 0) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_0002137c:
  if (local_30 < local_28) {
    if (local_30 == local_2c) goto LAB_00021148;
    uVar23 = local_34 >> 3;
    bVar25 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
    if (bVar25) {
      uVar23 = (int)local_30 - (int)local_2c;
    }
    local_7c = local_34 + uVar23 * -8;
  }
  else {
    uVar23 = local_34 >> 3;
    local_7c = local_34 & 7;
    bVar25 = false;
  }
  local_30 = (uint *)((int)local_30 - uVar23);
  local_34 = local_7c;
  local_38 = *local_30;
  if ((uVar21 - 2 < param_1) || (bVar25)) goto LAB_00021148;
  iVar18 = param_5 + ((local_38 << (local_7c & 0x1f)) >> uVar6) * 4;
  FUN_00036044(param_1,iVar18,2);
  local_34 = local_34 + *(byte *)(iVar18 + 2);
  param_1 = param_1 + *(byte *)(iVar18 + 3);
  if (0x20 < local_34) goto LAB_00021148;
  goto LAB_0002137c;
LAB_0002145c:
  if (0x20 < local_48) goto LAB_00021550;
LAB_00021464:
  if (local_44 < local_3c) {
    if (local_44 == local_40) goto LAB_00021550;
    uVar23 = local_48 >> 3;
    bVar25 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
    if (bVar25) {
      uVar23 = (int)local_44 - (int)local_40;
    }
    local_48 = local_48 + uVar23 * -8;
  }
  else {
    uVar23 = local_48 >> 3;
    local_48 = local_48 & 7;
    bVar25 = false;
  }
  local_44 = (uint *)((int)local_44 - uVar23);
  local_4c = *local_44;
  if ((uVar14 - 2 < local_84) || (bVar25)) goto LAB_00021550;
  iVar18 = param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4;
  FUN_00036044(local_84,iVar18,2);
  local_48 = local_48 + *(byte *)(iVar18 + 2);
  local_84 = local_84 + *(byte *)(iVar18 + 3);
  goto LAB_0002145c;
LAB_00021720:
  if (local_58 < local_50) {
    if (local_58 == local_54) goto LAB_00021818;
    uVar23 = local_5c >> 3;
    bVar25 = (uint *)((int)local_58 - (local_5c >> 3)) < local_54;
    if (bVar25) {
      uVar23 = (int)local_58 - (int)local_54;
    }
    local_5c = local_5c + uVar23 * -8;
  }
  else {
    uVar23 = local_5c >> 3;
    local_5c = local_5c & 7;
    bVar25 = false;
  }
  local_58 = (uint *)((int)local_58 - uVar23);
  local_60 = *local_58;
  if ((uVar13 - 2 < uVar8) || (bVar25)) goto LAB_00021818;
  iVar18 = param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4;
  FUN_00036044(uVar8,iVar18,2);
  local_5c = local_5c + *(byte *)(iVar18 + 2);
  uVar8 = uVar8 + *(byte *)(iVar18 + 3);
  if (0x20 < local_5c) goto LAB_00021818;
  goto LAB_00021720;
LAB_00021b48:
  if (0x20 < local_70) goto LAB_000219cc;
LAB_00021b50:
  if (local_6c < local_64) {
    if (local_6c == local_68) goto LAB_000219cc;
    uVar6 = local_70 >> 3;
    bVar25 = (uint *)((int)local_6c - (local_70 >> 3)) < local_68;
    if (bVar25) {
      uVar6 = (int)local_6c - (int)local_68;
    }
    local_70 = local_70 + uVar6 * -8;
  }
  else {
    uVar6 = local_70 >> 3;
    local_70 = local_70 & 7;
    bVar25 = false;
  }
  local_6c = (uint *)((int)local_6c - uVar6);
  local_74 = *local_6c;
  if ((uVar17 - 2 < local_80) || (bVar25)) goto LAB_000219cc;
  iVar18 = param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4;
  FUN_00036044(local_80,iVar18,2);
  local_70 = local_70 + *(byte *)(iVar18 + 2);
  local_80 = local_80 + *(byte *)(iVar18 + 3);
  goto LAB_00021b48;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021c08 FUN_00021c08 */

uint FUN_00021c08(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_0001f8dc(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00020370(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021c84 FUN_00021c84 */

uint FUN_00021c84(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_0001f8dc(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00020370(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021d04 FUN_00021d04 */

uint FUN_00021d04(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_4824;
  undefined auStack_4820 [16384];
  undefined auStack_820 [2048];
  
  FUN_00036068(auStack_4820,0x4000);
  local_4824 = 0xc00000c;
  uVar1 = FUN_0001f8dc(&local_4824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00020370(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_4824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021da0 FUN_00021da0 */

void FUN_00021da0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined uStack_24;
  char local_23;
  
  FUN_00036044(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    FUN_0001fdb0(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_0001de20(param_1,param_2,param_3,param_4,param_5);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021e20 FUN_00021e20 */

void FUN_00021e20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined uStack_24;
  char local_23;
  
  FUN_00036044(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    FUN_00020370(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_0001e368(param_1,param_2,param_3,param_4,param_5);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021ea0 FUN_00021ea0 */

bool FUN_00021ea0(uint param_1,uint param_2)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  
  iVar1 = 0xf;
  if (param_2 < param_1) {
    iVar1 = FUN_00024478(param_2 << 4,param_1);
  }
  piVar2 = (int *)(DAT_00021efc + 0x21ed8 + iVar1 * 0x18);
  uVar3 = piVar2[3] * (param_1 >> 8) + piVar2[2];
  return uVar3 + (uVar3 >> 3) < piVar2[1] * (param_1 >> 8) + *piVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021f00 FUN_00021f00 */

uint FUN_00021f00(undefined4 param_1,uint param_2,undefined *param_3,uint param_4)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  
  if (param_2 == 0) {
    return 0xffffffba;
  }
  uVar3 = 0xffffffec;
  if (param_4 <= param_2) {
    uVar3 = param_2;
    if (param_4 == param_2) {
      FUN_00036044(param_1,param_3,param_2);
    }
    else {
      if (param_4 != 1) {
        iVar1 = 0xf;
        if (param_4 < param_2) {
          iVar1 = FUN_00024478(param_4 << 4,param_2);
        }
        piVar2 = (int *)(DAT_00021fdc + 0x21f94 + iVar1 * 0x18);
        uVar3 = piVar2[3] * (param_2 >> 8) + piVar2[2];
                    /* WARNING: Could not emulate address calculation at 0x00021fc8 */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(DAT_00021fe0 + 0x21fb8 +
                            (uint)(uVar3 + (uVar3 >> 3) < piVar2[1] * (param_2 >> 8) + *piVar2) * 4)
                )(param_1,param_2,param_3,param_4);
        return uVar3;
      }
      FUN_00036050(param_1,*param_3,param_2);
    }
  }
  return uVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021fe4 FUN_00021fe4 */

uint FUN_00021fe4(undefined4 param_1,undefined4 param_2,uint param_3,undefined *param_4,uint param_5
                 )

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  undefined auStack_820 [2048];
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_3 < param_5) {
    return 0xffffffec;
  }
  if (param_5 == param_3) {
    FUN_00036044(param_2,param_4,param_3);
  }
  else {
    if (param_5 != 1) {
      iVar1 = 0xf;
      if (param_5 < param_3) {
        iVar1 = FUN_00024478(param_5 << 4,param_3);
      }
      piVar2 = (int *)(DAT_0002215c + 0x22094 + iVar1 * 0x18);
      uVar3 = piVar2[3] * (param_3 >> 8) + piVar2[2];
      if (piVar2[1] * (param_3 >> 8) + *piVar2 <= uVar3 + (uVar3 >> 3)) {
        uVar3 = FUN_0001dc3c(param_1,param_4,param_5,auStack_820,0x800);
        if (0xffffff88 < uVar3) {
          return uVar3;
        }
        if (param_5 <= uVar3) {
          return 0xffffffb8;
        }
        uVar3 = FUN_0001e368(param_2,param_3,param_4 + uVar3,param_5 - uVar3,param_1);
        return uVar3;
      }
      uVar3 = FUN_0001f8dc(param_1,param_4,param_5,auStack_820,0x800);
      if (0xffffff88 < uVar3) {
        return uVar3;
      }
      if (param_5 <= uVar3) {
        return 0xffffffb8;
      }
      uVar3 = FUN_00020370(param_2,param_3,param_4 + uVar3,param_5 - uVar3,param_1);
      return uVar3;
    }
    FUN_00036050(param_2,*param_4,param_3);
  }
  return param_3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00022160 FUN_00022160 */

void FUN_00022160(void)

{
  FUN_0002218c();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002218c FUN_0002218c */

uint FUN_0002218c(undefined4 param_1,undefined4 param_2,uint param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_5 != 0) {
    iVar1 = 0xf;
    if (param_5 < param_3) {
      iVar1 = FUN_00024478(param_5 << 4,param_3);
    }
    piVar3 = (int *)(DAT_000222bc + 0x221ec + iVar1 * 0x18);
    uVar4 = piVar3[3] * (param_3 >> 8) + piVar3[2];
    if (uVar4 + (uVar4 >> 3) < piVar3[1] * (param_3 >> 8) + *piVar3) {
      uVar2 = FUN_0001f8dc(param_1,param_4,param_5,param_6,param_7);
      uVar4 = uVar2;
      if ((uVar2 < 0xffffff89) && (uVar4 = 0xffffffb8, uVar2 < param_5)) {
        uVar4 = FUN_00020370(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
        return uVar4;
      }
    }
    else {
      uVar2 = FUN_0001dc3c(param_1,param_4,param_5,param_6,param_7);
      uVar4 = uVar2;
      if ((uVar2 < 0xffffff89) && (uVar4 = 0xffffffb8, uVar2 < param_5)) {
        uVar4 = FUN_0001e368(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
      }
    }
    return uVar4;
  }
  return 0xffffffec;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000222c0 FUN_000222c0 */

uint FUN_000222c0(undefined4 param_1,undefined4 param_2,uint param_3,undefined *param_4,uint param_5
                 ,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_3 < param_5) {
    return 0xffffffec;
  }
  if (param_5 == param_3) {
    FUN_00036044(param_2,param_4,param_3);
  }
  else {
    if (param_5 != 1) {
      iVar1 = 0xf;
      if (param_5 < param_3) {
        iVar1 = FUN_00024478(param_5 << 4,param_3);
      }
      piVar3 = (int *)(DAT_00022430 + 0x22374 + iVar1 * 0x18);
      uVar2 = piVar3[3] * (param_3 >> 8) + piVar3[2];
      if (piVar3[1] * (param_3 >> 8) + *piVar3 <= uVar2 + (uVar2 >> 3)) {
        uVar2 = FUN_0001dc3c(param_1,param_4,param_5,param_6,param_7);
        if (0xffffff88 < uVar2) {
          return uVar2;
        }
        if (param_5 <= uVar2) {
          return 0xffffffb8;
        }
        uVar2 = FUN_0001de20(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
        return uVar2;
      }
      uVar2 = FUN_0001f8dc(param_1,param_4,param_5,param_6,param_7);
      if (0xffffff88 < uVar2) {
        return uVar2;
      }
      if (param_5 <= uVar2) {
        return 0xffffffb8;
      }
      uVar2 = FUN_0001fdb0(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
      return uVar2;
    }
    FUN_00036050(param_2,*param_4,param_3);
  }
  return param_3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00022434 FUN_00022434 */

void FUN_00022434(void)

{
  FUN_000222c0();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00022478 FUN_00022478 */

uint FUN_00022478(int *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  
  piVar10 = (int *)((int)param_1 + param_2);
  if (((uint)param_1 & 3) == 0) {
    if (param_2 < 0x10) {
      iVar7 = param_3 + 0x165667b1;
    }
    else {
      uVar12 = param_3 + 0x61c8864f;
      uVar9 = param_3 + 0x85ebca77;
      uVar11 = param_3 + 0x24234428;
      do {
        piVar8 = param_1 + 3;
        piVar5 = param_1 + 2;
        uVar9 = param_1[1] * -0x7a143589 + uVar9;
        uVar11 = *param_1 * -0x7a143589 + uVar11;
        param_1 = param_1 + 4;
        param_3 = *piVar5 * -0x7a143589 + param_3;
        uVar12 = *piVar8 * -0x7a143589 + uVar12;
        uVar1 = uVar9 >> 0x13 | uVar9 * 0x2000;
        uVar2 = uVar11 >> 0x13 | uVar11 * 0x2000;
        uVar11 = uVar2 * -0x61c8864f;
        uVar3 = param_3 >> 0x13 | param_3 * 0x2000;
        param_3 = uVar3 * -0x61c8864f;
        uVar4 = uVar12 >> 0x13 | uVar12 * 0x2000;
        uVar12 = uVar4 * -0x61c8864f;
        uVar9 = uVar1 * -0x61c8864f;
      } while (param_1 <= piVar10 + -4);
      iVar7 = (uVar1 * 0x1bbcd880 | uVar9 >> 0x19) + (uVar2 * 0x3c6ef362 | uVar11 >> 0x1f) +
              (uVar3 * 0x779b1000 | param_3 >> 0x14) + (uVar12 >> 0xe | uVar4 * -0x193c0000);
    }
    param_2 = iVar7 + param_2;
    piVar8 = param_1 + 1;
    while (piVar8 <= piVar10) {
      param_2 = *param_1 * -0x3d4d51c3 + param_2;
      param_2 = (param_2 >> 0xf | param_2 * 0x20000) * 0x27d4eb2f;
      piVar8 = param_1 + 2;
      param_1 = param_1 + 1;
    }
    if (param_1 < piVar10) {
      do {
        piVar8 = (int *)((int)param_1 + 1);
        param_2 = (uint)*(byte *)param_1 * 0x165667b1 + param_2;
        param_2 = (param_2 >> 0x15 | param_2 * 0x800) * -0x61c8864f;
        param_1 = piVar8;
      } while (piVar10 != piVar8);
    }
  }
  else {
    if (param_2 < 0x10) {
      iVar7 = param_3 + 0x165667b1;
    }
    else {
      uVar12 = param_3 + 0x61c8864f;
      uVar11 = param_3 + 0x85ebca77;
      uVar9 = param_3 + 0x24234428;
      do {
        piVar8 = param_1 + 3;
        piVar5 = param_1 + 2;
        piVar6 = param_1 + 1;
        uVar9 = *param_1 * -0x7a143589 + uVar9;
        param_1 = param_1 + 4;
        param_3 = *piVar5 * -0x7a143589 + param_3;
        uVar12 = *piVar8 * -0x7a143589 + uVar12;
        uVar11 = *piVar6 * -0x7a143589 + uVar11;
        uVar1 = uVar9 >> 0x13 | uVar9 * 0x2000;
        uVar2 = param_3 >> 0x13 | param_3 * 0x2000;
        param_3 = uVar2 * -0x61c8864f;
        uVar3 = uVar12 >> 0x13 | uVar12 * 0x2000;
        uVar12 = uVar3 * -0x61c8864f;
        uVar4 = uVar11 >> 0x13 | uVar11 * 0x2000;
        uVar11 = uVar4 * -0x61c8864f;
        uVar9 = uVar1 * -0x61c8864f;
      } while (param_1 <= piVar10 + -4);
      iVar7 = (uVar4 * 0x1bbcd880 | uVar11 >> 0x19) + (uVar1 * 0x3c6ef362 | uVar9 >> 0x1f) +
              (uVar2 * 0x779b1000 | param_3 >> 0x14) + (uVar12 >> 0xe | uVar3 * -0x193c0000);
    }
    param_2 = iVar7 + param_2;
    piVar8 = param_1 + 1;
    while (piVar8 <= piVar10) {
      param_2 = *param_1 * -0x3d4d51c3 + param_2;
      param_2 = (param_2 >> 0xf | param_2 * 0x20000) * 0x27d4eb2f;
      piVar8 = param_1 + 2;
      param_1 = param_1 + 1;
    }
    if (param_1 < piVar10) {
      do {
        piVar8 = (int *)((int)param_1 + 1);
        param_2 = (uint)*(byte *)param_1 * 0x165667b1 + param_2;
        param_2 = (param_2 >> 0x15 | param_2 * 0x800) * -0x61c8864f;
        param_1 = piVar8;
      } while (piVar10 != piVar8);
    }
  }
  uVar9 = (param_2 ^ param_2 >> 0xf) * -0x7a143589;
  uVar9 = (uVar9 ^ uVar9 >> 0xd) * -0x3d4d51c3;
  return uVar9 ^ uVar9 >> 0x10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002278c FUN_0002278c */

uint FUN_0002278c(uint *param_1,uint param_2,uint param_3,uint param_4)

{
  uint *puVar1;
  uint *puVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint *puVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  int iVar24;
  uint *puVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  uint uVar34;
  uint uVar35;
  uint uVar36;
  uint uVar37;
  uint uVar38;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  uint uVar42;
  uint uVar43;
  uint uVar44;
  uint local_38;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  
  puVar25 = (uint *)((int)param_1 + param_2);
  if (((uint)param_1 & 7) == 0) {
    if (param_2 < 0x20) {
      uVar26 = param_3 + 0x165667c5;
      iVar24 = param_4 + 0x27d4eb2f + (uint)(0xe9a9983a < param_3);
    }
    else {
      uVar37 = param_3 + 0x7a143579;
      local_2c = param_4 + 0x61c8864e + (uint)(0x85ebca86 < param_3);
      local_34 = param_3 + 0x27d4eb4f;
      uVar26 = param_4 + 0xc2b2ae3d + (uint)(0xd82b14b0 < param_3);
      uVar36 = param_3 + 0xadc0b5d6;
      local_30 = param_4 + 0x60ea27ee + (uint)(0x523f4a29 < param_3);
      local_28 = param_4;
      do {
        lVar3 = (ulonglong)param_1[6] * 0x27d4eb4f;
        uVar16 = (uint)lVar3;
        uVar17 = uVar16 + uVar37;
        uVar37 = param_1[7] * 0x27d4eb4f +
                 param_1[6] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_2c +
                 (uint)CARRY4(uVar16,uVar37);
        uVar16 = uVar37 >> 1;
        uVar29 = uVar17 * -0x80000000 | uVar16;
        uVar17 = uVar17 >> 1;
        uVar11 = uVar37 * -0x80000000 | uVar17;
        uVar37 = (uint)((ulonglong)uVar29 * 0x85ebca87);
        puVar15 = param_1 + 3;
        local_2c = uVar11 * -0x7a143579 +
                   uVar29 * -0x61c8864f + (int)((ulonglong)uVar29 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)param_1[4] * 0x27d4eb4f;
        uVar18 = (uint)lVar3;
        uVar19 = uVar18 + param_3;
        uVar12 = param_1[5] * 0x27d4eb4f +
                 param_1[4] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_28 +
                 (uint)CARRY4(uVar18,param_3);
        uVar18 = uVar12 >> 1;
        uVar22 = uVar19 * -0x80000000 | uVar18;
        uVar19 = uVar19 >> 1;
        uVar13 = uVar12 * -0x80000000 | uVar19;
        param_3 = (uint)((ulonglong)uVar22 * 0x85ebca87);
        uVar14 = *param_1;
        local_28 = uVar13 * -0x7a143579 +
                   uVar22 * -0x61c8864f + (int)((ulonglong)uVar22 * 0x85ebca87 >> 0x20);
        puVar1 = param_1 + 2;
        lVar3 = (ulonglong)*puVar1 * 0x27d4eb4f;
        uVar12 = (uint)lVar3;
        puVar2 = param_1 + 1;
        param_1 = param_1 + 8;
        uVar31 = uVar12 + local_34;
        uVar26 = *puVar15 * 0x27d4eb4f + *puVar1 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 uVar26 + (uint)CARRY4(uVar12,local_34);
        uVar12 = uVar26 >> 1;
        uVar30 = uVar31 * -0x80000000 | uVar12;
        uVar31 = uVar31 >> 1;
        uVar20 = uVar26 * -0x80000000 | uVar31;
        local_34 = (uint)((ulonglong)uVar30 * 0x85ebca87);
        uVar26 = uVar20 * -0x7a143579 +
                 uVar30 * -0x61c8864f + (int)((ulonglong)uVar30 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)uVar14 * 0x27d4eb4f;
        uVar32 = (uint)lVar3;
        uVar21 = uVar32 + uVar36;
        uVar32 = *puVar2 * 0x27d4eb4f + uVar14 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 local_30 + (uint)CARRY4(uVar32,uVar36);
        uVar14 = uVar32 >> 1;
        uVar41 = uVar21 * -0x80000000 | uVar14;
        uVar36 = (uint)((ulonglong)uVar41 * 0x85ebca87);
        uVar21 = uVar21 >> 1;
        uVar32 = uVar32 * -0x80000000 | uVar21;
        local_30 = uVar32 * -0x7a143579 +
                   uVar41 * -0x61c8864f + (int)((ulonglong)uVar41 * 0x85ebca87 >> 0x20);
      } while (param_1 <= puVar25 + -8);
      uVar39 = (uint)((ulonglong)uVar41 * 0xbd7950e) | local_30 >> 0x1f;
      uVar33 = (uint)((ulonglong)uVar30 * 0xf5e54380) | uVar26 >> 0x19;
      uVar40 = uVar33 + uVar39;
      uVar34 = (uint)((ulonglong)uVar22 * 0xbca87000) | local_28 >> 0x14;
      uVar44 = uVar40 + uVar34;
      uVar37 = (uint)((ulonglong)uVar41 * 0x80000000) |
               uVar32 * 0xf796ca9 +
               uVar41 * -0x210ca4ff + (int)((ulonglong)uVar41 * 0xf796ca9 >> 0x20) >> 1;
      uVar35 = (uint)((ulonglong)uVar29 * 0x2a1c0000) | local_2c >> 0xe;
      lVar3 = (ulonglong)uVar37 * 0x85ebca87;
      uVar28 = uVar44 + uVar35 ^ (uint)lVar3;
      lVar4 = (ulonglong)uVar28 * 0x85ebca87;
      uVar38 = (uint)lVar4;
      uVar42 = (uint)((ulonglong)uVar30 * 0x80000000) |
               uVar20 * 0xf796ca9 +
               uVar30 * -0x210ca4ff + (int)((ulonglong)uVar30 * 0xf796ca9 >> 0x20) >> 1;
      lVar5 = (ulonglong)uVar42 * 0x85ebca87;
      uVar36 = uVar38 + 0xc2b2ae63 ^ (uint)lVar5;
      lVar6 = (ulonglong)uVar36 * 0x85ebca87;
      uVar32 = (uint)lVar6;
      uVar20 = (uint)((ulonglong)uVar22 * 0x80000000) |
               uVar13 * 0xf796ca9 +
               uVar22 * -0x210ca4ff + (int)((ulonglong)uVar22 * 0xf796ca9 >> 0x20) >> 1;
      lVar7 = (ulonglong)uVar20 * 0x85ebca87;
      uVar13 = uVar32 + 0xc2b2ae63 ^ (uint)lVar7;
      lVar8 = (ulonglong)uVar13 * 0x85ebca87;
      uVar23 = (uint)lVar8;
      uVar11 = (uint)((ulonglong)uVar29 * 0x80000000) |
               uVar11 * 0xf796ca9 +
               uVar29 * -0x210ca4ff + (int)((ulonglong)uVar29 * 0xf796ca9 >> 0x20) >> 1;
      lVar9 = (ulonglong)uVar11 * 0x85ebca87;
      uVar27 = uVar23 + 0xc2b2ae63 ^ (uint)lVar9;
      lVar10 = (ulonglong)uVar27 * 0x85ebca87;
      uVar43 = (uint)lVar10;
      uVar26 = uVar43 + 0xc2b2ae63;
      iVar24 = ((((uVar31 * -0xa1abc80 +
                   uVar12 * 0x1bbcd8c2 + (int)((ulonglong)uVar30 * 0xf5e54380 >> 0x20) +
                   uVar21 * 0xbd7950e +
                   uVar41 * 0x3c6ef363 + (int)((ulonglong)uVar41 * 0xbd7950e >> 0x20) +
                   (uint)CARRY4(uVar33,uVar39) +
                   uVar19 * -0x43579000 +
                   uVar18 * 0x779b185e + (int)((ulonglong)uVar22 * 0xbca87000 >> 0x20) +
                   (uint)CARRY4(uVar40,uVar34) +
                   uVar17 * 0x2a1c0000 +
                   uVar29 * -0x1939e851 + (int)((ulonglong)uVar29 * 0x2a1c0000 >> 0x20) +
                   (uint)CARRY4(uVar44,uVar35) ^
                  (uVar21 * -0x80000000 +
                  uVar14 * -0x784349ac + (int)((ulonglong)uVar41 * 0x80000000 >> 0x20)) *
                  -0x7a143579 + uVar37 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20)) *
                  -0x7a143579 + uVar28 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20) + -0x7a143589
                  + (uint)(0x3d4d519c < uVar38) ^
                 (uVar31 * -0x80000000 +
                 uVar12 * -0x784349ac + (int)((ulonglong)uVar30 * 0x80000000 >> 0x20)) * -0x7a143579
                 + uVar42 * -0x61c8864f + (int)((ulonglong)lVar5 >> 0x20)) * -0x7a143579 +
                 uVar36 * -0x61c8864f + (int)((ulonglong)lVar6 >> 0x20) + -0x7a143589 +
                 (uint)(0x3d4d519c < uVar32) ^
                (uVar19 * -0x80000000 +
                uVar18 * -0x784349ac + (int)((ulonglong)uVar22 * 0x80000000 >> 0x20)) * -0x7a143579
                + uVar20 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20)) * -0x7a143579 +
                uVar13 * -0x61c8864f + (int)((ulonglong)lVar8 >> 0x20) + -0x7a143589 +
                (uint)(0x3d4d519c < uVar23) ^
               (uVar17 * -0x80000000 +
               uVar16 * -0x784349ac + (int)((ulonglong)uVar29 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar11 * -0x61c8864f + (int)((ulonglong)lVar9 >> 0x20)) * -0x7a143579 +
               uVar27 * -0x61c8864f + (int)((ulonglong)lVar10 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar43);
    }
    uVar37 = uVar26 + param_2;
    uVar26 = iVar24 + (uint)CARRY4(uVar26,param_2);
    puVar15 = param_1 + 2;
    while (puVar15 <= puVar25) {
      uVar17 = *param_1;
      uVar36 = (uint)((ulonglong)uVar17 * 0x80000000) |
               param_1[1] * 0x27d4eb4f +
               uVar17 * -0x3d4d51c3 + (int)((ulonglong)uVar17 * 0x27d4eb4f >> 0x20) >> 1;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar16 = (uint)lVar3 ^ uVar37;
      uVar26 = (param_1[1] * -0x80000000 +
               uVar17 * -0x6c158a59 + (int)((ulonglong)uVar17 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar36 = uVar16 << 0x1b | uVar26 >> 5;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0xc2b2ae63;
      uVar26 = (uVar26 << 0x1b | uVar16 >> 5) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar17);
      puVar15 = param_1 + 4;
      param_1 = param_1 + 2;
    }
    if (param_1 + 1 <= puVar25) {
      lVar3 = (ulonglong)*param_1 * 0x85ebca87;
      uVar36 = (uint)lVar3 ^ uVar37;
      uVar26 = *param_1 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar16 = uVar36 << 0x17 | uVar26 >> 9;
      lVar3 = (ulonglong)uVar16 * 0x27d4eb4f;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0x9e3779f9;
      uVar26 = (uVar26 << 0x17 | uVar36 >> 9) * 0x27d4eb4f +
               uVar16 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + 0x165667b1 +
               (uint)(0x61c88606 < uVar17);
      param_1 = param_1 + 1;
    }
    if (param_1 < puVar25) {
      do {
        puVar15 = (uint *)((int)param_1 + 1);
        lVar3 = (ulonglong)(uint)*(byte *)param_1 * 0x165667c5;
        uVar16 = (uint)lVar3 ^ uVar37;
        uVar26 = (uint)*(byte *)param_1 * 0x27d4eb2f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
        uVar36 = uVar16 << 0xb | uVar26 >> 0x15;
        lVar3 = (ulonglong)uVar36 * 0x85ebca87;
        uVar37 = (uint)lVar3;
        uVar26 = (uVar26 << 0xb | uVar16 >> 0x15) * -0x7a143579 +
                 uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20);
        param_1 = puVar15;
      } while (puVar25 != puVar15);
    }
  }
  else {
    if (param_2 < 0x20) {
      uVar26 = param_3 + 0x165667c5;
      iVar24 = param_4 + 0x27d4eb2f + (uint)(0xe9a9983a < param_3);
    }
    else {
      uVar37 = param_3 + 0x7a143579;
      local_2c = param_4 + 0x61c8864e + (uint)(0x85ebca86 < param_3);
      local_34 = param_3 + 0x27d4eb4f;
      local_30 = param_4 + 0xc2b2ae3d + (uint)(0xd82b14b0 < param_3);
      uVar26 = param_3 + 0xadc0b5d6;
      uVar36 = param_4 + 0x60ea27ee + (uint)(0x523f4a29 < param_3);
      local_38 = param_3;
      local_28 = param_4;
      do {
        lVar3 = (ulonglong)param_1[6] * 0x27d4eb4f;
        uVar16 = (uint)lVar3;
        uVar17 = uVar16 + uVar37;
        puVar15 = param_1 + 3;
        uVar37 = param_1[7] * 0x27d4eb4f +
                 param_1[6] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_2c +
                 (uint)CARRY4(uVar16,uVar37);
        uVar16 = uVar37 >> 1;
        uVar29 = uVar17 * -0x80000000 | uVar16;
        uVar17 = uVar17 >> 1;
        uVar11 = uVar37 * -0x80000000 | uVar17;
        uVar37 = (uint)((ulonglong)uVar29 * 0x85ebca87);
        local_2c = uVar11 * -0x7a143579 +
                   uVar29 * -0x61c8864f + (int)((ulonglong)uVar29 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)param_1[4] * 0x27d4eb4f;
        uVar18 = (uint)lVar3;
        uVar19 = uVar18 + local_38;
        uVar12 = param_1[5] * 0x27d4eb4f +
                 param_1[4] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_28 +
                 (uint)CARRY4(uVar18,local_38);
        uVar18 = uVar12 >> 1;
        uVar30 = uVar19 * -0x80000000 | uVar18;
        uVar19 = uVar19 >> 1;
        uVar13 = uVar12 * -0x80000000 | uVar19;
        local_38 = (uint)((ulonglong)uVar30 * 0x85ebca87);
        puVar1 = param_1 + 1;
        local_28 = uVar13 * -0x7a143579 +
                   uVar30 * -0x61c8864f + (int)((ulonglong)uVar30 * 0x85ebca87 >> 0x20);
        puVar2 = param_1 + 2;
        lVar3 = (ulonglong)*puVar2 * 0x27d4eb4f;
        uVar12 = (uint)lVar3;
        uVar14 = *param_1;
        uVar31 = uVar12 + local_34;
        param_1 = param_1 + 8;
        uVar21 = *puVar15 * 0x27d4eb4f + *puVar2 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 local_30 + (uint)CARRY4(uVar12,local_34);
        uVar12 = uVar21 >> 1;
        uVar41 = uVar31 * -0x80000000 | uVar12;
        uVar31 = uVar31 >> 1;
        uVar22 = uVar21 * -0x80000000 | uVar31;
        local_34 = (uint)((ulonglong)uVar41 * 0x85ebca87);
        local_30 = uVar22 * -0x7a143579 +
                   uVar41 * -0x61c8864f + (int)((ulonglong)uVar41 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)uVar14 * 0x27d4eb4f;
        uVar32 = (uint)lVar3;
        uVar21 = uVar32 + uVar26;
        uVar26 = *puVar1 * 0x27d4eb4f + uVar14 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 uVar36 + (uint)CARRY4(uVar32,uVar26);
        uVar14 = uVar26 >> 1;
        uVar32 = uVar21 * -0x80000000 | uVar14;
        uVar21 = uVar21 >> 1;
        uVar20 = uVar26 * -0x80000000 | uVar21;
        uVar26 = (uint)((ulonglong)uVar32 * 0x85ebca87);
        uVar36 = uVar20 * -0x7a143579 +
                 uVar32 * -0x61c8864f + (int)((ulonglong)uVar32 * 0x85ebca87 >> 0x20);
      } while (param_1 <= puVar25 + -8);
      uVar27 = (uint)((ulonglong)uVar41 * 0xf5e54380) | local_30 >> 0x19;
      uVar33 = (uint)((ulonglong)uVar32 * 0xbd7950e) | uVar36 >> 0x1f;
      uVar42 = uVar27 + uVar33;
      uVar34 = (uint)((ulonglong)uVar30 * 0xbca87000) | local_28 >> 0x14;
      uVar43 = uVar42 + uVar34;
      uVar44 = (uint)((ulonglong)uVar32 * 0x80000000) |
               uVar20 * 0xf796ca9 +
               uVar32 * -0x210ca4ff + (int)((ulonglong)uVar32 * 0xf796ca9 >> 0x20) >> 1;
      uVar38 = (uint)((ulonglong)uVar29 * 0x2a1c0000) | local_2c >> 0xe;
      lVar3 = (ulonglong)uVar44 * 0x85ebca87;
      uVar28 = uVar43 + uVar38 ^ (uint)lVar3;
      lVar4 = (ulonglong)uVar28 * 0x85ebca87;
      uVar35 = (uint)lVar4;
      uVar39 = (uint)((ulonglong)uVar41 * 0x80000000) |
               uVar22 * 0xf796ca9 +
               uVar41 * -0x210ca4ff + (int)((ulonglong)uVar41 * 0xf796ca9 >> 0x20) >> 1;
      lVar5 = (ulonglong)uVar39 * 0x85ebca87;
      uVar37 = uVar35 + 0xc2b2ae63 ^ (uint)lVar5;
      lVar6 = (ulonglong)uVar37 * 0x85ebca87;
      uVar20 = (uint)lVar6;
      uVar13 = (uint)((ulonglong)uVar30 * 0x80000000) |
               uVar13 * 0xf796ca9 +
               uVar30 * -0x210ca4ff + (int)((ulonglong)uVar30 * 0xf796ca9 >> 0x20) >> 1;
      lVar7 = (ulonglong)uVar13 * 0x85ebca87;
      uVar36 = uVar20 + 0xc2b2ae63 ^ (uint)lVar7;
      lVar8 = (ulonglong)uVar36 * 0x85ebca87;
      uVar22 = (uint)lVar8;
      uVar11 = (uint)((ulonglong)uVar29 * 0x80000000) |
               uVar11 * 0xf796ca9 +
               uVar29 * -0x210ca4ff + (int)((ulonglong)uVar29 * 0xf796ca9 >> 0x20) >> 1;
      lVar9 = (ulonglong)uVar11 * 0x85ebca87;
      uVar23 = uVar22 + 0xc2b2ae63 ^ (uint)lVar9;
      lVar10 = (ulonglong)uVar23 * 0x85ebca87;
      uVar40 = (uint)lVar10;
      uVar26 = uVar40 + 0xc2b2ae63;
      iVar24 = ((((uVar31 * -0xa1abc80 +
                   uVar12 * 0x1bbcd8c2 + (int)((ulonglong)uVar41 * 0xf5e54380 >> 0x20) +
                   uVar21 * 0xbd7950e +
                   uVar32 * 0x3c6ef363 + (int)((ulonglong)uVar32 * 0xbd7950e >> 0x20) +
                   (uint)CARRY4(uVar27,uVar33) +
                   uVar19 * -0x43579000 +
                   uVar18 * 0x779b185e + (int)((ulonglong)uVar30 * 0xbca87000 >> 0x20) +
                   (uint)CARRY4(uVar42,uVar34) +
                   uVar17 * 0x2a1c0000 +
                   uVar29 * -0x1939e851 + (int)((ulonglong)uVar29 * 0x2a1c0000 >> 0x20) +
                   (uint)CARRY4(uVar43,uVar38) ^
                  (uVar21 * -0x80000000 +
                  uVar14 * -0x784349ac + (int)((ulonglong)uVar32 * 0x80000000 >> 0x20)) *
                  -0x7a143579 + uVar44 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20)) *
                  -0x7a143579 + uVar28 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20) + -0x7a143589
                  + (uint)(0x3d4d519c < uVar35) ^
                 (uVar31 * -0x80000000 +
                 uVar12 * -0x784349ac + (int)((ulonglong)uVar41 * 0x80000000 >> 0x20)) * -0x7a143579
                 + uVar39 * -0x61c8864f + (int)((ulonglong)lVar5 >> 0x20)) * -0x7a143579 +
                 uVar37 * -0x61c8864f + (int)((ulonglong)lVar6 >> 0x20) + -0x7a143589 +
                 (uint)(0x3d4d519c < uVar20) ^
                (uVar19 * -0x80000000 +
                uVar18 * -0x784349ac + (int)((ulonglong)uVar30 * 0x80000000 >> 0x20)) * -0x7a143579
                + uVar13 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20)) * -0x7a143579 +
                uVar36 * -0x61c8864f + (int)((ulonglong)lVar8 >> 0x20) + -0x7a143589 +
                (uint)(0x3d4d519c < uVar22) ^
               (uVar17 * -0x80000000 +
               uVar16 * -0x784349ac + (int)((ulonglong)uVar29 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar11 * -0x61c8864f + (int)((ulonglong)lVar9 >> 0x20)) * -0x7a143579 +
               uVar23 * -0x61c8864f + (int)((ulonglong)lVar10 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar40);
    }
    uVar37 = uVar26 + param_2;
    uVar26 = iVar24 + (uint)CARRY4(uVar26,param_2);
    puVar15 = param_1 + 2;
    while (puVar15 <= puVar25) {
      uVar17 = *param_1;
      uVar36 = (uint)((ulonglong)uVar17 * 0x80000000) |
               param_1[1] * 0x27d4eb4f +
               uVar17 * -0x3d4d51c3 + (int)((ulonglong)uVar17 * 0x27d4eb4f >> 0x20) >> 1;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar16 = (uint)lVar3 ^ uVar37;
      uVar26 = (param_1[1] * -0x80000000 +
               uVar17 * -0x6c158a59 + (int)((ulonglong)uVar17 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar36 = uVar16 << 0x1b | uVar26 >> 5;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0xc2b2ae63;
      uVar26 = (uVar26 << 0x1b | uVar16 >> 5) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar17);
      puVar15 = param_1 + 4;
      param_1 = param_1 + 2;
    }
    if (param_1 + 1 <= puVar25) {
      lVar3 = (ulonglong)*param_1 * 0x85ebca87;
      uVar36 = (uint)lVar3 ^ uVar37;
      uVar26 = *param_1 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar16 = uVar36 << 0x17 | uVar26 >> 9;
      lVar3 = (ulonglong)uVar16 * 0x27d4eb4f;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0x9e3779f9;
      uVar26 = (uVar26 << 0x17 | uVar36 >> 9) * 0x27d4eb4f +
               uVar16 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + 0x165667b1 +
               (uint)(0x61c88606 < uVar17);
      param_1 = param_1 + 1;
    }
    if (param_1 < puVar25) {
      do {
        puVar15 = (uint *)((int)param_1 + 1);
        lVar3 = (ulonglong)(uint)*(byte *)param_1 * 0x165667c5;
        uVar36 = (uint)lVar3 ^ uVar37;
        uVar26 = (uint)*(byte *)param_1 * 0x27d4eb2f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
        uVar16 = uVar36 << 0xb | uVar26 >> 0x15;
        lVar3 = (ulonglong)uVar16 * 0x85ebca87;
        uVar37 = (uint)lVar3;
        uVar26 = (uVar26 << 0xb | uVar36 >> 0x15) * -0x7a143579 +
                 uVar16 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20);
        param_1 = puVar15;
      } while (puVar25 != puVar15);
    }
  }
  uVar37 = uVar37 ^ uVar26 >> 1;
  lVar3 = (ulonglong)uVar37 * 0x27d4eb4f;
  uVar36 = (uint)lVar3;
  uVar26 = uVar26 * 0x27d4eb4f + uVar37 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20);
  uVar36 = (uVar36 >> 0x1d | uVar26 * 8) ^ uVar36;
  lVar3 = (ulonglong)uVar36 * 0x9e3779f9;
  return (uVar26 ^ uVar26 >> 0x1d) * -0x61c88607 +
         uVar36 * 0x165667b1 + (int)((ulonglong)lVar3 >> 0x20) ^ (uint)lVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00023528 FUN_00023528 */

undefined4 FUN_00023528(undefined4 param_1,int param_2)

{
  undefined auStack_48 [8];
  int local_40;
  int local_3c;
  int local_38;
  int local_34;
  
  FUN_00036050(auStack_48,0,0x2c);
  local_34 = param_2 + 0x61c8864f;
  local_3c = param_2 + -0x7a143589;
  local_40 = param_2 + 0x24234428;
  local_38 = param_2;
  FUN_00036044(param_1,auStack_48,0x30);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000235a0 FUN_000235a0 */

undefined4 FUN_000235a0(undefined4 param_1,undefined4 param_2,uint param_3,int param_4)

{
  undefined auStack_70 [8];
  int local_68;
  int local_64;
  int local_60;
  int local_5c;
  uint local_58;
  int local_54;
  int local_50;
  int local_4c;
  
  FUN_00036050(auStack_70,0,0x50);
  local_50 = param_3 + 0x7a143579;
  local_4c = param_4 + 0x61c8864e + (uint)(0x85ebca86 < param_3);
  local_60 = param_3 + 0x27d4eb4f;
  local_5c = param_4 + -0x3d4d51c3 + (uint)(0xd82b14b0 < param_3);
  local_68 = param_3 + 0xadc0b5d6;
  local_64 = param_4 + 0x60ea27ee + (uint)(0x523f4a29 < param_3);
  local_58 = param_3;
  local_54 = param_4;
  FUN_00036044(param_1,auStack_70,0x58);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00023650 FUN_00023650 */

undefined4 FUN_00023650(uint *param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  
  uVar5 = param_1[1];
  uVar4 = param_1[10];
  if (0xf < (*param_1 + param_3 | param_3)) {
    uVar5 = uVar5 | 1;
  }
  *param_1 = *param_1 + param_3;
  param_1[1] = uVar5;
  if (uVar4 + param_3 < 0x10) {
    FUN_00036044((int)param_1 + uVar4 + 0x18,param_2,param_3);
    param_3 = param_1[10] + param_3;
  }
  else {
    piVar9 = (int *)((int)param_2 + param_3);
    if (uVar4 != 0) {
      FUN_00036044((int)param_1 + uVar4 + 0x18,param_2,0x10 - uVar4);
      uVar4 = param_1[9] * -0x7a143589 + param_1[5];
      uVar5 = param_1[6] * -0x7a143589 + param_1[2];
      uVar6 = param_1[7] * -0x7a143589 + param_1[3];
      uVar7 = param_1[8] * -0x7a143589 + param_1[4];
      uVar8 = param_1[10];
      param_1[10] = 0;
      param_1[2] = (uVar5 >> 0x13 | uVar5 * 0x2000) * -0x61c8864f;
      param_1[3] = (uVar6 >> 0x13 | uVar6 * 0x2000) * -0x61c8864f;
      param_1[4] = (uVar7 >> 0x13 | uVar7 * 0x2000) * -0x61c8864f;
      param_1[5] = (uVar4 >> 0x13 | uVar4 * 0x2000) * -0x61c8864f;
      param_2 = (int *)((int)param_2 + (0x10 - uVar8));
    }
    if (param_2 <= piVar9 + -4) {
      uVar4 = param_1[2];
      uVar7 = param_1[3];
      uVar6 = param_1[4];
      uVar5 = param_1[5];
      do {
        piVar1 = param_2 + 2;
        iVar3 = *param_2;
        piVar2 = param_2 + 1;
        uVar5 = param_2[3] * -0x7a143589 + uVar5;
        param_2 = param_2 + 4;
        uVar6 = *piVar1 * -0x7a143589 + uVar6;
        uVar4 = iVar3 * -0x7a143589 + uVar4;
        uVar7 = *piVar2 * -0x7a143589 + uVar7;
        uVar5 = (uVar5 >> 0x13 | uVar5 * 0x2000) * -0x61c8864f;
        uVar6 = (uVar6 >> 0x13 | uVar6 * 0x2000) * -0x61c8864f;
        uVar4 = (uVar4 >> 0x13 | uVar4 * 0x2000) * -0x61c8864f;
        uVar7 = (uVar7 >> 0x13 | uVar7 * 0x2000) * -0x61c8864f;
      } while (param_2 <= piVar9 + -4);
      param_1[2] = uVar4;
      param_1[3] = uVar7;
      param_1[4] = uVar6;
      param_1[5] = uVar5;
    }
    if (piVar9 <= param_2) {
      return 0;
    }
    param_3 = (int)piVar9 - (int)param_2;
    FUN_00036044(param_1 + 6,param_2,param_3);
  }
  param_1[10] = param_3;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000237fc FUN_000237fc */

uint FUN_000237fc(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)((int)(param_1 + 6) + param_1[10]);
  if (param_1[1] == 0) {
    iVar2 = param_1[4] + 0x165667b1;
  }
  else {
    iVar2 = ((uint)param_1[3] >> 0x19 | param_1[3] << 7) +
            ((uint)param_1[2] >> 0x1f | param_1[2] << 1) +
            ((uint)param_1[4] >> 0x14 | param_1[4] << 0xc) +
            ((uint)param_1[5] >> 0xe | param_1[5] << 0x12);
  }
  uVar3 = *param_1 + iVar2;
  piVar4 = param_1 + 7;
  piVar5 = param_1 + 6;
  while (piVar4 <= piVar1) {
    uVar3 = *piVar5 * -0x3d4d51c3 + uVar3;
    uVar3 = (uVar3 >> 0xf | uVar3 * 0x20000) * 0x27d4eb2f;
    piVar4 = piVar5 + 2;
    piVar5 = piVar5 + 1;
  }
  if (piVar5 < piVar1) {
    do {
      piVar1 = (int *)((int)piVar5 + 1);
      uVar3 = (uint)*(byte *)piVar5 * 0x165667b1 + uVar3;
      uVar3 = (uVar3 >> 0x15 | uVar3 * 0x800) * -0x61c8864f;
      piVar5 = piVar1;
    } while ((int *)((int)param_1 + param_1[10] + 0x18) != piVar1);
  }
  uVar3 = (uVar3 ^ uVar3 >> 0xf) * -0x7a143589;
  uVar3 = (uVar3 ^ uVar3 >> 0xd) * -0x3d4d51c3;
  return uVar3 ^ uVar3 >> 0x10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000238ec FUN_000238ec */

undefined4 FUN_000238ec(uint *param_1,uint *param_2,uint param_3)

{
  uint *puVar1;
  uint *puVar2;
  uint *puVar3;
  longlong lVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint uVar11;
  uint *puVar12;
  uint *puVar13;
  uint uVar14;
  uint *puVar15;
  uint *puVar16;
  uint uVar17;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  
  uVar5 = *param_1;
  uVar6 = param_1[0x12];
  *param_1 = uVar5 + param_3;
  param_1[1] = param_1[1] + (uint)CARRY4(uVar5,param_3);
  if (uVar6 + param_3 < 0x20) {
    FUN_00036044((int)param_1 + uVar6 + 0x28,param_2,param_3);
    param_3 = param_1[0x12] + param_3;
  }
  else {
    puVar7 = (uint *)((int)param_2 + param_3);
    puVar13 = param_1 + 2;
    puVar12 = param_1 + 10;
    puVar16 = param_1 + 4;
    puVar15 = param_1 + 6;
    puVar10 = param_1 + 8;
    if (uVar6 != 0) {
      FUN_00036044((int)puVar12 + uVar6,param_2,0x20 - uVar6);
      lVar4 = (ulonglong)*puVar12 * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar6 = uVar5 + *puVar13;
      uVar5 = param_1[0xb] * 0x27d4eb4f + *puVar12 * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) +
              param_1[3] + (uint)CARRY4(uVar5,*puVar13);
      uVar8 = uVar6 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar8 * 0x85ebca87;
      *puVar13 = (uint)lVar4;
      param_1[3] = (uVar5 * -0x80000000 | uVar6 >> 1) * -0x7a143579 +
                   uVar8 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      lVar4 = (ulonglong)param_1[0xc] * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar8 = uVar5 + *puVar16;
      uVar5 = param_1[0xd] * 0x27d4eb4f +
              param_1[0xc] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + param_1[5] +
              (uint)CARRY4(uVar5,*puVar16);
      uVar6 = uVar8 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar6 * 0x85ebca87;
      *puVar16 = (uint)lVar4;
      param_1[5] = (uVar5 * -0x80000000 | uVar8 >> 1) * -0x7a143579 +
                   uVar6 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      lVar4 = (ulonglong)param_1[0xe] * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar8 = uVar5 + *puVar15;
      uVar5 = param_1[0xf] * 0x27d4eb4f +
              param_1[0xe] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + param_1[7] +
              (uint)CARRY4(uVar5,*puVar15);
      uVar6 = uVar8 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar6 * 0x85ebca87;
      *puVar15 = (uint)lVar4;
      param_1[7] = (uVar5 * -0x80000000 | uVar8 >> 1) * -0x7a143579 +
                   uVar6 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      lVar4 = (ulonglong)param_1[0x10] * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar8 = uVar5 + *puVar10;
      uVar5 = param_1[0x11] * 0x27d4eb4f +
              param_1[0x10] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + param_1[9] +
              (uint)CARRY4(uVar5,*puVar10);
      uVar6 = uVar8 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar6 * 0x85ebca87;
      *puVar10 = (uint)lVar4;
      param_1[9] = (uVar5 * -0x80000000 | uVar8 >> 1) * -0x7a143579 +
                   uVar6 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      uVar5 = param_1[0x12];
      param_1[0x12] = 0;
      param_2 = (uint *)((int)param_2 + (0x20 - uVar5));
    }
    if (param_2 + 8 <= puVar7) {
      local_30 = *puVar10;
      local_34 = param_1[9];
      local_2c = param_1[7];
      uVar5 = *puVar15;
      local_28 = *puVar16;
      uVar8 = param_1[5];
      uVar6 = *puVar13;
      uVar17 = param_1[3];
      do {
        lVar4 = (ulonglong)param_2[6] * 0x27d4eb4f;
        uVar14 = (uint)lVar4;
        uVar11 = uVar14 + local_30;
        puVar1 = param_2 + 1;
        uVar9 = param_2[7] * 0x27d4eb4f + param_2[6] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20)
                + local_34 + (uint)CARRY4(uVar14,local_30);
        uVar14 = uVar11 * -0x80000000 | uVar9 >> 1;
        lVar4 = (ulonglong)uVar14 * 0x85ebca87;
        local_30 = (uint)lVar4;
        local_34 = (uVar9 * -0x80000000 | uVar11 >> 1) * -0x7a143579 +
                   uVar14 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
        lVar4 = (ulonglong)param_2[4] * 0x27d4eb4f;
        uVar14 = (uint)lVar4;
        uVar9 = uVar14 + uVar5;
        uVar11 = param_2[5] * 0x27d4eb4f +
                 param_2[4] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + local_2c +
                 (uint)CARRY4(uVar14,uVar5);
        uVar14 = uVar9 * -0x80000000 | uVar11 >> 1;
        puVar2 = param_2 + 2;
        lVar4 = (ulonglong)uVar14 * 0x85ebca87;
        uVar5 = (uint)lVar4;
        puVar3 = param_2 + 3;
        local_2c = (uVar11 * -0x80000000 | uVar9 >> 1) * -0x7a143579 +
                   uVar14 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
        uVar11 = *param_2;
        param_2 = param_2 + 8;
        lVar4 = (ulonglong)*puVar2 * 0x27d4eb4f;
        uVar14 = (uint)lVar4;
        uVar9 = uVar14 + local_28;
        uVar8 = *puVar3 * 0x27d4eb4f + *puVar2 * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) +
                uVar8 + (uint)CARRY4(uVar14,local_28);
        uVar14 = uVar9 * -0x80000000 | uVar8 >> 1;
        lVar4 = (ulonglong)uVar14 * 0x85ebca87;
        local_28 = (uint)lVar4;
        uVar8 = (uVar8 * -0x80000000 | uVar9 >> 1) * -0x7a143579 +
                uVar14 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
        lVar4 = (ulonglong)uVar11 * 0x27d4eb4f;
        uVar14 = (uint)lVar4;
        uVar9 = uVar14 + uVar6;
        uVar17 = *puVar1 * 0x27d4eb4f + uVar11 * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) +
                 uVar17 + (uint)CARRY4(uVar14,uVar6);
        uVar14 = uVar9 * -0x80000000 | uVar17 >> 1;
        lVar4 = (ulonglong)uVar14 * 0x85ebca87;
        uVar6 = (uint)lVar4;
        uVar17 = (uVar17 * -0x80000000 | uVar9 >> 1) * -0x7a143579 +
                 uVar14 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      } while (param_2 <= puVar7 + -8);
      *puVar13 = uVar6;
      param_1[3] = uVar17;
      *puVar16 = local_28;
      param_1[5] = uVar8;
      *puVar15 = uVar5;
      param_1[7] = local_2c;
      *puVar10 = local_30;
      param_1[9] = local_34;
    }
    if (puVar7 <= param_2) {
      return 0;
    }
    param_3 = (int)puVar7 - (int)param_2;
    FUN_00036044(puVar12,param_2,param_3);
  }
  param_1[0x12] = param_3;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00023dc8 FUN_00023dc8 */

uint FUN_00023dc8(uint *param_1)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint *puVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  int iVar34;
  uint *puVar35;
  uint uVar36;
  uint *puVar37;
  uint uVar38;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  
  uVar17 = *param_1;
  uVar22 = param_1[1];
  puVar37 = (uint *)((int)(param_1 + 10) + param_1[0x12]);
  if (uVar22 == 0 && (0x1f < uVar17) <= uVar22) {
    uVar9 = param_1[6];
    uVar13 = uVar9 + 0x165667c5;
    iVar34 = param_1[7] + 0x27d4eb2f + (uint)(0xe9a9983a < uVar9);
  }
  else {
    uVar9 = param_1[2];
    uVar21 = param_1[3];
    uVar18 = param_1[5];
    uVar38 = param_1[4];
    uVar26 = uVar9 << 1 | uVar21 >> 0x1f;
    uVar27 = uVar38 << 7 | uVar18 >> 0x19;
    uVar40 = uVar27 + uVar26;
    uVar19 = param_1[7];
    uVar23 = param_1[6];
    uVar28 = uVar23 << 0xc | uVar19 >> 0x14;
    uVar24 = uVar40 + uVar28;
    uVar36 = (uint)((ulonglong)uVar9 * 0x80000000) |
             uVar21 * 0x27d4eb4f +
             uVar9 * -0x3d4d51c3 + (int)((ulonglong)uVar9 * 0x27d4eb4f >> 0x20) >> 1;
    uVar20 = param_1[8];
    uVar15 = param_1[9];
    uVar29 = uVar20 << 0x12 | uVar15 >> 0xe;
    lVar1 = (ulonglong)uVar36 * 0x85ebca87;
    uVar30 = uVar24 + uVar29 ^ (uint)lVar1;
    lVar2 = (ulonglong)uVar30 * 0x85ebca87;
    uVar25 = (uint)lVar2;
    uVar10 = (uint)((ulonglong)uVar38 * 0x80000000) |
             uVar18 * 0x27d4eb4f +
             uVar38 * -0x3d4d51c3 + (int)((ulonglong)uVar38 * 0x27d4eb4f >> 0x20) >> 1;
    lVar3 = (ulonglong)uVar10 * 0x85ebca87;
    uVar31 = uVar25 + 0xc2b2ae63 ^ (uint)lVar3;
    lVar4 = (ulonglong)uVar31 * 0x85ebca87;
    uVar41 = (uint)lVar4;
    uVar11 = (uint)((ulonglong)uVar23 * 0x80000000) |
             uVar19 * 0x27d4eb4f +
             uVar23 * -0x3d4d51c3 + (int)((ulonglong)uVar23 * 0x27d4eb4f >> 0x20) >> 1;
    lVar5 = (ulonglong)uVar11 * 0x85ebca87;
    uVar32 = uVar41 + 0xc2b2ae63 ^ (uint)lVar5;
    lVar6 = (ulonglong)uVar32 * 0x85ebca87;
    uVar39 = (uint)lVar6;
    uVar12 = (uint)((ulonglong)uVar20 * 0x80000000) |
             uVar15 * 0x27d4eb4f +
             uVar20 * -0x3d4d51c3 + (int)((ulonglong)uVar20 * 0x27d4eb4f >> 0x20) >> 1;
    lVar7 = (ulonglong)uVar12 * 0x85ebca87;
    uVar33 = uVar39 + 0xc2b2ae63 ^ (uint)lVar7;
    lVar8 = (ulonglong)uVar33 * 0x85ebca87;
    uVar16 = (uint)lVar8;
    uVar13 = uVar16 + 0xc2b2ae63;
    iVar34 = (((((uVar18 << 7 | uVar38 >> 0x19) + (uVar21 << 1 | uVar9 >> 0x1f) +
                 (uint)CARRY4(uVar27,uVar26) + (uVar19 << 0xc | uVar23 >> 0x14) +
                 (uint)CARRY4(uVar40,uVar28) + (uVar15 << 0x12 | uVar20 >> 0xe) +
                 (uint)CARRY4(uVar24,uVar29) ^
                (uVar21 * -0x80000000 +
                uVar9 * -0x6c158a59 + (int)((ulonglong)uVar9 * 0x80000000 >> 0x20)) * -0x7a143579 +
                uVar36 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20)) * -0x7a143579 +
                uVar30 * -0x61c8864f + (int)((ulonglong)lVar2 >> 0x20) + -0x7a143589 +
                (uint)(0x3d4d519c < uVar25) ^
               (uVar18 * -0x80000000 +
               uVar38 * -0x6c158a59 + (int)((ulonglong)uVar38 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar10 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20)) * -0x7a143579 +
               uVar31 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar41) ^
              (uVar19 * -0x80000000 +
              uVar23 * -0x6c158a59 + (int)((ulonglong)uVar23 * 0x80000000 >> 0x20)) * -0x7a143579 +
              uVar11 * -0x61c8864f + (int)((ulonglong)lVar5 >> 0x20)) * -0x7a143579 +
              uVar32 * -0x61c8864f + (int)((ulonglong)lVar6 >> 0x20) + -0x7a143589 +
              (uint)(0x3d4d519c < uVar39) ^
             (uVar15 * -0x80000000 +
             uVar20 * -0x6c158a59 + (int)((ulonglong)uVar20 * 0x80000000 >> 0x20)) * -0x7a143579 +
             uVar12 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20)) * -0x7a143579 +
             uVar33 * -0x61c8864f + (int)((ulonglong)lVar8 >> 0x20) + -0x7a143589 +
             (uint)(0x3d4d519c < uVar16);
  }
  uVar9 = uVar13 + uVar17;
  uVar17 = iVar34 + uVar22 + (uint)CARRY4(uVar13,uVar17);
  puVar14 = param_1 + 0xc;
  puVar35 = param_1 + 10;
  while (puVar14 <= puVar37) {
    uVar22 = *puVar35;
    uVar13 = (uint)((ulonglong)uVar22 * 0x80000000) |
             puVar35[1] * 0x27d4eb4f +
             uVar22 * -0x3d4d51c3 + (int)((ulonglong)uVar22 * 0x27d4eb4f >> 0x20) >> 1;
    lVar1 = (ulonglong)uVar13 * 0x85ebca87;
    uVar10 = (uint)lVar1 ^ uVar9;
    uVar17 = (puVar35[1] * -0x80000000 +
             uVar22 * -0x6c158a59 + (int)((ulonglong)uVar22 * 0x80000000 >> 0x20)) * -0x7a143579 +
             uVar13 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20) ^ uVar17;
    uVar22 = uVar10 << 0x1b | uVar17 >> 5;
    lVar1 = (ulonglong)uVar22 * 0x85ebca87;
    uVar13 = (uint)lVar1;
    uVar9 = uVar13 + 0xc2b2ae63;
    uVar17 = (uVar17 << 0x1b | uVar10 >> 5) * -0x7a143579 +
             uVar22 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20) + -0x7a143589 +
             (uint)(0x3d4d519c < uVar13);
    puVar14 = puVar35 + 4;
    puVar35 = puVar35 + 2;
  }
  if (puVar35 + 1 <= puVar37) {
    lVar1 = (ulonglong)*puVar35 * 0x85ebca87;
    uVar22 = (uint)lVar1 ^ uVar9;
    uVar17 = *puVar35 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20) ^ uVar17;
    uVar13 = uVar22 << 0x17 | uVar17 >> 9;
    lVar1 = (ulonglong)uVar13 * 0x27d4eb4f;
    uVar10 = (uint)lVar1;
    uVar9 = uVar10 + 0x9e3779f9;
    uVar17 = (uVar17 << 0x17 | uVar22 >> 9) * 0x27d4eb4f +
             uVar13 * -0x3d4d51c3 + (int)((ulonglong)lVar1 >> 0x20) + 0x165667b1 +
             (uint)(0x61c88606 < uVar10);
    puVar35 = puVar35 + 1;
  }
  if (puVar35 < puVar37) {
    do {
      puVar37 = (uint *)((int)puVar35 + 1);
      lVar1 = (ulonglong)(uint)*(byte *)puVar35 * 0x165667c5;
      uVar22 = (uint)lVar1 ^ uVar9;
      uVar17 = (uint)*(byte *)puVar35 * 0x27d4eb2f + (int)((ulonglong)lVar1 >> 0x20) ^ uVar17;
      uVar13 = uVar22 << 0xb | uVar17 >> 0x15;
      lVar1 = (ulonglong)uVar13 * 0x85ebca87;
      uVar9 = (uint)lVar1;
      uVar17 = (uVar17 << 0xb | uVar22 >> 0x15) * -0x7a143579 +
               uVar13 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20);
      puVar35 = puVar37;
    } while ((uint *)((int)param_1 + param_1[0x12] + 0x28) != puVar37);
  }
  uVar9 = uVar9 ^ uVar17 >> 1;
  lVar1 = (ulonglong)uVar9 * 0x27d4eb4f;
  uVar22 = (uint)lVar1;
  uVar17 = uVar17 * 0x27d4eb4f + uVar9 * -0x3d4d51c3 + (int)((ulonglong)lVar1 >> 0x20);
  uVar22 = (uVar22 >> 0x1d | uVar17 * 8) ^ uVar22;
  lVar1 = (ulonglong)uVar22 * 0x9e3779f9;
  return (uVar17 ^ uVar17 >> 0x1d) * -0x61c88607 +
         uVar22 * 0x165667b1 + (int)((ulonglong)lVar1 >> 0x20) ^ (uint)lVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00024348 FUN_00024348 */

void FUN_00024348(undefined4 param_1,uint param_2)

{
  uint local_c;
  
  local_c = param_2 << 0x18 | (param_2 >> 8 & 0xff) << 0x10 | (param_2 >> 0x10 & 0xff) << 8 |
            param_2 >> 0x18;
  FUN_00036044(param_1,&local_c,4);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00024370 FUN_00024370 */

void FUN_00024370(undefined4 param_1,undefined4 param_2,uint param_3,uint param_4)

{
  uint local_10;
  uint local_c;
  
  local_c = param_3 << 0x18 | (param_3 >> 8 & 0xff) << 0x10 | (param_3 >> 0x10 & 0xff) << 8 |
            param_3 >> 0x18;
  local_10 = param_4 << 0x18 | (param_4 >> 8 & 0xff) << 0x10 | (param_4 >> 0x10 & 0xff) << 8 |
             param_4 >> 0x18;
  FUN_00036044(param_1,&local_10,8);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000243e8 FUN_000243e8 */

void FUN_000243e8(undefined4 param_1,code *UNRECOVERED_JUMPTABLE,undefined4 param_3,
                 undefined4 param_4)

{
  if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000243fc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_4);
    return;
  }
  FUN_000246b0(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00024408 FUN_00024408 */

undefined4 FUN_00024408(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  if (param_2 != (code *)0x0) {
    uVar1 = (*param_2)(param_4,param_1);
    FUN_00036050(uVar1,0,param_1);
    return uVar1;
  }
  uVar1 = FUN_00026b28(1,param_1);
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00024454 FUN_00024454 */

void FUN_00024454(int param_1,undefined4 param_2,code *UNRECOVERED_JUMPTABLE,undefined4 param_4)

{
  if (param_1 == 0) {
    return;
  }
  if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0002446c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_4);
    return;
  }
  FUN_00025e5c(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00024478 FUN_00024478 */

ulonglong FUN_00024478(uint param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  bool bVar8;
  bool bVar9;
  bool bVar10;
  bool bVar11;
  bool bVar12;
  bool bVar13;
  bool bVar14;
  bool bVar15;
  bool bVar16;
  bool bVar17;
  bool bVar18;
  bool bVar19;
  bool bVar20;
  bool bVar21;
  bool bVar22;
  bool bVar23;
  bool bVar24;
  bool bVar25;
  bool bVar26;
  bool bVar27;
  bool bVar28;
  bool bVar29;
  bool bVar30;
  bool bVar31;
  bool bVar32;
  bool bVar33;
  ulonglong uVar34;
  
  if (param_2 - 1 == 0) {
    return CONCAT44(param_2,param_1);
  }
  if (param_2 == 0) {
    uVar1 = FUN_00036074(8);
    return (ulonglong)uVar1;
  }
  if (param_1 <= param_2) {
    return CONCAT44(param_2,(uint)(param_1 == param_2));
  }
  if ((param_2 & param_2 - 1) == 0) {
    return CONCAT44(param_2,param_1 >> (0x1fU - LZCOUNT(param_2) & 0xff));
  }
  iVar2 = 0x1f - (LZCOUNT(param_2) - LZCOUNT(param_1));
  if (iVar2 == 0) {
    bVar3 = param_2 << 0x1f <= param_1;
    if (bVar3) {
      param_1 = param_1 + param_2 * -0x80000000;
    }
    bVar4 = param_2 << 0x1e <= param_1;
    if (bVar4) {
      param_1 = param_1 + param_2 * -0x40000000;
    }
    bVar5 = param_2 << 0x1d <= param_1;
    if (bVar5) {
      param_1 = param_1 + param_2 * -0x20000000;
    }
    bVar6 = param_2 << 0x1c <= param_1;
    if (bVar6) {
      param_1 = param_1 + param_2 * -0x10000000;
    }
    bVar7 = param_2 << 0x1b <= param_1;
    if (bVar7) {
      param_1 = param_1 + param_2 * -0x8000000;
    }
    bVar8 = param_2 << 0x1a <= param_1;
    if (bVar8) {
      param_1 = param_1 + param_2 * -0x4000000;
    }
    bVar9 = param_2 << 0x19 <= param_1;
    if (bVar9) {
      param_1 = param_1 + param_2 * -0x2000000;
    }
    bVar10 = param_2 << 0x18 <= param_1;
    if (bVar10) {
      param_1 = param_1 + param_2 * -0x1000000;
    }
    bVar11 = param_2 << 0x17 <= param_1;
    if (bVar11) {
      param_1 = param_1 + param_2 * -0x800000;
    }
    bVar12 = param_2 << 0x16 <= param_1;
    if (bVar12) {
      param_1 = param_1 + param_2 * -0x400000;
    }
    bVar13 = param_2 << 0x15 <= param_1;
    if (bVar13) {
      param_1 = param_1 + param_2 * -0x200000;
    }
    bVar14 = param_2 << 0x14 <= param_1;
    if (bVar14) {
      param_1 = param_1 + param_2 * -0x100000;
    }
    bVar15 = param_2 << 0x13 <= param_1;
    if (bVar15) {
      param_1 = param_1 + param_2 * -0x80000;
    }
    bVar16 = param_2 << 0x12 <= param_1;
    if (bVar16) {
      param_1 = param_1 + param_2 * -0x40000;
    }
    bVar17 = param_2 << 0x11 <= param_1;
    if (bVar17) {
      param_1 = param_1 + param_2 * -0x20000;
    }
    bVar18 = param_2 << 0x10 <= param_1;
    if (bVar18) {
      param_1 = param_1 + param_2 * -0x10000;
    }
    bVar19 = param_2 << 0xf <= param_1;
    if (bVar19) {
      param_1 = param_1 + param_2 * -0x8000;
    }
    bVar20 = param_2 << 0xe <= param_1;
    if (bVar20) {
      param_1 = param_1 + param_2 * -0x4000;
    }
    bVar21 = param_2 << 0xd <= param_1;
    if (bVar21) {
      param_1 = param_1 + param_2 * -0x2000;
    }
    bVar22 = param_2 << 0xc <= param_1;
    if (bVar22) {
      param_1 = param_1 + param_2 * -0x1000;
    }
    bVar23 = param_2 << 0xb <= param_1;
    if (bVar23) {
      param_1 = param_1 + param_2 * -0x800;
    }
    bVar24 = param_2 << 10 <= param_1;
    if (bVar24) {
      param_1 = param_1 + param_2 * -0x400;
    }
    bVar25 = param_2 << 9 <= param_1;
    if (bVar25) {
      param_1 = param_1 + param_2 * -0x200;
    }
    bVar26 = param_2 << 8 <= param_1;
    if (bVar26) {
      param_1 = param_1 + param_2 * -0x100;
    }
    bVar27 = param_2 << 7 <= param_1;
    if (bVar27) {
      param_1 = param_1 + param_2 * -0x80;
    }
    bVar28 = param_2 << 6 <= param_1;
    if (bVar28) {
      param_1 = param_1 + param_2 * -0x40;
    }
    bVar29 = param_2 << 5 <= param_1;
    if (bVar29) {
      param_1 = param_1 + param_2 * -0x20;
    }
    bVar30 = param_2 << 4 <= param_1;
    if (bVar30) {
      param_1 = param_1 + param_2 * -0x10;
    }
    bVar31 = param_2 << 3 <= param_1;
    if (bVar31) {
      param_1 = param_1 + param_2 * -8;
    }
    bVar32 = param_2 << 2 <= param_1;
    if (bVar32) {
      param_1 = param_1 + param_2 * -4;
    }
    bVar33 = param_2 << 1 <= param_1;
    if (bVar33) {
      param_1 = param_1 + param_2 * -2;
    }
    return CONCAT44(param_2,(((((((((((((((((((((((((((((((uint)bVar3 * 2 + (uint)bVar4) * 2 +
                                                        (uint)bVar5) * 2 + (uint)bVar6) * 2 +
                                                      (uint)bVar7) * 2 + (uint)bVar8) * 2 +
                                                    (uint)bVar9) * 2 + (uint)bVar10) * 2 +
                                                  (uint)bVar11) * 2 + (uint)bVar12) * 2 +
                                                (uint)bVar13) * 2 + (uint)bVar14) * 2 + (uint)bVar15
                                              ) * 2 + (uint)bVar16) * 2 + (uint)bVar17) * 2 +
                                           (uint)bVar18) * 2 + (uint)bVar19) * 2 + (uint)bVar20) * 2
                                        + (uint)bVar21) * 2 + (uint)bVar22) * 2 + (uint)bVar23) * 2
                                     + (uint)bVar24) * 2 + (uint)bVar25) * 2 + (uint)bVar26) * 2 +
                                  (uint)bVar27) * 2 + (uint)bVar28) * 2 + (uint)bVar29) * 2 +
                               (uint)bVar30) * 2 + (uint)bVar31) * 2 + (uint)bVar32) * 2 +
                            (uint)bVar33) * 2 + (uint)(param_2 <= param_1));
  }
                    /* WARNING: Could not recover jumptable at 0x000244ac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar34 = (*(code *)(iVar2 * 0xc + 0x244b4))();
  return uVar34;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00024664 FUN_00024664 */

void FUN_00024664(undefined4 param_1,int param_2)

{
  if (param_2 != 0) {
    FUN_00024478();
    return;
  }
  FUN_00036074(8);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000246b0 FUN_000246b0 */

/* WARNING: Type propagation algorithm not settling */

uint ** FUN_000246b0(uint param_1)

{
  uint **ppuVar1;
  uint **ppuVar2;
  uint *puVar3;
  uint **ppuVar4;
  uint uVar5;
  int iVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  uint **ppuVar12;
  uint uVar13;
  uint **ppuVar14;
  uint uVar15;
  uint uVar16;
  uint **ppuVar17;
  uint uVar18;
  undefined4 *puVar19;
  uint **ppuVar20;
  uint *puVar21;
  uint uVar22;
  uint uVar23;
  undefined4 *puVar24;
  undefined4 *puVar25;
  undefined4 *puVar26;
  uint *puVar27;
  uint uVar28;
  undefined4 *puVar29;
  uint *puVar30;
  undefined4 *puVar31;
  undefined4 *puVar32;
  bool bVar33;
  bool bVar34;
  undefined8 uVar35;
  
  iVar6 = DAT_00025654;
  puVar30 = (uint *)(DAT_00025654 + 0x246d4);
  if (param_1 < 0xf5) {
    uVar28 = param_1 + 0xb & 0xfffffff8;
    if (param_1 < 0xb) {
      uVar28 = 0x10;
    }
    uVar8 = uVar28 >> 3;
    uVar5 = *(uint *)(DAT_00025658 + 0x246f8);
    uVar13 = uVar5 >> (uVar8 & 0xff);
    if ((uVar5 >> (uVar8 & 0xff) & 3) != 0) {
      uVar8 = (~uVar13 & 1) + uVar8;
      uVar28 = puVar30[uVar8 * 2 + 0xb];
      puVar21 = *(uint **)(uVar28 + 8);
      if (puVar21[3] == uVar28) {
        if (puVar21 == puVar30 + uVar8 * 2 + 9) {
          *puVar30 = uVar5 & ~(1 << (uVar8 & 0xff));
        }
        else {
          if (puVar21 < *(uint **)(DAT_00025654 + 0x246e4)) goto LAB_00024d70;
          puVar30[uVar8 * 2 + 0xb] = (uint)puVar21;
          puVar21[3] = (uint)(puVar30 + uVar8 * 2 + 9);
        }
        *(uint *)(uVar28 + 4) = uVar8 * 8 | 3;
        iVar6 = uVar28 + uVar8 * 8;
        *(uint *)(iVar6 + 4) = *(uint *)(iVar6 + 4) | 1;
        return (uint **)(uVar28 + 8);
      }
      goto LAB_00024d70;
    }
    uVar9 = *(uint *)(DAT_00025654 + 0x246dc);
    if (uVar9 < uVar28) {
      if (uVar13 != 0) {
        uVar8 = (-(2 << (uVar8 & 0xff)) | 2 << (uVar8 & 0xff)) & uVar13 << (uVar8 & 0xff);
        uVar8 = (uVar8 & -uVar8) - 1;
        uVar13 = uVar8 >> 0xc & 0x10;
        uVar8 = uVar8 >> uVar13;
        uVar18 = uVar8 >> 5 & 8;
        uVar8 = uVar8 >> uVar18;
        uVar16 = uVar8 >> 2 & 4;
        uVar8 = uVar8 >> uVar16;
        uVar22 = uVar8 >> 1 & 2;
        uVar8 = uVar8 >> uVar22;
        uVar15 = (uVar8 << 0x1e) >> 0x1f;
        uVar8 = (uVar18 | uVar13 | uVar16 | uVar22 | uVar15) + (uVar8 >> uVar15);
        uVar13 = puVar30[uVar8 * 2 + 0xb];
        puVar21 = *(uint **)(uVar13 + 8);
        if (puVar21[3] == uVar13) {
          if (puVar21 == puVar30 + uVar8 * 2 + 9) {
            uVar5 = uVar5 & ~(1 << (uVar8 & 0xff));
            *puVar30 = uVar5;
          }
          else {
            if (puVar21 < *(uint **)(DAT_00025654 + 0x246e4)) goto LAB_00024d70;
            puVar30[uVar8 * 2 + 0xb] = (uint)puVar21;
            puVar21[3] = (uint)(puVar30 + uVar8 * 2 + 9);
          }
          *(uint *)(uVar13 + 4) = uVar28 | 3;
          uVar15 = uVar8 * 8 - uVar28;
          *(uint *)(uVar13 + uVar28 + 4) = uVar15 | 1;
          *(uint *)(uVar13 + uVar8 * 8) = uVar15;
          if (uVar9 != 0) {
            iVar10 = *(int *)(iVar6 + 0x246e8);
            uVar8 = uVar9 & 0xfffffff8;
            uVar16 = (int)puVar30 + uVar8 + 0x24;
            if ((uVar5 & 1 << (uVar9 >> 3 & 0xff)) == 0) {
              *puVar30 = uVar5 | 1 << (uVar9 >> 3 & 0xff);
              uVar5 = uVar16;
            }
            else {
              uVar5 = *(uint *)((int)puVar30 + uVar8 + 0x2c);
              if (uVar5 < *(uint *)(iVar6 + 0x246e4)) goto LAB_00024d70;
            }
            *(int *)((int)puVar30 + uVar8 + 0x2c) = iVar10;
            *(int *)(uVar5 + 0xc) = iVar10;
            *(uint *)(iVar10 + 8) = uVar5;
            *(uint *)(iVar10 + 0xc) = uVar16;
          }
          *(uint *)(iVar6 + 0x246e8) = uVar13 + uVar28;
          *(uint *)(iVar6 + 0x246dc) = uVar15;
          return (uint **)(uVar13 + 8);
        }
        goto LAB_00024d70;
      }
      uVar8 = *(uint *)(DAT_00025654 + 0x246d8);
      if (uVar8 != 0) {
        uVar13 = (uVar8 & -uVar8) - 1;
        uVar15 = uVar13 >> 0xc & 0x10;
        uVar13 = uVar13 >> uVar15;
        uVar23 = uVar13 >> 5 & 8;
        uVar13 = uVar13 >> uVar23;
        uVar18 = uVar13 >> 2 & 4;
        uVar13 = uVar13 >> uVar18;
        uVar16 = uVar13 >> 1 & 2;
        uVar13 = uVar13 >> uVar16;
        uVar22 = (uVar13 << 0x1e) >> 0x1f;
        puVar31 = (undefined4 *)
                  puVar30[(uVar23 | uVar15 | uVar18 | uVar16 | uVar22) + (uVar13 >> uVar22) + 0x4b];
        uVar13 = (puVar31[1] & 0xfffffffc) - uVar28;
        puVar32 = puVar31;
        while( true ) {
          puVar24 = (undefined4 *)puVar31[4];
          puVar29 = puVar24;
          if (puVar24 == (undefined4 *)0x0) {
            puVar29 = (undefined4 *)puVar31[5];
          }
          puVar31 = puVar29;
          if (puVar24 == (undefined4 *)0x0 && puVar31 == (undefined4 *)0x0) break;
          uVar15 = (puVar31[1] & 0xfffffffc) - uVar28;
          if (uVar15 < uVar13) {
            uVar13 = uVar15;
            puVar32 = puVar31;
          }
        }
        puVar31 = *(undefined4 **)(DAT_00025654 + 0x246e4);
        if ((puVar32 < puVar31) ||
           (puVar29 = (undefined4 *)((int)puVar32 + uVar28), puVar29 <= puVar32)) goto LAB_00024d70;
        puVar24 = (undefined4 *)puVar32[3];
        uVar15 = puVar32[6];
        if (puVar24 == puVar32) {
          puVar19 = (undefined4 *)puVar32[5];
          puVar25 = puVar32 + 5;
          if (puVar19 == (undefined4 *)0x0) {
            puVar19 = (undefined4 *)puVar32[4];
            puVar25 = puVar32 + 4;
            if (puVar19 == (undefined4 *)0x0) {
              puVar24 = (undefined4 *)0x0;
              goto LAB_00025028;
            }
          }
          do {
            do {
              puVar26 = puVar25;
              puVar24 = puVar19;
              puVar19 = (undefined4 *)puVar24[5];
              puVar25 = puVar24 + 5;
            } while (puVar19 != (undefined4 *)0x0);
            puVar19 = (undefined4 *)puVar24[4];
            puVar25 = puVar24 + 4;
          } while (puVar19 != (undefined4 *)0x0);
          if (puVar26 < puVar31) goto LAB_00024d70;
          *puVar26 = 0;
        }
        else {
          puVar25 = (undefined4 *)puVar32[2];
          puVar19 = (undefined4 *)puVar25[3];
          bVar33 = puVar19 == puVar32;
          if (bVar33) {
            puVar19 = (undefined4 *)puVar24[2];
          }
          if ((!bVar33 || puVar19 != puVar32) || (puVar25 < puVar31)) goto LAB_00024d70;
          puVar25[3] = puVar24;
          puVar24[2] = puVar25;
        }
LAB_00025028:
        if (uVar15 != 0) {
          uVar16 = puVar32[7];
          if (puVar32 == (undefined4 *)puVar30[uVar16 + 0x4b]) {
            puVar30[uVar16 + 0x4b] = (uint)puVar24;
            if (puVar24 == (undefined4 *)0x0) {
              *(uint *)(iVar6 + 0x246d8) = uVar8 & ~(1 << (uVar16 & 0xff));
            }
            else {
LAB_000250f8:
              puVar31 = *(undefined4 **)(iVar6 + 0x246e4);
              if (puVar24 < puVar31) goto LAB_00024d70;
              puVar24[6] = uVar15;
              puVar19 = (undefined4 *)puVar32[4];
              if (puVar19 != (undefined4 *)0x0) {
                if (puVar19 < puVar31) goto LAB_00024d70;
                puVar24[4] = puVar19;
                puVar19[6] = puVar24;
              }
              uVar8 = puVar32[5];
              if (uVar8 != 0) {
                if (uVar8 < *(uint *)(iVar6 + 0x246e4)) goto LAB_00024d70;
                puVar24[5] = uVar8;
                *(undefined4 **)(uVar8 + 0x18) = puVar24;
              }
            }
          }
          else {
            if (uVar15 < *(uint *)(iVar6 + 0x246e4)) goto LAB_00024d70;
            iVar10 = 0x14;
            if (*(undefined4 **)(uVar15 + 0x10) == puVar32) {
              iVar10 = 0x10;
            }
            *(undefined4 **)(uVar15 + iVar10) = puVar24;
            if (puVar24 != (undefined4 *)0x0) goto LAB_000250f8;
          }
        }
        if (uVar13 < 0x10) {
          uVar13 = uVar13 + uVar28;
          puVar32[1] = uVar13 | 3;
          *(uint *)((int)puVar32 + uVar13 + 4) = *(uint *)((int)puVar32 + uVar13 + 4) | 1;
        }
        else {
          puVar32[1] = uVar28 | 3;
          puVar29[1] = uVar13 | 1;
          *(uint *)((int)puVar29 + uVar13) = uVar13;
          if (uVar9 != 0) {
            iVar10 = *(int *)(iVar6 + 0x246e8);
            uVar28 = uVar9 & 0xfffffff8;
            uVar8 = (int)puVar30 + uVar28 + 0x24;
            if ((uVar5 & 1 << (uVar9 >> 3 & 0xff)) == 0) {
              *puVar30 = 1 << (uVar9 >> 3 & 0xff) | uVar5;
              uVar5 = uVar8;
            }
            else {
              uVar5 = *(uint *)((int)puVar30 + uVar28 + 0x2c);
              if (uVar5 < *(uint *)(iVar6 + 0x246e4)) goto LAB_00024d70;
            }
            *(int *)((int)puVar30 + uVar28 + 0x2c) = iVar10;
            *(int *)(uVar5 + 0xc) = iVar10;
            *(uint *)(iVar10 + 8) = uVar5;
            *(uint *)(iVar10 + 0xc) = uVar8;
          }
          *(undefined4 **)(iVar6 + 0x246e8) = puVar29;
          *(uint *)(iVar6 + 0x246dc) = uVar13;
        }
        return (uint **)(puVar32 + 2);
      }
    }
  }
  else {
    uVar28 = 0xffffffff;
    if (param_1 < 0xffffffc0) {
      param_1 = param_1 + 0xb;
      uVar8 = *(uint *)(DAT_00025654 + 0x246d8);
      uVar28 = param_1 & 0xfffffff8;
      if (uVar8 != 0) {
        ppuVar2 = (uint **)0x0;
        uVar13 = 0;
        if ((param_1 >> 8 != 0) && (uVar13 = 0x1f, param_1 >> 0x18 == 0)) {
          param_1 = param_1 >> 8;
          uVar13 = param_1 + 0xfff00 >> 0x10 & 8;
          uVar9 = (param_1 << uVar13) + 0x7f000 >> 0x10 & 4;
          uVar5 = ((param_1 << uVar13) << uVar9) + 0x3c000 >> 0x10 & 2;
          iVar10 = ((((param_1 << uVar13) << uVar9) << uVar5) >> 0xf) - (uVar9 | uVar13 | uVar5);
          uVar13 = (uVar28 >> (iVar10 + 0x15U & 0xff) & 1 | iVar10 * 2) + 0x1c;
        }
        uVar5 = -uVar28;
        ppuVar1 = (uint **)puVar30[uVar13 + 0x4b];
        if (ppuVar1 == (uint **)0x0) {
          ppuVar4 = (uint **)0x0;
        }
        else {
          uVar9 = uVar13 - 0x1f;
          if (uVar9 != 0) {
            uVar9 = 0x19 - (uVar13 >> 1);
          }
          ppuVar2 = (uint **)0x0;
          ppuVar4 = (uint **)0x0;
          iVar10 = uVar28 << (uVar9 & 0xff);
          do {
            uVar9 = ((uint)ppuVar1[1] & 0xfffffffc) - uVar28;
            if ((uVar9 < uVar5) && (ppuVar4 = ppuVar1, uVar5 = uVar9, uVar9 == 0)) {
              uVar5 = 0;
              goto LAB_00024aa8;
            }
            ppuVar14 = (uint **)ppuVar1[5];
            ppuVar1 = (uint **)ppuVar1[4 - (iVar10 >> 0x1f)];
            ppuVar12 = ppuVar14;
            if (ppuVar14 == ppuVar1) {
              ppuVar12 = ppuVar2;
            }
            if (ppuVar14 != (uint **)0x0) {
              ppuVar2 = ppuVar12;
            }
            ppuVar12 = ppuVar1;
            if (ppuVar1 != (uint **)0x0) {
              ppuVar12 = (uint **)0x1;
            }
            iVar10 = iVar10 << ((uint)ppuVar12 & 0xff);
          } while (ppuVar1 != (uint **)0x0);
        }
        if (((uint)ppuVar2 | (uint)ppuVar4) == 0) {
          uVar13 = (-(2 << (uVar13 & 0xff)) | 2 << (uVar13 & 0xff)) & uVar8;
          if (uVar13 == 0) goto LAB_00024b48;
          uVar13 = (uVar13 & -uVar13) - 1;
          uVar15 = uVar13 >> 0xc & 0x10;
          uVar13 = uVar13 >> uVar15;
          uVar16 = uVar13 >> 5 & 8;
          uVar13 = uVar13 >> uVar16;
          uVar22 = uVar13 >> 2 & 4;
          uVar13 = uVar13 >> uVar22;
          uVar9 = uVar13 >> 1 & 2;
          uVar13 = uVar13 >> uVar9;
          uVar18 = (uVar13 << 0x1e) >> 0x1f;
          ppuVar2 = (uint **)puVar30[(uVar16 | uVar15 | uVar22 | uVar9 | uVar18) +
                                     (uVar13 >> uVar18) + 0x4b];
        }
        while (ppuVar1 = ppuVar2, ppuVar1 != (uint **)0x0) {
LAB_00024aa8:
          uVar13 = ((uint)ppuVar1[1] & 0xfffffffc) - uVar28;
          if (uVar13 < uVar5) {
            uVar5 = uVar13;
            ppuVar4 = ppuVar1;
          }
          ppuVar2 = (uint **)ppuVar1[4];
          if ((uint **)ppuVar1[4] == (uint **)0x0) {
            ppuVar2 = (uint **)ppuVar1[5];
          }
        }
        if ((ppuVar4 != (uint **)0x0) && (uVar5 < *(int *)(DAT_00025654 + 0x246dc) - uVar28)) {
          ppuVar2 = *(uint ***)(DAT_00025654 + 0x246e4);
          if ((ppuVar4 < ppuVar2) || (puVar21 = (uint *)((int)ppuVar4 + uVar28), puVar21 <= ppuVar4)
             ) goto LAB_00024d70;
          puVar3 = ppuVar4[3];
          uVar13 = (uint)ppuVar4[6];
          if ((uint **)puVar3 == ppuVar4) {
            puVar27 = ppuVar4[5];
            ppuVar1 = ppuVar4 + 5;
            if (puVar27 == (uint *)0x0) {
              puVar27 = ppuVar4[4];
              ppuVar1 = ppuVar4 + 4;
              if (puVar27 == (uint *)0x0) {
                puVar3 = (uint *)0x0;
                goto LAB_00024dcc;
              }
            }
            do {
              do {
                puVar3 = puVar27;
                ppuVar12 = ppuVar1;
                puVar27 = (uint *)puVar3[5];
                ppuVar1 = (uint **)(puVar3 + 5);
              } while (puVar27 != (uint *)0x0);
              puVar27 = (uint *)puVar3[4];
              ppuVar1 = (uint **)(puVar3 + 4);
            } while (puVar27 != (uint *)0x0);
            if (ppuVar12 < ppuVar2) goto LAB_00024d70;
            *ppuVar12 = (uint *)0x0;
          }
          else {
            ppuVar12 = (uint **)ppuVar4[2];
            ppuVar1 = (uint **)ppuVar12[3];
            bVar33 = ppuVar1 != ppuVar4;
            if (!bVar33) {
              ppuVar1 = (uint **)puVar3[2];
            }
            if ((bVar33 || ppuVar1 != ppuVar4) || (ppuVar12 < ppuVar2)) goto LAB_00024d70;
            ppuVar12[3] = puVar3;
            puVar3[2] = (uint)ppuVar12;
          }
LAB_00024dcc:
          if (uVar13 != 0) {
            puVar27 = ppuVar4[7];
            if (ppuVar4 == (uint **)puVar30[(int)puVar27 + 0x4b]) {
              puVar30[(int)puVar27 + 0x4b] = (uint)puVar3;
              if (puVar3 == (uint *)0x0) {
                uVar8 = uVar8 & ~(1 << ((uint)puVar27 & 0xff));
                *(uint *)(iVar6 + 0x246d8) = uVar8;
              }
              else {
LAB_0002507c:
                puVar27 = *(uint **)(iVar6 + 0x246e4);
                if (puVar3 < puVar27) goto LAB_00024d70;
                puVar3[6] = uVar13;
                puVar7 = ppuVar4[4];
                if (puVar7 != (uint *)0x0) {
                  if (puVar7 < puVar27) goto LAB_00024d70;
                  puVar3[4] = (uint)puVar7;
                  puVar7[6] = (uint)puVar3;
                }
                puVar27 = ppuVar4[5];
                if (puVar27 != (uint *)0x0) {
                  if (puVar27 < *(uint **)(iVar6 + 0x246e4)) goto LAB_00024d70;
                  puVar3[5] = (uint)puVar27;
                  puVar27[6] = (uint)puVar3;
                }
              }
            }
            else {
              if (uVar13 < *(uint *)(iVar6 + 0x246e4)) goto LAB_00024d70;
              iVar10 = 0x14;
              if (*(uint ***)(uVar13 + 0x10) == ppuVar4) {
                iVar10 = 0x10;
              }
              *(uint **)(uVar13 + iVar10) = puVar3;
              if (puVar3 != (uint *)0x0) goto LAB_0002507c;
            }
          }
          if (uVar5 < 0x10) {
            uVar5 = uVar5 + uVar28;
            ppuVar4[1] = (uint *)(uVar5 | 3);
            *(uint *)((int)ppuVar4 + uVar5 + 4) = *(uint *)((int)ppuVar4 + uVar5 + 4) | 1;
          }
          else {
            ppuVar4[1] = (uint *)(uVar28 | 3);
            puVar21[1] = uVar5 | 1;
            *(uint *)((int)puVar21 + uVar5) = uVar5;
            if (0xff < uVar5) {
              uVar28 = 0;
              if ((uVar5 >> 8 != 0) && (uVar28 = 0x1f, uVar5 >> 0x18 == 0)) {
                uVar28 = uVar5 >> 8;
                uVar13 = uVar28 + 0xfff00 >> 0x10 & 8;
                uVar15 = (uVar28 << uVar13) + 0x7f000 >> 0x10 & 4;
                uVar9 = ((uVar28 << uVar13) << uVar15) + 0x3c000 >> 0x10 & 2;
                iVar10 = ((((uVar28 << uVar13) << uVar15) << uVar9) >> 0xf) -
                         (uVar15 | uVar13 | uVar9);
                uVar28 = (uVar5 >> (iVar10 + 0x15U & 0xff) & 1 | iVar10 * 2) + 0x1c;
              }
              puVar21[7] = uVar28;
              puVar21[4] = 0;
              puVar21[5] = 0;
              ppuVar2 = (uint **)(puVar30 + uVar28 + 0x4b);
              if ((uVar8 & 1 << (uVar28 & 0xff)) == 0) {
                *(uint *)(iVar6 + 0x246d8) = uVar8 | 1 << (uVar28 & 0xff);
                *ppuVar2 = puVar21;
              }
              else {
                uVar8 = uVar28 - 0x1f;
                if (uVar8 != 0) {
                  uVar8 = 0x19 - (uVar28 >> 1);
                }
                iVar10 = uVar5 << (uVar8 & 0xff);
                puVar30 = *ppuVar2;
                do {
                  ppuVar2 = (uint **)puVar30;
                  if (((uint)ppuVar2[1] & 0xfffffffc) == uVar5) {
                    puVar3 = ppuVar2[2];
                    puVar30 = *(uint **)(iVar6 + 0x246e4);
                    bVar34 = puVar3 <= puVar30;
                    bVar33 = puVar30 == puVar3;
                    if (!bVar34 || bVar33) {
                      bVar34 = ppuVar2 <= puVar30;
                      bVar33 = (uint **)puVar30 == ppuVar2;
                    }
                    if (bVar34 && !bVar33) goto LAB_00024d70;
                    puVar3[3] = (uint)puVar21;
                    ppuVar2[2] = puVar21;
                    puVar21[6] = 0;
                    goto LAB_000252d4;
                  }
                  iVar11 = iVar10 >> 0x1f;
                  iVar10 = iVar10 << 1;
                  ppuVar1 = ppuVar2 + (4 - iVar11);
                  puVar30 = *ppuVar1;
                } while (*ppuVar1 != (uint *)0x0);
                if (ppuVar1 < *(uint ***)(iVar6 + 0x246e4)) goto LAB_00024d70;
                *ppuVar1 = puVar21;
              }
              puVar21[6] = (uint)ppuVar2;
              puVar21[2] = (uint)puVar21;
              puVar21[3] = (uint)puVar21;
              goto LAB_00025300;
            }
            uVar28 = uVar5 & 0xfffffff8;
            ppuVar2 = (uint **)((int)puVar30 + uVar28 + 0x24);
            if ((*puVar30 & 1 << (uVar5 >> 3 & 0xff)) == 0) {
              *puVar30 = *puVar30 | 1 << (uVar5 >> 3 & 0xff);
              puVar3 = (uint *)ppuVar2;
            }
            else {
              puVar3 = *(uint **)((int)puVar30 + uVar28 + 0x2c);
              if (puVar3 < *(uint **)(iVar6 + 0x246e4)) goto LAB_00024d70;
            }
            *(uint **)((int)puVar30 + uVar28 + 0x2c) = puVar21;
            puVar3[3] = (uint)puVar21;
LAB_000252d4:
            puVar21[2] = (uint)puVar3;
            puVar21[3] = (uint)ppuVar2;
          }
LAB_00025300:
          return ppuVar4 + 2;
        }
      }
    }
  }
LAB_00024b48:
  uVar8 = *(uint *)(DAT_00025654 + 0x246dc);
  if (uVar28 <= uVar8) {
    iVar10 = *(int *)(DAT_00025654 + 0x246e8);
    uVar13 = uVar8 - uVar28;
    if (uVar13 < 0x10) {
      *(undefined4 *)(DAT_00025654 + 0x246e8) = 0;
      *(undefined4 *)(iVar6 + 0x246dc) = 0;
      *(uint *)(iVar10 + 4) = uVar8 | 3;
      *(uint *)(iVar10 + uVar8 + 4) = *(uint *)(iVar10 + uVar8 + 4) | 1;
    }
    else {
      *(uint *)(DAT_00025654 + 0x246dc) = uVar13;
      *(uint *)(iVar6 + 0x246e8) = iVar10 + uVar28;
      *(uint *)(iVar10 + uVar28 + 4) = uVar13 | 1;
      *(uint *)(iVar10 + uVar8) = uVar13;
      *(uint *)(iVar10 + 4) = uVar28 | 3;
    }
    return (uint **)(iVar10 + 8);
  }
  uVar8 = *(uint *)(DAT_00025654 + 0x246e0);
  if (uVar8 <= uVar28) {
    FUN_0002717c();
    puVar30 = (uint *)(DAT_00025b78 + 0x24bd0);
    uVar8 = *(uint *)(DAT_00025b78 + 0x24d84);
    if ((((uVar8 & 1) != 0) && (*(uint *)(DAT_00025b7c + 0x24be4) <= uVar28)) &&
       (uVar13 = uVar28 + *(int *)(DAT_00025bec + 0x24bf4) + 0x1f &
                 -*(int *)(DAT_00025bec + 0x24bf4), uVar28 < uVar13)) {
      uVar8 = FUN_00036080(0,uVar13,3,0x22,0xffffffff,0);
      if (uVar8 != 0xffffffff) {
        uVar28 = uVar8 + 8 & 7;
        if (uVar28 != 0) {
          uVar28 = -uVar8 - 8 & 7;
        }
        puVar21 = (uint *)(uVar8 + uVar28);
        *puVar21 = uVar28 | 1;
        iVar6 = uVar13 - uVar28;
        puVar21[1] = iVar6 - 0x10U | 2;
        *(undefined4 *)((int)puVar21 + iVar6 + -8) = 0;
        *(undefined4 *)((int)puVar21 + iVar6 + -0xc) = 7;
        iVar6 = DAT_00025c70;
        if (uVar8 < *(uint *)(DAT_00025c70 + 0x24c90)) {
          *(uint *)(DAT_00025c70 + 0x24c90) = uVar8;
        }
        uVar13 = *(int *)(iVar6 + 0x24e2c) + uVar13;
        *(uint *)(iVar6 + 0x24e2c) = uVar13;
        if (*(uint *)(iVar6 + 0x24e30) < uVar13) {
          *(uint *)(iVar6 + 0x24e30) = uVar13;
        }
        goto LAB_00024b84;
      }
      puVar30 = (uint *)(DAT_00025de8 + 0x24e50);
      uVar8 = *(uint *)(DAT_00025de8 + 0x25004);
    }
    if ((uVar8 & 4) == 0) {
      uVar8 = puVar30[6];
      if (uVar8 != 0) {
        puVar21 = puVar30 + 0x6e;
        do {
          if ((*puVar21 <= uVar8) && (uVar8 < *puVar21 + puVar21[1])) {
            uVar8 = (uVar28 - puVar30[3]) + *(int *)(DAT_00025dfc + 0x24f1c) + 0x29 &
                    -*(int *)(DAT_00025dfc + 0x24f1c);
            if (0x7ffffffe < uVar8) goto LAB_0002541c;
            ppuVar2 = (uint **)FUN_00036098(uVar8);
            if (ppuVar2 != (uint **)(*puVar21 + puVar21[1])) goto LAB_00024f4c;
            puVar30 = (uint *)(DAT_00025e58 + 0x2531c);
            ppuVar1 = ppuVar2;
            goto joined_r0x00025318;
          }
          puVar21 = (uint *)puVar21[2];
        } while (puVar21 != (uint *)0x0);
      }
      ppuVar1 = (uint **)FUN_00036098(0);
      puVar30 = (uint *)(DAT_00025dec + 0x24ea8);
      if (ppuVar1 == (uint **)0xffffffff) {
LAB_0002541c:
        puVar30[0x6d] = puVar30[0x6d] | 4;
        goto LAB_00025428;
      }
      uVar8 = uVar28 + *(int *)(DAT_00025df0 + 0x24eb8) + 0x29 & -*(int *)(DAT_00025df0 + 0x24eb8);
      iVar6 = *(int *)(DAT_00025df4 + 0x24ed0);
      if ((iVar6 - 1U & (uint)ppuVar1) != 0) {
        uVar8 = (uVar8 - (int)ppuVar1) + (iVar6 + (int)ppuVar1 & -iVar6);
      }
      if (0x7ffffffe < uVar8) goto LAB_0002541c;
      ppuVar2 = (uint **)FUN_00036098(uVar8);
      if (ppuVar2 == ppuVar1) {
        puVar21 = (uint *)0x0;
        puVar30 = (uint *)(DAT_00025df8 + 0x250ec);
      }
      else {
LAB_00024f4c:
        puVar30 = (uint *)(DAT_00025e00 + 0x24f5c);
        ppuVar1 = ppuVar2;
        if ((uVar8 < 0x7fffffff) && (ppuVar2 != (uint **)0xffffffff)) {
          puVar21 = (uint *)0x0;
          if ((uVar8 < uVar28 + 0x29) &&
             (uVar13 = ((uVar28 + 0x29) - uVar8) + *(int *)(DAT_00025e04 + 0x24f84) &
                       -*(int *)(DAT_00025e04 + 0x24f84), uVar13 < 0x7fffffff)) {
            iVar6 = FUN_00036098(uVar13);
            if (iVar6 == -1) {
              FUN_00036098(-uVar8);
              puVar30 = (uint *)(DAT_00025e0c + 0x25420);
              goto LAB_0002541c;
            }
            uVar8 = uVar13 + uVar8;
            puVar30 = (uint *)(DAT_00025e08 + 0x24fb4);
          }
        }
        else {
joined_r0x00025318:
          puVar21 = (uint *)0x0;
          if (ppuVar1 == (uint **)0xffffffff) goto LAB_0002541c;
        }
      }
    }
    else {
LAB_00025428:
      puVar21 = (uint *)0x0;
      uVar8 = *(int *)(DAT_00025e10 + 0x2543c) + uVar28 + 0x29 & -*(int *)(DAT_00025e10 + 0x2543c);
      if (uVar28 < uVar8) {
        ppuVar1 = (uint **)FUN_00036080(0,uVar8,3,0x22,0xffffffff,0);
        puVar21 = (uint *)((int)ppuVar1 + 1);
        if (puVar21 != (uint *)0x0) {
          puVar21 = (uint *)0x1;
        }
        if (ppuVar1 != (uint **)0xffffffff) {
          puVar30 = (uint *)(DAT_00025e14 + 0x25490);
          goto LAB_000254ec;
        }
        uVar8 = *(int *)(DAT_00025e18 + 0x2549c) + uVar28 + 0x29 & -*(int *)(DAT_00025e18 + 0x2549c)
        ;
      }
      if (0x7ffffffe < uVar8) goto LAB_00025a1c;
      ppuVar1 = (uint **)FUN_00036098(uVar8);
      uVar35 = FUN_00036098(0);
      uVar13 = (uint)((ulonglong)uVar35 >> 0x20);
      ppuVar2 = (uint **)uVar35;
      puVar30 = (uint *)(DAT_00025e1c + 0x254d0);
      if ((ppuVar2 <= ppuVar1) || (ppuVar1 == (uint **)0xffffffff)) goto LAB_00025a1c;
      bVar33 = (uint **)0xfffffffe < ppuVar2;
      if (ppuVar2 != (uint **)0xffffffff) {
        uVar13 = uVar28 + 0x28;
        uVar8 = (int)ppuVar2 - (int)ppuVar1;
        bVar33 = uVar13 <= uVar8;
      }
      if (!bVar33 || (ppuVar2 == (uint **)0xffffffff || uVar8 == uVar13)) goto LAB_00025a1c;
    }
LAB_000254ec:
    uVar13 = puVar30[0x6b] + uVar8;
    puVar30[0x6b] = uVar13;
    if (puVar30[0x6c] < uVar13) {
      puVar30[0x6c] = uVar13;
    }
    iVar6 = DAT_00025e20;
    ppuVar2 = (uint **)puVar30[6];
    if (ppuVar2 == (uint **)0x0) {
      puVar30[0x71] = (uint)puVar21;
      puVar30[0x6e] = (uint)ppuVar1;
      puVar30[0x6f] = uVar8;
      uVar13 = (uint)*(byte *)(iVar6 + 0x25548);
      puVar30[4] = (uint)ppuVar1;
      if (uVar13 != 0) {
        uVar13 = 0x58585858;
      }
      puVar30[8] = uVar13;
      iVar6 = 0;
      do {
        iVar10 = iVar6 + 8;
        iVar11 = (int)puVar30 + iVar6 + 0x24;
        *(int *)((int)puVar30 + iVar6 + 0x2c) = iVar11;
        *(int *)((int)puVar30 + iVar6 + 0x30) = iVar11;
        iVar6 = iVar10;
      } while (iVar10 != 0x100);
      uVar13 = (uint)(ppuVar1 + 2) & 7;
      if (uVar13 != 0) {
        uVar13 = -(int)ppuVar1 - 8U & 7;
      }
      uVar5 = (uVar8 - 0x28) - uVar13;
      iVar6 = (int)ppuVar1 + (uVar8 - 0x28);
      puVar30[3] = uVar5;
      puVar30[6] = (int)ppuVar1 + uVar13;
      *(uint *)((int)ppuVar1 + uVar13 + 4) = uVar5 | 1;
LAB_000255b8:
      *(undefined4 *)(iVar6 + 4) = 0x28;
      puVar30[7] = *(uint *)(DAT_00025e24 + 0x255cc);
    }
    else {
      puVar3 = puVar30 + 0x6e;
      do {
        if (ppuVar1 == (uint **)((int)(uint **)*puVar3 + puVar3[1])) {
          puVar27 = (uint *)puVar3[3];
          bVar33 = ((uint)puVar27 & 8) == 0;
          if (bVar33) {
            puVar27 = (uint *)((uint)puVar27 & 1);
          }
          if (((bVar33 && puVar27 == puVar21) && (ppuVar2 < ppuVar1)) &&
             ((uint **)*puVar3 <= ppuVar2)) {
            puVar3[1] = puVar3[1] + uVar8;
            uVar5 = puVar30[3];
            uVar13 = (uint)(ppuVar2 + 2) & 7;
            if (uVar13 != 0) {
              uVar13 = -(int)ppuVar2 - 8U & 7;
            }
            uVar9 = (uVar5 + uVar8) - uVar13;
            puVar30[6] = (int)ppuVar2 + uVar13;
            puVar30[3] = uVar9;
            *(uint *)((int)ppuVar2 + uVar13 + 4) = uVar9 | 1;
            iVar6 = (int)ppuVar2 + uVar5 + uVar8;
            goto LAB_000255b8;
          }
          break;
        }
        puVar3 = (uint *)puVar3[2];
      } while (puVar3 != (uint *)0x0);
      ppuVar14 = (uint **)((int)ppuVar1 + uVar8);
      ppuVar12 = (uint **)(puVar30 + 0x6e);
      ppuVar4 = (uint **)puVar30[4];
      if (ppuVar1 < (uint **)puVar30[4]) {
        puVar30[4] = (uint)ppuVar1;
        ppuVar4 = ppuVar1;
      }
      do {
        if ((uint **)*ppuVar12 == ppuVar14) {
          puVar3 = ppuVar12[3];
          bVar33 = ((uint)puVar3 & 8) == 0;
          if (bVar33) {
            puVar3 = (uint *)((uint)puVar3 & 1);
          }
          if (bVar33 && puVar3 == puVar21) {
            ppuVar20 = ppuVar1 + 2;
            *ppuVar12 = (uint *)ppuVar1;
            ppuVar12[1] = (uint *)((int)ppuVar12[1] + uVar8);
            if (((uint)ppuVar20 & 7) != 0) {
              ppuVar1 = (uint **)((int)ppuVar1 + (-(int)ppuVar1 - 8U & 7));
            }
            ppuVar1[1] = (uint *)(uVar28 | 3);
            if (((uint)(ppuVar14 + 2) & 7) != 0) {
              ppuVar14 = (uint **)((int)ppuVar14 + (-(int)ppuVar14 - 8U & 7));
            }
            uVar8 = (int)ppuVar14 + (-uVar28 - (int)ppuVar1);
            puVar21 = (uint *)((int)ppuVar1 + uVar28);
            if (ppuVar2 == ppuVar14) {
              uVar28 = puVar30[3];
              puVar30[6] = (uint)puVar21;
              puVar30[3] = uVar28 + uVar8;
              puVar21[1] = uVar28 + uVar8 | 1;
              goto LAB_00025db0;
            }
            if ((uint **)puVar30[5] == ppuVar14) {
              puVar30[5] = (uint)puVar21;
              uVar8 = puVar30[2] + uVar8;
              puVar30[2] = uVar8;
              puVar21[1] = uVar8 | 1;
              *(uint *)((int)puVar21 + uVar8) = uVar8;
              goto LAB_00025db0;
            }
            puVar3 = ppuVar14[1];
            if (((uint)puVar3 & 2) != 0) goto LAB_00025c20;
            if ((uint *)0xff < puVar3) {
              ppuVar2 = (uint **)ppuVar14[3];
              puVar30 = ppuVar14[6];
              if (ppuVar2 == ppuVar14) {
                ppuVar20 = ppuVar14 + 5;
                ppuVar12 = (uint **)*ppuVar20;
                bVar33 = ppuVar12 == (uint **)0x0;
                if (bVar33) {
                  ppuVar20 = ppuVar14 + 4;
                  ppuVar12 = (uint **)*ppuVar20;
                }
                if (!bVar33 || ppuVar12 != (uint **)0x0) goto LAB_00025ad8;
                ppuVar2 = (uint **)0x0;
              }
              else {
                ppuVar20 = (uint **)ppuVar14[2];
                ppuVar12 = (uint **)ppuVar20[3];
                bVar33 = ppuVar12 != ppuVar14;
                if (!bVar33) {
                  ppuVar12 = (uint **)ppuVar2[2];
                }
                if ((bVar33 || ppuVar12 != ppuVar14) || (ppuVar20 < ppuVar4)) goto LAB_00024d70;
                ppuVar20[3] = (uint *)ppuVar2;
                ppuVar2[2] = (uint *)ppuVar20;
              }
              goto LAB_00025b10;
            }
            ppuVar12 = (uint **)ppuVar14[2];
            ppuVar2 = (uint **)ppuVar12[3];
            bVar33 = ppuVar2 != ppuVar14;
            if (!bVar33) {
              ppuVar2 = (uint **)ppuVar14[3];
              ppuVar20 = (uint **)ppuVar2[2];
            }
            if (bVar33 || ppuVar20 != ppuVar14) goto LAB_00024d70;
            if (ppuVar12 == ppuVar2) {
              *puVar30 = *(uint *)(DAT_00025e28 + 0x25b70) & ~(1 << ((uint)puVar3 >> 3 & 0xff));
              goto LAB_00025c0c;
            }
            ppuVar20 = (uint **)((int)puVar30 + ((uint)puVar3 & 0xfffffff8) + 0x24);
            bVar33 = ppuVar20 <= ppuVar12;
            if (ppuVar12 != ppuVar20) {
              bVar33 = ppuVar12 <= ppuVar4;
            }
            if (bVar33 && (ppuVar12 != ppuVar20 && ppuVar4 != ppuVar12)) goto LAB_00024d70;
            bVar33 = ppuVar20 <= ppuVar2;
            if (ppuVar2 != ppuVar20) {
              bVar33 = ppuVar2 <= ppuVar4;
            }
            if (bVar33 && (ppuVar2 != ppuVar20 && ppuVar4 != ppuVar2)) goto LAB_00024d70;
            ppuVar12[3] = (uint *)ppuVar2;
            ppuVar2[2] = (uint *)ppuVar12;
            goto LAB_00025c0c;
          }
          break;
        }
        ppuVar12 = (uint **)ppuVar12[2];
      } while (ppuVar12 != (uint **)0x0);
      for (puVar3 = puVar30 + 0x6e;
          (ppuVar2 < (uint **)*puVar3 ||
          (ppuVar4 = (uint **)((int)(uint **)*puVar3 + puVar3[1]), ppuVar4 <= ppuVar2));
          puVar3 = (uint *)puVar3[2]) {
      }
      uVar13 = (uint)(ppuVar1 + 2) & 7;
      if (uVar13 != 0) {
        uVar13 = -(int)ppuVar1 - 8U & 7;
      }
      uVar5 = (uVar8 - 0x28) - uVar13;
      puVar30[3] = uVar5;
      puVar30[6] = (int)ppuVar1 + uVar13;
      *(uint *)((int)ppuVar1 + uVar13 + 4) = uVar5 | 1;
      *(undefined4 *)((int)ppuVar1 + (uVar8 - 0x24)) = 0x28;
      puVar30[7] = *(uint *)(DAT_00025e40 + 0x256b4);
      ppuVar12 = (uint **)((int)ppuVar4 + -0x2f);
      if (((int)ppuVar4 - 0x27U & 7) != 0) {
        ppuVar12 = (uint **)((int)ppuVar12 + (0x27U - (int)ppuVar4 & 7));
      }
      if (ppuVar12 < ppuVar2 + 4) {
        ppuVar12 = ppuVar2;
      }
      ppuVar12[1] = (uint *)0x1b;
      puVar30 = *(uint **)(DAT_00025e44 + 0x258a0);
      puVar3 = *(uint **)(DAT_00025e44 + 0x258a4);
      puVar27 = *(uint **)(DAT_00025e44 + 0x258a8);
      ppuVar12[2] = *(uint **)(DAT_00025e44 + 0x2589c);
      ppuVar12[3] = puVar30;
      ppuVar12[4] = puVar3;
      ppuVar12[5] = puVar27;
      *(uint ***)(DAT_00025e48 + 0x258b8) = ppuVar1;
      *(uint *)(DAT_00025e4c + 0x258c8) = uVar8;
      *(uint ***)(DAT_00025e50 + 0x258d8) = ppuVar12 + 2;
      iVar6 = DAT_00025e54;
      puVar30 = (uint *)(DAT_00025e54 + 0x25728);
      *(uint **)(DAT_00025e54 + 0x258ec) = puVar21;
      ppuVar1 = ppuVar12 + 7;
      do {
        ppuVar14 = ppuVar1 + 1;
        *ppuVar1 = (uint *)0x7;
        ppuVar1 = ppuVar14;
      } while (ppuVar14 < ppuVar4);
      if (ppuVar12 != ppuVar2) {
        ppuVar12[1] = (uint *)((uint)ppuVar12[1] & 0xfffffffe);
        puVar21 = (uint *)((int)ppuVar12 - (int)ppuVar2);
        ppuVar2[1] = (uint *)((uint)puVar21 | 1);
        *ppuVar12 = puVar21;
        if (puVar21 < (uint *)0x100) {
          uVar8 = (uint)puVar21 & 0xfffffff8;
          puVar3 = (uint *)((int)puVar30 + uVar8 + 0x24);
          if ((*puVar30 & 1 << ((uint)puVar21 >> 3 & 0xff)) == 0) {
            *puVar30 = *puVar30 | 1 << ((uint)puVar21 >> 3 & 0xff);
            puVar21 = puVar3;
          }
          else {
            puVar21 = *(uint **)((int)puVar30 + uVar8 + 0x2c);
            if (puVar21 < *(uint **)(iVar6 + 0x25738)) {
LAB_00024d70:
                    /* WARNING: Subroutine does not return */
              FUN_0003608c();
            }
          }
          *(uint ***)((int)puVar30 + uVar8 + 0x2c) = ppuVar2;
          puVar21[3] = (uint)ppuVar2;
          ppuVar2[2] = puVar21;
          ppuVar2[3] = puVar3;
        }
        else {
          puVar3 = (uint *)0x0;
          if (((uint)puVar21 >> 8 != 0) && (puVar3 = (uint *)0x1f, (uint)puVar21 >> 0x18 == 0)) {
            uVar8 = (uint)puVar21 >> 8;
            uVar5 = uVar8 + 0xfff00 >> 0x10 & 8;
            uVar13 = (uVar8 << uVar5) + 0x7f000 >> 0x10 & 4;
            uVar9 = ((uVar8 << uVar5) << uVar13) + 0x3c000 >> 0x10 & 2;
            iVar10 = ((((uVar8 << uVar5) << uVar13) << uVar9) >> 0xf) - (uVar13 | uVar5 | uVar9);
            puVar3 = (uint *)(((uint)puVar21 >> (iVar10 + 0x15U & 0xff) & 1 | iVar10 * 2) + 0x1c);
          }
          ppuVar2[7] = puVar3;
          ppuVar2[4] = (uint *)0x0;
          ppuVar2[5] = (uint *)0x0;
          ppuVar1 = (uint **)(puVar30 + (int)puVar3 + 0x4b);
          if ((*(uint *)(iVar6 + 0x2572c) & 1 << ((uint)puVar3 & 0xff)) == 0) {
            *(uint *)(iVar6 + 0x2572c) = *(uint *)(iVar6 + 0x2572c) | 1 << ((uint)puVar3 & 0xff);
            *ppuVar1 = (uint *)ppuVar2;
            ppuVar2[6] = (uint *)ppuVar1;
          }
          else {
            uVar8 = (int)puVar3 - 0x1f;
            if (uVar8 != 0) {
              uVar8 = 0x19 - ((uint)puVar3 >> 1);
            }
            iVar10 = (int)puVar21 << (uVar8 & 0xff);
            puVar3 = *ppuVar1;
            do {
              puVar27 = puVar3;
              if ((uint *)(puVar27[1] & 0xfffffffc) == puVar21) {
                puVar21 = (uint *)puVar27[2];
                puVar3 = *(uint **)(iVar6 + 0x25738);
                bVar34 = puVar21 <= puVar3;
                bVar33 = puVar3 == puVar21;
                if (!bVar34 || bVar33) {
                  bVar34 = puVar27 <= puVar3;
                  bVar33 = puVar3 == puVar27;
                }
                if (bVar34 && !bVar33) goto LAB_00024d70;
                puVar21[3] = (uint)ppuVar2;
                puVar27[2] = (uint)ppuVar2;
                ppuVar2[6] = (uint *)0x0;
                ppuVar2[2] = puVar21;
                ppuVar2[3] = puVar27;
                goto LAB_00025a10;
              }
              iVar11 = iVar10 >> 0x1f;
              iVar10 = iVar10 << 1;
              ppuVar1 = (uint **)(puVar27 + (4 - iVar11));
              puVar3 = *ppuVar1;
            } while (*ppuVar1 != (uint *)0x0);
            if (ppuVar1 < *(uint ***)(iVar6 + 0x25738)) goto LAB_00024d70;
            *ppuVar1 = (uint *)ppuVar2;
            ppuVar2[6] = puVar27;
          }
          ppuVar2[2] = (uint *)ppuVar2;
          ppuVar2[3] = (uint *)ppuVar2;
        }
      }
    }
LAB_00025a10:
    uVar8 = puVar30[3];
    if (uVar8 <= uVar28) {
LAB_00025a1c:
      puVar31 = (undefined4 *)FUN_000360a4();
      *puVar31 = 0xc;
      return (uint **)0x0;
    }
  }
  puVar21 = (uint *)puVar30[6];
  puVar30[3] = uVar8 - uVar28;
  puVar30[6] = (int)puVar21 + uVar28;
  *(uint *)((int)puVar21 + uVar28 + 4) = uVar8 - uVar28 | 1;
  puVar21[1] = uVar28 | 3;
LAB_00024b84:
  return (uint **)(puVar21 + 2);
LAB_00025ad8:
  do {
    do {
      ppuVar2 = ppuVar12;
      ppuVar17 = ppuVar20;
      ppuVar12 = (uint **)ppuVar2[5];
      ppuVar20 = ppuVar2 + 5;
    } while (ppuVar12 != (uint **)0x0);
    ppuVar12 = (uint **)ppuVar2[4];
    ppuVar20 = ppuVar2 + 4;
  } while (ppuVar12 != (uint **)0x0);
  if (ppuVar17 < ppuVar4) goto LAB_00024d70;
  *ppuVar17 = (uint *)0x0;
LAB_00025b10:
  if (puVar30 != (uint *)0x0) {
    puVar27 = ppuVar14[7];
    ppuVar4 = (uint **)(DAT_00025e2c + (int)puVar27 * 4 + 0x25c54);
    if ((uint **)*ppuVar4 == ppuVar14) {
      *ppuVar4 = (uint *)ppuVar2;
      if (ppuVar2 == (uint **)0x0) {
        *(uint *)(DAT_00025e30 + 0x25c04) =
             *(uint *)(DAT_00025e30 + 0x25c04) & ~(1 << ((uint)puVar27 & 0xff));
      }
      else {
LAB_00025b8c:
        ppuVar4 = *(uint ***)(DAT_00025e34 + 0x25ba8);
        if (ppuVar2 < ppuVar4) goto LAB_00024d70;
        ppuVar2[6] = puVar30;
        ppuVar12 = (uint **)ppuVar14[4];
        if (ppuVar12 != (uint **)0x0) {
          if (ppuVar12 < ppuVar4) goto LAB_00024d70;
          ppuVar2[4] = (uint *)ppuVar12;
          ppuVar12[6] = (uint *)ppuVar2;
        }
        puVar30 = ppuVar14[5];
        if (puVar30 != (uint *)0x0) {
          if (puVar30 < *(uint **)(DAT_00025e38 + 0x25be8)) goto LAB_00024d70;
          ppuVar2[5] = puVar30;
          puVar30[6] = (uint)ppuVar2;
        }
      }
    }
    else {
      if (puVar30 < *(uint **)(DAT_00025e2c + 0x25b38)) goto LAB_00024d70;
      iVar6 = 0x14;
      if ((uint **)puVar30[4] == ppuVar14) {
        iVar6 = 0x10;
      }
      *(uint ***)((int)puVar30 + iVar6) = ppuVar2;
      if (ppuVar2 != (uint **)0x0) goto LAB_00025b8c;
    }
  }
LAB_00025c0c:
  uVar8 = ((uint)puVar3 & 0xfffffffc) + uVar8;
  ppuVar14 = (uint **)((int)ppuVar14 + ((uint)puVar3 & 0xfffffffc));
  puVar30 = (uint *)(DAT_00025e3c + 0x25c24);
LAB_00025c20:
  ppuVar14[1] = (uint *)((uint)ppuVar14[1] & 0xfffffffe);
  puVar21[1] = uVar8 | 1;
  *(uint *)((int)puVar21 + uVar8) = uVar8;
  if (uVar8 < 0x100) {
    uVar28 = uVar8 & 0xfffffff8;
    ppuVar2 = (uint **)((int)puVar30 + uVar28 + 0x24);
    if ((*puVar30 & 1 << (uVar8 >> 3 & 0xff)) == 0) {
      *puVar30 = *puVar30 | 1 << (uVar8 >> 3 & 0xff);
      ppuVar4 = ppuVar2;
    }
    else {
      ppuVar4 = *(uint ***)((int)puVar30 + uVar28 + 0x2c);
      if (ppuVar4 < (uint **)puVar30[4]) goto LAB_00024d70;
    }
    *(uint **)((int)puVar30 + uVar28 + 0x2c) = puVar21;
    ppuVar4[3] = puVar21;
LAB_00025d88:
    puVar21[2] = (uint)ppuVar4;
    puVar21[3] = (uint)ppuVar2;
  }
  else {
    uVar28 = 0;
    if ((uVar8 >> 8 != 0) && (uVar28 = 0x1f, uVar8 >> 0x18 == 0)) {
      uVar28 = uVar8 >> 8;
      uVar13 = uVar28 + 0xfff00 >> 0x10 & 8;
      uVar9 = (uVar28 << uVar13) + 0x7f000 >> 0x10 & 4;
      uVar5 = ((uVar28 << uVar13) << uVar9) + 0x3c000 >> 0x10 & 2;
      iVar6 = ((((uVar28 << uVar13) << uVar9) << uVar5) >> 0xf) - (uVar9 | uVar13 | uVar5);
      uVar28 = (uVar8 >> (iVar6 + 0x15U & 0xff) & 1 | iVar6 * 2) + 0x1c;
    }
    puVar21[7] = uVar28;
    puVar21[4] = 0;
    puVar21[5] = 0;
    ppuVar2 = (uint **)(puVar30 + uVar28 + 0x4b);
    if ((puVar30[1] & 1 << (uVar28 & 0xff)) == 0) {
      puVar30[1] = puVar30[1] | 1 << (uVar28 & 0xff);
      *ppuVar2 = puVar21;
    }
    else {
      uVar13 = uVar28 - 0x1f;
      if (uVar13 != 0) {
        uVar13 = 0x19 - (uVar28 >> 1);
      }
      iVar6 = uVar8 << (uVar13 & 0xff);
      ppuVar4 = (uint **)*ppuVar2;
      do {
        ppuVar2 = ppuVar4;
        if (((uint)ppuVar2[1] & 0xfffffffc) == uVar8) {
          ppuVar4 = (uint **)ppuVar2[2];
          ppuVar12 = (uint **)puVar30[4];
          bVar34 = ppuVar4 <= ppuVar12;
          bVar33 = ppuVar12 == ppuVar4;
          if (!bVar34 || bVar33) {
            bVar34 = ppuVar2 <= ppuVar12;
            bVar33 = ppuVar12 == ppuVar2;
          }
          if (bVar34 && !bVar33) goto LAB_00024d70;
          ppuVar4[3] = puVar21;
          ppuVar2[2] = puVar21;
          puVar21[6] = 0;
          goto LAB_00025d88;
        }
        iVar10 = iVar6 >> 0x1f;
        iVar6 = iVar6 << 1;
        ppuVar12 = ppuVar2 + (4 - iVar10);
        ppuVar4 = (uint **)*ppuVar12;
      } while ((uint **)*ppuVar12 != (uint **)0x0);
      if (ppuVar12 < (uint **)puVar30[4]) goto LAB_00024d70;
      *ppuVar12 = puVar21;
    }
    puVar21[6] = (uint)ppuVar2;
    puVar21[2] = (uint)puVar21;
    puVar21[3] = (uint)puVar21;
  }
LAB_00025db0:
  return ppuVar1 + 2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00025e5c FUN_00025e5c */

uint ** FUN_00025e5c(int param_1)

{
  int iVar1;
  uint **ppuVar2;
  int iVar3;
  uint **ppuVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint **ppuVar8;
  int iVar9;
  uint uVar10;
  uint *puVar11;
  uint *puVar12;
  uint **ppuVar13;
  uint **unaff_r5;
  uint **ppuVar14;
  uint **unaff_r6;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint **ppuVar18;
  uint uVar19;
  uint uVar20;
  uint *puVar21;
  uint *puVar22;
  uint *puVar23;
  uint uVar24;
  int iVar25;
  bool bVar26;
  bool bVar27;
  int local_2c;
  
  iVar25 = DAT_0002652c;
  if (param_1 == 0) {
    return (uint **)0x0;
  }
  ppuVar4 = (uint **)(param_1 + -8);
  puVar22 = (uint *)(DAT_0002652c + 0x25e7c);
  ppuVar8 = *(uint ***)(DAT_0002652c + 0x25e8c);
  if ((ppuVar4 < ppuVar8) || (uVar17 = *(uint *)(param_1 + -4), (uVar17 & 2) == 0))
  goto LAB_000263b4;
  uVar6 = uVar17 & 0xfffffffc;
  ppuVar2 = (uint **)((int)ppuVar4 + uVar6);
  if ((uVar17 & 1) == 0) {
    puVar12 = *ppuVar4;
    if (((uint)puVar12 & 1) != 0) {
      iVar9 = uVar6 + ((uint)puVar12 & 0xfffffffe) + 0x10;
      ppuVar4 = (uint **)FUN_000360b0((int)ppuVar4 - ((uint)puVar12 & 0xfffffffe),iVar9);
      if (ppuVar4 != (uint **)0x0) {
        return ppuVar4;
      }
      ppuVar4 = (uint **)(*(int *)(iVar25 + 0x26028) - iVar9);
      *(uint ***)(iVar25 + 0x26028) = ppuVar4;
      return ppuVar4;
    }
    ppuVar4 = (uint **)((int)ppuVar4 - (int)puVar12);
    if (ppuVar4 < ppuVar8) goto LAB_000263b4;
    uVar6 = (int)puVar12 + uVar6;
    if (*(uint ***)(DAT_0002652c + 0x25e90) == ppuVar4) {
      puVar12 = ppuVar2[1];
      if (((uint)puVar12 & 3) == 3) {
        *(uint *)(DAT_0002652c + 0x25e84) = uVar6;
        ppuVar2[1] = (uint *)((uint)puVar12 & 0xfffffffe);
        ppuVar4[1] = (uint *)(uint **)(uVar6 | 1);
        *(uint *)((int)ppuVar4 + uVar6) = uVar6;
        return (uint **)(uVar6 | 1);
      }
    }
    else if (puVar12 < 0x100) {
      unaff_r5 = (uint **)ppuVar4[2];
      ppuVar18 = (uint **)unaff_r5[3];
      bVar26 = ppuVar18 != ppuVar4;
      if (!bVar26) {
        unaff_r6 = (uint **)ppuVar4[3];
        ppuVar18 = (uint **)unaff_r6[2];
      }
      if (bVar26 || ppuVar18 != ppuVar4) goto LAB_000263b4;
      if (unaff_r5 == unaff_r6) {
        *puVar22 = *(uint *)(DAT_00026530 + 0x26064) & ~(1 << ((uint)puVar12 >> 3 & 0xff));
      }
      else {
        ppuVar18 = (uint **)((int)puVar22 + ((uint)puVar12 & 0xfffffff8) + 0x24);
        bVar26 = ppuVar18 <= unaff_r5;
        if (unaff_r5 != ppuVar18) {
          bVar26 = unaff_r5 <= ppuVar8;
        }
        if (bVar26 && (unaff_r5 != ppuVar18 && ppuVar8 != unaff_r5)) goto LAB_000263b4;
        bVar26 = ppuVar18 <= unaff_r6;
        if (unaff_r6 != ppuVar18) {
          bVar26 = unaff_r6 <= ppuVar8;
        }
        if (bVar26 && (unaff_r6 != ppuVar18 && ppuVar8 != unaff_r6)) goto LAB_000263b4;
        unaff_r5[3] = (uint *)unaff_r6;
        unaff_r6[2] = (uint *)unaff_r5;
      }
    }
    else {
      ppuVar18 = (uint **)ppuVar4[3];
      puVar12 = ppuVar4[6];
      if (ppuVar18 == ppuVar4) {
        ppuVar14 = ppuVar4 + 5;
        unaff_r5 = (uint **)*ppuVar14;
        bVar26 = unaff_r5 == (uint **)0x0;
        if (bVar26) {
          ppuVar14 = ppuVar4 + 4;
          unaff_r5 = (uint **)*ppuVar14;
        }
        if (bVar26 && unaff_r5 == (uint **)0x0) {
          ppuVar18 = (uint **)0x0;
        }
        else {
          do {
            do {
              ppuVar18 = unaff_r5;
              ppuVar13 = ppuVar14;
              unaff_r5 = (uint **)ppuVar18[5];
              ppuVar14 = ppuVar18 + 5;
            } while (unaff_r5 != (uint **)0x0);
            unaff_r5 = (uint **)ppuVar18[4];
            ppuVar14 = ppuVar18 + 4;
          } while (unaff_r5 != (uint **)0x0);
          if (ppuVar13 < ppuVar8) goto LAB_000263b4;
          *ppuVar13 = (uint *)0x0;
          unaff_r5 = (uint **)0x0;
        }
      }
      else {
        ppuVar14 = (uint **)ppuVar4[2];
        unaff_r5 = (uint **)ppuVar14[3];
        bVar26 = unaff_r5 != ppuVar4;
        if (!bVar26) {
          unaff_r5 = (uint **)ppuVar18[2];
        }
        if ((bVar26 || unaff_r5 != ppuVar4) || (ppuVar14 < ppuVar8)) goto LAB_000263b4;
        ppuVar14[3] = (uint *)ppuVar18;
        ppuVar18[2] = (uint *)ppuVar14;
      }
      if (puVar12 != (uint *)0x0) {
        puVar23 = ppuVar4[7];
        unaff_r5 = (uint **)puVar22[(int)puVar23 + 0x4b];
        if (unaff_r5 == ppuVar4) {
          puVar22[(int)puVar23 + 0x4b] = (uint)ppuVar18;
          if (ppuVar18 == (uint **)0x0) {
            *(uint *)(iVar25 + 0x25e80) =
                 *(uint *)(iVar25 + 0x25e80) & ~(1 << ((uint)puVar23 & 0xff));
          }
          else {
LAB_00026078:
            ppuVar8 = *(uint ***)(iVar25 + 0x25e8c);
            if (ppuVar18 < ppuVar8) goto LAB_000263b4;
            ppuVar18[6] = puVar12;
            ppuVar14 = (uint **)ppuVar4[4];
            if (ppuVar14 != (uint **)0x0) {
              if (ppuVar14 < ppuVar8) goto LAB_000263b4;
              ppuVar18[4] = (uint *)ppuVar14;
              ppuVar14[6] = (uint *)ppuVar18;
            }
            puVar12 = ppuVar4[5];
            if (puVar12 != (uint *)0x0) {
              if (puVar12 < *(uint **)(iVar25 + 0x25e8c)) goto LAB_000263b4;
              ppuVar18[5] = puVar12;
              puVar12[6] = (uint)ppuVar18;
            }
          }
        }
        else {
          if (puVar12 < *(uint **)(iVar25 + 0x25e8c)) goto LAB_000263b4;
          iVar9 = 0x14;
          if ((uint **)puVar12[4] == ppuVar4) {
            iVar9 = 0x10;
          }
          *(uint ***)((int)puVar12 + iVar9) = ppuVar18;
          if (ppuVar18 != (uint **)0x0) goto LAB_00026078;
        }
      }
    }
  }
  if ((ppuVar2 <= ppuVar4) || (puVar12 = ppuVar2[1], ((uint)puVar12 & 1) == 0)) goto LAB_000263b4;
  if (((uint)puVar12 & 2) == 0) {
    if (*(uint ***)(iVar25 + 0x25e94) == ppuVar2) {
      *(uint ***)(iVar25 + 0x25e94) = ppuVar4;
      ppuVar8 = (uint **)(*(int *)(iVar25 + 0x25e88) + uVar6);
      *(uint ***)(iVar25 + 0x25e88) = ppuVar8;
      ppuVar4[1] = (uint *)((uint)ppuVar8 | 1);
      if (ppuVar4 == *(uint ***)(iVar25 + 0x25e90)) {
        *(undefined4 *)(iVar25 + 0x25e84) = 0;
        *(undefined4 *)(iVar25 + 0x25e90) = 0;
      }
      if (ppuVar8 <= *(uint ***)(iVar25 + 0x25e98)) {
        return ppuVar8;
      }
      ppuVar4 = (uint **)0x0;
      iVar25 = DAT_00026b00 + 0x26560;
      uVar17 = *(uint *)(DAT_00026b00 + 0x26578);
      if (uVar17 == 0) goto LAB_00026aec;
      local_2c = 0;
      uVar6 = 0;
      if (0x28 < *(uint *)(DAT_00026b00 + 0x2656c)) {
        iVar9 = *(int *)(DAT_00026b04 + 0x26594);
        iVar25 = FUN_00024478(*(uint *)(DAT_00026b00 + 0x2656c) + iVar9 + -0x29,iVar9);
        uVar15 = (iVar25 + -1) * iVar9;
        iVar25 = DAT_00026b08 + 0x265b4;
        puVar22 = (uint *)(DAT_00026b08 + 0x2676c);
        do {
          if ((*puVar22 <= uVar17) && (uVar17 < *puVar22 + puVar22[1])) goto LAB_000265e0;
          puVar22 = (uint *)puVar22[2];
        } while (puVar22 != (uint *)0x0);
        puVar22 = (uint *)0x0;
LAB_000265e0:
        uVar6 = 0;
        if ((puVar22[3] & 8) == 0) {
          if ((puVar22[3] & 1) == 0) {
            uVar17 = FUN_00036098(0);
            iVar25 = DAT_00026b10 + 0x26618;
            uVar6 = 0;
            if (uVar17 == *puVar22 + puVar22[1]) {
              if (0x7ffffffe < uVar15) {
                uVar15 = 0x80000000 - iVar9;
              }
              iVar25 = FUN_00036098(-uVar15);
              uVar6 = 0;
              uVar19 = FUN_00036098(0);
              if (iVar25 == -1) {
                iVar25 = DAT_00026b14 + 0x26748;
              }
              else {
                uVar15 = uVar17 - uVar19;
                iVar25 = DAT_00026b18 + 0x26658;
                if (uVar19 <= uVar17 && uVar15 != 0) goto LAB_000266b8;
              }
            }
          }
          else {
            uVar17 = puVar22[1];
            uVar6 = 0;
            if (uVar15 <= uVar17) {
              uVar6 = *puVar22;
              uVar19 = DAT_00026b08 + 0x2676c;
              do {
                if ((uVar6 <= uVar19) && (uVar19 < uVar6 + uVar17)) {
                  uVar6 = 0;
                  goto LAB_00026744;
                }
                uVar19 = *(uint *)(uVar19 + 8);
              } while (uVar19 != 0);
              iVar9 = FUN_000360b0(uVar6 + (uVar17 - uVar15),uVar15);
              uVar6 = 0;
              iVar25 = DAT_00026b0c + 0x266b8;
              if (iVar9 == 0) {
LAB_000266b8:
                uVar6 = 0;
                if (uVar15 != 0) {
                  puVar22[1] = puVar22[1] - uVar15;
                  iVar3 = *(int *)(iVar25 + 0x18);
                  *(uint *)(iVar25 + 0x1ac) = *(int *)(iVar25 + 0x1ac) - uVar15;
                  uVar17 = iVar3 + 8U & 7;
                  iVar9 = *(int *)(iVar25 + 0xc) - uVar15;
                  if (uVar17 != 0) {
                    uVar17 = -iVar3 - 8U & 7;
                  }
                  uVar6 = iVar9 - uVar17;
                  *(uint *)(iVar25 + 0x18) = iVar3 + uVar17;
                  *(uint *)(iVar25 + 0xc) = uVar6;
                  *(uint *)(iVar3 + uVar17 + 4) = uVar6 | 1;
                  *(undefined4 *)(iVar3 + iVar9 + 4) = 0x28;
                  *(undefined4 *)(iVar25 + 0x1c) = *(undefined4 *)(DAT_00026b1c + 0x26730);
                  uVar6 = uVar15;
                }
              }
            }
          }
        }
      }
LAB_00026744:
      if (*(uint **)(iVar25 + 0x1c0) != (uint *)0x0) {
        local_2c = 0;
        puVar12 = (uint *)(iVar25 + 0x1b8);
        puVar22 = *(uint **)(iVar25 + 0x1c0);
        do {
          puVar23 = (uint *)puVar22[2];
          if ((puVar22[3] & 9) == 1) {
            uVar15 = *puVar22;
            uVar17 = uVar15;
            if ((uVar15 + 8 & 7) != 0) {
              uVar17 = uVar15 + (-uVar15 - 8 & 7);
            }
            uVar19 = *(uint *)(uVar17 + 4);
            if ((uVar19 & 2) == 0) {
              uVar20 = puVar22[1];
              uVar16 = uVar19 & 0xfffffffc;
              if ((uVar15 + uVar20) - 0x28 <= uVar17 + uVar16) {
                if (*(uint *)(iVar25 + 0x14) == uVar17) {
                  *(undefined4 *)(iVar25 + 8) = 0;
                  *(undefined4 *)(iVar25 + 0x14) = 0;
                }
                else {
                  uVar7 = *(uint *)(uVar17 + 0xc);
                  uVar24 = *(uint *)(uVar17 + 0x18);
                  if (uVar7 == uVar17) {
                    puVar21 = (uint *)(uVar17 + 0x14);
                    uVar10 = *puVar21;
                    bVar26 = uVar10 == 0;
                    if (bVar26) {
                      puVar21 = (uint *)(uVar17 + 0x10);
                      uVar10 = *puVar21;
                    }
                    if (bVar26 && uVar10 == 0) {
                      uVar7 = 0;
                    }
                    else {
                      do {
                        do {
                          puVar11 = puVar21;
                          uVar7 = uVar10;
                          uVar10 = *(uint *)(uVar7 + 0x14);
                          puVar21 = (uint *)(uVar7 + 0x14);
                        } while (uVar10 != 0);
                        uVar10 = *(uint *)(uVar7 + 0x10);
                        puVar21 = (uint *)(uVar7 + 0x10);
                      } while (uVar10 != 0);
                      if (puVar11 < *(uint **)(iVar25 + 0x10)) goto LAB_00026afc;
                      *puVar11 = 0;
                    }
                  }
                  else {
                    uVar5 = *(uint *)(uVar17 + 8);
                    uVar10 = *(uint *)(uVar5 + 0xc);
                    bVar26 = uVar10 != uVar17;
                    if (!bVar26) {
                      uVar10 = *(uint *)(uVar7 + 8);
                    }
                    if ((bVar26 || uVar10 != uVar17) || (uVar5 < *(uint *)(iVar25 + 0x10)))
                    goto LAB_00026afc;
                    *(uint *)(uVar5 + 0xc) = uVar7;
                    *(uint *)(uVar7 + 8) = uVar5;
                  }
                  if (uVar24 != 0) {
                    uVar10 = *(uint *)(uVar17 + 0x1c);
                    puVar21 = (uint *)(iVar25 + uVar10 * 4 + 300);
                    if (*puVar21 == uVar17) {
                      *puVar21 = uVar7;
                      if (uVar7 == 0) {
                        *(uint *)(iVar25 + 4) = *(uint *)(iVar25 + 4) & ~(1 << (uVar10 & 0xff));
                      }
                      else {
LAB_000268c8:
                        uVar10 = *(uint *)(iVar25 + 0x10);
                        if (uVar7 < uVar10) goto LAB_00026afc;
                        *(uint *)(uVar7 + 0x18) = uVar24;
                        uVar24 = *(uint *)(uVar17 + 0x10);
                        if (uVar24 != 0) {
                          if (uVar24 < uVar10) goto LAB_00026afc;
                          *(uint *)(uVar7 + 0x10) = uVar24;
                          *(uint *)(uVar24 + 0x18) = uVar7;
                        }
                        uVar24 = *(uint *)(uVar17 + 0x14);
                        if (uVar24 != 0) {
                          if (uVar24 < *(uint *)(iVar25 + 0x10)) goto LAB_00026afc;
                          *(uint *)(uVar7 + 0x14) = uVar24;
                          *(uint *)(uVar24 + 0x18) = uVar7;
                        }
                      }
                    }
                    else {
                      if (uVar24 < *(uint *)(iVar25 + 0x10)) goto LAB_00026afc;
                      iVar9 = 0x14;
                      if (*(uint *)(uVar24 + 0x10) == uVar17) {
                        iVar9 = 0x10;
                      }
                      *(uint *)(uVar24 + iVar9) = uVar7;
                      if (uVar7 != 0) goto LAB_000268c8;
                    }
                  }
                }
                iVar25 = FUN_000360b0(uVar15,uVar20);
                iVar9 = DAT_00026b24;
                if (iVar25 == 0) {
                  iVar25 = DAT_00026b20 + 0x26a50;
                  *(uint *)(DAT_00026b20 + 0x26bfc) = *(int *)(DAT_00026b20 + 0x26bfc) - uVar20;
                  puVar12[2] = (uint)puVar23;
                  local_2c = uVar20 + local_2c;
                  puVar22 = puVar12;
                }
                else {
                  uVar15 = 0;
                  iVar25 = DAT_00026b24 + 0x26954;
                  if ((uVar19 >> 8 != 0) && (uVar15 = 0x1f, uVar19 >> 0x18 == 0)) {
                    uVar19 = uVar19 >> 8;
                    uVar15 = uVar19 + 0xfff00 >> 0x10 & 8;
                    uVar7 = (uVar19 << uVar15) + 0x7f000 >> 0x10 & 4;
                    uVar20 = ((uVar19 << uVar15) << uVar7) + 0x3c000 >> 0x10 & 2;
                    iVar3 = ((((uVar19 << uVar15) << uVar7) << uVar20) >> 0xf) -
                            (uVar7 | uVar15 | uVar20);
                    uVar15 = (uVar16 >> (iVar3 + 0x15U & 0xff) & 1 | iVar3 * 2) + 0x1c;
                  }
                  *(uint *)(uVar17 + 0x1c) = uVar15;
                  *(undefined4 *)(uVar17 + 0x10) = 0;
                  *(undefined4 *)(uVar17 + 0x14) = 0;
                  puVar12 = (uint *)(iVar25 + uVar15 * 4 + 300);
                  if ((*(uint *)(iVar9 + 0x26958) & 1 << (uVar15 & 0xff)) == 0) {
                    *(uint *)(iVar9 + 0x26958) = *(uint *)(iVar9 + 0x26958) | 1 << (uVar15 & 0xff);
                    *puVar12 = uVar17;
                    *(uint **)(uVar17 + 0x18) = puVar12;
                  }
                  else {
                    uVar19 = uVar15 - 0x1f;
                    if (uVar19 != 0) {
                      uVar19 = 0x19 - (uVar15 >> 1);
                    }
                    iVar3 = uVar16 << (uVar19 & 0xff);
                    uVar15 = *puVar12;
                    do {
                      uVar19 = uVar15;
                      if ((*(uint *)(uVar19 + 4) & 0xfffffffc) == uVar16) {
                        uVar15 = *(uint *)(uVar19 + 8);
                        uVar20 = *(uint *)(iVar9 + 0x26964);
                        bVar27 = uVar15 <= uVar20;
                        bVar26 = uVar20 == uVar15;
                        if (!bVar27 || bVar26) {
                          bVar27 = uVar19 <= uVar20;
                          bVar26 = uVar20 == uVar19;
                        }
                        if (bVar27 && !bVar26) goto LAB_00026afc;
                        *(uint *)(uVar15 + 0xc) = uVar17;
                        *(uint *)(uVar19 + 8) = uVar17;
                        *(undefined4 *)(uVar17 + 0x18) = 0;
                        *(uint *)(uVar17 + 8) = uVar15;
                        *(uint *)(uVar17 + 0xc) = uVar19;
                        goto LAB_00026a90;
                      }
                      iVar1 = iVar3 >> 0x1f;
                      iVar3 = iVar3 << 1;
                      puVar12 = (uint *)(uVar19 + iVar1 * -4 + 0x10);
                      uVar15 = *puVar12;
                    } while (*puVar12 != 0);
                    if (puVar12 < *(uint **)(iVar9 + 0x26964)) {
LAB_00026afc:
                    /* WARNING: Subroutine does not return */
                      FUN_0003608c();
                    }
                    *puVar12 = uVar17;
                    *(uint *)(uVar17 + 0x18) = uVar19;
                  }
                  *(uint *)(uVar17 + 8) = uVar17;
                  *(uint *)(uVar17 + 0xc) = uVar17;
                }
              }
            }
          }
LAB_00026a90:
          puVar12 = puVar22;
          puVar22 = puVar23;
        } while (puVar23 != (uint *)0x0);
      }
      ppuVar4 = (uint **)(local_2c + uVar6);
      if (ppuVar4 == (uint **)0x0) {
        *(undefined4 *)(iVar25 + 0x1c) = 0xffffffff;
        ppuVar4 = (uint **)0x0;
      }
LAB_00026aec:
      if (ppuVar4 != (uint **)0x0) {
        ppuVar4 = (uint **)0x1;
      }
      return ppuVar4;
    }
    if (*(uint ***)(iVar25 + 0x25e90) == ppuVar2) {
      *(uint ***)(iVar25 + 0x25e90) = ppuVar4;
      ppuVar8 = (uint **)(*(int *)(iVar25 + 0x25e84) + uVar6);
      *(uint ***)(iVar25 + 0x25e84) = ppuVar8;
      ppuVar4[1] = (uint *)((uint)ppuVar8 | 1);
      *(uint ***)((int)ppuVar4 + (int)ppuVar8) = ppuVar8;
      return ppuVar8;
    }
    if (puVar12 < (uint *)0x100) {
      ppuVar18 = (uint **)ppuVar2[2];
      ppuVar8 = (uint **)ppuVar18[3];
      bVar26 = ppuVar8 != ppuVar2;
      if (!bVar26) {
        unaff_r5 = (uint **)ppuVar2[3];
        ppuVar8 = (uint **)unaff_r5[2];
      }
      if (bVar26 || ppuVar8 != ppuVar2) goto LAB_000263b4;
      if (ppuVar18 == unaff_r5) {
        *puVar22 = *(uint *)(DAT_00026534 + 0x26480) & ~(1 << ((uint)puVar12 >> 3 & 0xff));
      }
      else {
        ppuVar2 = (uint **)((int)puVar22 + ((uint)puVar12 & 0xfffffff8) + 0x24);
        bVar26 = ppuVar2 <= ppuVar18;
        if (ppuVar18 != ppuVar2) {
          ppuVar8 = *(uint ***)(iVar25 + 0x25e8c);
          bVar26 = ppuVar18 <= ppuVar8;
        }
        if (bVar26 && (ppuVar18 != ppuVar2 && ppuVar8 != ppuVar18)) goto LAB_000263b4;
        bVar26 = ppuVar2 <= unaff_r5;
        bVar27 = unaff_r5 != ppuVar2;
        if (bVar27) {
          ppuVar2 = *(uint ***)(iVar25 + 0x25e8c);
          bVar26 = unaff_r5 <= ppuVar2;
        }
        if (bVar26 && (bVar27 && ppuVar2 != unaff_r5)) goto LAB_000263b4;
        ppuVar18[3] = (uint *)unaff_r5;
        unaff_r5[2] = (uint *)ppuVar18;
      }
    }
    else {
      ppuVar8 = (uint **)ppuVar2[3];
      puVar23 = ppuVar2[6];
      if (ppuVar8 == ppuVar2) {
        ppuVar14 = ppuVar2 + 5;
        ppuVar18 = (uint **)*ppuVar14;
        bVar26 = ppuVar18 == (uint **)0x0;
        if (bVar26) {
          ppuVar14 = ppuVar2 + 4;
          ppuVar18 = (uint **)*ppuVar14;
        }
        if (bVar26 && ppuVar18 == (uint **)0x0) {
          ppuVar8 = (uint **)0x0;
        }
        else {
          do {
            do {
              ppuVar8 = ppuVar18;
              ppuVar13 = ppuVar14;
              ppuVar18 = (uint **)ppuVar8[5];
              ppuVar14 = ppuVar8 + 5;
            } while (ppuVar18 != (uint **)0x0);
            ppuVar18 = (uint **)ppuVar8[4];
            ppuVar14 = ppuVar8 + 4;
          } while (ppuVar18 != (uint **)0x0);
          if (ppuVar13 < *(uint ***)(iVar25 + 0x25e8c)) goto LAB_000263b4;
          *ppuVar13 = (uint *)0x0;
        }
      }
      else {
        puVar21 = ppuVar2[2];
        ppuVar18 = (uint **)puVar21[3];
        bVar26 = ppuVar18 != ppuVar2;
        if (!bVar26) {
          ppuVar18 = (uint **)ppuVar8[2];
        }
        if ((bVar26 || ppuVar18 != ppuVar2) || (puVar21 < *(uint **)(iVar25 + 0x25e8c)))
        goto LAB_000263b4;
        puVar21[3] = (uint)ppuVar8;
        ppuVar8[2] = puVar21;
      }
      if (puVar23 != (uint *)0x0) {
        puVar21 = ppuVar2[7];
        if ((uint **)puVar22[(int)puVar21 + 0x4b] == ppuVar2) {
          puVar22[(int)puVar21 + 0x4b] = (uint)ppuVar8;
          if (ppuVar8 == (uint **)0x0) {
            *(uint *)(iVar25 + 0x25e80) =
                 *(uint *)(iVar25 + 0x25e80) & ~(1 << ((uint)puVar21 & 0xff));
          }
          else {
LAB_00026494:
            ppuVar18 = *(uint ***)(iVar25 + 0x25e8c);
            if (ppuVar8 < ppuVar18) goto LAB_000263b4;
            ppuVar8[6] = puVar23;
            ppuVar14 = (uint **)ppuVar2[4];
            if (ppuVar14 != (uint **)0x0) {
              if (ppuVar14 < ppuVar18) goto LAB_000263b4;
              ppuVar8[4] = (uint *)ppuVar14;
              ppuVar14[6] = (uint *)ppuVar8;
            }
            puVar23 = ppuVar2[5];
            if (puVar23 != (uint *)0x0) {
              if (puVar23 < *(uint **)(iVar25 + 0x25e8c)) goto LAB_000263b4;
              ppuVar8[5] = puVar23;
              puVar23[6] = (uint)ppuVar8;
            }
          }
        }
        else {
          if (puVar23 < *(uint **)(iVar25 + 0x25e8c)) goto LAB_000263b4;
          iVar9 = 0x14;
          if ((uint **)puVar23[4] == ppuVar2) {
            iVar9 = 0x10;
          }
          *(uint ***)((int)puVar23 + iVar9) = ppuVar8;
          if (ppuVar8 != (uint **)0x0) goto LAB_00026494;
        }
      }
    }
    uVar6 = ((uint)puVar12 & 0xfffffffc) + uVar6;
    ppuVar4[1] = (uint *)(uVar6 | 1);
    *(uint *)((int)ppuVar4 + uVar6) = uVar6;
    if (ppuVar4 == *(uint ***)(iVar25 + 0x25e90)) {
      *(uint *)(iVar25 + 0x25e84) = uVar6;
      return *(uint ***)(iVar25 + 0x25e90);
    }
  }
  else {
    ppuVar2[1] = (uint *)((uint)puVar12 & 0xfffffffe);
    ppuVar4[1] = (uint *)(uVar6 | 1);
    *(uint *)((int)ppuVar4 + uVar6) = uVar6;
  }
  if (0xff < uVar6) {
    puVar12 = (uint *)0x0;
    if ((uVar6 >> 8 != 0) && (puVar12 = (uint *)0x1f, uVar6 >> 0x18 == 0)) {
      uVar17 = uVar6 >> 8;
      uVar19 = uVar17 + 0xfff00 >> 0x10 & 8;
      uVar15 = (uVar17 << uVar19) + 0x7f000 >> 0x10 & 4;
      uVar20 = ((uVar17 << uVar19) << uVar15) + 0x3c000 >> 0x10 & 2;
      iVar9 = ((((uVar17 << uVar19) << uVar15) << uVar20) >> 0xf) - (uVar15 | uVar19 | uVar20);
      puVar12 = (uint *)((uVar6 >> (iVar9 + 0x15U & 0xff) & 1 | iVar9 * 2) + 0x1c);
    }
    ppuVar4[7] = puVar12;
    ppuVar4[4] = (uint *)0x0;
    ppuVar4[5] = (uint *)0x0;
    ppuVar8 = (uint **)(puVar22 + (int)puVar12 + 0x4b);
    if ((*(uint *)(iVar25 + 0x25e80) & 1 << ((uint)puVar12 & 0xff)) == 0) {
      *(uint *)(iVar25 + 0x25e80) = *(uint *)(iVar25 + 0x25e80) | 1 << ((uint)puVar12 & 0xff);
      *ppuVar8 = (uint *)ppuVar4;
      ppuVar4[6] = (uint *)ppuVar8;
    }
    else {
      uVar17 = (int)puVar12 - 0x1f;
      if (uVar17 != 0) {
        uVar17 = 0x19 - ((uint)puVar12 >> 1);
      }
      iVar9 = uVar6 << (uVar17 & 0xff);
      ppuVar8 = (uint **)*ppuVar8;
      do {
        ppuVar2 = ppuVar8;
        if (((uint)ppuVar2[1] & 0xfffffffc) == uVar6) {
          ppuVar8 = (uint **)ppuVar2[2];
          ppuVar18 = *(uint ***)(iVar25 + 0x25e8c);
          bVar27 = ppuVar8 <= ppuVar18;
          bVar26 = ppuVar18 == ppuVar8;
          if (!bVar27 || bVar26) {
            bVar27 = ppuVar2 <= ppuVar18;
            bVar26 = ppuVar18 == ppuVar2;
          }
          if (!bVar27 || bVar26) {
            ppuVar8[3] = (uint *)ppuVar4;
            ppuVar2[2] = (uint *)ppuVar4;
            ppuVar4[6] = (uint *)0x0;
            ppuVar4[2] = (uint *)ppuVar8;
            ppuVar4[3] = (uint *)ppuVar2;
            return ppuVar8;
          }
          goto LAB_000263b4;
        }
        iVar3 = iVar9 >> 0x1f;
        iVar9 = iVar9 << 1;
        ppuVar18 = ppuVar2 + (4 - iVar3);
        ppuVar8 = (uint **)*ppuVar18;
      } while ((uint **)*ppuVar18 != (uint **)0x0);
      ppuVar8 = *(uint ***)(iVar25 + 0x25e8c);
      if (ppuVar18 < ppuVar8) {
LAB_000263b4:
                    /* WARNING: Subroutine does not return */
        FUN_0003608c();
      }
      *ppuVar18 = (uint *)ppuVar4;
      ppuVar4[6] = (uint *)ppuVar2;
    }
    ppuVar4[2] = (uint *)ppuVar4;
    ppuVar4[3] = (uint *)ppuVar4;
    return ppuVar8;
  }
  uVar17 = uVar6 & 0xfffffff8;
  ppuVar8 = (uint **)((int)puVar22 + uVar17 + 0x24);
  if ((*puVar22 & 1 << (uVar6 >> 3 & 0xff)) == 0) {
    *puVar22 = *puVar22 | 1 << (uVar6 >> 3 & 0xff);
    ppuVar2 = ppuVar8;
  }
  else {
    ppuVar2 = *(uint ***)((int)puVar22 + uVar17 + 0x2c);
    if (ppuVar2 < *(uint ***)(iVar25 + 0x25e8c)) goto LAB_000263b4;
  }
  *(uint ***)((int)puVar22 + uVar17 + 0x2c) = ppuVar4;
  ppuVar2[3] = (uint *)ppuVar4;
  ppuVar4[2] = (uint *)ppuVar2;
  ppuVar4[3] = (uint *)ppuVar8;
  return ppuVar8;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00026b28 FUN_00026b28 */

int FUN_00026b28(int param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if ((param_1 == 0) || (uVar1 = FUN_00024478(0xffffffff,param_1), param_2 <= uVar1)) {
    iVar3 = FUN_000246b0(param_2 * param_1);
    if (iVar3 != 0) {
      if (((*(byte *)(iVar3 + -4) & 1) == 0) && ((*(byte *)(iVar3 + -8) & 1) != 0)) {
        return iVar3;
      }
      FUN_00036050(iVar3,0,param_2 * param_1);
      return iVar3;
    }
  }
  else {
    puVar2 = (undefined4 *)FUN_000360a4();
    *puVar2 = 0xc;
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00026bb4 FUN_00026bb4 */

int FUN_00026bb4(int param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  
  iVar3 = DAT_00026d78;
  if (param_1 == 0) {
    iVar3 = FUN_000246b0(param_2);
    return iVar3;
  }
  if (0xffffffbf < param_2) {
    puVar1 = (undefined4 *)FUN_000360a4();
    *puVar1 = 0xc;
    return 0;
  }
  uVar6 = *(uint *)(param_1 + -4);
  uVar7 = uVar6 & 0xfffffffc;
  if ((0 < (int)uVar7) && ((uVar6 & 2) != 0)) {
    pbVar8 = (byte *)(param_1 + -8);
    uVar2 = DAT_00026d78 + 0x26c1c;
    if ((*(byte **)(DAT_00026d78 + 0x26c2c) <= pbVar8) &&
       ((*(byte *)(uVar7 + param_1 + -4) & 1) != 0)) {
      uVar5 = param_2 + 0xb & 0xfffffff8;
      if (param_2 < 0xb) {
        uVar5 = 0x10;
      }
      uVar6 = uVar6 & 1;
      if ((uVar6 == 0) && ((*pbVar8 & 1) != 0)) {
        if (0xff < uVar5) {
          uVar2 = uVar5 | 4;
        }
        if ((0xff < uVar5 && uVar2 <= uVar7) &&
           (uVar7 - uVar5 <= (uint)(*(int *)(DAT_00026d7c + 0x26d6c) * 2))) {
          return param_1;
        }
      }
      else {
        if (uVar5 <= uVar7) {
          uVar7 = uVar7 - uVar5;
          if (0xf < uVar7) {
            *(uint *)(param_1 + -4) = uVar5 | uVar6 | 2;
            *(uint *)(pbVar8 + uVar5 + 4) = uVar7 | 3;
            *(uint *)(pbVar8 + uVar7 + uVar5 + 4) = *(uint *)(pbVar8 + uVar7 + uVar5 + 4) | 1;
            FUN_00025e5c(pbVar8 + uVar5 + 8);
            return param_1;
          }
          return param_1;
        }
        if ((*(int *)(DAT_00026d78 + 0x26c34) == uVar7 + param_1 + -8) &&
           (uVar2 = *(int *)(DAT_00026d78 + 0x26c28) + uVar7, uVar5 < uVar2)) {
          *(uint *)(param_1 + -4) = uVar5 | uVar6 | 2;
          uVar2 = uVar2 - uVar5;
          *(uint *)(pbVar8 + uVar5 + 4) = uVar2 | 1;
          *(uint *)(iVar3 + 0x26c28) = uVar2;
          *(byte **)(iVar3 + 0x26c34) = pbVar8 + uVar5;
          return param_1;
        }
      }
      iVar3 = FUN_000246b0(param_2);
      if (iVar3 == 0) {
        return 0;
      }
      iVar4 = 4;
      if (((*(byte *)(param_1 + -4) & 1) == 0) && (iVar4 = 8, (*pbVar8 & 1) == 0)) {
        iVar4 = 4;
      }
      if (uVar7 - iVar4 < param_2) {
        param_2 = uVar7 - iVar4;
      }
      FUN_00036044(iVar3,param_1,param_2);
      FUN_00025e5c(param_1);
      return iVar3;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_0003608c();
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00026f5c FUN_00026f5c */

void FUN_00026f5c(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_c;
  
  local_c = param_2;
  FUN_00026f84(param_1,&local_c,3,param_3);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00026f84 FUN_00026f84 */

int * FUN_00026f84(int param_1,uint *param_2,uint param_3,int *param_4)

{
  uint *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  iVar2 = DAT_00027144;
  if (param_4 == (int *)0x0) {
    if (param_1 == 0) {
      piVar3 = (int *)FUN_000246b0(0);
      return piVar3;
    }
    uVar8 = param_1 * 4 + 0xbU & 0xfffffff8;
    if ((uint)(param_1 << 2) < 0xb) {
      uVar8 = 0x10;
    }
  }
  else {
    uVar8 = 0;
    if (param_1 == 0) {
      return param_4;
    }
  }
  if ((param_3 & 1) == 0) {
    uVar6 = 0;
    uVar7 = 0;
    puVar1 = param_2;
    iVar4 = param_1;
    do {
      uVar5 = *puVar1 + 0xb & 0xfffffff8;
      if (*puVar1 < 0xb) {
        uVar5 = 0x10;
      }
      uVar7 = uVar5 + uVar7;
      iVar4 = iVar4 + -1;
      puVar1 = puVar1 + 1;
    } while (iVar4 != 0);
  }
  else {
    uVar6 = *param_2 + 0xb & 0xfffffff8;
    if (*param_2 < 0xb) {
      uVar6 = 0x10;
    }
    uVar7 = uVar6 * param_1;
  }
  uVar5 = *(uint *)(DAT_00027144 + 0x271f0);
  *(uint *)(DAT_00027144 + 0x271f0) = uVar5 & 0xfffffffe;
  iVar4 = FUN_000246b0(uVar8 + uVar7 + -4);
  if ((uVar5 & 1) != 0) {
    *(uint *)(iVar2 + 0x271f0) = *(uint *)(iVar2 + 0x271f0) | 1;
  }
  if (iVar4 == 0) {
    param_4 = (int *)0x0;
  }
  else {
    uVar5 = *(uint *)(iVar4 + -4) & 0xfffffffc;
    if ((param_3 & 2) != 0) {
      FUN_00036050(iVar4,0,(uVar5 - uVar8) + -4);
    }
    iVar2 = iVar4 + -8;
    if (param_4 == (int *)0x0) {
      param_4 = (int *)(iVar2 + uVar7 + 8);
      *(uint *)(iVar2 + uVar7 + 4) = uVar5 - uVar7 | 3;
      uVar5 = uVar7;
    }
    *param_4 = iVar4;
    piVar3 = param_4;
    for (param_1 = param_1 + -1; param_1 != 0; param_1 = param_1 + -1) {
      piVar3 = piVar3 + 1;
      uVar8 = uVar6;
      if ((uVar6 == 0) && (uVar8 = *param_2 + 0xb & 0xfffffff8, *param_2 < 0xb)) {
        uVar8 = 0x10;
      }
      *(uint *)(iVar2 + 4) = uVar8 | 3;
      iVar2 = iVar2 + uVar8;
      uVar5 = uVar5 - uVar8;
      *piVar3 = iVar2 + 8;
      param_2 = param_2 + 1;
    }
    *(uint *)(iVar2 + 4) = uVar5 | 3;
  }
  return param_4;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002717c FUN_0002717c */

void FUN_0002717c(void)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint *puVar5;
  
  iVar2 = DAT_0002721c;
  if (*(int *)(DAT_00027210 + 0x27190) != 0) {
    return;
  }
  pcVar3 = (char *)(DAT_00027218 + 0x271b0);
  *(undefined4 *)(DAT_00027214 + 0x271a8) = 0x200000;
  cVar1 = *pcVar3;
  *(undefined4 *)(iVar2 + 0x271b8) = 0x10000;
  iVar2 = DAT_00027220;
  if (cVar1 == '\0') {
    *pcVar3 = '\x01';
    *(undefined4 *)(&UNK_00027390 + iVar2) = 1;
  }
  uVar4 = FUN_00036038(0x28);
  puVar5 = (uint *)(DAT_00027228 + 0x271f8);
  *(uint *)(DAT_00027224 + 0x271f4) = uVar4;
  *puVar5 = uVar4;
  if ((uVar4 & uVar4 - 1) == 0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0003608c();
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002722c FUN_0002722c */

uint * FUN_0002722c(int param_1)

{
  uint *puVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  int extraout_r1;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  uint *puVar10;
  
  FUN_0002717c();
  uVar4 = *(uint *)(DAT_0002725c + 0x27248);
  uVar5 = (param_1 + uVar4) - 1 & -uVar4;
  if (uVar4 < 9) {
    puVar1 = (uint *)FUN_000246b0(uVar5);
    return puVar1;
  }
  if (uVar4 < 0x11) {
    uVar4 = 0x10;
  }
  uVar8 = 0x10;
  uVar7 = uVar4;
  if ((uVar4 & uVar4 - 1) != 0) {
    do {
      uVar7 = uVar8;
      uVar8 = uVar7 << 1;
    } while (uVar7 < uVar4);
  }
  if (-uVar7 - 0x40 <= uVar5) {
    puVar3 = (undefined4 *)FUN_000360a4();
    *puVar3 = 0xc;
    return (uint *)0x0;
  }
  uVar4 = uVar5 + 0xb & 0xfffffff8;
  if (uVar5 < 0xb) {
    uVar4 = 0x10;
  }
  iVar2 = FUN_000246b0(uVar4 + uVar7 + 0xc);
  if (iVar2 == 0) {
    return (uint *)0x0;
  }
  FUN_00024664(iVar2,uVar7);
  puVar1 = (uint *)(iVar2 + -8);
  if (extraout_r1 == 0) {
    puVar6 = (uint *)(iVar2 + -4);
    uVar5 = *puVar6;
  }
  else {
    puVar10 = (uint *)(((iVar2 + uVar7) - 1 & -uVar7) - 8);
    if ((uint)((int)puVar10 - (int)puVar1) < 0x10) {
      puVar10 = (uint *)((int)puVar10 + uVar7);
    }
    uVar8 = (int)puVar10 - (int)puVar1;
    uVar5 = (*(uint *)(iVar2 + -4) & 0xfffffffc) - uVar8;
    if (((*(uint *)(iVar2 + -4) & 1) != 0) || ((*puVar1 & 1) == 0)) {
      puVar6 = puVar10 + 1;
      *puVar6 = uVar5 | *puVar6 & 1 | 2;
      *(uint *)((int)puVar10 + uVar5 + 4) = *(uint *)((int)puVar10 + uVar5 + 4) | 1;
      *(uint *)(iVar2 + -4) = uVar8 | *(uint *)(iVar2 + -4) & 1 | 2;
      uVar5 = *puVar6 | 1;
      *puVar6 = uVar5;
      puVar1 = puVar10;
      goto LAB_00026ee0;
    }
    *puVar10 = *puVar1 + uVar8;
    uVar5 = uVar5 | 2;
    puVar6 = puVar10 + 1;
    *puVar6 = uVar5;
    puVar1 = puVar10;
  }
  iVar2 = 0;
LAB_00026ee0:
  if (((uVar5 & 1) != 0) || (pbVar9 = (byte *)0x0, (*(byte *)puVar1 & 1) == 0)) {
    uVar8 = uVar5 & 0xfffffffc;
    pbVar9 = (byte *)0x0;
    if (uVar4 + 0x10 < uVar8) {
      *puVar6 = uVar4 | uVar5 & 1 | 2;
      *(uint *)((int)puVar1 + uVar4 + 4) = uVar8 - uVar4 | 3;
      pbVar9 = (byte *)((int)puVar1 + uVar4 + 8);
      *(uint *)((int)puVar1 + uVar8 + 4) = *(uint *)((int)puVar1 + uVar8 + 4) | 1;
    }
  }
  if (iVar2 != 0) {
    FUN_00025e5c(iVar2);
  }
  if (pbVar9 != (byte *)0x0) {
    FUN_00025e5c(pbVar9);
  }
  return puVar1 + 2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00027394 FUN_00027394 */

undefined4 FUN_00027394(int param_1,uint param_2)

{
  uint *puVar1;
  
  FUN_0002717c();
  if (param_1 == -3) {
    puVar1 = (uint *)(DAT_00027418 + 0x27404);
  }
  else if (param_1 == -2) {
    if ((param_2 & param_2 - 1) != 0) {
      return 0;
    }
    if (param_2 < *(uint *)(DAT_00027410 + 0x273e8)) {
      return 0;
    }
    puVar1 = (uint *)(DAT_00027414 + 0x273f8);
  }
  else {
    if (param_1 != -1) {
      return 0;
    }
    puVar1 = (uint *)(DAT_0002740c + 0x273d0);
  }
  *puVar1 = param_2;
  return 1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002741c FUN_0002741c */

void FUN_0002741c(code *param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  bool bVar7;
  
  iVar1 = DAT_000274fc;
  if (*(int *)(DAT_000274fc + 0x2744c) != 0) {
    puVar6 = (uint *)(DAT_000274fc + 0x275ec);
    do {
      uVar2 = *puVar6;
      uVar5 = uVar2;
      if ((uVar2 + 8 & 7) != 0) {
        uVar5 = uVar2 + (-uVar2 - 8 & 7);
      }
      do {
        if (uVar2 + puVar6[1] <= uVar5) break;
        uVar4 = *(uint *)(iVar1 + 0x2744c);
        bVar7 = uVar4 == uVar5;
        if (!bVar7) {
          uVar4 = *(uint *)(uVar5 + 4);
        }
        if (bVar7 || uVar4 == 7) break;
        if ((uVar4 & 2) == 0) {
          iVar3 = 0x20;
          if (uVar4 < 0x100) {
            iVar3 = 0x10;
          }
          (*param_1)(uVar5 + iVar3,uVar5 + (uVar4 & 0xfffffffc),param_2);
          uVar2 = *puVar6;
          uVar4 = *(uint *)(uVar5 + 4);
        }
        uVar5 = uVar5 + (uVar4 & 0xfffffffc);
      } while (uVar2 <= uVar5);
      if (*(uint *)(iVar1 + 0x2744c) == uVar5) {
        (*param_1)(uVar5 + 0x10,uVar5 + (*(uint *)(uVar5 + 4) & 0xfffffffc),param_2);
      }
      puVar6 = (uint *)puVar6[2];
    } while (puVar6 != (uint *)0x0);
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00027500 FUN_00027500 */

void FUN_00027500(code *param_1,undefined4 param_2)

{
  int iVar1;
  byte *pbVar2;
  byte *pbVar3;
  int iVar4;
  byte *pbVar5;
  byte **ppbVar6;
  bool bVar7;
  
  iVar1 = DAT_000275f8;
  ppbVar6 = (byte **)(DAT_000275f8 + 0x276dc);
  do {
    pbVar2 = *ppbVar6;
    pbVar5 = pbVar2;
    if (((uint)(pbVar2 + 8) & 7) != 0) {
      pbVar5 = pbVar2 + (-(int)pbVar2 - 8U & 7);
    }
    do {
      if (pbVar2 + (int)ppbVar6[1] <= pbVar5) break;
      pbVar2 = *(byte **)(iVar1 + 0x2753c);
      bVar7 = pbVar2 == pbVar5;
      if (!bVar7) {
        pbVar2 = *(byte **)(pbVar5 + 4);
      }
      if (bVar7 || pbVar2 == (byte *)0x7) break;
      pbVar3 = (byte *)0x0;
      iVar4 = 0;
      if (((uint)pbVar2 & 2) != 0) {
        iVar4 = 4;
        if ((((uint)pbVar2 & 1) == 0) && (iVar4 = 8, (*pbVar5 & 1) == 0)) {
          iVar4 = 4;
        }
        pbVar3 = pbVar5 + 8;
        iVar4 = ((uint)pbVar2 & 0xfffffffc) - iVar4;
      }
      (*param_1)(pbVar5,(uint)pbVar2 & 0xfffffffc,pbVar3,iVar4,param_2);
      pbVar2 = *ppbVar6;
      pbVar5 = pbVar5 + (*(uint *)(pbVar5 + 4) & 0xfffffffc);
    } while (pbVar2 <= pbVar5);
    if (*(byte **)(iVar1 + 0x2753c) == pbVar5) {
      (*param_1)(pbVar5,*(undefined4 *)(iVar1 + 0x27530),0,0,param_2);
    }
    ppbVar6 = (byte **)ppbVar6[2];
    if (ppbVar6 == (byte **)0x0) {
      return;
    }
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000275fc FUN_000275fc */

uint FUN_000275fc(byte *param_1)

{
  uint uVar1;
  uint local_8;
  byte *local_4;
  
  local_8 = 0;
  local_4 = param_1;
  while (*local_4 != 0) {
    local_8 = local_8 * 0x10 + (uint)*local_4;
    uVar1 = local_8 & 0xf0000000;
    if (uVar1 != 0) {
      local_8 = local_8 ^ uVar1 >> 0x18;
    }
    local_8 = local_8 & (uVar1 ^ 0xffffffff);
    local_4 = local_4 + 1;
  }
  return local_8;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002768c FUN_0002768c */

void FUN_0002768c(undefined4 param_1,undefined4 param_2)

{
  FUN_000360bc(param_1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000276b4 FUN_000276b4 */

undefined4 FUN_000276b4(int **param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  int **local_2c;
  ushort local_26;
  int **local_18;
  
  bVar4 = *(int *)(DAT_0002796c + 0x276e4) == 0;
  if (bVar4) {
    FUN_00027c6c(param_1);
  }
  else {
    FUN_000360c8(DAT_00027960 + 0x276f8,param_1);
  }
  local_18 = (int **)*param_1;
  do {
    if (local_18 == param_1) {
      if (bVar4) {
        FUN_000283e0(param_1);
      }
      local_18 = (int **)*param_1;
      while( true ) {
        if (local_18 != param_1) {
          local_2c = (int **)*local_18;
        }
        if (local_18 == param_1 || local_18 == (int **)0x0) break;
        if (((local_18[6] == (int *)0x0) || (local_18[7] == (int *)0x0)) ||
           ((local_18[0xb] == (int *)0x0 && (local_18[0xc] == (int *)0x0)))) {
          piVar1 = *local_18;
          piVar3 = local_18[1];
          piVar1[1] = (int)piVar3;
          *piVar3 = (int)piVar1;
          FUN_00025e5c(local_18);
        }
        local_18 = local_2c;
      }
      return 0;
    }
    if ((*(byte *)(local_18 + 0xf) & 1) == 0) {
      piVar1 = local_18[2];
      if ((int *)piVar1[7] < local_18[3]) {
        iVar2 = (int)local_18[2] + piVar1[7];
        for (local_26 = 0; local_26 != *(ushort *)(piVar1 + 0xb); local_26 = local_26 + 1) {
          if (*(int *)(iVar2 + (uint)local_26 * 0x20) == 1) {
            local_18[10] = (int *)((int)local_18[2] - *(int *)(iVar2 + (uint)local_26 * 0x20 + 8));
            break;
          }
        }
        FUN_00027fa0(local_18,iVar2,*(undefined2 *)(piVar1 + 0xb));
      }
      else {
        FUN_000360d4(6,DAT_00027964 + 0x2780c,DAT_00027968 + 0x27814,(int)local_18 + 0x3d);
      }
    }
    local_18 = (int **)*local_18;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00027970 FUN_00027970 */

undefined4 FUN_00027970(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int local_3c;
  undefined4 *local_2c;
  ushort local_22;
  int local_20;
  int local_1c;
  
  if ((*(short *)(param_1 + 3) != 0) && (param_1[2] != 0)) {
    local_1c = 0;
    local_20 = 0;
    for (local_22 = 0; local_22 != *(ushort *)(param_1 + 3); local_22 = local_22 + 1) {
      if (*(int *)(param_1[2] + (uint)local_22 * 0x20) == 1) {
        if (local_20 == 0) {
          local_20 = *(int *)(param_1[2] + (uint)local_22 * 0x20 + 8) + *param_1;
        }
        if ((*(uint *)(param_1[2] + (uint)local_22 * 0x20 + 4) <= *(uint *)(local_20 + 0x1c)) &&
           (iVar2 = param_1[2] + (uint)local_22 * 0x20,
           *(uint *)(local_20 + 0x1c) < (uint)(*(int *)(iVar2 + 4) + *(int *)(iVar2 + 0x10)))) {
          iVar2 = param_1[2] + (uint)local_22 * 0x20;
          local_1c = (*(int *)(local_20 + 0x1c) - *(int *)(iVar2 + 4)) +
                     *(int *)(iVar2 + 8) + *param_1;
          break;
        }
      }
    }
    if ((local_20 != 0) && (local_1c != 0)) {
      for (local_2c = (undefined4 *)*param_3; local_2c != param_3;
          local_2c = (undefined4 *)*local_2c) {
        if (local_2c[2] == local_20) {
          return 0;
        }
      }
      if (param_1[1] == 0) {
        local_3c = 0;
      }
      else {
        local_3c = FUN_000360e0(param_1[1]);
      }
      puVar1 = (undefined4 *)FUN_00026b28(1,local_3c + 0x40);
      puVar1[2] = local_20;
      if (param_1[1] != 0) {
        FUN_000360ec((int)puVar1 + 0x3d,param_1[1]);
      }
      FUN_00027fa0(puVar1,local_1c,*(undefined2 *)(local_20 + 0x2c));
      *puVar1 = param_3;
      puVar1[1] = param_3[1];
      *(undefined4 **)puVar1[1] = puVar1;
      param_3[1] = puVar1;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00027c6c FUN_00027c6c */

void FUN_00027c6c(undefined4 *param_1)

{
  bool bVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *local_108c;
  char *local_1078;
  char *local_1074;
  undefined4 local_1070;
  undefined4 local_106c;
  int local_1068;
  int local_1064;
  int local_1060;
  undefined4 local_105c;
  undefined4 local_1058;
  undefined auStack_1054 [4160];
  undefined4 *local_14;
  
  local_14 = param_1;
  local_1058 = FUN_000360f8(DAT_00027f90 + 0x27c88,0);
  local_105c = 0;
  local_1060 = 0;
  local_1064 = 0;
  while (local_1064 = FUN_00036104(local_1058,auStack_1054 + local_1060,0x1000 - local_1060),
        0 < local_1064) {
    auStack_1054[local_1060 + local_1064] = 0;
    local_1068 = 0;
    while (iVar2 = FUN_00028ca4(auStack_1054 + local_1068,(local_1060 + local_1064) - local_1068,
                                &local_106c,&local_1070,&local_1074,&local_1078), iVar2 != 0) {
      if (((local_1078 != (char *)0x0) && (*local_1078 == '/')) && (*local_1074 == 'r')) {
        piVar3 = (int *)FUN_00028f14(local_106c);
        iVar4 = FUN_00028f14(local_1070);
        bVar1 = false;
        for (local_108c = (undefined4 *)*local_14; local_108c != local_14;
            local_108c = (undefined4 *)*local_108c) {
          iVar5 = FUN_00036110((int)local_108c + 0x3d,local_1078);
          if (iVar5 == 0) {
            local_108c[4] = iVar4 - local_108c[2];
            bVar1 = true;
          }
        }
        iVar4 = iVar4 - (int)piVar3;
        if (((!bVar1) && (4 < iVar4)) &&
           ((iVar5 = FUN_0003611c(local_1078,DAT_00027f94 + 0x27e4c,5), iVar5 != 0 &&
            (*piVar3 == DAT_00027f98)))) {
          iVar5 = FUN_000360e0(local_1078);
          puVar6 = (undefined4 *)FUN_00026b28(1,iVar5 + 0x40);
          puVar6[2] = piVar3;
          FUN_000360ec((int)puVar6 + 0x3d,local_1078);
          iVar5 = DAT_00027f9c + 0x27eb0;
          puVar6[4] = iVar4;
          puVar6[3] = iVar4;
          iVar4 = FUN_00036128((int)puVar6 + 0x3d,iVar5);
          if (iVar4 == 0) {
            *puVar6 = local_14;
            puVar6[1] = local_14[1];
            *(undefined4 **)puVar6[1] = puVar6;
            local_14[1] = puVar6;
          }
        }
      }
      local_1068 = local_1068 + iVar2;
    }
    local_1060 = (local_1060 + local_1064) - local_1068;
    if (local_1060 != 0) {
      FUN_0003605c(auStack_1054,auStack_1054 + local_1068,local_1060);
    }
  }
  FUN_00036134(local_1058);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00027fa0 FUN_00027fa0 */

void FUN_00027fa0(int param_1,int param_2,int param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  int local_34;
  int *local_30;
  int local_2c;
  int *local_28;
  int local_24;
  ushort local_1c;
  
  if (*(int *)(param_1 + 0x10) == 0) {
    bVar1 = true;
    for (local_1c = 0; local_1c != *(ushort *)(*(int *)(param_1 + 8) + 0x2c);
        local_1c = local_1c + 1) {
      if (*(int *)(param_2 + (uint)local_1c * 0x20) == 1) {
        if (bVar1) {
          *(int *)(param_1 + 0x28) =
               *(int *)(param_1 + 8) - *(int *)(param_2 + (uint)local_1c * 0x20 + 8);
          bVar1 = false;
        }
        iVar2 = param_2 + (uint)local_1c * 0x20;
        *(int *)(param_1 + 0x10) =
             (*(int *)(iVar2 + 8) + *(int *)(iVar2 + 0x14) + *(int *)(param_1 + 0x28)) -
             *(int *)(param_1 + 8);
      }
    }
  }
  iVar2 = *(int *)(param_1 + 0x28);
  *(undefined *)(param_1 + 0x3c) = 1;
  local_24 = 0;
  while( true ) {
    if (local_24 == param_3) goto LAB_00028278;
    if (*(int *)(param_2 + local_24 * 0x20) == 2) break;
    local_24 = local_24 + 1;
  }
  *(int *)(param_1 + 0x14) = *(int *)(param_2 + local_24 * 0x20 + 8) + *(int *)(param_1 + 0x28);
  for (local_28 = *(int **)(param_1 + 0x14); *local_28 != 0; local_28 = local_28 + 2) {
    if (*local_28 == 6) {
      *(int *)(param_1 + 0x18) = local_28[1] + iVar2;
    }
    else if (*local_28 == 5) {
      *(int *)(param_1 + 0x1c) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_000283d4) {
      *(int *)(param_1 + 0x20) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_000283d8) {
      *(int *)(param_1 + 0x24) = local_28[1] + *(int *)(param_1 + 0x28);
    }
    else if (*local_28 == 4) {
      *(int *)(param_1 + 0x2c) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_000283dc) {
      *(int *)(param_1 + 0x30) = local_28[1] + iVar2;
    }
  }
LAB_00028278:
  if (*(int *)(param_1 + 0x24) != 0) {
    local_2c = *(int *)(param_1 + 0x24);
    while( true ) {
      local_30 = (int *)(local_2c + *(int *)(local_2c + 0xc));
      if ((*(ushort *)(local_2c + 2) & 1) != 0) {
        *(int *)(param_1 + 0x38) = *(int *)(param_1 + 0x1c) + *local_30;
        *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(local_2c + 8);
        return;
      }
      for (; local_30[1] != 0; local_30 = (int *)((int)local_30 + local_30[1])) {
      }
      if (*(int *)(local_2c + 0x10) == 0) break;
      local_2c = local_2c + *(int *)(local_2c + 0x10);
    }
  }
  if (*(int *)(param_1 + 0x38) == 0) {
    local_34 = FUN_00036140(param_1 + 0x3d,0x2f);
    if (local_34 == 0) {
      local_34 = param_1 + 0x3d;
    }
    else {
      local_34 = local_34 + 1;
    }
    *(int *)(param_1 + 0x38) = local_34;
    uVar3 = FUN_000275fc(*(undefined4 *)(param_1 + 0x38));
    *(undefined4 *)(param_1 + 0x34) = uVar3;
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000283e0 FUN_000283e0 */

void FUN_000283e0(int **param_1)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  int *piVar4;
  int **ppiVar5;
  int local_2c;
  int **local_24;
  int **local_20;
  int *local_18;
  int **local_14;
  
  iVar1 = FUN_00028724(param_1,DAT_00028654 + 0x283f8);
  if (((iVar1 != 0) && (*(int *)(iVar1 + 0x14) != 0)) && (*(int *)(iVar1 + 0x1c) != 0)) {
    local_14 = (int **)0x0;
    for (local_18 = *(int **)(iVar1 + 0x14); *local_18 != 0; local_18 = local_18 + 2) {
      if ((*local_18 == 1) &&
         (pcVar2 = (char *)(*(int *)(iVar1 + 0x1c) + local_18[1]), *pcVar2 != '\0')) {
        local_24 = (int **)*param_1;
        while( true ) {
          if (local_24 != param_1) {
            local_20 = (int **)*local_24;
          }
          if (local_24 == param_1 || local_24 == (int **)0x0) break;
          local_2c = FUN_00036140((int)local_24 + 0x3d,0x2f);
          if (local_2c == 0) {
            local_2c = (int)local_24 + 0x3d;
          }
          else {
            local_2c = local_2c + 1;
          }
          iVar3 = FUN_00036110(local_2c,pcVar2);
          if (iVar3 == 0) {
            piVar4 = *local_24;
            ppiVar5 = (int **)local_24[1];
            piVar4[1] = (int)ppiVar5;
            *ppiVar5 = piVar4;
            if (local_14 == (int **)0x0) {
              *local_24 = *param_1;
              local_24[1] = (int *)param_1;
              (*local_24)[1] = (int)local_24;
              *param_1 = (int *)local_24;
            }
            else {
              *local_24 = *local_14;
              local_24[1] = (int *)local_14;
              (*local_24)[1] = (int)local_24;
              *local_14 = (int *)local_24;
            }
            local_14 = local_24;
          }
          local_24 = local_20;
        }
      }
    }
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028658 FUN_00028658 */

void FUN_00028658(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  *(int *)param_1 = param_1;
  *(int *)(param_1 + 4) = param_1;
  FUN_000276b4(param_1);
  iVar1 = DAT_000286c0;
  iVar2 = DAT_000286bc + 0x28694;
  uVar3 = *(undefined4 *)(DAT_000286c4 + 0x286a4);
  *(undefined4 *)(DAT_000286c0 + 0x286b0) = *(undefined4 *)(DAT_000286c8 + 0x286ac);
  *(undefined4 *)((int)&DAT_000286bc + iVar1) = uVar3;
  *(int *)((int)&DAT_000286c8 + iVar1) = iVar2;
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000286cc FUN_000286cc */

undefined4 FUN_000286cc(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_c;
  
  iVar1 = FUN_00028724(param_1,param_2);
  if (iVar1 == 0) {
    local_c = 0;
  }
  else {
    local_c = *(undefined4 *)(iVar1 + 8);
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028724 FUN_00028724 */

undefined4 * FUN_00028724(undefined4 *param_1,uint param_2)

{
  undefined4 *local_14;
  
  local_14 = (undefined4 *)*param_1;
  while( true ) {
    if (local_14 == param_1) {
      return (undefined4 *)0x0;
    }
    if (((uint)local_14[2] <= param_2) && (param_2 < (uint)(local_14[2] + local_14[4]))) break;
    local_14 = (undefined4 *)*local_14;
  }
  return local_14;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000287c4 FUN_000287c4 */

void FUN_000287c4(int **param_1)

{
  int *piVar1;
  int **ppiVar2;
  int **local_18;
  int **local_14;
  
  local_14 = (int **)*param_1;
  while( true ) {
    if (local_14 != param_1) {
      local_18 = (int **)*local_14;
    }
    if (local_14 == param_1 || local_14 == (int **)0x0) break;
    piVar1 = *local_14;
    ppiVar2 = (int **)local_14[1];
    piVar1[1] = (int)ppiVar2;
    *ppiVar2 = piVar1;
    FUN_00025e5c(local_14);
    local_14 = local_18;
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028884 FUN_00028884 */

int FUN_00028884(undefined4 *param_1,char **param_2)

{
  uint uVar1;
  int local_30;
  int local_2c;
  int local_28;
  undefined4 local_24;
  undefined4 *local_20;
  undefined4 *local_1c;
  undefined4 *local_18;
  char **local_14;
  undefined4 *local_10;
  int local_c;
  
  if (**param_2 == '\0') {
    local_c = 0;
  }
  else {
    local_20 = (undefined4 *)0x0;
    local_24 = 0;
    local_18 = param_1;
    local_14 = param_2;
    local_10 = param_1;
    FUN_00036050(&local_30,0,0xc);
    for (local_1c = (undefined4 *)*local_18; local_1c != local_18;
        local_1c = (undefined4 *)*local_1c) {
      if (((local_1c != local_20) &&
          (uVar1 = FUN_00028a30(local_1c,local_10 + 2,local_14,&local_30), (uVar1 & 1) != 0)) &&
         (local_30 != 0)) {
        return local_30;
      }
    }
    if (local_2c == 0) {
      if (local_28 == 0) {
        local_c = FUN_0003614c(0xffffffff,*local_14);
        if (local_c == 0) {
          local_c = 0;
        }
      }
      else {
        local_c = local_28;
      }
    }
    else {
      local_c = local_2c;
    }
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028a30 FUN_00028a30 */

byte FUN_00028a30(int param_1,undefined4 param_2,undefined4 param_3,code **param_4)

{
  int iVar1;
  code *local_34;
  code *local_2c;
  int local_24;
  byte local_1d;
  code **local_1c;
  undefined4 local_18;
  undefined4 local_14;
  int local_10;
  byte local_9;
  
  local_1d = 0;
  local_24 = 0;
  local_1c = param_4;
  local_18 = param_3;
  local_14 = param_2;
  local_10 = param_1;
  iVar1 = FUN_0002902c(param_1,param_3,&local_24);
  if (iVar1 < 0) {
    *local_1c = *(code **)(DAT_00028ca0 + iVar1 * -0xc + 0x28a90);
    local_9 = 1;
  }
  else {
    if (iVar1 != 0) {
      local_2c = (code *)(*(int *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 4) +
                         *(int *)(local_10 + 0x28));
      if ((*(byte *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 0xc) & 0xf) == 10) {
        local_2c = (code *)(*local_2c)(local_2c);
      }
      if ((int)(uint)*(byte *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 0xc) >> 4 != 2) {
        if (*local_1c == (code *)0x0) {
          *local_1c = local_2c;
        }
        return 1;
      }
      if (local_1c[2] == (code *)0x0) {
        local_1c[2] = local_2c;
      }
      local_1d = 1;
    }
    if (local_24 != 0) {
      local_34 = (code *)(*(int *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 4) +
                         *(int *)(local_10 + 0x28));
      if ((*(byte *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 0xc) & 0xf) == 10) {
        local_34 = (code *)(*local_34)(local_34);
      }
      if ((int)(uint)*(byte *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 0xc) >> 4 == 2) {
        if (local_1c[2] == (code *)0x0) {
          local_1c[2] = local_34;
        }
      }
      else if (local_1c[1] == (code *)0x0) {
        local_1c[1] = local_34;
      }
      local_1d = 1;
    }
    local_9 = local_1d & 1;
  }
  return local_9;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028ca4 FUN_00028ca4 */

undefined *
FUN_00028ca4(undefined *param_1,int param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  undefined *local_2c;
  undefined *local_28;
  int local_24;
  
  *param_3 = 0;
  *param_4 = 0;
  *param_6 = 0;
  *param_5 = 0;
  local_24 = 0;
  local_28 = (undefined *)0x0;
  local_2c = param_1;
  do {
    if (param_1 + param_2 <= local_2c) {
      return (undefined *)0x0;
    }
    switch(*local_2c) {
    case 9:
    case 0x20:
      local_28 = (undefined *)0x0;
      break;
    case 10:
    case 0xd:
      *local_2c = 0;
      return local_2c + (1 - (int)param_1);
    default:
switchD_00028d3c_caseD_b:
      if (local_28 == (undefined *)0x0) {
        local_28 = local_2c;
        switch(local_24) {
        case 0:
          *param_3 = local_2c;
          break;
        case 1:
          *param_4 = local_2c;
          break;
        case 2:
          if (param_1 + param_2 < local_2c + 4) {
            return (undefined *)0x0;
          }
          *param_5 = local_2c;
          break;
        case 6:
          *param_6 = local_2c;
        }
        local_24 = local_24 + 1;
      }
      break;
    case 0x2d:
      if (local_24 != 1) goto switchD_00028d3c_caseD_b;
      local_28 = (undefined *)0x0;
    }
    local_2c = local_2c + 1;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028f14 FUN_00028f14 */

undefined8 FUN_00028f14(byte *param_1)

{
  byte local_11;
  uint local_10;
  uint local_c;
  byte *local_8;
  
  local_c = 0;
  local_10 = 0;
  for (local_8 = param_1; *local_8 != 0; local_8 = local_8 + 1) {
    local_11 = *local_8;
    if ((local_11 < 0x61) || (0x66 < local_11)) {
      if ((local_11 < 0x41) || (0x46 < local_11)) {
        if ((local_11 < 0x30) || (0x39 < local_11)) break;
        local_11 = local_11 - 0x30;
      }
      else {
        local_11 = local_11 - 0x37;
      }
    }
    else {
      local_11 = local_11 + 0xa9;
    }
    local_c = local_c << 4 | local_10 >> 0x1c;
    local_10 = local_10 << 4 | (uint)local_11;
  }
  return CONCAT44(local_c,local_10);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002902c FUN_0002902c */

undefined4 FUN_0002902c(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_18;
  
  local_18 = 0;
  if (*(int *)(param_1 + 0x30) == 0) {
    if (*(int *)(param_1 + 0x2c) != 0) {
      local_18 = FUN_00029370(param_1,param_2,param_3);
    }
  }
  else {
    local_18 = FUN_000290ac(param_1,param_2,param_3);
  }
  return local_18;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000290ac FUN_000290ac */

uint FUN_000290ac(int param_1,undefined4 *param_2,uint *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int extraout_r1;
  uint uVar9;
  uint uVar10;
  int extraout_r1_00;
  uint local_3c;
  
  iVar1 = *(int *)(param_1 + 0x18);
  iVar2 = *(int *)(param_1 + 0x1c);
  piVar3 = *(int **)(param_1 + 0x30);
  uVar4 = *param_2;
  *param_3 = 0;
  uVar5 = FUN_00029578(uVar4);
  iVar7 = piVar3[2];
  iVar8 = *piVar3;
  FUN_00024664(uVar5,*piVar3);
  local_3c = piVar3[iVar7 + extraout_r1 + 4];
  uVar9 = piVar3[1];
  if ((uVar9 <= local_3c) &&
     (uVar10 = piVar3[3], FUN_00024664(uVar5 >> 5,piVar3[2],extraout_r1),
     uVar10 = 1 << (uVar5 & 0x1f) | 1 << (uVar5 >> (uVar10 & 0xff) & 0x1f),
     (piVar3[extraout_r1_00 + 4] & uVar10) == uVar10)) {
    while( true ) {
      if ((((uVar5 & 0xfffffffe) == (piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] & 0xfffffffeU))
          && (*(short *)(iVar1 + local_3c * 0x10 + 0xe) != 0)) &&
         (iVar6 = FUN_00036110(iVar2 + *(int *)(iVar1 + local_3c * 0x10),*param_2), iVar6 == 0)) {
        if (param_2[1] == 0) {
          return local_3c;
        }
        uVar10 = FUN_000295e4(param_1,param_2,local_3c);
        if ((uVar10 & 1) != 0) {
          return local_3c;
        }
        *param_3 = local_3c;
      }
      if (((piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] & 1U) != 0) &&
         (piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] !=
          piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 5])) break;
      local_3c = local_3c + 1;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00029370 FUN_00029370 */

int FUN_00029370(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int extraout_r1;
  int local_34;
  int local_2c;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  iVar2 = *(int *)(param_1 + 0x18);
  uVar3 = *param_2;
  iVar4 = FUN_000275fc(uVar3);
  FUN_00024664(iVar4,*piVar1);
  *param_3 = 0;
  for (local_34 = 0; local_34 != 4; local_34 = local_34 + 1) {
    if ((iVar4 == *(int *)(DAT_00029570 + local_34 * 0xc + 0x29400)) &&
       (iVar5 = FUN_00036110(uVar3,*(undefined4 *)(DAT_00029574 + 0x29424 + local_34 * 0xc)),
       iVar5 == 0)) {
      return -local_34;
    }
  }
  local_2c = piVar1[extraout_r1 + 2];
  do {
    if (local_2c == 0) {
      return 0;
    }
    if ((*(short *)(iVar2 + local_2c * 0x10 + 0xe) != 0) &&
       (iVar4 = FUN_00036110(*(int *)(param_1 + 0x1c) + *(int *)(iVar2 + local_2c * 0x10),uVar3),
       iVar4 == 0)) {
      if (param_2[1] == 0) {
        return local_2c;
      }
      uVar6 = FUN_000295e4(param_1,param_2,local_2c);
      if ((uVar6 & 1) != 0) {
        return local_2c;
      }
      *param_3 = local_2c;
    }
    local_2c = piVar1[*piVar1 + local_2c + 2];
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00029578 FUN_00029578 */

int FUN_00029578(byte *param_1)

{
  int local_c;
  byte local_5;
  byte *local_4;
  
  local_c = 0x1505;
  local_5 = *param_1;
  local_4 = param_1;
  while (local_5 != 0) {
    local_c = local_c * 0x21 + (uint)local_5;
    local_5 = local_4[1];
    local_4 = local_4 + 1;
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000295e4 FUN_000295e4 */

undefined FUN_000295e4(int param_1,int param_2,int param_3)

{
  int iVar1;
  int local_20;
  
  if ((*(int *)(param_1 + 0x20) != 0) && (*(int *)(param_1 + 0x24) != 0)) {
    local_20 = *(int *)(param_1 + 0x24);
    while( true ) {
      if (((*(ushort *)(local_20 + 2) & 1) == 0) &&
         ((*(ushort *)(*(int *)(param_1 + 0x20) + param_3 * 2) & 0x7fff) ==
          *(ushort *)(local_20 + 4))) {
        if ((*(int *)(param_2 + 8) == *(int *)(local_20 + 8)) &&
           (iVar1 = FUN_00036110(*(undefined4 *)(param_2 + 4),
                                 *(int *)(param_1 + 0x1c) +
                                 *(int *)(local_20 + *(int *)(local_20 + 0xc))), iVar1 == 0)) {
          return 1;
        }
        return 0;
      }
      if (*(int *)(local_20 + 0x10) == 0) break;
      local_20 = local_20 + *(int *)(local_20 + 0x10);
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002c900 entry */

void processEntry entry(undefined4 param_1)

{
  undefined4 in_r1;
  undefined4 in_r2;
  undefined4 in_r3;
  
                    /* WARNING: Could not recover jumptable at 0x0001562c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_000155d0 + DAT_000155d0))(param_1,in_r1,in_r2,in_r3,param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002d540 FUN_0002d540 */

void FUN_0002d540(undefined4 param_1,undefined4 param_2)

{
  int unaff_r4;
  code *UNRECOVERED_JUMPTABLE;
  
  if (unaff_r4 != DAT_0002d554) {
    UNRECOVERED_JUMPTABLE = (code *)((int)&DAT_0002d578 + DAT_0002d578);
  }
                    /* WARNING: Could not recover jumptable at 0x0002d59c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(param_1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036038 FUN_00036038 */

void FUN_00036038(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036040. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1ac)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036044 FUN_00036044 */

void FUN_00036044(void)

{
                    /* WARNING: Could not recover jumptable at 0x0003604c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1b0)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036050 FUN_00036050 */

void FUN_00036050(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036058. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1b4)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003605c FUN_0003605c */

void FUN_0003605c(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036064. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1b8)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036068 FUN_00036068 */

void FUN_00036068(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036070. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1bc)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036074 FUN_00036074 */

void FUN_00036074(void)

{
                    /* WARNING: Could not recover jumptable at 0x0003607c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1c0)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036080 FUN_00036080 */

void FUN_00036080(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036088. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1c4)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003608c FUN_0003608c */

void FUN_0003608c(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036094. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1c8)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036098 FUN_00036098 */

void FUN_00036098(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1cc)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360a4 FUN_000360a4 */

void FUN_000360a4(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360ac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1d0)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360b0 FUN_000360b0 */

void FUN_000360b0(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1d4)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360bc FUN_000360bc */

void FUN_000360bc(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1d8)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360c8 FUN_000360c8 */

void FUN_000360c8(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360d0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1dc)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360d4 FUN_000360d4 */

void FUN_000360d4(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360dc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1e0)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360e0 FUN_000360e0 */

void FUN_000360e0(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1e4)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360ec FUN_000360ec */

void FUN_000360ec(void)

{
                    /* WARNING: Could not recover jumptable at 0x000360f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1e8)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000360f8 FUN_000360f8 */

void FUN_000360f8(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036100. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1ec)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036104 FUN_00036104 */

void FUN_00036104(void)

{
                    /* WARNING: Could not recover jumptable at 0x0003610c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1f0)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036110 FUN_00036110 */

void FUN_00036110(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036118. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1f4)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003611c FUN_0003611c */

void FUN_0003611c(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036124. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1f8)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036128 FUN_00036128 */

void FUN_00036128(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036130. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c1fc)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036134 FUN_00036134 */

void FUN_00036134(void)

{
                    /* WARNING: Could not recover jumptable at 0x0003613c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c200)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036140 FUN_00036140 */

void FUN_00036140(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036148. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c204)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003614c FUN_0003614c */

void FUN_0003614c(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036154. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c210)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036158 FUN_00036158 */

void FUN_00036158(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036160. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c214)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036164 FUN_00036164 */

void FUN_00036164(void)

{
                    /* WARNING: Could not recover jumptable at 0x0003616c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c218)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036170 FUN_00036170 */

void FUN_00036170(void)

{
                    /* WARNING: Could not recover jumptable at 0x00036178. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_0003c220)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00039fe0 _DT_INIT */

void _DT_INIT(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
                    /* WARNING: Could not recover jumptable at 0x0002992c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_000298d0 + DAT_000298d0))
            (param_1,param_2,param_3,param_4,param_1,param_2,param_3,param_4);
  return;
}

