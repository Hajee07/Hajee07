/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bd730 FUN_001bd730 */

undefined4 FUN_001bd730(undefined4 param_1,int param_2)

{
  undefined4 *puVar1;
  float fVar2;
  float fVar3;
  ushort uVar4;
  int iVar5;
  uint uVar6;
  
  iVar5 = *(int *)(param_2 + 8);
  uVar6 = (uint)(**(ushort **)(param_2 + 0x28) >> 8);
  uVar4 = (*(ushort **)(param_2 + 0x28))[1];
  *(undefined4 *)(iVar5 + uVar6 * 0xc) = 0x10;
  fVar2 = *(float *)(iVar5 + 4 + (uVar4 & 0xff) * 0xc);
  fVar3 = *(float *)(iVar5 + 4 + (uint)(uVar4 >> 8) * 0xc);
  if ((fVar2 == fVar3) && (!NAN(fVar2) && !NAN(fVar3))) {
    *(undefined4 *)(iVar5 + 4 + uVar6 * 0xc) = 0;
    return 0;
  }
  puVar1 = (undefined4 *)(iVar5 + 4 + uVar6 * 0xc);
  if (fVar2 < fVar3) {
    *puVar1 = 0xffffffff;
    return 0;
  }
  *puVar1 = 1;
  return 0;
}

