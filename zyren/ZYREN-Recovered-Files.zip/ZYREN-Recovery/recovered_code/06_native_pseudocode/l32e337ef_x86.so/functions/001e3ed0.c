/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e3ed0 FUN_001e3ed0 */

int FUN_001e3ed0(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 + 0x74;
  if (param_1 == 0) {
    iVar1 = 0;
  }
  return iVar1;
}

