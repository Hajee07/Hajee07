/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0013ecb8 FUN_0013ecb8 */

undefined8 __regparm3 FUN_0013ecb8(undefined4 param_1)

{
  undefined4 unaff_retaddr;
  
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
                    /* WARNING: Treating indirect jump as return */
  return CONCAT44(unaff_retaddr,param_1);
}

