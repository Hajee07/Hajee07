/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b59d0 FUN_001b59d0 */

void FUN_001b59d0(int param_1)

{
  FUN_001d0cb0(param_1 + -8);
  return;
}

