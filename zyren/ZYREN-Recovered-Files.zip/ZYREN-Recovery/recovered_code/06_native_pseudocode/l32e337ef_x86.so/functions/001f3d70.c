/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f3d70 FUN_001f3d70 */

void __regparm3 FUN_001f3d70(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  uint uVar2;
  
  pcVar1 = (code *)thunk_FUN_001f3ee5(param_2,param_3);
  uVar2 = (*pcVar1)();
  if (0xfffff000 < uVar2) {
    thunk_FUN_001f3ec5(-uVar2);
  }
  return;
}

