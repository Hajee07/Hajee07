/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bde30 FUN_001bde30 */

undefined4 FUN_001bde30(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  ushort uVar4;
  int iVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined4 uVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  uint local_94;
  undefined local_74 [100];
  
  iVar12 = *(int *)(param_2 + 8);
  uVar13 = (uint)(**(ushort **)(param_2 + 0x28) >> 8);
  uVar4 = (*(ushort **)(param_2 + 0x28))[1];
  uVar7 = uVar4 & 0xff;
  uVar14 = (uint)(uVar4 >> 8);
  iVar8 = *(int *)(iVar12 + uVar14 * 0xc);
  local_94 = 0;
  iVar5 = *(int *)(iVar12 + uVar13 * 0xc);
  iVar10 = *(int *)(iVar12 + 4 + uVar13 * 0xc);
  switch(iVar8) {
  case 1:
  case 2:
    local_94 = (uint)*(char *)(iVar12 + 4 + uVar14 * 0xc);
    break;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    break;
  case 4:
    local_94 = (uint)*(ushort *)(iVar12 + 4 + uVar14 * 0xc);
    break;
  case 8:
    local_94 = (uint)*(short *)(iVar12 + 4 + uVar14 * 0xc);
    break;
  case 0x10:
switchD_001bdea0_caseD_10:
    local_94 = *(uint *)(iVar12 + 4 + uVar14 * 0xc);
    break;
  default:
    if (iVar8 == 0x1000) goto switchD_001bdea0_caseD_10;
  }
  iVar8 = *(int *)(iVar12 + 4 + uVar7 * 0xc);
  if ((iVar8 != 0) &&
     ((iVar8 = (**(code **)(*param_1 + 0x2ac))(param_1,iVar8), (int)local_94 < 0 ||
      (iVar8 <= (int)local_94)))) {
    FUN_0018b030(local_74,"Index %d out of bounds for length %d",local_94,iVar8);
    iVar10 = FUN_001b7690();
    (**(code **)(*param_1 + 0x38))(param_1,iVar10,local_74);
    iVar12 = *param_1;
    goto LAB_001be27a;
  }
  piVar3 = (int *)(iVar12 + uVar13 * 0xc);
  if (*(int *)(param_2 + 0x2c) - 0x44U < 7) {
    puVar1 = (undefined4 *)(iVar12 + 4 + uVar13 * 0xc);
    puVar2 = (undefined4 *)(iVar12 + 4 + uVar7 * 0xc);
    switch(*(int *)(param_2 + 0x2c)) {
    default:
      iVar8 = (**(code **)(*param_1 + 0x7c))(param_1,*puVar2);
      if (iVar8 == 0) {
        iVar9 = 0;
      }
      else {
        iVar9 = FUN_001bbe80();
        (**(code **)(*param_1 + 0x5c))(param_1,iVar8);
      }
      switch(*(undefined *)(iVar9 + 1)) {
      case 0x42:
        *piVar3 = 2;
        (**(code **)(*param_1 + 800))(param_1,*puVar2,local_94,1,puVar1);
        break;
      case 0x43:
        *piVar3 = 4;
        (**(code **)(*param_1 + 0x324))(param_1,*puVar2,local_94,1,puVar1);
        break;
      case 0x46:
        *piVar3 = 0x40;
        (**(code **)(*param_1 + 0x334))(param_1,*puVar2,local_94,1,puVar1);
        break;
      case 0x49:
        *piVar3 = 0x10;
        (**(code **)(*param_1 + 0x32c))(param_1,*puVar2,local_94,1,puVar1);
        break;
      case 0x53:
        *piVar3 = 8;
        (**(code **)(*param_1 + 0x328))(param_1,*puVar2,local_94,1,puVar1);
        break;
      case 0x5a:
        *piVar3 = 1;
        (**(code **)(*param_1 + 0x31c))(param_1,*puVar2,local_94,1,puVar1);
      }
      break;
    case 0x45:
      iVar8 = (**(code **)(*param_1 + 0x7c))(param_1,*puVar2);
      if (iVar8 == 0) {
        iVar9 = 0;
      }
      else {
        iVar9 = FUN_001bbe80();
        (**(code **)(*param_1 + 0x5c))(param_1,iVar8);
      }
      iVar8 = FUN_0018b060(iVar9,&DAT_0021894b);
      if (iVar8 == 0) {
        *piVar3 = 0x20;
        (**(code **)(*param_1 + 0x330))(param_1,*puVar2,local_94,1,puVar1);
      }
      else {
        iVar8 = FUN_0018b060(iVar9,&DAT_0021894e);
        if (iVar8 == 0) {
          *piVar3 = 0x80;
          (**(code **)(*param_1 + 0x338))(param_1,*puVar2,local_94,1,puVar1);
        }
      }
      break;
    case 0x46:
      *piVar3 = 0x100;
      uVar11 = (**(code **)(*param_1 + 0x2b4))(param_1,*puVar2,local_94);
      *puVar1 = uVar11;
      goto LAB_001be17a;
    }
    FUN_0018ae20(iVar9);
  }
LAB_001be17a:
  cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
  if (cVar6 != '\0') {
    return 0;
  }
  iVar8 = *piVar3;
  switch(iVar8) {
  case 0:
switchD_001be1af_caseD_0:
    *(undefined4 *)(iVar12 + 8 + uVar13 * 0xc) = 0;
    *(undefined4 *)(iVar12 + 4 + uVar13 * 0xc) = 0;
    break;
  case 1:
  case 2:
    *(uint *)(iVar12 + 4 + uVar13 * 0xc) = (uint)*(byte *)(iVar12 + 4 + uVar13 * 0xc);
    *(undefined4 *)(iVar12 + 8 + uVar13 * 0xc) = 0;
    break;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2c:
  case 0x2d:
  case 0x2e:
  case 0x2f:
  case 0x30:
  case 0x31:
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x35:
  case 0x36:
  case 0x37:
  case 0x38:
  case 0x39:
  case 0x3a:
  case 0x3b:
  case 0x3c:
  case 0x3d:
  case 0x3e:
  case 0x3f:
    break;
  case 4:
  case 8:
    *(uint *)(iVar12 + 4 + uVar13 * 0xc) = (uint)*(ushort *)(iVar12 + 4 + uVar13 * 0xc);
    *(undefined4 *)(iVar12 + 8 + uVar13 * 0xc) = 0;
    break;
  case 0x10:
  case 0x40:
switchD_001be1af_caseD_10:
    *(undefined4 *)(iVar12 + 8 + uVar13 * 0xc) = 0;
    break;
  default:
    if (iVar8 < 0x800) {
      if (iVar8 == 0x100) goto switchD_001be1af_caseD_10;
      if ((iVar8 == 0x200) || (iVar8 == 0x400)) goto switchD_001be1af_caseD_0;
    }
    else {
      if (iVar8 == 0x800) goto switchD_001be1af_caseD_0;
      if ((iVar8 == 0x1000) || (iVar8 == 0x4000)) goto switchD_001be1af_caseD_10;
    }
  }
  if ((iVar5 != 0x4000) && (iVar5 != 0x100)) {
    return 0;
  }
  if (iVar10 == 0) {
    return 0;
  }
  iVar12 = *param_1;
LAB_001be27a:
  (**(code **)(iVar12 + 0x5c))(param_1,iVar10);
  return 0;
}

