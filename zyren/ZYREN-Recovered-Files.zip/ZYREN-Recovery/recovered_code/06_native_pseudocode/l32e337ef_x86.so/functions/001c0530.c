/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c0530 FUN_001c0530 */

undefined4 FUN_001c0530(int *param_1,int *param_2)

{
  int *piVar1;
  double *pdVar2;
  int iVar3;
  int iVar4;
  undefined uVar5;
  char cVar6;
  undefined2 uVar7;
  int iVar8;
  undefined *puVar9;
  int iVar10;
  float fVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  char *pcVar17;
  undefined *puVar18;
  char *pcVar19;
  uint uVar20;
  char *pcVar21;
  longdouble lVar22;
  undefined8 uVar23;
  undefined local_3c [16];
  undefined local_2c [16];
  undefined4 local_1c;
  undefined4 local_18;
  
  iVar14 = param_2[2];
  iVar15 = param_2[10];
  uVar20 = (uint)*(ushort *)(iVar15 + 2);
  iVar8 = FUN_001bfd90(uVar20);
  if (iVar8 == 0) {
    return 0;
  }
  local_2c = ZEXT816(0);
  local_3c = ZEXT816(0);
  local_18 = 0;
  local_1c = 0;
  iVar10 = *param_2;
  puVar9 = (undefined *)
           (*(int *)(*(int *)(iVar10 + 8) +
                    *(int *)(*(int *)(iVar10 + 0x18) +
                            (uint)*(ushort *)(*(int *)(iVar10 + 0x14) + 2 + uVar20 * 8) * 0xc) * 4)
            + 1 + *(int *)(iVar10 + 0x2c));
  do {
    puVar18 = puVar9;
    puVar9 = puVar18 + 1;
  } while ((char)puVar18[-1] < '\0');
  puVar9 = (undefined *)FUN_001bcd50(iVar15,1,puVar18 + 1);
  uVar16 = *(ushort *)(iVar15 + 4) & 0xf;
  if (puVar9 != local_3c) {
    uVar16 = (uint)*(ushort *)(iVar15 + 4);
  }
  iVar15 = *(int *)(iVar14 + 4 + uVar16 * 0xc);
  iVar10 = *param_2;
  if (iVar15 == 0) {
    uVar12 = FUN_001c01b0();
    uVar13 = FUN_0018af40("Cannot invoke \"");
    iVar14 = FUN_0018af10(uVar13);
    iVar15 = FUN_0018af10(uVar12);
    uVar13 = FUN_0018b200(uVar13,iVar14 + 1 + iVar15);
    FUN_0018b210(uVar13,uVar12);
    iVar14 = FUN_0018af10(uVar13);
    iVar14 = FUN_0018b200(uVar13,iVar14 + 0xb);
    iVar15 = FUN_0018af10(iVar14);
    *(undefined4 *)(iVar14 + iVar15) = 0x65622022;
    *(undefined4 *)(iVar14 + 4 + iVar15) = 0x73756163;
    *(undefined4 *)(iVar14 + 7 + iVar15) = 0x206573;
    iVar15 = FUN_0018af10(iVar14);
    iVar14 = FUN_0018b200(iVar14,iVar15 + 4);
    iVar15 = FUN_0018af10(iVar14);
    *(undefined4 *)(iVar14 + iVar15) = 0x787878;
    iVar15 = FUN_0018af10(iVar14);
    iVar14 = FUN_0018b200(iVar14,iVar15 + 9);
    iVar15 = FUN_0018af10(iVar14);
    *(undefined4 *)(iVar14 + iVar15) = 0x20736920;
    *(undefined4 *)(iVar14 + 4 + iVar15) = 0x6c6c756e;
    *(undefined *)(iVar14 + 8 + iVar15) = 0;
    uVar13 = FUN_001b7690();
    (**(code **)(*param_1 + 0x38))(param_1,uVar13,iVar14);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar13);
    FUN_0018ae20(iVar14);
    FUN_0018ae20(uVar12);
joined_r0x001c081d:
    if (puVar9 == local_3c) {
      return 0;
    }
    goto LAB_001c0b34;
  }
  pcVar21 = (char *)(*(int *)(iVar10 + 0x2c) +
                    *(int *)(*(int *)(iVar10 + 8) +
                            *(int *)(*(int *)(iVar10 + 0xc) +
                                    (uint)*(ushort *)(*(int *)(iVar10 + 0x14) + uVar20 * 8) * 4) * 4
                            ));
  do {
    cVar6 = *pcVar21;
    pcVar21 = pcVar21 + 1;
  } while (cVar6 < '\0');
  iVar10 = FUN_001b7690();
  if (iVar10 == 0) {
    FUN_001b7f40("dex-vmp: fail to find class: %s\n",pcVar21);
    iVar14 = *param_2;
    uVar20 = param_2[8] & 0xffff;
    iVar15 = *(int *)(iVar14 + 8);
    iVar8 = *(int *)(iVar14 + 0x14);
    iVar10 = *(int *)(iVar14 + 0x2c);
    pcVar21 = (char *)(*(int *)(iVar15 + *(int *)(iVar8 + 4 + uVar20 * 8) * 4) + iVar10);
    do {
      cVar6 = *pcVar21;
      pcVar21 = pcVar21 + 1;
    } while (cVar6 < '\0');
    pcVar19 = (char *)(*(int *)(iVar15 + *(int *)(*(int *)(iVar14 + 0x18) +
                                                 (uint)*(ushort *)(iVar8 + 2 + uVar20 * 8) * 0xc) *
                                         4) + iVar10);
    do {
      cVar6 = *pcVar19;
      pcVar19 = pcVar19 + 1;
    } while (cVar6 < '\0');
    pcVar17 = (char *)(iVar10 + *(int *)(iVar15 + *(int *)(*(int *)(iVar14 + 0xc) +
                                                          (uint)*(ushort *)(iVar8 + uVar20 * 8) * 4)
                                                  * 4));
    do {
      cVar6 = *pcVar17;
      pcVar17 = pcVar17 + 1;
    } while (cVar6 < '\0');
    FUN_001b7f40("dex-vmp: error in %08X. %s(%s) <- %s at 0x%X\n",param_2[8],pcVar21,pcVar19,pcVar17
                 ,(param_2[10] - param_2[1]) + -0x10);
    goto joined_r0x001c081d;
  }
  uVar20 = (uint)*(ushort *)param_2[1];
  piVar1 = (int *)(iVar14 + uVar20 * 0xc);
  iVar3 = *(int *)(iVar14 + uVar20 * 0xc);
  iVar4 = *(int *)(iVar14 + 4 + uVar20 * 0xc);
  pdVar2 = (double *)(iVar14 + 4 + uVar20 * 0xc);
  switch(*puVar18) {
  case 0x42:
    *piVar1 = 2;
    uVar5 = (**(code **)(*param_1 + 0x120))(param_1,iVar15,iVar10,iVar8,puVar9);
    goto LAB_001c0ad5;
  case 0x43:
    *piVar1 = 4;
    uVar7 = (**(code **)(*param_1 + 300))(param_1,iVar15,iVar10,iVar8,puVar9);
    goto LAB_001c0a74;
  case 0x44:
    *piVar1 = 0x80;
    lVar22 = (longdouble)(**(code **)(*param_1 + 0x168))(param_1,iVar15,iVar10,iVar8,puVar9);
    *pdVar2 = (double)lVar22;
    break;
  case 0x46:
    *piVar1 = 0x40;
    lVar22 = (longdouble)(**(code **)(*param_1 + 0x15c))(param_1,iVar15,iVar10,iVar8,puVar9);
    *(float *)pdVar2 = (float)lVar22;
    break;
  case 0x49:
    *piVar1 = 0x10;
    fVar11 = (float)(**(code **)(*param_1 + 0x144))(param_1,iVar15,iVar10,iVar8,puVar9);
    goto LAB_001c0a02;
  case 0x4a:
    *piVar1 = 0x20;
    uVar23 = (**(code **)(*param_1 + 0x150))(param_1,iVar15,iVar10,iVar8,puVar9);
    *(int *)(iVar14 + 8 + uVar20 * 0xc) = (int)((ulonglong)uVar23 >> 0x20);
    *(int *)(iVar14 + 4 + uVar20 * 0xc) = (int)uVar23;
    break;
  case 0x4c:
  case 0x5b:
    *piVar1 = 0x100;
    fVar11 = (float)(**(code **)(*param_1 + 0x108))(param_1,iVar15,iVar10,iVar8,puVar9);
LAB_001c0a02:
    *(float *)pdVar2 = fVar11;
    break;
  case 0x53:
    *piVar1 = 8;
    uVar7 = (**(code **)(*param_1 + 0x138))(param_1,iVar15,iVar10,iVar8,puVar9);
LAB_001c0a74:
    *(undefined2 *)pdVar2 = uVar7;
    break;
  case 0x56:
    *piVar1 = 0;
    (**(code **)(*param_1 + 0x174))(param_1,iVar15,iVar10,iVar8,puVar9);
    break;
  case 0x5a:
    *piVar1 = 1;
    uVar5 = (**(code **)(*param_1 + 0x114))(param_1,iVar15,iVar10,iVar8,puVar9);
LAB_001c0ad5:
    *(undefined *)pdVar2 = uVar5;
  }
  cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
  if (cVar6 != '\0') {
    *piVar1 = 0;
    *(undefined4 *)(iVar14 + 8 + uVar20 * 0xc) = 0;
    *(undefined4 *)(iVar14 + 4 + uVar20 * 0xc) = 0;
    goto switchD_001c0b8f_caseD_3;
  }
  if (((iVar3 == 0x4000) || (iVar3 == 0x100)) && (iVar4 != 0)) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
  }
  iVar15 = *piVar1;
  switch(iVar15) {
  case 0:
switchD_001c0b8f_caseD_0:
    *(undefined4 *)(iVar14 + 8 + uVar20 * 0xc) = 0;
    *(undefined4 *)(iVar14 + 4 + uVar20 * 0xc) = 0;
    break;
  case 1:
  case 2:
    uVar16 = (uint)*(byte *)(iVar14 + 4 + uVar20 * 0xc);
    goto LAB_001c0c0d;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2c:
  case 0x2d:
  case 0x2e:
  case 0x2f:
  case 0x30:
  case 0x31:
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x35:
  case 0x36:
  case 0x37:
  case 0x38:
  case 0x39:
  case 0x3a:
  case 0x3b:
  case 0x3c:
  case 0x3d:
  case 0x3e:
  case 0x3f:
    break;
  case 4:
  case 8:
    uVar16 = (uint)*(ushort *)(iVar14 + 4 + uVar20 * 0xc);
LAB_001c0c0d:
    *(uint *)(iVar14 + 4 + uVar20 * 0xc) = uVar16;
    *(undefined4 *)(iVar14 + 8 + uVar20 * 0xc) = 0;
    break;
  case 0x10:
  case 0x40:
switchD_001c0b8f_caseD_10:
    *(undefined4 *)(iVar14 + 8 + uVar20 * 0xc) = 0;
    break;
  default:
    if (iVar15 < 0x800) {
      if (iVar15 == 0x100) goto switchD_001c0b8f_caseD_10;
      if ((iVar15 == 0x200) || (iVar15 == 0x400)) goto switchD_001c0b8f_caseD_0;
    }
    else {
      if (iVar15 == 0x800) goto switchD_001c0b8f_caseD_0;
      if ((iVar15 == 0x1000) || (iVar15 == 0x4000)) goto switchD_001c0b8f_caseD_10;
    }
  }
switchD_001c0b8f_caseD_3:
  (**(code **)(*param_1 + 0x5c))(param_1,iVar10);
  if (puVar9 != local_3c) {
LAB_001c0b34:
    FUN_0018ae20(puVar9);
  }
  return 0;
}

