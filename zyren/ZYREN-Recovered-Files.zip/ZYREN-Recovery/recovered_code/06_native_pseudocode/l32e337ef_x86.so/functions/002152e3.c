/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002152e3 FUN_002152e3 */

int FUN_002152e3(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  char *pcVar4;
  char local_150;
  undefined4 local_14c [19];
  int local_100;
  undefined4 local_ec;
  undefined4 local_e4;
  undefined4 local_cc [37];
  undefined4 local_38;
  undefined2 local_34;
  int local_2c;
  undefined2 local_18;
  undefined4 local_10;
  
  puVar2 = local_14c;
  for (iVar3 = 0x20; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  puVar2 = local_cc;
  local_ec = 0x40000000;
  local_100 = param_1 + 1;
  iVar1 = FUN_00214da1();
  iVar3 = 0;
  if ((iVar1 == 0) && (local_2c != 2)) {
    pcVar4 = (char *)(param_2 + 0x5c);
    do {
      local_150 = (char)puVar2[1];
      *pcVar4 = local_150;
      if ((local_150 == '\x01') || (local_150 == '\x02')) {
        *(undefined4 *)(param_2 * -3 + -0x160 + (int)pcVar4 * 4) = *puVar2;
      }
      else {
        *(undefined4 *)(param_2 * -3 + -0x160 + (int)pcVar4 * 4) = 0;
      }
      pcVar4 = pcVar4 + 1;
      puVar2 = puVar2 + 2;
    } while (puVar2 != local_cc + 0x24);
    *(undefined4 *)(param_2 + 8) = local_38;
    *(undefined2 *)(param_2 + 0x58) = local_34;
    *(undefined2 *)(param_2 + 0x5a) = local_18;
    *(undefined4 *)(param_2 + 0xc) = local_e4;
    *(undefined4 *)(param_2 + 4) = local_10;
    iVar3 = param_2;
  }
  return iVar3;
}

