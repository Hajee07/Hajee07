/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bf490 FUN_001bf490 */

undefined4 FUN_001bf490(int *param_1,int *param_2)

{
  char cVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  char *pcVar8;
  uint uVar9;
  char *pcVar10;
  char *pcVar11;
  uint uVar12;
  int iVar13;
  
  iVar3 = *param_2;
  uVar9 = (uint)((ushort *)param_2[10])[1];
  iVar4 = *(int *)(iVar3 + 0x10);
  pcVar11 = (char *)(*(int *)(iVar3 + 0x2c) +
                    *(int *)(*(int *)(iVar3 + 8) +
                            *(int *)(*(int *)(iVar3 + 0xc) +
                                    (uint)*(ushort *)(iVar4 + uVar9 * 8) * 4) * 4));
  uVar2 = *(ushort *)param_2[10];
  iVar3 = param_2[2];
  do {
    cVar1 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar1 < '\0');
  iVar6 = FUN_001b7690();
  if (iVar6 == 0) {
    FUN_001b7f40();
    iVar3 = *param_2;
    uVar9 = param_2[8] & 0xffff;
    iVar4 = *(int *)(iVar3 + 8);
    iVar6 = *(int *)(iVar3 + 0x14);
    iVar13 = *(int *)(iVar3 + 0x2c);
    pcVar11 = (char *)(*(int *)(iVar4 + *(int *)(iVar6 + 4 + uVar9 * 8) * 4) + iVar13);
    do {
      cVar1 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar1 < '\0');
    pcVar8 = (char *)(*(int *)(iVar4 + *(int *)(*(int *)(iVar3 + 0x18) +
                                               (uint)*(ushort *)(iVar6 + 2 + uVar9 * 8) * 0xc) * 4)
                     + iVar13);
    do {
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 < '\0');
    pcVar10 = (char *)(iVar13 + *(int *)(iVar4 + *(int *)(*(int *)(iVar3 + 0xc) +
                                                         (uint)*(ushort *)(iVar6 + uVar9 * 8) * 4) *
                                                 4));
    do {
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar1 < '\0');
    FUN_001b7f40("dex-vmp: error in %08X. %s(%s) <- %s at 0x%X\n",param_2[8],pcVar11,pcVar8,pcVar10,
                 (param_2[10] - param_2[1]) + -0x10);
  }
  else {
    uVar12 = (uint)(uVar2 >> 8);
    iVar13 = *param_2;
    pcVar11 = (char *)(*(int *)(*(int *)(iVar13 + 8) + *(int *)(iVar4 + 4 + uVar9 * 8) * 4) +
                      *(int *)(iVar13 + 0x2c));
    do {
      cVar1 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar1 < '\0');
    pcVar8 = (char *)(*(int *)(iVar13 + 0x2c) +
                     *(int *)(*(int *)(iVar13 + 8) +
                             *(int *)(*(int *)(iVar13 + 0xc) +
                                     (uint)*(ushort *)(iVar4 + 2 + uVar9 * 8) * 4) * 4));
    do {
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 < '\0');
    iVar13 = iVar6;
    iVar7 = (**(code **)(*param_1 + 0x240))();
    if (iVar7 != 0) {
      switch(param_2[0xb]) {
      case 0x67:
        iVar3 = *param_2;
        pcVar11 = (char *)(*(int *)(iVar3 + 0x2c) +
                          *(int *)(*(int *)(iVar3 + 8) +
                                  *(int *)(*(int *)(iVar3 + 0xc) +
                                          (uint)*(ushort *)(iVar4 + 2 + uVar9 * 8) * 4) * 4));
        do {
          cVar1 = *pcVar11;
          pcVar11 = pcVar11 + 1;
        } while (cVar1 < '\0');
        if (*pcVar11 == 'F') {
          (**(code **)(*param_1 + 0x284))();
        }
        else if (*pcVar11 == 'I') {
          (**(code **)(*param_1 + 0x27c))();
        }
        break;
      case 0x68:
        iVar5 = *param_2;
        pcVar10 = (char *)(*(int *)(iVar5 + 0x2c) +
                          *(int *)(*(int *)(iVar5 + 8) +
                                  *(int *)(*(int *)(iVar5 + 0xc) +
                                          (uint)*(ushort *)(iVar4 + 2 + uVar9 * 8) * 4) * 4));
        do {
          cVar1 = *pcVar10;
          pcVar10 = pcVar10 + 1;
        } while (cVar1 < '\0');
        if (*pcVar10 == 'D') {
          (**(code **)(*param_1 + 0x288))
                    (param_1,iVar6,iVar7,*(undefined8 *)(iVar3 + 4 + uVar12 * 0xc),iVar13,pcVar11,
                     pcVar8);
        }
        else if (*pcVar10 == 'J') {
          (**(code **)(*param_1 + 0x280))
                    (param_1,iVar6,iVar7,*(undefined4 *)(iVar3 + 4 + uVar12 * 0xc),
                     *(undefined4 *)(iVar3 + 8 + uVar12 * 0xc));
        }
        break;
      case 0x69:
        (**(code **)(*param_1 + 0x268))();
        break;
      case 0x6a:
        (**(code **)(*param_1 + 0x26c))();
        break;
      case 0x6b:
        (**(code **)(*param_1 + 0x270))();
        break;
      case 0x6c:
        (**(code **)(*param_1 + 0x274))();
        break;
      case 0x6d:
        (**(code **)(*param_1 + 0x278))();
      }
    }
    (**(code **)(*param_1 + 0x5c))();
  }
  return 0;
}

