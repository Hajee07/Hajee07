/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c4a30 FUN_001c4a30 */

undefined4 FUN_001c4a30(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 != (undefined4 *)0x0) {
    uVar1 = param_1[0x170c];
    uVar2 = param_1[0x170d];
    uVar3 = param_1[0x170e];
    FUN_001cc0e0(*param_1,uVar1,uVar2,uVar3);
    FUN_001cc0e0(param_1,uVar1,uVar2,uVar3);
  }
  return 0;
}

