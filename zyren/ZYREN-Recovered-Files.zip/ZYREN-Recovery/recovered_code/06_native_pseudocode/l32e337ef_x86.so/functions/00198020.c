/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00198020 FUN_00198020 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00198020(int **param_1,int **param_2)

{
  undefined4 *puVar1;
  undefined2 *puVar2;
  char cVar3;
  char cVar4;
  int iVar5;
  char *pcVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  uint uVar15;
  undefined4 *puVar16;
  int **ppiVar17;
  int **ppiVar18;
  int *piVar19;
  int *piVar20;
  int **ppiVar21;
  int *piVar22;
  undefined4 uVar23;
  int **ppiVar24;
  uint uVar25;
  int **local_404;
  int local_3fc;
  undefined local_3ec [5];
  undefined auStack_3e7 [4];
  undefined2 uStack_3e3;
  uint uStack_3e0;
  undefined local_3dc [4];
  undefined auStack_3d8 [8];
  undefined4 uStack_3d0;
  undefined local_3cc [8];
  undefined8 uStack_3c4;
  undefined local_3bc [4];
  int aiStack_3b8 [3];
  undefined local_3ac [16];
  undefined4 local_39c;
  undefined4 local_398;
  uint local_38c;
  undefined *local_388;
  undefined local_384 [884];
  
  if (param_2 == (int **)0x0) {
    return 0;
  }
  ppiVar17 = (int **)*param_1;
  if (ppiVar17 == (int **)0x0) {
    return 0;
  }
  local_38c = FUN_0018ae70(0x27);
  if (DAT_0027290c == '\0') {
    FUN_0018b930(&DAT_00272910);
    FUN_0018ae30(&DAT_00272914,0,0x400);
    DAT_0027290c = '\x01';
  }
  local_388 = &DAT_00272910;
  FUN_0018b970(&DAT_00272910);
  cVar3 = *(char *)ppiVar17;
  while( true ) {
    while( true ) {
      while (cVar3 == -0x17) {
        ppiVar17 = (int **)((int)ppiVar17 + *(int *)((int)ppiVar17 + 1) + 5);
        cVar3 = *(char *)ppiVar17;
      }
      if (cVar3 != -0x15) break;
      ppiVar17 = (int **)((int)ppiVar17 + *(char *)((int)ppiVar17 + 1) + 2);
      cVar3 = *(char *)ppiVar17;
    }
    if ((cVar3 != -1) || (*(char *)((int)ppiVar17 + 1) != '%')) break;
    ppiVar17 = (int **)**(int ***)((int)ppiVar17 + 2);
    cVar3 = *(char *)ppiVar17;
  }
  do {
    cVar4 = *(char *)param_2;
    while( true ) {
      while (cVar4 == -0x17) {
        param_2 = (int **)((int)param_2 + *(int *)((int)param_2 + 1) + 5);
        cVar4 = *(char *)param_2;
      }
      if (cVar4 == -0x15) break;
      if ((cVar4 != -1) || (*(char *)((int)param_2 + 1) != '%')) {
        if ((cVar3 == -0xd) &&
           (((*(char *)((int)ppiVar17 + 1) == '\x0f' && (*(char *)((int)ppiVar17 + 2) == '\x1e')) &&
            (*(char *)((int)ppiVar17 + 3) == -6)))) {
          ppiVar17 = ppiVar17 + 1;
        }
        if (((cVar4 == -0xd) && (*(char *)((int)param_2 + 1) == '\x0f')) &&
           ((*(char *)((int)param_2 + 2) == '\x1e' && (*(char *)((int)param_2 + 3) == -6)))) {
          param_2 = param_2 + 1;
        }
        local_3ac = ZEXT816(0);
        _local_3bc = ZEXT816(0);
        _local_3cc = ZEXT816(0);
        _local_3dc = ZEXT816(0);
        _local_3ec = ZEXT816(0);
        local_398 = 0;
        local_39c = 0;
        iVar14 = FUN_0018ba00(local_384,1);
        if (iVar14 == 0) goto LAB_0019867a;
        piVar22 = (int *)0x0;
        ppiVar24 = ppiVar17;
        goto LAB_001981fb;
      }
      param_2 = (int **)**(int ***)((int)param_2 + 2);
      cVar4 = *(char *)param_2;
    }
    param_2 = (int **)((int)param_2 + *(char *)((int)param_2 + 1) + 2);
  } while( true );
LAB_001981fb:
  do {
    iVar14 = FUN_0018bb10(local_384,ppiVar24,0,ppiVar24,0x2e);
    if ((iVar14 == 0) ||
       ((uVar15 = *(int *)(iVar14 + 0x118) - 0x101, uVar15 < 5 &&
        ((0x19U >> (uVar15 & 0x1f) & 1) != 0)))) break;
    iVar5 = *(int *)(iVar14 + 0x124);
    FUN_0018ae80(local_3ec + (int)local_3dc,ppiVar24,iVar5);
    iVar7 = (int)local_3dc;
    if (*(int *)(iVar14 + 0x118) == 0x103) {
      pcVar6 = *(char **)(iVar14 + 0x11c);
      if (*pcVar6 == -0x18) {
        iVar5 = *(int *)(pcVar6 + 1);
        if ((((pcVar6[iVar5 + 5] != -0x75) || (pcVar6[iVar5 + 7] != '$')) ||
            (pcVar6[iVar5 + 8] != -0x3d)) || ((pcVar6[5] != -0x7f || ((pcVar6[6] & 0xf0U) != 0xc0)))
           ) {
          *(undefined2 *)((int)&uStack_3e3 + (int)local_3dc) = *(undefined2 *)((int)ppiVar24 + 9);
          *(undefined4 *)(auStack_3e7 + iVar7) = *(undefined4 *)((int)ppiVar24 + 5);
          if ((uint)local_3cc._4_4_ < 4) {
            *(int *)(local_3bc + local_3cc._4_4_ * 0xc + -8) = (int)piVar22 + 1;
            iVar5 = *(int *)(*(int *)(iVar14 + 0x11c) + 1);
            *(int *)(local_3bc + local_3cc._4_4_ * 0xc + -4) = iVar5;
            *(int *)(local_3bc + local_3cc._4_4_ * 0xc) = iVar5 >> 0x1f;
            local_3cc._4_4_ = local_3cc._4_4_ + 1;
          }
          local_3dc = (undefined  [4])((int)local_3dc + 5);
          iVar14 = *(int *)(iVar14 + 0x124);
          goto joined_r0x0019839a;
        }
        *(undefined2 *)((int)&uStack_3e3 + (int)local_3dc) = *(undefined2 *)((int)ppiVar24 + 9);
        *(undefined4 *)(auStack_3e7 + iVar7) = *(undefined4 *)((int)ppiVar24 + 5);
        if ((uint)local_3cc._4_4_ < 3) {
          *(int *)(local_3bc + local_3cc._4_4_ * 0xc + -8) = (int)piVar22 + 1;
          iVar5 = *(int *)(iVar14 + 0x11c);
          iVar7 = *(int *)(iVar5 + 1);
          *(int *)(local_3bc + local_3cc._4_4_ * 0xc + -4) = iVar7;
          *(int *)(local_3bc + local_3cc._4_4_ * 0xc) = iVar7 >> 0x1f;
          *(int *)(local_3bc + local_3cc._4_4_ * 0xc + 4) = (int)piVar22 + 7;
          iVar5 = *(int *)(iVar5 + 7);
          aiStack_3b8[local_3cc._4_4_ * 3 + 1] = iVar5;
          *(int *)(local_3ac + local_3cc._4_4_ * 0xc + -4) = iVar5 >> 0x1f;
          local_3cc._4_4_ = local_3cc._4_4_ + 2;
        }
        local_3dc = (undefined  [4])((int)local_3dc + 0xb);
      }
      else {
        uVar15 = local_3cc._4_4_;
        if ((uint)local_3cc._4_4_ < 4) {
          uVar23 = *(undefined4 *)(pcVar6 + 1);
          *(int *)(local_3bc + local_3cc._4_4_ * 0xc + -8) = (int)piVar22 + 1;
          *(undefined4 *)(local_3bc + local_3cc._4_4_ * 0xc + -4) = uVar23;
          *(undefined4 *)(local_3bc + local_3cc._4_4_ * 0xc) = 0;
          uVar25 = local_3cc._4_4_ + 1;
          local_3cc._4_4_ = uVar25;
          if (uVar25 < 4) {
            uVar23 = *(undefined4 *)(pcVar6 + 7);
            *(int *)(local_3bc + uVar25 * 0xc + -8) = (int)piVar22 + 7;
            *(undefined4 *)(local_3bc + uVar25 * 0xc + -4) = uVar23;
            *(undefined4 *)(local_3bc + uVar25 * 0xc) = 0;
            local_3cc._4_4_ = uVar15 + 2;
          }
        }
      }
      iVar14 = *(int *)(iVar14 + 0x124) + 6;
    }
    else {
      local_3dc = (undefined  [4])((int)local_3dc + iVar5);
      iVar14 = *(int *)(iVar14 + 0x124);
    }
joined_r0x0019839a:
    piVar22 = (int *)((int)piVar22 + iVar14);
    ppiVar24 = (int **)((int)ppiVar24 + iVar14);
  } while (piVar22 < (int *)0x5);
  FUN_0018ba80(local_384);
  uVar23 = 0;
  if ((piVar22 < (int *)0x5) || (0xff < DAT_00272d14)) goto LAB_00198889;
  uVar15 = FUN_0018ae70(0x27);
  local_3fc = 0x870;
  if ((int)(0x870 % (longlong)(int)uVar15) != 0) {
    local_3fc = ((int)(0x86f / (longlong)(int)uVar15) + 1) * uVar15;
  }
  ppiVar24 = (int **)(((uint)ppiVar17 / uVar15 + 1) * uVar15);
  if (DAT_00272d18 == (int **)0x0) {
LAB_001984b4:
    local_404 = (int **)FUN_0018ae90(ppiVar24,local_3fc,7,0x22,0xffffffff,0);
    if (local_404 != ppiVar24) {
      do {
        if (local_404 == (int **)0xffffffff) break;
        FUN_0018aea0(local_404,local_3fc);
        ppiVar24 = (int **)((int)ppiVar24 + uVar15);
        local_404 = (int **)FUN_0018ae90(ppiVar24,local_3fc,7,0x22,0xffffffff,0);
      } while (local_404 != ppiVar24);
    }
    DAT_00272d1c = DAT_00272d1c + 0x6c;
    DAT_00272d18 = local_404;
    if (local_404 != (int **)0xffffffff) goto LAB_00198529;
LAB_0019858f:
    puVar16 = (undefined4 *)FUN_0018aeb0();
    uVar23 = FUN_0018aec0(*puVar16);
    FUN_0018aed0("mmap err=%s\n",uVar23);
    local_3fc = 0;
  }
  else {
    uVar25 = (int)ppiVar24 - (int)DAT_00272d18;
    if (ppiVar24 < DAT_00272d18) {
      uVar25 = (int)DAT_00272d18 - (int)ppiVar24;
    }
    if (0x7ffeffff < uVar25) {
      DAT_00272d18 = (int **)0x0;
      DAT_00272d1c = 0;
      goto LAB_001984b4;
    }
    local_404 = (int **)((int)DAT_00272d18 + DAT_00272d1c);
    DAT_00272d1c = DAT_00272d1c + 0x6c;
    if (local_404 == (int **)0xffffffff) goto LAB_0019858f;
LAB_00198529:
    piVar19 = &DAT_00272914;
    iVar14 = 0x100;
    do {
      if (*piVar19 == 0) {
        *piVar19 = (int)local_404;
        DAT_00272d14 = DAT_00272d14 + 1;
        break;
      }
      piVar19 = piVar19 + 1;
      iVar14 = iVar14 + -1;
    } while (iVar14 != 0);
    if (local_404 == (int **)0x0) {
LAB_0019867a:
      uVar23 = 0;
      goto LAB_00198889;
    }
  }
  iVar14 = FUN_0018aee0(((uint)ppiVar17 / local_38c) * local_38c,
                        (((uint)((undefined *)((int)ppiVar17 + -1) + (int)piVar22) / local_38c -
                         (uint)ppiVar17 / local_38c) + 1) * local_38c,7);
  if (iVar14 == 0) {
    ppiVar24 = (int **)((int)ppiVar17 + (int)piVar22);
    if (piVar22 != (int *)0x0) {
      piVar19 = (int *)0x0;
      if (((int *)0x1f < piVar22) &&
         ((ppiVar24 <= local_404 + 0x13 ||
          ((int **)((int)(piVar22 + 0x13) + (int)local_404) <= ppiVar17)))) {
        piVar19 = (int *)((uint)piVar22 & 0xffffffe0);
        piVar20 = (int *)0x0;
        do {
          puVar16 = (undefined4 *)((int)ppiVar17 + (int)piVar20);
          uVar23 = puVar16[1];
          uVar8 = puVar16[2];
          uVar9 = puVar16[3];
          puVar1 = (undefined4 *)((int)(ppiVar17 + 4) + (int)piVar20);
          uVar10 = *puVar1;
          uVar11 = puVar1[1];
          uVar12 = puVar1[2];
          uVar13 = puVar1[3];
          puVar1 = (undefined4 *)((int)(local_404 + 0x13) + (int)piVar20);
          *puVar1 = *puVar16;
          puVar1[1] = uVar23;
          puVar1[2] = uVar8;
          puVar1[3] = uVar9;
          puVar16 = (undefined4 *)((int)(local_404 + 0x17) + (int)piVar20);
          *puVar16 = uVar10;
          puVar16[1] = uVar11;
          puVar16[2] = uVar12;
          puVar16[3] = uVar13;
          piVar20 = piVar20 + 8;
          if (piVar19 == piVar20) goto LAB_001986c4;
        } while( true );
      }
      do {
        *(undefined *)((int)(local_404 + 0x13) + (int)piVar19) =
             *(undefined *)((int)ppiVar17 + (int)piVar19);
        piVar19 = (int *)((int)piVar19 + 1);
LAB_001986c4:
      } while (piVar22 != piVar19);
    }
    ppiVar18 = local_404 + 0xb;
    if (local_3dc != (undefined  [4])0x0) {
      uVar15 = 0;
      if ((0x1f < (uint)local_3dc) &&
         ((local_3ec + (int)local_3dc <= ppiVar18 ||
          ((undefined *)((int)local_3dc + 0x2cU + (int)local_404) <= local_3ec)))) {
        uVar15 = (uint)local_3dc & 0xffffffe0;
        uVar25 = 0;
        do {
          uVar23 = *(undefined4 *)(local_3ec + uVar25 + 4);
          uVar8 = *(undefined4 *)(auStack_3e7 + uVar25 + 3);
          uVar9 = *(undefined4 *)(local_3dc + (uVar25 - 4));
          uVar10 = *(undefined4 *)(local_3dc + uVar25);
          uVar11 = *(undefined4 *)(auStack_3d8 + uVar25);
          uVar12 = *(undefined4 *)(auStack_3d8 + uVar25 + 4);
          uVar13 = *(undefined4 *)(local_3cc + (uVar25 - 4));
          puVar16 = (undefined4 *)((int)local_404 + uVar25 + 0x2c);
          *puVar16 = *(undefined4 *)(local_3ec + uVar25);
          puVar16[1] = uVar23;
          puVar16[2] = uVar8;
          puVar16[3] = uVar9;
          puVar16 = (undefined4 *)((int)local_404 + uVar25 + 0x3c);
          *puVar16 = uVar10;
          puVar16[1] = uVar11;
          puVar16[2] = uVar12;
          puVar16[3] = uVar13;
          uVar25 = uVar25 + 0x20;
        } while (uVar15 != uVar25);
        if (local_3dc == (undefined  [4])uVar15) goto LAB_0019873e;
      }
      do {
        *(undefined *)((int)local_404 + uVar15 + 0x2c) = local_3ec[uVar15];
        uVar15 = uVar15 + 1;
      } while (uVar15 < (uint)local_3dc);
    }
LAB_0019873e:
    puVar2 = (undefined2 *)((int)local_404 + (int)local_3dc + 0x2cU);
    ppiVar21 = (int **)((int)local_404 + (int)local_3dc + 0x31U);
    iVar14 = (int)ppiVar21 - (int)ppiVar24;
    if (ppiVar21 < ppiVar24 || (int)ppiVar21 - (int)ppiVar24 == 0) {
      iVar14 = (int)ppiVar24 - (int)ppiVar21;
    }
    if (iVar14 < 0x7fff0001) {
      *(undefined *)puVar2 = 0xe9;
      *(int *)((int)puVar2 + 1) = (int)ppiVar24 - (int)ppiVar21;
    }
    else {
      *puVar2 = 0x25ff;
      *(undefined2 **)(puVar2 + 1) = puVar2 + 3;
      *(int ***)(puVar2 + 3) = ppiVar24;
    }
    if (local_3cc._4_4_ != 0) {
      piVar19 = (int *)((int)&uStack_3c4 + 4);
      uVar15 = 0;
      do {
        *(int *)((int)ppiVar18 + piVar19[-1]) = (int)ppiVar17 + (*piVar19 - (int)ppiVar18);
        uVar15 = uVar15 + 1;
        piVar19 = piVar19 + 3;
      } while (uVar15 < (uint)local_3cc._4_4_);
    }
    uVar15 = (int)param_2 - (int)ppiVar17;
    if (param_2 < ppiVar17) {
      uVar15 = (int)ppiVar17 - (int)param_2;
    }
    if (uVar15 < 0x7fff0001) {
      ppiVar24 = (int **)((int)ppiVar17 + 5);
      ppiVar18 = (int **)((int)ppiVar24 - (int)param_2);
      if (ppiVar24 < param_2 || (int **)((int)ppiVar24 - (int)param_2) == (int **)0x0) {
        ppiVar18 = (int **)((int)param_2 - (int)ppiVar24);
      }
      if ((int)ppiVar18 < 0x7fff0001) {
        *(undefined *)ppiVar17 = 0xe9;
        ppiVar18 = (int **)((int)ppiVar17 + 1);
        ppiVar24 = (int **)((int)param_2 - (int)ppiVar24);
      }
      else {
        *(undefined2 *)ppiVar17 = 0x25ff;
        ppiVar18 = (int **)((int)ppiVar17 + 6);
        *(int ***)((int)ppiVar17 + 2) = ppiVar18;
        ppiVar24 = param_2;
      }
    }
    else {
      ppiVar24 = local_404 + 3;
      ppiVar18 = (int **)((int)local_404 + 0x11);
      ppiVar21 = (int **)((int)ppiVar18 - (int)param_2);
      if (ppiVar18 < param_2 || (int **)((int)ppiVar18 - (int)param_2) == (int **)0x0) {
        ppiVar21 = (int **)((int)param_2 - (int)ppiVar18);
      }
      if ((int)ppiVar21 < 0x7fff0001) {
        *(undefined *)(local_404 + 3) = 0xe9;
        ppiVar21 = (int **)((int)local_404 + 0xd);
        ppiVar18 = (int **)((int)param_2 - (int)ppiVar18);
      }
      else {
        *(undefined2 *)(local_404 + 3) = 0x25ff;
        ppiVar21 = (int **)((int)local_404 + 0x12);
        *(int ***)((int)local_404 + 0xe) = ppiVar21;
        ppiVar18 = param_2;
      }
      *ppiVar21 = (int *)ppiVar18;
      ppiVar21 = (int **)((int)ppiVar17 + 5);
      ppiVar18 = (int **)((int)ppiVar21 - (int)ppiVar24);
      if (ppiVar21 < ppiVar24 || (int **)((int)ppiVar21 - (int)ppiVar24) == (int **)0x0) {
        ppiVar18 = (int **)((int)ppiVar24 - (int)ppiVar21);
      }
      if ((int)ppiVar18 < 0x7fff0001) {
        *(undefined *)ppiVar17 = 0xe9;
        ppiVar18 = (int **)((int)ppiVar17 + 1);
        ppiVar24 = (int **)((int)ppiVar24 - (int)ppiVar21);
      }
      else {
        *(undefined2 *)ppiVar17 = 0x25ff;
        ppiVar18 = (int **)((int)ppiVar17 + 6);
        *(int ***)((int)ppiVar17 + 2) = ppiVar18;
      }
    }
    *ppiVar18 = (int *)ppiVar24;
    local_404[1] = piVar22;
    *local_404 = (int *)ppiVar17;
    local_404[2] = (int *)param_2;
  }
  else {
    puVar16 = (undefined4 *)FUN_0018aeb0();
    uVar23 = FUN_0018aec0(*puVar16);
    FUN_0018aed0("mhooks: Mhook_SetHook: failed mprotect 1: %s\n",uVar23);
    if (*local_404 == (int *)0x0) {
      ppiVar17 = (int **)&DAT_00272914;
      iVar14 = 0x100;
      uVar23 = 0;
      do {
        if ((int **)*ppiVar17 == local_404) {
          *ppiVar17 = (int *)0x0;
          FUN_0018aea0(local_404,local_3fc);
          DAT_00272d14 = DAT_00272d14 - 1;
          goto LAB_0019867a;
        }
        ppiVar17 = ppiVar17 + 1;
        iVar14 = iVar14 + -1;
      } while (iVar14 != 0);
      goto LAB_00198889;
    }
  }
  *param_1 = (int *)(local_404 + 0xb);
  uVar23 = 1;
LAB_00198889:
  FUN_0018b9a0(local_388);
  return uVar23;
}

