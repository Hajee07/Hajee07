/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f57a0 FUN_001f57a0 */

undefined4 FUN_001f57a0(int param_1,uint param_2)

{
  undefined *puVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 local_1c;
  int local_18;
  
  puVar1 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(int *)PTR___stack_chk_guard_0024bd6c;
  iVar6 = 1;
  if (param_1 != 0) {
    iVar6 = param_1;
  }
  uVar5 = 4;
  if (4 < param_2) {
    uVar5 = param_2;
  }
  while( true ) {
    iVar2 = FUN_00213710(&local_1c,uVar5,iVar6);
    if (iVar2 == 0) {
      if (*(int *)puVar1 != local_18) {
                    /* WARNING: Subroutine does not return */
        FUN_0018adc0();
      }
      return local_1c;
    }
    pcVar3 = (code *)FUN_001f9ec0();
    if (pcVar3 == (code *)0x0) break;
    (*pcVar3)();
  }
  uVar4 = FUN_001f8f90(4);
  FUN_001fcbb0(uVar4);
  FUN_001f9120(uVar4,PTR_PTR_0024bd74,PTR_FUN_0024bd70);
  uVar4 = FUN_001f5870();
  return uVar4;
}

