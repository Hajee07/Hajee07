/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c2bb0 FUN_001c2bb0 */

void __regparm3
FUN_001c2bb0(undefined4 param_1_00,int param_2_00,int *param_3_00,ushort *param_1,undefined4 param_2
            ,char param_3)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  ushort uVar4;
  char cVar5;
  uint uVar6;
  undefined4 uVar7;
  byte bVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  
  uVar10 = (uint)(*param_1 >> 8);
  if (param_3 == '\0') {
    uVar11 = param_1[1] & 0xff;
    uVar4 = param_1[1] >> 8;
  }
  else {
    uVar11 = uVar10 & 0xf;
    uVar4 = *param_1 >> 0xc;
    uVar10 = uVar11;
  }
  uVar9 = (uint)uVar4;
  iVar2 = *(int *)(param_2_00 + uVar11 * 0xc);
  uVar6 = 0;
  switch(iVar2) {
  case 1:
  case 2:
    uVar6 = (uint)*(char *)(param_2_00 + 4 + uVar11 * 0xc);
    break;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    break;
  case 4:
    uVar6 = (uint)*(ushort *)(param_2_00 + 4 + uVar11 * 0xc);
    break;
  case 8:
    uVar6 = (uint)*(short *)(param_2_00 + 4 + uVar11 * 0xc);
    break;
  case 0x10:
switchD_001c2c1d_caseD_10:
    uVar6 = *(uint *)(param_2_00 + 4 + uVar11 * 0xc);
    break;
  default:
    if (iVar2 == 0x1000) goto switchD_001c2c1d_caseD_10;
  }
  iVar2 = *(int *)(param_2_00 + uVar9 * 0xc);
  uVar11 = 0;
  switch(iVar2) {
  case 1:
  case 2:
    uVar11 = (uint)*(char *)(param_2_00 + 4 + uVar9 * 0xc);
    break;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    break;
  case 4:
    uVar11 = (uint)*(ushort *)(param_2_00 + 4 + uVar9 * 0xc);
    break;
  case 8:
    uVar11 = (uint)*(short *)(param_2_00 + 4 + uVar9 * 0xc);
    break;
  case 0x10:
switchD_001c2c74_caseD_10:
    uVar11 = *(uint *)(param_2_00 + 4 + uVar9 * 0xc);
    break;
  default:
    if (iVar2 == 0x1000) goto switchD_001c2c74_caseD_10;
  }
  iVar2 = *(int *)(param_2_00 + uVar10 * 0xc);
  iVar3 = *(int *)(param_2_00 + 4 + uVar10 * 0xc);
  puVar1 = (uint *)(param_2_00 + 4 + uVar10 * 0xc);
  bVar8 = (byte)uVar11;
  switch(param_2) {
  case 0x90:
  case 0xb0:
    *puVar1 = uVar11 + uVar6;
    break;
  case 0x91:
  case 0xb1:
    uVar6 = uVar6 - uVar11;
    goto LAB_001c2d52;
  case 0x92:
  case 0xb2:
    *puVar1 = uVar11 * uVar6;
    break;
  case 0x93:
  case 0xb3:
    if (uVar11 != 0) {
      *puVar1 = (int)uVar6 / (int)uVar11;
      break;
    }
    goto LAB_001c2da7;
  case 0x94:
  case 0xb4:
    if (uVar11 != 0) {
      *puVar1 = (int)uVar6 % (int)uVar11;
      break;
    }
LAB_001c2da7:
    uVar7 = FUN_001b7690();
    (**(code **)(*param_3_00 + 0x38))(param_3_00,uVar7,"divide by zero");
    (**(code **)(*param_3_00 + 0x5c))(param_3_00,uVar7);
    break;
  case 0x95:
  case 0xb5:
    *puVar1 = uVar11 & uVar6;
    break;
  case 0x96:
  case 0xb6:
    *puVar1 = uVar11 | uVar6;
    break;
  case 0x97:
  case 0xb7:
    *puVar1 = uVar11 ^ uVar6;
    break;
  case 0x98:
  case 0xb8:
    uVar6 = uVar6 << (bVar8 & 0x1f);
    goto LAB_001c2d52;
  case 0x99:
  case 0xb9:
    uVar6 = (int)uVar6 >> (bVar8 & 0x1f);
    goto LAB_001c2d52;
  case 0x9a:
  case 0xba:
    uVar6 = uVar6 >> (bVar8 & 0x1f);
LAB_001c2d52:
    *puVar1 = uVar6;
  }
  cVar5 = (**(code **)(*param_3_00 + 0x390))(param_3_00);
  if (cVar5 == '\0') {
    if (((iVar2 == 0x4000) || (iVar2 == 0x100)) && (iVar3 != 0)) {
      (**(code **)(*param_3_00 + 0x5c))(param_3_00,iVar3);
    }
    *(undefined4 *)(param_2_00 + uVar10 * 0xc) = 0x10;
  }
  return;
}

