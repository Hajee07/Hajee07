/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f0c80 FUN_001f0c80 */

int FUN_001f0c80(void)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 in_ECX;
  char *pcVar4;
  int local_1c;
  int *local_18;
  undefined4 local_14;
  
  local_1c = 0;
  cVar1 = FUN_001f3580(in_ECX,"linker");
  if (cVar1 == '\0') {
    iVar2 = 0;
    cVar1 = FUN_001f3580(in_ECX,"[vdso]");
    if (cVar1 == '\0') goto LAB_001f0cea;
  }
  iVar2 = FUN_001f2070();
  local_1c = iVar2;
LAB_001f0cea:
  iVar3 = FUN_001f3630();
  pcVar4 = "app_process32";
  if (iVar3 < 0x15) {
    pcVar4 = "app_process";
  }
  cVar1 = FUN_001f3580(in_ECX,pcVar4);
  if (cVar1 != '\0') {
    iVar2 = FUN_001f2070();
    local_1c = iVar2;
  }
  if (iVar2 == 0) {
    local_18 = &local_1c;
    local_14 = in_ECX;
    FUN_001f2460(FUN_001f2170,&local_18,0);
    iVar2 = local_1c;
  }
  return iVar2;
}

