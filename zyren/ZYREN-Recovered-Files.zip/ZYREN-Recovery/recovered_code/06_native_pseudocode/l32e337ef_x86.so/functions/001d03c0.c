/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d03c0 FUN_001d03c0 */

uint FUN_001d03c0(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  undefined local_4814 [2048];
  undefined4 local_4014;
  undefined local_4010 [16384];
  
  FUN_0018ae30(local_4010,0,0x4000,0x1d03cf);
  local_4014 = 0xc00000c;
  uVar1 = FUN_001cdda0(&local_4014,param_3,param_4,local_4814,0x800);
  uVar2 = uVar1;
  if ((uVar1 < 0xffffff89) && (uVar2 = 0xffffffb8, uVar1 < param_4)) {
    uVar2 = FUN_001ceba0(param_3 + uVar1,param_4 - uVar1,&local_4014);
  }
  return uVar2;
}

