/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9920 FUN_001f9920 */

void FUN_001f9920(void)

{
  int iVar1;
  
  iVar1 = FUN_0018b500(&DAT_00276e70,FUN_001f9980);
  if (iVar1 == 0) {
    FUN_0018b4e0(DAT_00276e6c);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_001fd290("execute once failure in __cxa_get_globals_fast()");
}

