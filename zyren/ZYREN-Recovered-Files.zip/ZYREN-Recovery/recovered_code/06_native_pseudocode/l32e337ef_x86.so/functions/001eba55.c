/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001eba55 FUN_001eba55 */

undefined4 FUN_001eba55(void)

{
  int unaff_retaddr;
  
  return **(undefined4 **)(&DAT_0008b34f + unaff_retaddr);
}

