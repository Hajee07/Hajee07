/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a7a70 FUN_001a7a70 */

void FUN_001a7a70(ulonglong **param_1,ulonglong *param_2,undefined4 *param_3)

{
  uint uVar1;
  ulonglong *puVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  byte bVar5;
  undefined4 uVar6;
  int iVar7;
  ulonglong *puVar8;
  undefined4 uVar9;
  ulonglong *puVar10;
  int iVar11;
  ulonglong *puVar12;
  int local_30;
  undefined8 local_2c;
  int local_24;
  int local_1c;
  uint local_18;
  uint local_14;
  
  puVar12 = *param_1;
  puVar10 = param_1[1];
  iVar11 = (int)puVar10 - (int)puVar12 >> 5;
  uVar1 = iVar11 + 1;
  if (0x7ffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_001a7a40(param_1);
  }
  local_18 = 0x7ffffff;
  if ((uint)((int)param_1[2] - (int)puVar12 >> 5) < 0x3ffffff) {
    local_18 = (int)param_1[2] - (int)puVar12 >> 4;
    if (local_18 < uVar1) {
      local_18 = uVar1;
    }
    if (local_18 != 0) {
      if (0x7ffffff < local_18) {
                    /* WARNING: Subroutine does not return */
        FUN_001a6e70("allocator<T>::allocate(size_t n) \'n\' exceeds maximum supported size");
      }
      goto LAB_001a7ada;
    }
    local_18 = 0;
    local_30 = 0;
  }
  else {
LAB_001a7ada:
    local_30 = FUN_001f5520(local_18 << 5);
  }
  local_2c = 0;
  local_24 = 0;
  if ((*(byte *)param_2 & 1) == 0) {
    local_24 = *(int *)(param_2 + 1);
    local_2c = *param_2;
    goto LAB_001a7bad;
  }
  uVar1 = *(uint *)((int)param_2 + 4);
  if (0xffffffef < uVar1) {
                    /* try { // try from 001a7cdc to 001a7cee has its CatchHandler @ 001a7d04 */
                    /* WARNING: Subroutine does not return */
    FUN_001a6e40(&local_2c);
  }
  if (uVar1 < 0xb) {
    local_2c = (ulonglong)(byte)((char)uVar1 * '\x02');
    iVar7 = (int)&local_2c + 1;
    uVar9 = *(undefined4 *)(param_2 + 1);
    if (uVar1 != 0) goto LAB_001a7b89;
  }
  else {
    local_14 = uVar1 + 0x10 & 0xfffffff0;
    local_1c = *(undefined4 *)(param_2 + 1);
                    /* try { // try from 001a7b5e to 001a7b6d has its CatchHandler @ 001a7d04 */
    iVar7 = FUN_001f5520(local_14);
    local_2c = CONCAT44(uVar1,local_14) | 1;
    uVar9 = local_1c;
    local_24 = iVar7;
LAB_001a7b89:
    local_1c = iVar7;
    FUN_0018ae80(iVar7,uVar9,uVar1);
    iVar7 = local_1c;
  }
  *(undefined *)(iVar7 + uVar1) = 0;
LAB_001a7bad:
  iVar11 = iVar11 * 0x20;
  puVar8 = (ulonglong *)(local_30 + iVar11);
  uVar9 = *param_3;
  uVar6 = param_3[1];
  *(int *)(puVar8 + 1) = local_24;
  *puVar8 = local_2c;
  *(undefined4 *)(local_30 + 0x10 + iVar11) = uVar6;
  *(undefined4 *)(local_30 + 0xc + iVar11) = uVar9;
  *(undefined4 *)(local_30 + 0x18 + iVar11) = 0;
  *(undefined4 *)(local_30 + 0x14 + iVar11) = 0;
  *(undefined *)(local_30 + 0x1c + iVar11) = 1;
  puVar2 = puVar8 + 4;
  if (puVar10 != puVar12) {
    do {
      *(undefined4 *)(puVar8 + -3) = *(undefined4 *)(puVar10 + -3);
      puVar8[-4] = puVar10[-4];
      *(undefined4 *)((int)puVar10 + -0x1c) = 0;
      *(undefined4 *)(puVar10 + -4) = 0;
      *(undefined4 *)(puVar10 + -3) = 0;
      *(undefined *)((int)puVar8 + -4) = *(undefined *)((int)puVar10 + -4);
      uVar4 = *(undefined8 *)((int)puVar10 + -0x14);
      puVar3 = (undefined8 *)((int)puVar10 + -0xc);
      puVar10 = puVar10 + -4;
      *(undefined8 *)((int)puVar8 + -0xc) = *puVar3;
      *(undefined8 *)((int)puVar8 + -0x14) = uVar4;
      puVar8 = puVar8 + -4;
    } while (puVar12 != puVar10);
    puVar10 = *param_1;
    puVar12 = param_1[1];
  }
  *param_1 = puVar8;
  param_1[1] = puVar2;
  param_1[2] = (ulonglong *)(local_18 * 0x20 + local_30);
  if (puVar12 != puVar10) {
    bVar5 = *(byte *)(puVar12 + -4);
    while( true ) {
      if ((bVar5 & 1) != 0) {
        FUN_001f5680(*(undefined4 *)(puVar12 + -3));
      }
      if (puVar10 == puVar12 + -4) break;
      bVar5 = *(byte *)(puVar12 + -8);
      puVar12 = puVar12 + -4;
    }
  }
  if (puVar10 != (ulonglong *)0x0) {
    FUN_001f5680(puVar10);
  }
  return;
}

