/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a74e0 FUN_001a74e0 */

void FUN_001a74e0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int **ppiVar7;
  int iVar8;
  int iVar9;
  int *local_30 [8];
  
  local_30[0] = param_2;
  local_30[1] = (int *)param_3;
  local_30[2] = (int *)param_4;
  local_30[3] = (int *)param_5;
  local_30[4] = (int *)param_6;
  local_30[5] = (int *)param_7;
  local_30[6] = (int *)param_8;
  local_30[7] = (int *)param_9;
  piVar1 = *(int **)(PTR_DAT_0024bc04 + 4);
  if (piVar1 == (int *)0x0) {
    return;
  }
  uVar3 = (int)piVar1 - ((uint)piVar1 >> 1 & 0x55555555);
  uVar3 = (uVar3 >> 2 & 0x33333333) + (uVar3 & 0x33333333);
  uVar3 = ((uVar3 >> 4) + uVar3 & 0xf0f0f0f) * 0x1010101 >> 0x18;
  iVar8 = 1;
  iVar9 = iVar8;
  if (param_2 == (int *)0x0) goto LAB_001a7680;
  do {
    uVar2 = ((uint)((int)param_2 * 0x5bd1e995) >> 0x18 ^ (int)param_2 * 0x5bd1e995) * 0x5bd1e995 ^
            0x6f47a654;
    uVar2 = (uVar2 >> 0xd ^ uVar2) * 0x5bd1e995;
    piVar4 = (int *)(uVar2 >> 0xf ^ uVar2);
    if (uVar3 < 2) {
      piVar5 = (int *)((int)piVar1 - 1U & (uint)piVar4);
      ppiVar7 = *(int ***)(*(int *)PTR_DAT_0024bc04 + (int)piVar5 * 4);
    }
    else {
      piVar5 = piVar4;
      if (piVar1 <= piVar4) {
        piVar5 = (int *)((uint)piVar4 % (uint)piVar1);
      }
      ppiVar7 = *(int ***)(*(int *)PTR_DAT_0024bc04 + (int)piVar5 * 4);
    }
    iVar9 = iVar8;
    if ((ppiVar7 != (int **)0x0) && (ppiVar7 = (int **)*ppiVar7, ppiVar7 != (int **)0x0)) {
      if (uVar3 < 2) {
        do {
          if (ppiVar7[1] == piVar4) {
            if (ppiVar7[2] == param_2) goto LAB_001a7698;
          }
          else if ((int *)((uint)ppiVar7[1] & (int)piVar1 - 1U) != piVar5) break;
          ppiVar7 = (int **)*ppiVar7;
        } while (ppiVar7 != (int **)0x0);
      }
      else {
        do {
          piVar6 = ppiVar7[1];
          if (piVar6 == piVar4) {
            if (ppiVar7[2] == param_2) {
LAB_001a7698:
              FUN_001a3900(param_2,local_30[iVar8]);
              return;
            }
          }
          else {
            if (piVar1 <= piVar6) {
              piVar6 = (int *)((uint)piVar6 % (uint)piVar1);
            }
            if (piVar6 != piVar5) break;
          }
          ppiVar7 = (int **)*ppiVar7;
        } while (ppiVar7 != (int **)0x0);
      }
    }
LAB_001a7680:
    do {
      iVar8 = iVar9 + 1;
      if (iVar8 == 8) {
        return;
      }
      param_2 = local_30[iVar9];
      iVar9 = iVar8;
    } while (param_2 == (int *)0x0);
  } while( true );
}

