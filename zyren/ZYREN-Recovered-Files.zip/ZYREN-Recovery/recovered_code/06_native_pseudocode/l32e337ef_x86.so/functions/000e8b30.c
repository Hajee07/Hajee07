/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000e8b30 FUN_000e8b30 */

void __regparm3 FUN_000e8b30(undefined4 param_1,int param_2,int *param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 local_2c;
  undefined4 local_28;
  undefined local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined2 local_14;
  
  if (param_2 != 0) {
    local_18 = 0;
    local_1c = 0;
    local_14 = 0;
    thunk_FUN_00061f80(&local_1c,&DAT_0017f145,10);
    local_28 = 0;
    local_2c = 0;
    local_24 = 0;
    thunk_FUN_00061f80(&local_2c,&DAT_0017f14f,9);
    local_20 = (**(code **)(*param_3 + 0x7c))(param_3,param_2);
    uVar1 = (**(code **)(*param_3 + 0x84))(param_3,local_20,&local_1c,"()Landroid/view/Window;");
    iVar2 = (**(code **)(*param_3 + 0x88))(param_3,param_2,uVar1);
    uVar1 = (**(code **)(*param_3 + 0x18))(param_3,"android/view/Window");
    uVar3 = (**(code **)(*param_3 + 0x84))(param_3,uVar1,&local_2c,&DAT_0015e2ac);
    if (iVar2 != 0) {
      (**(code **)(*param_3 + 0xf4))(param_3,iVar2,uVar3,0x2000);
      (**(code **)(*param_3 + 0x5c))(param_3,iVar2);
    }
    (**(code **)(*param_3 + 0x5c))(param_3,local_20);
    (**(code **)(*param_3 + 0x5c))(param_3,uVar1);
  }
  return;
}

