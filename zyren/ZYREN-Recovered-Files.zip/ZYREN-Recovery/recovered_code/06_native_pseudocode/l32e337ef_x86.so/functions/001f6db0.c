/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f6db0 FUN_001f6db0 */

void FUN_001f6db0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar1 = FUN_001f8f90(0x10);
  if (DAT_00276e4c == '\0') {
    iVar2 = FUN_001f9a30(&DAT_00276e4c);
    if (iVar2 != 0) {
      DAT_00276e48 = &PTR_FUN_0024a1cc;
      FUN_001f9ba0(&DAT_00276e4c);
    }
  }
                    /* try { // try from 001f6e17 to 001f6e31 has its CatchHandler @ 001f6e51 */
  FUN_001f6670(uVar1,CONCAT44(&DAT_00276e48,param_1),param_2);
  uVar3 = FUN_001f9120(uVar1,PTR_PTR_0024bd8c,PTR_FUN_0024bd88);
                    /* catch() { ... } // from try @ 001f6e17 with catch @ 001f6e51 */
  FUN_001f8ff0(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_002155d3(uVar3);
}

