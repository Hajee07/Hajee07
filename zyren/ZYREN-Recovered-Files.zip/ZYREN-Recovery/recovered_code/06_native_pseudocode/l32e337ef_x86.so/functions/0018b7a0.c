/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0018b7a0 _INIT_1 */

void __regparm3 _INIT_1(undefined4 param_1)

{
  undefined *puVar1;
  
  puVar1 = PTR_DAT_0024bc04;
  *(undefined4 *)(PTR_DAT_0024bc04 + 4) = 0;
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0;
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0x10) = 0x3f800000;
  FUN_0018adb0(FUN_001b4180,puVar1,&PTR_LOOP_00249de0,0x18b7a8,param_1);
  puVar1 = PTR_DAT_0024bc10;
  *(undefined4 *)(PTR_DAT_0024bc10 + 4) = 0;
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0;
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0x10) = 0x3f800000;
  FUN_0018adb0(FUN_001b41d0,puVar1,&PTR_LOOP_00249de0);
  puVar1 = PTR_DAT_0024bc84;
  *(undefined4 *)PTR_DAT_0024bc84 = 0;
  *(undefined4 *)(puVar1 + 4) = 0;
  *(undefined4 *)(puVar1 + 8) = 0;
  FUN_0018adb0(FUN_001b4220,puVar1,&PTR_LOOP_00249de0);
  return;
}

