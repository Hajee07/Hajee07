/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001cc270 FUN_001cc270 */

void FUN_001cc270(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined local_804 [2048];
  
  FUN_001cc120(param_1,param_2,param_3,local_804,0x800);
  return;
}

