/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ee000 FUN_001ee000 */

undefined4 FUN_001ee000(void)

{
  if (DAT_00276dbc != 0) {
    FUN_0018ae20(DAT_00276dbc);
    DAT_00276dc0 = 0;
    DAT_00276db8 = 0;
    DAT_00276dbc = 0;
    return 1;
  }
  return 0;
}

