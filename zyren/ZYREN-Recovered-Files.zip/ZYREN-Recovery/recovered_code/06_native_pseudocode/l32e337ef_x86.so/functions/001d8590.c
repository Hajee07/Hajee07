/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d8590 FUN_001d8590 */

uint FUN_001d8590(uint *param_1,uint param_2,uint param_3,undefined4 param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  uVar3 = 0;
  if ((param_3 < uVar2 || param_3 - uVar2 < (uint)(param_2 < uVar1)) &&
     (uVar3 = uVar1 - param_2,
     (uint)(uVar1 - param_2 < param_5) <= (uVar2 - param_3) - (uint)(uVar1 < param_2))) {
    uVar3 = param_5;
  }
  FUN_0018ae80(param_4,param_2 + *(int *)(param_1[0x12] + 0x48),uVar3,0x1d859c);
  return uVar3;
}

