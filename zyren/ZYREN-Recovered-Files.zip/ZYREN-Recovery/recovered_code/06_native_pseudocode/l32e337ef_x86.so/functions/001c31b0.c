/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c31b0 FUN_001c31b0 */

undefined4 FUN_001c31b0(undefined4 param_1,int param_2)

{
  FUN_001c31f0(*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_2 + 0x2c),0,0x1c31b9);
  return 0;
}

