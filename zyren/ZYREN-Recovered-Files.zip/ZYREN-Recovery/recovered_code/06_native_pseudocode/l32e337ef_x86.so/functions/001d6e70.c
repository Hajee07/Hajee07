/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d6e70 FUN_001d6e70 */

int FUN_001d6e70(int param_1,int param_2,int *param_3,uint param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int local_2b10;
  int local_2b0c;
  uint local_2b08;
  undefined4 local_2b04 [2749];
  
  uVar6 = 0x1d6e7f;
  *param_3 = 0;
  local_2b04[0] = 0;
  local_2b08 = param_4 & 0xfffffff9 | 4;
  iVar2 = 0;
  iVar5 = 0;
  uVar3 = 0;
  iVar4 = 0;
  while( true ) {
    local_2b0c = param_2 - iVar5;
    local_2b10 = uVar3 - iVar2;
    if (iVar4 == 0) {
      iVar2 = 0;
      iVar1 = 0;
    }
    else {
      iVar2 = iVar2 + iVar4;
      iVar1 = iVar4;
    }
    iVar2 = FUN_001d39a0(local_2b04,param_1 + iVar5,&local_2b0c,iVar1,iVar2,&local_2b10,local_2b08,
                         uVar6);
    if ((iVar2 < 0) || (iVar2 == 1)) break;
    iVar5 = iVar5 + local_2b0c;
    *param_3 = *param_3 + local_2b10;
    if (iVar2 == 0) {
      return iVar4;
    }
    uVar3 = uVar3 * 2;
    if (uVar3 < 0x81) {
      uVar3 = 0x80;
    }
    iVar1 = FUN_0018b200(iVar4,uVar3);
    if (iVar1 == 0) break;
    iVar2 = *param_3;
    iVar4 = iVar1;
  }
  FUN_0018ae20(iVar4);
  *param_3 = 0;
  return 0;
}

