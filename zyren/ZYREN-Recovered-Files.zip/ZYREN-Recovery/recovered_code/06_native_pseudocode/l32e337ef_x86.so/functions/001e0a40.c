/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e0a40 FUN_001e0a40 */

undefined4
FUN_001e0a40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined2 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 local_78;
  undefined local_74 [72];
  undefined4 local_2c;
  
  local_78 = 0;
  iVar1 = FUN_0018b240(param_3,local_74);
  if (iVar1 == 0) {
    local_78 = local_2c;
    iVar1 = FUN_0018b0c0(param_3,&DAT_00218693);
    if (iVar1 == 0) {
      uVar3 = 0;
      if (param_1 != 0) {
        *(undefined4 *)(param_1 + 0x1c) = 0x11;
      }
    }
    else {
      FUN_0018b0d0(iVar1,0,2);
      iVar2 = FUN_0018b0e0(iVar1);
      FUN_0018b0d0(iVar1,0,0);
      uVar3 = FUN_001df550(param_1,param_2,FUN_001e09d0,iVar1,iVar2,iVar2 >> 0x1f,&local_78,param_4,
                           param_5,param_6,param_7,0,0,0,0);
      FUN_0018b120(iVar1);
    }
  }
  else {
    uVar3 = 0;
    if (param_1 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 0x17;
    }
  }
  return uVar3;
}

