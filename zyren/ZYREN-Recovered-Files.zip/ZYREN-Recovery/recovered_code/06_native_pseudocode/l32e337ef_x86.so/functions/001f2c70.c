/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f2c70 FUN_001f2c70 */

void FUN_001f2c70(void)

{
  FUN_001f2ca0();
  if (DAT_00276dc4 != 0) {
    FUN_0018adf0(DAT_00276dc4);
  }
  return;
}

