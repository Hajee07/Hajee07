/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ea640 FUN_001ea640 */

undefined4 __regparm3
FUN_001ea640(undefined4 param_1_00,undefined4 param_2_00,int *param_3,undefined4 param_1,
            undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  char *pcVar7;
  char *local_424;
  uint local_418;
  uint local_414;
  char local_410 [1024];
  
  if (param_3 != (int *)0x0) {
    iVar2 = (**(code **)(*param_3 + 0x18))(param_3,param_2_00);
    cVar1 = (**(code **)(*param_3 + 0x390))(param_3);
    if (cVar1 != '\0') {
      (**(code **)(*param_3 + 0x44))(param_3);
    }
    if (iVar2 != 0) {
      iVar3 = (**(code **)(*param_3 + 0x84))(param_3,iVar2,param_1,param_2);
      cVar1 = (**(code **)(*param_3 + 0x390))(param_3);
      if (cVar1 != '\0') {
        (**(code **)(*param_3 + 0x44))(param_3);
      }
      (**(code **)(*param_3 + 0x5c))(param_3,iVar2);
      if (iVar3 != 0) {
        uVar6 = *(uint *)(iVar3 + 0x18);
        iVar2 = FUN_0018b0c0("/proc/self/maps",&DAT_00217bf0);
        if (iVar2 != 0) {
          FUN_0018ae30(local_410,0,0x400);
          iVar3 = FUN_0018b180(local_410,0x400,iVar2);
          if (iVar3 != 0) {
            if (uVar6 != 0) {
              do {
                local_414 = 0;
                local_418 = 0;
                iVar3 = FUN_0018b1f0(local_410,"%lx-%lx",&local_414,&local_418);
                if (((iVar3 == 2) && (local_414 <= uVar6)) && (uVar6 < local_418)) {
                  local_424 = local_410;
                  cVar1 = FUN_001ea0b0();
                  if (cVar1 != '\0') goto LAB_001ea7b3;
                  if (local_410[0] != '\0') {
                    goto LAB_001ea813;
                  }
                  break;
                }
                iVar3 = FUN_0018b180(local_410,0x400,iVar2);
              } while (iVar3 != 0);
              uVar5 = 0;
              goto LAB_001ea86a;
            }
            do {
              iVar3 = FUN_0018b180(local_410,0x400,iVar2);
            } while (iVar3 != 0);
          }
          uVar5 = 0;
          goto LAB_001ea86a;
        }
      }
    }
  }
  return 0;
LAB_001ea7b3:
  uVar5 = 1;
  goto LAB_001ea86a;
LAB_001ea813:
  do {
    uVar6 = 0;
    pcVar7 = "zygisk";
    do {
      if (5 < uVar6) goto LAB_001ea7fd;
      if (local_424[uVar6] == '\0') goto LAB_001ea802;
      cVar1 = *pcVar7;
      iVar3 = FUN_0018b360(local_424[uVar6]);
      iVar4 = FUN_0018b360(cVar1);
      uVar6 = uVar6 + 1;
      pcVar7 = pcVar7 + 1;
    } while (iVar3 == iVar4);
    uVar6 = ((iVar3 == iVar4) - 1) + uVar6;
LAB_001ea7fd:
    if (uVar6 == 6) goto LAB_001ea7b3;
LAB_001ea802:
    pcVar7 = local_424 + 1;
    local_424 = local_424 + 1;
  } while (*pcVar7 != '\0');
  local_424 = local_410;
  do {
    uVar6 = 0;
    pcVar7 = "magisk";
    do {
      if (5 < uVar6) goto LAB_001ea893;
      if (local_424[uVar6] == '\0') goto LAB_001ea89c;
      cVar1 = *pcVar7;
      iVar3 = FUN_0018b360(local_424[uVar6]);
      iVar4 = FUN_0018b360(cVar1);
      uVar6 = uVar6 + 1;
      pcVar7 = pcVar7 + 1;
    } while (iVar3 == iVar4);
    uVar6 = ((iVar3 == iVar4) - 1) + uVar6;
LAB_001ea893:
    if (uVar6 == 6) goto LAB_001ea7b3;
LAB_001ea89c:
    uVar5 = 0;
    pcVar7 = local_424 + 1;
    local_424 = local_424 + 1;
  } while (*pcVar7 != '\0');
LAB_001ea86a:
  FUN_0018b120(iVar2);
  return uVar5;
}

