/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c2400 FUN_001c2400 */

undefined4 FUN_001c2400(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = *(int *)(param_2 + 8);
  uVar3 = **(ushort **)(param_2 + 0x28) >> 8 & 0xf;
  uVar4 = (uint)(**(ushort **)(param_2 + 0x28) >> 0xc);
  iVar2 = *(int *)(iVar1 + uVar3 * 0xc);
  if ((((iVar2 == 0x4000) || (iVar2 == 0x100)) &&
      (iVar2 = *(int *)(iVar1 + 4 + uVar3 * 0xc), iVar2 != 0)) &&
     (iVar2 != *(int *)(iVar1 + 4 + uVar4 * 0xc))) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar2);
  }
  *(undefined4 *)(iVar1 + uVar3 * 0xc) = 0x40;
  *(float *)(iVar1 + 4 + uVar3 * 0xc) = (float)*(longlong *)(iVar1 + 4 + uVar4 * 0xc);
  *(undefined4 *)(iVar1 + 8 + uVar3 * 0xc) = 0;
  return 0;
}

