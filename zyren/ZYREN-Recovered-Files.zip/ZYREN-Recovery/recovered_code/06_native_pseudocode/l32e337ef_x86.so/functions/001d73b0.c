/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d73b0 FUN_001d73b0 */

undefined4
FUN_001d73b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  int iVar4;
  
  puVar2 = PTR_FUN_0024bd00;
  if (param_1 == (undefined4 *)0x0) {
    return 0;
  }
  if (((param_1[0xe] != 0) && (param_1[0x12] == 0)) && (param_1[5] == 0)) {
    pcVar1 = (code *)param_1[10];
    if (pcVar1 == (code *)0x0) {
      param_1[10] = PTR_FUN_0024bd00;
      iVar4 = param_1[0xb];
      pcVar1 = (code *)puVar2;
    }
    else {
      iVar4 = param_1[0xb];
    }
    if (iVar4 == 0) {
      param_1[0xb] = PTR_FUN_0024bd04;
      iVar4 = param_1[0xc];
    }
    else {
      iVar4 = param_1[0xc];
    }
    if (iVar4 == 0) {
      param_1[0xc] = PTR_FUN_0024bd08;
    }
    param_1[7] = 0;
    param_1[1] = 0;
    *param_1 = 0;
    param_1[3] = 0;
    param_1[2] = 0;
    param_1[4] = 0;
    puVar3 = (undefined4 *)(*pcVar1)(param_1[0xd],1,0x54);
    param_1[0x12] = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      param_1[7] = 0x10;
    }
    else {
      puVar3[1] = 0;
      *puVar3 = 0;
      puVar3[3] = 0;
      puVar3[2] = 0;
      puVar3[5] = 0;
      puVar3[4] = 0;
      puVar3[7] = 0;
      puVar3[6] = 0;
      puVar3[9] = 0;
      puVar3[8] = 0;
      puVar3[0xb] = 0;
      puVar3[10] = 0;
      puVar3[0xd] = 0;
      puVar3[0xc] = 0;
      puVar3[0xf] = 0;
      puVar3[0xe] = 0;
      puVar3[0x11] = 0;
      puVar3[0x10] = 0;
      puVar3[0x13] = 0;
      puVar3[0x12] = 0;
      puVar3[0x14] = 0;
      iVar4 = param_1[0x12];
      *(undefined4 *)(iVar4 + 0xc) = 1;
      *(undefined4 *)(iVar4 + 0x1c) = 4;
      *(undefined4 *)(iVar4 + 0x2c) = 4;
      *(undefined4 *)(iVar4 + 0x30) = param_4;
      *(undefined4 *)(iVar4 + 0x34) = 0;
      *(undefined4 *)(iVar4 + 0x38) = 0;
      param_1[5] = 1;
      param_1[6] = 1;
      param_1[1] = param_3;
      *param_1 = param_2;
      iVar4 = FUN_001d7660();
      if (iVar4 != 0) {
        return 1;
      }
      puVar3 = (undefined4 *)param_1[0x12];
      if (((puVar3 != (undefined4 *)0x0) && (param_1[10] != 0)) &&
         (((code *)param_1[0xb] != (code *)0x0 && (param_1[5] == 1)))) {
        param_1[0x12] = 0;
        (*(code *)param_1[0xb])(param_1[0xd],*puVar3);
        puVar3[1] = 0;
        *puVar3 = 0;
        puVar3[3] = 0;
        puVar3[2] = 0;
        (*(code *)param_1[0xb])(param_1[0xd],puVar3[4]);
        puVar3[5] = 0;
        puVar3[4] = 0;
        puVar3[7] = 0;
        puVar3[6] = 0;
        (*(code *)param_1[0xb])(param_1[0xd],puVar3[8]);
        puVar3[9] = 0;
        puVar3[8] = 0;
        puVar3[0xb] = 0;
        puVar3[10] = 0;
        if (puVar3[0xf] != 0) {
          if (param_1[6] == 4) {
            FUN_0018b120(puVar3[0xf]);
          }
          puVar3[0xf] = 0;
        }
        (*(code *)param_1[0xb])(param_1[0xd],puVar3);
        param_1[5] = 0;
      }
    }
    return 0;
  }
  param_1[7] = 0x18;
  return 0;
}

