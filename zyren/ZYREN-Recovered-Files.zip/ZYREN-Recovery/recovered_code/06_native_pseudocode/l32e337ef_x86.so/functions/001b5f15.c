/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5f15 FUN_001b5f15 */

undefined * FUN_001b5f15(void)

{
  int unaff_retaddr;
  
  return &UNK_000be53f + unaff_retaddr;
}

