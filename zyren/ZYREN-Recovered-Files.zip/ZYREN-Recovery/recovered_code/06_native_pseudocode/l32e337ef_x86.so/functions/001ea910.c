/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ea910 FUN_001ea910 */

char * FUN_001ea910(char *param_1,char *param_2,char **param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  if ((param_1 == (char *)0x0) && (param_1 = *param_3, *param_3 == (char *)0x0)) {
    return (char *)0x0;
  }
  do {
    pcVar2 = param_1;
    pcVar5 = param_2;
    do {
      cVar1 = *pcVar5;
      if (cVar1 == '\0') {
        pcVar5 = pcVar2 + 1;
        if (*pcVar2 != '\0') goto LAB_001ea953;
        pcVar5 = (char *)0x0;
        pcVar2 = (char *)0x0;
        goto LAB_001ea981;
      }
      pcVar5 = pcVar5 + 1;
      param_1 = pcVar2 + 1;
    } while (*pcVar2 != cVar1);
  } while( true );
LAB_001ea953:
  pcVar4 = pcVar5;
  pcVar5 = pcVar4 + 1;
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    if (cVar1 == *pcVar4) {
      if (*pcVar4 == '\0') {
        pcVar5 = (char *)0x0;
      }
      else {
        *pcVar4 = '\0';
      }
LAB_001ea981:
      *param_3 = pcVar5;
      return pcVar2;
    }
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  goto LAB_001ea953;
}

