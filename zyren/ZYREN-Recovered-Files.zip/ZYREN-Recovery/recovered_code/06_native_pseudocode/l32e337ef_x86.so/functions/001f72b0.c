/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f72b0 FUN_001f72b0 */

void FUN_001f72b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  undefined **ppuVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int local_1c;
  
  ppuVar2 = &__DT_PLTGOT;
  puVar4 = *(undefined4 **)(param_1 + 0x10);
  if (puVar4 < *(undefined4 **)(param_1 + 0x14)) {
    puVar4[1] = param_3;
    *puVar4 = param_2;
    *(undefined4 **)(param_1 + 0x10) = puVar4 + 2;
    return;
  }
  local_1c = *(int *)(param_1 + 0xc);
  iVar8 = (int)puVar4 - local_1c >> 3;
  uVar1 = iVar8 + 1;
  if (0x1fffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_001a7a40((int *)(param_1 + 0xc));
  }
  iVar3 = (int)*(undefined4 **)(param_1 + 0x14) - local_1c;
  uVar6 = 0x1fffffff;
  if ((uint)(iVar3 >> 3) < 0xfffffff) {
    uVar6 = iVar3 >> 2;
    if (uVar6 < uVar1) {
      uVar6 = uVar1;
    }
    if (uVar6 == 0) {
      uVar6 = 0;
      iVar3 = 0;
      goto LAB_001f7358;
    }
  }
  iVar3 = FUN_001f5520(uVar6 * 8);
  local_1c = *(int *)(param_1 + 0xc);
  puVar4 = *(undefined4 **)(param_1 + 0x10);
LAB_001f7358:
  *(undefined4 *)(iVar3 + 4 + iVar8 * 8) = param_3;
  *(undefined4 *)(iVar3 + iVar8 * 8) = param_2;
  iVar7 = iVar3 + uVar6 * 8;
  iVar5 = (int)puVar4 - local_1c;
  iVar9 = (iVar3 + iVar8 * 8) - iVar5;
  if (0 < iVar5) {
    FUN_0018ae80(iVar9,local_1c,iVar5,iVar7,ppuVar2);
  }
  *(int *)(param_1 + 0xc) = iVar9;
  *(int *)(param_1 + 0x10) = iVar3 + 8 + iVar8 * 8;
  *(int *)(param_1 + 0x14) = iVar7;
  if (local_1c != 0) {
    FUN_001f5680(local_1c);
  }
  return;
}

