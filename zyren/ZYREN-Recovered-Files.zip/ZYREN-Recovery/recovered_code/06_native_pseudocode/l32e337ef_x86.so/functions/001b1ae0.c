/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b1ae0 FUN_001b1ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_001b1ae0(int *param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint local_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined *local_2c;
  int local_28;
  int local_24;
  undefined4 local_20;
  int local_1c;
  int local_18;
  int local_14;
  
  if ((param_3 != 0) && (*(int *)PTR_DAT_0024bc9c != 0)) {
    local_14 = (**(code **)(*param_1 + 0x7c))(param_1,param_3);
    local_3c = 0x3919090c;
    uStack_38 = 0x1d151e06;
    uStack_34 = CONCAT22(uStack_34._2_2_,4);
    local_40 = 0;
    do {
      *(byte *)((int)&local_3c + local_40) =
           (char)local_40 + 0x6bU ^ *(byte *)((int)&local_3c + local_40);
      local_40 = local_40 + 1;
    } while (local_40 < 9);
    uStack_34._0_2_ = (ushort)(byte)uStack_34;
    uVar3 = (**(code **)(*param_1 + 0x84))(param_1,local_14,&local_3c,"()Landroid/view/Window;");
    iVar4 = FUN_001a64f0(param_1,param_3,uVar3);
    local_18 = (**(code **)(*param_1 + 0x7c))(param_1,iVar4);
    local_3c = 0x2f19090c;
    uStack_38 = 0x1b03041b;
    uStack_34 = 0x13010111;
    uStack_30 = CONCAT22(uStack_30._2_2_,4);
    local_40 = 0;
    do {
      *(byte *)((int)&local_3c + local_40) =
           (char)local_40 + 0x6bU ^ *(byte *)((int)&local_3c + local_40);
      local_40 = local_40 + 1;
    } while (local_40 < 0xd);
    uStack_30._0_2_ = (ushort)(byte)uStack_30;
    uVar3 = (**(code **)(*param_1 + 0x84))
                      (param_1,local_18,&local_3c,"()Landroid/view/WindowManager$LayoutParams;");
    local_24 = iVar4;
    iVar4 = FUN_001a64f0(param_1,iVar4,uVar3);
    local_1c = (**(code **)(*param_1 + 0x7c))(param_1,iVar4);
    local_3c = 0x90c000d;
    uStack_38 = CONCAT22(uStack_38._2_2_,0x1c);
    local_40 = 0;
    do {
      *(byte *)((int)&local_3c + local_40) =
           (char)local_40 + 0x6bU ^ *(byte *)((int)&local_3c + local_40);
      local_40 = local_40 + 1;
    } while (local_40 < 5);
    uStack_38._0_2_ = (ushort)(byte)uStack_38;
    local_20 = (**(code **)(*param_1 + 0x178))(param_1,local_1c,&local_3c,&DAT_00217d87);
    (**(code **)(*param_1 + 400))(param_1,iVar4,local_20);
    local_3c = _DAT_0021b250;
    uStack_38 = _UNK_0021b254;
    uStack_34 = _UNK_0021b258;
    uStack_30 = _UNK_0021b25c;
    local_2c = &LAB_000a131f;
    local_40 = 0;
    do {
      *(byte *)((int)&local_3c + local_40) =
           (char)local_40 + 0x6bU ^ *(byte *)((int)&local_3c + local_40);
      local_40 = local_40 + 1;
    } while (local_40 < 0x13);
    local_2c = (undefined *)((uint)local_2c & 0xffffff);
    local_28 = iVar4;
    iVar4 = (**(code **)(*param_1 + 0x18))(param_1,&local_3c);
    uVar1 = uStack_34;
    local_3c = 0x2809080a;
    uStack_38 = 0x1161103;
    uStack_34 = uStack_34 & 0xffffff00;
    local_40 = 0;
    do {
      *(byte *)((int)&local_3c + local_40) =
           (char)local_40 + 0x6bU ^ *(byte *)((int)&local_3c + local_40);
      local_40 = local_40 + 1;
    } while (local_40 < 8);
    uStack_34 = uVar1 & 0xffffff00;
    uVar3 = (**(code **)(*param_1 + 0x84))(param_1,iVar4,&local_3c,&DAT_00218285);
    iVar2 = local_24;
    if (local_24 != 0) {
      FUN_001b4350(param_1,local_24,uVar3,0x2000);
      iVar5 = (**(code **)(*param_1 + 400))(param_1,local_28,local_20);
      if (iVar5 == 0) {
        FUN_001aa710(0xdead0116);
      }
      (**(code **)(*param_1 + 0x5c))(param_1,iVar2);
    }
    if (iVar4 != 0) {
      (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
    }
    iVar4 = local_28;
    if (local_1c != 0) {
      (**(code **)(*param_1 + 0x5c))(param_1,local_1c);
    }
    if (iVar4 != 0) {
      (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
    }
    if (local_18 != 0) {
      (**(code **)(*param_1 + 0x5c))(param_1,local_18);
    }
    if (local_24 != 0) {
      (**(code **)(*param_1 + 0x5c))(param_1,local_24);
    }
    if (local_14 != 0) {
      (**(code **)(*param_1 + 0x5c))(param_1,local_14);
    }
  }
  return;
}

