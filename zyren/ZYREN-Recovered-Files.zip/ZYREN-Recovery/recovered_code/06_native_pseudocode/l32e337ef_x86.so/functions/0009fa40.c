/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0009fa40 FUN_0009fa40 */

void __regparm3 FUN_0009fa40(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  
  do {
    piVar1 = (int *)(unaff_EDI + (uint)*(ushort *)(param_1 + param_3 * 2));
    *piVar1 = *piVar1 + unaff_ESI;
    param_3 = param_3 + 1;
  } while (param_3 < *(uint *)(unaff_EBP + 0xc) >> 1);
  FUN_00090941();
  return;
}

