/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00203470 FUN_00203470 */

char * __regparm3 FUN_00203470(undefined4 param_1,char *param_2,char **param_3)

{
  char *pcVar1;
  char cVar2;
  undefined2 uVar3;
  char **ppcVar4;
  char *pcVar5;
  uint uVar6;
  char *pcVar7;
  char **ppcVar8;
  char *pcVar9;
  char *local_28;
  char *local_24;
  
  pcVar5 = *param_3;
  local_28 = param_3[1];
  if ((pcVar5 != local_28) && (local_24 = param_2, *pcVar5 == 'B')) {
    while( true ) {
      pcVar1 = pcVar5 + 1;
      *param_3 = pcVar1;
      pcVar9 = (char *)0x0;
      pcVar7 = (char *)0x0;
      if (local_28 != pcVar1) {
        pcVar9 = (char *)0x0;
        pcVar7 = (char *)0x0;
        if ((byte)(*pcVar1 - 0x30U) < 10) {
          *param_3 = pcVar5 + 2;
          uVar6 = (int)pcVar5[1] - 0x30;
          pcVar5 = pcVar5 + 2;
          while ((local_28 != pcVar5 && ((byte)(*pcVar5 - 0x30U) < 10))) {
            *param_3 = pcVar5 + 1;
            uVar6 = *pcVar5 + -0x30 + uVar6 * 10;
            pcVar5 = pcVar5 + 1;
          }
          pcVar9 = (char *)0x0;
          pcVar7 = (char *)0x0;
          if (uVar6 <= (uint)((int)local_28 - (int)pcVar5)) {
            pcVar9 = pcVar5 + uVar6;
            *param_3 = pcVar9;
            pcVar7 = pcVar5;
          }
        }
      }
      param_2 = (char *)0x0;
      if (pcVar7 == pcVar9) break;
      ppcVar8 = (char **)param_3[0x45b];
      pcVar5 = ppcVar8[1];
      if ((char *)0xff7 < pcVar5 + 0x20) {
        ppcVar4 = (char **)FUN_0018add0(0x1000);
        if (ppcVar4 == (char **)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_001f9d40();
        }
        *ppcVar4 = (char *)ppcVar8;
        ppcVar4[1] = (char *)0x0;
        param_3[0x45b] = (char *)ppcVar4;
        pcVar5 = (char *)0x0;
        ppcVar8 = ppcVar4;
      }
      ppcVar8[1] = pcVar5 + 0x20;
      cVar2 = local_24[7];
      uVar3 = *(undefined2 *)(local_24 + 5);
      *(char *)((int)(ppcVar8 + 3) + (int)pcVar5) = '\b';
      *(undefined2 *)(pcVar5 + (int)ppcVar8 + 0xd) = uVar3;
      pcVar5[(int)ppcVar8 + 0xf] = cVar2;
      *(undefined ***)((int)(ppcVar8 + 2) + (int)pcVar5) = &PTR_FUN_0024b308;
      *(char **)((int)(ppcVar8 + 4) + (int)pcVar5) = local_24;
      *(char **)((int)(ppcVar8 + 5) + (int)pcVar5) = pcVar7;
      local_24 = (char *)((int)(ppcVar8 + 2) + (int)pcVar5);
      *(char **)((int)(ppcVar8 + 6) + (int)pcVar5) = pcVar9;
      pcVar5 = *param_3;
      local_28 = param_3[1];
      if (pcVar5 == local_28) {
        return local_24;
      }
      if (*pcVar5 != 'B') {
        return local_24;
      }
    }
  }
  return param_2;
}

