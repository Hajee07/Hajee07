/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00216a28 FUN_00216a28 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void __regparm1 FUN_00216a28(undefined4 param_1_00,undefined4 param_1,undefined4 param_2)

{
  FUN_00216999(param_1,param_2,0,0,param_1_00);
  return;
}

