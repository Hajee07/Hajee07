/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001109a0 FUN_001109a0 */

undefined8
FUN_001109a0(char *param_1,int param_2,char **param_3,char **param_4,char **param_5,char **param_6)

{
  char **ppcVar1;
  char *local_24;
  char *local_20;
  int local_1c;
  char *local_14;
  
  *param_3 = (char *)0x0;
  *param_4 = (char *)0x0;
  *param_6 = (char *)0x0;
  *param_5 = (char *)0x0;
  local_1c = 0;
  local_20 = (char *)0x0;
  local_24 = param_1;
  ppcVar1 = param_5;
  do {
    if (param_1 + param_2 <= local_24) {
      local_14 = (char *)0x0;
LAB_00110b33:
      return CONCAT44(ppcVar1,local_14);
    }
    ppcVar1 = (char **)(&DAT_00281180 + (&switchD_00110a43::switchdataD_00071c34)[*local_24 + -9]);
    switch(*local_24) {
    case '\t':
    case ' ':
      local_20 = (char *)0x0;
      break;
    case '\n':
    case '\r':
      *local_24 = '\0';
      local_14 = local_24 + (1 - (int)param_1);
      goto LAB_00110b33;
    default:
switchD_00110a43_caseD_b:
      if (local_20 == (char *)0x0) {
        local_20 = local_24;
        ppcVar1 = (char **)(&DAT_00281180 + (&switchD_00110ab5::switchdataD_00071cc8)[local_1c]);
        switch(local_1c) {
        case 0:
          *param_3 = local_24;
          break;
        case 1:
          *param_4 = local_24;
          break;
        case 2:
          if (param_1 + param_2 < local_24 + 4) {
            local_14 = (char *)0x0;
            goto LAB_00110b33;
          }
          *param_5 = local_24;
          break;
        case 6:
          *param_6 = local_24;
        }
        local_1c = local_1c + 1;
      }
      break;
    case '-':
      if (local_1c != 1) goto switchD_00110a43_caseD_b;
      local_20 = (char *)0x0;
    }
    local_24 = local_24 + 1;
  } while( true );
}

