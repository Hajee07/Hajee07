/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00208ae0 FUN_00208ae0 */

char * FUN_00208ae0(void)

{
  char cVar1;
  char **ppcVar2;
  int iVar3;
  int iVar4;
  char **ppcVar5;
  int iVar6;
  char **in_ECX;
  char *pcVar7;
  
  pcVar7 = *in_ECX;
  if (((in_ECX[1] == pcVar7) || ((int)in_ECX[1] - (int)pcVar7 == 1)) || (*pcVar7 != 'd')) {
LAB_00208bd3:
    pcVar7 = (char *)FUN_002042b0();
  }
  else {
    cVar1 = pcVar7[1];
    if (cVar1 == 'X') {
      *in_ECX = pcVar7 + 2;
      iVar3 = FUN_002042b0();
      if (iVar3 == 0) {
        return (char *)0x0;
      }
      iVar4 = FUN_002042b0();
      if (iVar4 == 0) {
        return (char *)0x0;
      }
      iVar6 = FUN_00208ae0();
      if (iVar6 == 0) {
        return (char *)0x0;
      }
      ppcVar2 = (char **)in_ECX[0x45b];
      pcVar7 = ppcVar2[1];
      ppcVar5 = ppcVar2;
      if ((char *)0xff7 < pcVar7 + 0x20) {
        ppcVar5 = (char **)FUN_0018add0(0x1000);
        if (ppcVar5 == (char **)0x0) {
LAB_00208d28:
                    /* WARNING: Subroutine does not return */
          FUN_001f9d40();
        }
        *ppcVar5 = (char *)ppcVar2;
        ppcVar5[1] = (char *)0x0;
        in_ECX[0x45b] = (char *)ppcVar5;
        pcVar7 = (char *)0x0;
      }
      ppcVar5[1] = pcVar7 + 0x20;
      *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar7) = 0x1010143;
      *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar7) = &PTR_FUN_0024b068;
      *(int *)((int)(ppcVar5 + 4) + (int)pcVar7) = iVar3;
      *(int *)((int)(ppcVar5 + 5) + (int)pcVar7) = iVar4;
      *(int *)((int)(ppcVar5 + 6) + (int)pcVar7) = iVar6;
    }
    else if (cVar1 == 'x') {
      *in_ECX = pcVar7 + 2;
      iVar3 = FUN_002042b0();
      if (iVar3 == 0) {
        return (char *)0x0;
      }
      iVar4 = FUN_00208ae0();
      if (iVar4 == 0) {
        return (char *)0x0;
      }
      ppcVar2 = (char **)in_ECX[0x45b];
      pcVar7 = ppcVar2[1];
      ppcVar5 = ppcVar2;
      if ((char *)0xff7 < pcVar7 + 0x20) {
        ppcVar5 = (char **)FUN_0018add0(0x1000);
        if (ppcVar5 == (char **)0x0) goto LAB_00208d28;
        *ppcVar5 = (char *)ppcVar2;
        ppcVar5[1] = (char *)0x0;
        in_ECX[0x45b] = (char *)ppcVar5;
        pcVar7 = (char *)0x0;
      }
      ppcVar5[1] = pcVar7 + 0x20;
      *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar7) = 0x1010142;
      *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar7) = &PTR_FUN_0024b030;
      *(int *)((int)(ppcVar5 + 4) + (int)pcVar7) = iVar3;
      *(int *)((int)(ppcVar5 + 5) + (int)pcVar7) = iVar4;
      *(char *)((int)(ppcVar5 + 6) + (int)pcVar7) = '\x01';
    }
    else {
      if (cVar1 != 'i') goto LAB_00208bd3;
      *in_ECX = pcVar7 + 2;
      iVar3 = FUN_0020b6a0();
      if (iVar3 == 0) {
        return (char *)0x0;
      }
      iVar4 = FUN_00208ae0();
      if (iVar4 == 0) {
        return (char *)0x0;
      }
      ppcVar2 = (char **)in_ECX[0x45b];
      pcVar7 = ppcVar2[1];
      ppcVar5 = ppcVar2;
      if ((char *)0xff7 < pcVar7 + 0x20) {
        ppcVar5 = (char **)FUN_0018add0(0x1000);
        if (ppcVar5 == (char **)0x0) goto LAB_00208d28;
        *ppcVar5 = (char *)ppcVar2;
        ppcVar5[1] = (char *)0x0;
        in_ECX[0x45b] = (char *)ppcVar5;
        pcVar7 = (char *)0x0;
      }
      ppcVar5[1] = pcVar7 + 0x20;
      *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar7) = 0x1010142;
      *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar7) = &PTR_FUN_0024b030;
      *(int *)((int)(ppcVar5 + 4) + (int)pcVar7) = iVar3;
      *(int *)((int)(ppcVar5 + 5) + (int)pcVar7) = iVar4;
      *(char *)((int)(ppcVar5 + 6) + (int)pcVar7) = '\0';
    }
    pcVar7 = (char *)((int)(ppcVar5 + 2) + (int)pcVar7);
  }
  return pcVar7;
}

