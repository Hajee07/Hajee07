/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e5b30 FUN_001e5b30 */

undefined4 FUN_001e5b30(char *param_1,int param_2,uint param_3)

{
  char *pcVar1;
  bool bVar2;
  undefined auVar3 [16];
  undefined auVar4 [16];
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  char cVar8;
  uint uVar9;
  char *pcVar10;
  uint uVar11;
  uint uVar12;
  undefined4 uVar13;
  char *pcVar14;
  undefined local_cc [16];
  undefined local_bc [4];
  undefined auStack_b8 [4];
  undefined8 uStack_b4;
  undefined local_ac [12];
  code *pcStack_a0;
  undefined local_9c [4];
  undefined auStack_98 [12];
  undefined4 local_8c;
  undefined *local_88;
  undefined4 *local_84;
  char *local_80;
  undefined local_7c [16];
  undefined local_6c [16];
  undefined local_5c [16];
  undefined local_4c [16];
  undefined local_3c [16];
  undefined local_2c [16];
  
  uVar13 = 0xffffffea;
  if ((param_1 != (char *)0x0) && (*param_1 != '\0')) {
    local_cc = ZEXT816(0);
    local_8c = 0;
    local_84 = (undefined4 *)0x0;
    _local_9c = SUB1612(ZEXT816(0),0);
    auStack_98._8_4_ = FUN_001dd850;
    local_88 = local_cc;
    auVar4._4_4_ = PTR_FUN_0024bd04;
    auVar4._0_4_ = PTR_FUN_0024bd00;
    auVar4._8_8_ = 0;
    _local_ac = auVar4 << 0x40;
    local_9c = (undefined  [4])PTR_FUN_0024bd08;
    _auStack_b8 = SUB1612(ZEXT816(0),4);
    auVar3._12_4_ = 0;
    auVar3._0_12_ = _auStack_b8;
    _local_bc = auVar3 << 0x20;
    local_84 = (undefined4 *)FUN_0018add0(0x54);
    auVar3 = _local_bc;
    if (local_84 == (undefined4 *)0x0) {
      uVar13 = 0xffffffff;
    }
    else {
      local_84[1] = 0;
      *local_84 = 0;
      local_84[2] = 0;
      local_84[5] = 0;
      local_84[4] = 0;
      local_84[6] = 0;
      local_84[9] = 0;
      local_84[8] = 0;
      local_84[10] = 0;
      local_84[0xc] = 0;
      local_84[0xd] = 0;
      local_84[0xf] = 0;
      local_84[0xe] = 0;
      local_84[0x11] = 0;
      local_84[0x10] = 0;
      local_84[0x13] = 0;
      local_84[0x12] = 0;
      local_84[0x14] = 0;
      local_84[3] = 1;
      local_84[7] = 4;
      local_84[0xb] = 4;
      uStack_b4._0_4_ = 1;
      local_bc = auVar3._0_4_;
      auStack_b8 = (undefined  [4])0x2;
      iVar6 = FUN_0018b0c0(param_1,&DAT_00217bf9);
      puVar5 = local_84;
      if (iVar6 == 0) {
        if ((((local_84 != (undefined4 *)0x0) && (local_ac._8_4_ != 0)) &&
            (pcStack_a0 != (code *)0x0)) && (((uint)auStack_b8 & 0xfffffffe) == 2)) {
          local_84 = (undefined4 *)0x0;
          (*pcStack_a0)(auStack_98._0_4_,*puVar5);
          puVar5[1] = 0;
          *puVar5 = 0;
          puVar5[3] = 0;
          puVar5[2] = 0;
          (*pcStack_a0)(auStack_98._0_4_,puVar5[4]);
          puVar5[5] = 0;
          puVar5[4] = 0;
          puVar5[7] = 0;
          puVar5[6] = 0;
          (*pcStack_a0)(auStack_98._0_4_,puVar5[8]);
          puVar5[9] = 0;
          puVar5[8] = 0;
          puVar5[0xb] = 0;
          puVar5[10] = 0;
          if (puVar5[0xf] != 0) {
            if (((int)uStack_b4 == 4) && (iVar6 = FUN_0018b120(puVar5[0xf]), iVar6 == -1)) {
              uStack_b4._4_4_ = 0x15;
            }
            puVar5[0xf] = 0;
          }
          if (((code *)auStack_98._8_4_ == FUN_001dd1e0) && (puVar5[0x12] != 0)) {
            (*pcStack_a0)(auStack_98._0_4_,puVar5[0x12]);
            puVar5[0x12] = 0;
          }
          (*pcStack_a0)(auStack_98._0_4_,puVar5);
        }
        uVar13 = 0xffffffff;
      }
      else {
        local_84[0xf] = iVar6;
        uStack_b4._0_4_ = 4;
        local_7c = ZEXT816(0);
        local_6c = ZEXT816(0);
        local_5c = ZEXT816(0);
        local_4c = ZEXT816(0);
        local_3c = ZEXT816(0);
        local_2c = ZEXT816(0);
        if (param_3 == 0) {
          uVar13 = 0;
        }
        else {
          uVar11 = 0;
          uVar13 = 0;
          while( true ) {
            pcVar1 = *(char **)(param_2 + uVar11 * 4);
            if (pcVar1 == (char *)0x0) {
              uVar13 = 0xfffffffe;
              goto LAB_001e5fdd;
            }
            iVar6 = FUN_0018b240(pcVar1,local_7c);
            if (iVar6 != 0) break;
            uVar12 = local_6c._0_4_ & 0xf000;
            uVar7 = (local_6c._0_4_ & 0xfff) + 0x4000;
            if (uVar12 != 0x4000) {
              uVar7 = local_6c._0_4_ & 0xfff;
            }
            uVar9 = uVar7 - 0x8000;
            if (uVar12 != 0x8000) {
              uVar9 = uVar7;
            }
            uVar7 = uVar9 | 0xffffa000;
            if (uVar12 != 0xa000) {
              uVar7 = uVar9;
            }
            uVar9 = uVar7 | 0x6000;
            if (uVar12 != 0x6000) {
              uVar9 = uVar7;
            }
            uVar7 = uVar9 | 0x2000;
            if (uVar12 != 0x2000) {
              uVar7 = uVar9;
            }
            uVar9 = uVar7 | 0x1000;
            if (uVar12 != 0x1000) {
              uVar9 = uVar7;
            }
            uVar7 = uVar9 | 0xffffc000;
            if (uVar12 != 0xc000) {
              uVar7 = uVar9;
            }
            uVar7 = ((uint)local_6c._0_4_ >> 7 & 1 | uVar7 << 0x10) ^ 1;
            bVar2 = true;
            cVar8 = *pcVar1;
            pcVar14 = pcVar1;
            pcVar10 = pcVar1;
            while( true ) {
              pcVar10 = pcVar10 + 1;
              if (cVar8 != '/') goto LAB_001e5ddc;
              do {
                do {
                  pcVar14 = pcVar10;
                  pcVar10 = pcVar14 + 1;
                  cVar8 = *pcVar14;
                } while (cVar8 == '/');
LAB_001e5ddc:
              } while (cVar8 == '\\');
              if (cVar8 == '\0') break;
              bVar2 = false;
              cVar8 = *pcVar10;
            }
            uVar9 = uVar7 | 0x10;
            if (uVar12 != 0x4000) {
              uVar9 = uVar7;
            }
            if ((*pcVar14 == '\0') && (((*pcVar1 == '\\' || (*pcVar1 == '/')) && (bVar2)))) {
              pcVar14 = pcVar14 + -1;
            }
            local_80 = pcVar1;
            iVar6 = FUN_001e0a40(local_cc,pcVar14,pcVar1,&DAT_00217e63,0,6,uVar9);
            if (iVar6 == 0) {
              uVar13 = 0xffffffed;
            }
            uVar11 = uVar11 + 1;
            if ((param_3 <= uVar11) || (iVar6 == 0)) goto LAB_001e5fdd;
          }
          uVar13 = 0xffffffed;
        }
LAB_001e5fdd:
        FUN_001e1a20(local_cc);
        puVar5 = local_84;
        if (((local_84 != (undefined4 *)0x0) && (local_ac._8_4_ != 0)) &&
           ((pcStack_a0 != (code *)0x0 && (((uint)auStack_b8 & 0xfffffffe) == 2)))) {
          local_84 = (undefined4 *)0x0;
          (*pcStack_a0)(auStack_98._0_4_,*puVar5);
          puVar5[1] = 0;
          *puVar5 = 0;
          puVar5[3] = 0;
          puVar5[2] = 0;
          (*pcStack_a0)(auStack_98._0_4_,puVar5[4]);
          puVar5[5] = 0;
          puVar5[4] = 0;
          puVar5[7] = 0;
          puVar5[6] = 0;
          (*pcStack_a0)(auStack_98._0_4_,puVar5[8]);
          puVar5[9] = 0;
          puVar5[8] = 0;
          puVar5[0xb] = 0;
          puVar5[10] = 0;
          if (puVar5[0xf] != 0) {
            if (((int)uStack_b4 == 4) && (iVar6 = FUN_0018b120(puVar5[0xf]), iVar6 == -1)) {
              uStack_b4._4_4_ = 0x15;
            }
            puVar5[0xf] = 0;
          }
          if (((code *)auStack_98._8_4_ == FUN_001dd1e0) && (puVar5[0x12] != 0)) {
            (*pcStack_a0)(auStack_98._0_4_,puVar5[0x12]);
            puVar5[0x12] = 0;
          }
          (*pcStack_a0)(auStack_98._0_4_,puVar5);
        }
      }
    }
  }
  return uVar13;
}

