/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b68a0 FUN_001b68a0 */

undefined4 FUN_001b68a0(int *param_1,undefined4 param_2,int param_3)

{
  short sVar1;
  ushort uVar2;
  int **ppiVar3;
  bool bVar4;
  int *piVar5;
  char cVar6;
  short sVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  short sVar11;
  int iVar12;
  uint uVar13;
  ushort uVar14;
  int *local_20;
  int local_1c;
  uint uVar15;
  
  sVar1 = *(short *)(param_1 + 3);
  if ((sVar1 != 0) && (param_1[2] != 0)) {
    iVar10 = param_1[1];
    cVar6 = FUN_001b6b80();
    if (cVar6 == '\0') {
      if (iVar10 == 0) {
        local_20 = (int *)FUN_0018b0f0(1,0x3c);
      }
      else {
        iVar8 = FUN_0018af10(iVar10);
        local_20 = (int *)FUN_0018b0f0(1,iVar8 + 0x3c);
        FUN_0018b050(local_20 + 0xe,iVar10);
        sVar1 = *(short *)(param_1 + 3);
        if (sVar1 == 0) {
LAB_001b69fc:
          if (local_20 == (int *)0x0) {
            return 0;
          }
LAB_001b6a04:
          FUN_0018ae20(local_20);
          return 0;
        }
      }
      local_1c = 0;
      sVar11 = 1;
      iVar10 = *(int *)param_1[2];
      piVar9 = (int *)param_1[2] + 4;
joined_r0x001b6958:
      if (iVar10 == 1) {
        iVar10 = local_20[2];
        if (iVar10 == 0) {
          iVar10 = *param_1 + piVar9[-2];
          local_20[2] = iVar10;
          local_1c = iVar10;
        }
        uVar13 = *(uint *)(local_1c + 0x1c);
        uVar15 = piVar9[-3];
        if ((uVar15 <= uVar13) && (uVar13 < uVar15 + *piVar9)) {
          if ((local_1c == 0) ||
             (piVar9 = (int *)((uVar13 - uVar15) + piVar9[-2] + *param_1), piVar9 == (int *)0x0))
          goto LAB_001b6a04;
          uVar2 = *(ushort *)(local_1c + 0x2c);
          uVar13 = (uint)uVar2;
          if (uVar13 == 0) goto switchD_001b6b3c_caseD_0;
          bVar4 = true;
          iVar8 = *piVar9;
          uVar15 = uVar13;
          piVar5 = piVar9 + 2;
          while( true ) {
            if (iVar8 == 1) {
              iVar8 = *piVar5;
              if (bVar4) {
                iVar12 = iVar10 - iVar8;
                local_20[9] = iVar12;
                bVar4 = false;
              }
              else {
                iVar12 = local_20[9];
              }
              local_20[4] = (iVar12 + iVar8) - iVar10;
            }
            uVar14 = (short)uVar15 - 1;
            uVar15 = (uint)uVar14;
            if (uVar14 == 0) break;
            iVar8 = piVar5[6];
            piVar5 = piVar5 + 8;
          }
          if (uVar2 != 0) {
            iVar10 = local_20[9];
            piVar9 = piVar9 + 2;
            do {
              if (piVar9[-2] == 2) {
                piVar9 = (int *)(*piVar9 + 4 + iVar10);
                iVar8 = piVar9[-1];
                goto joined_r0x001b6a87;
              }
              piVar9 = piVar9 + 8;
              uVar13 = uVar13 - 1;
            } while (uVar13 != 0);
          }
switchD_001b6b3c_caseD_0:
          iVar10 = local_20[8];
          if (iVar10 != 0) {
            if ((*(byte *)(iVar10 + 2) & 1) == 0) {
              do {
                    /* WARNING: Do nothing block with infinite loop */
              } while( true );
            }
            local_20[0xd] = local_20[6] + *(int *)(iVar10 + *(int *)(iVar10 + 0xc));
            local_20[0xc] = *(int *)(iVar10 + 8);
          }
          *local_20 = param_3;
          ppiVar3 = *(int ***)(param_3 + 4);
          local_20[1] = (int)ppiVar3;
          *ppiVar3 = local_20;
          *(int **)(param_3 + 4) = local_20;
          return 0;
        }
      }
      sVar7 = (1 - sVar1) + sVar11;
      sVar11 = sVar11 + 1;
      if (sVar7 == 1) goto LAB_001b69fc;
      iVar10 = piVar9[4];
      piVar9 = piVar9 + 8;
      goto joined_r0x001b6958;
    }
  }
  return 0;
joined_r0x001b6a87:
  if (iVar8 < 0x6ffffef5) goto LAB_001b6b2a;
LAB_001b6acc:
  if (iVar8 == 0x6ffffef5) {
    local_20[0xb] = *piVar9 + iVar10;
    goto switchD_001b6b3c_caseD_1;
  }
  if (iVar8 != 0x6ffffff0) {
    if (iVar8 == 0x6ffffffc) {
      local_20[8] = *piVar9 + iVar10;
      iVar8 = piVar9[1];
      piVar9 = piVar9 + 2;
      goto joined_r0x001b6a87;
    }
switchD_001b6b3c_caseD_1:
    iVar8 = piVar9[1];
    do {
      piVar9 = piVar9 + 2;
      if (0x6ffffef4 < iVar8) goto LAB_001b6acc;
LAB_001b6b2a:
      switch(iVar8) {
      case 0:
        goto switchD_001b6b3c_caseD_0;
      default:
        goto switchD_001b6b3c_caseD_1;
      case 4:
        local_20[10] = *piVar9 + iVar10;
        iVar8 = piVar9[1];
        goto joined_r0x001b6b12;
      case 5:
        local_20[6] = *piVar9 + iVar10;
        iVar8 = piVar9[1];
        break;
      case 6:
        local_20[5] = *piVar9 + iVar10;
        iVar8 = piVar9[1];
        goto joined_r0x001b6b12;
      }
    } while( true );
  }
  local_20[7] = *piVar9 + iVar10;
  iVar8 = piVar9[1];
joined_r0x001b6b12:
  piVar9 = piVar9 + 2;
  goto joined_r0x001b6a87;
}

