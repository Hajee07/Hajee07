/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00213cc0 FUN_00213cc0 */

/* WARNING: Function: __i686.get_pc_thunk.cx replaced with injection: get_pc_thunk_cx */

void FUN_00213cc0(void)

{
  DAT_00277094 = 4;
  DAT_00277096 = 4;
  DAT_00277095 = 4;
  DAT_00277097 = 4;
  DAT_0027709a = 4;
  DAT_0027709b = 4;
  DAT_00277099 = 4;
  DAT_00277098 = 4;
  DAT_0027709f = 0xc;
  DAT_002770a0 = 0xc;
  DAT_002770a1 = 0xc;
  DAT_002770a2 = 0xc;
  DAT_002770a3 = 0xc;
  DAT_002770a4 = 0xc;
  DAT_0027709d = 4;
  DAT_0027709c = 4;
  return;
}

