/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f3db0 FUN_001f3db0 */

void FUN_001f3db0(void)

{
  code *pcVar1;
  uint uVar2;
  
  pcVar1 = (code *)thunk_FUN_001f3ee5();
  uVar2 = (*pcVar1)();
  if (0xfffff000 < uVar2) {
    thunk_FUN_001f3ec5(-uVar2);
  }
  return;
}

