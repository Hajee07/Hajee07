/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00209410 FUN_00209410 */

void FUN_00209410(int param_1,int *param_2)

{
  uint uVar1;
  char cVar2;
  undefined *puVar3;
  char cVar4;
  char cVar5;
  char *pcVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  char cVar10;
  char *pcVar11;
  int iVar12;
  char acStack_47 [4];
  char cStack_43;
  char acStack_42 [2];
  undefined local_40 [16];
  undefined local_30 [16];
  int local_18;
  
  puVar3 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(int *)PTR___stack_chk_guard_0024bd6c;
  pcVar11 = *(char **)(param_1 + 8);
  if (0x10 < (*(int *)(param_1 + 0xc) - (int)pcVar11) + 1U) {
    cVar4 = -0x57;
    if ((int)pcVar11[1] - 0x30U < 10) {
      cVar4 = -0x30;
    }
    cVar5 = -0x57;
    if ((int)pcVar11[3] - 0x30U < 10) {
      cVar5 = -0x30;
    }
    acStack_47[0] =
         ((9 < (int)pcVar11[2] - 0x30U) * '\t' + pcVar11[2]) * '\x10' + cVar5 + pcVar11[3];
    cVar5 = -0x57;
    if ((int)pcVar11[5] - 0x30U < 10) {
      cVar5 = -0x30;
    }
    acStack_47[1] =
         ((9 < (int)pcVar11[4] - 0x30U) * '\t' + pcVar11[4]) * '\x10' + cVar5 + pcVar11[5];
    cVar5 = -0x57;
    if ((int)pcVar11[7] - 0x30U < 10) {
      cVar5 = -0x30;
    }
    acStack_47[2] =
         ((9 < (int)pcVar11[6] - 0x30U) * '\t' + pcVar11[6]) * '\x10' + cVar5 + pcVar11[7];
    cVar5 = -0x57;
    if ((int)pcVar11[9] - 0x30U < 10) {
      cVar5 = -0x30;
    }
    acStack_47[3] =
         ((9 < (int)pcVar11[8] - 0x30U) * '\t' + pcVar11[8]) * '\x10' + cVar5 + pcVar11[9];
    cVar5 = -0x57;
    if ((int)pcVar11[0xb] - 0x30U < 10) {
      cVar5 = -0x30;
    }
    cStack_43 = ((9 < (int)pcVar11[10] - 0x30U) * '\t' + pcVar11[10]) * '\x10' +
                cVar5 + pcVar11[0xb];
    cVar5 = -0x57;
    if ((int)pcVar11[0xd] - 0x30U < 10) {
      cVar5 = -0x30;
    }
    acStack_42[0] =
         ((9 < (int)pcVar11[0xc] - 0x30U) * '\t' + pcVar11[0xc]) * '\x10' + cVar5 + pcVar11[0xd];
    cVar5 = pcVar11[0xe];
    cVar2 = pcVar11[0xf];
    cVar10 = -0x57;
    if ((int)cVar2 - 0x30U < 10) {
      cVar10 = -0x30;
    }
    pcVar6 = acStack_47;
    acStack_42[1] = ((9 < (int)*pcVar11 - 0x30U) * '\t' + *pcVar11) * '\x10' + cVar4 + pcVar11[1];
    pcVar11 = acStack_42;
    do {
      pcVar6 = pcVar6 + 1;
      cVar4 = pcVar6[-1];
      pcVar6[-1] = *pcVar11;
      *pcVar11 = cVar4;
      pcVar11 = pcVar11 + -1;
    } while (pcVar6 < pcVar11);
    local_30 = ZEXT816(0);
    local_40 = ZEXT816(0);
    iVar7 = FUN_0018ae50(local_40,0x20,&DAT_0021a484,
                         CONCAT17(acStack_42[1],
                                  CONCAT16(acStack_42[0],
                                           CONCAT15(cStack_43,
                                                    CONCAT14(acStack_47[3],
                                                             CONCAT13(acStack_47[2],
                                                                      CONCAT12(acStack_47[1],
                                                                               CONCAT11(acStack_47
                                                                                        [0],((9 < (
                                                  int)cVar5 - 0x30U) * '\t' + cVar5) * '\x10' +
                                                  cVar10 + cVar2))))))));
    if (iVar7 != 0) {
      iVar12 = param_2[1];
      uVar1 = iVar12 + iVar7;
      if (uVar1 < (uint)param_2[2]) {
        iVar9 = *param_2;
      }
      else {
        uVar8 = param_2[2] * 2;
        if (uVar8 < uVar1) {
          uVar8 = uVar1;
        }
        param_2[2] = uVar8;
        iVar9 = FUN_0018b200(*param_2,uVar8);
        *param_2 = iVar9;
        if (iVar9 == 0) {
                    /* WARNING: Subroutine does not return */
          FUN_001f9d40();
        }
        iVar12 = param_2[1];
      }
      FUN_0018ae40(iVar12 + iVar9,local_40,iVar7);
      param_2[1] = param_2[1] + iVar7;
    }
  }
  if (*(int *)puVar3 != local_18) {
                    /* WARNING: Subroutine does not return */
    FUN_0018adc0();
  }
  return;
}

