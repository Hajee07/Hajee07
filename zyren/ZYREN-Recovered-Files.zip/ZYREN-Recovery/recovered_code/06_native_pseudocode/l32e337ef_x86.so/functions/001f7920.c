/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7920 FUN_001f7920 */

void FUN_001f7920(undefined4 param_1)

{
                    /* try { // try from 001f7939 to 001f7940 has its CatchHandler @ 001f7947 */
  FUN_0018b4f0(param_1);
  return;
}

