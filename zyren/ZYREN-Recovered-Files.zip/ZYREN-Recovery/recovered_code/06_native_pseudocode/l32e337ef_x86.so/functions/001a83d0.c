/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a83d0 FUN_001a83d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_001a83d0(undefined4 param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  byte local_100;
  uint local_fc;
  undefined4 local_f8;
  undefined4 local_f4;
  int local_f0;
  undefined4 local_ec;
  int local_e8;
  undefined local_e4 [4];
  byte local_e0;
  undefined4 local_dc;
  uint uStack_d8;
  int iStack_d4;
  undefined4 uStack_d0;
  undefined4 local_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 local_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 local_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 local_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 local_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 local_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 local_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  
  if (DAT_00273e90 == (code *)0x0) {
    local_e8 = 0;
    local_dc = 0x60616b6d;
    uStack_d8 = 0x61617e60;
    iStack_d4 = 0x7f256f65;
    uStack_d0 = CONCAT22(uStack_d0._2_2_,0x62);
    local_fc = 0;
    do {
      *(byte *)((int)&local_dc + local_fc) =
           (char)local_fc + 1U ^ *(byte *)((int)&local_dc + local_fc);
      local_fc = local_fc + 1;
    } while (local_fc < 0xd);
    uStack_d0._0_2_ = (ushort)(byte)uStack_d0;
    iVar3 = FUN_001abcb0(&local_dc,&local_e8);
    if (iVar3 != 0) {
      local_dc = _DAT_0021acc0;
      uStack_d8 = _UNK_0021acc4;
      iStack_d4 = _UNK_0021acc8;
      uStack_d0 = _UNK_0021accc;
      local_cc = _DAT_0021acd0;
      uStack_c8 = _UNK_0021acd4;
      uStack_c4 = _UNK_0021acd8;
      uStack_c0 = _UNK_0021acdc;
      local_bc = _DAT_0021ace0;
      uStack_b8 = _UNK_0021ace4;
      uStack_b4 = _UNK_0021ace8;
      uStack_b0 = _UNK_0021acec;
      local_ac = _DAT_0021acf0;
      uStack_a8 = _UNK_0021acf4;
      uStack_a4 = _UNK_0021acf8;
      uStack_a0 = _UNK_0021acfc;
      local_9c = _DAT_0021ad00;
      uStack_98 = _UNK_0021ad04;
      uStack_94 = _UNK_0021ad08;
      uStack_90 = _UNK_0021ad0c;
      local_8c = _DAT_0021ad10;
      uStack_88 = _UNK_0021ad14;
      uStack_84 = _UNK_0021ad18;
      uStack_80 = _UNK_0021ad1c;
      local_7c = _DAT_0021ad20;
      uStack_78 = _UNK_0021ad24;
      uStack_74 = _UNK_0021ad28;
      uStack_70 = _UNK_0021ad2c;
      local_6c = _DAT_0021ad30;
      uStack_68 = _UNK_0021ad34;
      uStack_64 = _UNK_0021ad38;
      uStack_60 = _UNK_0021ad3c;
      local_5c = _DAT_0021ad40;
      uStack_58 = _UNK_0021ad44;
      uStack_54 = _UNK_0021ad48;
      uStack_50 = _UNK_0021ad4c;
      local_4c = _DAT_0021ad50;
      uStack_48 = _UNK_0021ad54;
      uStack_44 = _UNK_0021ad58;
      uStack_40 = _UNK_0021ad5c;
      local_3c = _DAT_0021ad60;
      uStack_38 = _UNK_0021ad64;
      uStack_34 = _UNK_0021ad68;
      uStack_30 = _UNK_0021ad6c;
      local_2c = _DAT_0021ad70;
      uStack_28 = _UNK_0021ad74;
      uStack_24 = _UNK_0021ad78;
      uStack_20 = _UNK_0021ad7c;
      local_fc = 0;
      do {
        *(byte *)((int)&local_dc + local_fc) =
             (char)local_fc + 1U ^ *(byte *)((int)&local_dc + local_fc);
        local_fc = local_fc + 1;
      } while (local_fc < 0xbf);
      pcVar2 = (code *)FUN_001f0dd0(iVar3,&local_dc,0);
      if (pcVar2 == (code *)0x0) {
        pcVar2 = (code *)FUN_001b62a0(&local_dc);
      }
      DAT_00273e90 = pcVar2;
      if (local_e8 != 0) {
        FUN_001f0d70(iVar3);
      }
      if (DAT_00273e90 == (code *)0x0) {
        return 0;
      }
    }
  }
  pcVar2 = DAT_00273e90;
  if (DAT_00273e90 == (code *)0x0) {
    return 0;
  }
  local_e8 = 0;
  uStack_d8 = 0;
  local_dc = 0;
  iStack_d4 = 0;
  uVar1 = FUN_0018af10(param_1);
  if (0xffffffef < uVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_001a6e40(&local_dc);
  }
  if (uVar1 < 0xb) {
    local_dc = CONCAT31(local_dc._1_3_,(char)uVar1 * '\x02');
    iVar3 = (int)&local_dc + 1;
    if (uVar1 == 0) goto LAB_001a8651;
  }
  else {
    uVar4 = uVar1 + 0x10 & 0xfffffff0;
    iVar3 = FUN_001f5520(uVar4);
    local_dc = uVar4 | 1;
    uStack_d8 = uVar1;
    iStack_d4 = iVar3;
  }
  FUN_0018ae80(iVar3,param_1,uVar1);
LAB_001a8651:
  *(undefined *)(iVar3 + uVar1) = 0;
  local_f8 = 0;
  local_fc = 0;
  local_f4 = 0;
  local_ec = 0;
                    /* try { // try from 001a8681 to 001a86d7 has its CatchHandler @ 001a875f */
  (*pcVar2)(local_e4,&local_e8,param_2,param_3,&local_dc,*(undefined4 *)(param_2 + 8),0,0,0,
            &local_fc,&local_ec);
  iVar3 = local_f0;
  local_f0 = 0;
  if (iVar3 != 0) {
    FUN_001f5680(iVar3);
  }
  iVar3 = local_e8;
  if (local_e8 == 0) {
    iVar3 = 0;
  }
  local_e8 = 0;
  if ((local_100 & 1) != 0) {
    FUN_001f5680(local_f8);
  }
  if ((local_e0 & 1) != 0) {
    FUN_001f5680(uStack_d8);
    return iVar3;
  }
  return iVar3;
}

