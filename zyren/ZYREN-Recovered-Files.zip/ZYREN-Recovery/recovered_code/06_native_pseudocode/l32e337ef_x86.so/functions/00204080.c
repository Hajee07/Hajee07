/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00204080 FUN_00204080 */

undefined FUN_00204080(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined uVar2;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(undefined *)(param_1 + 0x10) = 1;
    piVar1 = *(int **)(param_1 + 0xc);
    if (*(char *)((int)piVar1 + 6) == '\x02') {
                    /* try { // try from 002040bb to 002040c3 has its CatchHandler @ 002040da */
      uVar2 = (**(code **)(*piVar1 + 4))(piVar1,param_2);
    }
    else {
      uVar2 = *(char *)((int)piVar1 + 6) == '\0';
    }
    *(undefined *)(param_1 + 0x10) = 0;
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

