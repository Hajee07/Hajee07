/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000d2920 FUN_000d2920 */

uint FUN_000d2920(int *param_1,uint param_2)

{
  int iVar1;
  bool bVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 uVar7;
  uint local_28;
  int local_24;
  undefined4 local_20;
  int local_1c;
  uint local_18;
  uint local_14;
  
  uVar7 = 0xd292c;
  uVar3 = 0xfffffffe;
  if ((param_1 != (int *)0x0) && (iVar1 = param_1[7], iVar1 != 0)) {
    local_18 = 2;
    if (param_2 != 1) {
      local_18 = param_2;
    }
    if ((local_18 < 5) && ((0x15U >> (local_18 & 0x1f) & 1) != 0)) {
      bVar2 = 0 < *(int *)(iVar1 + 0x2b00);
      local_20 = CONCAT31(local_20._1_3_,bVar2);
      local_24 = param_1[1];
      local_1c = *(int *)(iVar1 + 11000);
      *(undefined4 *)(iVar1 + 11000) = 0;
      if (-1 < *(int *)(iVar1 + 0xab04)) {
        if ((local_18 != 4) && (*(uint *)(iVar1 + 0x2afc) != 0)) {
          return 0xfffffffe;
        }
        uVar3 = (uint)bVar2;
        *(uint *)(iVar1 + 0x2afc) = *(uint *)(iVar1 + 0x2afc) | (uint)(local_18 == 4);
        if ((local_18 == 4) && (local_1c != 0)) {
          local_28 = param_1[4];
          iVar4 = FUN_000d2d50(iVar1,*param_1,&local_24,param_1[3],param_1[3],&local_28,uVar3 | 0xc,
                               0xd292c);
          *(int *)(iVar1 + 0xab04) = iVar4;
          *param_1 = *param_1 + local_24;
          param_1[1] = param_1[1] - local_24;
          param_1[2] = param_1[2] + local_24;
          param_1[0xc] = *(int *)(iVar1 + 0x1c);
          param_1[3] = param_1[3] + local_28;
          param_1[4] = param_1[4] - local_28;
          param_1[5] = param_1[5] + local_28;
          if (iVar4 < 0) {
            return 0xfffffffd;
          }
          if (iVar4 != 0) {
            *(undefined4 *)(iVar1 + 0xab04) = 0xffffffff;
            return 0xfffffffb;
          }
          return 1;
        }
        local_14 = uVar3 | 10;
        if (local_18 == 4) {
          local_14 = uVar3 | 8;
        }
        uVar3 = *(uint *)(iVar1 + 0x2af4);
        if (uVar3 != 0) {
          uVar6 = param_1[4];
          if (uVar3 < (uint)param_1[4]) {
            uVar6 = uVar3;
          }
          FUN_000fe898(param_1[3],iVar1 + 0x2b04 + *(int *)(iVar1 + 0x2af0),uVar6);
          param_1[3] = param_1[3] + uVar6;
          param_1[4] = param_1[4] - uVar6;
          param_1[5] = param_1[5] + uVar6;
          iVar4 = *(int *)(iVar1 + 0x2af4) - uVar6;
          *(int *)(iVar1 + 0x2af4) = iVar4;
          *(uint *)(iVar1 + 0x2af0) = uVar6 + *(int *)(iVar1 + 0x2af0) & 0x7fff;
          if (*(int *)(iVar1 + 0xab04) != 0) {
            return 0;
          }
LAB_000d2ae3:
          return (uint)(iVar4 == 0);
        }
        local_20 = iVar1 + 0x2b04;
        uVar3 = *(uint *)(iVar1 + 0x2af0);
        if (local_24 == 0) {
          local_24 = 0;
          while( true ) {
            local_28 = 0x8000 - uVar3;
            local_1c = FUN_000d2d50(iVar1,*param_1,&local_24,local_20,iVar1 + 0x2b04 + uVar3,
                                    &local_28,local_14,uVar7);
            *(int *)(iVar1 + 0xab04) = local_1c;
            *param_1 = *param_1 + local_24;
            param_1[1] = param_1[1] - local_24;
            param_1[2] = param_1[2] + local_24;
            param_1[0xc] = *(int *)(iVar1 + 0x1c);
            *(uint *)(iVar1 + 0x2af4) = local_28;
            uVar3 = param_1[4];
            if (local_28 < (uint)param_1[4]) {
              uVar3 = local_28;
            }
            FUN_000fe898(param_1[3],*(int *)(iVar1 + 0x2af0) + local_20,uVar3);
            param_1[3] = param_1[3] + uVar3;
            iVar5 = param_1[4] - uVar3;
            param_1[4] = iVar5;
            param_1[5] = param_1[5] + uVar3;
            iVar4 = *(int *)(iVar1 + 0x2af4) - uVar3;
            *(int *)(iVar1 + 0x2af4) = iVar4;
            uVar3 = uVar3 + *(int *)(iVar1 + 0x2af0) & 0x7fff;
            *(uint *)(iVar1 + 0x2af0) = uVar3;
            if (local_1c < 0) break;
            if (local_1c == 1) {
              return 0xfffffffb;
            }
            if (local_18 == 4) {
              if (local_1c == 0) {
LAB_000d2d33:
                if (iVar4 == 0) {
                  return 1;
                }
                return 0xfffffffb;
              }
              if (iVar5 == 0) {
                return 0xfffffffb;
              }
              local_24 = param_1[1];
            }
            else {
              if (local_1c == 0) goto LAB_000d2ae3;
              if (iVar4 != 0) {
                return 0;
              }
              if (iVar5 == 0) {
                return 0;
              }
              local_24 = param_1[1];
              if (local_24 == 0) {
                return 0;
              }
            }
          }
        }
        else {
          while( true ) {
            local_28 = 0x8000 - uVar3;
            local_1c = FUN_000d2d50(iVar1,*param_1,&local_24,local_20,iVar1 + 0x2b04 + uVar3,
                                    &local_28,local_14,uVar7);
            *(int *)(iVar1 + 0xab04) = local_1c;
            *param_1 = *param_1 + local_24;
            param_1[1] = param_1[1] - local_24;
            param_1[2] = param_1[2] + local_24;
            param_1[0xc] = *(int *)(iVar1 + 0x1c);
            *(uint *)(iVar1 + 0x2af4) = local_28;
            uVar3 = param_1[4];
            if (local_28 < (uint)param_1[4]) {
              uVar3 = local_28;
            }
            FUN_000fe898(param_1[3],*(int *)(iVar1 + 0x2af0) + local_20,uVar3);
            param_1[3] = param_1[3] + uVar3;
            iVar5 = param_1[4] - uVar3;
            param_1[4] = iVar5;
            param_1[5] = param_1[5] + uVar3;
            iVar4 = *(int *)(iVar1 + 0x2af4) - uVar3;
            *(int *)(iVar1 + 0x2af4) = iVar4;
            uVar3 = uVar3 + *(int *)(iVar1 + 0x2af0) & 0x7fff;
            *(uint *)(iVar1 + 0x2af0) = uVar3;
            if (local_1c < 0) break;
            if (local_18 == 4) {
              if (local_1c == 0) goto LAB_000d2d33;
              if (iVar5 == 0) {
                return 0xfffffffb;
              }
              local_24 = param_1[1];
            }
            else {
              if (local_1c == 0) goto LAB_000d2ae3;
              if (iVar4 != 0) {
                return 0;
              }
              if (iVar5 == 0) {
                return 0;
              }
              local_24 = param_1[1];
              if (local_24 == 0) {
                return 0;
              }
            }
          }
        }
      }
      uVar3 = 0xfffffffd;
    }
  }
  return uVar3;
}

