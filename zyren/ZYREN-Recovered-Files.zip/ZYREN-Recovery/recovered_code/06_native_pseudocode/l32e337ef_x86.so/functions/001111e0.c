/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001111e0 FUN_001111e0 */

undefined4 FUN_001111e0(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int local_3c;
  undefined4 *local_28;
  ushort local_1e;
  int local_1c;
  int local_18;
  
  if ((*(short *)(param_1 + 3) != 0) && (param_1[2] != 0)) {
    local_18 = 0;
    local_1c = 0;
    for (local_1e = 0; local_1e != *(ushort *)(param_1 + 3); local_1e = local_1e + 1) {
      if (*(int *)(param_1[2] + (uint)local_1e * 0x20) == 1) {
        if (local_1c == 0) {
          local_1c = *(int *)(param_1[2] + (uint)local_1e * 0x20 + 8) + *param_1;
        }
        if ((*(uint *)(param_1[2] + (uint)local_1e * 0x20 + 4) <= *(uint *)(local_1c + 0x1c)) &&
           (*(uint *)(local_1c + 0x1c) <
            (uint)(*(int *)(param_1[2] + (uint)local_1e * 0x20 + 4) +
                  *(int *)(param_1[2] + (uint)local_1e * 0x20 + 0x10)))) {
          local_18 = (*(int *)(local_1c + 0x1c) - *(int *)(param_1[2] + (uint)local_1e * 0x20 + 4))
                     + *(int *)(param_1[2] + (uint)local_1e * 0x20 + 8) + *param_1;
          break;
        }
      }
    }
    if ((local_1c != 0) && (local_18 != 0)) {
      for (local_28 = (undefined4 *)*param_3; local_28 != param_3;
          local_28 = (undefined4 *)*local_28) {
        if (local_28[2] == local_1c) {
          return 0;
        }
      }
      if (param_1[1] == 0) {
        local_3c = 0;
      }
      else {
        local_3c = FUN_00054684(param_1[1]);
      }
      puVar1 = (undefined4 *)FUN_000546a2(1,local_3c + 0x40);
      puVar1[2] = local_1c;
      if (param_1[1] != 0) {
        FUN_00054666((int)puVar1 + 0x3d,param_1[1]);
      }
      FUN_00111480(puVar1,local_18,*(undefined2 *)(local_1c + 0x2c));
      *puVar1 = param_3;
      puVar1[1] = param_3[1];
      *(undefined4 **)puVar1[1] = puVar1;
      param_3[1] = puVar1;
    }
  }
  return 0;
}

