/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bb410 FUN_001bb410 */

undefined4 FUN_001bb410(int *param_1,int param_2)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  iVar2 = *(int *)(param_2 + 8);
  uVar1 = **(ushort **)(param_2 + 0x28);
  uVar4 = uVar1 >> 8 & 0xf;
  iVar3 = *(int *)(iVar2 + uVar4 * 0xc);
  if (((iVar3 == 0x4000) || (iVar3 == 0x100)) &&
     (iVar3 = *(int *)(iVar2 + 4 + uVar4 * 0xc), iVar3 != 0)) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar3);
  }
  *(undefined4 *)(iVar2 + uVar4 * 0xc) = 0x1000;
  *(undefined4 *)(iVar2 + 8 + uVar4 * 0xc) = 0;
  uVar5 = uVar1 >> 0xc | 0xfffffff8;
  if (-1 < (short)uVar1) {
    uVar5 = (uint)(uVar1 >> 0xc);
  }
  *(uint *)(iVar2 + 4 + uVar4 * 0xc) = uVar5;
  return 0;
}

