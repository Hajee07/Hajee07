/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ecc70 FUN_001ecc70 */

void FUN_001ecc70(void)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  uint local_3c;
  undefined4 local_38;
  undefined local_34;
  undefined2 uStack_33;
  undefined uStack_31;
  uint local_2c;
  undefined4 local_28;
  undefined4 *local_24;
  uint local_1c;
  undefined4 local_18;
  undefined4 *local_14;
  
  if (DAT_00276da8 == (int *)0x0) {
    uVar1 = thunk_FUN_001eba55();
    local_14 = (undefined4 *)FUN_001f5520(0x10);
    local_1c = 0x11;
    local_18 = 0xe;
    *(undefined2 *)(local_14 + 3) = 0x7265;
    local_14[2] = 0x64616f4c;
    local_14[1] = 0x7373616c;
    *local_14 = 0x43746567;
    *(undefined *)((int)local_14 + 0xe) = 0;
                    /* try { // try from 001eccd5 to 001eccec has its CatchHandler @ 001ece3d */
    iVar2 = FUN_001ece60(uVar1,&local_1c,1);
    if ((local_1c & 1) != 0) {
      FUN_001f5680(local_14);
    }
    piVar3 = (int *)FUN_001f5520(4);
    *piVar3 = 0;
    DAT_00276da8 = piVar3;
    piVar4 = (int *)FUN_001eba70();
    if (*piVar3 != 0) {
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x58))(piVar4,*piVar3);
      }
      *piVar3 = 0;
    }
    if ((iVar2 != 0) && (piVar4 != (int *)0x0)) {
      iVar2 = (**(code **)(*piVar4 + 0x54))(piVar4,iVar2);
      *piVar3 = iVar2;
    }
    local_24 = (undefined4 *)FUN_001f5520(0x20);
    local_2c = 0x21;
    local_28 = 0x15;
    *(undefined2 *)(local_24 + 5) = 0x72;
    local_24[4] = 0x6564616f;
    local_24[3] = 0x4c737361;
    local_24[2] = 0x6c432f67;
    local_24[1] = 0x6e616c2f;
    *local_24 = 0x6176616a;
    uStack_31 = 0;
    uStack_33 = 0x73;
    local_3c = 0x6e696612;
    local_38 = 0x616c4364;
    local_34 = 0x73;
                    /* try { // try from 001ecdd3 to 001ecde6 has its CatchHandler @ 001ece1b */
    DAT_00276dac = FUN_001ed1f0(&local_2c,&local_3c);
    if ((local_3c & 1) != 0) {
      FUN_001f5680(CONCAT13(uStack_31,CONCAT21(uStack_33,local_34)));
    }
    if ((local_2c & 1) != 0) {
      FUN_001f5680(local_24);
    }
  }
  return;
}

