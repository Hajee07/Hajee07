/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e2ff0 FUN_001e2ff0 */

void FUN_001e2ff0(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != (undefined4 *)0x0) {
    FUN_001e1a20(param_1);
    uVar1 = *param_1;
    if (((((code *)param_1[0xf] != FUN_001dd1e0) || (*(int *)(param_1[0x12] + 0x48) == 0)) &&
        (param_1[5] == 3)) && (iVar2 = *(int *)(param_1[0x12] + 0x3c), iVar2 != 0)) {
      uVar3 = FUN_0018b310(iVar2);
      FUN_0018b320(uVar3,uVar1);
    }
    FUN_001dd2d0();
    FUN_001d7270();
    FUN_0018ae20(param_1);
  }
  return;
}

