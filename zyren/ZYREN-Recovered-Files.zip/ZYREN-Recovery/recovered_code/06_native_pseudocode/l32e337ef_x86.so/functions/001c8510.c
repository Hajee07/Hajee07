/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c8510 FUN_001c8510 */

undefined4 FUN_001c8510(int param_1,int param_2,uint param_3)

{
  if (param_2 != 0) {
    return 0xffffffd8;
  }
  *(uint *)(param_1 + 0x5d00) = -(uint)(param_3 == 0) | param_3;
  return 0;
}

