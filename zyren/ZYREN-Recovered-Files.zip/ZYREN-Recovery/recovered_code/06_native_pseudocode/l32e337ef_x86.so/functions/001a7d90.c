/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a7d90 FUN_001a7d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_001a7d90(undefined4 param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint local_9c;
  undefined4 local_98;
  undefined4 local_94;
  int local_90;
  undefined4 local_8c;
  uint uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 local_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 local_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  
  if (DAT_00273e88 == (code *)0x0) {
    local_90 = 0;
    local_8c = 0x65616b6d;
    uStack_88 = 0x7b297277;
    uStack_84 = CONCAT22(uStack_84._2_2_,0x66);
    local_9c = 0;
    do {
      *(byte *)((int)&local_8c + local_9c) =
           (char)local_9c + 1U ^ *(byte *)((int)&local_8c + local_9c);
      local_9c = local_9c + 1;
    } while (local_9c < 9);
    uStack_84._0_2_ = (ushort)(byte)uStack_84;
    iVar3 = FUN_001abcb0(&local_8c,&local_90);
    if (iVar3 != 0) {
      local_8c = _DAT_0021ac40;
      uStack_88 = _UNK_0021ac44;
      uStack_84 = _UNK_0021ac48;
      uStack_80 = _UNK_0021ac4c;
      local_7c = _DAT_0021ac50;
      uStack_78 = _UNK_0021ac54;
      uStack_74 = _UNK_0021ac58;
      uStack_70 = _UNK_0021ac5c;
      local_6c = _DAT_0021ac60;
      uStack_68 = _UNK_0021ac64;
      uStack_64 = _UNK_0021ac68;
      uStack_60 = _UNK_0021ac6c;
      local_5c = _DAT_0021ac70;
      uStack_58 = _UNK_0021ac74;
      uStack_54 = _UNK_0021ac78;
      uStack_50 = _UNK_0021ac7c;
      local_4c = _DAT_0021ac80;
      uStack_48 = _UNK_0021ac84;
      uStack_44 = _UNK_0021ac88;
      uStack_40 = _UNK_0021ac8c;
      local_3c = _DAT_0021ac90;
      uStack_38 = _UNK_0021ac94;
      uStack_34 = _UNK_0021ac98;
      uStack_30 = _UNK_0021ac9c;
      local_2c = _DAT_0021aca0;
      uStack_28 = _UNK_0021aca4;
      uStack_24 = _UNK_0021aca8;
      uStack_20 = _UNK_0021acac;
      local_1c = 0x2c4b22;
      local_9c = 0;
      do {
        *(byte *)((int)&local_8c + local_9c) =
             (char)local_9c + 1U ^ *(byte *)((int)&local_8c + local_9c);
        local_9c = local_9c + 1;
      } while (local_9c < 0x73);
      pcVar2 = (code *)FUN_001f0dd0(iVar3,&local_8c,0);
      if (pcVar2 == (code *)0x0) {
        pcVar2 = (code *)FUN_001b62a0(&local_8c);
      }
      DAT_00273e88 = pcVar2;
      if (local_90 != 0) {
        FUN_001f0d70(iVar3);
      }
      if (DAT_00273e88 == (code *)0x0) {
        return 0;
      }
    }
  }
  pcVar2 = DAT_00273e88;
  if (DAT_00273e88 == (code *)0x0) {
    return 0;
  }
  uStack_88 = 0;
  local_8c = 0;
  uStack_84 = 0;
  uVar1 = FUN_0018af10(param_1);
  if (0xffffffef < uVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_001a6e40(&local_8c);
  }
  if (uVar1 < 0xb) {
    local_8c = CONCAT31(local_8c._1_3_,(char)uVar1 * '\x02');
    iVar3 = (int)&local_8c + 1;
    if (uVar1 == 0) goto LAB_001a7faf;
  }
  else {
    uVar5 = uVar1 + 0x10 & 0xfffffff0;
    iVar3 = FUN_001f5520(uVar5);
    local_8c = uVar5 | 1;
    uStack_88 = uVar1;
    uStack_84 = iVar3;
  }
  FUN_0018ae80(iVar3,param_1,uVar1);
LAB_001a7faf:
  *(undefined *)(iVar3 + uVar1) = 0;
  local_98 = 0;
  local_9c = 0;
  local_94 = 0;
                    /* try { // try from 001a7fd7 to 001a8002 has its CatchHandler @ 001a8059 */
  uVar4 = (*pcVar2)(param_2,param_3,&local_8c,*(undefined4 *)(param_2 + 8),0,&local_9c);
  if ((local_9c & 1) != 0) {
    FUN_001f5680(local_94);
  }
  if ((local_8c & 1) != 0) {
    FUN_001f5680(uStack_84);
    return uVar4;
  }
  return uVar4;
}

