/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b7aa0 FUN_001b7aa0 */

int FUN_001b7aa0(int *param_1,int param_2,int param_3,int param_4,ushort *param_5,undefined4 param_6
                )

{
  undefined4 *puVar1;
  double *pdVar2;
  ushort uVar3;
  char cVar4;
  undefined uVar5;
  short sVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  float fVar10;
  uint uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  uint uVar14;
  int iVar15;
  char *pcVar16;
  longdouble lVar17;
  double dVar18;
  int local_34;
  
  uVar3 = *param_5;
  iVar8 = (uint)uVar3 * 0xc + 0xc;
  iVar7 = FUN_0018add0(iVar8);
  if (iVar7 == 0) {
    FUN_001b7f40("fail to new slots\n");
                    /* WARNING: Subroutine does not return */
    FUN_0018b160();
  }
  FUN_0018ae30(iVar7,0,iVar8);
  pcVar16 = (char *)(*(int *)(param_3 + 0x2c) +
                    *(int *)(*(int *)(param_3 + 8) +
                            *(int *)(*(int *)(param_3 + 0x18) +
                                    (uint)*(ushort *)(*(int *)(param_3 + 0x14) + 2 + param_4 * 8) *
                                    0xc) * 4));
  do {
    cVar4 = *pcVar16;
    pcVar16 = pcVar16 + 1;
  } while (cVar4 < '\0');
  local_34 = (uint)uVar3 - (uint)param_5[1];
  iVar8 = FUN_0018af10(pcVar16);
  uVar14 = *(uint *)(param_2 + 0x24) >> 1 & 1;
  if ((*(uint *)(param_2 + 0x24) & 1) != 0) {
    *(undefined4 *)(iVar7 + local_34 * 0xc) = 0x100;
    uVar9 = (**(code **)(*param_1 + 0x2b4))(param_1,param_6,uVar14);
    *(undefined4 *)(iVar7 + 4 + local_34 * 0xc) = uVar9;
    local_34 = local_34 + 1;
  }
  if (1 < iVar8) {
    iVar15 = 1;
    do {
      uVar9 = (**(code **)(*param_1 + 0x2b4))
                        (param_1,param_6,(uVar14 + iVar15) - (~*(uint *)(param_2 + 0x24) & 1));
      *(undefined4 *)(iVar7 + 8 + local_34 * 0xc) = 0;
      *(undefined4 *)(iVar7 + 4 + local_34 * 0xc) = 0;
      puVar1 = (undefined4 *)(iVar7 + local_34 * 0xc);
      pdVar2 = (double *)(iVar7 + 4 + local_34 * 0xc);
      switch(pcVar16[iVar15]) {
      case 'B':
        *puVar1 = 2;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"byteValue",&DAT_0021863c);
        cVar4 = FUN_001c4290(param_1,uVar9,uVar13);
        fVar10 = (float)(int)cVar4;
        break;
      case 'C':
        *puVar1 = 4;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"charValue",&DAT_00218659);
        uVar11 = FUN_001c4310(param_1,uVar9,uVar13);
        fVar10 = (float)(uVar11 & 0xffff);
        break;
      case 'D':
        *puVar1 = 0x80;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"doubleValue",&DAT_0021868f);
        lVar17 = (longdouble)FUN_001c43d0(param_1,uVar9,uVar13);
        *pdVar2 = (double)lVar17;
        (**(code **)(*param_1 + 0x5c))(param_1,uVar12);
        *(undefined4 *)(iVar7 + 0xc + local_34 * 0xc) = 0x800;
        goto LAB_001b7d9e;
      default:
        goto switchD_001b7c9e_caseD_45;
      case 'F':
        *puVar1 = 0x40;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"floatValue",&DAT_0021867f);
        lVar17 = (longdouble)FUN_001c4390(param_1,uVar9,uVar13);
        *(float *)pdVar2 = (float)lVar17;
        goto LAB_001b7bf3;
      case 'I':
        *puVar1 = 0x10;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"intValue",&DAT_00217db4);
        fVar10 = (float)FUN_001b4980(param_1,uVar9,uVar13);
        break;
      case 'J':
        *puVar1 = 0x20;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"longValue",&DAT_00218670);
        dVar18 = (double)FUN_001c4350(param_1,uVar9,uVar13);
        *pdVar2 = dVar18;
        (**(code **)(*param_1 + 0x5c))(param_1,uVar12);
        *(undefined4 *)(iVar7 + 0xc + local_34 * 0xc) = 0x400;
LAB_001b7d9e:
        *(undefined4 *)(iVar7 + 0x10 + local_34 * 0xc) = 0;
        local_34 = local_34 + 2;
        goto switchD_001b7c9e_caseD_45;
      case 'L':
      case '[':
        *puVar1 = 0x100;
        fVar10 = (float)(**(code **)(*param_1 + 100))(param_1,uVar9);
        *(float *)pdVar2 = fVar10;
        goto LAB_001b7c02;
      case 'S':
        *puVar1 = 8;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"shortValue",&DAT_0021864b);
        sVar6 = FUN_001c42d0(param_1,uVar9,uVar13);
        fVar10 = (float)(int)sVar6;
        break;
      case 'Z':
        *puVar1 = 1;
        uVar12 = (**(code **)(*param_1 + 0x7c))(param_1,uVar9);
        uVar13 = (**(code **)(*param_1 + 0x84))(param_1,uVar12,"booleanValue",&DAT_00217e1f);
        uVar5 = FUN_001b4310(param_1,uVar9,uVar13);
        *(undefined *)pdVar2 = uVar5;
        goto LAB_001b7bf3;
      }
      *(float *)pdVar2 = fVar10;
LAB_001b7bf3:
      (**(code **)(*param_1 + 0x5c))(param_1,uVar12);
LAB_001b7c02:
      local_34 = local_34 + 1;
switchD_001b7c9e_caseD_45:
      (**(code **)(*param_1 + 0x5c))(param_1,uVar9);
      iVar15 = iVar15 + 1;
    } while (iVar8 != iVar15);
  }
  return iVar7;
}

