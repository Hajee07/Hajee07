/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002157fb FUN_002157fb */

void __regparm3 FUN_002157fb(byte *param_1,uint *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  uint uVar4;
  
  uVar4 = 0;
  bVar3 = 0;
  do {
    bVar1 = *param_1;
    bVar2 = bVar3 & 0x1f;
    bVar3 = bVar3 + 7;
    uVar4 = uVar4 | (bVar1 & 0x7f) << bVar2;
    param_1 = param_1 + 1;
  } while ((char)bVar1 < '\0');
  *param_2 = uVar4;
  return;
}

