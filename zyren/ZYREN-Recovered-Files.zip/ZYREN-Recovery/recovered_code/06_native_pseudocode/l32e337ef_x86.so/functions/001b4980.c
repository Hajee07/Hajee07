/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b4980 FUN_001b4980 */

void FUN_001b4980(int *param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*param_1 + 200))(param_1,param_2,param_3,&stack0x00000010);
  return;
}

