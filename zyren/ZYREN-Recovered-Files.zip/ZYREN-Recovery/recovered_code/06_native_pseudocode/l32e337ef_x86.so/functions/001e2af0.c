/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e2af0 FUN_001e2af0 */

undefined8 FUN_001e2af0(int param_1)

{
  if ((param_1 != 0) && (*(int *)(param_1 + 0x48) != 0)) {
    return *(undefined8 *)(*(int *)(param_1 + 0x48) + 0x40);
  }
  return 0;
}

