/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c59a0 FUN_001c59a0 */

void FUN_001c59a0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x5c2c);
  if (iVar1 != param_2) {
    *(int *)(param_1 + 0x5c38) = iVar1;
    *(int *)(param_1 + 0x5c34) = (*(int *)(param_1 + 0x5c30) - iVar1) + param_2;
    *(int *)(param_1 + 0x5c30) = param_2;
    *(int *)(param_1 + 0x5c2c) = param_2;
  }
  iVar1 = FUN_001c5a20(param_3,param_4,param_5,0x1c59ac);
  *(int *)(param_1 + 0x5c2c) = param_2 + iVar1;
  return;
}

