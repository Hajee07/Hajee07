/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9450 FUN_001f9450 */

void FUN_001f9450(void)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  uint **ppuVar5;
  uint **ppuVar6;
  uint uVar7;
  undefined4 uStack_34;
  uint *local_30 [3];
  int local_24;
  uint local_20;
  uint local_1c;
  uint *local_18;
  
  uStack_34 = 0x1f946d;
  piVar4 = (int *)FUN_001f9870();
  iVar2 = *piVar4;
  ppuVar6 = local_30;
  if (iVar2 != 0) {
    local_1c = *(uint *)(iVar2 + 0x34);
    local_20 = *(uint *)(iVar2 + 0x30) & 0xffffff00;
    puVar1 = (uint *)(iVar2 + 0x30);
    if ((local_1c ^ 0x434c4e47 | local_20 ^ 0x432b2b00) == 0) {
      *(int *)(iVar2 + 0x14) = -*(int *)(iVar2 + 0x14);
      piVar4[1] = piVar4[1] + 1;
    }
    else {
      *piVar4 = 0;
    }
    uStack_34 = 0x1f94b7;
    local_30[0] = puVar1;
    local_24 = iVar2;
    FUN_002153c7();
    uVar3 = *puVar1;
    uVar7 = *(uint *)(iVar2 + 0x34);
                    /* try { // try from 001f94c0 to 001f94c4 has its CatchHandler @ 001f953e */
    uStack_34 = 0x1f94c5;
    local_18 = puVar1;
    ppuVar5 = (uint **)FUN_001f9870();
    puVar1 = local_18 + -0xc;
    if ((uVar3 & 0xffffff00 ^ 0x432b2b00 | uVar7 ^ 0x434c4e47) == 0) {
      uVar3 = local_18[-7];
      uVar7 = -uVar3;
      if (0 < (int)uVar3) {
        uVar7 = uVar3;
      }
      local_18[-7] = uVar7 + 1;
      if (*ppuVar5 != puVar1) {
        local_18[-8] = (uint)*ppuVar5;
        *ppuVar5 = puVar1;
      }
      ppuVar5[1] = (uint *)((int)ppuVar5[1] + -1);
    }
    else {
      ppuVar6 = local_30;
      if (*ppuVar5 != (uint *)0x0) goto LAB_001f9539;
      *ppuVar5 = puVar1;
    }
    ppuVar6 = local_30;
    if ((local_1c ^ 0x434c4e47 | local_20 ^ 0x432b2b00) == 0) {
      local_30[0] = *(uint **)(local_24 + 0xc);
      uStack_34 = 0x1f9536;
      FUN_001f9e20();
      ppuVar6 = (uint **)&uStack_34;
    }
  }
LAB_001f9539:
                    /* WARNING: Subroutine does not return */
  *(undefined **)((int)ppuVar6 + -4) = &LAB_001f953e;
  FUN_001f9d40();
}

