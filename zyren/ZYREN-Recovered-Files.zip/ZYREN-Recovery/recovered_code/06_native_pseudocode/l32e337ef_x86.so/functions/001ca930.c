/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ca930 FUN_001ca930 */

uint FUN_001ca930(undefined4 param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined4 local_218;
  uint local_214;
  undefined local_210 [512];
  
  local_218 = 0xff;
  uVar1 = FUN_001c9540(local_210,&local_218,&local_214,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_214 <= param_6) {
      uVar2 = FUN_001c9b30(param_5,local_210,local_218,local_214);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_001c9d60(param_1,param_2,param_3 + uVar1,param_4 - uVar1,param_5);
      }
    }
  }
  return uVar2;
}

