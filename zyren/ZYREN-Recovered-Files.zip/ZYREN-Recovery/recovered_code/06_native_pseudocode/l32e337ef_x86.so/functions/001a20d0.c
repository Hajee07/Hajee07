/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a20d0 FUN_001a20d0 */

void FUN_001a20d0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)PTR_DAT_0024bbd8)(param_1,param_2);
  FUN_0019bae0(uVar1,param_1,param_2,0);
  return;
}

