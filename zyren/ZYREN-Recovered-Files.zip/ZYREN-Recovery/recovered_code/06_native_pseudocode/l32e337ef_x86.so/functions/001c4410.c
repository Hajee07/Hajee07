/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c4410 FUN_001c4410 */

undefined * FUN_001c4410(int param_1)

{
  int *piVar1;
  
  if (param_1 == 0) {
    return (undefined *)0x0;
  }
  piVar1 = *(int **)(param_1 + 0x5ce8);
  if (piVar1 != (int *)0x0) {
    if (*piVar1 != 0) {
      return &LAB_0002b984 + *(int *)(param_1 + 0x5d08) + *(int *)(param_1 + 0x5cf8) + piVar1[2];
    }
    return &LAB_0002b984 + *(int *)(param_1 + 0x5d08) + *(int *)(param_1 + 0x5cf8);
  }
  return &DAT_00025d48 + *(int *)(param_1 + 0x5d08) + *(int *)(param_1 + 0x5cf8);
}

