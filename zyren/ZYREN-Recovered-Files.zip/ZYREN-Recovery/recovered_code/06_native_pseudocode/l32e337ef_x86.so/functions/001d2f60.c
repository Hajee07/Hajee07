/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d2f60 FUN_001d2f60 */

undefined4 FUN_001d2f60(int param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}

