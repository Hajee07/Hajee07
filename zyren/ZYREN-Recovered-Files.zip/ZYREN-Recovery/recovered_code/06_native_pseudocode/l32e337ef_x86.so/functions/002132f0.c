/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002132f0 FUN_002132f0 */

void FUN_002132f0(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined *puVar7;
  int *piVar8;
  int iVar9;
  
  if (*(char *)(param_1 + 0x10) != '\0') {
    return;
  }
  *(undefined *)(param_1 + 0x10) = 1;
  piVar8 = *(int **)(param_1 + 8);
  iVar5 = *(int *)(param_1 + 0xc);
                    /* try { // try from 00213324 to 0021332f has its CatchHandler @ 002134df */
  iVar2 = (**(code **)(*piVar8 + 0xc))(piVar8,param_2);
  while (*(char *)(iVar2 + 4) == '\f') {
    piVar8 = *(int **)(iVar2 + 8);
    if (*(int *)(iVar2 + 0xc) <= iVar5) {
      iVar5 = *(int *)(iVar2 + 0xc);
    }
                    /* try { // try from 00213346 to 00213351 has its CatchHandler @ 002134e1 */
    iVar2 = (**(code **)(*piVar8 + 0xc))(piVar8,param_2);
  }
                    /* try { // try from 00213359 to 00213409 has its CatchHandler @ 002134df */
  (**(code **)(*piVar8 + 0x10))(piVar8,param_2);
  if (*(char *)((int)piVar8 + 6) == '\0') {
LAB_00213385:
    iVar2 = param_2[1];
    uVar6 = iVar2 + 1;
    if (uVar6 < (uint)param_2[2]) {
      iVar9 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar6) {
        uVar3 = uVar6;
      }
      param_2[2] = uVar3;
      iVar9 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar9;
      if (iVar9 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_001f9d40();
      }
      iVar2 = param_2[1];
    }
    *(undefined *)(iVar9 + iVar2) = 0x20;
    param_2[1] = param_2[1] + 1;
LAB_002133ce:
    if ((*(char *)((int)piVar8 + 6) != '\0') &&
       ((*(char *)((int)piVar8 + 6) != '\x02' ||
        (cVar1 = (**(code **)(*piVar8 + 4))(piVar8,param_2), cVar1 == '\0')))) goto LAB_002133ee;
  }
  else {
    if (*(char *)((int)piVar8 + 6) == '\x02') {
      cVar1 = (**(code **)(*piVar8 + 4))(piVar8,param_2);
      if (cVar1 != '\0') goto LAB_00213385;
      goto LAB_002133ce;
    }
LAB_002133ee:
    if ((*(char *)((int)piVar8 + 7) != '\0') &&
       ((*(char *)((int)piVar8 + 7) != '\x02' ||
        (cVar1 = (**(code **)(*piVar8 + 8))(piVar8,param_2), cVar1 == '\0')))) goto LAB_0021344e;
  }
  iVar2 = param_2[1];
  uVar6 = iVar2 + 1;
  if (uVar6 < (uint)param_2[2]) {
    iVar9 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar6) {
      uVar3 = uVar6;
    }
    param_2[2] = uVar3;
    iVar9 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar9;
    if (iVar9 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_001f9d40();
    }
    iVar2 = param_2[1];
  }
  *(undefined *)(iVar9 + iVar2) = 0x28;
  param_2[1] = param_2[1] + 1;
LAB_0021344e:
  uVar6 = (uint)(iVar5 == 0);
  puVar7 = &DAT_0021a340;
  if (iVar5 == 0) {
    puVar7 = &DAT_0021a343;
  }
  iVar5 = param_2[1];
  uVar3 = (iVar5 + 2) - uVar6;
  if (uVar3 < (uint)param_2[2]) {
    iVar2 = *param_2;
  }
  else {
    uVar4 = param_2[2] * 2;
    if (uVar4 < uVar3) {
      uVar4 = uVar3;
    }
    param_2[2] = uVar4;
    iVar2 = FUN_0018b200(*param_2,uVar4);
    *param_2 = iVar2;
    if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_001f9d40();
    }
    iVar5 = param_2[1];
  }
  iVar9 = 2 - uVar6;
  FUN_0018ae40(iVar5 + iVar2,puVar7,iVar9);
  param_2[1] = param_2[1] + iVar9;
  *(undefined *)(param_1 + 0x10) = 0;
  return;
}

