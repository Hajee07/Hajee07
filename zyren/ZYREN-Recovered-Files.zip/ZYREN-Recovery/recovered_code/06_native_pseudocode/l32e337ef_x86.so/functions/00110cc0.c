/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110cc0 FUN_00110cc0 */

undefined4 FUN_00110cc0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_14;
  
  iVar1 = FUN_00110d30(param_1,param_2);
  if (iVar1 == 0) {
    local_14 = 0;
  }
  else {
    local_14 = *(undefined4 *)(iVar1 + 8);
  }
  return local_14;
}

