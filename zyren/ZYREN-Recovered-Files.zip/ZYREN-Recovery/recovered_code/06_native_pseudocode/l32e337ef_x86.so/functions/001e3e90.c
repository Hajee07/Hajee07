/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e3e90 FUN_001e3e90 */

undefined8 FUN_001e3e90(int param_1)

{
  if (param_1 != 0) {
    return *(undefined8 *)(param_1 + 0x94);
  }
  return 0;
}

