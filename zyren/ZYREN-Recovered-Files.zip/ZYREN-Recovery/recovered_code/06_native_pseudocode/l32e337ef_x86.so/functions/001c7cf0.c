/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c7cf0 FUN_001c7cf0 */

int FUN_001c7cf0(int param_1,int param_2)

{
  param_1 = param_1 + 0x5c3c;
  if (param_2 != 0) {
    param_1 = 0x5c3c;
  }
  return param_1;
}

