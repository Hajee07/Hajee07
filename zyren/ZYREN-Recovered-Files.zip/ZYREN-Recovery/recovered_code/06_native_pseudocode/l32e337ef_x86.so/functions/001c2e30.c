/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c2e30 FUN_001c2e30 */

void __regparm3
FUN_001c2e30(undefined4 param_1_00,int param_2_00,int *param_3_00,ushort *param_1,undefined4 param_2
            ,char param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  ushort uVar5;
  char cVar6;
  uint uVar7;
  undefined4 uVar8;
  byte bVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined8 uVar13;
  
  uVar10 = (uint)(*param_1 >> 8);
  if (param_3 == '\0') {
    uVar12 = param_1[1] & 0xff;
    uVar5 = param_1[1] >> 8;
  }
  else {
    uVar10 = uVar10 & 0xf;
    uVar5 = *param_1 >> 0xc;
    uVar12 = uVar10;
  }
  iVar1 = *(int *)(param_2_00 + uVar10 * 0xc);
  iVar2 = *(int *)(param_2_00 + 4 + uVar10 * 0xc);
  uVar3 = *(uint *)(param_2_00 + 4 + uVar12 * 0xc);
  uVar12 = *(uint *)(param_2_00 + 8 + uVar12 * 0xc);
  uVar4 = *(uint *)(param_2_00 + 4 + (uint)uVar5 * 0xc);
  uVar11 = *(uint *)(param_2_00 + 8 + (uint)uVar5 * 0xc);
  bVar9 = (byte)uVar4;
  switch(param_2) {
  case 0x9b:
  case 0xbb:
    uVar7 = uVar4 + uVar3;
    uVar11 = uVar11 + uVar12 + (uint)CARRY4(uVar4,uVar3);
    goto LAB_001c2f53;
  case 0x9c:
  case 0xbc:
    *(uint *)(param_2_00 + 4 + uVar10 * 0xc) = uVar3 - uVar4;
    *(uint *)(param_2_00 + 8 + uVar10 * 0xc) = (uVar12 - uVar11) - (uint)(uVar3 < uVar4);
    break;
  case 0x9d:
  case 0xbd:
    *(int *)(param_2_00 + 4 + uVar10 * 0xc) = (int)((ulonglong)uVar4 * (ulonglong)uVar3);
    *(uint *)(param_2_00 + 8 + uVar10 * 0xc) =
         uVar11 * uVar3 + uVar12 * uVar4 + (int)((ulonglong)uVar4 * (ulonglong)uVar3 >> 0x20);
    break;
  case 0x9e:
  case 0xbe:
    if ((uVar4 | uVar11) == 0) {
      uVar8 = FUN_001b7690();
      (**(code **)(*param_3_00 + 0x38))(param_3_00,uVar8,"divide by zero");
      (**(code **)(*param_3_00 + 0x5c))(param_3_00,uVar8);
      break;
    }
    uVar13 = FUN_0021376e(uVar3,uVar12,uVar4,uVar11);
    goto LAB_001c2f2c;
  case 0x9f:
  case 0xbf:
    uVar13 = FUN_00213908(uVar3,uVar12,uVar4,uVar11);
LAB_001c2f2c:
    *(int *)(param_2_00 + 8 + uVar10 * 0xc) = (int)((ulonglong)uVar13 >> 0x20);
    *(int *)(param_2_00 + 4 + uVar10 * 0xc) = (int)uVar13;
    break;
  case 0xa0:
  case 0xc0:
    uVar11 = uVar11 & uVar12;
    uVar7 = uVar4 & uVar3;
    goto LAB_001c2f53;
  case 0xa1:
  case 0xc1:
    uVar11 = uVar11 | uVar12;
    uVar7 = uVar4 | uVar3;
    goto LAB_001c2f53;
  case 0xa2:
  case 0xc2:
    uVar11 = uVar11 ^ uVar12;
    uVar7 = uVar4 ^ uVar3;
LAB_001c2f53:
    *(uint *)(param_2_00 + 4 + uVar10 * 0xc) = uVar7;
    *(uint *)(param_2_00 + 8 + uVar10 * 0xc) = uVar11;
    break;
  case 0xa3:
  case 0xc3:
    uVar11 = uVar3 << (bVar9 & 0x1f);
    uVar7 = 0;
    if ((uVar4 & 0x20) == 0) {
      uVar7 = uVar11;
      uVar11 = uVar12 << (bVar9 & 0x1f) | uVar3 >> 0x20 - (bVar9 & 0x1f);
    }
    *(uint *)(param_2_00 + 8 + uVar10 * 0xc) = uVar11;
    *(uint *)(param_2_00 + 4 + uVar10 * 0xc) = uVar7;
    break;
  case 0xa4:
  case 0xc4:
    uVar11 = (int)uVar12 >> (bVar9 & 0x1f);
    uVar7 = (int)uVar12 >> 0x1f;
    if ((uVar4 & 0x20) == 0) {
      uVar7 = uVar11;
      uVar11 = uVar3 >> (bVar9 & 0x1f) | uVar12 << 0x20 - (bVar9 & 0x1f);
    }
    *(uint *)(param_2_00 + 8 + uVar10 * 0xc) = uVar7;
    *(uint *)(param_2_00 + 4 + uVar10 * 0xc) = uVar11;
    break;
  case 0xa5:
  case 0xc5:
    uVar11 = uVar12 >> (bVar9 & 0x1f);
    uVar7 = 0;
    if ((uVar4 & 0x20) == 0) {
      uVar7 = uVar11;
      uVar11 = uVar3 >> (bVar9 & 0x1f) | uVar12 << 0x20 - (bVar9 & 0x1f);
    }
    *(uint *)(param_2_00 + 8 + uVar10 * 0xc) = uVar7;
    *(uint *)(param_2_00 + 4 + uVar10 * 0xc) = uVar11;
  }
  cVar6 = (**(code **)(*param_3_00 + 0x390))(param_3_00);
  if (cVar6 == '\0') {
    if (((iVar1 == 0x4000) || (iVar1 == 0x100)) && (iVar2 != 0)) {
      (**(code **)(*param_3_00 + 0x5c))(param_3_00,iVar2);
    }
    *(undefined4 *)(param_2_00 + uVar10 * 0xc) = 0x20;
  }
  return;
}

