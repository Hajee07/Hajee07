/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019c210 FUN_0019c210 */

undefined ** FUN_0019c210(byte *param_1,uint param_2,uint param_3)

{
  undefined *puVar1;
  undefined *puVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  
  puVar2 = PTR_DAT_0024bb38;
  puVar1 = PTR_DAT_0024bb34;
  if ((param_2 | param_3) == 0) {
    return &__DT_PLTGOT;
  }
  uVar4 = 0;
  uVar5 = 1;
  bVar3 = *param_1;
  if (*(int *)PTR_DAT_0024bb34 == 1) goto LAB_0019c2c9;
  do {
    bVar3 = bVar3 ^ (puVar2[6] * -0x80 +
                    puVar2[5] * '@' +
                    puVar2[4] * ' ' +
                    puVar2[3] * '\x10' + *puVar2 * '\x02' + puVar2[1] * '\x04' + puVar2[2] * '\b') *
                    ((char)uVar4 + 'd');
    uVar4 = uVar5;
    while( true ) {
      param_1[uVar4 - 1] = bVar3;
      uVar5 = uVar4 + 1;
      if (param_3 == 0 && (uint)(uVar4 < param_2) <= -param_3) {
        return (undefined **)(-param_3 - (uint)(uVar4 < param_2));
      }
      bVar3 = param_1[uVar4];
      if (*(int *)puVar1 != 1) break;
LAB_0019c2c9:
      bVar3 = (((((((bVar3 - puVar2[0xf] ^ puVar2[0xe]) - puVar2[0xd] ^ puVar2[0xc]) - puVar2[0xb] ^
                  puVar2[10]) - puVar2[9] ^ puVar2[8]) - puVar2[7] ^ puVar2[6]) - puVar2[5] ^
               puVar2[4]) - puVar2[3] ^ puVar2[2]) - puVar2[1] ^ *puVar2;
      uVar4 = uVar5;
    }
  } while( true );
}

