/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f5e40 FUN_001f5e40 */

undefined4 FUN_001f5e40(int *param_1,undefined4 param_2,int *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  int local_20;
  int local_1c;
  undefined4 local_18;
  
  puVar1 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(undefined4 *)PTR___stack_chk_guard_0024bd6c;
  (**(code **)(*param_1 + 0xc))(&local_20,param_1,param_2);
  if (local_20 == param_3[1]) {
    uVar2 = CONCAT31(0x1f5e,*param_3 == 0x1f5e51);
  }
  else {
    uVar2 = 0;
  }
  if (*(int *)puVar1 == local_1c) {
    return uVar2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0018adc0();
}

