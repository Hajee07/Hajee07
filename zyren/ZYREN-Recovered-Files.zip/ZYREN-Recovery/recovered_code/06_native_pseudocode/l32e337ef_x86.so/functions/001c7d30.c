/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c7d30 FUN_001c7d30 */

int FUN_001c7d30(int param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if (((param_1 != 0) && (7 < *(uint *)(param_1 + 8))) && (**(int **)(param_1 + 4) == -0x13cf5bc9))
  {
    iVar1 = (*(int **)(param_1 + 4))[1];
  }
  return iVar1;
}

