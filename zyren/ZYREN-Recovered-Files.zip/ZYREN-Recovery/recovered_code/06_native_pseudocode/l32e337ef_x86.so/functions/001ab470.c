/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ab470 FUN_001ab470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_001ab470(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint local_30;
  undefined4 local_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  ushort local_18;
  
  local_2c = _DAT_0021b060;
  puStack_28 = (undefined *)_UNK_0021b064;
  uStack_24 = _UNK_0021b068;
  uStack_20 = _UNK_0021b06c;
  local_1c = 0x12143a03;
  local_18 = 0x1a;
  local_30 = 0;
  do {
    *(byte *)((int)&local_2c + local_30) =
         (char)local_30 + 0x6bU ^ *(byte *)((int)&local_2c + local_30);
    local_30 = local_30 + 1;
  } while (local_30 < 0x15);
  local_18 = local_18 & 0xff;
  uVar2 = (**(code **)(*param_1 + 0x18))(param_1,&local_2c);
  local_2c = 0x1022f06;
  puStack_28 = &LAB_00141904;
  local_30 = 0;
  do {
    *(byte *)((int)&local_2c + local_30) =
         (char)local_30 + 0x6bU ^ *(byte *)((int)&local_2c + local_30);
    local_30 = local_30 + 1;
  } while (local_30 < 7);
  puStack_28 = (undefined *)((uint)puStack_28 & 0xffffff);
  uVar3 = (**(code **)(*param_1 + 0x178))(param_1,uVar2,&local_2c,"Ljava/lang/Object;");
  (**(code **)(*param_1 + 0x5c))(param_1,uVar2);
  uVar2 = (**(code **)(*param_1 + 0x17c))(param_1,param_2,uVar3);
  local_2c = CONCAT31(local_2c._1_3_,1);
  (**(code **)(*param_1 + 0x2ac))(param_1,uVar2);
  puVar4 = (undefined4 *)(**(code **)(*param_1 + 0x2f0))(param_1,uVar2,&local_2c);
  puVar4[1] = param_4;
  *puVar4 = param_3;
  (**(code **)(*param_1 + 0x310))(param_1,uVar2,puVar4,0);
  cVar1 = (**(code **)(*param_1 + 0x390))(param_1);
  if (cVar1 == '\0') {
    uVar3 = (**(code **)(*param_1 + 0x2f0))(param_1,uVar2,&local_2c);
    (**(code **)(*param_1 + 0x310))(param_1,uVar2,uVar3,0);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar2);
  }
  return;
}

