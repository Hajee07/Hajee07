/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020f170 FUN_0020f170 */

void FUN_0020f170(int param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  
  uVar7 = 0x20f181;
  (**(code **)(**(int **)(param_1 + 8) + 0x10))(*(int **)(param_1 + 8),param_2);
  iVar4 = param_2[1];
  uVar1 = iVar4 + 5;
  if (uVar1 < (uint)param_2[2]) {
    iVar5 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar5 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar5;
    if (iVar5 == 0) goto LAB_0020f280;
    iVar4 = param_2[1];
  }
  *(undefined *)(iVar5 + 4 + iVar4) = 0x3a;
  *(undefined4 *)(iVar5 + iVar4) = 0x6962615b;
  iVar5 = param_2[1] + 5;
  param_2[1] = iVar5;
  iVar4 = *(int *)(param_1 + 0xc);
  iVar6 = *(int *)(param_1 + 0x10) - iVar4;
  if (iVar6 != 0) {
    uVar1 = iVar5 + iVar6;
    if (uVar1 < (uint)param_2[2]) {
      iVar2 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar2 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar2;
      if (iVar2 == 0) goto LAB_0020f280;
      iVar5 = param_2[1];
    }
    FUN_0018ae40(iVar5 + iVar2,iVar4,iVar6,uVar7);
    iVar5 = iVar6 + param_2[1];
    param_2[1] = iVar5;
  }
  uVar1 = iVar5 + 1;
  if (uVar1 < (uint)param_2[2]) {
    iVar4 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar4 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar4;
    if (iVar4 == 0) {
LAB_0020f280:
                    /* WARNING: Subroutine does not return */
      FUN_001f9d40();
    }
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar4 + iVar5) = 0x5d;
  param_2[1] = param_2[1] + 1;
  return;
}

