/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bb040 FUN_001bb040 */

undefined4 FUN_001bb040(int *param_1,int param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  iVar3 = *(int *)(param_2 + 8);
  uVar5 = (uint)(**(ushort **)(param_2 + 0x28) >> 8);
  uVar6 = (uint)**(ushort **)(param_2 + 4);
  puVar1 = (undefined8 *)(iVar3 + uVar6 * 0xc);
  puVar2 = (undefined8 *)(iVar3 + uVar5 * 0xc);
  iVar4 = *(int *)(iVar3 + uVar5 * 0xc);
  if (((iVar4 == 0x4000) || (iVar4 == 0x100)) &&
     (iVar4 = *(int *)(iVar3 + 4 + uVar5 * 0xc), iVar4 != 0)) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
  }
  *(undefined4 *)(puVar2 + 1) = *(undefined4 *)(puVar1 + 1);
  *puVar2 = *puVar1;
  *(undefined4 *)puVar1 = 0;
  *(undefined4 *)(iVar3 + 8 + uVar6 * 0xc) = 0;
  *(undefined4 *)(iVar3 + 4 + uVar6 * 0xc) = 0;
  return 0;
}

