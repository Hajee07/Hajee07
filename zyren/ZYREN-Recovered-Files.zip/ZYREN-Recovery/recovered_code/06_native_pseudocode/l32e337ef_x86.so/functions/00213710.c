/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00213710 FUN_00213710 */

undefined4 FUN_00213710(int *param_1,uint param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  
  uVar1 = 0x16;
  if ((param_2 != 0 && (param_2 & param_2 - 1) == 0) && ((param_2 & 3) == 0)) {
    iVar2 = FUN_0018b570(param_2,param_3);
    *param_1 = iVar2;
    uVar1 = 0;
    if (iVar2 == 0) {
      puVar3 = (undefined4 *)FUN_0018aeb0();
      uVar1 = *puVar3;
    }
  }
  return uVar1;
}

