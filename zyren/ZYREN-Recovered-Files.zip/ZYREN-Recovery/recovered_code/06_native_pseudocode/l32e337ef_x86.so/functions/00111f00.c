/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00111f00 FUN_00111f00 */

int FUN_00111f00(byte *param_1)

{
  int local_c;
  byte local_5;
  
  local_c = 0x1505;
  local_5 = *param_1;
  while (local_5 != 0) {
    local_c = local_c * 0x21 + (uint)local_5;
    local_5 = param_1[1];
    param_1 = param_1 + 1;
  }
  return local_c;
}

