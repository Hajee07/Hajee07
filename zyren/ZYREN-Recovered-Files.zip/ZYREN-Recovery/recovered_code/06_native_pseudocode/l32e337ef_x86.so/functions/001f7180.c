/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7180 FUN_001f7180 */

void FUN_001f7180(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar1 = (undefined4 *)param_1[4];
  for (puVar3 = (undefined4 *)param_1[3]; puVar3 != puVar1; puVar3 = puVar3 + 2) {
    FUN_001f4bf0(puVar3[1]);
    FUN_001f76c0(*puVar3);
  }
  puVar1 = (undefined4 *)param_1[1];
  for (puVar3 = (undefined4 *)*param_1; puVar3 != puVar1; puVar3 = puVar3 + 1) {
                    /* try { // try from 001f71e2 to 001f71e9 has its CatchHandler @ 001f722c */
    FUN_001f8190(*puVar3);
    FUN_001f4860(*puVar3);
  }
  iVar2 = param_1[3];
  if (iVar2 != 0) {
    param_1[4] = iVar2;
    FUN_001f5680(iVar2);
  }
  iVar2 = *param_1;
  if (iVar2 != 0) {
    param_1[1] = iVar2;
    FUN_001f5680(iVar2);
  }
  return;
}

