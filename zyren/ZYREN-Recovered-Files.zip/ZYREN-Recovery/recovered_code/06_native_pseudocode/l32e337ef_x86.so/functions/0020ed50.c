/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020ed50 FUN_0020ed50 */

void FUN_0020ed50(int param_1,int *param_2)

{
  uint uVar1;
  char *pcVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  switch(*(undefined4 *)(param_1 + 8)) {
  case 0:
    iVar5 = param_2[1];
    uVar1 = iVar5 + 0xe;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) {
LAB_0020efbb:
                    /* WARNING: Subroutine does not return */
        FUN_001f9d40();
      }
      iVar5 = param_2[1];
    }
    *(undefined2 *)(iVar4 + 0xc + iVar5) = 0x726f;
    *(undefined4 *)(iVar4 + 8 + iVar5) = 0x7461636f;
    *(undefined4 *)(iVar4 + 4 + iVar5) = 0x6c6c613a;
    *(undefined4 *)(iVar4 + iVar5) = 0x3a647473;
    iVar5 = 0xe;
    break;
  case 1:
    iVar5 = param_2[1];
    uVar1 = iVar5 + 0x11;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) goto LAB_0020efbb;
      iVar5 = param_2[1];
    }
    *(undefined *)(iVar4 + 0x10 + iVar5) = 0x67;
    *(undefined4 *)(iVar4 + 0xc + iVar5) = 0x6e697274;
    *(undefined4 *)(iVar4 + 8 + iVar5) = 0x735f6369;
    *(undefined4 *)(iVar4 + 4 + iVar5) = 0x7361623a;
    *(undefined4 *)(iVar4 + iVar5) = 0x3a647473;
    iVar5 = 0x11;
    break;
  case 2:
    iVar5 = param_2[1];
    uVar1 = iVar5 + 0x46;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) goto LAB_0020efbb;
      iVar5 = param_2[1];
    }
    FUN_0018ae80(iVar5 + iVar4,
                 "std::basic_string<char, std::char_traits<char>, std::allocator<char> >",0x46);
    iVar5 = 0x46;
    break;
  case 3:
    iVar5 = param_2[1];
    uVar1 = iVar5 + 0x31;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) goto LAB_0020efbb;
      iVar5 = param_2[1];
    }
    iVar5 = iVar5 + iVar4;
    pcVar2 = "std::basic_istream<char, std::char_traits<char> >";
    goto LAB_0020eec8;
  case 4:
    iVar5 = param_2[1];
    uVar1 = iVar5 + 0x31;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) goto LAB_0020efbb;
      iVar5 = param_2[1];
    }
    iVar5 = iVar5 + iVar4;
    pcVar2 = "std::basic_ostream<char, std::char_traits<char> >";
LAB_0020eec8:
    FUN_0018ae80(iVar5,pcVar2,0x31);
    iVar5 = 0x31;
    break;
  case 5:
    iVar5 = param_2[1];
    uVar1 = iVar5 + 0x32;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) goto LAB_0020efbb;
      iVar5 = param_2[1];
    }
    FUN_0018ae80(iVar5 + iVar4,"std::basic_iostream<char, std::char_traits<char> >",0x32);
    iVar5 = 0x32;
    break;
  default:
    return;
  }
  param_2[1] = param_2[1] + iVar5;
  return;
}

