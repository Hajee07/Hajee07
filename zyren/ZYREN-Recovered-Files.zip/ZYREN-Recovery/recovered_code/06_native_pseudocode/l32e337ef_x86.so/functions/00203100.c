/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00203100 FUN_00203100 */

char * FUN_00203100(void)

{
  char *pcVar1;
  char *pcVar2;
  char **ppcVar3;
  int iVar4;
  char **ppcVar5;
  char **in_ECX;
  char *pcVar6;
  
  pcVar2 = *in_ECX;
  pcVar6 = (char *)0x0;
  if ((pcVar2 != in_ECX[1]) && (*pcVar2 == 'D')) {
    pcVar1 = pcVar2 + 1;
    *in_ECX = pcVar1;
    if ((pcVar1 != in_ECX[1]) && ((*pcVar1 == 't' || (*pcVar1 == 'T')))) {
      *in_ECX = pcVar2 + 2;
      iVar4 = FUN_002042b0();
      if ((iVar4 != 0) && ((pcVar2 = *in_ECX, pcVar2 != in_ECX[1] && (*pcVar2 == 'E')))) {
        *in_ECX = pcVar2 + 1;
        ppcVar3 = (char **)in_ECX[0x45b];
        pcVar6 = ppcVar3[1];
        ppcVar5 = ppcVar3;
        if ((char *)0xff7 < pcVar6 + 0x20) {
          ppcVar5 = (char **)FUN_0018add0(0x1000);
          if (ppcVar5 == (char **)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_001f9d40();
          }
          *ppcVar5 = (char *)ppcVar3;
          ppcVar5[1] = (char *)0x0;
          in_ECX[0x45b] = (char *)ppcVar5;
          pcVar6 = (char *)0x0;
        }
        ppcVar5[1] = pcVar6 + 0x20;
        *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar6) = 0x101012f;
        *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar6) = &PTR_FUN_0024b148;
        *(char **)((int)(ppcVar5 + 4) + (int)pcVar6) = "decltype(";
        *(char **)((int)(ppcVar5 + 5) + (int)pcVar6) = "";
        *(int *)((int)(ppcVar5 + 6) + (int)pcVar6) = iVar4;
        *(undefined **)((int)(ppcVar5 + 7) + (int)pcVar6) = &DAT_0021a33e;
        *(undefined **)((int)(ppcVar5 + 8) + (int)pcVar6) = &DAT_0021a33f;
        pcVar6 = (char *)((int)(ppcVar5 + 2) + (int)pcVar6);
      }
    }
  }
  return pcVar6;
}

