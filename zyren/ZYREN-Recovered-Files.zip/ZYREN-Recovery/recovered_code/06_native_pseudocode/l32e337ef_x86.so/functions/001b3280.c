/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b3280 FUN_001b3280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __regparm3
FUN_001b3280(undefined4 param_1_00,undefined4 param_2_00,int *param_3_00,undefined4 param_1,
            undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint local_44 [2];
  uint local_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined local_2c;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_18 = (**(code **)(*param_3_00 + 0x29c))(param_3_00,param_2_00);
  local_1c = (**(code **)(*param_3_00 + 0x29c))(param_3_00,param_1);
  local_3c = _DAT_0021b390;
  puStack_38 = (undefined *)_UNK_0021b394;
  uStack_34 = _UNK_0021b398;
  uStack_30 = _UNK_0021b39c;
  local_44[0] = 0;
  do {
    *(byte *)((int)&local_3c + local_44[0]) =
         (char)local_44[0] + 0x6bU ^ *(byte *)((int)&local_3c + local_44[0]);
    local_44[0] = local_44[0] + 1;
  } while (local_44[0] < 0xf);
  uStack_30 = uStack_30 & 0xffffff;
  iVar1 = (**(code **)(*param_3_00 + 0x18))(param_3_00,&local_3c);
  if (iVar1 != 0) {
    local_3c = 0x201f030d;
    puStack_38 = &LAB_00141d0e;
    local_44[0] = 0;
    do {
      *(byte *)((int)&local_3c + local_44[0]) =
           (char)local_44[0] + 0x6bU ^ *(byte *)((int)&local_3c + local_44[0]);
      local_44[0] = local_44[0] + 1;
    } while (local_44[0] < 7);
    puStack_38 = (undefined *)((uint)puStack_38 & 0xffffff);
    iVar2 = (**(code **)(*param_3_00 + 0x1c4))
                      (param_3_00,iVar1,&local_3c,"(Ljava/lang/String;)Ljava/lang/Class;");
    if (iVar2 != 0) {
      local_20 = FUN_001b4250(param_3_00,iVar1,iVar2,local_18);
      local_14 = (**(code **)(*param_3_00 + 0x7c))(param_3_00,local_20);
      local_3c = _DAT_0021b3a0;
      puStack_38 = (undefined *)_UNK_0021b3a4;
      uStack_34 = _UNK_0021b3a8;
      uStack_30 = _UNK_0021b3ac;
      local_44[0] = 0;
      do {
        *(byte *)((int)&local_3c + local_44[0]) =
             (char)local_44[0] + 0x6bU ^ *(byte *)((int)&local_3c + local_44[0]);
        local_44[0] = local_44[0] + 1;
      } while (local_44[0] < 0x10);
      local_2c = 0;
      iVar2 = (**(code **)(*param_3_00 + 0x84))
                        (param_3_00,local_14,&local_3c,
                         "(Ljava/lang/String;)Ljava/lang/reflect/Field;");
      if (iVar2 != 0) {
        local_24 = FUN_001a64f0(param_3_00,local_20,iVar2,local_1c);
        uVar3 = (**(code **)(*param_3_00 + 0x7c))(param_3_00,local_24);
        local_3c = 0x2f190918;
        puStack_38 = (undefined *)0x114130c;
        uStack_34 = 0x1a171d00;
        uStack_30 = CONCAT22(uStack_30._2_2_,0x12);
        local_44[0] = 0;
        do {
          *(byte *)((int)&local_3c + local_44[0]) =
               (char)local_44[0] + 0x6bU ^ *(byte *)((int)&local_3c + local_44[0]);
          local_44[0] = local_44[0] + 1;
        } while (local_44[0] < 0xd);
        uStack_30._0_2_ = (ushort)(byte)uStack_30;
        iVar2 = (**(code **)(*param_3_00 + 0x84))(param_3_00,uVar3,&local_3c,&DAT_002182de);
        if (iVar2 != 0) {
          FUN_001b4350(param_3_00,local_24,iVar2,1);
          local_44[0] = 0x190918;
          local_3c = 0;
          do {
            *(byte *)((int)local_44 + local_3c) =
                 (char)local_3c + 0x6bU ^ *(byte *)((int)local_44 + local_3c);
            local_3c = local_3c + 1;
          } while (local_3c < 3);
          local_44[0] = local_44[0] & 0xffffff;
          iVar2 = (**(code **)(*param_3_00 + 0x84))
                            (param_3_00,uVar3,local_44,"(Ljava/lang/Object;Ljava/lang/Object;)V");
          uVar3 = local_24;
          if (iVar2 != 0) {
            FUN_001b4350(param_3_00,local_24,iVar2,param_2,param_3);
            (**(code **)(*param_3_00 + 0x5c))(param_3_00,iVar1);
            (**(code **)(*param_3_00 + 0x5c))(param_3_00,local_20);
            (**(code **)(*param_3_00 + 0x5c))(param_3_00,local_14);
            (**(code **)(*param_3_00 + 0x5c))(param_3_00,uVar3);
            (**(code **)(*param_3_00 + 0x5c))(param_3_00,local_18);
            (**(code **)(*param_3_00 + 0x5c))(param_3_00,local_1c);
            return;
          }
        }
      }
    }
  }
  FUN_001aa7e0(param_3_00);
  return;
}

