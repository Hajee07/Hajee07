/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c0c20 FUN_001c0c20 */

undefined4 FUN_001c0c20(int *param_1,int *param_2)

{
  int *piVar1;
  double *pdVar2;
  int iVar3;
  int iVar4;
  undefined uVar5;
  char cVar6;
  undefined2 uVar7;
  undefined *puVar8;
  undefined *puVar9;
  int iVar10;
  uint uVar11;
  int *piVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  int iVar19;
  float fVar20;
  uint uVar21;
  char *pcVar22;
  char *pcVar23;
  char *pcVar24;
  int iVar25;
  longdouble lVar26;
  double dVar27;
  int local_7c;
  undefined4 local_70;
  undefined local_3c [16];
  undefined local_2c [16];
  undefined4 local_1c;
  undefined4 local_18;
  
  iVar15 = param_2[2];
  iVar19 = param_2[10];
  uVar21 = (uint)*(ushort *)(iVar19 + 2);
  local_2c = ZEXT816(0);
  local_3c = ZEXT816(0);
  local_18 = 0;
  local_1c = 0;
  iVar10 = *param_2;
  puVar9 = (undefined *)
           (*(int *)(*(int *)(iVar10 + 8) +
                    *(int *)(*(int *)(iVar10 + 0x18) +
                            (uint)*(ushort *)(*(int *)(iVar10 + 0x14) + 2 + uVar21 * 8) * 0xc) * 4)
            + 1 + *(int *)(iVar10 + 0x2c));
  do {
    puVar8 = puVar9;
    puVar9 = puVar8 + 1;
  } while ((char)puVar8[-1] < '\0');
  puVar9 = (undefined *)FUN_001bcd50(iVar19,1,puVar8 + 1);
  uVar11 = *(ushort *)(iVar19 + 4) & 0xf;
  if (puVar9 != local_3c) {
    uVar11 = (uint)*(ushort *)(iVar19 + 4);
  }
  iVar19 = *(int *)(iVar15 + 4 + uVar11 * 0xc);
  iVar10 = *param_2;
  if (iVar19 == 0) {
    uVar17 = FUN_001c01b0();
    uVar18 = FUN_0018af40("Cannot invoke \"");
    iVar15 = FUN_0018af10(uVar18);
    iVar19 = FUN_0018af10(uVar17);
    uVar18 = FUN_0018b200(uVar18,iVar15 + 1 + iVar19);
    FUN_0018b210(uVar18,uVar17);
    iVar15 = FUN_0018af10(uVar18);
    iVar15 = FUN_0018b200(uVar18,iVar15 + 0xb);
    iVar19 = FUN_0018af10(iVar15);
    *(undefined4 *)(iVar15 + iVar19) = 0x65622022;
    *(undefined4 *)(iVar15 + 4 + iVar19) = 0x73756163;
    *(undefined4 *)(iVar15 + 7 + iVar19) = 0x206573;
    iVar19 = FUN_0018af10(iVar15);
    iVar15 = FUN_0018b200(iVar15,iVar19 + 4);
    iVar19 = FUN_0018af10(iVar15);
    *(undefined4 *)(iVar15 + iVar19) = 0x787878;
    iVar19 = FUN_0018af10(iVar15);
    iVar15 = FUN_0018b200(iVar15,iVar19 + 9);
    iVar19 = FUN_0018af10(iVar15);
    *(undefined4 *)(iVar15 + iVar19) = 0x20736920;
    *(undefined4 *)(iVar15 + 4 + iVar19) = 0x6c6c756e;
    *(undefined *)(iVar15 + 8 + iVar19) = 0;
    uVar18 = FUN_001b7690();
    (**(code **)(*param_1 + 0x38))(param_1,uVar18,iVar15);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar18);
    FUN_0018ae20(iVar15);
    FUN_0018ae20(uVar17);
  }
  else {
    pcVar23 = (char *)(*(int *)(iVar10 + 0x2c) +
                      *(int *)(*(int *)(iVar10 + 8) +
                              *(int *)(*(int *)(iVar10 + 0xc) +
                                      (uint)*(ushort *)
                                             (*(int *)(iVar10 + 0x14) +
                                             (uint)*(ushort *)(param_2 + 8) * 8) * 4) * 4));
    do {
      cVar6 = *pcVar23;
      pcVar23 = pcVar23 + 1;
    } while (cVar6 < '\0');
    iVar10 = FUN_001b7690();
    if (iVar10 != 0) {
      uVar11 = (uint)*(ushort *)param_2[1];
      iVar3 = *(int *)(iVar15 + uVar11 * 0xc);
      iVar4 = *(int *)(iVar15 + 4 + uVar11 * 0xc);
      local_7c = (**(code **)(*param_1 + 0x28))(param_1,iVar10);
      if (local_7c != 0) {
        piVar1 = (int *)(iVar15 + uVar11 * 0xc);
        pdVar2 = (double *)(iVar15 + 4 + uVar11 * 0xc);
        do {
          iVar15 = *param_2;
          iVar25 = *(int *)(iVar15 + 0x2c);
          pcVar23 = (char *)(*(int *)(*(int *)(iVar15 + 8) +
                                     *(int *)(*(int *)(iVar15 + 0x14) + 4 + uVar21 * 8) * 4) +
                            iVar25);
          do {
            cVar6 = *pcVar23;
            pcVar23 = pcVar23 + 1;
          } while (cVar6 < '\0');
          uVar11 = (uint)*(ushort *)(*(int *)(iVar15 + 0x14) + 2 + uVar21 * 8);
          iVar16 = *(int *)(iVar15 + 0x18);
          iVar13 = *(int *)(iVar16 + 8 + uVar11 * 0xc);
          local_70 = FUN_0018af40(&DAT_00218b05);
          if (((iVar13 != 0) && (piVar12 = (int *)(iVar25 + iVar13), piVar12 != (int *)0x0)) &&
             (0 < *piVar12)) {
            iVar25 = 0;
            do {
              pcVar24 = (char *)(*(int *)(iVar15 + 0x2c) +
                                *(int *)(*(int *)(iVar15 + 8) +
                                        *(int *)(*(int *)(iVar15 + 0xc) +
                                                (uint)*(ushort *)((int)piVar12 + iVar25 * 2 + 4) * 4
                                                ) * 4));
              do {
                cVar6 = *pcVar24;
                pcVar24 = pcVar24 + 1;
              } while (cVar6 < '\0');
              iVar13 = FUN_0018af10(local_70);
              iVar14 = FUN_0018af10(pcVar24);
              local_70 = FUN_0018b200(local_70,iVar13 + 1 + iVar14);
              FUN_0018b210(local_70,pcVar24);
              iVar25 = iVar25 + 1;
            } while (iVar25 < *piVar12);
          }
          iVar25 = FUN_0018af10(local_70);
          iVar25 = FUN_0018b200(local_70,iVar25 + 2);
          iVar13 = FUN_0018af10(iVar25);
          *(undefined2 *)(iVar25 + iVar13) = 0x29;
          pcVar24 = (char *)(*(int *)(iVar15 + 0x2c) +
                            *(int *)(*(int *)(iVar15 + 8) +
                                    *(int *)(*(int *)(iVar15 + 0xc) +
                                            *(int *)(iVar16 + 4 + uVar11 * 0xc) * 4) * 4));
          do {
            cVar6 = *pcVar24;
            pcVar24 = pcVar24 + 1;
          } while (cVar6 < '\0');
          iVar15 = FUN_0018af10(iVar25);
          iVar16 = FUN_0018af10(pcVar24);
          uVar17 = FUN_0018b200(iVar25,iVar15 + 1 + iVar16);
          FUN_0018b210(uVar17,pcVar24);
          iVar15 = (**(code **)(*param_1 + 0x84))(param_1,local_7c,pcVar23,uVar17);
          if (iVar15 == 0) {
            iVar15 = FUN_0018b060(pcVar23,"<init>");
            if ((iVar15 == 0) && (iVar15 = FUN_0018b060(uVar17,&DAT_00217efa), iVar15 == 0)) {
              cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
              iVar25 = local_7c;
              if (cVar6 != '\0') {
                (**(code **)(*param_1 + 0x40))(param_1);
                (**(code **)(*param_1 + 0x44))(param_1);
              }
              do {
                iVar25 = (**(code **)(*param_1 + 0x28))(param_1,iVar25);
                iVar15 = (**(code **)(*param_1 + 0x84))(param_1,iVar25,"<init>",&DAT_00217efa);
                (**(code **)(*param_1 + 0x5c))(param_1,iVar25);
                if (iVar15 != 0) goto LAB_001c0f68;
                cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
                if (cVar6 != '\0') {
                  (**(code **)(*param_1 + 0x40))(param_1);
                  (**(code **)(*param_1 + 0x44))(param_1);
                }
              } while (iVar25 != 0);
            }
            FUN_0018ae20(uVar17);
            cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
            if (cVar6 != '\0') goto LAB_001c0d80;
            goto LAB_001c0d8c;
          }
LAB_001c0f68:
          FUN_0018ae20(uVar17);
          switch(*puVar8) {
          case 0x42:
            *piVar1 = 2;
            uVar5 = (**(code **)(*param_1 + 0x120))(param_1,iVar19,local_7c,iVar15,puVar9);
            goto LAB_001c129a;
          case 0x43:
            *piVar1 = 4;
            uVar7 = (**(code **)(*param_1 + 300))(param_1,iVar19,local_7c,iVar15,puVar9);
            goto LAB_001c1243;
          case 0x44:
            *piVar1 = 0x80;
            lVar26 = (longdouble)
                     (**(code **)(*param_1 + 0x168))(param_1,iVar19,local_7c,iVar15,puVar9);
            *pdVar2 = (double)lVar26;
            break;
          case 0x46:
            *piVar1 = 0x40;
            lVar26 = (longdouble)
                     (**(code **)(*param_1 + 0x15c))(param_1,iVar19,local_7c,iVar15,puVar9);
            *(float *)pdVar2 = (float)lVar26;
            break;
          case 0x49:
            *piVar1 = 0x10;
            fVar20 = (float)(**(code **)(*param_1 + 0x144))(param_1,iVar19,local_7c,iVar15,puVar9);
            goto LAB_001c11de;
          case 0x4a:
            *piVar1 = 0x20;
            dVar27 = (double)(**(code **)(*param_1 + 0x150))(param_1,iVar19,local_7c,iVar15,puVar9);
            *pdVar2 = dVar27;
            break;
          case 0x4c:
          case 0x5b:
            *piVar1 = 0x100;
            fVar20 = (float)(**(code **)(*param_1 + 0x108))(param_1,iVar19,local_7c,iVar15,puVar9);
LAB_001c11de:
            *(float *)pdVar2 = fVar20;
            break;
          case 0x53:
            *piVar1 = 8;
            uVar7 = (**(code **)(*param_1 + 0x138))(param_1,iVar19,local_7c,iVar15,puVar9);
LAB_001c1243:
            *(undefined2 *)pdVar2 = uVar7;
            break;
          case 0x56:
            *piVar1 = 0;
            (**(code **)(*param_1 + 0x174))(param_1,iVar19,local_7c,iVar15,puVar9);
            break;
          case 0x5a:
            *piVar1 = 1;
            uVar5 = (**(code **)(*param_1 + 0x114))(param_1,iVar19,local_7c,iVar15,puVar9);
LAB_001c129a:
            *(undefined *)pdVar2 = uVar5;
          }
          (**(code **)(*param_1 + 0x5c))(param_1,local_7c);
          cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
          if (cVar6 == '\0') {
            cVar6 = (**(code **)(*param_1 + 0x390))(param_1);
            if (cVar6 != '\0') {
              *piVar1 = 0;
              fVar20 = 0.0;
              goto switchD_001c1635_caseD_0;
            }
            if (((iVar3 == 0x4000) || (iVar3 == 0x100)) && (iVar4 != 0)) {
              (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
            }
            iVar15 = *piVar1;
            fVar20 = 0.0;
            switch(iVar15) {
            case 0:
              break;
            case 1:
            case 2:
              fVar20 = (float)(uint)*(byte *)pdVar2;
              break;
            case 3:
            case 5:
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xc:
            case 0xd:
            case 0xe:
            case 0xf:
            case 0x11:
            case 0x12:
            case 0x13:
            case 0x14:
            case 0x15:
            case 0x16:
            case 0x17:
            case 0x18:
            case 0x19:
            case 0x1a:
            case 0x1b:
            case 0x1c:
            case 0x1d:
            case 0x1e:
            case 0x1f:
            case 0x20:
            case 0x21:
            case 0x22:
            case 0x23:
            case 0x24:
            case 0x25:
            case 0x26:
            case 0x27:
            case 0x28:
            case 0x29:
            case 0x2a:
            case 0x2b:
            case 0x2c:
            case 0x2d:
            case 0x2e:
            case 0x2f:
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
            case 0x3a:
            case 0x3b:
            case 0x3c:
            case 0x3d:
            case 0x3e:
            case 0x3f:
              goto switchD_001c1635_caseD_3;
            case 4:
            case 8:
              fVar20 = (float)(uint)*(ushort *)pdVar2;
              break;
            case 0x10:
            case 0x40:
switchD_001c1635_caseD_10:
              fVar20 = *(float *)pdVar2;
              break;
            default:
              if (iVar15 < 0x800) {
                if (iVar15 == 0x100) goto switchD_001c1635_caseD_10;
                if ((iVar15 == 0x200) || (iVar15 == 0x400)) break;
              }
              else {
                if (iVar15 == 0x800) break;
                if ((iVar15 == 0x1000) || (iVar15 == 0x4000)) goto switchD_001c1635_caseD_10;
              }
              goto switchD_001c1635_caseD_3;
            }
switchD_001c1635_caseD_0:
            *(float *)pdVar2 = fVar20;
            *(float *)((int)pdVar2 + 4) = 0.0;
switchD_001c1635_caseD_3:
            (**(code **)(*param_1 + 0x5c))(param_1,iVar10);
            goto joined_r0x001c15cd;
          }
          (**(code **)(*param_1 + 0x40))(param_1);
LAB_001c0d80:
          (**(code **)(*param_1 + 0x44))(param_1);
LAB_001c0d8c:
          local_7c = (**(code **)(*param_1 + 0x28))(param_1,local_7c);
        } while (local_7c != 0);
      }
      (**(code **)(*param_1 + 0x5c))(param_1,iVar10);
      if (puVar9 != local_3c) {
        FUN_0018ae20(puVar9);
      }
      (**(code **)(*param_1 + 0x40))(param_1);
      (**(code **)(*param_1 + 0x44))(param_1);
      FUN_001c0530(param_1,param_2);
      return 0;
    }
    FUN_001b7f40("dex-vmp: fail to find class: %s\n",pcVar23);
    iVar15 = *param_2;
    uVar21 = param_2[8] & 0xffff;
    iVar19 = *(int *)(iVar15 + 8);
    iVar10 = *(int *)(iVar15 + 0x14);
    iVar3 = *(int *)(iVar15 + 0x2c);
    pcVar23 = (char *)(*(int *)(iVar19 + *(int *)(iVar10 + 4 + uVar21 * 8) * 4) + iVar3);
    do {
      cVar6 = *pcVar23;
      pcVar23 = pcVar23 + 1;
    } while (cVar6 < '\0');
    pcVar24 = (char *)(*(int *)(iVar19 + *(int *)(*(int *)(iVar15 + 0x18) +
                                                 (uint)*(ushort *)(iVar10 + 2 + uVar21 * 8) * 0xc) *
                                         4) + iVar3);
    do {
      cVar6 = *pcVar24;
      pcVar24 = pcVar24 + 1;
    } while (cVar6 < '\0');
    pcVar22 = (char *)(iVar3 + *(int *)(iVar19 + *(int *)(*(int *)(iVar15 + 0xc) +
                                                         (uint)*(ushort *)(iVar10 + uVar21 * 8) * 4)
                                                 * 4));
    do {
      cVar6 = *pcVar22;
      pcVar22 = pcVar22 + 1;
    } while (cVar6 < '\0');
    FUN_001b7f40("dex-vmp: error in %08X. %s(%s) <- %s at 0x%X\n",param_2[8],pcVar23,pcVar24,pcVar22
                 ,(param_2[10] - param_2[1]) + -0x10);
  }
joined_r0x001c15cd:
  if (puVar9 != local_3c) {
    FUN_0018ae20(puVar9);
  }
  return 0;
}

