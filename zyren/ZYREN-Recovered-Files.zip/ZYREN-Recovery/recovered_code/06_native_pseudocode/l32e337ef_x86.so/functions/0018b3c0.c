/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0018b3c0 FUN_0018b3c0 */

void FUN_0018b3c0(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x0018b3c0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x194))();
  return;
}

