/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e9eb0 FUN_001e9eb0 */

undefined4 __regparm3
FUN_001e9eb0(undefined4 param_1_00,int param_2_00,undefined4 param_3_00,int param_1,
            undefined4 param_2,char param_3)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  char *local_420;
  char local_410 [1024];
  
  iVar3 = FUN_0018b0c0(param_3_00,&DAT_00217bf0);
  if (iVar3 == 0) {
    return 0;
  }
  FUN_0018ae30(local_410,0,0x400);
  iVar4 = FUN_0018b180(local_410,0x400,iVar3);
  if (iVar4 != 0) {
    if (param_1 == 0) {
      do {
        iVar4 = FUN_0018b180(local_410,0x400,iVar3);
        param_2 = 0;
      } while (iVar4 != 0);
      goto LAB_001ea076;
    }
    do {
      if (local_410[0] != '\0') {
        iVar4 = 0;
        do {
          pcVar1 = *(char **)(param_2_00 + iVar4 * 4);
          if ((pcVar1 != (char *)0x0) && (*pcVar1 != '\0')) {
            uVar5 = FUN_0018af10(pcVar1);
            local_420 = local_410;
            do {
              uVar8 = 0;
              do {
                if ((uVar5 <= uVar8) || (local_420[uVar8] == '\0')) goto LAB_001e9fe3;
                cVar2 = pcVar1[uVar8];
                iVar6 = FUN_0018b360(local_420[uVar8]);
                iVar7 = FUN_0018b360(cVar2);
                uVar8 = uVar8 + 1;
              } while (iVar6 == iVar7);
              uVar8 = ((iVar6 == iVar7) - 1) + uVar8;
LAB_001e9fe3:
              if (uVar8 == uVar5) {
                if ((param_3 != '\0') && (cVar2 = FUN_001ea0b0(), cVar2 != '\0')) {
                  DAT_00276d0c = 1;
                }
                goto LAB_001ea076;
              }
              local_420 = local_420 + 1;
            } while (*local_420 != '\0');
          }
          iVar4 = iVar4 + 1;
        } while (iVar4 != param_1);
      }
      iVar4 = FUN_0018b180(local_410,0x400,iVar3);
    } while (iVar4 != 0);
  }
  param_2 = 0;
LAB_001ea076:
  FUN_0018b120(iVar3);
  return param_2;
}

