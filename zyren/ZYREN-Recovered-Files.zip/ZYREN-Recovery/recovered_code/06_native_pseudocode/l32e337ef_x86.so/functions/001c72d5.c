/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c72d5 FUN_001c72d5 */

undefined4 FUN_001c72d5(undefined4 param_1,int param_2)

{
  int unaff_retaddr;
  
  if (*(int *)(param_2 + 0x5c64) - 2U < 6) {
    return *(undefined4 *)(&UNK_00056f5b + *(int *)(param_2 + 0x5c64) * 4 + unaff_retaddr);
  }
  return 0;
}

