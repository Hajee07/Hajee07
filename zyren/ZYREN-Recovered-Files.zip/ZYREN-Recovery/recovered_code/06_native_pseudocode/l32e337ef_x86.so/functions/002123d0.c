/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002123d0 FUN_002123d0 */

undefined4 FUN_002123d0(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (*(char *)((int)piVar1 + 6) == '\x02') {
    uVar2 = (**(code **)(*piVar1 + 4))(piVar1,param_2);
  }
  else {
    uVar2 = CONCAT31((int3)((uint)piVar1 >> 8),*(char *)((int)piVar1 + 6) == '\0');
  }
  return uVar2;
}

