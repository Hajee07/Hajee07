/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002153c7 FUN_002153c7 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int __regparm2 FUN_002153c7(undefined4 param_1_00,undefined4 param_2,undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  byte bVar5;
  undefined8 uVar6;
  undefined4 local_1dc [32];
  undefined4 local_15c [18];
  undefined4 local_114;
  undefined4 local_110;
  int local_fc;
  code *local_34;
  int local_18;
  undefined4 local_14;
  
  bVar5 = 0;
  local_14 = param_2;
  FUN_00215085();
  puVar3 = local_1dc;
  puVar4 = local_15c;
  for (iVar1 = 0x20; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar4 = *puVar3;
    puVar3 = puVar3 + (uint)bVar5 * -2 + 1;
    puVar4 = puVar4 + (uint)bVar5 * -2 + 1;
  }
  while( true ) {
    uVar6 = FUN_00214da1();
    uVar2 = (undefined4)((ulonglong)uVar6 >> 0x20);
    if ((int)uVar6 == 5) {
      return 5;
    }
    if ((int)uVar6 != 0) break;
    if (local_34 != (code *)0x0) {
      iVar1 = (*local_34)(1,1,*param_1,param_1[1],param_1,local_15c,uVar2,uVar2);
      if (iVar1 == 6) {
        param_1[3] = 0;
        iVar1 = FUN_00213e9f(local_15c);
        param_1[4] = iVar1 + (local_fc >> 0x1f);
        puVar3 = local_1dc;
        puVar4 = local_15c;
        for (iVar1 = 0x20; iVar1 != 0; iVar1 = iVar1 + -1) {
          *puVar4 = *puVar3;
          puVar3 = puVar3 + (uint)bVar5 * -2 + 1;
          puVar4 = puVar4 + (uint)bVar5 * -2 + 1;
        }
        iVar1 = FUN_00215150();
        if (iVar1 == 7) {
          iVar1 = FUN_00213db9();
          FUN_002153c2(local_114,local_110,iVar1,iVar1);
          *(undefined4 *)(&stack0x00000000 + iVar1) = local_110;
          return local_18;
        }
        return iVar1;
      }
      if (iVar1 != 8) {
        return 3;
      }
    }
    FUN_00214d67();
  }
  return 3;
}

