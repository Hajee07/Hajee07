/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c31f0 FUN_001c31f0 */

void __regparm3
FUN_001c31f0(undefined4 param_1_00,int param_2_00,int *param_3_00,ushort *param_1,undefined4 param_2
            ,char param_3)

{
  double dVar1;
  int iVar2;
  ushort uVar3;
  uint uVar4;
  uint uVar5;
  longdouble lVar6;
  double dVar7;
  
  uVar4 = (uint)(*param_1 >> 8);
  if (param_3 == '\0') {
    uVar5 = param_1[1] & 0xff;
    uVar3 = param_1[1] >> 8;
  }
  else {
    uVar4 = uVar4 & 0xf;
    uVar3 = *param_1 >> 0xc;
    uVar5 = uVar4;
  }
  dVar7 = *(double *)(param_2_00 + 4 + uVar5 * 0xc);
  dVar1 = *(double *)(param_2_00 + 4 + (uint)uVar3 * 0xc);
  iVar2 = *(int *)(param_2_00 + uVar4 * 0xc);
  if (((iVar2 == 0x4000) || (iVar2 == 0x100)) &&
     (iVar2 = *(int *)(param_2_00 + 4 + uVar4 * 0xc), iVar2 != 0)) {
    (**(code **)(*param_3_00 + 0x5c))(param_3_00,iVar2);
  }
  *(undefined4 *)(param_2_00 + uVar4 * 0xc) = 0x80;
  switch(param_2) {
  case 0xab:
  case 0xcb:
    dVar7 = dVar7 + dVar1;
    break;
  case 0xac:
  case 0xcc:
    dVar7 = dVar7 - dVar1;
    break;
  case 0xad:
  case 0xcd:
    dVar7 = dVar7 * dVar1;
    break;
  case 0xae:
  case 0xce:
    dVar7 = dVar7 / dVar1;
    break;
  case 0xaf:
  case 0xcf:
    lVar6 = (longdouble)FUN_0018b2a0(dVar7,dVar1);
    dVar7 = (double)lVar6;
    break;
  default:
    goto switchD_001c32b0_caseD_b0;
  }
  *(double *)(param_2_00 + 4 + uVar4 * 0xc) = dVar7;
switchD_001c32b0_caseD_b0:
  return;
}

