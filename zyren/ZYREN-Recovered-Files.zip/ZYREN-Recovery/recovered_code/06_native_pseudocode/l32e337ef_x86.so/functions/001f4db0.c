/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f4db0 FUN_001f4db0 */

bool FUN_001f4db0(undefined4 param_1)

{
  int iVar1;
  
                    /* try { // try from 001f4dc9 to 001f4dd0 has its CatchHandler @ 001f4ddc */
  iVar1 = FUN_0018b3e0(param_1);
  return iVar1 == 0;
}

