/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00216999 FUN_00216999 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00216999(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined *puVar1;
  undefined4 *puVar2;
  
  puVar1 = PTR_pthread_create_0024bdf4;
  if ((param_1 != (int *)0x0) && (*param_1 != 0)) {
    param_2[4] = 0;
    param_2[1] = param_3;
    *param_2 = 0xffffffff;
    param_2[3] = param_1;
    param_2[2] = param_4;
    *(undefined2 *)(param_2 + 4) = 0x7f8;
    if (puVar1 != (undefined *)0x0) {
      FUN_0018adf0(&DAT_002771c0);
    }
    puVar2 = DAT_002771c8;
    DAT_002771c8 = param_2;
    param_2[5] = puVar2;
    if (puVar1 != (undefined *)0x0) {
      FUN_0018ae00(&DAT_002771c0);
    }
  }
  return;
}

