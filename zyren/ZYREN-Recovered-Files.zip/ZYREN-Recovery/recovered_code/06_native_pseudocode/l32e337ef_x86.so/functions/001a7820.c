/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a7820 FUN_001a7820 */

void FUN_001a7820(int *param_1,undefined8 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined8 *puVar8;
  uint local_20;
  
  iVar4 = *param_1;
  iVar7 = param_1[1];
  iVar3 = iVar7 - iVar4 >> 2;
  uVar1 = iVar3 * -0x55555555 + 1;
  if (0x15555555 < uVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_001a7a40(param_1);
  }
  iVar5 = param_1[2] - iVar4 >> 2;
  local_20 = 0x15555555;
  if ((uint)(iVar5 * -0x55555555) < 0xaaaaaaa) {
    local_20 = iVar5 * 0x55555556;
    if (local_20 < uVar1) {
      local_20 = uVar1;
    }
    if (local_20 != 0) goto LAB_001a7883;
    local_20 = 0;
    iVar5 = 0;
  }
  else {
LAB_001a7883:
    iVar5 = FUN_001f5520(local_20 * 0xc);
  }
  puVar8 = (undefined8 *)(iVar5 + iVar3 * 4);
  *(undefined4 *)(iVar5 + 4 + iVar3 * 4) = 0;
  *(undefined4 *)(iVar5 + iVar3 * 4) = 0;
  *(undefined4 *)(iVar5 + 8 + iVar3 * 4) = 0;
  if ((*(byte *)param_2 & 1) == 0) {
    *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(param_2 + 1);
    *puVar8 = *param_2;
    goto LAB_001a7954;
  }
  uVar1 = *(uint *)((int)param_2 + 4);
  if (0xffffffef < uVar1) {
                    /* try { // try from 001a7a06 to 001a7a10 has its CatchHandler @ 001a7a11 */
                    /* WARNING: Subroutine does not return */
    FUN_001a6e40(puVar8);
  }
  uVar2 = *(undefined4 *)(param_2 + 1);
  if (uVar1 < 0xb) {
    *(char *)puVar8 = (char)uVar1 * '\x02';
    iVar4 = (int)puVar8 + 1;
    if (uVar1 != 0) goto LAB_001a7933;
  }
  else {
    uVar6 = uVar1 + 0x10 & 0xfffffff0;
                    /* try { // try from 001a790c to 001a7913 has its CatchHandler @ 001a7a11 */
    iVar4 = FUN_001f5520(uVar6);
    *(int *)(iVar5 + 8 + iVar3 * 4) = iVar4;
    *(uint *)puVar8 = uVar6 | 1;
    *(uint *)(iVar5 + 4 + iVar3 * 4) = uVar1;
LAB_001a7933:
    FUN_0018ae80(iVar4,uVar2,uVar1);
  }
  *(undefined *)(iVar4 + uVar1) = 0;
  iVar4 = *param_1;
  iVar7 = param_1[1];
LAB_001a7954:
  iVar3 = (int)puVar8 + 0xc;
  if (iVar7 != iVar4) {
    do {
      *(undefined4 *)((int)puVar8 + -4) = *(undefined4 *)(iVar7 + -4);
      *(undefined8 *)((int)puVar8 + -0xc) = *(undefined8 *)(iVar7 + -0xc);
      puVar8 = (undefined8 *)((int)puVar8 + -0xc);
      *(undefined4 *)(iVar7 + -8) = 0;
      *(undefined4 *)(iVar7 + -0xc) = 0;
      *(undefined4 *)(iVar7 + -4) = 0;
      iVar7 = iVar7 + -0xc;
    } while (iVar4 != iVar7);
    iVar4 = *param_1;
    iVar7 = param_1[1];
  }
  *param_1 = (int)puVar8;
  param_1[1] = iVar3;
  param_1[2] = iVar5 + local_20 * 0xc;
  while (iVar3 = iVar7, iVar3 != iVar4) {
    iVar7 = iVar3 + -0xc;
    if ((*(byte *)(iVar3 + -0xc) & 1) != 0) {
      FUN_001f5680(*(undefined4 *)(iVar3 + -4));
    }
  }
  if (iVar4 != 0) {
    FUN_001f5680(iVar4);
  }
  return;
}

