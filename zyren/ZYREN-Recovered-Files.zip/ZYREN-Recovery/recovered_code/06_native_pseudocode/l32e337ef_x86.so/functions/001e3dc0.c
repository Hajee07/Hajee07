/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e3dc0 FUN_001e3dc0 */

uint FUN_001e3dc0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  uVar2 = *(uint *)(param_1 + 0x50);
  if (-1 < (int)uVar2) {
    piVar1 = *(int **)(param_1 + 0x48);
    if (((piVar1 != (int *)0x0) && (uVar2 < *(uint *)(param_1 + 0x10))) &&
       (iVar3 = *piVar1 + *(int *)(piVar1[4] + uVar2 * 4), iVar3 != 0)) {
      if ((*(ushort *)(iVar3 + 0x1c) == 0) ||
         (uVar2 = 1, *(char *)(iVar3 + 0x2d + (uint)*(ushort *)(iVar3 + 0x1c)) != '/')) {
        uVar2 = *(uint *)(iVar3 + 0x26) >> 4 & 1;
      }
      return uVar2;
    }
    *(undefined4 *)(param_1 + 0x1c) = 0x18;
    return 0;
  }
  return 0xfffffff6;
}

