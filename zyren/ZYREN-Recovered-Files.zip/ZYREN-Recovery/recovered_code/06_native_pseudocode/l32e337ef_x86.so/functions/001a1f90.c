/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a1f90 FUN_001a1f90 */

void FUN_001a1f90(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined *puVar5;
  
  puVar5 = PTR_DAT_0024bba8;
  piVar2 = *(int **)(PTR_DAT_0024bba8 + 4);
  while (piVar4 = piVar2, piVar4 != (int *)puVar5) {
    piVar2 = (int *)piVar4[1];
    if (piVar4[2] == param_1) {
      iVar3 = *piVar4;
      *(int **)(iVar3 + 4) = piVar2;
      *(int *)piVar4[1] = iVar3;
      piVar1 = (int *)(puVar5 + 8);
      *piVar1 = *piVar1 + -1;
      FUN_001f5680(piVar4);
    }
  }
  (**(code **)PTR_DAT_0024bbd0)(param_1);
  return;
}

