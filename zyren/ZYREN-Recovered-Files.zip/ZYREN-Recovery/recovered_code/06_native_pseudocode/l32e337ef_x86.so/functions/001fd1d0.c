/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fd1d0 FUN_001fd1d0 */

void FUN_001fd1d0(undefined4 *param_1)

{
  *param_1 = PTR_DAT_0024bdec + 8;
  return;
}

