/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001aa460 FUN_001aa460 */

void FUN_001aa460(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_0018b0f0(1,0x13c);
  FUN_0018ae80(iVar1,PTR_s_dex_035_0024bc7c,0x13c);
  *(undefined4 *)(iVar1 + 8) = param_2;
  uVar2 = FUN_0018b0c0(param_1,&DAT_00217bf9);
  FUN_0018b140(iVar1,0x13c,1,uVar2);
  FUN_0018b120(uVar2);
  return;
}

