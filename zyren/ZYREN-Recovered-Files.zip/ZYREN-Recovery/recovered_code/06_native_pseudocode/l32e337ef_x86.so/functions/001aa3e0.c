/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001aa3e0 FUN_001aa3e0 */

void FUN_001aa3e0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0018b130(param_1,0);
  if (iVar1 == -1) {
    iVar1 = FUN_0018b0c0(param_1,&DAT_00217bf9);
    if (iVar1 != 0) {
      FUN_0018b140(PTR_s_dex_035_0024bc7c,0x13c,1,iVar1);
      FUN_0018b120(iVar1);
      FUN_0018b150(param_1,0x100);
    }
  }
  return;
}

