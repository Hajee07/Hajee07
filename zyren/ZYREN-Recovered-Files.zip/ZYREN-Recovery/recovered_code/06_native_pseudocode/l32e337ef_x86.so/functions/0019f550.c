/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019f550 FUN_0019f550 */

void FUN_0019f550(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined local_110f [255];
  undefined local_1010 [4096];
  
  FUN_0018ae30(local_110f,0,0xff);
  FUN_0018b030(local_110f,"/proc/self/fd/%d",param_1);
  FUN_0018ae30(local_1010,0,0x1000);
  FUN_0019c080();
  (**(code **)PTR_DAT_0024bb74)(param_1,param_2,param_3);
  return;
}

