/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7020 FUN_001f7020 */

void FUN_001f7020(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  int iVar4;
  int *piVar5;
  bool bVar6;
  bool bVar7;
  int local_20;
  int local_1c;
  int local_18;
  
  puVar3 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(int *)PTR___stack_chk_guard_0024bd6c;
  uVar1 = *param_1;
  uVar2 = param_1[1];
  if ((SBORROW4(uVar2,(uint)(uVar1 == 0)) != false) == (int)(uVar2 - (uVar1 == 0)) < 0) {
    iVar4 = FUN_00213aaa(uVar1,uVar2,1000000000,0);
    bVar7 = SBORROW4(uVar2,499999999) != SBORROW4(uVar2 + 0xe2329b01,(uint)(uVar1 < 0xc4653600));
    bVar6 = (int)((uVar2 + 0xe2329b01) - (uint)(uVar1 < 0xc4653600)) < 0;
    local_20 = 0x7fffffff;
    if (bVar7 != bVar6) {
      local_20 = iVar4;
    }
    local_1c = 999999999;
    if (bVar7 != bVar6) {
      local_1c = iVar4 * -1000000000 + uVar1;
    }
    do {
      iVar4 = FUN_0018b4a0(&local_20,&local_20);
      if (iVar4 != -1) break;
      piVar5 = (int *)FUN_0018aeb0();
    } while (*piVar5 == 4);
  }
  if (*(int *)puVar3 != local_18) {
                    /* WARNING: Subroutine does not return */
    FUN_0018adc0();
  }
  return;
}

