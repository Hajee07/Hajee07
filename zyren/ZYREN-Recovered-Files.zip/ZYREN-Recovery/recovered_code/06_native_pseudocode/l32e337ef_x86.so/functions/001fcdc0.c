/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fcdc0 FUN_001fcdc0 */

void FUN_001fcdc0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  *param_1 = PTR_DAT_0024bd7c + 8;
  iVar3 = param_1[1];
  LOCK();
  piVar1 = (int *)(iVar3 + -4);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 + -1 < 0) {
    FUN_001f5680(iVar3 + -0xc);
  }
  FUN_001fcb00(param_1);
  FUN_001f5680(param_1);
  return;
}

