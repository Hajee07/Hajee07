/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019c790 FUN_0019c790 */

uint FUN_0019c790(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  undefined3 uVar3;
  bool bVar4;
  bool bVar5;
  uint local_cc;
  uint local_c8;
  uint local_bc;
  uint local_74;
  uint local_70;
  uint local_6c;
  uint local_68;
  uint local_5c;
  uint local_14;
  uint local_10;
  
  iVar1 = FUN_0018b000(param_1,&local_6c);
  if (iVar1 == 0) {
    iVar1 = FUN_0018b000(param_2,&local_cc);
    if (iVar1 == 0) {
      bVar4 = true;
      uVar2 = local_6c ^ local_cc | local_68 ^ local_c8;
      uVar3 = (undefined3)(uVar2 >> 8);
      bVar5 = true;
      if (uVar2 == 0) {
        uVar2 = local_14 ^ local_74 | local_10 ^ local_70;
        bVar5 = uVar2 != 0;
        uVar3 = (undefined3)(uVar2 >> 8);
      }
      if ((local_5c & 0xf000) == 0x8000) {
        bVar4 = (local_bc & 0xf000) != 0x8000;
      }
      return CONCAT31(uVar3,bVar5 | bVar4) ^ 1;
    }
  }
  return 0;
}

