/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e5410 FUN_001e5410 */

undefined4 __regparm3
FUN_001e5410(undefined4 param_1_00,undefined4 param_2_00,int param_3,code *param_1,
            undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  char cVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  undefined4 uVar13;
  uint uVar14;
  char *pcVar15;
  char acStack_a67 [515];
  undefined local_864 [13];
  byte local_857;
  uint local_840;
  int local_83c;
  uint local_834;
  char local_818 [1030];
  undefined local_412 [512];
  char acStack_212 [514];
  char *pcVar16;
  
  FUN_0018ae30(acStack_a67 + 2,0,0x201);
  FUN_0018ae30(local_412,0,0x201);
  uVar2 = FUN_0018af10(param_2_00);
  if (0x200 < uVar2 + 1) {
    return 0xfffffffe;
  }
  FUN_0018ae30(local_864,0,0x44c);
  FUN_0018b050(acStack_a67 + 2,param_2_00);
  cVar9 = (acStack_a67 + 2)[uVar2 - 1];
  if ((cVar9 != '/') && (cVar9 != '\\')) {
    acStack_a67[uVar2 + 2] = '/';
    uVar2 = uVar2 + 1;
  }
  uVar7 = 0x200 - uVar2;
  if (0x1ff < uVar7) {
    uVar7 = 0x200;
  }
  uVar13 = 0;
  if ((param_3 != 0) && (uVar1 = *(uint *)(param_3 + 0x10), uVar1 != 0)) {
    uVar14 = 0;
joined_r0x001e550e:
    iVar3 = 0;
    if (param_3 != 0) {
      piVar5 = *(int **)(param_3 + 0x48);
      iVar3 = 0;
      if ((piVar5 != (int *)0x0) && (iVar3 = 0, uVar14 < *(uint *)(param_3 + 0x10))) {
        iVar3 = *piVar5 + *(int *)(piVar5[4] + uVar14 * 4);
      }
    }
    iVar3 = FUN_001dc030(iVar3,local_864,0);
    if (iVar3 == 0) {
      uVar13 = 0xfffffffd;
    }
    else {
      iVar3 = FUN_0018af10(local_818);
      if (iVar3 != 0) {
        pcVar16 = local_818 + 1;
        cVar9 = local_818[0];
        if (local_818[0] != '/') goto LAB_001e55ba;
        do {
          do {
            pcVar15 = pcVar16 + 1;
            cVar9 = *pcVar16;
            pcVar16 = pcVar15;
          } while (cVar9 == '/');
LAB_001e55ba:
        } while (cVar9 == '\\');
        iVar10 = 0;
        iVar8 = 0;
        iVar11 = 0;
        if (cVar9 == '\\') goto LAB_001e55f0;
LAB_001e55d0:
        if (cVar9 == '/') goto LAB_001e55f0;
        local_818[iVar8 + iVar10] = cVar9;
        iVar10 = iVar10 + 1;
        do {
          if (iVar3 + -1 == iVar11) {
            if (iVar10 == 0) {
LAB_001e56f0:
              local_818[iVar8] = '\0';
            }
            else {
              iVar3 = FUN_0018b060(local_818 + iVar8,&DAT_0021f693);
              if ((iVar3 == 0) ||
                 (iVar3 = FUN_0018b060(local_818 + iVar8,&DAT_0021f696), iVar3 == 0))
              goto LAB_001e56f0;
            }
            FUN_0018b250(acStack_a67 + uVar2 + 2,local_818,uVar7);
            FUN_0018ae30(acStack_212 + 1,0,0x201);
            if (acStack_a67[2] == '\0') goto LAB_001e57ae;
            uVar12 = 1;
            cVar9 = acStack_a67[2];
            goto LAB_001e5740;
          }
          cVar9 = pcVar16[iVar11];
          iVar11 = iVar11 + 1;
          if (cVar9 != '\\') goto LAB_001e55d0;
LAB_001e55f0:
          if (iVar10 != 0) {
            iVar4 = FUN_0018b060(local_818 + iVar8,&DAT_0021f693);
            if ((iVar4 != 0) && (iVar4 = FUN_0018b060(local_818 + iVar8,&DAT_0021f696), iVar4 != 0))
            {
              iVar4 = iVar8 + iVar10;
              iVar8 = iVar8 + 1 + iVar10;
              local_818[iVar4] = cVar9;
            }
          }
          iVar10 = 0;
        } while( true );
      }
      uVar13 = 0xfffffffe;
    }
  }
LAB_001e5956:
  iVar3 = FUN_001d7270();
  uVar6 = 0xffffffe7;
  if (iVar3 != 0) {
    uVar6 = uVar13;
  }
  return uVar6;
LAB_001e5740:
  do {
    if (((cVar9 == '\\') || (cVar9 == '/')) && (uVar12 != 1)) {
      if (cVar9 == '\\') {
        acStack_a67[uVar12 + 1] = '/';
      }
      iVar3 = FUN_0018b1c0(acStack_212 + 1,0x1ed);
      if ((iVar3 == -1) && (piVar5 = (int *)FUN_0018aeb0(), *piVar5 != 0x11)) {
        uVar13 = 0xffffffe9;
        goto LAB_001e5956;
      }
    }
    cVar9 = acStack_a67[uVar12 + 2];
    acStack_212[uVar12] = acStack_a67[uVar12 + 1];
  } while ((uVar12 < 0x200) && (uVar12 = uVar12 + 1, cVar9 != '\0'));
LAB_001e57ae:
  if (((local_857 | 0x10) == 0x13) && ((local_834 & 0x20000000) != 0)) {
    uVar13 = 0xffffffee;
    if ((local_83c != 0 || (uint)-local_83c < (uint)(0x200 < local_840)) ||
       (iVar3 = FUN_001d9950(local_412,0x200,0,0,0,0), iVar3 == 0)) goto LAB_001e5956;
    local_412[local_840] = 0;
    iVar3 = FUN_0018b330(local_412,acStack_a67 + 2);
    if (iVar3 != 0) {
      uVar13 = 0xffffffe8;
      goto LAB_001e5956;
    }
    goto LAB_001e58fa;
  }
  if (param_3 == 0) {
LAB_001e5817:
    iVar3 = FUN_001db790(param_3,uVar14,acStack_a67 + 2,0);
    if (iVar3 == 0) {
      uVar13 = 0xffffffed;
      goto LAB_001e5956;
    }
  }
  else {
    piVar5 = *(int **)(param_3 + 0x48);
    if (((piVar5 == (int *)0x0) || (*(uint *)(param_3 + 0x10) <= uVar14)) ||
       (iVar3 = *piVar5 + *(int *)(piVar5[4] + uVar14 * 4), iVar3 == 0)) {
      *(undefined4 *)(param_3 + 0x1c) = 0x18;
      goto LAB_001e5817;
    }
    if (((*(ushort *)(iVar3 + 0x1c) == 0) ||
        (*(char *)(iVar3 + 0x2d + (uint)*(ushort *)(iVar3 + 0x1c)) != '/')) &&
       ((*(byte *)(iVar3 + 0x26) & 0x10) == 0)) goto LAB_001e5817;
  }
  if ((local_834 >> 0x10 != 0) &&
     (iVar3 = FUN_0018b150(acStack_a67 + 2,local_834 >> 0x10), iVar3 < 0)) {
    uVar13 = 0xffffffec;
    goto LAB_001e5956;
  }
LAB_001e58fa:
  if (((param_1 != (code *)0x0) && (iVar3 = (*param_1)(acStack_a67 + 2,param_2), iVar3 < 0)) ||
     (uVar14 = uVar14 + 1, uVar14 == uVar1)) goto LAB_001e592a;
  goto joined_r0x001e550e;
LAB_001e592a:
  uVar13 = 0;
  goto LAB_001e5956;
}

