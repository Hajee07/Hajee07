/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001da2d0 FUN_001da2d0 */

void FUN_001da2d0(int param_1,uint param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = 0;
  if (((param_1 != 0) && (piVar1 = *(int **)(param_1 + 0x48), piVar1 != (int *)0x0)) &&
     (param_2 < *(uint *)(param_1 + 0x10))) {
    iVar2 = *piVar1 + *(int *)(piVar1[4] + param_2 * 4);
  }
  FUN_001dc030(iVar2,param_3,0,0x1da2d8);
  return;
}

