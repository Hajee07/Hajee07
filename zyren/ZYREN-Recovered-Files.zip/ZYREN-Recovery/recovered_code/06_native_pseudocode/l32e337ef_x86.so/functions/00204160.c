/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00204160 FUN_00204160 */

int FUN_00204160(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = param_1;
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(undefined *)(param_1 + 0x10) = 1;
                    /* try { // try from 0020418f to 00204197 has its CatchHandler @ 002041a7 */
    iVar1 = (**(code **)(**(int **)(param_1 + 0xc) + 0xc))(*(int **)(param_1 + 0xc),param_2);
    *(undefined *)(param_1 + 0x10) = 0;
  }
  return iVar1;
}

