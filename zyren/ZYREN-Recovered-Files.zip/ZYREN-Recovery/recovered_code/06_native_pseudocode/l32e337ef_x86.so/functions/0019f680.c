/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019f680 FUN_0019f680 */

void FUN_0019f680(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14)

{
  undefined local_110f [255];
  undefined local_1010 [4096];
  
  FUN_0018ae30(local_110f,0,0xff);
  FUN_0018b030(local_110f,"/proc/self/fd/%d",param_1);
  FUN_0018ae30(local_1010,0,0x1000);
  FUN_0019c080();
  (**(code **)PTR_DAT_0024bb7c)
            (param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
             param_11,param_12,param_13,param_14);
  return;
}

