/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a3900 FUN_001a3900 */

int ** FUN_001a3900(int *param_1,int **param_2)

{
  int **ppiVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  int **ppiVar5;
  byte *pbVar6;
  uint uVar7;
  int **ppiVar8;
  ushort uVar9;
  int **ppiVar10;
  uint uVar11;
  int **ppiVar12;
  int **ppiVar13;
  int *piVar14;
  byte bVar15;
  byte bVar16;
  int iVar17;
  int iVar18;
  uint uVar19;
  int **ppiVar20;
  bool bVar21;
  int **local_40;
  uint local_3c;
  int *local_38;
  uint local_34;
  int *local_30;
  uint local_2c;
  uint local_28;
  uint local_24;
  int *local_1c;
  
  if (param_1 == (int *)0x0) {
    return (int **)&__DT_PLTGOT;
  }
  if (param_2 == (int **)0x0) {
    return (int **)&__DT_PLTGOT;
  }
  ppiVar1 = *(int ***)(PTR_DAT_0024bc04 + 4);
  if (ppiVar1 == (int **)0x0) {
    return (int **)&__DT_PLTGOT;
  }
  uVar4 = ((uint)((int)param_1 * 0x5bd1e995) >> 0x18 ^ (int)param_1 * 0x5bd1e995) * 0x5bd1e995 ^
          0x6f47a654;
  uVar4 = (uVar4 >> 0xd ^ uVar4) * 0x5bd1e995;
  ppiVar10 = (int **)(uVar4 >> 0xf ^ uVar4);
  uVar4 = (int)ppiVar1 - ((uint)ppiVar1 >> 1 & 0x55555555);
  uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333);
  uVar4 = ((uVar4 >> 4) + uVar4 & 0xf0f0f0f) * 0x1010101 >> 0x18;
  if (uVar4 < 2) {
    ppiVar12 = (int **)((int)ppiVar1 - 1U & (uint)ppiVar10);
  }
  else {
    ppiVar12 = ppiVar10;
    if (ppiVar1 <= ppiVar10) {
      ppiVar12 = (int **)((uint)ppiVar10 % (uint)ppiVar1);
    }
  }
  ppiVar5 = *(int ***)(*(int *)PTR_DAT_0024bc04 + (int)ppiVar12 * 4);
  if (ppiVar5 == (int **)0x0) {
    return (int **)0x0;
  }
  ppiVar20 = (int **)*ppiVar5;
  if (ppiVar20 == (int **)0x0) {
    return ppiVar5;
  }
  if (1 < uVar4) {
    do {
      ppiVar5 = (int **)ppiVar20[1];
      if (ppiVar5 == ppiVar10) {
        if (ppiVar20[2] == param_1) goto LAB_001a3a4d;
      }
      else {
        if (ppiVar1 <= ppiVar5) {
          ppiVar5 = (int **)((uint)ppiVar5 % (uint)ppiVar1);
        }
        if (ppiVar5 != ppiVar12) {
          return ppiVar5;
        }
      }
      ppiVar20 = (int **)*ppiVar20;
      if (ppiVar20 == (int **)0x0) {
        return ppiVar5;
      }
    } while( true );
  }
  ppiVar5 = (int **)ppiVar20[1];
  if (ppiVar5 != ppiVar10) goto LAB_001a3a06;
  while (ppiVar20[2] != param_1) {
    while( true ) {
      ppiVar20 = (int **)*ppiVar20;
      if (ppiVar20 == (int **)0x0) {
        return ppiVar5;
      }
      ppiVar5 = (int **)ppiVar20[1];
      if (ppiVar5 == ppiVar10) break;
LAB_001a3a06:
      ppiVar5 = (int **)((uint)ppiVar5 & (int)ppiVar1 - 1U);
      if (ppiVar5 != ppiVar12) {
        return ppiVar5;
      }
    }
  }
LAB_001a3a4d:
  piVar2 = ppiVar20[3];
  if (piVar2 == (int *)0x0) {
    return (int **)0x0;
  }
  ppiVar1 = *(int ***)(PTR_DAT_0024bc10 + 4);
  if (ppiVar1 == (int **)0x0) {
    return (int **)&__DT_PLTGOT;
  }
  uVar4 = (int)ppiVar1 - ((uint)ppiVar1 >> 1 & 0x55555555);
  uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333);
  uVar4 = ((uVar4 >> 4) + uVar4 & 0xf0f0f0f) * 0x1010101 >> 0x18;
  if (uVar4 < 2) {
    ppiVar12 = (int **)((int)ppiVar1 - 1U & (uint)ppiVar10);
  }
  else {
    ppiVar12 = ppiVar10;
    if (ppiVar1 <= ppiVar10) {
      ppiVar12 = (int **)((uint)ppiVar10 % (uint)ppiVar1);
    }
  }
  ppiVar5 = *(int ***)(*(int *)PTR_DAT_0024bc10 + (int)ppiVar12 * 4);
  if (ppiVar5 == (int **)0x0) {
    return (int **)0x0;
  }
  ppiVar20 = (int **)*ppiVar5;
  if (ppiVar20 == (int **)0x0) {
    return ppiVar5;
  }
  if (1 < uVar4) {
    do {
      ppiVar5 = (int **)ppiVar20[1];
      if (ppiVar5 == ppiVar10) {
        if (ppiVar20[2] == param_1) goto LAB_001a3b2f;
      }
      else {
        if (ppiVar1 <= ppiVar5) {
          ppiVar5 = (int **)((uint)ppiVar5 % (uint)ppiVar1);
        }
        if (ppiVar5 != ppiVar12) {
          return ppiVar5;
        }
      }
      ppiVar20 = (int **)*ppiVar20;
      if (ppiVar20 == (int **)0x0) {
        return ppiVar5;
      }
    } while( true );
  }
  ppiVar5 = (int **)ppiVar20[1];
  if (ppiVar5 != ppiVar10) goto LAB_001a3b01;
  while (ppiVar20[2] != param_1) {
    while( true ) {
      ppiVar20 = (int **)*ppiVar20;
      if (ppiVar20 == (int **)0x0) {
        return ppiVar5;
      }
      ppiVar5 = (int **)ppiVar20[1];
      if (ppiVar5 == ppiVar10) break;
LAB_001a3b01:
      ppiVar5 = (int **)((uint)ppiVar5 & (int)ppiVar1 - 1U);
      if (ppiVar5 != ppiVar12) {
        return ppiVar5;
      }
    }
  }
LAB_001a3b2f:
  ppiVar1 = (int **)ppiVar20[3];
  if (ppiVar1 == (int **)0x0) {
    return (int **)0x0;
  }
  ppiVar10 = (int **)ppiVar1[1];
  if (ppiVar10 == (int **)0x0) {
    return ppiVar1;
  }
  ppiVar1 = (int **)ppiVar1[2];
  if (ppiVar1 < (int **)0x70) {
    return ppiVar1;
  }
  if (*(char *)ppiVar10 != 'd') {
    return ppiVar1;
  }
  if (*(char *)((int)ppiVar10 + 1) != 'e') {
    return ppiVar1;
  }
  if (*(char *)((int)ppiVar10 + 2) != 'x') {
    return ppiVar1;
  }
  if (*(char *)((int)ppiVar10 + 3) != '\n') {
    return ppiVar1;
  }
  ppiVar12 = (int **)ppiVar10[8];
  if (ppiVar12 < (int **)0x70) {
    return ppiVar1;
  }
  if (ppiVar1 < ppiVar12) {
    return ppiVar1;
  }
  if (param_2 < ppiVar10) {
    return ppiVar1;
  }
  ppiVar1 = (int **)((int)ppiVar10 + (int)ppiVar12);
  if (ppiVar1 < param_2 + 8) {
    return param_2 + 8;
  }
  ppiVar5 = (int **)param_2[6];
  if (ppiVar5 == (int **)0x0) {
    return param_2;
  }
  if (ppiVar12 <= ppiVar5) {
    return ppiVar5;
  }
  if ((int)ppiVar12 <= (int)ppiVar5) {
    return ppiVar5;
  }
  pbVar6 = (byte *)((int)ppiVar5 + (int)ppiVar10);
  bVar16 = *pbVar6;
  local_38 = (int *)0x0;
  if ((char)bVar16 < '\0') {
    if (ppiVar1 <= pbVar6 + 1) {
      return (int **)(CONCAT31((int3)((uint)ppiVar5 >> 8),bVar16) & 0xffffff7f);
    }
    bVar15 = pbVar6[1];
    param_1 = (int *)CONCAT31((int3)((uint)param_1 >> 8),bVar15);
    local_3c = (uint)(bVar15 & 0x7f) << 7 | bVar16 & 0x7f;
    iVar17 = 2;
    if (-1 < (char)bVar15) goto LAB_001a3bc7;
    ppiVar5 = (int **)(pbVar6 + 2);
    if (ppiVar1 <= ppiVar5) {
      return ppiVar5;
    }
    param_1 = (int *)((uint)(*(byte *)ppiVar5 & 0x7f) * 0x4000);
    local_3c = local_3c + (int)param_1;
    iVar17 = 3;
    if (-1 < (char)*(byte *)ppiVar5) goto LAB_001a3bc7;
    ppiVar5 = (int **)(pbVar6 + 3);
    if (ppiVar1 <= ppiVar5) {
      return ppiVar5;
    }
    param_1 = (int *)((uint)(*(byte *)ppiVar5 & 0x7f) * 0x200000);
    local_3c = local_3c + (int)param_1;
    iVar17 = 4;
    if (-1 < (char)*(byte *)ppiVar5) goto LAB_001a3bc7;
    ppiVar5 = (int **)(pbVar6 + 4);
    if (ppiVar1 <= ppiVar5) {
      return ppiVar5;
    }
    bVar16 = *(byte *)ppiVar5;
    if ((char)bVar16 < '\0') {
      return (int **)CONCAT31((int3)((uint)ppiVar5 >> 8),bVar16);
    }
    local_38 = (int *)(uint)((bVar16 & 0x7f) >> 4);
    local_3c = local_3c + (uint)(bVar16 & 0x7f) * 0x10000000;
    iVar17 = 5;
    ppiVar5 = (int **)(pbVar6 + 5);
  }
  else {
    local_3c = bVar16 & 0x7f;
    iVar17 = 1;
LAB_001a3bc7:
    ppiVar5 = (int **)(pbVar6 + iVar17);
  }
  if (ppiVar1 <= ppiVar5) {
    return ppiVar5;
  }
  bVar16 = *(byte *)ppiVar5;
  iVar18 = iVar17 + 1;
  local_2c = 0;
  if ((char)bVar16 < '\0') {
    if (ppiVar1 <= pbVar6 + iVar18) {
      return (int **)(CONCAT31((int3)((uint)param_1 >> 8),bVar16) & 0xffffff7f);
    }
    bVar15 = pbVar6[iVar18];
    iVar18 = iVar17 + 2;
    uVar9 = CONCAT11(bVar15,bVar15) & 0x7fff;
    uVar4 = (uint)(uVar9 >> 8) << 7 | (uint)(int **)(bVar16 & 0x7f);
    if ((char)uVar9 < '\0') {
      if (ppiVar1 <= pbVar6 + iVar18) {
        return (int **)(bVar16 & 0x7f);
      }
      bVar16 = pbVar6[iVar18];
      iVar18 = iVar17 + 3;
      uVar4 = uVar4 + (uint)(bVar16 & 0x7f) * 0x4000;
      if ((char)bVar16 < '\0') {
        if (ppiVar1 <= pbVar6 + iVar18) {
          return (int **)(uint)bVar16;
        }
        bVar16 = pbVar6[iVar18];
        iVar18 = iVar17 + 4;
        uVar4 = uVar4 + (uint)(bVar16 & 0x7f) * 0x200000;
        if ((char)bVar16 < '\0') {
          if (ppiVar1 <= pbVar6 + iVar18) {
            return (int **)(uint)bVar16;
          }
          bVar16 = pbVar6[iVar18];
          if ((char)bVar16 < '\0') {
            return (int **)(uint)bVar16;
          }
          iVar18 = iVar17 + 5;
          local_2c = (uint)((bVar16 & 0x7f) >> 4);
          uVar4 = uVar4 + (uint)(bVar16 & 0x7f) * 0x10000000;
        }
      }
    }
  }
  else {
    uVar4 = bVar16 & 0x7f;
  }
  ppiVar5 = (int **)(pbVar6 + iVar18);
  if (ppiVar1 <= ppiVar5) {
    return ppiVar5;
  }
  bVar16 = *(byte *)ppiVar5;
  iVar17 = iVar18 + 1;
  bVar15 = bVar16 & 0x7f;
  local_30 = (int *)0x0;
  if ((char)bVar16 < '\0') {
    if (ppiVar1 <= pbVar6 + iVar17) {
      return (int **)CONCAT31((int3)((uint)ppiVar5 >> 8),bVar16);
    }
    bVar16 = pbVar6[iVar17];
    iVar17 = iVar18 + 2;
    uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
    uVar7 = (uint)(uVar9 >> 8) << 7 | (uint)(int **)(uint)bVar15;
    if ((char)uVar9 < '\0') {
      if (ppiVar1 <= pbVar6 + iVar17) {
        return (int **)(uint)bVar15;
      }
      bVar16 = pbVar6[iVar17];
      iVar17 = iVar18 + 3;
      uVar7 = uVar7 + (uint)(bVar16 & 0x7f) * 0x4000;
      if ((char)bVar16 < '\0') {
        if (ppiVar1 <= pbVar6 + iVar17) {
          return (int **)(uint)bVar16;
        }
        bVar16 = pbVar6[iVar17];
        iVar17 = iVar18 + 4;
        uVar7 = uVar7 + (uint)(bVar16 & 0x7f) * 0x200000;
        if ((char)bVar16 < '\0') {
          if (ppiVar1 <= pbVar6 + iVar17) {
            return (int **)(uint)bVar16;
          }
          bVar16 = pbVar6[iVar17];
          if ((char)bVar16 < '\0') {
            return (int **)(uint)bVar16;
          }
          iVar17 = iVar18 + 5;
          local_30 = (int *)(uint)((bVar16 & 0x7f) >> 4);
          uVar7 = uVar7 + (uint)(bVar16 & 0x7f) * 0x10000000;
        }
      }
    }
  }
  else {
    uVar7 = (uint)bVar15;
  }
  ppiVar5 = (int **)(pbVar6 + iVar17);
  if (ppiVar1 <= ppiVar5) {
    return ppiVar5;
  }
  local_40 = (int **)(iVar17 + 1);
  bVar16 = *(byte *)ppiVar5 & 0x7f;
  if ((char)*(byte *)ppiVar5 < '\0') {
    ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
    if (ppiVar1 <= ppiVar5) {
      return ppiVar5;
    }
    local_40 = (int **)(iVar17 + 2);
    uVar9 = CONCAT11(*(byte *)ppiVar5,*(byte *)ppiVar5) & 0x7fff;
    local_24 = (uint)(uVar9 >> 8) << 7 | (uint)bVar16;
    if ((char)uVar9 < '\0') {
      if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
        return local_40;
      }
      bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
      local_40 = (int **)(iVar17 + 3);
      local_24 = local_24 + (uint)(bVar16 & 0x7f) * 0x4000;
      if ((char)bVar16 < '\0') {
        if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
          return local_40;
        }
        bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
        local_40 = (int **)(iVar17 + 4);
        local_24 = local_24 + (uint)(bVar16 & 0x7f) * 0x200000;
        if ((char)bVar16 < '\0') {
          ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
          if (ppiVar1 <= ppiVar5) {
            return local_40;
          }
          bVar16 = *(byte *)ppiVar5;
          if ((char)bVar16 < '\0') {
            return (int **)CONCAT31((int3)((uint)ppiVar5 >> 8),bVar16);
          }
          local_40 = (int **)(iVar17 + 5);
          local_28 = (uint)((bVar16 & 0x7f) >> 4);
          local_24 = local_24 + (uint)(bVar16 & 0x7f) * 0x10000000;
          goto LAB_001a3c57;
        }
      }
    }
  }
  else {
    local_24 = (uint)bVar16;
  }
  local_28 = 0;
LAB_001a3c57:
  ppiVar5 = (int **)(local_2c | (uint)local_38 | (uint)local_30 | local_28);
  if (ppiVar5 == (int **)0x0 &&
      (uint)(0xffff < (uVar4 | local_3c | uVar7 | local_24)) <= (uint)-(int)ppiVar5) {
    if ((local_3c | (uint)local_38) != 0) {
      uVar19 = 0;
      uVar11 = 0;
      do {
        ppiVar5 = (int **)(pbVar6 + (int)local_40);
        if (ppiVar1 <= ppiVar5) {
          return ppiVar5;
        }
        ppiVar20 = (int **)((int)local_40 + 1);
        if ((char)*(byte *)ppiVar5 < '\0') {
          ppiVar8 = (int **)((int)ppiVar20 + (int)pbVar6);
          if (ppiVar1 <= ppiVar8) {
            return ppiVar5;
          }
          ppiVar20 = (int **)((int)local_40 + 2);
          if ((char)*(byte *)ppiVar8 < '\0') {
            ppiVar5 = (int **)((int)ppiVar20 + (int)pbVar6);
            if (ppiVar1 <= ppiVar5) {
              return ppiVar5;
            }
            ppiVar20 = (int **)((int)local_40 + 3);
            if ((char)*(byte *)ppiVar5 < '\0') {
              ppiVar8 = (int **)((int)ppiVar20 + (int)pbVar6);
              if (ppiVar1 <= ppiVar8) {
                return ppiVar5;
              }
              ppiVar20 = local_40 + 1;
              if ((char)*(byte *)ppiVar8 < '\0') {
                ppiVar20 = (int **)((int)ppiVar20 + (int)pbVar6);
                if (ppiVar1 <= ppiVar20) {
                  return ppiVar20;
                }
                if ((char)*(byte *)ppiVar20 < '\0') {
                  return ppiVar20;
                }
                ppiVar20 = (int **)((int)local_40 + 5);
              }
            }
          }
        }
        ppiVar5 = (int **)(pbVar6 + (int)ppiVar20);
        if (ppiVar1 <= ppiVar5) {
          return ppiVar5;
        }
        local_40 = (int **)((int)ppiVar20 + 1);
        if ((char)*(byte *)ppiVar5 < '\0') {
          ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
          if (ppiVar1 <= ppiVar5) {
            return ppiVar5;
          }
          local_40 = (int **)((int)ppiVar20 + 2);
          if ((char)*(byte *)ppiVar5 < '\0') {
            ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
            if (ppiVar1 <= ppiVar5) {
              return ppiVar5;
            }
            local_40 = (int **)((int)ppiVar20 + 3);
            if ((char)*(byte *)ppiVar5 < '\0') {
              ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
              if (ppiVar1 <= ppiVar5) {
                return ppiVar5;
              }
              local_40 = ppiVar20 + 1;
              if ((char)*(byte *)ppiVar5 < '\0') {
                local_40 = (int **)((int)local_40 + (int)pbVar6);
                if (ppiVar1 <= local_40) {
                  return local_40;
                }
                if ((char)*(byte *)local_40 < '\0') {
                  return local_40;
                }
                local_40 = (int **)((int)ppiVar20 + 5);
              }
            }
          }
        }
        bVar21 = 0xfffffffe < uVar19;
        uVar19 = uVar19 + 1;
        uVar11 = uVar11 + bVar21;
      } while (uVar11 < local_38 || uVar11 - (int)local_38 < (uint)(uVar19 < local_3c));
    }
    if ((uVar4 | local_2c) != 0) {
      uVar11 = 0;
      uVar19 = 0;
      do {
        ppiVar5 = (int **)(pbVar6 + (int)local_40);
        if (ppiVar1 <= ppiVar5) {
          return ppiVar5;
        }
        ppiVar20 = (int **)((int)local_40 + 1);
        if ((char)*(byte *)ppiVar5 < '\0') {
          ppiVar8 = (int **)((int)ppiVar20 + (int)pbVar6);
          if (ppiVar1 <= ppiVar8) {
            return ppiVar5;
          }
          ppiVar20 = (int **)((int)local_40 + 2);
          if ((char)*(byte *)ppiVar8 < '\0') {
            ppiVar5 = (int **)((int)ppiVar20 + (int)pbVar6);
            if (ppiVar1 <= ppiVar5) {
              return ppiVar5;
            }
            ppiVar20 = (int **)((int)local_40 + 3);
            if ((char)*(byte *)ppiVar5 < '\0') {
              ppiVar8 = (int **)((int)ppiVar20 + (int)pbVar6);
              if (ppiVar1 <= ppiVar8) {
                return ppiVar5;
              }
              ppiVar20 = local_40 + 1;
              if ((char)*(byte *)ppiVar8 < '\0') {
                ppiVar20 = (int **)((int)ppiVar20 + (int)pbVar6);
                if (ppiVar1 <= ppiVar20) {
                  return ppiVar20;
                }
                if ((char)*(byte *)ppiVar20 < '\0') {
                  return ppiVar20;
                }
                ppiVar20 = (int **)((int)local_40 + 5);
              }
            }
          }
        }
        ppiVar5 = (int **)(pbVar6 + (int)ppiVar20);
        if (ppiVar1 <= ppiVar5) {
          return ppiVar5;
        }
        local_40 = (int **)((int)ppiVar20 + 1);
        if ((char)*(byte *)ppiVar5 < '\0') {
          ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
          if (ppiVar1 <= ppiVar5) {
            return ppiVar5;
          }
          local_40 = (int **)((int)ppiVar20 + 2);
          if ((char)*(byte *)ppiVar5 < '\0') {
            ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
            if (ppiVar1 <= ppiVar5) {
              return ppiVar5;
            }
            local_40 = (int **)((int)ppiVar20 + 3);
            if ((char)*(byte *)ppiVar5 < '\0') {
              ppiVar5 = (int **)((int)local_40 + (int)pbVar6);
              if (ppiVar1 <= ppiVar5) {
                return ppiVar5;
              }
              local_40 = ppiVar20 + 1;
              if ((char)*(byte *)ppiVar5 < '\0') {
                local_40 = (int **)((int)local_40 + (int)pbVar6);
                if (ppiVar1 <= local_40) {
                  return local_40;
                }
                if ((char)*(byte *)local_40 < '\0') {
                  return local_40;
                }
                local_40 = (int **)((int)ppiVar20 + 5);
              }
            }
          }
        }
        bVar21 = 0xfffffffe < uVar11;
        uVar11 = uVar11 + 1;
        uVar19 = uVar19 + bVar21;
      } while (uVar19 < local_2c || uVar19 - local_2c < (uint)(uVar11 < uVar4));
    }
    if ((uVar7 | (uint)local_30) != 0) {
      local_2c = 0;
      local_34 = 0;
      local_38 = (int *)0x0;
      do {
        ppiVar5 = (int **)(pbVar6 + (int)local_40);
        if (ppiVar1 <= ppiVar5) {
          return ppiVar5;
        }
        ppiVar20 = (int **)((int)local_40 + 1);
        ppiVar8 = (int **)(*(byte *)ppiVar5 & 0x7f);
        if ((char)*(byte *)ppiVar5 < '\0') {
          if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
            return ppiVar8;
          }
          bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
          ppiVar20 = (int **)((int)local_40 + 2);
          ppiVar8 = (int **)((uint)(bVar16 & 0x7f) << 7 | (uint)ppiVar8);
          if ((char)bVar16 < '\0') {
            if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
              return ppiVar8;
            }
            bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
            ppiVar20 = (int **)((int)local_40 + 3);
            uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
            ppiVar8 = (int **)((uint)ppiVar8 | (uint)(uVar9 >> 8) << 0xe);
            if ((char)uVar9 < '\0') {
              if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
                return ppiVar8;
              }
              bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
              ppiVar20 = local_40 + 1;
              uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
              ppiVar8 = (int **)((uint)ppiVar8 | (uint)(uVar9 >> 8) << 0x15);
              if ((char)uVar9 < '\0') {
                if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
                  return ppiVar8;
                }
                bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
                if ((char)bVar16 < '\0') {
                  return ppiVar8;
                }
                ppiVar20 = (int **)((int)local_40 + 5);
                ppiVar8 = (int **)((uint)ppiVar8 | (uint)bVar16 << 0x1c);
              }
            }
          }
        }
        if (ppiVar1 <= pbVar6 + (int)ppiVar20) {
          return ppiVar8;
        }
        ppiVar5 = (int **)((int)ppiVar20 + 1);
        if ((char)pbVar6[(int)ppiVar20] < '\0') {
          ppiVar13 = (int **)((int)ppiVar5 + (int)pbVar6);
          if (ppiVar1 <= ppiVar13) {
            return ppiVar8;
          }
          ppiVar5 = (int **)((int)ppiVar20 + 2);
          if ((char)*(byte *)ppiVar13 < '\0') {
            ppiVar13 = (int **)((int)ppiVar5 + (int)pbVar6);
            if (ppiVar1 <= ppiVar13) {
              return ppiVar8;
            }
            ppiVar5 = (int **)((int)ppiVar20 + 3);
            if ((char)*(byte *)ppiVar13 < '\0') {
              ppiVar13 = (int **)((int)ppiVar5 + (int)pbVar6);
              if (ppiVar1 <= ppiVar13) {
                return ppiVar8;
              }
              ppiVar5 = ppiVar20 + 1;
              if ((char)*(byte *)ppiVar13 < '\0') {
                if (ppiVar1 <= (int **)((int)ppiVar5 + (int)pbVar6)) {
                  return ppiVar8;
                }
                if ((char)*(byte *)(int **)((int)ppiVar5 + (int)pbVar6) < '\0') {
                  return ppiVar8;
                }
                ppiVar5 = (int **)((int)ppiVar20 + 5);
              }
            }
          }
        }
        if (ppiVar1 <= pbVar6 + (int)ppiVar5) {
          return ppiVar8;
        }
        bVar16 = pbVar6[(int)ppiVar5];
        local_40 = (int **)((int)ppiVar5 + 1);
        local_3c = bVar16 & 0x7f;
        if ((char)bVar16 < '\0') {
          if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
            return ppiVar8;
          }
          bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
          local_40 = (int **)((int)ppiVar5 + 2);
          uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
          local_3c = (uint)(uVar9 >> 8) << 7 | local_3c;
          if ((char)uVar9 < '\0') {
            if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
              return ppiVar8;
            }
            bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
            local_40 = (int **)((int)ppiVar5 + 3);
            uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
            local_3c = local_3c + (uint)(uVar9 >> 8) * 0x4000;
            if ((char)uVar9 < '\0') {
              if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
                return ppiVar8;
              }
              bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
              local_40 = ppiVar5 + 1;
              uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
              local_3c = local_3c + (uint)(uVar9 >> 8) * 0x200000;
              if ((char)uVar9 < '\0') {
                if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
                  return ppiVar8;
                }
                bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
                if ((char)bVar16 < '\0') {
                  return ppiVar8;
                }
                local_40 = (int **)((int)ppiVar5 + 5);
                local_3c = local_3c + (uint)bVar16 * 0x10000000;
              }
            }
          }
        }
        local_38 = (int *)((int)local_38 + (int)ppiVar8);
        if ((local_3c != 0) && (piVar3 = (int *)piVar2[1], piVar3 != (int *)0x0)) {
          uVar4 = (int)piVar3 - ((uint)piVar3 >> 1 & 0x55555555);
          uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333);
          uVar4 = ((uVar4 >> 4) + uVar4 & 0xf0f0f0f) * 0x1010101 >> 0x18;
          if (uVar4 < 2) {
            local_1c = (int *)((int)piVar3 - 1U & (uint)local_38);
          }
          else {
            local_1c = local_38;
            if (piVar3 <= local_38) {
              local_1c = (int *)((uint)local_38 % (uint)piVar3);
            }
          }
          ppiVar5 = *(int ***)(*piVar2 + (int)local_1c * 4);
          if ((ppiVar5 != (int **)0x0) && (ppiVar5 = (int **)*ppiVar5, ppiVar5 != (int **)0x0)) {
            if (uVar4 < 2) {
              piVar14 = ppiVar5[1];
              if (piVar14 != local_38) goto LAB_001a461c;
              while (ppiVar5[2] != local_38) {
                while( true ) {
                  ppiVar5 = (int **)*ppiVar5;
                  if (ppiVar5 == (int **)0x0) goto LAB_001a4321;
                  piVar14 = ppiVar5[1];
                  if (piVar14 == local_38) break;
LAB_001a461c:
                  if ((int *)((uint)piVar14 & (int)piVar3 - 1U) != local_1c) goto LAB_001a4321;
                }
              }
LAB_001a46c3:
              if ((((0xffffffef < local_3c == 0 &&
                     (uint)(ppiVar12 < (int **)(local_3c + 0x10)) <= -(uint)(0xffffffef < local_3c))
                   && (piVar3 = ppiVar5[3], piVar3 != (int *)0x0)) &&
                  (piVar14 = ppiVar5[4], (int *)0xf < piVar14)) &&
                 ((piVar3[3] != 0 &&
                  (CARRY4((uint)piVar14,local_3c) == 0 &&
                   (uint)(ppiVar12 < (int **)((int)piVar14 + local_3c)) <=
                   -(uint)CARRY4((uint)piVar14,local_3c))))) {
                FUN_0018ae80((char *)(local_3c + (int)ppiVar10),piVar3,piVar14);
              }
            }
            else {
              do {
                piVar14 = ppiVar5[1];
                if (piVar14 == local_38) {
                  if (ppiVar5[2] == local_38) goto LAB_001a46c3;
                }
                else {
                  if (piVar3 <= piVar14) {
                    piVar14 = (int *)((uint)piVar14 % (uint)piVar3);
                  }
                  if (piVar14 != local_1c) break;
                }
                ppiVar5 = (int **)*ppiVar5;
              } while (ppiVar5 != (int **)0x0);
            }
          }
        }
LAB_001a4321:
        bVar21 = 0xfffffffe < local_2c;
        local_2c = local_2c + 1;
        local_34 = local_34 + bVar21;
      } while (local_34 < local_30 || local_34 - (int)local_30 < (uint)(local_2c < uVar7));
    }
    ppiVar5 = (int **)(local_24 | local_28);
    if (ppiVar5 != (int **)0x0) {
      local_2c = 0;
      local_34 = 0;
      local_38 = (int *)0x0;
      while (ppiVar5 = (int **)(pbVar6 + (int)local_40), ppiVar5 < ppiVar1) {
        ppiVar20 = (int **)((int)local_40 + 1);
        ppiVar8 = (int **)(*(byte *)ppiVar5 & 0x7f);
        if ((char)*(byte *)ppiVar5 < '\0') {
          if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
            return ppiVar8;
          }
          bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
          ppiVar20 = (int **)((int)local_40 + 2);
          ppiVar8 = (int **)((uint)(bVar16 & 0x7f) << 7 | (uint)ppiVar8);
          if ((char)bVar16 < '\0') {
            if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
              return ppiVar8;
            }
            bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
            ppiVar20 = (int **)((int)local_40 + 3);
            uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
            ppiVar8 = (int **)((uint)ppiVar8 | (uint)(uVar9 >> 8) << 0xe);
            if ((char)uVar9 < '\0') {
              if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
                return ppiVar8;
              }
              bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
              ppiVar20 = local_40 + 1;
              uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
              ppiVar8 = (int **)((uint)ppiVar8 | (uint)(uVar9 >> 8) << 0x15);
              if ((char)uVar9 < '\0') {
                if (ppiVar1 <= (int **)((int)ppiVar20 + (int)pbVar6)) {
                  return ppiVar8;
                }
                bVar16 = *(byte *)(int **)((int)ppiVar20 + (int)pbVar6);
                if ((char)bVar16 < '\0') {
                  return ppiVar8;
                }
                ppiVar20 = (int **)((int)local_40 + 5);
                ppiVar8 = (int **)((uint)ppiVar8 | (uint)bVar16 << 0x1c);
              }
            }
          }
        }
        if (ppiVar1 <= pbVar6 + (int)ppiVar20) {
          return ppiVar8;
        }
        ppiVar5 = (int **)((int)ppiVar20 + 1);
        if ((char)pbVar6[(int)ppiVar20] < '\0') {
          ppiVar13 = (int **)((int)ppiVar5 + (int)pbVar6);
          if (ppiVar1 <= ppiVar13) {
            return ppiVar8;
          }
          ppiVar5 = (int **)((int)ppiVar20 + 2);
          if ((char)*(byte *)ppiVar13 < '\0') {
            ppiVar13 = (int **)((int)ppiVar5 + (int)pbVar6);
            if (ppiVar1 <= ppiVar13) {
              return ppiVar8;
            }
            ppiVar5 = (int **)((int)ppiVar20 + 3);
            if ((char)*(byte *)ppiVar13 < '\0') {
              ppiVar13 = (int **)((int)ppiVar5 + (int)pbVar6);
              if (ppiVar1 <= ppiVar13) {
                return ppiVar8;
              }
              ppiVar5 = ppiVar20 + 1;
              if ((char)*(byte *)ppiVar13 < '\0') {
                if (ppiVar1 <= (int **)((int)ppiVar5 + (int)pbVar6)) {
                  return ppiVar8;
                }
                if ((char)*(byte *)(int **)((int)ppiVar5 + (int)pbVar6) < '\0') {
                  return ppiVar8;
                }
                ppiVar5 = (int **)((int)ppiVar20 + 5);
              }
            }
          }
        }
        if (ppiVar1 <= pbVar6 + (int)ppiVar5) {
          return ppiVar8;
        }
        bVar16 = pbVar6[(int)ppiVar5];
        local_40 = (int **)((int)ppiVar5 + 1);
        local_3c = bVar16 & 0x7f;
        if ((char)bVar16 < '\0') {
          if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
            return ppiVar8;
          }
          bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
          local_40 = (int **)((int)ppiVar5 + 2);
          uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
          local_3c = (uint)(uVar9 >> 8) << 7 | local_3c;
          if ((char)uVar9 < '\0') {
            if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
              return ppiVar8;
            }
            bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
            local_40 = (int **)((int)ppiVar5 + 3);
            uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
            local_3c = local_3c + (uint)(uVar9 >> 8) * 0x4000;
            if ((char)uVar9 < '\0') {
              if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
                return ppiVar8;
              }
              bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
              local_40 = ppiVar5 + 1;
              uVar9 = CONCAT11(bVar16,bVar16) & 0x7fff;
              local_3c = local_3c + (uint)(uVar9 >> 8) * 0x200000;
              if ((char)uVar9 < '\0') {
                if (ppiVar1 <= (int **)((int)local_40 + (int)pbVar6)) {
                  return ppiVar8;
                }
                bVar16 = *(byte *)(int **)((int)local_40 + (int)pbVar6);
                if ((char)bVar16 < '\0') {
                  return ppiVar8;
                }
                local_40 = (int **)((int)ppiVar5 + 5);
                local_3c = local_3c + (uint)bVar16 * 0x10000000;
              }
            }
          }
        }
        local_38 = (int *)((int)local_38 + (int)ppiVar8);
        if ((local_3c != 0) && (piVar3 = (int *)piVar2[1], piVar3 != (int *)0x0)) {
          uVar4 = (int)piVar3 - ((uint)piVar3 >> 1 & 0x55555555);
          uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333);
          uVar4 = ((uVar4 >> 4) + uVar4 & 0xf0f0f0f) * 0x1010101 >> 0x18;
          if (uVar4 < 2) {
            local_30 = (int *)((int)piVar3 - 1U & (uint)local_38);
          }
          else {
            local_30 = local_38;
            if (piVar3 <= local_38) {
              local_30 = (int *)((uint)local_38 % (uint)piVar3);
            }
          }
          ppiVar5 = *(int ***)(*piVar2 + (int)local_30 * 4);
          if ((ppiVar5 != (int **)0x0) && (ppiVar5 = (int **)*ppiVar5, ppiVar5 != (int **)0x0)) {
            if (uVar4 < 2) {
              piVar14 = ppiVar5[1];
              if (piVar14 != local_38) goto LAB_001a4a59;
              while (ppiVar5[2] != local_38) {
                while( true ) {
                  ppiVar5 = (int **)*ppiVar5;
                  if (ppiVar5 == (int **)0x0) goto LAB_001a475e;
                  piVar14 = ppiVar5[1];
                  if (piVar14 == local_38) break;
LAB_001a4a59:
                  if ((int *)((uint)piVar14 & (int)piVar3 - 1U) != local_30) goto LAB_001a475e;
                }
              }
LAB_001a4b00:
              if ((((0xffffffef < local_3c == 0 &&
                     (uint)(ppiVar12 < (int **)(local_3c + 0x10)) <= -(uint)(0xffffffef < local_3c))
                   && (piVar3 = ppiVar5[3], piVar3 != (int *)0x0)) &&
                  (piVar14 = ppiVar5[4], (int *)0xf < piVar14)) &&
                 ((piVar3[3] != 0 &&
                  (CARRY4((uint)piVar14,local_3c) == 0 &&
                   (uint)(ppiVar12 < (int **)((int)piVar14 + local_3c)) <=
                   -(uint)CARRY4((uint)piVar14,local_3c))))) {
                FUN_0018ae80((char *)(local_3c + (int)ppiVar10),piVar3,piVar14);
              }
            }
            else {
              do {
                piVar14 = ppiVar5[1];
                if (piVar14 == local_38) {
                  if (ppiVar5[2] == local_38) goto LAB_001a4b00;
                }
                else {
                  if (piVar3 <= piVar14) {
                    piVar14 = (int *)((uint)piVar14 % (uint)piVar3);
                  }
                  if (piVar14 != local_30) break;
                }
                ppiVar5 = (int **)*ppiVar5;
              } while (ppiVar5 != (int **)0x0);
            }
          }
        }
LAB_001a475e:
        bVar21 = 0xfffffffe < local_2c;
        local_2c = local_2c + 1;
        local_34 = local_34 + bVar21;
        if (local_28 <= local_34 && (uint)(local_2c < local_24) <= local_34 - local_28) {
          return (int **)((local_34 - local_28) - (uint)(local_2c < local_24));
        }
      }
    }
  }
  return ppiVar5;
}

