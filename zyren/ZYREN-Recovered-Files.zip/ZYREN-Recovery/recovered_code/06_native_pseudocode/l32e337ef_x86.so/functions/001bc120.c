/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bc120 FUN_001bc120 */

undefined4 FUN_001bc120(int *param_1,int param_2)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  uint uVar6;
  
  iVar2 = *(int *)(param_2 + 8);
  uVar1 = **(ushort **)(param_2 + 0x28);
  iVar3 = *(int *)(iVar2 + 4 + (uint)(uVar1 >> 0xc) * 0xc);
  if (iVar3 == 0) {
    uVar5 = FUN_001b7690();
    (**(code **)(*param_1 + 0x38))(param_1,uVar5,"when getting array length");
    (**(code **)(*param_1 + 0x5c))(param_1,uVar5);
  }
  else {
    uVar5 = (**(code **)(*param_1 + 0x2ac))(param_1,iVar3);
    cVar4 = (**(code **)(*param_1 + 0x390))(param_1);
    if (cVar4 == '\0') {
      uVar6 = uVar1 >> 8 & 0xf;
      iVar3 = *(int *)(iVar2 + uVar6 * 0xc);
      if (((iVar3 == 0x4000) || (iVar3 == 0x100)) &&
         (iVar3 = *(int *)(iVar2 + 4 + uVar6 * 0xc), iVar3 != 0)) {
        (**(code **)(*param_1 + 0x5c))(param_1,iVar3);
      }
      *(undefined4 *)(iVar2 + uVar6 * 0xc) = 0x10;
      *(undefined4 *)(iVar2 + 4 + uVar6 * 0xc) = uVar5;
    }
  }
  return 0;
}

