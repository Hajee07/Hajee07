/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00201bf0 FUN_00201bf0 */

char * FUN_00201bf0(void)

{
  char cVar1;
  char **ppcVar2;
  char *pcVar3;
  char *pcVar4;
  int iVar5;
  char **ppcVar6;
  char **ppcVar7;
  char **in_ECX;
  int iVar8;
  int *piVar9;
  int iVar10;
  uint uVar11;
  
  pcVar4 = *in_ECX;
  pcVar3 = in_ECX[1];
  if (pcVar3 == pcVar4) {
LAB_00201c56:
    pcVar3 = (char *)FUN_001fed60();
    return pcVar3;
  }
  cVar1 = *pcVar4;
  if (cVar1 != 'J') {
    if (cVar1 == 'L') {
      if (((uint)((int)pcVar3 - (int)pcVar4) < 2) || (pcVar4[1] != 'Z')) {
        pcVar3 = (char *)FUN_00207600();
        return pcVar3;
      }
      *in_ECX = pcVar4 + 2;
      pcVar3 = (char *)FUN_001fdc90();
    }
    else {
      if (cVar1 != 'X') goto LAB_00201c56;
      *in_ECX = pcVar4 + 1;
      pcVar3 = (char *)FUN_002042b0();
    }
    if (pcVar3 == (char *)0x0) {
      return (char *)0x0;
    }
    pcVar4 = *in_ECX;
    if (pcVar4 == in_ECX[1]) {
      return (char *)0x0;
    }
    if (*pcVar4 != 'E') {
      return (char *)0x0;
    }
    *in_ECX = pcVar4 + 1;
    return pcVar3;
  }
  pcVar4 = pcVar4 + 1;
  *in_ECX = pcVar4;
  iVar8 = (int)in_ECX[3] - (int)in_ECX[2] >> 2;
  if (pcVar4 != pcVar3) goto LAB_00201cf3;
  do {
    do {
      iVar5 = FUN_00201bf0();
      if (iVar5 == 0) {
        return (char *)0x0;
      }
      piVar9 = (int *)in_ECX[3];
      if (piVar9 == (int *)in_ECX[4]) {
        ppcVar2 = (char **)in_ECX[2];
        iVar10 = (int)piVar9 - (int)ppcVar2;
        if (in_ECX + 5 == ppcVar2) {
          pcVar3 = (char *)FUN_0018add0(iVar10 * 2);
          if (pcVar3 == (char *)0x0) goto LAB_00201ea5;
          if (iVar10 != 0) {
            FUN_0018ae40(pcVar3,ppcVar2,iVar10);
          }
          in_ECX[2] = pcVar3;
        }
        else {
          pcVar3 = (char *)FUN_0018b200(ppcVar2,iVar10 * 2);
          in_ECX[2] = pcVar3;
          if (pcVar3 == (char *)0x0) goto LAB_00201ea5;
        }
        piVar9 = (int *)(pcVar3 + (iVar10 >> 2) * 4);
        in_ECX[3] = (char *)piVar9;
        in_ECX[4] = pcVar3 + (iVar10 >> 1) * 4;
      }
      in_ECX[3] = (char *)(piVar9 + 1);
      *piVar9 = iVar5;
      pcVar4 = *in_ECX;
    } while (pcVar4 == in_ECX[1]);
LAB_00201cf3:
  } while (*pcVar4 != 'E');
  *in_ECX = pcVar4 + 1;
  pcVar3 = in_ECX[2];
  iVar5 = (int)in_ECX[3] - (int)(pcVar3 + iVar8 * 4);
  uVar11 = iVar5 + 0xfU & 0xfffffff0;
  ppcVar2 = (char **)in_ECX[0x45b];
  pcVar4 = ppcVar2[1];
  ppcVar6 = ppcVar2;
  if (pcVar4 + uVar11 < (char *)0xff8) {
LAB_00201dfd:
    ppcVar6[1] = pcVar4 + uVar11;
    ppcVar6 = (char **)((int)(ppcVar6 + 2) + (int)pcVar4);
  }
  else {
    if (uVar11 < 0xff9) {
      ppcVar6 = (char **)FUN_0018add0(0x1000);
      if (ppcVar6 == (char **)0x0) goto LAB_00201ea5;
      *ppcVar6 = (char *)ppcVar2;
      ppcVar6[1] = (char *)0x0;
      in_ECX[0x45b] = (char *)ppcVar6;
      pcVar4 = (char *)0x0;
      goto LAB_00201dfd;
    }
    ppcVar6 = (char **)FUN_0018add0(uVar11 | 8);
    if (ppcVar6 == (char **)0x0) goto LAB_00201ea5;
    *ppcVar6 = *ppcVar2;
    ppcVar6[1] = (char *)0x0;
    *ppcVar2 = (char *)ppcVar6;
    ppcVar6 = ppcVar6 + 2;
  }
  if (iVar5 != 0) {
    FUN_0018ae40(ppcVar6,pcVar3 + iVar8 * 4,iVar5);
    pcVar3 = in_ECX[2];
  }
  in_ECX[3] = pcVar3 + iVar8 * 4;
  ppcVar2 = (char **)in_ECX[0x45b];
  pcVar3 = ppcVar2[1];
  ppcVar7 = ppcVar2;
  if ((char *)0xff7 < pcVar3 + 0x10) {
    ppcVar7 = (char **)FUN_0018add0(0x1000);
    if (ppcVar7 == (char **)0x0) {
LAB_00201ea5:
                    /* WARNING: Subroutine does not return */
      FUN_001f9d40();
    }
    *ppcVar7 = (char *)ppcVar2;
    ppcVar7[1] = (char *)0x0;
    in_ECX[0x45b] = (char *)ppcVar7;
    pcVar3 = (char *)0x0;
  }
  ppcVar7[1] = pcVar3 + 0x10;
  *(undefined4 *)((int)(ppcVar7 + 3) + (int)pcVar3) = 0x101011c;
  *(undefined ***)((int)(ppcVar7 + 2) + (int)pcVar3) = &PTR_FUN_0024b538;
  *(char ***)((int)(ppcVar7 + 4) + (int)pcVar3) = ppcVar6;
  *(int *)((int)(ppcVar7 + 5) + (int)pcVar3) = iVar5 >> 2;
  return (char *)((int)(ppcVar7 + 2) + (int)pcVar3);
}

