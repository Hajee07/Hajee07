/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fd340 FUN_001fd340 */

undefined4 FUN_001fd340(code *param_1)

{
  undefined4 uVar1;
  code *pcVar2;
  
  pcVar2 = FUN_001fd370;
  if (param_1 != (code *)0x0) {
    pcVar2 = param_1;
  }
  LOCK();
  uVar1 = *(undefined4 *)PTR_PTR_FUN_0024bdac;
  *(code **)PTR_PTR_FUN_0024bdac = pcVar2;
  UNLOCK();
  return uVar1;
}

