/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c9ac0 FUN_001c9ac0 */

void FUN_001c9ac0(uint param_1)

{
  uint uVar1;
  
  uVar1 = 0xf;
  if (param_1 < 0xf) {
    uVar1 = param_1;
  }
  FUN_0018add0((4 << ((byte)uVar1 & 0x1f)) + 4);
  return;
}

