/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d5a70 FUN_001d5a70 */

code * __regparm3 FUN_001d5a70(undefined4 param_1,int param_2,code **param_3)

{
  code **ppcVar1;
  code **ppcVar2;
  code *pcVar3;
  bool bVar4;
  code *pcVar5;
  int iVar6;
  code *pcVar7;
  code *pcVar8;
  code *pcVar9;
  code *pcVar10;
  code *local_20;
  
  if ((*(byte *)((int)param_3 + 10) & 8) == 0) {
    bVar4 = false;
    pcVar10 = *param_3;
  }
  else {
    bVar4 = param_3[7] + -(int)param_3[0x10] <= param_3[9];
    pcVar10 = *param_3;
  }
  if ((pcVar10 == (code *)0x0) && (0x14ccb < (uint)(*(int *)param_3[0x1f] - (int)param_3[0x23]))) {
    pcVar10 = param_3[0x23] + (int)param_3[0x1d];
  }
  else {
    pcVar10 = (code *)((int)param_3 + 0x39272);
  }
  param_3[0xc] = pcVar10;
  param_3[0xd] = pcVar10 + 0x14cbc;
  param_3[0x16] = (code *)0x0;
  param_3[0x17] = (code *)0x0;
  *param_3[0xb] = (code)((byte)*param_3[0xb] >> (*(byte *)(param_3 + 0xe) & 0x1f));
  param_3[10] = param_3[10] + -(uint)(param_3[0xe] == (code *)0x8);
  if (((*(byte *)((int)param_3 + 9) & 0x10) != 0) && (param_3[0x19] == (code *)0x0)) {
    pcVar5 = (code *)(0x78 << ((byte)param_3[0x11] & 0x1f) | (uint)param_3[0x12]);
    param_3[0x12] = pcVar5;
    pcVar7 = param_3[0x11] + 8;
    param_3[0x11] = pcVar7;
    while ((code *)0x7 < pcVar7) {
      pcVar9 = param_3[0xc];
      if (pcVar9 < param_3[0xd]) {
        param_3[0xc] = pcVar9 + 1;
        *pcVar9 = SUB41(pcVar5,0);
        pcVar7 = param_3[0x11];
        pcVar5 = param_3[0x12];
      }
      pcVar5 = (code *)((uint)pcVar5 >> 8);
      param_3[0x12] = pcVar5;
      pcVar7 = pcVar7 + -8;
      param_3[0x11] = pcVar7;
    }
    pcVar5 = (code *)((uint)pcVar5 | 1 << ((uint)pcVar7 & 0x1f));
    param_3[0x12] = pcVar5;
    pcVar7 = pcVar7 + 8;
    param_3[0x11] = pcVar7;
    pcVar9 = param_3[0xc];
    if (pcVar9 < param_3[0xd]) goto LAB_001d5b89;
    while( true ) {
      pcVar5 = (code *)((uint)pcVar5 >> 8);
      param_3[0x12] = pcVar5;
      pcVar7 = pcVar7 + -8;
      param_3[0x11] = pcVar7;
      if (pcVar7 < (code *)0x8) break;
      pcVar9 = param_3[0xc];
      if (pcVar9 < param_3[0xd]) {
LAB_001d5b89:
        param_3[0xc] = pcVar9 + 1;
        *pcVar9 = SUB41(pcVar5,0);
        pcVar7 = param_3[0x11];
        pcVar5 = param_3[0x12];
      }
    }
  }
  ppcVar1 = param_3 + 0x11;
  local_20 = param_3[0xc];
  ppcVar2 = param_3 + 0x12;
  pcVar5 = (code *)((uint)(param_2 == 4) << ((byte)param_3[0x11] & 0x1f) | (uint)param_3[0x12]);
  param_3[0x12] = pcVar5;
  pcVar7 = param_3[0x11] + 1;
  param_3[0x11] = pcVar7;
  while ((code *)0x7 < pcVar7) {
    if (local_20 < param_3[0xd]) {
      param_3[0xc] = local_20 + 1;
      *local_20 = SUB41(pcVar5,0);
      pcVar5 = param_3[0x12];
      local_20 = param_3[0xc];
      pcVar7 = param_3[0x11];
    }
    pcVar5 = (code *)((uint)pcVar5 >> 8);
    *ppcVar2 = pcVar5;
    pcVar7 = pcVar7 + -8;
    *ppcVar1 = pcVar7;
  }
  iVar6 = 0;
  if (!bVar4) {
    iVar6 = FUN_001e61d0();
    if ((param_3[0xf] == (code *)0x0) || (param_3[0xc] + (1 - (int)local_20) < param_3[0xf])) {
LAB_001d5cbd:
      if (iVar6 == 0) {
        param_3[0xc] = local_20;
        param_3[0x12] = pcVar5;
        param_3[0x11] = pcVar7;
        FUN_001e61d0();
      }
LAB_001d5e78:
      if (param_2 != 0) {
        if (param_2 != 4) {
          pcVar7 = *ppcVar1 + 3;
          *ppcVar1 = pcVar7;
          while ((code *)0x7 < pcVar7) {
            pcVar5 = param_3[0xc];
            if (pcVar5 < param_3[0xd]) {
              param_3[0xc] = pcVar5 + 1;
              *pcVar5 = *(code *)(param_3 + 0x12);
              pcVar7 = param_3[0x11];
            }
            *ppcVar2 = (code *)((uint)*ppcVar2 >> 8);
            pcVar7 = pcVar7 + -8;
            *ppcVar1 = pcVar7;
          }
          if (pcVar7 == (code *)0x0) {
            pcVar5 = *ppcVar2;
            pcVar7 = (code *)0x10;
          }
          else {
            *ppcVar1 = (code *)0x8;
            pcVar5 = param_3[0xc];
            pcVar7 = (code *)0x8;
            if (pcVar5 < param_3[0xd]) goto LAB_001d5f2c;
            while( true ) {
              pcVar5 = (code *)((uint)*ppcVar2 >> 8);
              *ppcVar2 = pcVar5;
              pcVar9 = pcVar7 + -8;
              *ppcVar1 = pcVar9;
              if (pcVar9 < (code *)0x8) break;
              pcVar5 = param_3[0xc];
              pcVar7 = pcVar9;
              if (pcVar5 < param_3[0xd]) {
LAB_001d5f2c:
                param_3[0xc] = pcVar5 + 1;
                *pcVar5 = *(code *)(param_3 + 0x12);
                pcVar7 = param_3[0x11];
              }
            }
            pcVar7 = pcVar7 + 8;
          }
          *ppcVar2 = pcVar5;
          *ppcVar1 = pcVar7;
          pcVar9 = param_3[0xc];
          if (param_3[0xd] <= pcVar9) goto LAB_001d60ce;
          do {
            param_3[0xc] = pcVar9 + 1;
            *pcVar9 = SUB41(pcVar5,0);
            pcVar5 = param_3[0x12];
            pcVar7 = param_3[0x11];
LAB_001d60ce:
            do {
              pcVar5 = (code *)((uint)pcVar5 >> 8);
              *ppcVar2 = pcVar5;
              pcVar8 = pcVar7 + -8;
              *ppcVar1 = pcVar8;
              if (pcVar8 < (code *)0x8) {
                pcVar5 = (code *)((uint)pcVar5 | 0xffff << ((byte)pcVar8 & 0x1f));
                *ppcVar2 = pcVar5;
                pcVar7 = pcVar7 + 8;
                *ppcVar1 = pcVar7;
                while ((code *)0x7 < pcVar7) {
                  pcVar9 = param_3[0xc];
                  if (pcVar9 < param_3[0xd]) {
                    param_3[0xc] = pcVar9 + 1;
                    *pcVar9 = SUB41(pcVar5,0);
                    pcVar7 = param_3[0x11];
                    pcVar5 = param_3[0x12];
                  }
                  pcVar5 = (code *)((uint)pcVar5 >> 8);
                  *ppcVar2 = pcVar5;
                  pcVar7 = pcVar7 + -8;
                  *ppcVar1 = pcVar7;
                }
                goto LAB_001d6138;
              }
              pcVar9 = param_3[0xc];
              pcVar7 = pcVar8;
            } while (param_3[0xd] <= pcVar9);
          } while( true );
        }
        if (*ppcVar1 == (code *)0x0) {
          pcVar7 = (code *)0x0;
        }
        else {
          *ppcVar1 = (code *)0x8;
          pcVar7 = (code *)0x8;
          pcVar5 = param_3[0xc];
          if (pcVar5 < param_3[0xd]) goto LAB_001d5eca;
          while( true ) {
            *ppcVar2 = (code *)((uint)*ppcVar2 >> 8);
            pcVar7 = pcVar7 + -8;
            *ppcVar1 = pcVar7;
            if (pcVar7 < (code *)0x8) break;
            pcVar5 = param_3[0xc];
            if (pcVar5 < param_3[0xd]) {
LAB_001d5eca:
              param_3[0xc] = pcVar5 + 1;
              *pcVar5 = *(code *)(param_3 + 0x12);
              pcVar7 = param_3[0x11];
            }
          }
        }
        if ((*(byte *)((int)param_3 + 9) & 0x10) != 0) {
          pcVar5 = param_3[6];
          pcVar8 = (code *)(((uint)pcVar5 >> 0x18) << ((byte)pcVar7 & 0x1f) | (uint)param_3[0x12]);
          param_3[0x12] = pcVar8;
          param_3[0x11] = pcVar7 + 8;
          pcVar9 = param_3[0xc];
          pcVar7 = pcVar7 + 8;
          if (param_3[0xd] <= pcVar9) goto LAB_001d5fae;
          do {
            param_3[0xc] = pcVar9 + 1;
            *pcVar9 = SUB41(pcVar8,0);
            pcVar8 = param_3[0x12];
            pcVar7 = param_3[0x11];
LAB_001d5fae:
            do {
              pcVar8 = (code *)((uint)pcVar8 >> 8);
              *ppcVar2 = pcVar8;
              pcVar3 = pcVar7 + -8;
              *ppcVar1 = pcVar3;
              if (pcVar3 < (code *)0x8) {
                pcVar8 = (code *)((uint)pcVar8 |
                                 ((uint)pcVar5 >> 0x10 & 0xff) << ((byte)pcVar3 & 0x1f));
                *ppcVar2 = pcVar8;
                *ppcVar1 = pcVar7;
                while ((code *)0x7 < pcVar7) {
                  pcVar9 = param_3[0xc];
                  if (pcVar9 < param_3[0xd]) {
                    param_3[0xc] = pcVar9 + 1;
                    *pcVar9 = SUB41(pcVar8,0);
                    pcVar7 = param_3[0x11];
                    pcVar8 = param_3[0x12];
                  }
                  pcVar8 = (code *)((uint)pcVar8 >> 8);
                  *ppcVar2 = pcVar8;
                  pcVar7 = pcVar7 + -8;
                  *ppcVar1 = pcVar7;
                }
                pcVar8 = (code *)(((uint)pcVar5 >> 8 & 0xff) << ((byte)pcVar7 & 0x1f) | (uint)pcVar8
                                 );
                *ppcVar2 = pcVar8;
                pcVar7 = pcVar7 + 8;
                *ppcVar1 = pcVar7;
                while ((code *)0x7 < pcVar7) {
                  pcVar9 = param_3[0xc];
                  if (pcVar9 < param_3[0xd]) {
                    param_3[0xc] = pcVar9 + 1;
                    *pcVar9 = SUB41(pcVar8,0);
                    pcVar7 = param_3[0x11];
                    pcVar8 = param_3[0x12];
                  }
                  pcVar8 = (code *)((uint)pcVar8 >> 8);
                  *ppcVar2 = pcVar8;
                  pcVar7 = pcVar7 + -8;
                  *ppcVar1 = pcVar7;
                }
                pcVar8 = (code *)(((uint)pcVar5 & 0xff) << ((byte)pcVar7 & 0x1f) | (uint)pcVar8);
                *ppcVar2 = pcVar8;
                pcVar7 = pcVar7 + 8;
                *ppcVar1 = pcVar7;
                pcVar5 = param_3[0xc];
                if (pcVar5 < param_3[0xd]) goto LAB_001d609c;
                while( true ) {
                  pcVar8 = (code *)((uint)pcVar8 >> 8);
                  *ppcVar2 = pcVar8;
                  pcVar7 = pcVar7 + -8;
                  *ppcVar1 = pcVar7;
                  if (pcVar7 < (code *)0x8) break;
                  pcVar5 = param_3[0xc];
                  if (pcVar5 < param_3[0xd]) {
LAB_001d609c:
                    param_3[0xc] = pcVar5 + 1;
                    *pcVar5 = SUB41(pcVar8,0);
                    pcVar7 = param_3[0x11];
                    pcVar8 = param_3[0x12];
                  }
                }
                goto LAB_001d6138;
              }
              pcVar9 = param_3[0xc];
              pcVar7 = pcVar3;
            } while (param_3[0xd] <= pcVar9);
          } while( true );
        }
      }
LAB_001d6138:
      FUN_0018ae30((int)param_3 + 0x8192,0,0x280);
      param_3[10] = (code *)((int)param_3 + 0x9273);
      param_3[0xb] = (code *)((int)param_3 + 0x9272);
      param_3[0xe] = (code *)0x8;
      param_3[0x10] = param_3[0x10] + (int)param_3[0xf];
      param_3[0xf] = (code *)0x0;
      param_3[0x19] = param_3[0x19] + 1;
      pcVar7 = param_3[0xc] + -(int)pcVar10;
      if (pcVar7 != (code *)0x0) {
        pcVar5 = *param_3;
        if (pcVar5 == (code *)0x0) {
          if (pcVar10 == (code *)((int)param_3 + 0x39272)) {
            pcVar10 = (code *)(*(int *)param_3[0x1f] - (int)param_3[0x23]);
            if (pcVar7 < pcVar10) {
              pcVar10 = pcVar7;
            }
            FUN_0018ae80(param_3[0x23] + (int)param_3[0x1d],(code *)((int)param_3 + 0x39272),pcVar10
                        );
            param_3[0x23] = param_3[0x23] + (int)pcVar10;
            if (pcVar7 + -(int)pcVar10 != (code *)0x0) {
              param_3[0x16] = pcVar10;
              param_3[0x17] = pcVar7 + -(int)pcVar10;
            }
          }
          else {
            param_3[0x23] = param_3[0x23] + (int)pcVar7;
          }
        }
        else {
          *(int *)param_3[0x1e] = (int)param_3[0x21] - (int)param_3[0x1c];
          iVar6 = (*pcVar5)(&DAT_00039272 + (int)param_3,pcVar7,param_3[1]);
          if (iVar6 == 0) {
            param_3[0x1b] = (code *)0xffffffff;
            return (code *)0xffffffff;
          }
        }
      }
      return param_3[0x17];
    }
  }
  if (param_3[7] + -(int)param_3[0x10] <= param_3[9]) {
    param_3[0xc] = local_20;
    param_3[0x12] = pcVar5;
    pcVar7 = pcVar7 + 2;
    param_3[0x11] = pcVar7;
    if ((code *)0x7 < pcVar7) {
      if (param_3[0xd] <= local_20) goto LAB_001d5c63;
      do {
        param_3[0xc] = local_20 + 1;
        *local_20 = SUB41(pcVar5,0);
        pcVar7 = param_3[0x11];
        pcVar5 = param_3[0x12];
LAB_001d5c63:
        do {
          pcVar5 = (code *)((uint)pcVar5 >> 8);
          *ppcVar2 = pcVar5;
          pcVar7 = pcVar7 + -8;
          *ppcVar1 = pcVar7;
          if (pcVar7 < (code *)0x8) {
            if (pcVar7 != (code *)0x0) goto LAB_001d5cef;
            pcVar7 = (code *)0x0;
            goto LAB_001d5d3d;
          }
          local_20 = param_3[0xc];
        } while (param_3[0xd] <= local_20);
      } while( true );
    }
LAB_001d5cef:
    *ppcVar1 = (code *)0x8;
    pcVar7 = (code *)0x8;
    pcVar9 = param_3[0xc];
    if (pcVar9 < param_3[0xd]) goto LAB_001d5d2b;
    while( true ) {
      pcVar5 = (code *)((uint)pcVar5 >> 8);
      *ppcVar2 = pcVar5;
      pcVar7 = pcVar7 + -8;
      *ppcVar1 = pcVar7;
      if (pcVar7 < (code *)0x8) break;
      pcVar9 = param_3[0xc];
      if (pcVar9 < param_3[0xd]) {
LAB_001d5d2b:
        param_3[0xc] = pcVar9 + 1;
        *pcVar9 = SUB41(pcVar5,0);
        pcVar7 = param_3[0x11];
        pcVar5 = param_3[0x12];
      }
    }
LAB_001d5d3d:
    pcVar5 = (code *)((uint)*(ushort *)(param_3 + 0xf) << ((byte)pcVar7 & 0x1f) | (uint)pcVar5);
    param_3[0x12] = pcVar5;
    param_3[0x11] = pcVar7 + 0x10;
    pcVar9 = param_3[0xc];
    pcVar7 = pcVar7 + 0x10;
    if (param_3[0xd] <= pcVar9) goto LAB_001d5d6e;
LAB_001d5d60:
    param_3[0xc] = pcVar9 + 1;
    *pcVar9 = SUB41(pcVar5,0);
    pcVar5 = param_3[0x12];
    pcVar7 = param_3[0x11];
LAB_001d5d6e:
    pcVar5 = (code *)((uint)pcVar5 >> 8);
    *ppcVar2 = pcVar5;
    pcVar8 = pcVar7 + -8;
    *ppcVar1 = pcVar8;
    if ((code *)0x7 < pcVar8) goto code_r0x001d5d7d;
    pcVar9 = param_3[0xf];
    param_3[0xf] = (code *)((uint)pcVar9 ^ 0xffff);
    pcVar5 = (code *)((uint)pcVar5 |
                     ((uint)(code *)((uint)pcVar9 ^ 0xffff) & 0xffff) << ((byte)pcVar8 & 0x1f));
    param_3[0x12] = pcVar5;
    pcVar7 = pcVar7 + 8;
    param_3[0x11] = pcVar7;
    if (pcVar7 < (code *)0x8) {
      param_3[0xf] = pcVar9;
      if (pcVar9 != (code *)0x0) goto LAB_001d5e07;
    }
    else {
      pcVar9 = param_3[0xc];
      if (pcVar9 < param_3[0xd]) goto LAB_001d5dd8;
      while( true ) {
        pcVar5 = (code *)((uint)pcVar5 >> 8);
        *ppcVar2 = pcVar5;
        pcVar7 = pcVar7 + -8;
        *ppcVar1 = pcVar7;
        if (pcVar7 < (code *)0x8) break;
        pcVar9 = param_3[0xc];
        if (pcVar9 < param_3[0xd]) {
LAB_001d5dd8:
          param_3[0xc] = pcVar9 + 1;
          *pcVar9 = SUB41(pcVar5,0);
          pcVar7 = param_3[0x11];
          pcVar5 = param_3[0x12];
        }
      }
      pcVar9 = param_3[0xf];
      param_3[0xf] = (code *)((uint)pcVar9 ^ 0xffff);
      if ((code *)((uint)pcVar9 ^ 0xffff) == (code *)0x0) goto LAB_001d5e78;
LAB_001d5e07:
      pcVar9 = (code *)0x0;
      do {
        pcVar5 = (code *)((uint)pcVar5 |
                         (uint)*(byte *)((int)param_3 +
                                        ((uint)(param_3[0x10] + (int)pcVar9) & 0x7fff) + 0x90) <<
                         ((byte)pcVar7 & 0x1f));
        param_3[0x12] = pcVar5;
        pcVar7 = pcVar7 + 8;
        param_3[0x11] = pcVar7;
        pcVar8 = param_3[0xc];
        if (pcVar8 < param_3[0xd]) goto LAB_001d5e68;
        while( true ) {
          pcVar5 = (code *)((uint)pcVar5 >> 8);
          *ppcVar2 = pcVar5;
          pcVar7 = pcVar7 + -8;
          *ppcVar1 = pcVar7;
          if (pcVar7 < (code *)0x8) break;
          pcVar8 = param_3[0xc];
          if (pcVar8 < param_3[0xd]) {
LAB_001d5e68:
            param_3[0xc] = pcVar8 + 1;
            *pcVar8 = SUB41(pcVar5,0);
            pcVar7 = param_3[0x11];
            pcVar5 = param_3[0x12];
          }
        }
        pcVar9 = pcVar9 + 1;
      } while (pcVar9 < param_3[0xf]);
    }
    goto LAB_001d5e78;
  }
  goto LAB_001d5cbd;
code_r0x001d5d7d:
  pcVar9 = param_3[0xc];
  pcVar7 = pcVar8;
  if (pcVar9 < param_3[0xd]) goto LAB_001d5d60;
  goto LAB_001d5d6e;
}

