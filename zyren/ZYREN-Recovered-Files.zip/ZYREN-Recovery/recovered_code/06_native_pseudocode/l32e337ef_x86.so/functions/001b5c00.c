/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5c00 FUN_001b5c00 */

void FUN_001b5c00(int param_1)

{
  if (*(undefined4 **)(param_1 + -4) != (undefined4 *)0x0) {
    **(undefined4 **)(param_1 + -4) = 0;
  }
  *(undefined4 *)(param_1 + -4) = 0;
  return;
}

