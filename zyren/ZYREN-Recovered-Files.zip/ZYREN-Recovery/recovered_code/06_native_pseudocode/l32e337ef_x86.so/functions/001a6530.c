/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a6530 FUN_001a6530 */

uint * FUN_001a6530(uint *param_1,byte *param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  param_1[1] = 0;
  *param_1 = 0;
  param_1[2] = 0;
  if ((*param_2 & 1) == 0) {
    uVar1 = (uint)(*param_2 >> 1);
    iVar2 = FUN_0018af10(param_3);
    param_2 = param_2 + 1;
    uVar3 = uVar1 + iVar2;
  }
  else {
    uVar1 = *(uint *)(param_2 + 4);
    iVar2 = FUN_0018af10(param_3);
    param_2 = *(byte **)(param_2 + 8);
    uVar3 = uVar1 + iVar2;
  }
  if (uVar3 < 0xfffffff0) {
    if (uVar3 < 0xb) {
      *(char *)param_1 = (char)uVar1 * '\x02';
      uVar3 = (int)param_1 + 1;
    }
    else {
      uVar4 = uVar3 + 0x10 & 0xfffffff0;
      uVar3 = FUN_001f5520(uVar4);
      param_1[2] = uVar3;
      *param_1 = uVar4 | 1;
      param_1[1] = uVar1;
    }
    if (uVar1 != 0) {
      FUN_0018ae80(uVar3,param_2,uVar1);
    }
    *(undefined *)(uVar3 + uVar1) = 0;
                    /* try { // try from 001a65e0 to 001a663f has its CatchHandler @ 001a6640 */
    FUN_001a7130(param_1,param_3,iVar2);
    return param_1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_001a6e40(param_1);
}

