/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00215a60 FUN_00215a60 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 * __regparm2
FUN_00215a60(byte param_1_00,undefined4 *param_2_00,undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puStack_20;
  
  if (param_1_00 == 0x50) {
    puVar1 = (undefined4 *)((int)param_1 + 3U & 0xfffffffc);
    puStack_20 = (undefined4 *)*puVar1;
    puVar1 = puVar1 + 1;
    goto LAB_00215afd;
  }
  switch(param_1_00 & 0xf) {
  case 0:
  case 3:
  case 0xb:
    puStack_20 = (undefined4 *)*param_1;
    puVar1 = param_1 + 1;
    break;
  case 1:
    puVar1 = (undefined4 *)FUN_002157fb();
    break;
  case 2:
    puStack_20 = (undefined4 *)(uint)*(ushort *)param_1;
    goto code_r0x00215acb;
  case 4:
  case 0xc:
    puStack_20 = (undefined4 *)*param_1;
    puVar1 = param_1 + 2;
    break;
  default:
                    /* WARNING: Subroutine does not return */
    FUN_0018b160();
  case 9:
    puVar1 = (undefined4 *)FUN_00215826();
    break;
  case 10:
    puStack_20 = (undefined4 *)(int)(short)*(ushort *)param_1;
code_r0x00215acb:
    puVar1 = (undefined4 *)((int)param_1 + 2);
  }
  if (puStack_20 != (undefined4 *)0x0) {
    if ((param_1_00 & 0x70) == 0x10) {
      param_2_00 = param_1;
    }
    puStack_20 = (undefined4 *)((int)puStack_20 + (int)param_2_00);
    if ((char)param_1_00 < '\0') {
      puStack_20 = (undefined4 *)*puStack_20;
    }
  }
LAB_00215afd:
  *param_2 = puStack_20;
  return puVar1;
}

