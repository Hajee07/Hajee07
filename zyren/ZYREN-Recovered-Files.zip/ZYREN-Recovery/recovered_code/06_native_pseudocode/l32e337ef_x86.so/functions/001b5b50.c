/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5b50 FUN_001b5b50 */

int * FUN_001b5b50(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = 0;
  piVar2 = (int *)0x0;
  if (param_1 != 0) {
    piVar4 = (int *)(param_1 + -8);
    do {
      piVar2 = piVar4;
      piVar4 = (int *)*piVar2;
    } while (piVar4 != (int *)0x0);
    piVar2 = piVar2 + 2;
  }
  if (param_2 != 0) {
    iVar3 = param_2 + -8;
    do {
      iVar1 = iVar3;
      iVar3 = *(int *)(iVar1 + 4);
    } while (iVar3 != 0);
    iVar1 = iVar1 + 8;
  }
  piVar4 = piVar2 + -2;
  if (piVar2 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  iVar3 = iVar1 + -8;
  if (iVar1 == 0) {
    iVar3 = 0;
  }
  if (piVar4 != (int *)0x0) {
    *piVar4 = iVar3;
  }
  if (iVar3 != 0) {
    *(int **)(iVar3 + 4) = piVar4;
  }
  piVar2 = piVar4 + 2;
  if (piVar4 == (int *)0x0) {
    piVar2 = (int *)0x0;
  }
  piVar4 = (int *)(iVar3 + 8);
  if (iVar3 == 0) {
    piVar4 = piVar2;
  }
  if (piVar2 != (int *)0x0) {
    piVar4 = piVar2;
  }
  if (piVar4 != (int *)0x0) {
    piVar2 = piVar4 + -2;
    do {
      piVar4 = piVar2;
      piVar2 = (int *)piVar4[1];
    } while (piVar2 != (int *)0x0);
    return piVar4 + 2;
  }
  return (int *)0x0;
}

