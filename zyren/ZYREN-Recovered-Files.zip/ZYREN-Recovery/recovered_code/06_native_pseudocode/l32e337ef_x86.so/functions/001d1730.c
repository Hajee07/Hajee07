/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d1730 FUN_001d1730 */

undefined4 FUN_001d1730(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar4 = 0x1d1738;
  uVar3 = 0xfffffffe;
  if ((((param_1 != 0) && (puVar1 = *(undefined4 **)(param_1 + 0x1c), puVar1 != (undefined4 *)0x0))
      && (*(int *)(param_1 + 0x20) != 0)) && (*(int *)(param_1 + 0x24) != 0)) {
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    uVar2 = puVar1[2];
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[3] = ((uVar2 & 0xfff) * 0xaaab + 0x15556 >> 0x11) + 1;
    puVar1[5] = uVar2 >> 0xe & 1;
    puVar1[4] = (((uVar2 & 0xfff) >> 2) * 0xaaab + 0x15556 >> 0x11) + 1;
    if (-1 < (short)uVar2) {
      FUN_0018ae30(&DAT_00029272 + (int)puVar1,0,0x10000,0x1d1738);
    }
    puVar1[9] = 0;
    puVar1[8] = 0;
    puVar1[7] = 0;
    puVar1[0x10] = 0;
    puVar1[0xf] = 0;
    puVar1[0x12] = 0;
    puVar1[0x11] = 0;
    puVar1[0x17] = 0;
    puVar1[0x16] = 0;
    puVar1[0x19] = 0;
    puVar1[0x18] = 0;
    puVar1[0x1a] = 0;
    puVar1[10] = (int)puVar1 + 0x9273;
    puVar1[0xb] = (int)puVar1 + 0x9272;
    *(undefined *)((int)puVar1 + 0x9272) = 0;
    puVar1[0xe] = 8;
    puVar1[0xc] = &DAT_00039272 + (int)puVar1;
    puVar1[0xd] = &DAT_00039272 + (int)puVar1;
    puVar1[0x1b] = 0;
    puVar1[0x15] = 0;
    puVar1[0x14] = 0;
    puVar1[0x13] = 0;
    puVar1[6] = 1;
    puVar1[0x22] = 0;
    puVar1[0x23] = 0;
    puVar1[0x20] = 0;
    puVar1[0x21] = 0;
    puVar1[0x1e] = 0;
    puVar1[0x1f] = 0;
    puVar1[0x1c] = 0;
    puVar1[0x1d] = 0;
    if (-1 < (short)uVar2) {
      FUN_0018ae30(puVar1 + 0x24,0,0x8101,uVar4);
    }
    FUN_0018ae30((int)puVar1 + 0x8192,0,0x280,uVar4);
    uVar3 = 0;
  }
  return uVar3;
}

