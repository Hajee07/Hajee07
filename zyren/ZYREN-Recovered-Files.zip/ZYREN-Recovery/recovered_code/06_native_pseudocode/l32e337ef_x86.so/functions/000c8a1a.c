/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000c8a1a FUN_000c8a1a */

void FUN_000c8a1a(void)

{
  FUN_000e8170();
  FUN_0009aec0();
  return;
}

