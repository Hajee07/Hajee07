/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b8450 FUN_001b8450 */

longdouble FUN_001b8450(undefined4 param_1)

{
  float local_10;
  undefined local_c [8];
  
  thunk_FUN_00154500(local_c,param_1);
  return (longdouble)local_10;
}

