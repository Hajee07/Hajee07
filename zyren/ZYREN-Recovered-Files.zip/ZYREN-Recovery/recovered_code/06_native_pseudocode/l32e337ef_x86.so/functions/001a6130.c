/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a6130 FUN_001a6130 */

undefined4 FUN_001a6130(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if ((param_1 != 0) && (*(int *)PTR_DAT_0024bc34 != 0)) {
    iVar1 = FUN_0018b060(param_1,"/system/bin/dex2oat");
    if (iVar1 == 0) {
      return 0;
    }
  }
  uVar2 = (**(code **)PTR_DAT_0024bc38)(param_1,param_2);
  return uVar2;
}

