/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001dc660 FUN_001dc660 */

undefined4 FUN_001dc660(int param_1,int param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  bool bVar5;
  undefined local_5c [16];
  undefined local_4c [8];
  int iStack_44;
  int iStack_40;
  undefined local_3c [12];
  code *pcStack_30;
  undefined local_2c [16];
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 *local_14;
  
  if ((param_1 == 0) || (param_2 == 0)) {
    if (param_4 == (int *)0x0) {
      return 0;
    }
    *param_4 = 0x18;
    return 0;
  }
  local_2c = ZEXT816(0);
  _local_3c = ZEXT816(0);
  _local_4c = ZEXT816(0);
  local_5c = ZEXT816(0);
  local_18 = 0;
  local_1c = 0;
  local_14 = (undefined4 *)0x0;
  iVar3 = FUN_001d8290(local_5c,param_1,param_2,param_3);
  if (iVar3 == 0) {
    if (param_4 == (int *)0x0) {
      return 0;
    }
    *param_4 = iStack_40;
    return 0;
  }
  iVar3 = FUN_001dc510(local_5c,param_3);
  puVar1 = local_14;
  if (iVar3 == 0) {
    iVar2 = iStack_40;
    iVar3 = iStack_40;
    if ((((local_14 != (undefined4 *)0x0) && (local_3c._8_4_ != 0)) && (pcStack_30 != (code *)0x0))
       && (local_4c._4_4_ == 1)) {
      local_14 = (undefined4 *)0x0;
      (*pcStack_30)(local_2c._4_4_,*puVar1);
      puVar1[1] = 0;
      *puVar1 = 0;
      puVar1[3] = 0;
      puVar1[2] = 0;
      (*pcStack_30)(local_2c._4_4_,puVar1[4]);
      puVar1[5] = 0;
      puVar1[4] = 0;
      puVar1[7] = 0;
      puVar1[6] = 0;
      (*pcStack_30)(local_2c._4_4_,puVar1[8]);
      puVar1[9] = 0;
      puVar1[8] = 0;
      puVar1[0xb] = 0;
      puVar1[10] = 0;
      if (puVar1[0xf] == 0) {
        bVar5 = true;
      }
      else {
        bVar5 = true;
        if (iStack_44 == 4) {
          iVar3 = FUN_0018b120(puVar1[0xf]);
          bVar5 = iVar3 != -1;
        }
        puVar1[0xf] = 0;
      }
      (*pcStack_30)(local_2c._4_4_,puVar1);
      uVar4 = 0;
      iVar3 = iStack_40;
      goto joined_r0x001dc994;
    }
joined_r0x001dc957:
    uVar4 = 0;
    if (iStack_40 != 0) goto joined_r0x001dc95f;
  }
  else {
    if (((local_14 != (undefined4 *)0x0) && (local_3c._8_4_ != 0)) &&
       ((pcStack_30 != (code *)0x0 && (local_4c._4_4_ == 1)))) {
      local_14 = (undefined4 *)0x0;
      (*pcStack_30)(local_2c._4_4_,*puVar1);
      puVar1[1] = 0;
      *puVar1 = 0;
      puVar1[3] = 0;
      puVar1[2] = 0;
      (*pcStack_30)(local_2c._4_4_,puVar1[4]);
      puVar1[5] = 0;
      puVar1[4] = 0;
      puVar1[7] = 0;
      puVar1[6] = 0;
      (*pcStack_30)(local_2c._4_4_,puVar1[8]);
      puVar1[9] = 0;
      puVar1[8] = 0;
      puVar1[0xb] = 0;
      puVar1[10] = 0;
      uVar4 = 1;
      bVar5 = true;
      if (puVar1[0xf] != 0) {
        bVar5 = true;
        if (iStack_44 == 4) {
          iVar3 = FUN_0018b120(puVar1[0xf]);
          bVar5 = true;
          if (iVar3 == -1) {
            iStack_40 = 0x15;
            bVar5 = false;
          }
        }
        puVar1[0xf] = 0;
      }
      (*pcStack_30)(local_2c._4_4_,puVar1);
      iVar2 = 0;
      iVar3 = iStack_40;
joined_r0x001dc994:
      iStack_40 = iVar2;
      if (bVar5) goto joined_r0x001dc95f;
      goto joined_r0x001dc957;
    }
    iVar3 = 0x18;
  }
  uVar4 = 0;
  iStack_40 = iVar3;
joined_r0x001dc95f:
  if (param_4 != (int *)0x0) {
    *param_4 = iStack_40;
  }
  return uVar4;
}

