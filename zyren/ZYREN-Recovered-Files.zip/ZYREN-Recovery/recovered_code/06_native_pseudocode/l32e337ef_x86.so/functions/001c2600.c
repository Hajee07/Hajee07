/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c2600 FUN_001c2600 */

undefined4 FUN_001c2600(int *param_1,int param_2)

{
  float fVar1;
  longlong lVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  iVar3 = *(int *)(param_2 + 8);
  uVar5 = **(ushort **)(param_2 + 0x28) >> 8 & 0xf;
  uVar6 = (uint)(**(ushort **)(param_2 + 0x28) >> 0xc);
  iVar4 = *(int *)(iVar3 + uVar5 * 0xc);
  if ((((iVar4 == 0x4000) || (iVar4 == 0x100)) &&
      (iVar4 = *(int *)(iVar3 + 4 + uVar5 * 0xc), iVar4 != 0)) &&
     (iVar4 != *(int *)(iVar3 + 4 + uVar6 * 0xc))) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
  }
  lVar2 = 0x7fffffffffffffff;
  *(undefined4 *)(iVar3 + uVar5 * 0xc) = 0x20;
  fVar1 = *(float *)(iVar3 + 4 + uVar6 * 0xc);
  if (fVar1 < DAT_0021dc18) {
    lVar2 = -0x8000000000000000;
    if (DAT_0021dc1c < fVar1) {
      if (NAN(fVar1)) {
        lVar2 = 0;
      }
      else {
        lVar2 = (longlong)fVar1;
      }
    }
  }
  *(int *)(iVar3 + 8 + uVar5 * 0xc) = (int)((ulonglong)lVar2 >> 0x20);
  *(int *)(iVar3 + 4 + uVar5 * 0xc) = (int)lVar2;
  return 0;
}

