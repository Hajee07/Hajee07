/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d0570 FUN_001d0570 */

uint FUN_001d0570(undefined4 param_1,uint param_2,undefined *param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  
  if (param_2 == 0) {
    uVar1 = 0xffffffba;
  }
  else {
    uVar1 = 0xffffffec;
    if (param_4 <= param_2) {
      uVar1 = param_2;
      if (param_4 == param_2) {
        FUN_0018ae80(param_1,param_3,param_2);
      }
      else if (param_4 == 1) {
        FUN_0018ae30(param_1,*param_3,param_2);
      }
      else {
        uVar1 = 0xf;
        if (param_4 < param_2) {
          uVar1 = (param_4 << 4) / param_2;
        }
        uVar2 = (param_2 >> 8) * *(int *)(&DAT_0021e29c + uVar1 * 0x18) +
                *(int *)(&DAT_0021e298 + uVar1 * 0x18);
        uVar1 = (*(code *)(&PTR_FUN_00249eac)
                          [(uVar2 >> 3) + uVar2 <
                           *(int *)(&DAT_0021e294 + uVar1 * 0x18) * (param_2 >> 8) +
                           *(int *)(&DAT_0021e290 + uVar1 * 0x18)])(param_1,param_2,param_3,param_4)
        ;
      }
    }
  }
  return uVar1;
}

