/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c9540 FUN_001c9540 */

undefined8 FUN_001c9540(int param_1,uint *param_2,uint *param_3,uint *param_4,uint param_5)

{
  uint *puVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint *puVar11;
  short sVar12;
  uint uVar13;
  uint local_3c;
  int local_38;
  uint local_34;
  uint local_30;
  
  iVar4 = -0x48;
  if (3 < param_5) {
    uVar13 = *param_4;
    uVar7 = uVar13 & 0xf;
    iVar4 = -0x2c;
    if (uVar7 + 5 < 0x10) {
      *param_3 = uVar7 + 5;
      uVar8 = 0x20 << (sbyte)uVar7;
      iVar4 = -0x14;
      if (1 < uVar8) {
        local_30 = uVar8 | 1;
        uVar6 = *param_2;
        local_38 = uVar7 + 6;
        uVar13 = uVar13 >> 4;
        puVar1 = (uint *)((int)param_4 + (param_5 - 7));
        puVar2 = (uint *)((int)param_4 + (param_5 - 4));
        local_3c = 4;
        param_5 = 0;
        uVar7 = 0;
        puVar5 = param_4;
        do {
          local_34 = uVar7;
          if (param_5 != 0) {
            sVar12 = (short)uVar13;
            uVar9 = uVar7;
            puVar11 = puVar5;
            while (sVar12 == -1) {
              while (puVar11 < (uint *)((int)param_4 + (param_5 - 5))) {
                puVar5 = (uint *)((int)puVar11 + 2);
                puVar11 = (uint *)((int)puVar11 + 2);
                uVar13 = *puVar5 >> ((byte)local_3c & 0x1f);
                uVar9 = uVar9 + 0x18;
                if ((short)uVar13 != -1) goto joined_r0x001c9640;
              }
              local_3c = local_3c + 0x10;
              uVar9 = uVar9 + 0x18;
              sVar12 = (short)(uVar13 >> 0x10);
              uVar13 = uVar13 >> 0x10;
            }
joined_r0x001c9640:
            for (; uVar3 = uVar13 & 3, uVar3 == 3; uVar13 = uVar13 >> 2) {
              uVar9 = uVar9 + 3;
              local_3c = local_3c + 2;
            }
            param_5 = uVar9 + uVar3;
            if (uVar6 < param_5) {
              iVar4 = -0x30;
              goto LAB_001c9826;
            }
            local_3c = local_3c + 2;
            if (uVar7 <= param_5 && param_5 - uVar7 != 0) {
              FUN_0018ae30(param_1 + uVar7 * 2,0,(param_5 - uVar7) * 2);
              iVar4 = (uVar9 + uVar3) - uVar7;
              do {
                iVar4 = iVar4 + -1;
                local_34 = param_5;
              } while (iVar4 != 0);
            }
            iVar4 = (int)local_3c >> 3;
            puVar5 = (uint *)((int)puVar11 + iVar4);
            if ((puVar1 < puVar11) && (puVar2 < puVar5)) {
              uVar13 = uVar13 >> 2;
              puVar5 = puVar11;
            }
            else {
              local_3c = local_3c & 7;
              uVar13 = *(uint *)((int)puVar11 + iVar4) >> (sbyte)local_3c;
            }
          }
          uVar7 = uVar8 * 2 - 1;
          uVar6 = uVar7 - local_30;
          uVar9 = uVar8 - 1 & uVar13;
          if (uVar9 < uVar6) {
            iVar4 = local_38 + -1;
          }
          else {
            uVar13 = uVar13 & uVar7;
            if ((int)uVar13 < (int)uVar8) {
              uVar6 = 0;
            }
            uVar9 = uVar13 - uVar6;
            iVar4 = local_38;
          }
          local_3c = iVar4 + local_3c;
          iVar4 = uVar9 - 1;
          iVar10 = 1 - uVar9;
          if (0 < (int)uVar9) {
            iVar10 = iVar4;
          }
          local_30 = local_30 - iVar10;
          *(short *)(param_1 + local_34 * 2) = (short)iVar4;
          param_5 = 0;
          for (; (int)local_30 < (int)uVar8; uVar8 = (int)uVar8 >> 1) {
            local_38 = local_38 + -1;
          }
          puVar11 = (uint *)(((int)local_3c >> 3) + (int)puVar5);
          if ((puVar1 < puVar5) && (puVar2 < puVar11)) {
            local_3c = local_3c + ((int)puVar2 - (int)puVar5) * -8;
            puVar11 = puVar2;
          }
          else {
            local_3c = local_3c & 7;
          }
          uVar13 = *puVar11 >> ((byte)local_3c & 0x1f);
          if ((int)local_30 < 2) break;
          uVar7 = local_34 + 1;
          param_5 = (uint)(iVar4 == 0);
          uVar6 = *param_2;
          puVar5 = puVar11;
        } while (uVar7 <= uVar6);
        if (local_30 == 1) {
          iVar4 = -0x14;
          param_5 = local_3c;
          if ((int)local_3c < 0x21) {
            *param_2 = local_34;
            param_5 = (int)(local_3c + 7) >> 3;
            iVar4 = (int)puVar11 + (param_5 - (int)param_4);
          }
        }
        else {
          iVar4 = -0x14;
        }
      }
    }
  }
LAB_001c9826:
  return CONCAT44(param_5,iVar4);
}

