/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001baa80 FUN_001baa80 */

undefined4 FUN_001baa80(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined local_50 [64];
  
  FUN_0018b030(local_50,&DAT_002178d0,param_2,param_3);
  iVar1 = FUN_0018af10(param_1);
  iVar2 = FUN_0018af10(local_50);
  uVar3 = FUN_0018b200(param_1,iVar1 + 1 + iVar2);
  FUN_0018b210(uVar3,local_50);
  return uVar3;
}

