/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a6850 FUN_001a6850 */

void FUN_001a6850(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  if (param_1[2] != 0) {
    iVar1 = *param_1;
    piVar2 = (int *)param_1[1];
    iVar3 = *piVar2;
    *(undefined4 *)(iVar3 + 4) = *(undefined4 *)(iVar1 + 4);
    **(int **)(iVar1 + 4) = iVar3;
    param_1[2] = 0;
    while (piVar2 != param_1) {
      piVar4 = (int *)piVar2[1];
      FUN_001f5680(piVar2);
      piVar2 = piVar4;
    }
  }
  return;
}

