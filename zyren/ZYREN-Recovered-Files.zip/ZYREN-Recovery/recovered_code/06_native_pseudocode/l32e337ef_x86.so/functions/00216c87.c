/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00216c87 FUN_00216c87 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00216c87(uint param_1,uint *param_2)

{
  int iVar1;
  uint *puVar2;
  uint **ppuVar3;
  undefined4 extraout_EDX;
  uint *puVar4;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  int local_24;
  undefined4 local_20;
  undefined4 uStack_14;
  
  uStack_14 = 0x216c92;
  puVar4 = DAT_002771c4;
  if (PTR_pthread_create_0024bdf4 != (undefined *)0x0) {
    FUN_0018adf0(&DAT_002771c0);
    puVar4 = DAT_002771c4;
  }
  while( true ) {
    if (puVar4 == (uint *)0x0) goto LAB_00216cdb;
    if (*puVar4 <= param_1) break;
    puVar4 = (uint *)puVar4[5];
  }
  iVar1 = FUN_00216450();
  while (iVar1 == 0) {
LAB_00216cdb:
    puVar4 = DAT_002771c8;
    if (DAT_002771c8 == (uint *)0x0) {
      iVar1 = 0;
      if (PTR_pthread_create_0024bdf4 != (undefined *)0x0) goto LAB_00216d31;
      goto LAB_00216d9f;
    }
    DAT_002771c8 = (uint *)DAT_002771c8[5];
    iVar1 = FUN_00216450();
    ppuVar3 = &DAT_002771c4;
    for (puVar2 = DAT_002771c4; (puVar2 != (uint *)0x0 && (*puVar4 <= *puVar2));
        puVar2 = (uint *)puVar2[5]) {
      ppuVar3 = (uint **)(puVar2 + 5);
    }
    puVar4[5] = (uint)puVar2;
    *ppuVar3 = puVar4;
  }
  if (PTR_pthread_create_0024bdf4 != (undefined *)0x0) {
LAB_00216d31:
    FUN_0018ae00(&DAT_002771c0);
    if (iVar1 == 0) {
LAB_00216d9f:
      local_30 = 0;
      local_2c = 0;
      local_34 = param_1;
      local_28 = 0;
      local_24 = 0;
      local_20 = 1;
      iVar1 = FUN_0018b380(FUN_00215d3e,&local_34,param_1,param_1);
      if (iVar1 < 0) {
        return 0;
      }
      if (local_24 == 0) {
        return 0;
      }
      *param_2 = local_30;
      param_2[1] = local_2c;
      param_2[2] = local_28;
      return local_24;
    }
  }
  *param_2 = puVar4[1];
  param_2[1] = puVar4[2];
  if ((*(byte *)(puVar4 + 4) & 4) != 0) {
    FUN_00215d2d();
  }
  FUN_002159dc();
  FUN_00215a60(iVar1 + 8,&local_34,extraout_EDX,extraout_EDX);
  param_2[2] = local_34;
  return iVar1;
}

