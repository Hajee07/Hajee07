/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001aa6d5 FUN_001aa6d5 */

undefined4 FUN_001aa6d5(void)

{
  int unaff_retaddr;
  
  return *(undefined4 *)(&LAB_000c7233 + unaff_retaddr);
}

