/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00215150 FUN_00215150 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 __regparm3 FUN_00215150(undefined4 *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  code *local_34;
  
  do {
    iVar1 = FUN_00214da1();
    iVar2 = FUN_00213e9f(param_2);
    uVar3 = (uint)(iVar2 + (*(int *)(param_2 + 0x60) >> 0x1f) == param_1[4]);
    if (iVar1 != 0) {
      return 2;
    }
    if (local_34 != (code *)0x0) {
      iVar1 = (*local_34)(1,uVar3 << 2 | 2,*param_1,param_1[1],param_1,param_2,0,0);
      if (iVar1 == 7) {
        return 7;
      }
      if (iVar1 != 8) {
        return 2;
      }
    }
    if (uVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0018b160();
    }
    FUN_00214d67();
  } while( true );
}

