/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f3f10 FUN_001f3f10 */

uint FUN_001f3f10(uint param_1)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  bool bVar10;
  
  if (param_1 < 0xd4) {
    puVar2 = (uint *)&DAT_0021f72c;
    uVar5 = 0x30;
    do {
      uVar4 = uVar5 >> 1;
      if (puVar2[uVar4] < param_1) {
        puVar2 = puVar2 + uVar4 + 1;
        uVar4 = ~uVar4 + uVar5;
      }
      uVar5 = uVar4;
    } while (uVar4 != 0);
    return *puVar2;
  }
  if (0xfffffffb < param_1) {
    FUN_001f46d0("__next_prime overflow");
    uVar5 = FUN_001f46d0();
    return uVar5;
  }
  uVar5 = param_1 / 0xd2;
  puVar7 = &DAT_0021f7ec;
  uVar4 = 0x30;
  do {
    uVar1 = uVar4 >> 1;
    if ((uint)puVar7[uVar1] < param_1 % 0xd2) {
      puVar7 = puVar7 + uVar1 + 1;
      uVar1 = ~uVar1 + uVar4;
    }
    uVar4 = uVar1;
  } while (uVar1 != 0);
  iVar8 = (int)(puVar7 + -0x87dfb) >> 2;
  do {
    puVar2 = &DAT_0021f740;
    uVar4 = uVar5 * 0xd2 + (&DAT_0021f7ec)[iVar8];
    iVar6 = 0x2a;
    do {
      uVar1 = *puVar2;
      if (uVar4 / uVar1 < uVar1) {
        return uVar4;
      }
      if (uVar4 == (uVar4 / uVar1) * uVar1) goto LAB_001f4670;
      puVar2 = puVar2 + 1;
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
    uVar1 = 0xd3;
    do {
      if (uVar4 / uVar1 < uVar1) {
        return uVar4;
      }
      if (uVar4 == (uVar4 / uVar1) * uVar1) break;
      uVar3 = uVar1 + 10;
      if (uVar4 / uVar3 < uVar3) {
        return uVar4;
      }
      if (uVar4 == (uVar4 / uVar3) * uVar3) break;
      uVar3 = uVar4 / (uVar1 + 0xc);
      if (uVar3 < uVar1 + 0xc) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xc)) break;
      uVar3 = uVar4 / (uVar1 + 0x10);
      if (uVar3 < uVar1 + 0x10) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x10)) break;
      uVar3 = uVar4 / (uVar1 + 0x12);
      if (uVar3 < uVar1 + 0x12) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x12)) break;
      uVar3 = uVar4 / (uVar1 + 0x16);
      if (uVar3 < uVar1 + 0x16) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x16)) break;
      uVar3 = uVar4 / (uVar1 + 0x1c);
      if (uVar3 < uVar1 + 0x1c) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x1c)) break;
      uVar3 = uVar4 / (uVar1 + 0x1e);
      if (uVar3 < uVar1 + 0x1e) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x1e)) break;
      uVar3 = uVar4 / (uVar1 + 0x24);
      if (uVar3 < uVar1 + 0x24) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x24)) break;
      uVar3 = uVar4 / (uVar1 + 0x28);
      if (uVar3 < uVar1 + 0x28) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x28)) break;
      uVar3 = uVar4 / (uVar1 + 0x2a);
      if (uVar3 < uVar1 + 0x2a) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x2a)) break;
      uVar3 = uVar4 / (uVar1 + 0x2e);
      if (uVar3 < uVar1 + 0x2e) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x2e)) break;
      uVar3 = uVar4 / (uVar1 + 0x34);
      if (uVar3 < uVar1 + 0x34) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x34)) break;
      uVar3 = uVar4 / (uVar1 + 0x3a);
      if (uVar3 < uVar1 + 0x3a) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x3a)) break;
      uVar3 = uVar4 / (uVar1 + 0x3c);
      if (uVar3 < uVar1 + 0x3c) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x3c)) break;
      uVar3 = uVar4 / (uVar1 + 0x42);
      if (uVar3 < uVar1 + 0x42) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x42)) break;
      uVar3 = uVar4 / (uVar1 + 0x46);
      if (uVar3 < uVar1 + 0x46) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x46)) break;
      uVar3 = uVar4 / (uVar1 + 0x48);
      if (uVar3 < uVar1 + 0x48) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x48)) break;
      uVar3 = uVar4 / (uVar1 + 0x4e);
      if (uVar3 < uVar1 + 0x4e) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x4e)) break;
      uVar3 = uVar4 / (uVar1 + 0x52);
      if (uVar3 < uVar1 + 0x52) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x52)) break;
      uVar3 = uVar4 / (uVar1 + 0x58);
      if (uVar3 < uVar1 + 0x58) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x58)) break;
      uVar3 = uVar4 / (uVar1 + 0x60);
      if (uVar3 < uVar1 + 0x60) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x60)) break;
      uVar3 = uVar4 / (uVar1 + 100);
      if (uVar3 < uVar1 + 100) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 100)) break;
      uVar3 = uVar4 / (uVar1 + 0x66);
      if (uVar3 < uVar1 + 0x66) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x66)) break;
      uVar3 = uVar4 / (uVar1 + 0x6a);
      if (uVar3 < uVar1 + 0x6a) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x6a)) break;
      uVar3 = uVar4 / (uVar1 + 0x6c);
      if (uVar3 < uVar1 + 0x6c) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x6c)) break;
      uVar3 = uVar4 / (uVar1 + 0x70);
      if (uVar3 < uVar1 + 0x70) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x70)) break;
      uVar3 = uVar4 / (uVar1 + 0x78);
      if (uVar3 < uVar1 + 0x78) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x78)) break;
      uVar3 = uVar4 / (uVar1 + 0x7e);
      if (uVar3 < uVar1 + 0x7e) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x7e)) break;
      uVar3 = uVar4 / (uVar1 + 0x82);
      if (uVar3 < uVar1 + 0x82) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x82)) break;
      uVar3 = uVar4 / (uVar1 + 0x88);
      if (uVar3 < uVar1 + 0x88) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x88)) break;
      uVar3 = uVar4 / (uVar1 + 0x8a);
      if (uVar3 < uVar1 + 0x8a) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x8a)) break;
      uVar3 = uVar4 / (uVar1 + 0x8e);
      if (uVar3 < uVar1 + 0x8e) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x8e)) break;
      uVar3 = uVar4 / (uVar1 + 0x94);
      if (uVar3 < uVar1 + 0x94) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x94)) break;
      uVar3 = uVar4 / (uVar1 + 0x96);
      if (uVar3 < uVar1 + 0x96) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x96)) break;
      uVar3 = uVar4 / (uVar1 + 0x9c);
      if (uVar3 < uVar1 + 0x9c) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0x9c)) break;
      uVar3 = uVar4 / (uVar1 + 0xa2);
      if (uVar3 < uVar1 + 0xa2) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xa2)) break;
      uVar3 = uVar4 / (uVar1 + 0xa6);
      if (uVar3 < uVar1 + 0xa6) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xa6)) break;
      uVar3 = uVar4 / (uVar1 + 0xa8);
      if (uVar3 < uVar1 + 0xa8) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xa8)) break;
      uVar3 = uVar4 / (uVar1 + 0xac);
      if (uVar3 < uVar1 + 0xac) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xac)) break;
      uVar3 = uVar4 / (uVar1 + 0xb2);
      if (uVar3 < uVar1 + 0xb2) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xb2)) break;
      uVar3 = uVar4 / (uVar1 + 0xb4);
      if (uVar3 < uVar1 + 0xb4) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xb4)) break;
      uVar3 = uVar4 / (uVar1 + 0xba);
      if (uVar3 < uVar1 + 0xba) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xba)) break;
      uVar3 = uVar4 / (uVar1 + 0xbe);
      if (uVar3 < uVar1 + 0xbe) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xbe)) break;
      uVar3 = uVar4 / (uVar1 + 0xc0);
      if (uVar3 < uVar1 + 0xc0) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xc0)) break;
      uVar3 = uVar4 / (uVar1 + 0xc4);
      if (uVar3 < uVar1 + 0xc4) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xc4)) break;
      uVar3 = uVar4 / (uVar1 + 0xc6);
      if (uVar3 < uVar1 + 0xc6) {
        return uVar4;
      }
      if (uVar4 == uVar3 * (uVar1 + 0xc6)) break;
      uVar9 = uVar1 + 0xd0;
      uVar3 = uVar4 / uVar9;
      if (uVar3 < uVar1 + 0xd0) {
        return uVar4;
      }
      uVar1 = uVar1 + 0xd2;
    } while (uVar4 != uVar3 * uVar9);
LAB_001f4670:
    iVar8 = iVar8 + 1;
    bVar10 = iVar8 == 0x30;
    if (bVar10) {
      iVar8 = 0;
    }
    uVar5 = uVar5 + bVar10;
  } while( true );
}

