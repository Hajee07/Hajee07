/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005469c FUN_0005469c */

void FUN_0005469c(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x0005469c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x74))();
  return;
}

