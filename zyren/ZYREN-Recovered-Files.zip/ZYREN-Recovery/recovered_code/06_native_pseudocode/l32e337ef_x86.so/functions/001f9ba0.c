/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9ba0 FUN_001f9ba0 */

void FUN_001f9ba0(undefined *param_1)

{
  byte bVar1;
  int iVar2;
  char *pcVar3;
  
  *param_1 = 1;
  iVar2 = FUN_0018adf0(&DAT_00276e74);
  if (iVar2 != 0) {
    pcVar3 = "%s failed to acquire mutex";
LAB_001f9c45:
                    /* WARNING: Subroutine does not return */
    FUN_001fd290(pcVar3,"__cxa_guard_release");
  }
  bVar1 = param_1[1];
  param_1[1] = 1;
                    /* try { // try from 001f9bdb to 001f9be2 has its CatchHandler @ 001f9c50 */
  iVar2 = FUN_0018ae00(&DAT_00276e74);
  if (iVar2 != 0) {
                    /* try { // try from 001f9c1a to 001f9c34 has its CatchHandler @ 001f9c50 */
                    /* WARNING: Subroutine does not return */
    FUN_001fd290("%s failed to release mutex","__cxa_guard_release");
  }
  if ((bVar1 & 4) != 0) {
    iVar2 = FUN_0018b460(&DAT_00276e78);
    if (iVar2 != 0) {
      pcVar3 = "%s failed to broadcast";
      goto LAB_001f9c45;
    }
  }
  return;
}

