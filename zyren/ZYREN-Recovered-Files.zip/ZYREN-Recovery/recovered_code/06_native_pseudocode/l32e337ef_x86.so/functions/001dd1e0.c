/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001dd1e0 FUN_001dd1e0 */

uint FUN_001dd1e0(int param_1,uint param_2,int param_3,undefined4 param_4,uint param_5)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar6 = 0x1dd1ec;
  iVar1 = *(int *)(param_1 + 0x48);
  uVar2 = param_3 + (uint)CARRY4(param_5,param_2);
  uVar5 = param_5 + param_2;
  if (uVar2 == 0 && (uint)(*(uint *)(iVar1 + 0x4c) < param_5 + param_2) <= -uVar2) {
    uVar2 = 0;
    uVar5 = *(uint *)(iVar1 + 0x4c);
  }
  if (param_5 != 0) {
    if ((uVar2 >> 0x1f | uVar2 << 1 | uVar5 >> 0x1f) == 0) {
      uVar4 = *(uint *)(iVar1 + 0x50);
      if (uVar2 == 0 && (uint)(uVar4 < uVar5) <= -uVar2) {
        iVar3 = *(int *)(iVar1 + 0x48);
      }
      else {
        uVar6 = 0x40;
        if (0x40 < uVar4) {
          uVar6 = uVar4;
        }
        do {
          uVar4 = uVar6;
          uVar6 = uVar4 * 2;
        } while (uVar2 != 0 || -uVar2 < (uint)(uVar4 < uVar5));
        uVar6 = uVar4;
        iVar3 = (**(code **)(param_1 + 0x30))
                          (*(undefined4 *)(param_1 + 0x34),*(undefined4 *)(iVar1 + 0x48),1,uVar4);
        if (iVar3 == 0) {
          *(undefined4 *)(param_1 + 0x1c) = 0x10;
          return 0;
        }
        *(int *)(iVar1 + 0x48) = iVar3;
        *(uint *)(iVar1 + 0x50) = uVar4;
      }
      FUN_0018ae80(iVar3 + param_2,param_4,param_5,uVar6);
      *(uint *)(iVar1 + 0x4c) = uVar5;
      return param_5;
    }
    *(undefined4 *)(param_1 + 0x1c) = 3;
  }
  return 0;
}

