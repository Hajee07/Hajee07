/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00211cb0 FUN_00211cb0 */

void FUN_00211cb0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  bool bVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int local_28;
  int local_24;
  
  iVar7 = param_2[1];
  uVar4 = iVar7 + 1;
  piVar2 = param_2 + 1;
  if (uVar4 < (uint)param_2[2]) {
    iVar6 = *param_2;
  }
  else {
    uVar5 = param_2[2] * 2;
    if (uVar5 < uVar4) {
      uVar5 = uVar4;
    }
    param_2[2] = uVar5;
    iVar6 = FUN_0018b200(*param_2,uVar5);
    *param_2 = iVar6;
    if (iVar6 == 0) goto LAB_002120d6;
    iVar7 = *piVar2;
  }
  *(undefined *)(iVar6 + iVar7) = 0x28;
  local_28 = *piVar2 + 1;
  *piVar2 = local_28;
  if (*(int *)(param_1 + 0x10) != 0) {
    local_24 = 0;
    bVar3 = true;
    do {
      iVar7 = local_28;
      if (!bVar3) {
        uVar4 = local_28 + 2;
        if (uVar4 < (uint)param_2[2]) {
          iVar7 = *param_2;
          iVar6 = local_28;
        }
        else {
          uVar5 = param_2[2] * 2;
          if (uVar5 < uVar4) {
            uVar5 = uVar4;
          }
          param_2[2] = uVar5;
          iVar7 = FUN_0018b200(*param_2,uVar5);
          *param_2 = iVar7;
          if (iVar7 == 0) {
                    /* WARNING: Subroutine does not return */
            FUN_001f9d40();
          }
          iVar6 = *piVar2;
        }
        *(undefined2 *)(iVar7 + iVar6) = 0x202c;
        iVar7 = *piVar2 + 2;
        *piVar2 = iVar7;
      }
      piVar1 = *(int **)(*(int *)(param_1 + 0xc) + local_24 * 4);
      (**(code **)(*piVar1 + 0x10))(piVar1,param_2);
      if (*(char *)((int)piVar1 + 5) != '\x01') {
        (**(code **)(*piVar1 + 0x14))(piVar1,param_2);
      }
      if (iVar7 == *piVar2) {
        *piVar2 = local_28;
      }
      else {
        bVar3 = false;
        local_28 = *piVar2;
      }
      local_24 = local_24 + 1;
    } while (local_24 != *(int *)(param_1 + 0x10));
  }
  uVar4 = local_28 + 1;
  if (uVar4 < (uint)param_2[2]) {
    iVar7 = *param_2;
  }
  else {
    uVar5 = param_2[2] * 2;
    if (uVar5 < uVar4) {
      uVar5 = uVar4;
    }
    param_2[2] = uVar5;
    iVar7 = FUN_0018b200(*param_2,uVar5);
    *param_2 = iVar7;
    if (iVar7 == 0) goto LAB_002120d6;
    local_28 = *piVar2;
  }
  *(undefined *)(iVar7 + local_28) = 0x29;
  param_2[1] = param_2[1] + 1;
  (**(code **)(**(int **)(param_1 + 8) + 0x14))(*(int **)(param_1 + 8),param_2);
  uVar4 = *(uint *)(param_1 + 0x14);
  if ((uVar4 & 1) != 0) {
    iVar7 = param_2[1];
    uVar4 = iVar7 + 6;
    if (uVar4 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar4) {
        uVar5 = uVar4;
      }
      param_2[2] = uVar5;
      iVar6 = FUN_0018b200(*param_2,uVar5);
      *param_2 = iVar6;
      if (iVar6 == 0) goto LAB_002120d6;
      iVar7 = *piVar2;
    }
    *(undefined2 *)(iVar6 + 4 + iVar7) = 0x7473;
    *(undefined4 *)(iVar6 + iVar7) = 0x6e6f6320;
    *piVar2 = *piVar2 + 6;
    uVar4 = *(uint *)(param_1 + 0x14);
  }
  if ((uVar4 & 2) != 0) {
    iVar7 = param_2[1];
    uVar4 = iVar7 + 9;
    if (uVar4 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar4) {
        uVar5 = uVar4;
      }
      param_2[2] = uVar5;
      iVar6 = FUN_0018b200(*param_2,uVar5);
      *param_2 = iVar6;
      if (iVar6 == 0) goto LAB_002120d6;
      iVar7 = *piVar2;
    }
    *(undefined *)(iVar6 + 8 + iVar7) = 0x65;
    *(undefined4 *)(iVar6 + 4 + iVar7) = 0x6c697461;
    *(undefined4 *)(iVar6 + iVar7) = 0x6c6f7620;
    *piVar2 = *piVar2 + 9;
    uVar4 = *(uint *)(param_1 + 0x14);
  }
  if ((uVar4 & 4) != 0) {
    iVar7 = param_2[1];
    uVar4 = iVar7 + 9;
    if (uVar4 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar4) {
        uVar5 = uVar4;
      }
      param_2[2] = uVar5;
      iVar6 = FUN_0018b200(*param_2,uVar5);
      *param_2 = iVar6;
      if (iVar6 == 0) goto LAB_002120d6;
      iVar7 = *piVar2;
    }
    *(undefined *)(iVar6 + 8 + iVar7) = 0x74;
    *(undefined4 *)(iVar6 + 4 + iVar7) = 0x63697274;
    *(undefined4 *)(iVar6 + iVar7) = 0x73657220;
    *piVar2 = *piVar2 + 9;
  }
  if (*(char *)(param_1 + 0x18) == '\x02') {
    iVar7 = param_2[1];
    uVar4 = iVar7 + 3;
    if (uVar4 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar4) {
        uVar5 = uVar4;
      }
      param_2[2] = uVar5;
      iVar6 = FUN_0018b200(*param_2,uVar5);
      *param_2 = iVar6;
      if (iVar6 == 0) goto LAB_002120d6;
      iVar7 = *piVar2;
    }
    *(undefined *)(iVar6 + 2 + iVar7) = 0x26;
    *(undefined2 *)(iVar6 + iVar7) = 0x2620;
    iVar7 = 3;
LAB_0021204a:
    *piVar2 = *piVar2 + iVar7;
  }
  else if (*(char *)(param_1 + 0x18) == '\x01') {
    iVar7 = param_2[1];
    uVar4 = iVar7 + 2;
    if (uVar4 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar4) {
        uVar5 = uVar4;
      }
      param_2[2] = uVar5;
      iVar6 = FUN_0018b200(*param_2,uVar5);
      *param_2 = iVar6;
      if (iVar6 == 0) goto LAB_002120d6;
      iVar7 = *piVar2;
    }
    *(undefined2 *)(iVar6 + iVar7) = 0x2620;
    iVar7 = 2;
    goto LAB_0021204a;
  }
  if (*(int *)(param_1 + 0x1c) != 0) {
    iVar7 = param_2[1];
    uVar4 = iVar7 + 1;
    if (uVar4 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar5 = param_2[2] * 2;
      if (uVar5 < uVar4) {
        uVar5 = uVar4;
      }
      param_2[2] = uVar5;
      iVar6 = FUN_0018b200(*param_2,uVar5);
      *param_2 = iVar6;
      if (iVar6 == 0) {
LAB_002120d6:
                    /* WARNING: Subroutine does not return */
        FUN_001f9d40();
      }
      iVar7 = *piVar2;
      uVar4 = iVar7 + 1;
    }
    param_2[1] = uVar4;
    *(undefined *)(iVar6 + iVar7) = 0x20;
    piVar2 = *(int **)(param_1 + 0x1c);
    (**(code **)(*piVar2 + 0x10))(piVar2,param_2);
    if (*(char *)((int)piVar2 + 5) != '\x01') {
      (**(code **)(*piVar2 + 0x14))(piVar2,param_2);
    }
  }
  return;
}

