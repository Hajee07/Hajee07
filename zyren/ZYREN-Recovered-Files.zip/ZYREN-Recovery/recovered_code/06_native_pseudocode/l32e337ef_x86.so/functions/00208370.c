/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00208370 FUN_00208370 */

int FUN_00208370(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int in_ECX;
  int iVar5;
  
  iVar2 = FUN_002042b0();
  iVar5 = 0;
  if (iVar2 != 0) {
    iVar3 = FUN_002042b0();
    if (iVar3 != 0) {
      piVar1 = *(int **)(in_ECX + 0x116c);
      iVar5 = piVar1[1];
      piVar4 = piVar1;
      if (0xff7 < iVar5 + 0x20U) {
        piVar4 = (int *)FUN_0018add0(0x1000);
        if (piVar4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_001f9d40();
        }
        *piVar4 = (int)piVar1;
        piVar4[1] = 0;
        *(int **)(in_ECX + 0x116c) = piVar4;
        iVar5 = 0;
      }
      piVar4[1] = iVar5 + 0x20;
      *(undefined4 *)((int)piVar4 + iVar5 + 0xc) = 0x101012a;
      *(undefined ***)((int)piVar4 + iVar5 + 8) = &PTR_FUN_0024ad58;
      *(int *)((int)piVar4 + iVar5 + 0x10) = iVar2;
      *(undefined4 *)((int)piVar4 + iVar5 + 0x18) = param_2;
      *(undefined4 *)((int)piVar4 + iVar5 + 0x14) = param_1;
      *(int *)((int)piVar4 + iVar5 + 0x1c) = iVar3;
      iVar5 = (int)piVar4 + iVar5 + 8;
    }
  }
  return iVar5;
}

