/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019b8f0 FUN_0019b8f0 */

int FUN_0019b8f0(int param_1,uint param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined local_12c [16];
  undefined local_11c [268];
  
  local_12c = ZEXT816(0);
  uVar7 = param_2 + 0xfff & 0xfffff000;
  iVar1 = FUN_0018add0(uVar7);
  FUN_0018ae30(iVar1,0,uVar7);
  if (iVar1 != 0) {
    uVar8 = (param_3 / 0x1000) * 0x1000;
    uVar3 = ~uVar8 + 0x1000 + param_3 + param_2 & 0xfffff000;
    local_12c = *(undefined (*) [16])PTR_DAT_0024bb38;
    uVar8 = (uint)(*(uint *)(param_4 + 0x2c) < uVar3 + uVar8);
    uVar6 = *(uint *)(param_4 + 0x2c) + (param_3 / 0x1000) * -0x1000;
    if ((SBORROW4(*(int *)(param_4 + 0x30),uVar8) != false) ==
        (int)(*(int *)(param_4 + 0x30) - uVar8) < 0) {
      uVar6 = uVar3;
    }
    FUN_0018ae30(local_11c,0,0x108);
    thunk_FUN_0005e980(local_11c,local_12c,0x10);
    uVar8 = *(uint *)(param_4 + 0x20);
    iVar2 = param_1;
    iVar4 = iVar1;
    uVar3 = uVar6;
    if (uVar8 < uVar6) {
      iVar5 = 0;
      do {
        FUN_001b5e90(local_11c,iVar2,iVar4,uVar8);
        uVar3 = uVar3 - *(int *)(param_4 + 0x20);
        iVar5 = iVar5 + *(int *)(param_4 + 0x20);
        FUN_0018ae30(local_11c,0,0x108);
        thunk_FUN_0005e980(local_11c,local_12c,0x10);
        uVar8 = *(uint *)(param_4 + 0x20);
        iVar2 = param_1 + iVar5;
        iVar4 = iVar1 + iVar5;
      } while (uVar8 < uVar3);
    }
    FUN_001b5e90(local_11c,iVar2,iVar4,uVar3);
    uVar6 = uVar6 - param_3 % 0x1000;
    if (param_2 < uVar6) {
      uVar6 = param_2;
    }
    FUN_0018ae80(iVar1,param_3 % 0x1000 + iVar1,uVar6);
    FUN_0018ae30(iVar1 + uVar6,0,uVar7 - uVar6);
    param_1 = iVar1;
  }
  return param_1;
}

