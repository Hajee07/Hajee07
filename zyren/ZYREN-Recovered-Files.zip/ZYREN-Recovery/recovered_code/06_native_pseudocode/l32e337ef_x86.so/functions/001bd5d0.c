/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bd5d0 FUN_001bd5d0 */

undefined4 FUN_001bd5d0(undefined4 param_1,int param_2)

{
  ushort uVar1;
  ushort *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint *puVar7;
  
  iVar5 = *(int *)(param_2 + 8);
  puVar2 = *(ushort **)(param_2 + 0x28);
  uVar4 = (uint)(*puVar2 >> 8);
  iVar3 = *(int *)(iVar5 + uVar4 * 0xc);
  uVar6 = 0;
  uVar1 = puVar2[*(int *)(puVar2 + 1) + 1];
  switch(iVar3) {
  case 1:
  case 2:
    uVar6 = (uint)*(char *)(iVar5 + 4 + uVar4 * 0xc);
    goto joined_r0x001bd696;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    break;
  case 4:
    uVar6 = (uint)*(ushort *)(iVar5 + 4 + uVar4 * 0xc);
joined_r0x001bd696:
    if ((short)uVar1 < 1) {
      return 0;
    }
    goto LAB_001bd64a;
  case 8:
    uVar6 = (uint)*(short *)(iVar5 + 4 + uVar4 * 0xc);
    break;
  case 0x10:
switchD_001bd61d_caseD_10:
    uVar6 = *(uint *)(iVar5 + 4 + uVar4 * 0xc);
    break;
  default:
    if (iVar3 == 0x1000) goto switchD_001bd61d_caseD_10;
  }
  if (0 < (short)uVar1) {
LAB_001bd64a:
    puVar7 = (uint *)(puVar2 + *(int *)(puVar2 + 1) + 2);
    uVar4 = *puVar7;
    iVar5 = (int)(short)uVar1;
    while( true ) {
      if (uVar6 == uVar4) {
        *(undefined *)(param_2 + 0x30) = 1;
        puVar2 = puVar2 + puVar7[(short)uVar1];
        *(ushort **)(param_2 + 0x28) = puVar2;
      }
      if (iVar5 == 1) break;
      iVar5 = iVar5 + -1;
      puVar7 = puVar7 + 1;
      uVar4 = *puVar7;
    }
  }
  return 0;
}

