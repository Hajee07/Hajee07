/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5a10 FUN_001b5a10 */

void FUN_001b5a10(int param_1)

{
  int *piVar1;
  int *piVar2;
  
  if (param_1 != 0) {
    piVar2 = (int *)(param_1 + -8);
    do {
      piVar1 = (int *)*piVar2;
      FUN_001d0cb0(piVar2);
      piVar2 = piVar1;
    } while (piVar1 != (int *)0x0);
  }
  return;
}

