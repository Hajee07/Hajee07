/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00214ad9 FUN_00214ad9 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void __regparm3 FUN_00214ad9(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 extraout_ECX;
  undefined4 extraout_ECX_00;
  undefined4 extraout_EDX;
  int *piVar5;
  int *piVar6;
  int iVar7;
  undefined8 uVar8;
  undefined *puVar9;
  undefined local_a4 [4];
  undefined local_a0 [4];
  int local_9c [4];
  int local_8c;
  byte local_39;
  char acStack_30 [4];
  char local_2c;
  undefined4 uStack_14;
  
  uStack_14 = 0x214af1;
  piVar5 = param_1;
  piVar6 = local_9c;
  for (iVar4 = 0x20; iVar4 != 0; iVar4 = iVar4 + -1) {
    *piVar6 = *piVar5;
    piVar5 = piVar5 + 1;
    piVar6 = piVar6 + 1;
  }
  if ((((local_39 & 0x40) == 0) || (local_2c == '\0')) && (local_8c == 0)) {
    FUN_00213d40(local_a4);
  }
  if ((*(byte *)((int)param_1 + 99) & 0x40) != 0) {
    *(undefined *)(param_1 + 0x1c) = 0;
  }
  param_1[4] = 0;
  if (*(int *)(param_2 + 0xa0) == 1) {
    uVar8 = FUN_00213d76(local_9c,*(undefined4 *)(param_2 + 0x98),piVar6,piVar6);
    uVar8 = CONCAT44((int)((ulonglong)uVar8 >> 0x20),(int)uVar8 + *(int *)(param_2 + 0x94));
  }
  else {
    if (*(int *)(param_2 + 0xa0) != 2) {
LAB_00214c4b:
                    /* WARNING: Subroutine does not return */
      FUN_0018b160();
    }
    FUN_00213bab();
    uVar8 = FUN_00214546(local_9c,0,extraout_ECX,extraout_ECX);
  }
  piVar5 = (int *)((ulonglong)uVar8 >> 0x20);
  iVar7 = (int)uVar8;
  iVar4 = 0;
  param_1[0x12] = iVar7;
  puVar9 = local_a0;
  do {
    uVar1 = *(undefined4 *)(param_2 + 4 + iVar4 * 8);
    switch(uVar1) {
    case 1:
      iVar2 = *(int *)(param_2 + iVar4 * 8) + iVar7;
code_r0x00214c67:
      if ((*(byte *)((int)param_1 + 99) & 0x40) != 0) {
        *(undefined *)((int)param_1 + iVar4 + 0x6c) = 0;
      }
      break;
    case 2:
      iVar2 = *(int *)(param_2 + iVar4 * 8);
      if (acStack_30[iVar2] == '\0') {
        iVar2 = local_9c[iVar2];
        goto code_r0x00214c67;
      }
      uVar8 = FUN_00213d76(local_9c,iVar2,piVar5,piVar5);
      piVar5 = (int *)((ulonglong)uVar8 >> 0x20);
      iVar2 = (int)uVar8;
      if (4 < (byte)(&DAT_00277094)[iVar4]) goto LAB_00214c4b;
      *(undefined *)((int)param_1 + iVar4 + 0x6c) = 1;
      break;
    case 3:
      FUN_00213bab(uVar1,puVar9);
      iVar2 = FUN_00214546(local_9c,iVar7,extraout_ECX_00,extraout_ECX_00);
      if ((*(byte *)((int)param_1 + 99) & 0x40) != 0) {
        *(undefined *)((int)param_1 + iVar4 + 0x6c) = 0;
      }
      param_1[iVar4] = iVar2;
      piVar5 = param_1;
      goto LAB_00214d26;
    case 4:
      iVar2 = *(int *)(param_2 + iVar4 * 8) + iVar7;
      goto code_r0x00214d08;
    case 5:
      FUN_00213bab(uVar1,puVar9);
      iVar2 = FUN_00214546(local_9c,iVar7,extraout_EDX,extraout_EDX);
code_r0x00214d08:
      if (4 < (byte)(&DAT_00277094)[iVar4]) goto LAB_00214c4b;
      *(undefined *)((int)param_1 + iVar4 + 0x6c) = 1;
      piVar5 = param_1;
      break;
    default:
      goto LAB_00214d26;
    }
    param_1[iVar4] = iVar2;
LAB_00214d26:
    iVar4 = iVar4 + 1;
    if (iVar4 == 0x12) {
      uVar3 = param_1[0x18] & 0x7fffffff;
      if (*(char *)(param_2 + 0xbb) != '\0') {
        uVar3 = param_1[0x18] | 0x80000000;
      }
      param_1[0x18] = uVar3;
      return;
    }
  } while( true );
}

