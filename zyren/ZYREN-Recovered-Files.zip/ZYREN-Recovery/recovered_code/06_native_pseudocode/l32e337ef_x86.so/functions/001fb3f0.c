/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fb3f0 FUN_001fb3f0 */

bool FUN_001fb3f0(int param_1,int param_2)

{
  return *(int *)(param_1 + 4) == *(int *)(param_2 + 4);
}

