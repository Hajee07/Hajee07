/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110240 FUN_00110240 */

int FUN_00110240(void)

{
  byte *in_ECX;
  byte bVar1;
  int iVar2;
  
  bVar1 = *in_ECX;
  if (bVar1 != 0) {
    in_ECX = in_ECX + 1;
    iVar2 = 0x1505;
    do {
      iVar2 = iVar2 * 0x21 + (uint)bVar1;
      bVar1 = *in_ECX;
      in_ECX = in_ECX + 1;
    } while (bVar1 != 0);
    return iVar2;
  }
  return 0x1505;
}

