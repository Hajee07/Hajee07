/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a2250 FUN_001a2250 */

void FUN_001a2250(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  undefined *puVar3;
  undefined *puVar4;
  char cVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined local_4c [16];
  undefined local_3c [16];
  undefined local_2c [16];
  undefined4 local_1c;
  
  local_2c = ZEXT816(0);
  local_3c = ZEXT816(0);
  local_4c = ZEXT816(0);
  local_1c = 0;
  uVar6 = thunk_FUN_001b5f55();
  cVar5 = FUN_001b61f0(uVar6,param_1,PTR_FUN_0024bb60,local_4c);
  if (cVar5 != '\0') {
    uVar6 = thunk_FUN_001b5f55();
    FUN_001b60e0(uVar6,param_1,FUN_0019b1c0);
  }
  puVar3 = PTR_DAT_0024bb68;
  if (*PTR_DAT_0024bbcc != '\0') {
    FUN_001f4b70(PTR_DAT_0024bb68);
    puVar4 = PTR_DAT_0024bb6c;
    piVar7 = *(int **)(PTR_DAT_0024bb6c + 4);
    while (piVar7 != (int *)puVar4) {
      while (piVar7[3] != param_1) {
        piVar7 = (int *)piVar7[1];
        if (piVar7 == (int *)puVar4) goto LAB_001a2345;
      }
      if (piVar7[5] != 0) {
        FUN_0018ae20(piVar7[5]);
      }
      iVar1 = *piVar7;
      piVar2 = (int *)piVar7[1];
      *(int **)(iVar1 + 4) = piVar2;
      *(int *)piVar7[1] = iVar1;
      *(int *)(puVar4 + 8) = *(int *)(puVar4 + 8) + -1;
      FUN_001f5680(piVar7);
      piVar7 = piVar2;
    }
LAB_001a2345:
    FUN_001f4bf0(puVar3);
  }
  (**(code **)PTR_DAT_0024bb48)(param_1,param_2,param_3);
  return;
}

