/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f1c10 FUN_001f1c10 */

undefined4 FUN_001f1c10(uint param_1,undefined4 *param_2,undefined4 *param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  ushort uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  byte *pbVar11;
  undefined4 *local_34;
  int local_30;
  int local_2c;
  int local_28;
  uint local_24;
  int local_20;
  int local_1c;
  undefined4 **local_18;
  uint local_14;
  
  if (param_1 == 0) {
    return 0;
  }
  if (param_2 == (undefined4 *)0x0) {
    return 0;
  }
  if (param_3 == (undefined4 *)0x0) {
    return 0;
  }
  param_2[1] = 0;
  *param_2 = 0;
  param_2[3] = 0;
  param_2[2] = 0;
  for (puVar10 = (undefined4 *)*param_3; puVar10 != (undefined4 *)0x0;
      puVar10 = (undefined4 *)puVar10[4]) {
    uVar3 = puVar10[1];
    if ((uVar3 <= param_1) && (uVar4 = *(ushort *)(puVar10 + 3), uVar4 != 0)) {
      piVar5 = (int *)puVar10[2];
      uVar9 = (uint)uVar4;
      iVar7 = *piVar5;
      while( true ) {
        if (((iVar7 == 1) && ((uint)piVar5[2] <= param_1 - uVar3)) &&
           (param_1 - uVar3 < (uint)(piVar5[2] + piVar5[5]))) goto LAB_001f1d25;
        piVar5 = piVar5 + 8;
        uVar9 = uVar9 - 1;
        if (uVar9 == 0) break;
        iVar7 = *piVar5;
      }
    }
  }
  local_34 = (undefined4 *)0x0;
  local_18 = &local_34;
  local_14 = param_1;
  FUN_001f2460(FUN_001f2350,&local_18,0);
  if (local_34 == (undefined4 *)0x0) {
    return 0;
  }
  local_34[4] = *param_3;
  *param_3 = local_34;
  uVar3 = local_34[1];
  uVar4 = *(ushort *)(local_34 + 3);
  puVar10 = local_34;
LAB_001f1d25:
  param_2[1] = uVar3;
  *param_2 = *puVar10;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = puVar10[2];
  param_2[6] = (uint)uVar4;
  if (*(char *)(puVar10 + 6) == '\0') {
    *(undefined *)(puVar10 + 6) = 1;
    iVar7 = FUN_001f0ff0();
    if (iVar7 != 0) goto LAB_001f1ebd;
  }
  iVar7 = puVar10[7];
  if (iVar7 != 0) {
    local_30 = puVar10[1];
    local_28 = puVar10[0xe];
    uVar3 = param_1 - local_30;
    if (local_28 == 0) {
      if (puVar10[0xc] != 0) {
        pbVar11 = (byte *)(iVar7 + 0xc);
        uVar9 = 0;
        bVar1 = *pbVar11;
        do {
          if ((((bVar1 & 0xf) != 6) && (uVar8 = *(uint *)(pbVar11 + -8), uVar8 <= uVar3)) &&
             (iVar6 = *(int *)(pbVar11 + -4), uVar3 < iVar6 + uVar8)) {
LAB_001f1e2c:
            param_2[2] = puVar10[8] + *(int *)(iVar7 + uVar9 * 0x10);
            param_2[3] = uVar8 + local_30;
            param_2[4] = iVar6;
            return 1;
          }
          uVar9 = uVar9 + 1;
          pbVar11 = pbVar11 + 0x10;
          if (puVar10[0xc] == uVar9) break;
          bVar1 = *pbVar11;
        } while( true );
      }
    }
    else {
      local_20 = puVar10[0xd];
      local_24 = puVar10[0x10];
      local_2c = iVar7 + 0xc;
      iVar6 = 0;
      do {
        local_1c = iVar6;
        uVar9 = *(uint *)(local_20 + local_1c * 4);
        if (local_24 <= uVar9) {
          pbVar11 = (byte *)(uVar9 * 0x10 + local_2c);
          bVar1 = *pbVar11;
          while( true ) {
            if ((((bVar1 & 0xf) != 6) && (uVar8 = *(uint *)(pbVar11 + -8), uVar8 <= uVar3)) &&
               (iVar6 = *(int *)(pbVar11 + -4), uVar3 < iVar6 + uVar8)) goto LAB_001f1e2c;
            pbVar11 = pbVar11 + 0x10;
            iVar6 = uVar9 * 4;
            uVar9 = uVar9 + 1;
            if ((*(byte *)(puVar10[0xf] + local_24 * -4 + iVar6) & 1) != 0) break;
            bVar1 = *pbVar11;
          }
        }
        iVar6 = local_1c + 1;
      } while (local_1c + 1 != local_28);
    }
  }
LAB_001f1ebd:
  if (*(char *)(puVar10 + 0x14) == '\0') {
    *(undefined *)(puVar10 + 0x14) = 1;
    iVar7 = FUN_001f1290();
    if (iVar7 != 0) {
      return 1;
    }
  }
  if (puVar10[0x16] == 0) {
    return 1;
  }
  iVar7 = puVar10[0x17];
  if (iVar7 == 0) {
    return 1;
  }
  iVar6 = puVar10[1];
  param_1 = param_1 - iVar6;
  pbVar11 = (byte *)(puVar10[0x16] + 0xc);
  if ((*pbVar11 & 0xf) != 6) goto LAB_001f1f01;
  do {
    do {
      pbVar11 = pbVar11 + 0x10;
      iVar7 = iVar7 + -1;
      if (iVar7 == 0) {
        return 1;
      }
    } while ((*pbVar11 & 0xf) == 6);
LAB_001f1f01:
    uVar3 = *(uint *)(pbVar11 + -8);
  } while ((param_1 < uVar3) || (iVar2 = *(int *)(pbVar11 + -4), iVar2 + uVar3 <= param_1));
  param_2[2] = puVar10[0x18] + *(int *)(pbVar11 + -0xc);
  param_2[3] = uVar3 + iVar6;
  param_2[4] = iVar2;
  return 1;
}

