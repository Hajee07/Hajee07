/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b8510 FUN_001b8510 */

void FUN_001b8510(undefined4 param_1)

{
  FUN_001b8540(param_1);
  return;
}

