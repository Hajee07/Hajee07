/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f6180 FUN_001f6180 */

undefined4 * FUN_001f6180(undefined4 *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  
  if (param_3 < 0x1000) {
    FUN_001f5ed0(param_1);
  }
  else {
    param_1[1] = 0;
    *param_1 = 0;
    param_1[2] = 0;
    iVar1 = FUN_001f5520(0x30);
    param_1[2] = iVar1;
    *param_1 = 0x31;
    param_1[1] = 0x21;
    FUN_0018ae80(iVar1,"unspecified system_category error",0x21);
    *(undefined *)(iVar1 + 0x21) = 0;
  }
  return param_1;
}

