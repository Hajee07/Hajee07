/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019c080 FUN_0019c080 */

void __regparm3 FUN_0019c080(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0018b040(0x55,param_3,param_2,0x1000);
  return;
}

