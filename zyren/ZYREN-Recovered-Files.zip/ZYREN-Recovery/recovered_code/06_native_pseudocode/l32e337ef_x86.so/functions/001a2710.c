/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a2710 FUN_001a2710 */

void FUN_001a2710(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined *puVar3;
  undefined *puVar4;
  int *piVar5;
  
  puVar3 = PTR_DAT_0024bbf0;
  FUN_001f4b70(PTR_DAT_0024bbf0);
  puVar4 = PTR_DAT_0024bbf4;
  piVar5 = *(int **)(PTR_DAT_0024bbf4 + 4);
  while (piVar5 != (int *)puVar4) {
    while (piVar5[3] != param_1) {
      piVar5 = (int *)piVar5[1];
      if (piVar5 == (int *)puVar4) goto LAB_001a279c;
    }
    if (piVar5[10] != 0) {
      FUN_0018ae20(piVar5[10]);
    }
    if (piVar5[2] != 0) {
      FUN_0018ae20(piVar5[2]);
    }
    iVar1 = *piVar5;
    piVar2 = (int *)piVar5[1];
    *(int **)(iVar1 + 4) = piVar2;
    *(int *)piVar5[1] = iVar1;
    *(int *)(puVar4 + 8) = *(int *)(puVar4 + 8) + -1;
    FUN_001f5680(piVar5);
    piVar5 = piVar2;
  }
LAB_001a279c:
  FUN_001f4bf0(puVar3);
  (**(code **)PTR_DAT_0024bbfc)(param_1);
  return;
}

