/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c7300 FUN_001c7300 */

uint FUN_001c7300(int param_1,int param_2,uint param_3,uint *param_4,uint param_5)

{
  byte bVar1;
  ushort uVar2;
  int iVar3;
  uint3 uVar4;
  uint uVar5;
  uint uVar6;
  
  if (*(uint *)(param_1 + 0x5c3c) != param_5) {
    return 0xffffffb8;
  }
  if ((param_3 != 0) && (iVar3 = *(int *)(param_1 + 0x5c2c), iVar3 != param_2)) {
    *(int *)(param_1 + 0x5c38) = iVar3;
    *(int *)(param_1 + 0x5c34) = (*(int *)(param_1 + 0x5c30) - iVar3) + param_2;
    *(int *)(param_1 + 0x5c30) = param_2;
    *(int *)(param_1 + 0x5c2c) = param_2;
  }
  switch(*(undefined4 *)(param_1 + 0x5c64)) {
  case 0:
    if (param_5 != 5) {
      return 0xffffffb8;
    }
    if ((*param_4 & 0xfffffff0) == 0x184d2a50) {
      (&DAT_00025d38)[param_1] = *(undefined *)(param_4 + 1);
      *(uint *)(&DAT_00025d34 + param_1) = *param_4;
      *(undefined4 *)(param_1 + 0x5c3c) = 3;
      *(undefined4 *)(param_1 + 0x5c64) = 6;
      return 0;
    }
    bVar1 = *(byte *)(param_4 + 1);
    uVar5 = (bVar1 & 0x20) >> 5;
    uVar5 = ((*(int *)(&DAT_0021b5e0 + (uint)(bVar1 >> 6) * 4) +
             *(int *)(&DAT_0021b5d0 + (bVar1 & 3) * 4)) - uVar5) + 6 +
            (uint)(bVar1 >> 6 == 0 & (byte)uVar5);
    *(uint *)(param_1 + 0x5cc4) = uVar5;
    if (0xffffff88 < uVar5) {
      return uVar5;
    }
    (&DAT_00025d38)[param_1] = *(undefined *)(param_4 + 1);
    *(uint *)(&DAT_00025d34 + param_1) = *param_4;
    if (5 < uVar5) {
      *(uint *)(param_1 + 0x5c3c) = uVar5 - 5;
      *(undefined4 *)(param_1 + 0x5c64) = 1;
      return 0;
    }
    *(undefined4 *)(param_1 + 0x5c3c) = 0;
    param_5 = 0;
    break;
  case 1:
    uVar5 = *(uint *)(param_1 + 0x5cc4);
    break;
  case 2:
    uVar2 = *(ushort *)param_4;
    uVar4 = *(uint3 *)param_4;
    uVar6 = uVar2 >> 1 & 3;
    uVar5 = uVar6;
    if ((uVar6 != 1) && (uVar5 = (uint)(uVar4 >> 3), uVar6 == 3)) {
      return 0xffffffec;
    }
    *(uint *)(param_1 + 0x5c3c) = uVar5;
    *(uint *)(param_1 + 0x5c60) = uVar6;
    *(uint *)(param_1 + 0x5ce0) = (uint)(uVar4 >> 3);
    if (uVar5 != 0) {
      *(uint *)(param_1 + 0x5c64) = (uVar2 & 1) + 3;
      return 0;
    }
    if ((uVar2 & 1) == 0) {
      *(undefined4 *)(param_1 + 0x5c3c) = 3;
      *(undefined4 *)(param_1 + 0x5c64) = 2;
      return 0;
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      *(undefined4 *)(param_1 + 0x5c3c) = 4;
      *(undefined4 *)(param_1 + 0x5c64) = 5;
      return 0;
    }
  case 7:
    *(undefined4 *)(param_1 + 0x5c3c) = 0;
    *(undefined4 *)(param_1 + 0x5c64) = 0;
    return 0;
  case 3:
  case 4:
    iVar3 = *(int *)(param_1 + 0x5c60);
    if (iVar3 == 0) {
      if (param_3 < param_5) {
        return 0xffffffba;
      }
      FUN_0018ae80(param_2,param_4,param_5);
      if (0xffffff88 < param_5) {
        return param_5;
      }
    }
    else {
      if (iVar3 == 1) {
        if (param_5 != 1) {
          return 0xffffffb8;
        }
        param_5 = *(uint *)(param_1 + 0x5ce0);
        if (param_3 < param_5) {
          return 0xffffffba;
        }
        FUN_0018ae30(param_2,*(undefined *)param_4,param_5);
      }
      else {
        if (iVar3 != 2) {
          return 0xffffffec;
        }
        param_5 = FUN_001c5a20(param_3,param_4,param_5);
      }
      if (0xffffff88 < param_5) {
        return param_5;
      }
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      FUN_001cb7c0(param_1 + 0x5c70,param_2,param_5);
    }
    if (*(int *)(param_1 + 0x5c64) != 4) {
      *(undefined4 *)(param_1 + 0x5c64) = 2;
      *(undefined4 *)(param_1 + 0x5c3c) = 3;
      *(uint *)(param_1 + 0x5c2c) = param_2 + param_5;
      return param_5;
    }
    if (*(int *)(param_1 + 0x5c5c) == 0) {
      *(undefined4 *)(param_1 + 0x5c3c) = 0;
      *(undefined4 *)(param_1 + 0x5c64) = 0;
      return param_5;
    }
    *(undefined4 *)(param_1 + 0x5c3c) = 4;
    *(undefined4 *)(param_1 + 0x5c64) = 5;
    return param_5;
  case 5:
    uVar5 = FUN_001cbab0(param_1 + 0x5c70);
    if (*param_4 == uVar5) {
      *(undefined4 *)(param_1 + 0x5c3c) = 0;
      *(undefined4 *)(param_1 + 0x5c64) = 0;
      return 0;
    }
    return 0xffffffea;
  case 6:
    FUN_0018ae80(&DAT_00025d39 + param_1,param_4,param_5);
    *(undefined4 *)(param_1 + 0x5c3c) = *(undefined4 *)(&DAT_00025d38 + param_1);
    *(undefined4 *)(param_1 + 0x5c64) = 7;
    return 0;
  default:
    return 0xffffffff;
  }
  FUN_0018ae80(&DAT_00025d39 + param_1,param_4,param_5);
  uVar5 = FUN_001c4b50(param_1 + 0x5c40,&DAT_00025d34 + param_1,uVar5);
  if (0xffffff88 < uVar5) {
    return uVar5;
  }
  if (uVar5 == 0) {
    if ((*(int *)(param_1 + 0x5c58) != 0) &&
       (*(int *)(param_1 + 0x5cc8) != *(int *)(param_1 + 0x5c58))) {
      return 0xffffffe0;
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      FUN_001cb4b0(param_1 + 0x5c70,0,0);
    }
    *(undefined4 *)(param_1 + 0x5c3c) = 3;
    *(undefined4 *)(param_1 + 0x5c64) = 2;
    return 0;
  }
  return 0xffffffb8;
}

