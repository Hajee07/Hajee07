/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001abd70 FUN_001abd70 */

int FUN_001abd70(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_0018b0c0(param_1,&DAT_00217d83);
  if (iVar1 == 0) {
    iVar3 = 0;
  }
  else {
    FUN_0018b0d0(iVar1,0,2);
    uVar2 = FUN_0018b0e0(iVar1);
    *param_2 = uVar2;
    FUN_0018b0d0(iVar1,0,0);
    uVar2 = *param_2;
    iVar3 = FUN_0018b0f0(uVar2,1);
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      FUN_0018b100(iVar3,1,uVar2,iVar1);
    }
    FUN_0018b120(iVar1);
  }
  return iVar3;
}

