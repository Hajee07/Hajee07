/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001cc030 FUN_001cc030 */

int FUN_001cc030(uint param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if (0xffffff88 < param_1) {
    iVar1 = -param_1;
  }
  return iVar1;
}

