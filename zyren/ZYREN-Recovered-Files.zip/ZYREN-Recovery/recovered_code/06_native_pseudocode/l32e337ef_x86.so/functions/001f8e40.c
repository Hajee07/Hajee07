/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f8e40 FUN_001f8e40 */

void FUN_001f8e40(undefined4 *param_1)

{
  *param_1 = PTR_DAT_0024bda4 + 8;
  FUN_001f93b0(param_1[1]);
  FUN_001f5680(param_1);
  return;
}

