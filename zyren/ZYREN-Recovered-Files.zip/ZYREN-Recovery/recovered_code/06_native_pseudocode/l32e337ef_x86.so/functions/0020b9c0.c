/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020b9c0 FUN_0020b9c0 */

int __regparm3 FUN_0020b9c0(undefined4 param_1,undefined *param_2,undefined4 *param_3)

{
  undefined uVar1;
  char cVar2;
  undefined *puVar3;
  int **ppiVar4;
  int *piVar5;
  int iVar6;
  int **ppiVar7;
  undefined **ppuVar8;
  int *piVar9;
  int iVar10;
  uint uVar11;
  int local_1c;
  
  puVar3 = (undefined *)*param_3;
  local_1c = 0;
  uVar11 = (int)(undefined *)param_3[1] - (int)puVar3;
  if ((undefined *)param_3[1] == puVar3) {
    return 0;
  }
  switch(*puVar3) {
  case 0x61:
    if (uVar11 < 2) {
      return 0;
    }
    switch(puVar3[1]) {
    case 0x4e:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator&=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x53:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x61:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator&&";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 100:
    case 0x6e:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator&";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 99:
    if (1 < uVar11) {
      switch(puVar3[1]) {
      case 0x6c:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator()";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x6d:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator,";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x6f:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator~";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x76:
        *param_3 = puVar3 + 2;
        uVar1 = *(undefined *)(param_3 + 0x5a);
        cVar2 = *(char *)((int)param_3 + 0x169);
        *(undefined *)(param_3 + 0x5a) = 0;
        *(bool *)((int)param_3 + 0x169) = param_2 != (undefined *)0x0 || cVar2 != '\0';
                    /* try { // try from 0020c99f to 0020c9a3 has its CatchHandler @ 0020d3cd */
        iVar6 = FUN_001fed60();
        if (iVar6 == 0) {
          local_1c = 0;
        }
        else {
          if (param_2 != (undefined *)0x0) {
            *param_2 = 1;
          }
          piVar9 = (int *)param_3[0x45b];
          iVar10 = piVar9[1];
          piVar5 = piVar9;
          if (0xff7 < iVar10 + 0x10U) {
            piVar5 = (int *)FUN_0018add0(0x1000);
            if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
            *piVar5 = (int)piVar9;
            piVar5[1] = 0;
            param_3[0x45b] = piVar5;
            iVar10 = 0;
          }
          piVar5[1] = iVar10 + 0x10;
          local_1c = (int)piVar5 + iVar10 + 8;
          *(undefined4 *)((int)piVar5 + iVar10 + 0xc) = 0x1010104;
          *(undefined ***)((int)piVar5 + iVar10 + 8) = &PTR_FUN_0024af18;
          *(int *)((int)piVar5 + iVar10 + 0x10) = iVar6;
        }
        *(char *)((int)param_3 + 0x169) = cVar2;
        *(undefined *)(param_3 + 0x5a) = uVar1;
      }
    }
    break;
  case 100:
    if (uVar11 < 2) {
      return 0;
    }
    switch(puVar3[1]) {
    case 0x56:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator/=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x61:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator delete[]";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x65:
switchD_0020bfc0_caseD_6c:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) {
LAB_0020d3c8:
                    /* WARNING: Subroutine does not return */
          FUN_001f9d40();
        }
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator*";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x6c:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator delete";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x76:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator/";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x65:
    if (1 < uVar11) {
      cVar2 = puVar3[1];
      if (cVar2 == 'O') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator^=";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
      else if (cVar2 == 'q') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator==";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
      else if (cVar2 == 'o') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator^";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
    }
    break;
  case 0x67:
    if (1 < uVar11) {
      if (puVar3[1] == 't') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator>";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
      else if (puVar3[1] == 'e') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator>=";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
    }
    break;
  case 0x69:
    if ((1 < uVar11) && (puVar3[1] == 'x')) {
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator[]";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x6c:
    if (uVar11 < 2) {
      return 0;
    }
    switch(puVar3[1]) {
    case 0x53:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator<<=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x65:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator<=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x69:
      *param_3 = puVar3 + 2;
      iVar6 = FUN_0020b6a0();
      if (iVar6 == 0) {
        return 0;
      }
      ppiVar4 = (int **)param_3[0x45b];
      piVar9 = ppiVar4[1];
      ppiVar7 = ppiVar4;
      if ((int *)0xff7 < piVar9 + 4) {
        ppiVar7 = (int **)FUN_0018add0(0x1000);
        if (ppiVar7 == (int **)0x0) goto LAB_0020d3c8;
        *ppiVar7 = (int *)ppiVar4;
        ppiVar7[1] = (int *)0x0;
        param_3[0x45b] = ppiVar7;
        piVar9 = (int *)0x0;
      }
      ppiVar7[1] = piVar9 + 4;
      local_1c = (int)(ppiVar7 + 2) + (int)piVar9;
      *(undefined4 *)((int)(ppiVar7 + 3) + (int)piVar9) = 0x1010113;
      ppuVar8 = &PTR_FUN_0024af50;
      goto LAB_0020cd16;
    case 0x73:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator<<";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x74:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator<";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x6d:
    if (uVar11 < 2) {
      return 0;
    }
    switch(puVar3[1]) {
    case 0x49:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator-=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x4c:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator*=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x69:
switchD_0020c2e7_caseD_67:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator-";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x6c:
      goto switchD_0020bfc0_caseD_6c;
    case 0x6d:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator--";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x6e:
    if (uVar11 < 2) {
      return 0;
    }
    switch(puVar3[1]) {
    case 0x61:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator new[]";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x65:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator!=";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x67:
      goto switchD_0020c2e7_caseD_67;
    case 0x74:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator!";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      break;
    case 0x77:
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator new";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x6f:
    if (1 < uVar11) {
      cVar2 = puVar3[1];
      if (cVar2 == 'R') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator|=";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
      else if (cVar2 == 'r') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator|";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
      else if (cVar2 == 'o') {
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator||";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
    }
    break;
  case 0x70:
    if (1 < uVar11) {
      switch(puVar3[1]) {
      case 0x4c:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator+=";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x6c:
      case 0x73:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator+";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x6d:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator->*";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x70:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator++";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x74:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator->";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
    }
    break;
  case 0x71:
    if ((1 < uVar11) && (puVar3[1] == 'u')) {
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator?";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x72:
    if (1 < uVar11) {
      switch(puVar3[1]) {
      case 0x4d:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator%=";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x53:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator>>=";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x6d:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator%";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
        break;
      case 0x73:
        *param_3 = puVar3 + 2;
        piVar9 = (int *)param_3[0x45b];
        iVar6 = piVar9[1];
        piVar5 = piVar9;
        if (0xff7 < iVar6 + 0x10U) {
          piVar5 = (int *)FUN_0018add0(0x1000);
          if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
          *piVar5 = (int)piVar9;
          piVar5[1] = 0;
          param_3[0x45b] = piVar5;
          iVar6 = 0;
        }
        piVar5[1] = iVar6 + 0x10;
        local_1c = (int)piVar5 + iVar6 + 8;
        *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
        *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
        *(char **)((int)piVar5 + iVar6 + 0x10) = "operator>>";
        *(char **)((int)piVar5 + iVar6 + 0x14) = "";
      }
    }
    break;
  case 0x73:
    if ((1 < uVar11) && (puVar3[1] == 's')) {
      *param_3 = puVar3 + 2;
      piVar9 = (int *)param_3[0x45b];
      iVar6 = piVar9[1];
      piVar5 = piVar9;
      if (0xff7 < iVar6 + 0x10U) {
        piVar5 = (int *)FUN_0018add0(0x1000);
        if (piVar5 == (int *)0x0) goto LAB_0020d3c8;
        *piVar5 = (int)piVar9;
        piVar5[1] = 0;
        param_3[0x45b] = piVar5;
        iVar6 = 0;
      }
      piVar5[1] = iVar6 + 0x10;
      local_1c = (int)piVar5 + iVar6 + 8;
      *(undefined4 *)((int)piVar5 + iVar6 + 0xc) = 0x1010107;
      *(undefined ***)((int)piVar5 + iVar6 + 8) = &PTR_FUN_0024aab8;
      *(char **)((int)piVar5 + iVar6 + 0x10) = "operator<=>";
      *(char **)((int)piVar5 + iVar6 + 0x14) = "";
    }
    break;
  case 0x76:
    if (uVar11 < 2) {
      return 0;
    }
    if (9 < (int)(char)puVar3[1] - 0x30U) {
      return 0;
    }
    *param_3 = puVar3 + 2;
    iVar6 = FUN_0020b6a0();
    if (iVar6 == 0) {
      return 0;
    }
    ppiVar4 = (int **)param_3[0x45b];
    piVar9 = ppiVar4[1];
    ppiVar7 = ppiVar4;
    if ((int *)0xff7 < piVar9 + 4) {
      ppiVar7 = (int **)FUN_0018add0(0x1000);
      if (ppiVar7 == (int **)0x0) goto LAB_0020d3c8;
      *ppiVar7 = (int *)ppiVar4;
      ppiVar7[1] = (int *)0x0;
      param_3[0x45b] = ppiVar7;
      piVar9 = (int *)0x0;
    }
    ppiVar7[1] = piVar9 + 4;
    local_1c = (int)(ppiVar7 + 2) + (int)piVar9;
    *(undefined4 *)((int)(ppiVar7 + 3) + (int)piVar9) = 0x1010104;
    ppuVar8 = &PTR_FUN_0024af18;
LAB_0020cd16:
    *(undefined ***)((int)(ppiVar7 + 2) + (int)piVar9) = ppuVar8;
    *(int *)((int)(ppiVar7 + 4) + (int)piVar9) = iVar6;
  }
  return local_1c;
}

