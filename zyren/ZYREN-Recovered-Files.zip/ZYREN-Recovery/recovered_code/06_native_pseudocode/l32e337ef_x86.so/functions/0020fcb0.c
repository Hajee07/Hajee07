/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020fcb0 FUN_0020fcb0 */

undefined FUN_0020fcb0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  uint uVar4;
  
  if (*(int *)(param_2 + 0x10) == -1) {
    iVar2 = *(int *)(param_1 + 0xc);
    *(int *)(param_2 + 0x10) = iVar2;
    *(undefined4 *)(param_2 + 0xc) = 0;
    uVar4 = 0;
    if (iVar2 == 0) {
      return 0;
    }
  }
  else {
    uVar4 = *(uint *)(param_2 + 0xc);
    if (*(uint *)(param_1 + 0xc) <= uVar4) {
      return 0;
    }
  }
  piVar1 = *(int **)(*(int *)(param_1 + 8) + uVar4 * 4);
  if (*(char *)((int)piVar1 + 6) == '\x02') {
    uVar3 = (**(code **)(*piVar1 + 4))(piVar1,param_2);
  }
  else {
    uVar3 = *(char *)((int)piVar1 + 6) == '\0';
  }
  return uVar3;
}

