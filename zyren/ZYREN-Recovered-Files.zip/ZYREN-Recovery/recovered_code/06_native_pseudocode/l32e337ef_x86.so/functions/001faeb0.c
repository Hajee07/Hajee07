/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001faeb0 FUN_001faeb0 */

int FUN_001faeb0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0018b0f0(param_1,param_2);
  if (iVar1 == 0) {
    iVar1 = FUN_001fadb0();
    if (iVar1 == 0) {
      iVar1 = 0;
    }
    else {
      FUN_0018ae30(iVar1,0,param_2 * param_1);
    }
  }
  return iVar1;
}

