/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b70d0 FUN_001b70d0 */

undefined4 FUN_001b70d0(int param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  
  uVar1 = FUN_0018af10(param_2);
  uVar2 = FUN_0018af10(param_1);
  if ((uVar1 <= uVar2) && (iVar3 = FUN_0018b060(param_1 + (uVar2 - uVar1),param_2), iVar3 == 0)) {
    return 1;
  }
  return 0;
}

