/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b61f0 FUN_001b61f0 */

bool FUN_001b61f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  FUN_0018adf0(param_1);
  iVar1 = FUN_001b5c90(*(undefined4 *)(param_1 + 8),param_2,param_3,param_4);
  FUN_0018ae00(param_1);
  return iVar1 != 0;
}

