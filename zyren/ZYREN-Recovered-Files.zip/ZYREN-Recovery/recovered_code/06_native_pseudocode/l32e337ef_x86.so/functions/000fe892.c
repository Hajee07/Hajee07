/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000fe892 FUN_000fe892 */

void FUN_000fe892(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x000fe892. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x18))();
  return;
}

