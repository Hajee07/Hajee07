/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ed930 FUN_001ed930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_001ed930(undefined4 param_1,undefined4 param_2)

{
  uint local_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined local_10;
  
  if (DAT_00276db4 == (code *)0x0) {
    local_3c = _DAT_0021b750;
    uStack_38 = _UNK_0021b754;
    uStack_34 = _UNK_0021b758;
    uStack_30 = _UNK_0021b75c;
    local_2c = _DAT_0021b780;
    uStack_28 = _UNK_0021b784;
    uStack_24 = _UNK_0021b788;
    uStack_20 = _UNK_0021b78c;
    local_1c = 0x66d795d;
    local_18 = 0x202e2a60;
    local_14 = 0x32262129;
    local_40 = 0;
    do {
      *(byte *)((int)&local_3c + local_40) =
           (char)local_40 + 0x1bU ^ *(byte *)((int)&local_3c + local_40);
      local_40 = local_40 + 1;
    } while (local_40 < 0x2c);
    local_10 = 0;
    DAT_00276db4 = (code *)FUN_001ee050(&local_3c,0);
    if (DAT_00276db4 == (code *)0x0) {
      return;
    }
  }
  (*DAT_00276db4)(param_1,param_2);
  return;
}

