/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f3140 FUN_001f3140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_001f3140(int param_1,int param_2,int *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int local_1030;
  int local_102c;
  int local_1028;
  code *local_1024;
  int local_1020;
  undefined8 local_101c;
  undefined local_1014 [4100];
  
  local_101c = _PTR_FUN_0024a0a0;
  iVar2 = FUN_001f3630();
  if (DAT_00276de0 == '\0') {
    FUN_0018adf0(&DAT_00276ddc);
    if (DAT_00276de0 == '\0') {
      iVar3 = FUN_001f0c10("/system/lib/liblzma.so",1);
      if (iVar3 != 0) {
        local_1020 = iVar2;
        pcVar4 = (code *)FUN_001f0dd0(iVar3,"CrcGenerateTable",0);
        if ((((pcVar4 != (code *)0x0) &&
             (local_1024 = (code *)FUN_001f0dd0(iVar3,"Crc64GenerateTable",0),
             local_1024 != (code *)0x0)) &&
            (DAT_00276de8 = (code *)FUN_001f0dd0(iVar3,"XzUnpacker_Construct",0),
            DAT_00276de8 != (code *)0x0)) &&
           (((DAT_00276df0 = (code *)FUN_001f0dd0(iVar3,"XzUnpacker_IsStreamWasFinished",0),
             DAT_00276df0 != (code *)0x0 &&
             (DAT_00276dec = (code *)FUN_001f0dd0(iVar3,"XzUnpacker_Free",0),
             DAT_00276dec != (code *)0x0)) &&
            (DAT_00276de4 = (code *)FUN_001f0dd0(iVar3,"XzUnpacker_Code",0),
            DAT_00276de4 != (code *)0x0)))) {
          (*pcVar4)();
          (*local_1024)();
        }
        FUN_001f0d70(iVar3);
        iVar2 = local_1020;
      }
      DAT_00276de0 = '\x01';
    }
    FUN_0018ae00(&DAT_00276ddc);
  }
  if (DAT_00276de4 == (code *)0x0) {
    return 0xffffffff;
  }
  (*DAT_00276de8)(local_1014,&local_101c);
  *param_4 = param_2 * 2;
  *param_3 = 0;
  *param_4 = param_2 * 4;
  iVar3 = FUN_0018add0(param_2 * 4);
  *param_3 = iVar3;
  if (iVar2 < 0x1d) {
    if (iVar3 != 0) {
      iVar2 = 0;
      iVar5 = 0;
      do {
        local_102c = param_2 - iVar2;
        local_1030 = *param_4 - iVar5;
        iVar3 = (*DAT_00276de4)(local_1014,iVar3 + iVar5,&local_1030,param_1 + iVar2,&local_102c,0,
                                &local_1028);
        if (iVar3 != 0) goto LAB_001f3462;
        iVar5 = iVar5 + local_1030;
        if (local_1028 != 2) goto LAB_001f3494;
        iVar2 = iVar2 + local_102c;
        iVar3 = *param_4;
        iVar1 = *param_3;
        *param_4 = iVar3 * 2;
        iVar3 = FUN_0018b200(iVar1,iVar3 * 2);
        *param_3 = iVar3;
      } while (iVar3 != 0);
    }
  }
  else if (iVar3 != 0) {
    iVar2 = 0;
    iVar5 = 0;
    do {
      local_102c = param_2 - iVar2;
      local_1030 = *param_4 - iVar5;
      iVar3 = (*DAT_00276de4)(local_1014,iVar3 + iVar5,&local_1030,param_1 + iVar2,&local_102c,1,0,
                              &local_1028);
      if (iVar3 != 0) goto LAB_001f3462;
      iVar5 = iVar5 + local_1030;
      if (local_1028 != 2) {
LAB_001f3494:
        (*DAT_00276dec)(local_1014);
        iVar2 = (*DAT_00276df0)(local_1014);
        if (iVar2 == 0) {
          FUN_0018ae20(*param_3);
          return 0xffffffff;
        }
        *param_4 = iVar5;
        iVar2 = FUN_0018b200(*param_3,iVar5);
        *param_3 = iVar2;
        return 0;
      }
      iVar2 = iVar2 + local_102c;
      iVar3 = *param_4;
      iVar1 = *param_3;
      *param_4 = iVar3 * 2;
      iVar3 = FUN_0018b200(iVar1,iVar3 * 2);
      *param_3 = iVar3;
    } while (iVar3 != 0);
  }
LAB_001f3476:
  (*DAT_00276dec)(local_1014);
  return 0xffffffff;
LAB_001f3462:
  FUN_0018ae20(*param_3);
  goto LAB_001f3476;
}

