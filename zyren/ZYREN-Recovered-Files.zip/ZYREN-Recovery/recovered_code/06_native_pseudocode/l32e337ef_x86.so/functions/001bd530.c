/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bd530 FUN_001bd530 */

undefined4 FUN_001bd530(undefined4 param_1,int param_2)

{
  int iVar1;
  ushort *puVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  iVar1 = *(int *)(param_2 + 8);
  puVar2 = *(ushort **)(param_2 + 0x28);
  uVar5 = (uint)(*puVar2 >> 8);
  iVar3 = *(int *)(puVar2 + 1);
  iVar4 = *(int *)(iVar1 + uVar5 * 0xc);
  uVar6 = 0;
  switch(iVar4) {
  case 1:
  case 2:
    uVar6 = (uint)*(char *)(iVar1 + 4 + uVar5 * 0xc);
    break;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    break;
  case 4:
    uVar6 = (uint)*(ushort *)(iVar1 + 4 + uVar5 * 0xc);
    break;
  case 8:
    uVar6 = (uint)*(short *)(iVar1 + 4 + uVar5 * 0xc);
    break;
  default:
    if (iVar4 != 0x1000) break;
  case 0x10:
    uVar6 = *(uint *)(iVar1 + 4 + uVar5 * 0xc);
  }
  iVar1 = *(int *)(puVar2 + iVar3 + 2);
  if ((iVar1 <= (int)uVar6) && ((int)uVar6 < iVar1 + (short)puVar2[iVar3 + 1])) {
    *(undefined *)(param_2 + 0x30) = 1;
    *(ushort **)(param_2 + 0x28) = puVar2 + *(int *)(puVar2 + iVar3 + (uVar6 - iVar1) * 2 + 4);
  }
  return 0;
}

