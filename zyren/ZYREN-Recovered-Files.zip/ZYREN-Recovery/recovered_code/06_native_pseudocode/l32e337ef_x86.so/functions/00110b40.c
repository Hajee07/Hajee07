/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110b40 FUN_00110b40 */

undefined8 FUN_00110b40(char *param_1)

{
  char local_15;
  uint local_14;
  uint local_10;
  char *local_c;
  
  local_10 = 0;
  local_14 = 0;
  for (local_c = param_1; *local_c != '\0'; local_c = local_c + 1) {
    local_15 = *local_c;
    if ((local_15 < 'a') || ('f' < local_15)) {
      if ((local_15 < 'A') || ('F' < local_15)) {
        if ((local_15 < '0') || ('9' < local_15)) break;
        local_15 = local_15 + -0x30;
      }
      else {
        local_15 = local_15 + -0x37;
      }
    }
    else {
      local_15 = local_15 + -0x57;
    }
    local_10 = local_10 << 4 | local_14 >> 0x1c | (int)local_15 >> 0x1f;
    local_14 = local_14 << 4 | (int)local_15;
  }
  return CONCAT44(local_10,local_14);
}

