/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c7d10 FUN_001c7d10 */

int FUN_001c7d10(int *param_1,uint param_2)

{
  int iVar1;
  
  iVar1 = 0;
  if ((7 < param_2) && (*param_1 == -0x13cf5bc9)) {
    iVar1 = param_1[1];
  }
  return iVar1;
}

