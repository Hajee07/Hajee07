/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019ab20 FUN_0019ab20 */

void FUN_0019ab20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  if (*(code **)PTR_DAT_0024bb5c != (code *)0x0) {
    (**(code **)PTR_DAT_0024bb5c)(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_0018b010(param_1,param_2,param_3,param_4);
  return;
}

