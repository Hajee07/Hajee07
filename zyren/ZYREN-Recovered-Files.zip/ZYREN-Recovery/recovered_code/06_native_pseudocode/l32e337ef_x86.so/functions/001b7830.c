/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b7830 FUN_001b7830 */

uint __regparm1 FUN_001b7830(undefined4 param_1_00,undefined4 param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar2 = *param_2;
  if ((uVar2 & 0x3000) != 0) {
    uVar2 = *param_3;
  }
  uVar1 = 0;
  if ((int)uVar2 < 0x80) {
    switch(uVar2) {
    case 1:
    case 2:
      uVar2 = 0;
      bVar3 = *(char *)(param_2 + 1) == *(char *)(param_3 + 1);
      break;
    default:
      goto switchD_001b7867_caseD_3;
    case 4:
    case 8:
      uVar2 = (uint)*(ushort *)(param_2 + 1);
      bVar3 = *(ushort *)(param_2 + 1) == *(ushort *)(param_3 + 1);
      break;
    case 0x10:
      goto switchD_001b7867_caseD_10;
    case 0x20:
switchD_001b7867_caseD_20:
      uVar2 = param_2[1] ^ param_3[1] | param_2[2] ^ param_3[2];
      bVar3 = uVar2 == 0;
      break;
    case 0x40:
      bVar3 = (float)param_3[1] == (float)param_2[1];
LAB_001b78fc:
      return -(uint)bVar3 & 1;
    }
  }
  else {
    if ((int)uVar2 < 0x1000) {
      if (uVar2 != 0x80) {
        if (uVar2 != 0x100) {
          return 0;
        }
LAB_001b78a3:
        uVar2 = FUN_001b75a0(param_1,param_2[1],param_3[1],0x1b7838,param_1_00);
        return uVar2;
      }
      bVar3 = *(double *)(param_3 + 1) == *(double *)(param_2 + 1);
      goto LAB_001b78fc;
    }
    if (uVar2 != 0x1000) {
      if (uVar2 != 0x2000) {
        if (uVar2 != 0x4000) {
          return 0;
        }
        goto LAB_001b78a3;
      }
      goto switchD_001b7867_caseD_20;
    }
switchD_001b7867_caseD_10:
    uVar2 = param_2[1];
    bVar3 = uVar2 == param_3[1];
  }
  uVar1 = CONCAT31((int3)(uVar2 >> 8),bVar3);
switchD_001b7867_caseD_3:
  return uVar1;
}

