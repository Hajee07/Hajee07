/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001cdcf0 FUN_001cdcf0 */

uint FUN_001cdcf0(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  undefined local_2814 [2048];
  undefined4 local_2014;
  undefined local_2010 [8192];
  
  FUN_0018ae30(local_2010,0,0x2000,0x1cdcff);
  local_2014 = 0xb00000b;
  uVar1 = FUN_001cc120(&local_2014,param_3,param_4,local_2814,0x800);
  uVar2 = uVar1;
  if ((uVar1 < 0xffffff89) && (uVar2 = 0xffffffb8, uVar1 < param_4)) {
    uVar2 = FUN_001cc7f0(param_3 + uVar1,param_4 - uVar1,&local_2014);
  }
  return uVar2;
}

