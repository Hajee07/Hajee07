/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a27c0 FUN_001a27c0 */

undefined4 FUN_001a27c0(int param_1)

{
  undefined *puVar1;
  undefined *puVar2;
  undefined4 uVar3;
  
  uVar3 = (**(code **)PTR_DAT_0024bc00)(param_1);
  puVar2 = PTR_DAT_0024bbf0;
  FUN_001f4b70(PTR_DAT_0024bbf0);
  for (puVar1 = *(undefined **)(PTR_DAT_0024bbf4 + 4); puVar1 != PTR_DAT_0024bbf4;
      puVar1 = *(undefined **)(puVar1 + 4)) {
    if (*(int *)(puVar1 + 0xc) == param_1) {
      uVar3 = *(undefined4 *)(puVar1 + 0x28);
    }
  }
  FUN_001f4bf0(puVar2);
  return uVar3;
}

