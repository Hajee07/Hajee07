/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a2410 FUN_001a2410 */

int FUN_001a2410(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint *puVar1;
  uint *puVar2;
  undefined *puVar3;
  int iVar4;
  int iVar5;
  byte *pbVar6;
  uint uVar7;
  undefined *puVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  undefined *puVar17;
  uint local_30;
  
  iVar4 = (**(code **)PTR_DAT_0024bbec)(param_1,param_2,param_3);
  iVar5 = FUN_0018af10(param_2);
  pbVar6 = (byte *)FUN_0018add0(iVar5 + 8);
  FUN_0018ae30(pbVar6,0,iVar5 + 8);
  FUN_0018b030(pbVar6,"assets/%s",param_2);
  puVar17 = PTR_DAT_0024bb14;
  if (*pbVar6 != 0) {
    uVar7 = 0;
    uVar13 = 0;
    local_30 = 0;
    uVar15 = (uint)*pbVar6;
    do {
      uVar12 = local_30 << 7 | uVar13 >> 0x19;
      uVar16 = local_30 << 0x1d | uVar13 >> 3;
      uVar14 = local_30 >> 3;
      uVar15 = uVar13 << 7 ^ uVar15;
      while( true ) {
        uVar13 = uVar13 ^ uVar16 ^ uVar15;
        local_30 = local_30 ^ uVar14 ^ uVar12;
        iVar5 = uVar7 + 1;
        uVar7 = uVar7 + 1;
        if (pbVar6[iVar5] == 0) goto LAB_001a2524;
        uVar15 = (uint)pbVar6[iVar5];
        if ((uVar7 & 1) == 0) break;
        uVar12 = local_30 << 0xb | uVar13 >> 0x15;
        uVar15 = uVar13 << 0xb | uVar15;
        uVar16 = ~(local_30 << 0x1b | uVar13 >> 5);
        uVar14 = ~(local_30 >> 5);
      }
    } while( true );
  }
  uVar13 = 0;
  local_30 = 0;
LAB_001a2524:
  if (iVar4 == 0) goto LAB_001a26eb;
  FUN_001f4b70(PTR_DAT_0024bb14);
  for (puVar8 = *(undefined **)(PTR_DAT_0024bb18 + 4); puVar8 != PTR_DAT_0024bb18;
      puVar8 = *(undefined **)(puVar8 + 4)) {
    if ((*(uint *)(puVar8 + 0xc) ^ local_30 | *(uint *)(puVar8 + 8) ^ uVar13) == 0) {
      FUN_001f4bf0(PTR_DAT_0024bb14);
      puVar17 = PTR_DAT_0024bbf0;
      FUN_001f4b70(PTR_DAT_0024bbf0);
      puVar3 = PTR_DAT_0024bbf4;
      puVar8 = *(undefined **)(PTR_DAT_0024bbf4 + 4);
      if (puVar8 == PTR_DAT_0024bbf4) goto LAB_001a25e9;
      goto LAB_001a25c0;
    }
  }
  goto LAB_001a26e3;
  while (puVar8 = *(undefined **)(puVar8 + 4), puVar8 != PTR_DAT_0024bbf4) {
LAB_001a25c0:
    puVar1 = (uint *)(puVar8 + 0x14);
    puVar2 = (uint *)(puVar8 + 0x10);
    if ((*puVar2 ^ uVar13 | *puVar1 ^ local_30) == 0) goto LAB_001a26e3;
  }
  if ((*puVar2 ^ uVar13 | *puVar1 ^ local_30) != 0) {
LAB_001a25e9:
    iVar5 = FUN_0018af40(pbVar6);
    iVar9 = FUN_0018af70(iVar4);
    iVar10 = FUN_0018add0(iVar9);
    FUN_0018ae30(iVar10,0,iVar9);
    FUN_0018b080(iVar4,0,0);
    (**(code **)PTR_DAT_0024bbf8)(iVar4,iVar10,iVar9);
    FUN_0018b080(iVar4,0,0);
    piVar11 = (int *)FUN_001f5520(0x2c);
    piVar11[2] = iVar5;
    piVar11[3] = iVar4;
    piVar11[5] = local_30;
    piVar11[4] = uVar13;
    piVar11[7] = iVar9 >> 0x1f;
    piVar11[6] = iVar9;
    piVar11[9] = 0;
    piVar11[8] = 0;
    piVar11[10] = iVar10;
    piVar11[1] = (int)puVar3;
    iVar5 = *(int *)puVar3;
    *piVar11 = iVar5;
    *(int **)(iVar5 + 4) = piVar11;
    *(int **)puVar3 = piVar11;
    *(int *)(puVar3 + 8) = *(int *)(puVar3 + 8) + 1;
  }
LAB_001a26e3:
  FUN_001f4bf0(puVar17);
LAB_001a26eb:
  FUN_0018ae20(pbVar6);
  return iVar4;
}

