/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d6510 FUN_001d6510 */

undefined4 FUN_001d6510(undefined4 param_1,int param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  
  uVar5 = 0x1d651c;
  uVar3 = *param_3;
  uVar4 = param_3[1];
  uVar1 = uVar3 + param_2;
  if (uVar4 < uVar1) {
    if (param_3[3] == 0) {
      return 0;
    }
    do {
      uVar4 = uVar4 * 2;
      if (uVar4 < 0x81) {
        uVar4 = 0x80;
      }
    } while (uVar4 < uVar1);
    uVar2 = FUN_0018b200(param_3[2],uVar4);
    if (uVar2 == 0) {
      return 0;
    }
    param_3[2] = uVar2;
    param_3[1] = uVar4;
    uVar3 = *param_3;
  }
  else {
    uVar2 = param_3[2];
  }
  FUN_0018ae80(uVar3 + uVar2,param_1,param_2,uVar5);
  *param_3 = uVar1;
  return 1;
}

