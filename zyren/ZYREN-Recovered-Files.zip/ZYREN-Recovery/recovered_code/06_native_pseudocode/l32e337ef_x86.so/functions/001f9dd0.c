/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9dd0 FUN_001f9dd0 */

undefined4 FUN_001f9dd0(void)

{
  FUN_001f9da0(*(undefined4 *)PTR_PTR_FUN_0024bda8);
  return *(undefined4 *)PTR_PTR_FUN_0024bdac;
}

