/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001dd850 FUN_001dd850 */

undefined4 FUN_001dd850(int param_1,uint param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  
  uVar5 = 0x1dd85c;
  uVar1 = FUN_0018b0e0(*(undefined4 *)(*(int *)(param_1 + 0x48) + 0x3c));
  iVar2 = *(int *)(param_1 + 0x48);
  uVar3 = *(uint *)(iVar2 + 0x40) + param_2;
  uVar4 = *(int *)(iVar2 + 0x44) + param_3 + (uint)CARRY4(*(uint *)(iVar2 + 0x40),param_2);
  if ((int)uVar4 < 0) {
LAB_001dd8ad:
    *(undefined4 *)(param_1 + 0x1c) = 0x16;
    uVar5 = 0;
  }
  else {
    if ((uVar4 ^ (int)uVar1 >> 0x1f | uVar3 ^ uVar1) != 0) {
      iVar2 = FUN_0018b0d0(*(undefined4 *)(iVar2 + 0x3c),uVar3,0,uVar5);
      if (iVar2 != 0) goto LAB_001dd8ad;
      iVar2 = *(int *)(param_1 + 0x48);
    }
    uVar5 = FUN_0018b140(param_4,1,param_5,*(undefined4 *)(iVar2 + 0x3c));
  }
  return uVar5;
}

