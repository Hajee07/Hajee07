/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ecbd0 FUN_001ecbd0 */

void FUN_001ecbd0(byte *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  byte *pbVar4;
  int iVar5;
  undefined4 uVar6;
  byte *pbVar7;
  
  piVar3 = (int *)FUN_001eba70();
  pbVar7 = param_1 + 1;
  pbVar4 = pbVar7;
  if ((*param_1 & 1) != 0) {
    pbVar4 = *(byte **)(param_1 + 8);
  }
  iVar5 = (**(code **)(*piVar3 + 0x18))(piVar3,pbVar4);
  if (iVar5 == 0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
    uVar2 = DAT_00276dac;
    uVar1 = *DAT_00276da8;
    if ((*param_1 & 1) != 0) {
      pbVar7 = *(byte **)(param_1 + 8);
    }
    uVar6 = (**(code **)(*piVar3 + 0x29c))(piVar3,pbVar7);
    FUN_001a64f0(piVar3,uVar1,uVar2,uVar6);
  }
  return;
}

