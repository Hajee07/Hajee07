/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c51b0 FUN_001c51b0 */

uint FUN_001c51b0(int param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  bool bVar8;
  
  uVar5 = 0xffffffec;
  if (param_3 < 3) {
    return 0xffffffec;
  }
  bVar1 = *(byte *)param_2;
  bVar3 = bVar1 & 3;
  switch(bVar3) {
  case 0:
    bVar3 = bVar1 >> 2 & 3;
    if (bVar3 == 1) {
      uVar2 = (uint)(*(ushort *)param_2 >> 4);
      iVar7 = 2;
      uVar5 = uVar2 + 2;
      uVar4 = uVar2 + 10;
    }
    else if (bVar3 == 3) {
      uVar2 = (uint)(*(uint3 *)param_2 >> 4);
      iVar7 = 3;
      uVar5 = uVar2 + 3;
      uVar4 = uVar2 + 0xb;
    }
    else {
      uVar2 = (uint)(bVar1 >> 3);
      iVar7 = 1;
      uVar5 = uVar2 + 1;
      uVar4 = uVar2 + 9;
    }
    if (uVar4 <= param_3) {
      *(byte **)(param_1 + 0x5ccc) = (byte *)((int)param_2 + iVar7);
      *(uint *)(param_1 + 0x5cdc) = uVar2;
      return uVar5;
    }
    if (param_3 < uVar5) {
      return 0xffffffec;
    }
    FUN_0018ae80(param_1 + 0x5d2c,(byte *)((int)param_2 + iVar7),uVar2);
    *(int *)(param_1 + 0x5ccc) = param_1 + 0x5d2c;
    *(uint *)(param_1 + 0x5cdc) = uVar2;
    *(undefined4 *)(param_1 + 0x5d30 + uVar2) = 0;
    *(undefined4 *)(param_1 + 0x5d2c + uVar2) = 0;
    return uVar5;
  case 3:
    if (*(int *)(param_1 + 0x5c68) == 0) {
      return 0xffffffe2;
    }
  case 2:
    if (4 < param_3) {
      bVar1 = bVar1 >> 2 & 3;
      uVar4 = *param_2;
      if (bVar1 == 2) {
        uVar6 = uVar4 >> 4 & 0x3fff;
        uVar4 = uVar4 >> 0x12;
        bVar8 = false;
        iVar7 = 4;
        uVar2 = uVar4 + 4;
      }
      else if (bVar1 == 3) {
        uVar6 = uVar4 >> 4 & 0x3ffff;
        if (0x20000 < uVar6) {
          return 0xffffffec;
        }
        uVar4 = uVar4 >> 0x16 | (uint)*(byte *)(param_2 + 1) << 10;
        bVar8 = false;
        iVar7 = 5;
        uVar2 = uVar4 + 5;
      }
      else {
        bVar8 = bVar1 == 0;
        uVar6 = uVar4 >> 4 & 0x3ff;
        uVar4 = uVar4 >> 0xe & 0x3ff;
        iVar7 = 3;
        uVar2 = uVar4 + 3;
      }
      if (uVar2 <= param_3) {
        if (bVar3 == 3) {
          if (bVar8) {
            uVar4 = FUN_001d0470(param_1 + 0x5d2c,uVar6,(byte *)((int)param_2 + iVar7),uVar4,
                                 *(undefined4 *)(param_1 + 0xc));
          }
          else {
            uVar4 = FUN_001d04c0(param_1 + 0x5d2c,uVar6,(byte *)((int)param_2 + iVar7),uVar4,
                                 *(undefined4 *)(param_1 + 0xc));
          }
        }
        else if (bVar8) {
          uVar4 = FUN_001cc5f0(param_1 + 0x141c,param_1 + 0x5d2c,uVar6,
                               (byte *)((int)param_2 + iVar7),uVar4,param_1 + 0x5420,0x800);
        }
        else {
          uVar4 = FUN_001d0800(param_1 + 0x141c,param_1 + 0x5d2c,uVar6,
                               (byte *)((int)param_2 + iVar7),uVar4,param_1 + 0x5420,0x800);
        }
        if (uVar4 < 0xffffff89) {
          *(int *)(param_1 + 0x5ccc) = param_1 + 0x5d2c;
          *(uint *)(param_1 + 0x5cdc) = uVar6;
          *(undefined4 *)(param_1 + 0x5c68) = 1;
          if (bVar3 == 2) {
            *(int *)(param_1 + 0xc) = param_1 + 0x141c;
          }
          *(undefined4 *)(param_1 + 0x5d30 + uVar6) = 0;
          *(undefined4 *)(param_1 + 0x5d2c + uVar6) = 0;
          uVar5 = uVar2;
        }
      }
    }
    return uVar5;
  }
  bVar3 = bVar1 >> 2 & 3;
  if (bVar3 == 1) {
    uVar5 = (uint)(*(ushort *)param_2 >> 4);
    iVar7 = 2;
  }
  else if (bVar3 == 3) {
    if (param_3 < 4) {
      return 0xffffffec;
    }
    if (0x20000f < *(uint3 *)param_2) {
      return 0xffffffec;
    }
    uVar5 = (uint)(*(uint3 *)param_2 >> 4);
    iVar7 = 3;
  }
  else {
    uVar5 = (uint)(bVar1 >> 3);
    iVar7 = 1;
  }
  FUN_0018ae30(param_1 + 0x5d2c,*(byte *)((int)param_2 + iVar7),uVar5 + 8);
  *(int *)(param_1 + 0x5ccc) = param_1 + 0x5d2c;
  *(uint *)(param_1 + 0x5cdc) = uVar5;
  return iVar7 + 1;
}

