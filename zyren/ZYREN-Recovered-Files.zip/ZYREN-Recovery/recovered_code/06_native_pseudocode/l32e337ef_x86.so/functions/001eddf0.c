/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001eddf0 FUN_001eddf0 */

void FUN_001eddf0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = 0x1eddfc;
  iVar2 = FUN_001ed860(*(undefined4 *)(param_1 + 4),param_2);
  if (iVar2 != 0) {
    cVar1 = (**(code **)(**(int **)(param_1 + 4) + 0x80))
                      (*(int **)(param_1 + 4),iVar2,*(undefined4 *)(param_1 + 8),uVar3);
    if (cVar1 != '\0') {
      FUN_001ef900(*(undefined4 *)(param_1 + 4),iVar2,param_2);
    }
    FUN_001ed930(*(undefined4 *)(param_1 + 4),iVar2);
  }
  return;
}

