/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020e730 FUN_0020e730 */

void FUN_0020e730(int param_1,int *param_2)

{
  uint uVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = param_2[1];
  uVar1 = iVar5 + 1;
  if (uVar1 < (uint)param_2[2]) {
    iVar4 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar4 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar4;
    if (iVar4 == 0) goto LAB_0020e8c3;
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar4 + iVar5) = 0x28;
  param_2[1] = param_2[1] + 1;
  piVar2 = *(int **)(param_1 + 8);
  (**(code **)(*piVar2 + 0x10))(piVar2,param_2);
  if (*(char *)((int)piVar2 + 5) != '\x01') {
    (**(code **)(*piVar2 + 0x14))(piVar2,param_2);
  }
  iVar5 = param_2[1];
  uVar1 = iVar5 + 5;
  if (uVar1 < (uint)param_2[2]) {
    iVar4 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar4 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar4;
    if (iVar4 == 0) goto LAB_0020e8c3;
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar4 + 4 + iVar5) = 0x28;
  *(undefined4 *)(iVar4 + iVar5) = 0x203f2029;
  param_2[1] = param_2[1] + 5;
  piVar2 = *(int **)(param_1 + 0xc);
  (**(code **)(*piVar2 + 0x10))(piVar2,param_2);
  if (*(char *)((int)piVar2 + 5) != '\x01') {
    (**(code **)(*piVar2 + 0x14))(piVar2,param_2);
  }
  iVar5 = param_2[1];
  uVar1 = iVar5 + 5;
  if (uVar1 < (uint)param_2[2]) {
    iVar4 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar4 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar4;
    if (iVar4 == 0) goto LAB_0020e8c3;
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar4 + 4 + iVar5) = 0x28;
  *(undefined4 *)(iVar4 + iVar5) = 0x203a2029;
  param_2[1] = param_2[1] + 5;
  piVar2 = *(int **)(param_1 + 0x10);
  (**(code **)(*piVar2 + 0x10))(piVar2,param_2);
  if (*(char *)((int)piVar2 + 5) != '\x01') {
    (**(code **)(*piVar2 + 0x14))(piVar2,param_2);
  }
  iVar5 = param_2[1];
  uVar1 = iVar5 + 1;
  if (uVar1 < (uint)param_2[2]) {
    iVar4 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar4 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar4;
    if (iVar4 == 0) {
LAB_0020e8c3:
                    /* WARNING: Subroutine does not return */
      FUN_001f9d40();
    }
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar4 + iVar5) = 0x29;
  param_2[1] = param_2[1] + 1;
  return;
}

