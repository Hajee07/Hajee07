/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c4af0 FUN_001c4af0 */

int FUN_001c4af0(int param_1,uint param_2)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  
  iVar2 = -0x48;
  if (4 < param_2) {
    bVar1 = *(byte *)(param_1 + 4);
    uVar3 = (bVar1 & 0x20) >> 5;
    iVar2 = ((*(int *)(&DAT_0021b5e0 + (uint)(bVar1 >> 6) * 4) +
             *(int *)(&DAT_0021b5d0 + (bVar1 & 3) * 4)) - uVar3) + 6 +
            (uint)(bVar1 >> 6 == 0 & (byte)uVar3);
  }
  return iVar2;
}

