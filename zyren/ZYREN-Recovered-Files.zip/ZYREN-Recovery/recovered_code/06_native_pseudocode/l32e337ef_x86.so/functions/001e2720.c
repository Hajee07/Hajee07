/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e2720 FUN_001e2720 */

int FUN_001e2720(int param_1,int param_2,undefined4 param_3,undefined4 *param_4,uint param_5,
                undefined4 *param_6)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 local_60;
  undefined local_5c [16];
  undefined local_4c [8];
  int iStack_44;
  undefined4 uStack_40;
  undefined local_3c [12];
  code *pcStack_30;
  undefined local_2c [16];
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 *local_14;
  
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = 0;
  }
  if ((param_1 == 0) || (param_2 == 0)) {
    if (param_6 != (undefined4 *)0x0) {
      *param_6 = 0x18;
      return 0;
    }
    return 0;
  }
  local_2c = ZEXT816(0);
  _local_3c = ZEXT816(0);
  _local_4c = ZEXT816(0);
  local_5c = ZEXT816(0);
  local_18 = 0;
  local_1c = 0;
  local_14 = (undefined4 *)0x0;
  iVar2 = FUN_001d8640(local_5c,param_1,param_5 | 0x800,0,0,0,0,0x1e272c);
  if (iVar2 != 0) {
    iVar2 = FUN_001d9350(local_5c,param_2,param_3,param_5,&local_60);
    if (iVar2 == 0) {
      iVar2 = 0;
      puVar1 = local_14;
    }
    else {
      iVar2 = FUN_001da1a0(local_5c,local_60,param_4,param_5);
      puVar1 = local_14;
    }
    if ((((puVar1 == (undefined4 *)0x0) || (local_3c._8_4_ == 0)) || (pcStack_30 == (code *)0x0)) ||
       (local_4c._4_4_ != 1)) {
      if (iVar2 != 0) {
        uStack_40 = 0x18;
      }
    }
    else {
      local_14 = (undefined4 *)0x0;
      (*pcStack_30)(local_2c._4_4_,*puVar1);
      puVar1[1] = 0;
      *puVar1 = 0;
      puVar1[3] = 0;
      puVar1[2] = 0;
      (*pcStack_30)(local_2c._4_4_,puVar1[4]);
      puVar1[5] = 0;
      puVar1[4] = 0;
      puVar1[7] = 0;
      puVar1[6] = 0;
      (*pcStack_30)(local_2c._4_4_,puVar1[8]);
      puVar1[9] = 0;
      puVar1[8] = 0;
      puVar1[0xb] = 0;
      puVar1[10] = 0;
      if (puVar1[0xf] != 0) {
        if (((iStack_44 == 4) && (iVar3 = FUN_0018b120(puVar1[0xf]), iVar3 == -1)) && (iVar2 != 0))
        {
          uStack_40 = 0x15;
        }
        puVar1[0xf] = 0;
      }
      (*pcStack_30)(local_2c._4_4_,puVar1);
    }
    if (param_6 != (undefined4 *)0x0) {
      *param_6 = uStack_40;
    }
    return iVar2;
  }
  if (param_6 != (undefined4 *)0x0) {
    *param_6 = uStack_40;
    return 0;
  }
  return 0;
}

