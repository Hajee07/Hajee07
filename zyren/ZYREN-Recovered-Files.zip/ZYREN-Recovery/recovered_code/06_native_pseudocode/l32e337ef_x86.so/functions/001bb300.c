/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bb300 FUN_001bb300 */

undefined4 FUN_001bb300(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  uint uVar5;
  
  iVar1 = *(int *)(param_2 + 8);
  uVar3 = (uint)(**(ushort **)(param_2 + 0x28) >> 8);
  iVar2 = *(int *)(iVar1 + uVar3 * 0xc);
  switch(iVar2) {
  case 1:
  case 2:
    uVar5 = (uint)*(byte *)(iVar1 + 4 + uVar3 * 0xc);
    goto LAB_001bb3af;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2c:
  case 0x2d:
  case 0x2e:
  case 0x2f:
  case 0x30:
  case 0x31:
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x35:
  case 0x36:
  case 0x37:
  case 0x38:
  case 0x39:
  case 0x3a:
  case 0x3b:
  case 0x3c:
  case 0x3d:
  case 0x3e:
  case 0x3f:
switchD_001bb346_caseD_3:
    uVar5 = *(uint *)(iVar1 + 4 + uVar3 * 0xc);
    uVar4 = *(undefined4 *)(iVar1 + 8 + uVar3 * 0xc);
    break;
  case 4:
  case 8:
    uVar5 = (uint)*(ushort *)(iVar1 + 4 + uVar3 * 0xc);
LAB_001bb3af:
    *(uint *)(iVar1 + 4 + uVar3 * 0xc) = uVar5;
LAB_001bb3b5:
    uVar4 = 0;
    *(undefined4 *)(iVar1 + 8 + uVar3 * 0xc) = 0;
    break;
  case 0x10:
  case 0x40:
switchD_001bb346_caseD_10:
    uVar5 = *(uint *)(iVar1 + 4 + uVar3 * 0xc);
    goto LAB_001bb3b5;
  default:
    if (iVar2 < 0x800) {
      if (iVar2 == 0x100) goto switchD_001bb346_caseD_10;
      if ((iVar2 != 0x200) && (iVar2 != 0x400)) goto switchD_001bb346_caseD_3;
    }
    else if (iVar2 != 0x800) {
      if ((iVar2 == 0x1000) || (iVar2 == 0x4000)) goto switchD_001bb346_caseD_10;
      goto switchD_001bb346_caseD_3;
    }
  case 0:
    *(undefined4 *)(iVar1 + 8 + uVar3 * 0xc) = 0;
    *(undefined4 *)(iVar1 + 4 + uVar3 * 0xc) = 0;
    uVar5 = 0;
    uVar4 = 0;
  }
  *(uint *)(param_2 + 0x18) = uVar5;
  *(undefined4 *)(param_2 + 0x1c) = uVar4;
  iVar2 = *(int *)(iVar1 + uVar3 * 0xc);
  if ((iVar2 == 0x4000) || (iVar2 == 0x100)) {
    uVar4 = (**(code **)(*param_1 + 100))(param_1,*(undefined4 *)(iVar1 + 4 + uVar3 * 0xc));
    *(undefined4 *)(iVar1 + 4 + uVar3 * 0xc) = uVar4;
  }
  *(undefined *)(param_2 + 0x31) = 1;
  return 0;
}

