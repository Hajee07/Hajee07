/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5b10 FUN_001b5b10 */

int FUN_001b5b10(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = param_1 + -8;
    do {
      iVar2 = iVar1;
      iVar1 = *(int *)(iVar2 + 4);
    } while (iVar1 != 0);
    return iVar2 + 8;
  }
  return 0;
}

