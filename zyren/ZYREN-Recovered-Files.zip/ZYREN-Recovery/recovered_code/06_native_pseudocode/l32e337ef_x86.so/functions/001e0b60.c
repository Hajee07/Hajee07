/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e0b60 FUN_001e0b60 */

undefined4 FUN_001e0b60(uint *param_1,int param_2,uint param_3)

{
  short *psVar1;
  ushort uVar2;
  int *piVar3;
  int iVar4;
  ulonglong uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  int iVar23;
  uint uVar24;
  uint uVar25;
  bool bVar26;
  undefined8 *local_14ec;
  uint local_14e8;
  uint local_14e4;
  uint local_14e0;
  short *local_14dc;
  uint local_14d4;
  uint local_14d0;
  uint local_14c4;
  uint local_14c0;
  uint local_14b8;
  uint local_14b4;
  uint local_14b0;
  undefined8 local_14ac;
  undefined8 local_14a4;
  undefined8 local_149c;
  undefined8 local_1494;
  undefined6 uStack_148c;
  undefined2 local_1486;
  undefined2 uStack_1484;
  uint uStack_1482;
  int local_147c;
  byte local_1476;
  int local_146a;
  int local_1466;
  ushort local_1462;
  ushort local_1460;
  undefined local_145c [28];
  uint local_1440;
  int local_143c;
  undefined4 local_1438;
  undefined4 local_1434;
  uint local_1428;
  int local_1424;
  undefined2 local_1010;
  undefined2 uStack_100e;
  undefined4 uStack_100c;
  undefined4 local_1008;
  uint uStack_1004;
  undefined local_1000;
  undefined uStack_fff;
  undefined uStack_ffe;
  undefined uStack_ffd;
  undefined uStack_ffc;
  undefined uStack_ffb;
  undefined uStack_ffa;
  undefined uStack_ff9;
  int local_ff8;
  
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  piVar3 = (int *)param_1[0x12];
  if (((((piVar3 == (int *)0x0) || (param_1[5] != 2)) || (*(int *)(param_2 + 0x38) == 0)) ||
      ((piVar9 = *(int **)(param_2 + 0x48), piVar9[0xd] != 0 && (piVar3[0xd] == 0)))) ||
     ((piVar9 == (int *)0x0 ||
      ((*(uint *)(param_2 + 0x10) <= param_3 ||
       (puVar15 = (undefined8 *)(*piVar9 + *(int *)(piVar9[4] + param_3 * 4)),
       puVar15 == (undefined8 *)0x0)))))) {
    param_1[7] = 0x18;
    return 0;
  }
  if (*(int *)puVar15 != 0x2014b50) {
LAB_001e0dec:
    param_1[7] = 9;
    return 0;
  }
  uVar2 = *(ushort *)((int)puVar15 + 0x1c);
  uVar6 = (uint)uVar2;
  local_14b0 = (uint)*(ushort *)(puVar15 + 4);
  local_14b4 = (uint)*(ushort *)((int)puVar15 + 0x1e);
  uVar20 = local_14b0 + uVar6 + local_14b4;
  if (piVar3[1] + uVar20 == -0x4f) {
    param_1[7] = 0xf;
    return 0;
  }
  uVar21 = param_1[8];
  if ((param_1[9] | uVar21) == 0) {
    uVar21 = 0;
  }
  else {
    uVar21 = uVar21 - (*param_1 & uVar21 - 1) & uVar21 - 1;
  }
  if (piVar3[0xd] == 0) {
    if (param_1[4] == 0xffff) goto LAB_001e0e03;
  }
  else if (param_1[4] == 0xffffffff) {
LAB_001e0e03:
    param_1[7] = 2;
    return 0;
  }
  iVar7 = FUN_001dc030(puVar15,local_145c,0,0x1e0b6f);
  iVar8 = local_1424;
  uVar17 = local_1428;
  if (iVar7 == 0) {
    return 0;
  }
  uVar18 = *param_1;
  uVar13 = param_1[1];
  iVar7 = (**(code **)(param_2 + 0x38))
                    (*(undefined4 *)(param_2 + 0x44),local_1428,local_1424,&local_147c,0x1e);
  if (iVar7 != 0x1e) {
    param_1[7] = 0x14;
    return 0;
  }
  if (local_147c != 0x4034b50) goto LAB_001e0dec;
  uVar22 = uVar17 + 0x1e;
  iVar8 = iVar8 + (uint)(0xffffffe1 < uVar17);
  uVar16 = (uint)local_1462;
  uVar24 = (uint)local_1460;
  uVar17 = uVar16 + uVar24 + local_1440;
  uVar19 = local_143c + (uint)CARRY4(uVar16 + uVar24,local_1440);
  if ((uVar24 == 0) || ((local_1466 != -1 && (local_146a != -1)))) {
    local_14c4 = 0;
    iVar7 = piVar3[0xd];
  }
  else {
    piVar9 = (int *)(*(code *)param_1[0xc])(param_1[0xd],0,1,uVar24);
    if (piVar9 == (int *)0x0) goto LAB_001e1902;
    uVar16 = (**(code **)(param_2 + 0x38))
                       (*(undefined4 *)(param_2 + 0x44),uVar16 + local_1428 + 0x1e,
                        local_1424 + (uint)CARRY4(uVar16,local_1428) +
                        (uint)(0xffffffe1 < uVar16 + local_1428),piVar9,uVar24);
    piVar10 = piVar9;
    if (uVar16 != uVar24) goto LAB_001e13c8;
    do {
      if (uVar24 < 4) {
LAB_001e0e8d:
        (*(code *)param_1[0xb])(param_1[0xd],piVar9);
        param_1[7] = 9;
        return 0;
      }
      uVar16 = *(ushort *)((int)piVar10 + 2) + 4;
      if (uVar24 < uVar16) goto LAB_001e0e8d;
      if (*(short *)piVar10 == 1) {
        local_14c4 = 1;
        if (*(ushort *)((int)piVar10 + 2) < 0x10) goto LAB_001e0e8d;
        goto LAB_001e0ea8;
      }
      uVar24 = uVar24 - uVar16;
      piVar10 = (int *)((int)piVar10 + uVar16);
    } while (uVar24 != 0);
    local_14c4 = 0;
LAB_001e0ea8:
    (*(code *)param_1[0xb])(param_1[0xd],piVar9);
    iVar7 = piVar3[0xd];
  }
  if ((iVar7 == 0) &&
     (uVar16 = uVar20 + uVar21 + uVar18, uVar24 = uVar16 + uVar17, uVar12 = uVar24 + piVar3[1],
     iVar7 = CARRY4(uVar20,uVar21) + uVar13 + (uint)CARRY4(uVar20 + uVar21,uVar18) + uVar19 +
             (uint)CARRY4(uVar16,uVar17) + (uint)CARRY4(uVar24,piVar3[1]) +
             (uint)(0xffffff4d < uVar12),
     iVar7 != 0 || (uint)-iVar7 < (uint)(0xfffffffe < uVar12 + 0xb2))) {
LAB_001e0e73:
    param_1[7] = 0x1d;
    return 0;
  }
  uVar16 = 0x1000;
  if (uVar21 < 0x1000) {
    uVar16 = uVar21;
  }
  FUN_0018ae30(&local_1010,0,uVar16);
  uVar16 = uVar18;
  uVar24 = uVar13;
  for (uVar12 = uVar21; uVar12 != 0; uVar12 = uVar12 - uVar25) {
    uVar25 = 0x1000;
    if (uVar12 < 0x1000) {
      uVar25 = uVar12;
    }
    uVar11 = (*(code *)param_1[0xf])(param_1[0x11],uVar16,uVar24,&local_1010,uVar25);
    if (uVar11 != uVar25) goto LAB_001e1833;
    bVar26 = CARRY4(uVar16,uVar25);
    uVar16 = uVar16 + uVar25;
    uVar24 = uVar24 + bVar26;
  }
  uVar16 = uVar18 + uVar21;
  iVar23 = uVar13 + CARRY4(uVar18,uVar21);
  iVar7 = (*(code *)param_1[0xf])(param_1[0x11],uVar16,iVar23,&local_147c,0x1e);
  if (iVar7 != 0x1e) {
LAB_001e1833:
    param_1[7] = 0x13;
    return 0;
  }
  local_14c0 = uVar16 + 0x1e;
  local_14d4 = iVar23 + (uint)(0xffffffe1 < uVar16);
  bVar26 = uVar19 < (uVar17 < 0x2000);
  uVar21 = 0;
  if (bVar26) {
    uVar21 = uVar19;
  }
  uVar18 = 0x2000;
  if (bVar26) {
    uVar18 = uVar17;
  }
  if (uVar21 == 0 && (uint)(0x20 < uVar18) <= -uVar21) {
    uVar18 = 0x20;
  }
  piVar9 = (int *)(*(code *)param_1[10])(param_1[0xd],1,uVar18);
  if (piVar9 == (int *)0x0) {
    param_1[7] = 0x10;
    return 0;
  }
  uVar21 = uVar17 | uVar19;
  while (uVar21 != 0) {
    bVar26 = uVar19 < (uVar17 < 0x2000);
    uVar21 = 0;
    if (bVar26) {
      uVar21 = uVar19;
    }
    uVar18 = 0x2000;
    if (bVar26) {
      uVar18 = uVar17;
    }
    uVar13 = (**(code **)(param_2 + 0x38))
                       (*(undefined4 *)(param_2 + 0x44),uVar22,iVar8,piVar9,uVar18);
    local_14b8 = uVar18;
    if (uVar13 != uVar18) goto LAB_001e13c8;
    uVar13 = (*(code *)param_1[0xf])(param_1[0x11],local_14c0,local_14d4,piVar9,uVar18);
    if (uVar13 != uVar18) goto LAB_001e1823;
    bVar26 = CARRY4(uVar22,uVar18);
    uVar22 = uVar22 + uVar18;
    iVar8 = iVar8 + uVar21 + (uint)bVar26;
    bVar26 = CARRY4(local_14c0,uVar18);
    local_14c0 = local_14c0 + uVar18;
    local_14d4 = local_14d4 + uVar21 + (uint)bVar26;
    bVar26 = uVar17 < uVar18;
    uVar17 = uVar17 - uVar18;
    uVar19 = (uVar19 - uVar21) - (uint)bVar26;
    uVar21 = uVar17 | uVar19;
  }
  if ((local_1476 & 8) != 0) {
    if ((local_14c4 | *(uint *)(*(int *)(param_2 + 0x48) + 0x34)) == 0) {
      iVar8 = (**(code **)(param_2 + 0x38))
                        (*(undefined4 *)(param_2 + 0x44),uVar22,iVar8,piVar9,0x10);
      if (iVar8 != 0x10) goto LAB_001e13c8;
      if (*(int *)(param_1[0x12] + 0x34) == 0) {
        uVar21 = (uint)(*piVar9 == 0x8074b50) * 4 + 0xc;
      }
      else {
        uVar21 = (uint)(*piVar9 == 0x8074b50);
        iVar8 = piVar9[uVar21];
        iVar7 = piVar9[uVar21 + 1];
        iVar4 = piVar9[uVar21 + 2];
        *piVar9 = 0x8074b50;
        *(char *)(piVar9 + 1) = (char)iVar8;
        *(char *)((int)piVar9 + 5) = (char)((uint)iVar8 >> 8);
        *(char *)((int)piVar9 + 6) = (char)((uint)iVar8 >> 0x10);
        *(char *)((int)piVar9 + 7) = (char)((uint)iVar8 >> 0x18);
        *(char *)(piVar9 + 2) = (char)iVar7;
        *(char *)((int)piVar9 + 9) = (char)((uint)iVar7 >> 8);
        *(char *)((int)piVar9 + 10) = (char)((uint)iVar7 >> 0x10);
        *(char *)((int)piVar9 + 0xb) = (char)((uint)iVar7 >> 0x18);
        piVar9[3] = 0;
        *(char *)(piVar9 + 4) = (char)iVar4;
        *(char *)((int)piVar9 + 0x11) = (char)((uint)iVar4 >> 8);
        *(char *)((int)piVar9 + 0x12) = (char)((uint)iVar4 >> 0x10);
        *(char *)((int)piVar9 + 0x13) = (char)((uint)iVar4 >> 0x18);
        piVar9[5] = 0;
        uVar21 = 0x18;
      }
    }
    else {
      iVar8 = (**(code **)(param_2 + 0x38))
                        (*(undefined4 *)(param_2 + 0x44),uVar22,iVar8,piVar9,0x18);
      if (iVar8 != 0x18) {
LAB_001e13c8:
        (*(code *)param_1[0xb])(param_1[0xd],piVar9);
        param_1[7] = 0x14;
        return 0;
      }
      uVar21 = (uint)(*piVar9 == 0x8074b50) * 4 + 0x14;
    }
    local_14b8 = uVar21;
    uVar17 = (*(code *)param_1[0xf])(param_1[0x11],local_14c0,local_14d4,piVar9,uVar21);
    if (uVar17 != uVar21) {
LAB_001e1823:
      (*(code *)param_1[0xb])(param_1[0xd],piVar9);
      goto LAB_001e1833;
    }
    bVar26 = CARRY4(local_14c0,uVar21);
    local_14c0 = local_14c0 + uVar21;
    local_14d4 = local_14d4 + bVar26;
  }
  (*(code *)param_1[0xb])(param_1[0xd],piVar9);
  uVar21 = piVar3[1];
  uStack_1484 = (undefined2)((ulonglong)*(undefined8 *)((int)puVar15 + 0x26) >> 0x10);
  uStack_148c = (undefined6)puVar15[4];
  local_1486 = (undefined2)((ulonglong)puVar15[4] >> 0x30);
  local_1494 = puVar15[3];
  local_149c = puVar15[2];
  local_14ac = *puVar15;
  local_14a4 = puVar15[1];
  if (piVar3[0xd] == 0) {
    if (local_14d4 != 0) {
      param_1[7] = 0x1d;
      return 0;
    }
    if (iVar23 != 0 || (uint)-iVar23 < (uint)(0xfffffffe < uVar16)) goto LAB_001e0e73;
    uVar6 = uVar21 + 0x2e;
    uVar17 = piVar3[2];
    uStack_1482 = uVar16;
    if (uVar17 < uVar6) {
      uVar18 = 1;
      if (uVar17 != 0) {
        uVar18 = uVar17;
      }
      do {
        uVar17 = uVar18;
        uVar18 = uVar17 * 2;
      } while (uVar17 < uVar6);
      iVar8 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar17);
      if (iVar8 == 0) goto LAB_001e1902;
      *piVar3 = iVar8;
      piVar3[2] = uVar17;
    }
    else {
      iVar8 = *piVar3;
    }
    piVar3[1] = uVar6;
    FUN_0018ae80(piVar3[3] * uVar21 + iVar8,&local_14ac,piVar3[3] * 0x2e);
    iVar8 = piVar3[1];
    uVar6 = piVar3[2];
    uVar17 = uVar20 + iVar8;
    if (uVar17 <= uVar6) {
LAB_001e18b9:
      piVar3[1] = uVar17;
      if (uVar20 != 0) {
        FUN_0018ae80(iVar8 * piVar3[3] + *piVar3,(int)puVar15 + 0x2e,uVar20 * piVar3[3]);
        goto LAB_001e191d;
      }
      goto LAB_001e1927;
    }
    uVar18 = 1;
    if (uVar6 != 0) {
      uVar18 = uVar6;
    }
    do {
      uVar6 = uVar18;
      uVar18 = uVar6 * 2;
    } while (uVar6 < uVar17);
    iVar7 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar6);
    if (iVar7 != 0) {
      *piVar3 = iVar7;
      piVar3[2] = uVar6;
      goto LAB_001e18b9;
    }
  }
  else {
    local_14d0 = local_14b4 + 0x40;
    uVar5 = (ulonglong)local_1494 >> 0x20;
    local_1494 = CONCAT44((int)uVar5,0xffffffff);
    local_149c = CONCAT44(0xffffffff,(undefined4)local_149c);
    uStack_1482 = 0xffffffff;
    local_14ec = (undefined8 *)(*(code *)param_1[0xc])(param_1[0xd],0,1,local_14d0);
    local_14e8 = 0x10;
    if (local_14ec == (undefined8 *)0x0) {
      local_14ec = (undefined8 *)0x0;
LAB_001e153d:
      param_1[7] = local_14e8;
      (*(code *)param_1[0xb])(param_1[0xd],local_14ec);
      return 0;
    }
    local_1010 = 1;
    local_1008 = local_1434;
    uStack_100c = local_1438;
    uStack_1004 = local_1440;
    local_1000 = (undefined)local_143c;
    uStack_fff = (undefined)((uint)local_143c >> 8);
    uStack_ffe = (undefined)((uint)local_143c >> 0x10);
    uStack_ffd = (undefined)((uint)local_143c >> 0x18);
    uStack_ffc = (undefined)uVar16;
    uStack_ffb = (undefined)(uVar16 >> 8);
    uStack_ffa = (undefined)(uVar16 >> 0x10);
    uStack_ff9 = (undefined)(uVar16 >> 0x18);
    uStack_100e = 0x18;
    local_14ec[1] = CONCAT44(local_1440,local_1434);
    local_14ec[2] =
         CONCAT17(uStack_ff9,
                  CONCAT16(uStack_ffa,CONCAT15(uStack_ffb,CONCAT14(uStack_ffc,local_143c))));
    *(int *)(local_14ec + 3) = iVar23;
    psVar1 = (short *)((int)puVar15 + uVar6 + 0x2e);
    *local_14ec = CONCAT44(local_1438,&UNK_00180001);
    local_ff8 = iVar23;
    if ((short)local_14b4 != 0) {
      local_14e4 = 0x1c;
      local_14dc = psVar1;
      uVar20 = local_14b4;
      while ((3 < uVar20 && (uVar17 = (ushort)local_14dc[1] + 4, uVar17 <= uVar20))) {
        if (*local_14dc != 1) {
          uVar18 = uVar17 + local_14e4;
          puVar14 = local_14ec;
          if (local_14d0 < uVar18) {
            uVar13 = local_14d0;
            if (local_14d0 == 0) {
              uVar13 = 1;
            }
            do {
              local_14d0 = uVar13;
              uVar13 = local_14d0 * 2;
            } while (local_14d0 < uVar18);
            puVar14 = (undefined8 *)(*(code *)param_1[0xc])(param_1[0xd],local_14ec,1,local_14d0);
            if (puVar14 == (undefined8 *)0x0) goto LAB_001e153d;
          }
          FUN_0018ae80(local_14e4 + (int)puVar14,local_14dc,uVar17);
          local_14e4 = uVar18;
          local_14ec = puVar14;
        }
        uVar20 = uVar20 - uVar17;
        if (uVar20 == 0) goto LAB_001e1561;
        local_14dc = (short *)((int)local_14dc + uVar17);
      }
      local_14e8 = 9;
      goto LAB_001e153d;
    }
    local_14e4 = 0x1c;
LAB_001e1561:
    local_1494 = CONCAT26((short)local_14e4,(undefined6)local_1494);
    iVar8 = piVar3[1];
    uVar17 = piVar3[2];
    uVar20 = iVar8 + 0x2e;
    if (uVar17 < uVar20) {
      uVar18 = 1;
      if (uVar17 != 0) {
        uVar18 = uVar17;
      }
      do {
        uVar17 = uVar18;
        uVar18 = uVar17 * 2;
      } while (uVar17 < uVar20);
      iVar7 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar17);
      if (iVar7 == 0) {
        (*(code *)param_1[0xb])(param_1[0xd],local_14ec);
        goto LAB_001e1902;
      }
      *piVar3 = iVar7;
      piVar3[2] = uVar17;
    }
    else {
      iVar7 = *piVar3;
    }
    piVar3[1] = uVar20;
    FUN_0018ae80(iVar8 * piVar3[3] + iVar7,&local_14ac,piVar3[3] * 0x2e);
    iVar8 = piVar3[1];
    uVar17 = piVar3[2];
    uVar20 = uVar6 + iVar8;
    if (uVar17 < uVar20) {
      uVar18 = 1;
      if (uVar17 != 0) {
        uVar18 = uVar17;
      }
      do {
        uVar17 = uVar18;
        uVar18 = uVar17 * 2;
      } while (uVar17 < uVar20);
      iVar7 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar17);
      if (iVar7 != 0) {
        *piVar3 = iVar7;
        piVar3[2] = uVar17;
        goto LAB_001e163d;
      }
LAB_001e178a:
      (*(code *)param_1[0xb])(param_1[0xd],local_14ec);
      goto LAB_001e179a;
    }
LAB_001e163d:
    piVar3[1] = uVar20;
    if (uVar2 != 0) {
      FUN_0018ae80(iVar8 * piVar3[3] + *piVar3,(int)puVar15 + 0x2e,uVar6 * piVar3[3]);
      uVar20 = piVar3[1];
      uVar17 = piVar3[2];
    }
    local_14e0 = local_14e4 + uVar20;
    if (uVar17 < local_14e0) {
      uVar6 = 1;
      if (uVar17 != 0) {
        uVar6 = uVar17;
      }
      do {
        uVar17 = uVar6;
        uVar6 = uVar17 * 2;
      } while (uVar17 < local_14e0);
      iVar8 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar17);
      if (iVar8 == 0) goto LAB_001e178a;
      *piVar3 = iVar8;
      piVar3[2] = uVar17;
    }
    piVar3[1] = local_14e0;
    if (local_14e4 != 0) {
      FUN_0018ae80(uVar20 * piVar3[3] + *piVar3,local_14ec,local_14e4 * piVar3[3]);
      local_14e0 = piVar3[1];
      uVar17 = piVar3[2];
    }
    uVar6 = local_14e0 + local_14b0;
    if (uVar17 < uVar6) {
      uVar20 = 1;
      if (uVar17 != 0) {
        uVar20 = uVar17;
      }
      do {
        uVar17 = uVar20;
        uVar20 = uVar17 * 2;
      } while (uVar17 < uVar6);
      iVar8 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar17);
      if (iVar8 == 0) goto LAB_001e178a;
      *piVar3 = iVar8;
      piVar3[2] = uVar17;
    }
    piVar3[1] = uVar6;
    if ((short)local_14b0 != 0) {
      FUN_0018ae80(local_14e0 * piVar3[3] + *piVar3,(int)psVar1 + local_14b4,local_14b0 * piVar3[3])
      ;
    }
    (*(code *)param_1[0xb])(param_1[0xd],local_14ec);
LAB_001e191d:
    uVar17 = piVar3[1];
LAB_001e1927:
    if (uVar17 == 0xffffffff) {
      if ((uint)piVar3[2] < uVar21) {
        iVar8 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar21);
        if (iVar8 == 0) goto LAB_001e19c8;
        *piVar3 = iVar8;
        piVar3[2] = uVar21;
      }
      piVar3[1] = uVar21;
LAB_001e19c8:
      param_1[7] = 0xf;
      return 0;
    }
    iVar8 = piVar3[5];
    uVar20 = piVar3[6];
    uVar6 = iVar8 + 1;
    local_14b8 = uVar21;
    if (uVar6 <= uVar20) {
      iVar7 = piVar3[4];
LAB_001e19dd:
      piVar3[5] = uVar6;
      FUN_0018ae80(iVar8 * piVar3[7] + iVar7,&local_14b8,piVar3[7]);
      param_1[4] = param_1[4] + 1;
      param_1[1] = local_14d4;
      *param_1 = local_14c0;
      return 1;
    }
    uVar17 = 1;
    if (uVar20 != 0) {
      uVar17 = uVar20;
    }
    do {
      uVar20 = uVar17;
      uVar17 = uVar20 * 2;
    } while (uVar20 < uVar6);
    iVar7 = (*(code *)param_1[0xc])(param_1[0xd],piVar3[4],piVar3[7],uVar20);
    if (iVar7 != 0) {
      piVar3[4] = iVar7;
      piVar3[6] = uVar20;
      goto LAB_001e19dd;
    }
  }
LAB_001e179a:
  if ((uint)piVar3[2] < uVar21) {
    iVar8 = (*(code *)param_1[0xc])(param_1[0xd],*piVar3,piVar3[3],uVar21);
    if (iVar8 == 0) goto LAB_001e1902;
    *piVar3 = iVar8;
    piVar3[2] = uVar21;
  }
  piVar3[1] = uVar21;
LAB_001e1902:
  param_1[7] = 0x10;
  return 0;
}

