/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00212930 FUN_00212930 */

void FUN_00212930(int param_1,int *param_2)

{
  uint uVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  
  uVar7 = 0x212941;
  iVar5 = param_2[1];
  if ((iVar5 == 0) || (*(char *)(iVar5 + -1 + *param_2) != ']')) {
    uVar1 = iVar5 + 1;
    if (uVar1 < (uint)param_2[2]) {
      iVar6 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar6 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar6;
      if (iVar6 == 0) goto LAB_00212ab5;
      iVar5 = param_2[1];
    }
    *(undefined *)(iVar6 + iVar5) = 0x20;
    iVar5 = param_2[1] + 1;
    param_2[1] = iVar5;
  }
  uVar1 = iVar5 + 1;
  if (uVar1 < (uint)param_2[2]) {
    iVar6 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar6 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar6;
    if (iVar6 == 0) goto LAB_00212ab5;
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar6 + iVar5) = 0x5b;
  iVar5 = param_2[1] + 1;
  param_2[1] = iVar5;
  piVar2 = *(int **)(param_1 + 0xc);
  if (*(int *)(param_1 + 0x10) == 0) {
    if ((piVar2 != (int *)0x0) &&
       ((**(code **)(*piVar2 + 0x10))(piVar2,param_2), *(char *)((int)piVar2 + 5) != '\x01')) {
      (**(code **)(*piVar2 + 0x14))(piVar2,param_2);
    }
  }
  else if ((piVar2 != (int *)0x0) && (iVar6 = *(int *)(param_1 + 0x10) - (int)piVar2, iVar6 != 0)) {
    uVar1 = iVar5 + iVar6;
    if (uVar1 < (uint)param_2[2]) {
      iVar4 = *param_2;
    }
    else {
      uVar3 = param_2[2] * 2;
      if (uVar3 < uVar1) {
        uVar3 = uVar1;
      }
      param_2[2] = uVar3;
      iVar4 = FUN_0018b200(*param_2,uVar3);
      *param_2 = iVar4;
      if (iVar4 == 0) goto LAB_00212ab5;
      iVar5 = param_2[1];
    }
    FUN_0018ae40(iVar5 + iVar4,piVar2,iVar6,uVar7);
    param_2[1] = param_2[1] + iVar6;
  }
  iVar5 = param_2[1];
  uVar1 = iVar5 + 1;
  if (uVar1 < (uint)param_2[2]) {
    iVar6 = *param_2;
  }
  else {
    uVar3 = param_2[2] * 2;
    if (uVar3 < uVar1) {
      uVar3 = uVar1;
    }
    param_2[2] = uVar3;
    iVar6 = FUN_0018b200(*param_2,uVar3);
    *param_2 = iVar6;
    if (iVar6 == 0) {
LAB_00212ab5:
                    /* WARNING: Subroutine does not return */
      FUN_001f9d40();
    }
    iVar5 = param_2[1];
  }
  *(undefined *)(iVar6 + iVar5) = 0x5d;
  param_2[1] = param_2[1] + 1;
  (**(code **)(**(int **)(param_1 + 8) + 0x14))(*(int **)(param_1 + 8),param_2);
  return;
}

