/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b19c0 FUN_001b19c0 */

int FUN_001b19c0(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = *(int *)PTR_DAT_0024bcc0;
  if (iVar3 == 0) {
    uVar1 = (**(code **)(*param_1 + 0x18))(param_1,"java/lang/String");
    uVar2 = (**(code **)(*param_1 + 0x29c))(param_1,&DAT_00217e63);
    iVar3 = (**(code **)(*param_1 + 0x2b0))(param_1,1,uVar1,uVar2);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar2);
    (**(code **)(*param_1 + 0x5c))(param_1,uVar1);
  }
  return iVar3;
}

