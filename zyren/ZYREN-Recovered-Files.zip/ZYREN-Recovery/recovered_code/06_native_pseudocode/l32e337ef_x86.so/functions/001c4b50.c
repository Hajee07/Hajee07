/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c4b50 FUN_001c4b50 */

uint FUN_001c4b50(uint *param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  longlong lVar2;
  byte bVar3;
  uint uVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  uint local_1c;
  uint local_18;
  
  if (param_3 < 5) {
    return 5;
  }
  if (*param_2 != 0xfd2fb528) {
    if ((*param_2 & 0xfffffff0) != 0x184d2a50) {
      return 0xfffffff6;
    }
    if (7 < param_3) {
      param_1[1] = 0;
      *param_1 = 0;
      param_1[3] = 0;
      param_1[2] = 0;
      param_1[5] = 0;
      param_1[4] = 0;
      param_1[7] = 0;
      param_1[6] = 0;
      *param_1 = param_2[1];
      param_1[1] = 0;
      param_1[4] = 1;
      param_1[3] = 0;
      param_1[2] = 0;
      return 0;
    }
    return 8;
  }
  bVar1 = *(byte *)(param_2 + 1);
  uVar4 = (bVar1 & 0x20) >> 5;
  uVar4 = ((*(int *)(&DAT_0021b5e0 + (uint)(bVar1 >> 6) * 4) +
           *(int *)(&DAT_0021b5d0 + (bVar1 & 3) * 4)) - uVar4) + 6 +
          (uint)(bVar1 >> 6 == 0 & (byte)uVar4);
  if (param_3 < uVar4) {
    return uVar4;
  }
  param_1[5] = uVar4;
  bVar1 = *(byte *)(param_2 + 1);
  if ((bVar1 & 8) != 0) {
    return 0xfffffff2;
  }
  if ((bVar1 & 0x20) == 0) {
    bVar5 = (*(byte *)((int)param_2 + 5) >> 3) + 10;
    if (0x1b < bVar5) {
      return 0xfffffff0;
    }
    uVar9 = 1 << (bVar5 & 0x1f);
    uVar8 = uVar9;
    uVar4 = 0 << (bVar5 & 0x1f) | 1U >> 0x20 - (bVar5 & 0x1f);
    if ((bVar5 & 0x20) != 0) {
      uVar8 = 0;
      uVar4 = uVar9;
    }
    uVar7 = *(byte *)((int)param_2 + 5) & 7;
    lVar2 = (ulonglong)(uVar4 << 0x1d | uVar8 >> 3) * (ulonglong)uVar7;
    uVar9 = (uint)lVar2;
    local_18 = uVar9 + uVar8;
    local_1c = (int)((ulonglong)lVar2 >> 0x20) + (uVar4 >> 3) * uVar7 + uVar4 +
               (uint)CARRY4(uVar9,uVar8);
    iVar6 = 6;
  }
  else {
    iVar6 = 5;
    local_18 = 0;
    local_1c = 0;
  }
  bVar3 = bVar1 & 3;
  bVar5 = bVar1 >> 6;
  if (bVar3 == 3) {
    uVar4 = *(uint *)((int)param_2 + iVar6);
    iVar6 = iVar6 + 4;
joined_r0x001c4d10:
    if (bVar5 == 1) goto LAB_001c4d34;
LAB_001c4d12:
    if (bVar5 == 2) {
      uVar8 = *(uint *)((int)param_2 + iVar6);
    }
    else {
      if (bVar5 == 3) {
        uVar8 = *(uint *)((int)param_2 + iVar6);
        uVar9 = *(uint *)((int)param_2 + iVar6 + 4);
        goto LAB_001c4d68;
      }
      uVar8 = 0xffffffff;
      uVar9 = 0xffffffff;
      if ((bVar1 & 0x20) == 0) goto LAB_001c4d68;
      uVar8 = (uint)*(byte *)((int)param_2 + iVar6);
    }
  }
  else {
    if (bVar3 == 2) {
      uVar4 = (uint)*(ushort *)((int)param_2 + iVar6);
      iVar6 = iVar6 + 2;
      goto joined_r0x001c4d10;
    }
    if (bVar3 != 1) {
      uVar4 = 0;
      goto joined_r0x001c4d10;
    }
    uVar4 = (uint)*(byte *)((int)param_2 + iVar6);
    iVar6 = iVar6 + 1;
    if (bVar5 != 1) goto LAB_001c4d12;
LAB_001c4d34:
    uVar8 = *(ushort *)((int)param_2 + iVar6) + 0x100;
  }
  uVar9 = 0;
LAB_001c4d68:
  bVar10 = (bVar1 & 0x20) != 0;
  if (bVar10) {
    local_18 = uVar8;
  }
  param_1[4] = 0;
  *param_1 = uVar8;
  if (bVar10) {
    local_1c = uVar9;
  }
  param_1[1] = uVar9;
  param_1[3] = local_1c;
  param_1[2] = local_18;
  param_1[6] = uVar4;
  param_1[7] = bVar1 >> 2 & 1;
  return 0;
}

