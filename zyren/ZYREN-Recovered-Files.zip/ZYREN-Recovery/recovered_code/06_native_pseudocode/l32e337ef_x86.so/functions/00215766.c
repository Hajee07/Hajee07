/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00215766 FUN_00215766 */

undefined4 FUN_00215766(code *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined local_14c [320];
  
  FUN_00215085();
  while (((iVar1 = FUN_00214da1(), iVar1 == 5 || (iVar1 == 0)) &&
         (iVar2 = (*param_1)(local_14c,param_2,iVar1,iVar1), iVar2 == 0))) {
    if (iVar1 == 5) {
      return 5;
    }
    FUN_00214d67();
  }
  return 3;
}

