/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a56c0 FUN_001a56c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_001a56c0(void)

{
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  code *pcVar6;
  code *pcVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined *puVar10;
  undefined *puVar11;
  uint *puVar12;
  uint *puVar13;
  uint local_90;
  uint local_8c;
  uint uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined local_7c;
  uint local_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint local_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined local_24;
  undefined4 *local_18;
  int *local_14;
  
  puVar1 = PTR_DAT_0024bc24;
  if (*PTR_DAT_0024bc20 != '\0') {
    uVar5 = *(undefined4 *)PTR_DAT_0024bc24;
    local_6c = 0x434e426e;
    uStack_68 = 0x5a5a7e42;
    uStack_64 = 0x45535e;
    local_8c = 0;
    do {
      *(byte *)((int)&local_6c + local_8c) =
           (char)local_8c + 0x2dU ^ *(byte *)((int)&local_6c + local_8c);
      local_8c = local_8c + 1;
    } while (local_8c < 0xb);
    uStack_64 = uStack_64 & 0xffffff;
    local_8c = 0x59494b69;
    uStack_88 = 0x5870575f;
    uStack_84 = 0x444554;
    local_90 = 0;
    do {
      *(byte *)((int)&local_8c + local_90) =
           (char)local_90 + 0x2dU ^ *(byte *)((int)&local_8c + local_90);
      local_90 = local_90 + 1;
    } while (local_90 < 0xb);
    uStack_84 = uStack_84 & 0xffffff;
    puVar13 = &local_8c;
    puVar12 = &local_6c;
    iVar3 = FUN_001a5fa0(uVar5);
    if (iVar3 != 0) {
      local_6c = 0x514d4741;
      uStack_68 = 0x471d4643;
      uStack_64 = CONCAT22(uStack_64._2_2_,0x5a);
      local_8c = 0;
      do {
        *(byte *)((int)&local_6c + local_8c) =
             (char)local_8c + 0x2dU ^ *(byte *)((int)&local_6c + local_8c);
        local_8c = local_8c + 1;
      } while (local_8c < 9);
      uStack_64._0_2_ = (ushort)(byte)uStack_64;
      if (*(int *)PTR_DAT_0024bbac < 0x18) {
        iVar4 = FUN_0018b090(&local_6c,0,puVar12,puVar13);
        if (iVar4 == 0) {
          *(undefined4 *)PTR_DAT_0024bc14 = 0;
          iVar3 = *(int *)PTR_DAT_0024bbac;
          local_14 = (int *)PTR_DAT_0024bbac;
          goto joined_r0x001a5885;
        }
        iVar3 = FUN_0018b0a0(iVar4,iVar3);
        FUN_0018b0b0(iVar4);
        puVar10 = PTR_DAT_0024bc14;
        *(int *)PTR_DAT_0024bc14 = iVar3;
      }
      else {
        iVar3 = FUN_001b62a0(iVar3);
        puVar10 = PTR_DAT_0024bc14;
        *(int *)PTR_DAT_0024bc14 = iVar3;
      }
      puVar11 = PTR_FUN_0024bc2c;
      if (iVar3 != 0) goto LAB_001a5c84;
    }
    iVar3 = *(int *)PTR_DAT_0024bbac;
    local_14 = (int *)PTR_DAT_0024bbac;
joined_r0x001a5885:
    PTR_DAT_0024bbac = (undefined *)local_14;
    if (0x1e < iVar3) {
      uStack_54._3_1_ = (undefined)((uint)uStack_54 >> 0x18);
      uVar5 = *(undefined4 *)puVar1;
      local_8c = 0x44415b7f;
      uStack_88 = 0x565f58;
      local_6c = 0;
      do {
        *(byte *)((int)&local_8c + local_6c) =
             (char)local_6c + 0x2dU ^ *(byte *)((int)&local_8c + local_6c);
        local_6c = local_6c + 1;
      } while (local_6c < 7);
      uStack_88 = uStack_88 & 0xffffff;
      local_6c = _DAT_0021ab90;
      uStack_68 = _UNK_0021ab94;
      uStack_64 = _UNK_0021ab98;
      uStack_60 = _UNK_0021ab9c;
      local_5c = 0x4c555e;
      local_90 = 0;
      do {
        *(byte *)((int)&local_6c + local_90) =
             (char)local_90 + 0x2dU ^ *(byte *)((int)&local_6c + local_90);
        local_90 = local_90 + 1;
      } while (local_90 < 0x13);
      local_5c = local_5c & 0xffffff;
      iVar3 = FUN_001a5fa0(uVar5);
      uVar2 = uStack_58;
      uVar5 = *(undefined4 *)puVar1;
      local_8c = _DAT_0021aba0;
      uStack_88 = _UNK_0021aba4;
      uStack_84 = _UNK_0021aba8;
      uStack_80 = _UNK_0021abac;
      local_6c = 0;
      do {
        *(byte *)((int)&local_8c + local_6c) =
             (char)local_6c + 0x2dU ^ *(byte *)((int)&local_8c + local_6c);
        local_6c = local_6c + 1;
      } while (local_6c < 0x10);
      local_7c = 0;
      local_6c = _DAT_0021abb0;
      uStack_68 = _UNK_0021abb4;
      uStack_64 = _UNK_0021abb8;
      uStack_60 = _UNK_0021abbc;
      local_5c = 0x2b5c5f5f;
      uStack_58 = uStack_58 & 0xffffff00;
      local_90 = 0;
      do {
        *(byte *)((int)&local_6c + local_90) =
             (char)local_90 + 0x2dU ^ *(byte *)((int)&local_6c + local_90);
        local_90 = local_90 + 1;
      } while (local_90 < 0x14);
      uStack_58 = uVar2 & 0xffffff00;
      puVar13 = &local_8c;
      puVar12 = &local_6c;
      iVar4 = FUN_001a5fa0(uVar5);
      piVar9 = local_14;
      if (iVar3 == 0) {
        return 0;
      }
      if (iVar4 == 0) {
        return 0;
      }
      local_8c = 0x514d4741;
      uStack_88 = 0x471d4643;
      uStack_84 = CONCAT22(uStack_84._2_2_,0x5a);
      local_6c = 0;
      do {
        *(byte *)((int)&local_8c + local_6c) =
             (char)local_6c + 0x2dU ^ *(byte *)((int)&local_8c + local_6c);
        local_6c = local_6c + 1;
      } while (local_6c < 9);
      uStack_84._0_2_ = (ushort)(byte)uStack_84;
      local_6c = _DAT_0021abc0;
      uStack_68 = _UNK_0021abc4;
      uStack_64 = _UNK_0021abc8;
      uStack_60 = _UNK_0021abcc;
      local_5c = 0x344c5054;
      uStack_58 = 0x21202c20;
      uStack_54 = CONCAT13(uStack_54._3_1_,0x31a);
      local_90 = 0;
      do {
        *(byte *)((int)&local_6c + local_90) =
             (char)local_90 + 0x2dU ^ *(byte *)((int)&local_6c + local_90);
        local_90 = local_90 + 1;
      } while (local_90 < 0x1a);
      uStack_54._0_3_ = (uint3)(ushort)uStack_54;
      if (*local_14 < 0x18) {
        iVar3 = FUN_0018b090(&local_8c,0,puVar13,puVar12);
        if (iVar3 == 0) {
          local_18 = (undefined4 *)0x0;
          piVar9 = local_14;
        }
        else {
          local_18 = (undefined4 *)FUN_0018b0a0(iVar3,&local_6c);
          FUN_0018b0b0(iVar3);
          piVar9 = local_14;
        }
      }
      else {
        local_18 = (undefined4 *)FUN_001b62a0(&local_6c);
      }
      local_8c = 0x514d4741;
      uStack_88 = 0x471d4643;
      uStack_84 = CONCAT22(uStack_84._2_2_,0x5a);
      local_6c = 0;
      do {
        *(byte *)((int)&local_8c + local_6c) =
             (char)local_6c + 0x2dU ^ *(byte *)((int)&local_8c + local_6c);
        local_6c = local_6c + 1;
      } while (local_6c < 9);
      uStack_84._0_2_ = (ushort)(byte)uStack_84;
      local_6c = _DAT_0021abd0;
      uStack_68 = _UNK_0021abd4;
      uStack_64 = _UNK_0021abd8;
      uStack_60 = _UNK_0021abdc;
      local_5c = _DAT_0021abe0;
      uStack_58 = _UNK_0021abe4;
      uStack_54 = _UNK_0021abe8;
      uStack_50 = _UNK_0021abec;
      local_4c = 0x23242d2c;
      uStack_48 = CONCAT13(uStack_48._3_1_,0x2414);
      local_90 = 0;
      do {
        *(byte *)((int)&local_6c + local_90) =
             (char)local_90 + 0x2dU ^ *(byte *)((int)&local_6c + local_90);
        local_90 = local_90 + 1;
      } while (local_90 < 0x26);
      uStack_48._0_3_ = (uint3)(ushort)uStack_48;
      if (*piVar9 < 0x18) {
        iVar3 = FUN_0018b090(&local_8c,0);
        if (iVar3 == 0) {
          pcVar6 = (code *)0x0;
        }
        else {
          pcVar6 = (code *)FUN_0018b0a0(iVar3,&local_6c);
          FUN_0018b0b0(iVar3);
        }
      }
      else {
        pcVar6 = (code *)FUN_001b62a0(&local_6c);
      }
      local_8c = 0x514d4741;
      uStack_88 = 0x471d4643;
      uStack_84 = CONCAT22(uStack_84._2_2_,0x5a);
      local_6c = 0;
      do {
        *(byte *)((int)&local_8c + local_6c) =
             (char)local_6c + 0x2dU ^ *(byte *)((int)&local_8c + local_6c);
        local_6c = local_6c + 1;
      } while (local_6c < 9);
      uStack_84._0_2_ = (ushort)(byte)uStack_84;
      local_6c = _DAT_0021abf0;
      uStack_68 = _UNK_0021abf4;
      uStack_64 = _UNK_0021abf8;
      uStack_60 = _UNK_0021abfc;
      local_5c = _DAT_0021ac00;
      uStack_58 = _UNK_0021ac04;
      uStack_54 = _UNK_0021ac08;
      uStack_50 = _UNK_0021ac0c;
      local_4c = _DAT_0021ac10;
      uStack_48 = _UNK_0021ac14;
      uStack_44 = _UNK_0021ac18;
      uStack_40 = _UNK_0021ac1c;
      local_3c = _DAT_0021ac20;
      uStack_38 = _UNK_0021ac24;
      uStack_34 = _UNK_0021ac28;
      uStack_30 = _UNK_0021ac2c;
      local_2c = 0x1203020c;
      local_28 = 0x31181110;
      local_90 = 0;
      do {
        *(byte *)((int)&local_6c + local_90) =
             (char)local_90 + 0x2dU ^ *(byte *)((int)&local_6c + local_90);
        local_90 = local_90 + 1;
      } while (local_90 < 0x48);
      local_24 = 0;
      if (*piVar9 < 0x18) {
        iVar3 = FUN_0018b090(&local_8c,0);
        if (iVar3 == 0) {
          pcVar7 = (code *)0x0;
        }
        else {
          pcVar7 = (code *)FUN_0018b0a0(iVar3,&local_6c);
          FUN_0018b0b0(iVar3);
        }
      }
      else {
        pcVar7 = (code *)FUN_001b62a0(&local_6c);
      }
      if (local_18 == (undefined4 *)0x0) {
        return 0;
      }
      if (pcVar6 == (code *)0x0) {
        return 0;
      }
      if (pcVar7 == (code *)0x0) {
        return 0;
      }
      iVar3 = (*pcVar6)(*local_18);
      if (iVar3 != 0) {
        puVar8 = (undefined4 *)FUN_001f5520(4);
        *puVar8 = PTR_DAT_0024bc30 + 8;
        (*pcVar7)(iVar3,puVar8);
        return 1;
      }
    }
    return 0;
  }
  local_6c = 0x544d4741;
  uStack_68 = 0x471d5f47;
  uStack_64 = CONCAT22(uStack_64._2_2_,0x5a);
  local_8c = 0;
  do {
    *(byte *)((int)&local_6c + local_8c) =
         (char)local_8c + 0x2dU ^ *(byte *)((int)&local_6c + local_8c);
    local_8c = local_8c + 1;
  } while (local_8c < 9);
  uStack_64._0_2_ = (ushort)(byte)uStack_64;
  iVar3 = FUN_0018b090(&local_6c,0);
  if (iVar3 == 0) {
    return 0;
  }
  local_6c = _DAT_0021ac30;
  uStack_68 = _UNK_0021ac34;
  uStack_64 = _UNK_0021ac38;
  uStack_60 = _UNK_0021ac3c;
  local_5c = 0x408756d;
  uStack_58 = 0x2d053a24;
  uStack_54 = 0x3172329;
  uStack_50 = CONCAT22(uStack_50._2_2_,0x2a);
  local_8c = 0;
  do {
    *(byte *)((int)&local_6c + local_8c) =
         (char)local_8c + 0x2dU ^ *(byte *)((int)&local_6c + local_8c);
    local_8c = local_8c + 1;
  } while (local_8c < 0x1d);
  uStack_50._0_2_ = (ushort)(byte)uStack_50;
  uVar5 = FUN_0018b0a0(iVar3,&local_6c);
  puVar10 = PTR_DAT_0024bc18;
  *(undefined4 *)PTR_DAT_0024bc18 = uVar5;
  FUN_0018b0b0(iVar3);
  puVar11 = PTR_FUN_0024bc28;
  if (*(int *)puVar10 == 0) {
    return 0;
  }
LAB_001a5c84:
  FUN_00198020(puVar10,puVar11);
  return 1;
}

