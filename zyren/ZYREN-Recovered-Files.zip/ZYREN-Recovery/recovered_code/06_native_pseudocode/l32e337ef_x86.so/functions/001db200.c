/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001db200 FUN_001db200 */

uint FUN_001db200(int *param_1,byte *param_2,uint param_3)

{
  uint *puVar1;
  byte bVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  byte *pbVar9;
  uint uVar10;
  uint local_24;
  uint local_20;
  int *local_1c;
  int local_18;
  uint local_14;
  
  uVar7 = 0;
  if ((((param_1 != (int *)0x0) && (iVar5 = *param_1, iVar5 != 0)) && (param_2 != (byte *)0x0)) &&
     (*(int *)(iVar5 + 0x48) != 0)) {
    if (((*(byte *)((int)param_1 + 5) & 4) == 0) && (*(short *)((int)param_1 + 0x52) != 0)) {
      local_1c = param_1 + 0x126;
      uVar7 = 0;
      do {
        iVar5 = param_1[0x124];
        pbVar9 = (byte *)(iVar5 + (param_1[0xc] & 0x7fffU));
        local_24 = 0x8000 - (param_1[0xc] & 0x7fffU);
        uVar4 = param_1[0x125];
        if (param_1[0x125] == 0) {
          uVar4 = param_1[8];
          if ((param_1[9] | uVar4) == 0) {
            iVar3 = *param_1;
            uVar4 = 0;
            if (*(int *)(*(int *)(iVar3 + 0x48) + 0x48) == 0) {
              uVar4 = param_1[5];
              uVar6 = param_1[0xb];
              uVar10 = param_1[10];
              if (uVar4 < uVar6 || uVar4 - uVar6 < (uint)((uint)param_1[4] < (uint)param_1[10])) {
                uVar6 = uVar4;
                uVar10 = param_1[4];
              }
              param_1[9] = uVar6;
              param_1[8] = uVar10;
              uVar4 = (**(code **)(iVar3 + 0x38))
                                (*(undefined4 *)(iVar3 + 0x44),param_1[0xe],param_1[0xf],
                                 param_1[0x123],uVar10);
              if ((param_1[8] ^ uVar4 | param_1[9]) != 0) {
                if (*param_1 != 0) {
                  *(undefined4 *)(*param_1 + 0x1c) = 0x14;
                }
                goto LAB_001db6ac;
              }
              puVar1 = (uint *)(param_1 + 0xe);
              uVar6 = *puVar1;
              *puVar1 = *puVar1 + uVar4;
              param_1[0xf] = param_1[0xf] + (uint)CARRY4(uVar6,uVar4);
              puVar1 = (uint *)(param_1 + 10);
              uVar6 = *puVar1;
              *puVar1 = *puVar1 - uVar4;
              param_1[0xb] = param_1[0xb] - (uint)(uVar6 < uVar4);
              param_1[7] = 0;
              param_1[6] = 0;
              iVar5 = param_1[0x124];
            }
          }
          local_20 = uVar4;
          iVar5 = FUN_001d39a0(local_1c,param_1[0x123] + param_1[6],&local_20,iVar5,pbVar9,&local_24
                               ,((param_1[10] | param_1[0xb]) != 0U) * '\x02');
          param_1[2] = iVar5;
          *(ulonglong *)(param_1 + 6) = *(longlong *)(param_1 + 6) + (ulonglong)local_20;
          *(ulonglong *)(param_1 + 8) = *(longlong *)(param_1 + 8) - (ulonglong)local_20;
          param_1[0x125] = local_24;
          uVar4 = local_24;
          if (local_24 != 0) goto LAB_001db3a5;
        }
        else {
LAB_001db3a5:
          uVar6 = param_3 - uVar7;
          if (uVar4 <= param_3 - uVar7) {
            uVar6 = uVar4;
          }
          FUN_0018ae80(param_2 + uVar7,pbVar9,uVar6);
          uVar4 = ~param_1[3];
          uVar10 = uVar6;
          if (3 < uVar6) {
            local_14 = uVar6 - 4 & 0xfffffffc;
            local_18 = local_14 + 4;
            pbVar8 = pbVar9;
            do {
              uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)*pbVar8) * 4);
              uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)pbVar8[1]) * 4);
              uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)pbVar8[2]) * 4);
              uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)pbVar8[3]) * 4);
              uVar10 = uVar10 - 4;
              pbVar8 = pbVar8 + 4;
            } while (3 < uVar10);
            pbVar9 = pbVar9 + local_18;
            uVar10 = (uVar6 - 4) - local_14;
          }
          for (; uVar10 != 0; uVar10 = uVar10 - 1) {
            uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)*pbVar9) * 4);
            pbVar9 = pbVar9 + 1;
          }
          param_1[3] = ~uVar4;
          param_1[0x125] = param_1[0x125] - uVar6;
          uVar4 = param_1[0xc] + uVar6;
          uVar10 = param_1[0xd] + (uint)CARRY4(param_1[0xc],uVar6);
          param_1[0xc] = uVar4;
          param_1[0xd] = uVar10;
          if ((uint)param_1[0x1a] < uVar10 ||
              param_1[0x1a] - uVar10 < (uint)((uint)param_1[0x19] < uVar4)) {
            if (*param_1 != 0) {
              *(undefined4 *)(*param_1 + 0x1c) = 0xb;
              param_1[2] = -1;
              return uVar7;
            }
LAB_001db6ac:
            param_1[2] = -1;
            return uVar7;
          }
          uVar7 = uVar7 + uVar6;
        }
        if (param_3 <= uVar7) {
          return uVar7;
        }
        if (1 < param_1[2] - 1U) {
          return uVar7;
        }
      } while( true );
    }
    uVar7 = param_1[10];
    if (param_1[0xb] != 0 || (uint)-param_1[0xb] < (uint)(param_3 < (uint)param_1[10])) {
      uVar7 = param_3;
    }
    if (*(int *)(*(int *)(iVar5 + 0x48) + 0x48) == 0) {
      uVar4 = (**(code **)(iVar5 + 0x38))
                        (*(undefined4 *)(iVar5 + 0x44),param_1[0xe],param_1[0xf],param_2,uVar7);
      if (uVar4 != uVar7) {
        if (*param_1 != 0) {
          *(undefined4 *)(*param_1 + 0x1c) = 0x14;
        }
        param_1[2] = -1;
        uVar7 = 0;
      }
      bVar2 = *(byte *)((int)param_1 + 5);
    }
    else {
      FUN_0018ae80(param_2,param_1[0x123],uVar7);
      param_1[0x123] = param_1[0x123] + uVar7;
      bVar2 = *(byte *)((int)param_1 + 5);
    }
    if ((bVar2 & 4) == 0) {
      uVar4 = ~param_1[3];
      uVar6 = uVar7;
      if (3 < uVar7) {
        uVar6 = uVar7 - 4 & 0xfffffffc;
        uVar10 = uVar7;
        pbVar9 = param_2;
        do {
          uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)*pbVar9) * 4);
          uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)pbVar9[1]) * 4);
          uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)pbVar9[2]) * 4);
          uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)pbVar9[3]) * 4);
          uVar10 = uVar10 - 4;
          pbVar9 = pbVar9 + 4;
        } while (3 < uVar10);
        param_2 = param_2 + uVar6 + 4;
        uVar6 = (uVar7 - 4) - uVar6;
      }
      for (; uVar6 != 0; uVar6 = uVar6 - 1) {
        uVar4 = uVar4 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar4 & 0xff ^ (uint)*param_2) * 4);
        param_2 = param_2 + 1;
      }
      param_1[3] = ~uVar4;
    }
    puVar1 = (uint *)(param_1 + 0xe);
    uVar4 = *puVar1;
    *puVar1 = *puVar1 + uVar7;
    param_1[0xf] = param_1[0xf] + (uint)CARRY4(uVar4,uVar7);
    *(ulonglong *)(param_1 + 10) = *(longlong *)(param_1 + 10) - (ulonglong)uVar7;
    *(ulonglong *)(param_1 + 0xc) = *(longlong *)(param_1 + 0xc) + (ulonglong)uVar7;
  }
  return uVar7;
}

