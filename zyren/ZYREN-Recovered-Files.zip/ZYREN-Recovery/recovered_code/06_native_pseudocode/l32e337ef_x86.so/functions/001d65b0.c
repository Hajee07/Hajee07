/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d65b0 FUN_001d65b0 */

undefined4
FUN_001d65b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined auVar1 [16];
  int iVar2;
  undefined4 uVar3;
  undefined local_2c [16];
  
  uVar3 = 0;
  if (param_1 != 0) {
    auVar1._4_4_ = param_1;
    auVar1._0_4_ = param_2;
    auVar1._8_8_ = 0;
    local_2c = auVar1 << 0x20;
    iVar2 = FUN_001d6270(param_3,param_4,FUN_001d6510,local_2c,param_5);
    if (iVar2 != 0) {
      uVar3 = local_2c._0_4_;
    }
  }
  return uVar3;
}

