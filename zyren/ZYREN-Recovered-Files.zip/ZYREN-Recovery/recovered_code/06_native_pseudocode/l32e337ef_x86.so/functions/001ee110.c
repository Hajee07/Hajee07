/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ee110 FUN_001ee110 */

undefined4 FUN_001ee110(int *param_1,undefined4 param_2,ushort *param_3)

{
  int iVar1;
  char cVar2;
  byte *pbVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  ushort uVar7;
  int iVar8;
  int *piVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int *piVar14;
  int *piVar15;
  byte bVar16;
  int iVar17;
  byte *pbVar18;
  int *piVar19;
  uint uVar20;
  uint uVar21;
  int iVar22;
  uint uVar23;
  int iVar24;
  uint *puVar25;
  char *pcVar26;
  int iVar27;
  int local_28;
  
  if ((((param_1[1] == 0) || (iVar8 = FUN_0018b190(param_1[1],0x2e), iVar8 == 0)) ||
      (*(char *)(iVar8 + 1) != 's')) ||
     (((*(char *)(iVar8 + 2) != 'o' || (0xd < *(byte *)(iVar8 + 3))) ||
      (((0x2401U >> (*(byte *)(iVar8 + 3) & 0x1f) & 1) == 0 ||
       (*(int *)(param_3 + 2) = *(int *)(param_3 + 2) + 1, *(short *)(param_1 + 3) == 0)))))) {
    return 0;
  }
  uVar23 = 0;
  do {
    if (*(int *)(param_1[2] + uVar23 * 0x20) == 2) {
      iVar8 = *param_1;
      pcVar26 = (char *)param_1[1];
      piVar19 = (int *)(*(int *)(param_1[2] + 8 + uVar23 * 0x20) + iVar8);
      uVar7 = *param_3;
      if ((uVar7 & 2) == 0) {
        if ((uVar7 & 1) != 0) {
          if (*pcVar26 == '/') {
            cVar2 = pcVar26[1];
            if (cVar2 == 'o') {
              if ((pcVar26[2] == 'e') && (pcVar26[3] == 'm')) {
                cVar2 = pcVar26[4];
joined_r0x001ee22c:
                if (cVar2 == '/') goto LAB_001ee400;
              }
            }
            else if (cVar2 == 'v') {
              if ((((pcVar26[2] == 'e') && (pcVar26[3] == 'n')) && (pcVar26[4] == 'd')) &&
                 ((pcVar26[5] == 'o' && (pcVar26[6] == 'r')))) goto LAB_001ee251;
            }
            else if ((((cVar2 == 's') && ((pcVar26[2] == 'y' && (pcVar26[3] == 's')))) &&
                     (pcVar26[4] == 't')) && ((pcVar26[5] == 'e' && (pcVar26[6] == 'm')))) {
LAB_001ee251:
              cVar2 = pcVar26[7];
              goto joined_r0x001ee22c;
            }
          }
          goto LAB_001ee260;
        }
      }
      else {
LAB_001ee260:
        iVar13 = *piVar19;
        if (iVar13 != 0) {
          uVar10 = *(undefined4 *)(param_3 + 8);
          piVar9 = piVar19 + 2;
          iVar17 = iVar13;
LAB_001ee280:
          if (iVar17 != 0x17) break;
          piVar6 = piVar19 + 2;
          piVar15 = piVar19;
          if (iVar13 != 6) {
            do {
              piVar14 = piVar6;
              piVar6 = piVar14 + 2;
            } while (*piVar14 != 6);
            local_28 = piVar14[1] + iVar8;
            iVar17 = iVar13;
            goto joined_r0x001ee2c6;
          }
          local_28 = piVar19[1] + iVar8;
          do {
            iVar17 = piVar15[2];
            piVar15 = piVar15 + 2;
joined_r0x001ee2c6:
          } while (iVar17 != 5);
          iVar17 = piVar15[1];
          piVar15 = piVar19;
          while (iVar13 != 2) {
            iVar13 = piVar15[2];
            piVar15 = piVar15 + 2;
            if (iVar13 == 0) goto LAB_001ee400;
          }
          if ((piVar15 != (int *)0x0) && (uVar20 = (uint)piVar15[1] >> 3, uVar20 != 0)) {
            puVar25 = (uint *)(piVar9[-1] + iVar8 + 4);
            do {
              iVar13 = FUN_0018b060(*(int *)(local_28 + (*puVar25 >> 4 & 0xfffffff0)) +
                                    iVar17 + iVar8,uVar10);
              if (iVar13 == 0) {
                piVar9 = (int *)(iVar8 + puVar25[-1]);
                if (piVar9 != (int *)0x0) {
                  if ((*(int **)(param_3 + 4) != (int *)0x0) && (*piVar9 != **(int **)(param_3 + 4))
                     ) {
                    return 1;
                  }
                  *(int **)(param_3 + 4) = piVar9;
                  if ((uVar7 & 4) != 0) {
                    if (param_3[1] == 0) {
                      param_3[1] = 1;
                      uVar10 = FUN_0018b0f0(1,4);
                      *(undefined4 *)(param_3 + 10) = uVar10;
                    }
                    else {
                      uVar7 = param_3[1] + 1;
                      param_3[1] = uVar7;
                      uVar10 = FUN_0018b200(*(undefined4 *)(param_3 + 10),(uint)uVar7 << 2);
                      *(undefined4 *)(param_3 + 10) = uVar10;
                      pcVar26 = (char *)param_1[1];
                    }
                    uVar10 = FUN_0018af40(pcVar26);
                    *(undefined4 *)(*(int *)(param_3 + 10) + -4 + (uint)param_3[1] * 4) = uVar10;
                  }
                }
                break;
              }
              puVar25 = puVar25 + 2;
              uVar20 = uVar20 - 1;
            } while (uVar20 != 0);
          }
        }
      }
LAB_001ee400:
      iVar8 = *piVar19;
      if (iVar8 != 0) {
        pbVar3 = *(byte **)(param_3 + 8);
        piVar15 = piVar19;
        piVar9 = piVar19;
        if (iVar8 == 6) {
          iVar13 = *param_1;
          iVar17 = piVar19[1] + iVar13;
        }
        else {
          do {
            piVar6 = piVar15;
            piVar15 = piVar6 + 2;
          } while (*piVar15 != 6);
          iVar13 = *param_1;
          iVar17 = piVar6[3] + iVar13;
          piVar15 = piVar19;
          if (iVar8 == 5) goto LAB_001ee459;
        }
        do {
          piVar6 = piVar9 + 2;
          piVar15 = piVar9 + 2;
          piVar9 = piVar9 + 2;
        } while (*piVar6 != 5);
LAB_001ee459:
        iVar4 = piVar15[1];
        piVar9 = piVar19;
        iVar12 = iVar8;
LAB_001ee470:
        if (iVar12 != 0x6ffffef5) goto code_r0x001ee478;
        if (piVar9 != (int *)0x0) {
          iVar8 = piVar9[1];
          iVar12 = *(int *)(iVar8 + 4 + iVar13);
          iVar5 = *(int *)(iVar8 + 8 + iVar13);
          bVar16 = *pbVar3;
          if (bVar16 == 0) {
            uVar20 = 0x1505;
          }
          else {
            uVar20 = 0x1505;
            pbVar18 = pbVar3;
            do {
              pbVar18 = pbVar18 + 1;
              uVar20 = uVar20 * 0x21 + (uint)bVar16;
              bVar16 = *pbVar18;
            } while (bVar16 != 0);
          }
          uVar21 = *(uint *)(iVar8 + 0x10 + iVar13 + (uVar20 >> 5 & iVar5 - 1U) * 4);
          if ((uVar21 >> ((byte)(uVar20 >> ((byte)*(undefined4 *)(iVar8 + 0xc + iVar13) & 0x1f)) &
                         0x1f) & uVar21 >> ((byte)uVar20 & 0x1f) & 1) != 0) {
            iVar22 = *(int *)(iVar8 + iVar13 + 0x10 + iVar5 * 4 +
                             (uVar20 % *(uint *)(iVar8 + iVar13)) * 4);
            if (iVar22 == 0) goto LAB_001ee6d0;
            iVar1 = iVar17 + 0xe + iVar22 * 0x10;
            iVar24 = *(uint *)(iVar8 + iVar13) + iVar22;
            iVar27 = 0;
            while ((((uVar21 = *(uint *)(iVar8 + iVar13 + 0x10 + ((iVar24 + iVar5) - iVar12) * 4 +
                                        iVar27), 1 < (uVar21 ^ uVar20) ||
                     (1 < (byte)((*(byte *)(iVar1 + -2 + iVar27 * 4) >> 4) - 1))) ||
                    (*(short *)(iVar1 + iVar27 * 4) == 0)) ||
                   (iVar11 = FUN_0018b060(*(int *)(iVar1 + -0xe + iVar27 * 4) + iVar4 + iVar13,
                                          pbVar3), iVar11 != 0))) {
              iVar22 = iVar22 + 1;
              iVar27 = iVar27 + 4;
              if ((uVar21 & 1) != 0) goto LAB_001ee6d0;
            }
            goto LAB_001ee6a6;
          }
          goto LAB_001ee6d0;
        }
        goto LAB_001ee4f0;
      }
LAB_001ee6d0:
      if (((*(int **)(param_3 + 4) != (int *)0x0) && (*(int *)(param_3 + 6) != 0)) &&
         (**(int **)(param_3 + 4) != *(int *)(param_3 + 6))) {
        return 1;
      }
    }
    uVar23 = uVar23 + 1;
    if (*(ushort *)(param_1 + 3) <= uVar23) {
      return 0;
    }
  } while( true );
  iVar17 = *piVar9;
  piVar9 = piVar9 + 2;
  if (iVar17 == 0) goto LAB_001ee400;
  goto LAB_001ee280;
code_r0x001ee478:
  iVar12 = piVar9[2];
  piVar9 = piVar9 + 2;
  if (iVar12 == 0) goto LAB_001ee4f0;
  goto LAB_001ee470;
LAB_001ee4f0:
  if (iVar8 != 4) goto code_r0x001ee4f5;
  if (piVar19 != (int *)0x0) {
    iVar8 = piVar19[1];
    uVar20 = *(uint *)(iVar8 + iVar13);
    bVar16 = *pbVar3;
    if (bVar16 == 0) {
      uVar21 = 0;
    }
    else {
      uVar21 = 0;
      pbVar18 = pbVar3;
      do {
        pbVar18 = pbVar18 + 1;
        uVar21 = (uint)bVar16 + uVar21 * 0x10;
        uVar21 = uVar21 >> 0x18 & 0xfffffff0 ^ uVar21 & 0xfffffff;
        bVar16 = *pbVar18;
      } while (bVar16 != 0);
    }
    iVar22 = *(int *)(iVar8 + 8 + iVar13 + (uVar21 % uVar20) * 4);
    if (iVar22 != 0) {
      do {
        iVar12 = iVar22 * 0x10;
        if ((((byte)((*(byte *)(iVar17 + 0xc + iVar12) >> 4) - 1) < 2) &&
            (*(short *)(iVar17 + 0xe + iVar12) != 0)) &&
           (iVar12 = FUN_0018b060(*(int *)(iVar17 + iVar12) + iVar4 + iVar13,pbVar3), iVar12 == 0))
        {
LAB_001ee6a6:
          iVar13 = iVar13 + *(int *)(iVar17 + 4 + iVar22 * 0x10);
          if ((iVar13 != 0) && (*(int *)(param_3 + 6) = iVar13, *param_3 == 8)) {
            return 8;
          }
          break;
        }
        iVar22 = *(int *)(iVar8 + iVar13 + 8 + uVar20 * 4 + iVar22 * 4);
      } while (iVar22 != 0);
    }
  }
  goto LAB_001ee6d0;
code_r0x001ee4f5:
  iVar8 = piVar19[2];
  piVar19 = piVar19 + 2;
  if (iVar8 == 0) goto LAB_001ee6d0;
  goto LAB_001ee4f0;
}

