/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e7e40 FUN_001e7e40 */

undefined4 FUN_001e7e40(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
                    /* try { // try from 001e7e57 to 001e7e5b has its CatchHandler @ 001e7eac */
  puVar2 = (undefined4 *)FUN_001f70e0();
  iVar1 = *param_1;
  *param_1 = 0;
                    /* try { // try from 001e7e66 to 001e7e7d has its CatchHandler @ 001e7eb4 */
  FUN_0018b350(*puVar2,iVar1);
  (*(code *)param_1[1])(0);
  iVar1 = *param_1;
  *param_1 = 0;
  if (iVar1 != 0) {
    FUN_001f7580(iVar1);
    FUN_001f5680(iVar1);
  }
  FUN_001f5680(param_1);
  return 0;
}

