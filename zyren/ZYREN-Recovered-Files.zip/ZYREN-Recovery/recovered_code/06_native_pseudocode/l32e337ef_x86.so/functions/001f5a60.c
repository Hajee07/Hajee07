/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f5a60 FUN_001f5a60 */

void FUN_001f5a60(undefined4 *param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = PTR_DAT_0024bd78 + 8;
  if ((*param_2 & 1) == 0) {
    param_2 = param_2 + 1;
  }
  else {
    param_2 = *(byte **)(param_2 + 8);
  }
  iVar1 = FUN_0018af10(param_2);
                    /* try { // try from 001f5aa5 to 001f5aac has its CatchHandler @ 001f5ae1 */
  piVar2 = (int *)FUN_001f5520(iVar1 + 0xd);
  *piVar2 = iVar1;
  piVar2[1] = iVar1;
  piVar2[2] = 0;
  FUN_0018ae80(piVar2 + 3,param_2,iVar1 + 1);
  param_1[1] = piVar2 + 3;
  return;
}

