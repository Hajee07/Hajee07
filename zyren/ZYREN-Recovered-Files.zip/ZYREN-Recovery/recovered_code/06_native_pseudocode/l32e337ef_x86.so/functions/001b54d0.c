/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b54d0 FUN_001b54d0 */

void FUN_001b54d0(int param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  longdouble lVar5;
  uint local_1c;
  
  uVar3 = 2;
  if ((param_2 != 1) && (uVar3 = param_2, (param_2 & param_2 - 1) != 0)) {
    uVar3 = FUN_001f3f10(param_2);
  }
  uVar1 = *(uint *)(param_1 + 4);
  if (uVar1 < uVar3) goto LAB_001b55c4;
  if (uVar1 <= uVar3) {
    return;
  }
  lVar5 = (longdouble)
          FUN_0018b1e0((float)((double)((ulonglong)*(uint *)(param_1 + 0xc) |
                                       (ulonglong)DAT_0021b950) - DAT_0021b950) /
                       *(float *)(param_1 + 0x10));
  local_1c = (uint)(longlong)lVar5;
  if ((uVar1 < 3) ||
     (uVar4 = uVar1 - (uVar1 >> 1 & 0x55555555),
     uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333),
     1 < ((uVar4 >> 4) + uVar4 & 0xf0f0f0f) * 0x1010101 >> 0x18)) {
    local_1c = FUN_001f3f10(local_1c);
LAB_001b55bb:
    if (uVar3 < local_1c) {
      uVar3 = local_1c;
    }
  }
  else {
    if (local_1c < 2) goto LAB_001b55bb;
    iVar2 = 0x1f;
    if (local_1c - 1 != 0) {
      for (; local_1c - 1 >> iVar2 == 0; iVar2 = iVar2 + -1) {
      }
    }
    uVar4 = 1 << (-((byte)iVar2 ^ 0x1f) & 0x1f);
    if (uVar3 < uVar4) {
      uVar3 = uVar4;
    }
  }
  if (uVar1 <= uVar3) {
    return;
  }
LAB_001b55c4:
  FUN_001b55e0(param_1,uVar3);
  return;
}

