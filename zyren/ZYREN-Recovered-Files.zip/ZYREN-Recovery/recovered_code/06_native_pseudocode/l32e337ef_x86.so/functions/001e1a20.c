/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e1a20 FUN_001e1a20 */

undefined4 FUN_001e1a20(uint *param_1)

{
  undefined4 *puVar1;
  undefined2 uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  uint local_130;
  uint local_12c;
  uint local_128;
  uint local_124;
  uint local_120;
  undefined4 local_110;
  undefined local_10c;
  undefined4 local_10b;
  undefined local_107;
  undefined local_106;
  undefined local_105;
  uint local_104;
  uint local_100 [2];
  undefined local_f8;
  undefined local_f7;
  undefined local_f6;
  undefined local_f5;
  undefined4 local_f4;
  undefined local_f0;
  undefined local_ef;
  undefined local_ee;
  undefined local_ed;
  undefined4 local_ec;
  undefined local_e8;
  undefined local_e7;
  undefined local_e6;
  undefined local_e5;
  undefined4 local_e4;
  undefined local_e0;
  undefined local_df;
  undefined local_de;
  undefined local_dd;
  undefined local_dc;
  undefined local_db;
  undefined local_da;
  undefined local_d9;
  
  uVar6 = 0x1e1a2f;
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  puVar1 = (undefined4 *)param_1[0x12];
  if ((puVar1 == (undefined4 *)0x0) || (param_1[5] != 2)) {
    param_1[7] = 0x18;
    return 0;
  }
  iVar4 = puVar1[0xd];
  if (iVar4 == 0) {
    uVar3 = param_1[4];
    if ((0xffff < uVar3) ||
       (local_12c = puVar1[1],
       param_1[1] + (uint)CARRY4(*param_1,local_12c) + (uint)(0xffffffe9 < *param_1 + local_12c) !=
       0)) goto LAB_001e1afb;
  }
  else {
    local_12c = puVar1[1];
    if (local_12c == 0xffffffff) {
LAB_001e1afb:
      param_1[7] = 2;
      return 0;
    }
    uVar3 = param_1[4];
  }
  if (uVar3 == 0) {
    local_120 = 0;
    local_124 = 0;
    local_12c = 0;
  }
  else {
    local_120 = *param_1;
    local_124 = param_1[1];
    param_1[3] = local_124;
    param_1[2] = local_120;
    uVar3 = (*(code *)param_1[0xf])(param_1[0x11],local_120,local_124,*puVar1,local_12c);
    if (uVar3 != local_12c) goto LAB_001e1ddc;
    uVar3 = *param_1;
    *param_1 = *param_1 + local_12c;
    param_1[1] = param_1[1] + (uint)CARRY4(uVar3,local_12c);
    iVar4 = puVar1[0xd];
  }
  local_130 = *param_1;
  local_128 = param_1[1];
  if (iVar4 != 0) {
    FUN_0018ae30(local_100,0,0xf0,uVar6);
    local_110 = 0x6064b50;
    local_10c = 0x2c;
    local_10b = 0;
    local_107 = 0;
    local_106 = 0;
    local_105 = 0;
    local_104 = 0x2d031e;
    uVar3 = param_1[4];
    local_f8 = (undefined)uVar3;
    local_f7 = (undefined)(uVar3 >> 8);
    local_f6 = (undefined)(uVar3 >> 0x10);
    local_f5 = (undefined)(uVar3 >> 0x18);
    local_f4 = 0;
    local_ec = 0;
    local_e8 = (undefined)local_12c;
    local_e4 = 0;
    local_e0 = (undefined)local_120;
    local_df = (undefined)(local_120 >> 8);
    local_de = (undefined)(local_120 >> 0x10);
    local_dd = (undefined)(local_120 >> 0x18);
    local_dc = (undefined)local_124;
    local_db = (undefined)(local_124 >> 8);
    local_da = (undefined)(local_124 >> 0x10);
    local_d9 = (undefined)(local_124 >> 0x18);
    local_f0 = local_f8;
    local_ef = local_f7;
    local_ee = local_f6;
    local_ed = local_f5;
    local_e7 = (char)(local_12c >> 8);
    local_e6 = (char)(local_12c >> 0x10);
    local_e5 = (char)(local_12c >> 0x18);
    iVar4 = (*(code *)param_1[0xf])(param_1[0x11],local_130,local_128,&local_110,0x38);
    if (iVar4 != 0x38) goto LAB_001e1ddc;
    uVar3 = *param_1 + 0x38;
    uVar5 = param_1[1] + (uint)(0xffffffc7 < *param_1);
    *param_1 = uVar3;
    param_1[1] = uVar5;
    FUN_0018ae30(&local_10c,0,0xfc,uVar6);
    local_110 = 0x7064b50;
    local_10b = CONCAT13((char)local_130,(undefined3)local_10b);
    local_107 = (undefined)(local_130 >> 8);
    local_106 = (undefined)(local_130 >> 0x10);
    local_105 = (undefined)(local_130 >> 0x18);
    local_100[0] = 1;
    local_104 = local_128;
    iVar4 = (*(code *)param_1[0xf])(param_1[0x11],uVar3,uVar5,&local_110,0x14);
    if (iVar4 != 0x14) goto LAB_001e1ddc;
    local_130 = *param_1 + 0x14;
    local_128 = param_1[1] + (uint)(0xffffffeb < *param_1);
    *param_1 = local_130;
    param_1[1] = local_128;
  }
  FUN_0018ae30(&local_10c,0,0xfc,uVar6);
  local_110 = 0x6054b50;
  uVar2 = 0xffff;
  if (param_1[4] < 0xffff) {
    uVar2 = (undefined2)param_1[4];
  }
  local_106 = (undefined)uVar2;
  local_10b = CONCAT13(local_106,(undefined3)local_10b);
  local_107 = (undefined)((ushort)uVar2 >> 8);
  local_100[0] = 0xffffffff;
  if (local_124 < (local_120 != 0xffffffff)) {
    local_100[0] = local_120;
  }
  local_105 = local_107;
  local_104 = local_12c;
  iVar4 = (*(code *)param_1[0xf])(param_1[0x11],local_130,local_128,&local_110,0x16);
  if (iVar4 == 0x16) {
    if ((puVar1[0xf] != 0) && (iVar4 = FUN_0018ae60(puVar1[0xf]), iVar4 == -1)) {
      param_1[7] = 0x15;
      return 0;
    }
    uVar3 = *param_1;
    *param_1 = *param_1 + 0x16;
    param_1[1] = param_1[1] + (uint)(0xffffffe9 < uVar3);
    param_1[5] = 3;
    return 1;
  }
LAB_001e1ddc:
  param_1[7] = 0x13;
  return 0;
}

