/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001abe10 FUN_001abe10 */

void FUN_001abe10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  if (DAT_0027443c == (code *)0x0) {
    iVar1 = FUN_001a91c0(param_1,param_2,param_3);
    if (iVar1 == 0) {
      iVar1 = FUN_001a83d0(param_1,param_2,param_3);
      if (iVar1 == 0) {
        iVar1 = FUN_001a9910(param_1,param_2,param_3);
        if (iVar1 == 0) {
          iVar1 = FUN_001a9510(param_1,param_2,param_3);
          if (iVar1 == 0) {
            iVar1 = FUN_001a9c90(param_1,param_2,param_3);
            if (iVar1 == 0) {
              iVar1 = FUN_001a8e70(param_1,param_2,param_3);
              if (iVar1 == 0) {
                iVar1 = FUN_001a8b30(param_1,param_2,param_3);
                if (iVar1 == 0) {
                  iVar1 = FUN_001a87d0(param_1,param_2,param_3);
                  if (iVar1 == 0) {
                    iVar1 = FUN_001a80a0(param_1,param_2,param_3);
                    if (iVar1 == 0) {
                      iVar1 = FUN_001a7d90(param_1,param_2,param_3);
                      if (iVar1 == 0) goto LAB_001abe4c;
                      iVar1 = 9;
                    }
                    else {
                      iVar1 = 8;
                    }
                  }
                  else {
                    iVar1 = 7;
                  }
                }
                else {
                  iVar1 = 6;
                }
              }
              else {
                iVar1 = 5;
              }
            }
            else {
              iVar1 = 4;
            }
          }
          else {
            iVar1 = 3;
          }
        }
        else {
          iVar1 = 2;
        }
      }
      else {
        iVar1 = 1;
      }
    }
    else {
      iVar1 = 0;
    }
    DAT_0027443c = (code *)(&PTR_FUN_00249e60)[iVar1];
  }
  else {
    iVar1 = (*DAT_0027443c)(param_1,param_2,param_3);
    if (iVar1 == 0) {
LAB_001abe4c:
                    /* WARNING: Subroutine does not return */
      FUN_0018b160();
    }
  }
  return;
}

