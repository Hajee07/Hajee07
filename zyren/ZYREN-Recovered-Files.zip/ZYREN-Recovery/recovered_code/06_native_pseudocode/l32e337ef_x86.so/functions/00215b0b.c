/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00215b0b FUN_00215b0b */

int FUN_00215b0b(undefined4 param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint local_14;
  uint local_10;
  
  uVar1 = FUN_002159dc();
  FUN_00215a60(param_2 + 8,&local_14,uVar1,uVar1);
  FUN_00215a60(param_3 + 8,&local_10);
  iVar2 = 1;
  if (local_14 <= local_10) {
    iVar2 = -(uint)(local_14 < local_10);
  }
  return iVar2;
}

