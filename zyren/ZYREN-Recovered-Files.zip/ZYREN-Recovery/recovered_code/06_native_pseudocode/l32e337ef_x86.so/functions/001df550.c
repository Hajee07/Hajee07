/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001df550 FUN_001df550 */

undefined4
FUN_001df550(uint *param_1,char *param_2,code *param_3,undefined4 param_4,uint param_5,uint param_6,
            undefined4 *param_7,int param_8,ushort param_9,uint param_10,undefined4 param_11,
            undefined4 param_12,uint param_13,undefined4 param_14,uint param_15)

{
  undefined2 uVar1;
  undefined uVar2;
  undefined uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  byte *pbVar7;
  code **ppcVar8;
  bool bVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined uVar14;
  int iVar13;
  uint uVar15;
  uint uVar16;
  byte *pbVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint *puVar22;
  bool bVar23;
  char cVar24;
  uint local_10b8;
  uint local_10b4;
  uint local_10b0;
  uint local_10a8;
  uint local_10a4;
  uint local_10a0;
  uint local_1098;
  uint local_1094;
  uint local_1090;
  uint local_108c;
  uint local_1088;
  uint *local_1080;
  uint local_107c;
  uint local_1078;
  undefined4 local_1074;
  uint local_1070;
  uint local_106c;
  uint local_1068;
  uint local_1064;
  uint local_1060;
  uint *local_105c;
  uint local_1058;
  uint local_1054;
  undefined4 local_1050;
  uint local_104c;
  undefined local_1048;
  undefined local_1047;
  undefined local_1046;
  uint local_1044;
  uint local_1040;
  uint local_103c;
  uint local_1038;
  uint local_1034;
  uint local_1030;
  uint local_102c [4];
  undefined4 local_101c;
  undefined uStack_1018;
  undefined uStack_1017;
  undefined uStack_1016;
  undefined uStack_1015;
  undefined uStack_1014;
  undefined uStack_1013;
  undefined uStack_1012;
  undefined uStack_1011;
  undefined uStack_1010;
  undefined uStack_100f;
  undefined uStack_100e;
  undefined uStack_100d;
  undefined uStack_100c;
  undefined uStack_100b;
  undefined uStack_100a;
  undefined uStack_1009;
  undefined local_1008;
  undefined uStack_1007;
  undefined uStack_1006;
  undefined uStack_1005;
  undefined local_1004;
  undefined local_1003;
  undefined4 local_1002;
  
  uVar10 = ~(param_10 >> 0xe) & 8;
  local_1088 = 0;
  local_108c = 0;
  local_1090 = 0;
  local_1094 = 0;
  uVar16 = uVar10 + 0x800;
  if ((param_10 & 0x10000) != 0) {
    uVar16 = uVar10;
  }
  local_1070 = 6;
  if (-1 < (int)param_10) {
    local_1070 = param_10;
  }
  if (param_1 == (uint *)0x0) {
    return 0;
  }
  uVar10 = param_1[0x12];
  if ((((uVar10 == 0) || (param_2 == (char *)0x0)) || (param_1[5] != 2)) ||
     ((param_8 == 0 && param_9 != 0 || (uVar4 = local_1070 & 0xf, 10 < uVar4)))) {
LAB_001df66d:
    param_1[7] = 0x18;
    return 0;
  }
  uVar12 = *param_1;
  uVar11 = param_1[1];
  local_1074 = *(uint *)(uVar10 + 0x34);
  if ((param_6 != 0) && (local_1074 == 0)) {
    *(undefined4 *)(uVar10 + 0x34) = 1;
    local_1074 = 1;
  }
  if ((local_1070 & 0x400) != 0) goto LAB_001df66d;
  if (*param_2 == '/') {
LAB_001df6b1:
    param_1[7] = 0x19;
    return 0;
  }
  if (local_1074 == 0) {
    local_1074 = 0;
    if (param_1[4] == 0xffff) {
      *(undefined4 *)(uVar10 + 0x34) = 1;
      local_1074 = 1;
    }
  }
  else if (param_1[4] == 0xffffffff) {
    param_1[7] = 2;
    return 0;
  }
  uVar5 = FUN_0018af10(param_2);
  if (0xffff < uVar5) goto LAB_001df6b1;
  uVar15 = param_1[8];
  local_1098 = 0;
  if ((param_1[9] | uVar15) != 0) {
    local_1098 = uVar15 - (uVar15 - 1 & uVar12) & uVar15 - 1;
  }
  uVar15 = *(uint *)(uVar10 + 4);
  local_1040 = (uint)param_9;
  uVar18 = local_1040 + uVar5 + uVar15;
  iVar13 = (uint)CARRY4(local_1040,uVar5) + (uint)CARRY4(local_1040 + uVar5,uVar15) +
           (uint)(0xffffffb5 < uVar18);
  if (iVar13 != 0 || (uint)-iVar13 < (uint)(0xfffffffe < uVar18 + 0x4a)) {
    param_1[7] = 0xf;
    return 0;
  }
  if ((local_1074 == 0) &&
     (uVar18 = local_1040 + param_13 + param_15, uVar19 = uVar18 + uVar12,
     uVar20 = uVar19 + uVar5 * 2, uVar21 = uVar20 + local_1098,
     (((uint)CARRY4(local_1040,param_13) + (uint)CARRY4(local_1040 + param_13,param_15) + uVar11 +
      (uint)CARRY4(uVar18,uVar12)) - ((int)uVar5 >> 0x1f)) + (uint)CARRY4(uVar19,uVar5 * 2) +
     (uint)CARRY4(uVar20,local_1098) + (uint)CARRY4(uVar21,uVar15) +
     (uint)(0xfffffb8d < uVar21 + uVar15) != 0)) {
    *(undefined4 *)(uVar10 + 0x34) = 1;
  }
  if (param_7 == (undefined4 *)0x0) {
    local_1060 = 0;
    local_1064 = 0;
  }
  else {
    local_101c = *param_7;
    puVar6 = (uint *)FUN_0018b2f0(&local_101c);
    local_1060 = (*puVar6 >> 1) + puVar6[1] * 0x20 + puVar6[2] * 0x800;
    local_1064 = puVar6[3] + 0x6020 + puVar6[4] * 0x20 + puVar6[5] * 0x200;
  }
  if (param_6 < (param_5 < 4)) {
    uVar4 = 0;
  }
  uVar15 = 0x1000;
  if (local_1098 < 0x1000) {
    uVar15 = local_1098;
  }
  FUN_0018ae30(&local_101c,0,uVar15);
  uVar19 = uVar12;
  local_107c = uVar11;
  uVar15 = local_1098;
  uVar18 = local_1074;
  while (local_1074 = uVar19, uVar15 != 0) {
    uVar18 = 0x1000;
    if (uVar15 < 0x1000) {
      uVar18 = uVar15;
    }
    uVar19 = (*(code *)param_1[0xf])(param_1[0x11],local_1074,local_107c,&local_101c,uVar18);
    if (uVar19 != uVar18) goto LAB_001e0930;
    local_107c = local_107c + CARRY4(local_1074,uVar18);
    uVar15 = uVar15 - uVar18;
    uVar19 = local_1074 + uVar18;
    uVar18 = local_1074;
  }
  uVar15 = uVar12 + local_1098;
  uVar11 = uVar11 + CARRY4(uVar12,local_1098);
  bVar23 = (param_5 | param_6) != 0;
  bVar9 = uVar4 != 0 && bVar23;
  local_1074 = CONCAT31((int3)(uVar18 >> 8),bVar9);
  local_107c = (uint)bVar9 << 3;
  local_101c = 0;
  uStack_1018 = 0;
  uStack_1017 = 0;
  uStack_1016 = 0;
  uStack_1015 = 0;
  uStack_1014 = 0;
  uStack_1013 = 0;
  uStack_1012 = 0;
  uStack_1011 = 0;
  uStack_1010 = 0;
  uStack_100f = 0;
  uStack_100e = 0;
  uStack_100d = 0;
  local_1008 = 0;
  uStack_1007 = 0;
  uStack_100c = 0;
  uStack_100b = 0;
  uStack_100a = 0;
  uStack_1009 = 0;
  local_1002 = 0;
  uStack_1006 = 0;
  uStack_1005 = 0;
  local_1004 = 0;
  local_1003 = 0;
  uVar3 = (undefined)uVar16;
  uVar14 = (undefined)(uVar16 >> 8);
  uVar1 = (undefined2)uVar5;
  local_106c = uVar15;
  local_1068 = uVar11;
  if (*(int *)(uVar10 + 0x34) == 0) {
    if ((local_1090 | uVar11) != 0) {
      param_1[7] = 0x1d;
      return 0;
    }
    local_101c = 0x4034b50;
    uStack_1018 = 0x14;
    if (uVar4 == 0 || !bVar23) {
      uStack_1018 = 0;
    }
    uStack_1017 = 0;
    uStack_1014 = (undefined)local_107c;
    uStack_1013 = 0;
    uStack_1012 = (undefined)local_1060;
    uStack_1011 = (undefined)(local_1060 >> 8);
    uStack_1010 = (undefined)local_1064;
    uStack_100f = (undefined)(local_1064 >> 8);
    uStack_100a = 0;
    uStack_1009 = 0;
    local_1008 = 0;
    uStack_1007 = 0;
    uStack_100e = 0;
    uStack_100d = 0;
    uStack_100c = 0;
    uStack_100b = 0;
    uStack_1006 = 0;
    uStack_1005 = 0;
    local_1004 = 0;
    local_1003 = 0;
    local_1002 = CONCAT13((char)(param_13 >> 8),CONCAT12((char)param_13,uVar1));
    uStack_1016 = uVar3;
    uStack_1015 = uVar14;
    iVar13 = (*(code *)param_1[0xf])(param_1[0x11],uVar15,uVar11,&local_101c,0x1e);
    if (iVar13 != 0x1e) {
LAB_001dfdc6:
      param_1[7] = 0x13;
      return 0;
    }
    uVar15 = uVar15 + 0x1e;
    iVar13 = uVar11 + (0xffffffe1 < uVar15);
    uVar10 = (*(code *)param_1[0xf])(param_1[0x11],uVar15,iVar13,param_2,uVar5);
    if (uVar10 != uVar5) goto LAB_001dfdc6;
    local_10b8 = uVar15 + uVar5;
    local_10b4 = iVar13 + (uint)CARRY4(uVar15,uVar5);
    local_1080 = (uint *)0x0;
    local_10a8 = 0;
    if (param_13 != 0) goto LAB_001dff77;
LAB_001dfb22:
    if ((param_5 | param_6) == 0) goto LAB_001dffca;
LAB_001dfb37:
    pbVar7 = (byte *)(*(code *)param_1[10])(param_1[0xd],1,0x2000);
    if (pbVar7 == (byte *)0x0) {
LAB_001e0415:
      param_1[7] = 0x10;
      return 0;
    }
    if (uVar4 == 0) {
      uVar10 = (*param_3)(param_4,0,0,pbVar7,0x2000);
      if (uVar10 == 0) {
        local_10a4 = 0;
        local_10a0 = 0;
        local_10b0 = 0;
      }
      else {
        local_10b0 = 0;
        local_10a4 = 0;
        local_10a0 = 0;
        do {
          if (0x2000 < uVar10) {
LAB_001e04ed:
            (*(code *)param_1[0xb])(param_1[0xd],pbVar7);
            param_1[7] = 0x14;
            return 0;
          }
          bVar9 = CARRY4(local_10a4,uVar10);
          local_10a4 = local_10a4 + uVar10;
          local_10a0 = local_10a0 + bVar9;
          local_1078 = uVar10;
          if (param_6 < local_10a0 || param_6 - local_10a0 < (uint)(param_5 < local_10a4))
          goto LAB_001e04ed;
          uVar4 = (*(code *)param_1[0xf])(param_1[0x11],local_10b8,local_10b4,pbVar7,uVar10);
          if (uVar4 != uVar10) {
            (*(code *)param_1[0xb])(param_1[0xd],pbVar7);
            param_1[7] = 0x13;
            return 0;
          }
          local_10b0 = ~local_10b0;
          pbVar17 = pbVar7;
          if (uVar10 < 4) {
LAB_001e037e:
            do {
              local_10b0 = local_10b0 >> 8 ^
                           *(uint *)(&DAT_0021e588 + (local_10b0 & 0xff ^ (uint)*pbVar17) * 4);
              uVar10 = uVar10 - 1;
              pbVar17 = pbVar17 + 1;
            } while (uVar10 != 0);
          }
          else {
            uVar4 = uVar10 - 4;
            local_103c = uVar4 & 0xfffffffc;
            do {
              uVar12 = local_10b0 >> 8 ^
                       *(uint *)(&DAT_0021e588 + (local_10b0 & 0xff ^ (uint)*pbVar17) * 4);
              uVar12 = uVar12 >> 8 ^
                       *(uint *)(&DAT_0021e588 + (uVar12 & 0xff ^ (uint)pbVar17[1]) * 4);
              uVar12 = uVar12 >> 8 ^
                       *(uint *)(&DAT_0021e588 + (uVar12 & 0xff ^ (uint)pbVar17[2]) * 4);
              local_10b0 = uVar12 >> 8 ^
                           *(uint *)(&DAT_0021e588 + (uVar12 & 0xff ^ (uint)pbVar17[3]) * 4);
              uVar10 = uVar10 - 4;
              pbVar17 = pbVar17 + 4;
            } while (3 < uVar10);
            uVar10 = uVar4 - local_103c;
            if (uVar10 != 0) {
              pbVar17 = pbVar7 + local_103c + 4;
              goto LAB_001e037e;
            }
          }
          local_10b0 = ~local_10b0;
          bVar9 = CARRY4(local_10b8,local_1078);
          local_10b8 = local_10b8 + local_1078;
          local_10b4 = local_10b4 + bVar9;
          uVar10 = (*param_3)(param_4,local_10a4,local_10a0,pbVar7,0x2000);
        } while (uVar10 != 0);
      }
      local_108c = local_10a4;
      local_1088 = local_10a0;
      local_1094 = local_10a4;
      local_1090 = local_10a0;
    }
    else {
      ppcVar8 = (code **)(*(code *)param_1[10])(param_1[0xd],1,&LAB_0004df40);
      if (ppcVar8 == (code **)0x0) {
        (*(code *)param_1[0xb])(param_1[0xd],pbVar7);
        goto LAB_001e0415;
      }
      local_105c = param_1;
      local_1058 = local_10b8;
      local_1054 = local_10b4;
      local_104c = 0;
      local_1050 = 0;
      uVar10 = 10;
      if (uVar4 < 10) {
        uVar10 = uVar4;
      }
      uVar10 = *(uint *)(&DAT_0021e988 + uVar10 * 4);
      uVar4 = (uint)(uVar4 < 4) << 0xe;
      *ppcVar8 = FUN_001deef0;
      ppcVar8[1] = (code *)&local_105c;
      ppcVar8[2] = (code *)(uVar4 | uVar10);
      ppcVar8[3] = (code *)(((uVar10 & 0xfff) * 0xaaab + 0x15556 >> 0x11) + 1);
      ppcVar8[5] = (code *)((uVar4 | uVar10 & 0x4000) >> 0xe);
      ppcVar8[4] = (code *)((((uVar10 & 0xfff) >> 2) * 0xaaab + 0x15556 >> 0x11) + 1);
      if (-1 < (short)uVar10) {
        FUN_0018ae30(&DAT_00029272 + (int)ppcVar8,0,0x10000);
      }
      ppcVar8[9] = (code *)0x0;
      ppcVar8[8] = (code *)0x0;
      ppcVar8[7] = (code *)0x0;
      ppcVar8[0x10] = (code *)0x0;
      ppcVar8[0xf] = (code *)0x0;
      ppcVar8[0x12] = (code *)0x0;
      ppcVar8[0x11] = (code *)0x0;
      ppcVar8[0x17] = (code *)0x0;
      ppcVar8[0x16] = (code *)0x0;
      ppcVar8[0x19] = (code *)0x0;
      ppcVar8[0x18] = (code *)0x0;
      ppcVar8[0x1a] = (code *)0x0;
      ppcVar8[10] = (code *)((int)ppcVar8 + 0x9273);
      ppcVar8[0xb] = (code *)((int)ppcVar8 + 0x9272);
      *(undefined *)((int)ppcVar8 + 0x9272) = 0;
      ppcVar8[0xe] = (code *)0x8;
      ppcVar8[0xc] = (code *)(&DAT_00039272 + (int)ppcVar8);
      ppcVar8[0xd] = (code *)(&DAT_00039272 + (int)ppcVar8);
      ppcVar8[0x1b] = (code *)0x0;
      ppcVar8[0x15] = (code *)0x0;
      ppcVar8[0x14] = (code *)0x0;
      ppcVar8[0x13] = (code *)0x0;
      ppcVar8[6] = (code *)0x1;
      ppcVar8[0x22] = (code *)0x0;
      ppcVar8[0x23] = (code *)0x0;
      ppcVar8[0x20] = (code *)0x0;
      ppcVar8[0x21] = (code *)0x0;
      ppcVar8[0x1e] = (code *)0x0;
      ppcVar8[0x1f] = (code *)0x0;
      ppcVar8[0x1c] = (code *)0x0;
      ppcVar8[0x1d] = (code *)0x0;
      if (-1 < (short)uVar10) {
        FUN_0018ae30(ppcVar8 + 0x24,0,0x8101);
      }
      FUN_0018ae30((int)ppcVar8 + 0x8192,0,0x280);
      local_10b0 = 0;
      local_10b4 = 0;
      local_10b8 = 0;
      do {
        uVar10 = (*param_3)(param_4,local_10b8,local_10b4,pbVar7,0x2000);
        local_1078 = 0x14;
        if (0x2000 < uVar10) goto LAB_001e0513;
        uVar12 = local_10b8 + uVar10;
        uVar4 = local_10b4 + CARRY4(local_10b8,uVar10);
        if (param_6 < uVar4 || param_6 - uVar4 < (uint)(param_5 < uVar12)) goto LAB_001e0513;
        local_10b0 = ~local_10b0;
        pbVar17 = pbVar7;
        uVar11 = uVar10;
        if (3 < uVar10) {
          local_1078 = uVar10 - 4 & 0xfffffffc;
          do {
            uVar15 = local_10b0 >> 8 ^
                     *(uint *)(&DAT_0021e588 + (local_10b0 & 0xff ^ (uint)*pbVar17) * 4);
            uVar15 = uVar15 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar15 & 0xff ^ (uint)pbVar17[1]) * 4)
            ;
            uVar15 = uVar15 >> 8 ^ *(uint *)(&DAT_0021e588 + (uVar15 & 0xff ^ (uint)pbVar17[2]) * 4)
            ;
            local_10b0 = uVar15 >> 8 ^
                         *(uint *)(&DAT_0021e588 + (uVar15 & 0xff ^ (uint)pbVar17[3]) * 4);
            uVar11 = uVar11 - 4;
            pbVar17 = pbVar17 + 4;
          } while (3 < uVar11);
          pbVar17 = pbVar7 + local_1078 + 4;
          uVar11 = (uVar10 - 4) - local_1078;
        }
        for (; uVar11 != 0; uVar11 = uVar11 - 1) {
          local_10b0 = local_10b0 >> 8 ^
                       *(uint *)(&DAT_0021e588 + (local_10b0 & 0xff ^ (uint)*pbVar17) * 4);
          pbVar17 = pbVar17 + 1;
        }
        if ((code *)param_1[0x10] == (code *)0x0) {
          cVar24 = '\0';
        }
        else {
          iVar13 = (*(code *)param_1[0x10])(param_1[0x11]);
          cVar24 = (iVar13 != 0) * '\x03';
        }
        local_1044 = uVar10;
        if (uVar10 == 0) {
          local_1044 = 0;
          cVar24 = '\x04';
        }
        iVar13 = FUN_001d1b10(ppcVar8,pbVar7,&local_1044,0,0,cVar24);
        local_10b0 = ~local_10b0;
        local_10b4 = uVar4;
        local_10b8 = uVar12;
      } while (iVar13 == 0);
      local_1078 = 0xc;
      if (iVar13 == 1) {
        bVar9 = false;
      }
      else {
LAB_001e0513:
        param_1[7] = local_1078;
        bVar9 = true;
      }
      (*(code *)param_1[0xb])(param_1[0xd],ppcVar8);
      if (bVar9) {
        (*(code *)param_1[0xb])(param_1[0xd],pbVar7);
        return 0;
      }
      local_108c = local_10b8;
      local_1088 = local_10b4;
      local_1090 = local_104c;
      local_1094 = local_1050;
      local_10b8 = local_1058;
      local_10b4 = local_1054;
    }
    (*(code *)param_1[0xb])(param_1[0xd],pbVar7);
    if ((local_1070 & 0x20000) == 0) goto LAB_001dffe0;
LAB_001e05c0:
    if (local_1080 != (uint *)0x0) {
      puVar6 = &local_1094;
      if (param_6 == 0 && (uint)(0xfffffffe < param_5) <= -param_6) {
        puVar6 = (uint *)0x0;
      }
      puVar22 = &local_106c;
      if (local_1068 == 0 && (uint)(0xfffffffe < local_106c) <= -local_1068) {
        puVar22 = (uint *)0x0;
      }
      local_10a8 = FUN_001dee80(puVar6,puVar22);
    }
    uVar4 = local_1068;
    uVar10 = local_106c;
    local_1070 = 0xffffffff;
    uStack_1018 = 0;
    if (param_6 == 0 && (uint)(0xfffffffe < param_5) <= -param_6) {
      local_10a4 = local_1088;
      uVar12 = local_1094;
      uVar11 = local_108c;
      uVar15 = local_1090;
    }
    else {
      uVar15 = 0;
      uVar12 = 0xffffffff;
      local_10a4 = 0;
      uVar11 = uVar12;
    }
    if ((char)local_1074 != '\0') {
      uStack_1018 = 0x14;
    }
    local_101c = 0x4034b50;
    uStack_1017 = 0;
    uStack_1014 = (undefined)local_107c;
    uStack_1013 = 0;
    uStack_1012 = (undefined)local_1060;
    uStack_1011 = (undefined)(local_1060 >> 8);
    uStack_1010 = (undefined)local_1064;
    uStack_100f = (undefined)(local_1064 >> 8);
    uStack_100e = (undefined)local_10b0;
    uStack_100d = (undefined)(local_10b0 >> 8);
    uStack_100c = (undefined)(local_10b0 >> 0x10);
    uStack_100b = (undefined)(local_10b0 >> 0x18);
    if ((uVar12 != 0xffffffff) <= uVar15) {
      uVar12 = 0xffffffff;
    }
    uStack_100a = (undefined)uVar12;
    uStack_1009 = (undefined)(uVar12 >> 8);
    local_1008 = (undefined)(uVar12 >> 0x10);
    uStack_1007 = (undefined)(uVar12 >> 0x18);
    uVar12 = 0xffffffff;
    if (local_10a4 < (uVar11 != 0xffffffff)) {
      uVar12 = uVar11;
    }
    uStack_1006 = (undefined)uVar12;
    uStack_1005 = (undefined)(uVar12 >> 8);
    local_1004 = (undefined)(uVar12 >> 0x10);
    local_1003 = (undefined)(uVar12 >> 0x18);
    local_1002 = CONCAT13((char)(param_13 + local_10a8 >> 8),
                          CONCAT12((char)(param_13 + local_10a8),uVar1));
    uStack_1016 = uVar3;
    uStack_1015 = uVar14;
    iVar13 = (*(code *)param_1[0xf])(param_1[0x11],local_106c,local_1068,&local_101c,0x1e);
    if (iVar13 != 0x1e) {
LAB_001e0930:
      param_1[7] = 0x13;
      return 0;
    }
    if (local_1080 == (uint *)0x0) goto LAB_001e0883;
    uVar12 = uVar10 + 0x1e;
    iVar13 = uVar4 + (0xffffffe1 < uVar10);
    uVar10 = (*(code *)param_1[0xf])(param_1[0x11],uVar12,iVar13,param_2,uVar5);
    if ((uVar10 != uVar5) ||
       (uVar10 = (*(code *)param_1[0xf])
                           (param_1[0x11],uVar12 + uVar5,iVar13 + (uint)CARRY4(uVar12,uVar5),
                            &local_1038,local_10a8), uVar10 != local_10a8)) goto LAB_001e0930;
  }
  else {
    local_10a8 = 0;
    if ((param_6 != 0 || -param_6 < (uint)(0xfffffffe < param_5)) ||
       (local_1080 = (uint *)0x0, uVar11 != 0 || -uVar11 < (uint)(0xfffffffe < uVar15))) {
      if ((local_1070 & 0x20000) == 0) {
        uVar2 = 0;
        if (uVar11 == 0 && (uint)(0xfffffffe < uVar15) <= -uVar11) {
          puVar6 = &local_1034;
        }
        else {
          uVar2 = 8;
          puVar6 = local_102c;
          local_1034 = uVar15;
          local_1030 = uVar11;
        }
        local_1080 = &local_1038;
        local_1038 = (uint)CONCAT12(uVar2,1);
        local_10a8 = (int)puVar6 - (int)local_1080;
      }
      else {
        puVar6 = &local_1094;
        if (param_6 == 0 && (uint)(0xfffffffe < param_5) <= -param_6) {
          puVar6 = (uint *)0x0;
        }
        puVar22 = &local_106c;
        if (uVar11 == 0 && (uint)(0xfffffffe < uVar15) <= -uVar11) {
          puVar22 = (uint *)0x0;
        }
        local_1080 = &local_1038;
        local_10a8 = FUN_001dee80(puVar6,puVar22);
      }
    }
    local_101c = 0x4034b50;
    uStack_1018 = 0x14;
    if ((char)local_1074 == '\0') {
      uStack_1018 = 0;
    }
    uStack_1017 = 0;
    uStack_1014 = (undefined)local_107c;
    uStack_1013 = 0;
    uStack_1012 = (undefined)local_1060;
    uStack_1011 = (undefined)(local_1060 >> 8);
    uStack_1010 = (undefined)local_1064;
    uStack_100f = (undefined)(local_1064 >> 8);
    uStack_100a = 0;
    uStack_1009 = 0;
    local_1008 = 0;
    uStack_1007 = 0;
    uStack_100e = 0;
    uStack_100d = 0;
    uStack_100c = 0;
    uStack_100b = 0;
    uStack_1006 = 0;
    uStack_1005 = 0;
    local_1004 = 0;
    local_1003 = 0;
    local_1002 = CONCAT13((char)(local_10a8 + param_13 >> 8),
                          CONCAT12((char)(local_10a8 + param_13),uVar1));
    uStack_1016 = uVar3;
    uStack_1015 = uVar14;
    iVar13 = (*(code *)param_1[0xf])(param_1[0x11],uVar15,uVar11,&local_101c,0x1e);
    if (iVar13 != 0x1e) {
LAB_001e0064:
      param_1[7] = 0x13;
      return 0;
    }
    uVar15 = uVar15 + 0x1e;
    iVar13 = uVar11 + (0xffffffe1 < uVar15);
    uVar10 = (*(code *)param_1[0xf])(param_1[0x11],uVar15,iVar13,param_2,uVar5);
    if (uVar10 != uVar5) goto LAB_001e0064;
    uVar12 = uVar15 + uVar5;
    iVar13 = iVar13 + (uint)CARRY4(uVar15,uVar5);
    uVar10 = (*(code *)param_1[0xf])(param_1[0x11],uVar12,iVar13,&local_1038,local_10a8);
    if (uVar10 != local_10a8) goto LAB_001e0064;
    local_10b8 = uVar12 + local_10a8;
    local_10b4 = iVar13 + (uint)CARRY4(uVar12,local_10a8);
    if (param_13 == 0) goto LAB_001dfb22;
LAB_001dff77:
    uVar10 = (*(code *)param_1[0xf])(param_1[0x11],local_10b8,local_10b4,param_12,param_13);
    if (uVar10 != param_13) {
      param_1[7] = 0x13;
      return 0;
    }
    bVar9 = CARRY4(local_10b8,param_13);
    local_10b8 = local_10b8 + param_13;
    local_10b4 = local_10b4 + bVar9;
    if ((param_5 | param_6) != 0) goto LAB_001dfb37;
LAB_001dffca:
    local_10b0 = 0;
    if ((local_1070 & 0x20000) != 0) goto LAB_001e05c0;
LAB_001dffe0:
    local_105c = (uint *)0x8074b50;
    local_1058 = local_10b0;
    uVar3 = (undefined)(local_108c >> 0x18);
    if (local_1080 == (uint *)0x0) {
      if (local_1090 != 0) {
        param_1[7] = 0x1d;
        return 0;
      }
      uVar10 = 0x10;
      iVar13 = 0xf;
    }
    else {
      local_1050 = local_1090;
      local_104c = local_108c;
      local_1048 = (undefined)local_1088;
      local_1047 = (undefined)(local_1088 >> 8);
      local_1046 = (undefined)(local_1088 >> 0x10);
      uVar3 = (undefined)(local_1088 >> 0x18);
      uVar10 = 0x18;
      iVar13 = 0x17;
    }
    local_1054 = local_1094;
    *(undefined *)((int)&local_105c + iVar13) = uVar3;
    uVar4 = (*(code *)param_1[0xf])(param_1[0x11],local_10b8,local_10b4,&local_105c,uVar10);
    if (uVar4 != uVar10) {
      return 0;
    }
    bVar9 = CARRY4(local_10b8,uVar10);
    local_10b8 = local_10b8 + uVar10;
    local_10b4 = local_10b4 + bVar9;
    if (local_1080 == (uint *)0x0) goto LAB_001e0883;
  }
  puVar6 = &local_1094;
  if (local_1088 == 0 && (uint)(0xfffffffe < local_108c) <= -local_1088) {
    puVar6 = (uint *)0x0;
  }
  puVar22 = &local_106c;
  if (local_1068 == 0 && (uint)(0xfffffffe < local_106c) <= -local_1068) {
    puVar22 = (uint *)0x0;
  }
  local_10a8 = FUN_001dee80(puVar6,puVar22);
LAB_001e0883:
  iVar13 = FUN_001def60(uVar5 & 0xffff,local_1080,local_10a8 & 0xffff,param_8,local_1040,local_108c,
                        local_1088,local_1094,local_1090,local_10b0,local_107c & 0xffff,uVar16,
                        local_1060 & 0xffff,local_1064 & 0xffff,local_106c,local_1068,param_11,
                        param_14,param_15);
  if (iVar13 == 0) {
    return 0;
  }
  param_1[4] = param_1[4] + 1;
  *param_1 = local_10b8;
  param_1[1] = local_10b4;
  return 1;
}

