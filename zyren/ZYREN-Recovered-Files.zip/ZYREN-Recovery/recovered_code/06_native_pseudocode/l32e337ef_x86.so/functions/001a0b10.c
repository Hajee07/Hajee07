/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a0b10 FUN_001a0b10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_001a0b10(undefined4 param_1,undefined4 *param_2,uint param_3)

{
  undefined *puVar1;
  undefined *puVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  code *pcVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  bool bVar17;
  bool bVar18;
  undefined4 *puVar19;
  int local_16c;
  undefined local_15c [16];
  undefined local_14c [16];
  uint local_13c;
  uint local_138;
  undefined local_12c [16];
  undefined4 local_11c;
  undefined8 local_118;
  undefined8 local_110;
  undefined4 local_108;
  int local_104;
  int local_100;
  undefined4 *local_fc;
  uint local_f8;
  
  local_14c = ZEXT816(0);
  local_15c = ZEXT816(0);
  local_138 = 0;
  local_13c = 0;
  cVar3 = FUN_0019af90(param_1,local_15c);
  if (cVar3 == '\0') {
    uVar6 = (**(code **)PTR_DAT_0024bba0)(param_1,param_2,param_3);
  }
  else {
    if (*(code **)PTR_DAT_0024bb3c == (code *)0x0) {
      iVar4 = FUN_0018afb0(param_1,2,0x100);
    }
    else {
      iVar4 = (**(code **)PTR_DAT_0024bb3c)(param_1,2,0x100,0,0,0,0,0,0,0,0,0,0);
    }
    if (iVar4 == -1) {
      uVar6 = 0;
    }
    else {
      uVar12 = local_14c._4_4_;
      uVar9 = (int)param_2 - 1;
      iVar11 = (param_3 - 1) + (uint)(param_2 != (undefined4 *)0x0);
      if ((int)local_14c._4_4_ < 1) {
        uVar15 = 0xffffffff;
        iVar10 = -1;
        iVar5 = -1;
      }
      else {
        uVar15 = 0;
        iVar5 = FUN_0021376e(uVar9,iVar11,local_14c._4_4_,(int)local_14c._4_4_ >> 0x1f);
        iVar10 = 0;
      }
      uVar6 = (undefined4)((ulonglong)uVar15 * (ulonglong)uVar12);
      iVar10 = iVar10 * uVar12 + (int)((ulonglong)uVar15 * (ulonglong)uVar12 >> 0x20);
      uVar12 = ((iVar5 - uVar15) + 1) * uVar12;
      uVar15 = (uint)(uVar12 < local_13c);
      bVar18 = SBORROW4(-local_138,uVar15) != false;
      bVar17 = (int)(-local_138 - uVar15) < 0;
      if (bVar18 == bVar17) {
        uVar12 = local_13c;
      }
      local_16c = 0;
      uVar15 = local_138;
      if (bVar18 != bVar17) {
        uVar15 = 0;
      }
      iVar5 = FUN_0018add0(uVar12);
      FUN_0018ae30(iVar5,0,uVar12);
      if ((uVar12 | uVar15) != 0) {
        if (*(code **)PTR_DAT_0024bb54 == (code *)0x0) {
          iVar7 = FUN_0018aff0(iVar4,iVar5,uVar12,uVar6);
        }
        else {
          iVar7 = (**(code **)PTR_DAT_0024bb54)(iVar4,iVar5,uVar12,uVar6,iVar10);
        }
        if (0 < iVar7) {
          FUN_0018ae30(&local_11c,0,0x108);
          puVar1 = PTR_DAT_0024bb38;
          thunk_FUN_0005e980(&local_11c,PTR_DAT_0024bb38,0x10);
          iVar7 = iVar5;
          uVar13 = uVar12;
          if ((SBORROW4(-uVar15,(uint)((uint)local_14c._4_4_ < uVar12)) != false) !=
              (int)(-uVar15 - (uint)((uint)local_14c._4_4_ < uVar12)) < 0) {
            iVar14 = 0;
            uVar16 = uVar15;
            do {
              FUN_001b5e90(&local_11c,iVar7,iVar7,local_14c._4_4_);
              bVar17 = uVar13 < (uint)local_14c._4_4_;
              uVar13 = uVar13 - local_14c._4_4_;
              uVar16 = uVar16 - bVar17;
              iVar14 = iVar14 + local_14c._4_4_;
              FUN_0018ae30(&local_11c,0,0x108);
              thunk_FUN_0005e980(&local_11c,puVar1,0x10);
              iVar7 = iVar5 + iVar14;
            } while ((SBORROW4(-uVar16,(uint)((uint)local_14c._4_4_ < uVar13)) != false) !=
                     (int)(-uVar16 - (uint)((uint)local_14c._4_4_ < uVar13)) < 0);
          }
          FUN_001b5e90(&local_11c,iVar7,iVar7,uVar13);
        }
      }
      FUN_0018ae30(&local_11c,0,0x108);
      puVar1 = PTR_DAT_0024bb38;
      thunk_FUN_0005e980(&local_11c,PTR_DAT_0024bb38,0x10);
      iVar7 = iVar5;
      if ((SBORROW4(-uVar15,(uint)((uint)local_14c._4_4_ < uVar12)) != false) !=
          (int)(-uVar15 - (uint)((uint)local_14c._4_4_ < uVar12)) < 0) {
        local_16c = 0;
        do {
          FUN_001b5e90(&local_11c,iVar7,iVar7,local_14c._4_4_);
          bVar17 = uVar12 < (uint)local_14c._4_4_;
          uVar12 = uVar12 - local_14c._4_4_;
          uVar15 = uVar15 - bVar17;
          local_16c = local_16c + local_14c._4_4_;
          FUN_0018ae30(&local_11c,0,0x108);
          thunk_FUN_0005e980(&local_11c,puVar1,0x10);
          iVar7 = iVar5 + local_16c;
        } while ((SBORROW4(-uVar15,(uint)((uint)local_14c._4_4_ < uVar12)) != false) !=
                 (int)(-uVar15 - (uint)((uint)local_14c._4_4_ < uVar12)) < 0);
      }
      FUN_001b5e90(&local_11c,iVar7,iVar7,uVar12);
      puVar2 = PTR_DAT_0024bb5c;
      (**(code **)PTR_DAT_0024bb5c)(iVar4,iVar5,local_16c + uVar12,uVar6,iVar10);
      puVar19 = param_2;
      uVar12 = param_3;
      uVar6 = (**(code **)PTR_DAT_0024bb9c)(iVar4,param_2,param_3);
      if (((uint)param_2 | param_3) != 0) {
        local_11c = 0x534e4553;
        local_118 = CONCAT44(*(uint *)(puVar1 + 4) ^ _UNK_0021ab84,*(uint *)puVar1 ^ _DAT_0021ab80);
        local_12c._8_4_ = *(uint *)(puVar1 + 8) ^ _UNK_0021ab88;
        local_12c._0_8_ = local_118;
        local_12c._12_4_ = *(uint *)(puVar1 + 0xc) ^ _UNK_0021ab8c;
        local_110 = local_12c._8_8_;
        local_108 = 0x1000;
        uVar15 = (uint)(iVar11 >> 0x1f) >> 0x14;
        iVar11 = iVar11 + (uint)CARRY4(uVar9,uVar15);
        uVar9 = uVar9 + uVar15 >> 0xc | iVar11 * 0x100000;
        local_104 = uVar9 + 1;
        local_100 = (iVar11 >> 0xc) + (uint)(0xfffffffe < uVar9);
        local_fc = param_2;
        local_f8 = param_3;
        if (*(code **)puVar2 == (code *)0x0) {
          uVar12 = 0x28;
          puVar19 = &local_11c;
          FUN_0018b010(iVar4,puVar19,0x28,param_2);
        }
        else {
          (**(code **)puVar2)(iVar4,&local_11c,0x28,param_2,param_3);
        }
      }
      FUN_0018ae20(iVar5);
      pcVar8 = *(code **)PTR_DAT_0024bb48;
      if (pcVar8 == (code *)0x0) {
        pcVar8 = *(code **)PTR_DAT_0024bb4c;
        if (pcVar8 == (code *)0x0) {
          FUN_0018afd0(iVar4);
          return uVar6;
        }
      }
      else {
        uVar12 = 0;
        puVar19 = (undefined4 *)0x0;
      }
      (*pcVar8)(iVar4,puVar19,uVar12);
    }
  }
  return uVar6;
}

