/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d9300 FUN_001d9300 */

uint FUN_001d9300(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  uint local_8;
  
  iVar1 = FUN_001d9350(param_1,param_2,param_3,param_4,&local_8);
  return -(uint)(iVar1 == 0) | local_8;
}

