/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d0470 FUN_001d0470 */

void FUN_001d0470(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 int param_5)

{
  if (*(char *)(param_5 + 1) == '\0') {
    FUN_001cc310(param_3,param_4,param_5,0x1d0478);
  }
  else {
    FUN_001ce640(param_3,param_4,param_5);
  }
  return;
}

