/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f0380 FUN_001f0380 */

void __regparm1 FUN_001f0380(undefined4 param_1_00,byte *param_1)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_001eba70(param_1_00);
  if ((*param_1 & 1) == 0) {
    param_1 = param_1 + 1;
  }
  else {
    param_1 = *(byte **)(param_1 + 8);
  }
  (**(code **)(*piVar1 + 0x29c))(piVar1,param_1);
  return;
}

