/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0019ab90 FUN_0019ab90 */

void FUN_0019ab90(void)

{
  undefined4 uVar1;
  
  uVar1 = thunk_FUN_001b5f75();
  FUN_001b6000(uVar1);
  uVar1 = thunk_FUN_001b5f55();
  FUN_001b6000(uVar1);
  uVar1 = thunk_FUN_001b5f95();
  FUN_001b6000(uVar1);
  uVar1 = thunk_FUN_001b5fb5();
  FUN_001b6000(uVar1);
  uVar1 = thunk_FUN_001b5ef5();
  FUN_001b6000(uVar1);
  return;
}

