/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5970 FUN_001b5970 */

int * FUN_001b5970(int *param_1,int param_2)

{
  if (param_1 != (int *)0x0) {
    do {
      if (*param_1 == param_2) {
        return param_1;
      }
      param_1 = (int *)param_1[2];
    } while (param_1 != (int *)0x0);
  }
  return (int *)0x0;
}

