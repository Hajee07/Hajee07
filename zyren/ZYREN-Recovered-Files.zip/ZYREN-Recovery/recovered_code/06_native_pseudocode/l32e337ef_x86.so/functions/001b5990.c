/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5990 FUN_001b5990 */

int FUN_001b5990(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = 0x1b5998;
  iVar1 = FUN_001d0c50(param_1 + 8);
  FUN_0018ae30(iVar1,0,param_1 + 8,uVar2);
  return iVar1 + 8;
}

