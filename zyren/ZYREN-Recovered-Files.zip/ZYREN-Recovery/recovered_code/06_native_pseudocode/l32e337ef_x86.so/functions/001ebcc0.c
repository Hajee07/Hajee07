/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ebcc0 FUN_001ebcc0 */

void FUN_001ebcc0(char *param_1)

{
  if (*param_1 != '\0') {
                    /* try { // try from 001ebce4 to 001ebce8 has its CatchHandler @ 001ebcee */
    (**(code **)(*DAT_00276d9c + 0x14))(DAT_00276d9c);
  }
  return;
}

