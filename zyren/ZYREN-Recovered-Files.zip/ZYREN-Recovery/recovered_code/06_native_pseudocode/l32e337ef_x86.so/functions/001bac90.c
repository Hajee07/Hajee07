/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bac90 FUN_001bac90 */

int FUN_001bac90(char *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  cVar1 = *param_1;
  iVar2 = FUN_0018af10(param_1);
  iVar3 = FUN_0018add0(iVar2 + 1);
  if (cVar1 == 'L') {
    if (iVar3 != 0) {
      iVar2 = FUN_0018af10(param_1 + 1);
      FUN_0018ae80(iVar3,param_1 + 1,iVar2 + 1);
      iVar2 = FUN_0018af10(iVar3);
      *(undefined *)(iVar2 + -1 + iVar3) = 0;
    }
  }
  else if (iVar3 != 0) {
    FUN_0018ae80(iVar3,param_1,iVar2 + 1);
  }
  return iVar3;
}

