/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f6220 FUN_001f6220 */

int * FUN_001f6220(int *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined1 *local_18;
  
  if (param_3 < 0x1000) {
    puVar2 = &DAT_00276e3c;
    if (DAT_00276e40 != '\0') goto LAB_001f628a;
    local_18 = &DAT_00276e40;
    iVar1 = FUN_001f9a30(&DAT_00276e40);
    if (iVar1 == 0) goto LAB_001f628a;
    DAT_00276e3c = &PTR_FUN_0024a19c;
  }
  else {
    puVar2 = &DAT_00276e48;
    if (DAT_00276e4c != '\0') goto LAB_001f628a;
    local_18 = &DAT_00276e4c;
    iVar1 = FUN_001f9a30(&DAT_00276e4c);
    if (iVar1 == 0) goto LAB_001f628a;
    DAT_00276e48 = &PTR_FUN_0024a1cc;
  }
  FUN_001f9ba0(local_18);
LAB_001f628a:
  *param_1 = param_3;
  param_1[1] = (int)puVar2;
  return param_1;
}

