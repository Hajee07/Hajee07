/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110270 FUN_00110270 */

uint FUN_00110270(void)

{
  uint uVar1;
  uint uVar2;
  char *in_ECX;
  char cVar3;
  uint uVar4;
  
  cVar3 = *in_ECX;
  if (cVar3 != '\0') {
    in_ECX = in_ECX + 1;
    uVar1 = 0;
    do {
      uVar4 = (int)cVar3 + uVar1 * 0x10;
      uVar2 = uVar4 & 0xf0000000;
      uVar1 = uVar2 >> 0x18;
      if (uVar2 == 0) {
        uVar1 = 0;
      }
      uVar1 = ~uVar2 & (uVar1 ^ uVar4);
      cVar3 = *in_ECX;
      in_ECX = in_ECX + 1;
    } while (cVar3 != '\0');
    return uVar1;
  }
  return 0;
}

