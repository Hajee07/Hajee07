/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f97f0 FUN_001f97f0 */

bool FUN_001f97f0(void)

{
  int iVar1;
  bool bVar2;
  
                    /* try { // try from 001f9806 to 001f980a has its CatchHandler @ 001f9820 */
  iVar1 = FUN_001f9920();
  if (iVar1 == 0) {
    bVar2 = false;
  }
  else {
    bVar2 = *(int *)(iVar1 + 4) != 0;
  }
  return bVar2;
}

