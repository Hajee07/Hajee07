/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e3ac0 FUN_001e3ac0 */

undefined4 FUN_001e3ac0(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  ushort uVar7;
  undefined2 uVar8;
  uint uVar9;
  uint *puVar10;
  int iVar11;
  undefined4 *puVar12;
  undefined4 uVar13;
  undefined4 *puVar14;
  undefined4 local_44 [7];
  undefined4 local_28;
  undefined4 local_24;
  undefined8 local_20;
  undefined8 local_18;
  
  if (param_1 == (undefined4 *)0x0) {
    return 0xffffffff;
  }
  uVar13 = 0;
  if (param_1[5] != 1) {
    if ((*(byte *)(param_1 + 0x13) & 0xf) != 0) {
      local_44[0] = 0;
      uVar9 = FUN_001d1b10(param_1 + 0x2d,&DAT_00217e63,local_44,0,0,4);
      uVar13 = 0xfffffff4;
      if (1 < uVar9) goto LAB_001e3d3f;
      param_1[0x19] = param_1[0x2c];
      param_1[0x18] = param_1[0x2b];
      param_1[0x1c] = param_1[0x2a];
      param_1[0x1b] = param_1[0x29];
      *(undefined2 *)(param_1 + 0x27) = 8;
    }
    uVar7 = FUN_0018af10(param_1[0x15]);
    local_44[0] = param_1[0x137fe];
    puVar10 = (uint *)FUN_0018b2f0(local_44);
    uVar9 = puVar10[2];
    uVar2 = *puVar10;
    uVar3 = puVar10[1];
    uVar4 = puVar10[5];
    uVar5 = puVar10[4];
    uVar6 = puVar10[3];
    local_28 = 0x8074b50;
    local_24 = param_1[0x1a];
    local_20 = *(undefined8 *)(param_1 + 0x18);
    local_18 = *(undefined8 *)(param_1 + 0x16);
    iVar11 = (*(code *)param_1[0xf])(param_1[0x11],param_1[0x1b],param_1[0x1c],&local_28,0x18);
    uVar13 = 0xfffffff2;
    if (iVar11 == 0x18) {
      puVar10 = param_1 + 0x1b;
      uVar1 = *puVar10;
      *puVar10 = *puVar10 + 0x18;
      param_1[0x1c] = param_1[0x1c] + (uint)(0xffffffe7 < uVar1);
      puVar14 = param_1 + 0x18;
      if (param_1[0x19] == 0 && (uint)(0xfffffffe < (uint)param_1[0x18]) <= (uint)-param_1[0x19]) {
        puVar14 = (undefined4 *)0x0;
      }
      puVar12 = param_1 + 0x25;
      if (param_1[0x26] == 0 && (uint)(0xfffffffe < (uint)param_1[0x25]) <= (uint)-param_1[0x26]) {
        puVar12 = (undefined4 *)0x0;
      }
      uVar8 = FUN_001dee80(puVar14,puVar12);
      if (((uVar7 != 0) && (*(char *)((uVar7 - 1) + param_1[0x15]) == '/')) &&
         ((param_1[0x16] | param_1[0x17]) == 0)) {
        *(byte *)(param_1 + 0x137fd) = *(byte *)(param_1 + 0x137fd) | 0x10;
      }
      iVar11 = FUN_001def60(uVar7,local_44,uVar8,&DAT_00217e63,0,param_1[0x16],param_1[0x17],
                            param_1[0x18],param_1[0x19],param_1[0x1a],
                            *(undefined2 *)(param_1 + 0x27),0x808,
                            (uVar2 >> 1) + uVar3 * 0x20 + uVar9 * 0x800 & 0xffff,
                            uVar6 + 0x6020 + uVar5 * 0x20 + uVar4 * 0x200 & 0xffff,param_1[0x25],
                            param_1[0x26],param_1[0x137fd],0,0);
      if (iVar11 == 0) {
        uVar13 = 0xfffffff1;
        param_1[0x137fe] = 0;
        iVar11 = param_1[0x15];
        goto joined_r0x001e3d4e;
      }
      param_1[4] = param_1[4] + 1;
      param_1[1] = param_1[0x1c];
      *param_1 = param_1[0x1b];
      uVar13 = 0;
    }
  }
LAB_001e3d3f:
  param_1[0x137fe] = 0;
  iVar11 = param_1[0x15];
joined_r0x001e3d4e:
  if (iVar11 != 0) {
    FUN_0018ae20(iVar11);
    param_1[0x15] = 0;
  }
  return uVar13;
}

