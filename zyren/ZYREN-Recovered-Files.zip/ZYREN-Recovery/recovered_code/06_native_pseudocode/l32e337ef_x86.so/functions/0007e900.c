/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0007e900 FUN_0007e900 */

void FUN_0007e900(void)

{
  int unaff_EBP;
  
  if ((*(int *)(unaff_EBP + 8) != 0) && (*(int *)(unaff_EBP + 0xc) != 0)) {
    if (1 < *(uint *)(unaff_EBP + 0xc)) {
      FUN_0009fa40();
      return;
    }
  }
  *(byte *)(unaff_EBP + 0x1c) = *(byte *)(unaff_EBP + 0x1c) | 1;
  FUN_0002d080();
  return;
}

