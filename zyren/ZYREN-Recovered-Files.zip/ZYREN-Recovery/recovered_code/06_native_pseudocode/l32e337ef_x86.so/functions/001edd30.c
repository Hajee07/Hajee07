/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001edd30 FUN_001edd30 */

void FUN_001edd30(int *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  uVar1 = 0x1edd3c;
  if (param_3 != 0) {
    do {
      (**(code **)(*param_1 + 0x10))(param_1,*(undefined4 *)*param_2,param_4,uVar1);
      param_2 = param_2 + 1;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}

