/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b4fb0 FUN_001b4fb0 */

void FUN_001b4fb0(undefined4 *param_1,int *param_2,int **param_3,int **param_4)

{
  int **ppiVar1;
  int **ppiVar2;
  undefined uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  longdouble lVar9;
  float fVar10;
  int *local_20;
  uint local_1c;
  
  piVar7 = *param_3;
  piVar8 = (int *)param_2[1];
  if (piVar8 != (int *)0x0) {
    uVar4 = (int)piVar8 - ((uint)piVar8 >> 1 & 0x55555555);
    uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333);
    uVar4 = ((uVar4 >> 4) + uVar4 & 0xf0f0f0f) * 0x1010101 >> 0x18;
    if (uVar4 < 2) {
      local_20 = (int *)((int)piVar8 - 1U & (uint)piVar7);
    }
    else {
      local_20 = piVar7;
      if (piVar8 <= piVar7) {
        local_20 = (int *)((uint)piVar7 % (uint)piVar8);
      }
    }
    ppiVar1 = *(int ***)(*param_2 + (int)local_20 * 4);
    if (ppiVar1 != (int **)0x0) {
      if (1 < uVar4) {
        do {
          ppiVar1 = (int **)*ppiVar1;
          if (ppiVar1 == (int **)0x0) goto LAB_001b509a;
          piVar6 = ppiVar1[1];
          if (piVar6 != piVar7) {
            if (piVar8 <= piVar6) {
              piVar6 = (int *)((uint)piVar6 % (uint)piVar8);
            }
            if (piVar6 != local_20) goto LAB_001b509a;
          }
        } while (ppiVar1[2] != piVar7);
LAB_001b51df:
        uVar3 = 0;
        goto LAB_001b51f1;
      }
      for (ppiVar1 = (int **)*ppiVar1;
          (ppiVar1 != (int **)0x0 &&
          ((ppiVar1[1] == piVar7 || ((int *)((uint)ppiVar1[1] & (int)piVar8 - 1U) == local_20))));
          ppiVar1 = (int **)*ppiVar1) {
        if (ppiVar1[2] == piVar7) goto LAB_001b51df;
      }
    }
  }
LAB_001b509a:
  ppiVar1 = (int **)FUN_001f5520(0x14);
  ppiVar1[2] = *param_4;
  *(undefined8 *)(ppiVar1 + 3) = *(undefined8 *)(param_4 + 1);
  ppiVar1[1] = piVar7;
  *ppiVar1 = (int *)0x0;
  fVar10 = (float)((double)((ulonglong)(param_2[3] + 1) | (ulonglong)DAT_0021b950) - DAT_0021b950);
  if ((piVar8 == (int *)0x0) ||
     ((float)((double)(ZEXT48(piVar8) | (ulonglong)DAT_0021b950) - DAT_0021b950) * (float)param_2[4]
      < fVar10)) {
    uVar4 = (uint)(((uint)piVar8 & (int)piVar8 - 1U) != 0 || piVar8 < (int *)0x3) + (int)piVar8 * 2;
    lVar9 = (longdouble)FUN_0018b1e0(fVar10 / (float)param_2[4]);
    local_1c = (uint)(longlong)lVar9;
    if (uVar4 < local_1c) {
      uVar4 = local_1c;
    }
                    /* try { // try from 001b5192 to 001b51a1 has its CatchHandler @ 001b5204 */
    FUN_001b4640(param_2,uVar4);
    piVar8 = (int *)param_2[1];
    if (((uint)piVar8 & (int)piVar8 - 1U) == 0) {
      piVar7 = (int *)((uint)piVar7 & (int)piVar8 - 1U);
      iVar5 = *param_2;
      ppiVar2 = *(int ***)(iVar5 + (int)piVar7 * 4);
      goto joined_r0x001b51d8;
    }
    if (piVar8 <= piVar7) {
      piVar7 = (int *)((uint)piVar7 % (uint)piVar8);
    }
    iVar5 = *param_2;
    ppiVar2 = *(int ***)(iVar5 + (int)piVar7 * 4);
    if (ppiVar2 != (int **)0x0) goto LAB_001b51c9;
LAB_001b5120:
    *ppiVar1 = (int *)param_2[2];
    param_2[2] = (int)ppiVar1;
    *(int **)(iVar5 + (int)piVar7 * 4) = param_2 + 2;
    if (*ppiVar1 != (int *)0x0) {
      piVar7 = (int *)(*ppiVar1)[1];
      if (((uint)piVar8 & (int)piVar8 - 1U) == 0) {
        piVar7 = (int *)((uint)piVar7 & (int)piVar8 - 1U);
      }
      else if (piVar8 <= piVar7) {
        piVar7 = (int *)((uint)piVar7 % (uint)piVar8);
      }
      ppiVar2 = (int **)((int)piVar7 * 4 + *param_2);
      goto LAB_001b51ea;
    }
  }
  else {
    iVar5 = *param_2;
    ppiVar2 = *(int ***)(iVar5 + (int)local_20 * 4);
    piVar7 = local_20;
joined_r0x001b51d8:
    if (ppiVar2 == (int **)0x0) goto LAB_001b5120;
LAB_001b51c9:
    *ppiVar1 = *ppiVar2;
LAB_001b51ea:
    *ppiVar2 = (int *)ppiVar1;
  }
  param_2[3] = param_2[3] + 1;
  uVar3 = 1;
LAB_001b51f1:
  *param_1 = ppiVar1;
  *(undefined *)(param_1 + 1) = uVar3;
  return;
}

