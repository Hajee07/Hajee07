/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fc060 FUN_001fc060 */

void FUN_001fc060(int param_1,int *param_2,int *param_3,int param_4,char param_5)

{
  undefined4 uVar1;
  uint uVar2;
  int *piVar3;
  bool bVar4;
  byte bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int **ppiVar9;
  int **ppiVar10;
  byte local_24;
  
  iVar6 = param_2[2];
  if (param_5 == '\0') {
    if (*(int *)(param_1 + 4) != *(int *)(iVar6 + 4)) {
      if (*(int *)(param_1 + 4) != *(int *)(*param_2 + 4)) {
LAB_001fc140:
        iVar6 = *(int *)(param_1 + 0xc);
        uVar2 = *(uint *)(param_1 + 0x14);
        iVar7 = (int)uVar2 >> 8;
        if ((uVar2 & 1) != 0) {
          iVar7 = *(int *)(*param_3 + iVar7);
        }
        iVar8 = 2;
        if ((uVar2 & 2) != 0) {
          iVar8 = param_4;
        }
        (**(code **)(**(int **)(param_1 + 0x10) + 0x18))
                  (*(int **)(param_1 + 0x10),param_2,iVar7 + (int)param_3,iVar8,param_5);
        if (iVar6 < 2) {
          return;
        }
        ppiVar10 = (int **)(param_1 + 0x10 + iVar6 * 8);
        ppiVar9 = (int **)(param_1 + 0x18);
        if (((*(uint *)(param_1 + 8) & 2) != 0) || (param_2[9] == 1)) {
          do {
            if (*(char *)((int)param_2 + 0x36) != '\0') {
              return;
            }
            piVar3 = ppiVar9[1];
            iVar6 = (int)piVar3 >> 8;
            if (((uint)piVar3 & 1) != 0) {
              iVar6 = *(int *)(*param_3 + iVar6);
            }
            iVar7 = param_4;
            if (((uint)piVar3 & 2) == 0) {
              iVar7 = 2;
            }
            (**(code **)(**ppiVar9 + 0x18))(*ppiVar9,param_2,iVar6 + (int)param_3,iVar7,param_5);
            ppiVar9 = ppiVar9 + 2;
          } while (ppiVar9 < ppiVar10);
          return;
        }
        if ((*(uint *)(param_1 + 8) & 1) != 0) {
          while( true ) {
            if (*(char *)((int)param_2 + 0x36) != '\0') {
              return;
            }
            if ((param_2[9] == 1) && (param_2[6] == 1)) break;
            piVar3 = ppiVar9[1];
            iVar6 = (int)piVar3 >> 8;
            if (((uint)piVar3 & 1) != 0) {
              iVar6 = *(int *)(*param_3 + iVar6);
            }
            iVar7 = param_4;
            if (((uint)piVar3 & 2) == 0) {
              iVar7 = 2;
            }
            (**(code **)(**ppiVar9 + 0x18))(*ppiVar9,param_2,iVar6 + (int)param_3,iVar7,param_5);
            ppiVar9 = ppiVar9 + 2;
            if (ppiVar10 <= ppiVar9) {
              return;
            }
          }
          return;
        }
        while( true ) {
          if (*(char *)((int)param_2 + 0x36) != '\0') {
            return;
          }
          if (param_2[9] == 1) break;
          piVar3 = ppiVar9[1];
          iVar6 = (int)piVar3 >> 8;
          if (((uint)piVar3 & 1) != 0) {
            iVar6 = *(int *)(*param_3 + iVar6);
          }
          iVar7 = param_4;
          if (((uint)piVar3 & 2) == 0) {
            iVar7 = 2;
          }
          (**(code **)(**ppiVar9 + 0x18))(*ppiVar9,param_2,iVar6 + (int)param_3,iVar7,param_5);
          ppiVar9 = ppiVar9 + 2;
          if (ppiVar10 <= ppiVar9) {
            return;
          }
        }
        return;
      }
LAB_001fc0d2:
      if (((int *)param_2[4] == param_3) || ((int *)param_2[5] == param_3)) {
        if (param_4 != 1) {
          return;
        }
        param_2[8] = 1;
        return;
      }
      param_2[8] = param_4;
      if (param_2[0xb] != 4) {
        iVar6 = *(int *)(param_1 + 0xc);
        if (iVar6 < 1) {
          param_2[0xb] = 4;
        }
        else {
          ppiVar10 = (int **)(param_1 + 0x10);
          bVar4 = false;
          local_24 = 0;
          do {
            *(undefined2 *)(param_2 + 0xd) = 0;
            piVar3 = ppiVar10[1];
            iVar7 = (int)piVar3 >> 8;
            if (((uint)piVar3 & 1) != 0) {
              iVar7 = *(int *)(*param_3 + iVar7);
            }
            (**(code **)(**ppiVar10 + 0x14))
                      (*ppiVar10,param_2,param_3,iVar7 + (int)param_3,
                       (((uint)piVar3 & 2) == 0) + '\x01',param_5);
            if (*(char *)((int)param_2 + 0x36) != '\0') break;
            bVar5 = local_24;
            if (*(char *)((int)param_2 + 0x35) != '\0') {
              if (*(char *)(param_2 + 0xd) == '\0') {
                local_24 = 1;
                bVar5 = 1;
                if ((*(byte *)(param_1 + 8) & 1) == 0) break;
              }
              else {
                if (param_2[6] == 1) {
LAB_001fc427:
                  param_2[0xb] = 3;
                  return;
                }
                bVar4 = true;
                bVar5 = 1;
                if ((*(byte *)(param_1 + 8) & 2) == 0) goto LAB_001fc427;
              }
            }
            local_24 = bVar5;
            ppiVar10 = ppiVar10 + 2;
          } while (ppiVar10 < (int **)(param_1 + 0x10 + iVar6 * 8));
          param_2[0xb] = 4 - (uint)local_24;
          if (bVar4) {
            return;
          }
        }
      }
      param_2[5] = (int)param_3;
      param_2[10] = param_2[10] + 1;
      if (param_2[9] != 1) {
        return;
      }
      if (param_2[6] != 2) {
        return;
      }
      *(undefined *)((int)param_2 + 0x36) = 1;
      return;
    }
  }
  else if (param_1 != iVar6) {
    uVar1 = *(undefined4 *)(param_1 + 4);
    iVar6 = FUN_0018b060(uVar1,*(undefined4 *)(iVar6 + 4));
    if (iVar6 != 0) {
      if ((param_1 != *param_2) &&
         (iVar6 = FUN_0018b060(uVar1,*(undefined4 *)(*param_2 + 4)), iVar6 != 0)) goto LAB_001fc140;
      goto LAB_001fc0d2;
    }
  }
  if (((int *)param_2[1] == param_3) && (param_2[7] != 1)) {
    param_2[7] = param_4;
  }
  return;
}

