/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00203210 FUN_00203210 */

char * __regparm3
FUN_00203210(undefined4 param_1_00,char **param_2,char **param_3,undefined *param_1)

{
  char cVar1;
  char cVar2;
  char **ppcVar3;
  char *pcVar4;
  char **ppcVar5;
  char *pcVar6;
  int iVar7;
  char *pcVar8;
  
  if (((*param_2)[4] == '$') && (iVar7 = *(int *)(*param_2 + 8), iVar7 - 2U < 4)) {
    ppcVar3 = (char **)param_3[0x45b];
    pcVar8 = ppcVar3[1];
    ppcVar5 = ppcVar3;
    if ((char *)0xff7 < pcVar8 + 0x10) {
      ppcVar5 = (char **)FUN_0018add0(0x1000);
      if (ppcVar5 == (char **)0x0) goto LAB_00203460;
      *ppcVar5 = (char *)ppcVar3;
      ppcVar5[1] = (char *)0x0;
      param_3[0x45b] = (char *)ppcVar5;
      pcVar8 = (char *)0x0;
    }
    ppcVar5[1] = pcVar8 + 0x10;
    *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar8) = 0x1010123;
    *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar8) = &PTR_FUN_0024b298;
    *(int *)((int)(ppcVar5 + 4) + (int)pcVar8) = iVar7;
    *param_2 = (char *)((int)(ppcVar5 + 2) + (int)pcVar8);
  }
  pcVar8 = *param_3;
  pcVar4 = param_3[1];
  if ((pcVar8 == pcVar4) || (*pcVar8 != 'C')) {
    if (pcVar4 == pcVar8) {
      return (char *)0x0;
    }
    if ((int)pcVar4 - (int)pcVar8 == 1) {
      return (char *)0x0;
    }
    if (*pcVar8 != 'D') {
      return (char *)0x0;
    }
    cVar2 = pcVar8[1];
    if (5 < (byte)(cVar2 - 0x30U)) {
      return (char *)0x0;
    }
    if ((byte)(cVar2 - 0x30U) == 3) {
      return (char *)0x0;
    }
    *param_3 = pcVar8 + 2;
    if (param_1 != (undefined *)0x0) {
      *param_1 = 1;
    }
    ppcVar3 = (char **)param_3[0x45b];
    pcVar8 = ppcVar3[1];
    ppcVar5 = ppcVar3;
    if ((char *)0xff7 < pcVar8 + 0x20) {
      ppcVar5 = (char **)FUN_0018add0(0x1000);
      if (ppcVar5 == (char **)0x0) {
LAB_00203460:
                    /* WARNING: Subroutine does not return */
        FUN_001f9d40();
      }
      *ppcVar5 = (char *)ppcVar3;
      ppcVar5[1] = (char *)0x0;
      param_3[0x45b] = (char *)ppcVar5;
      pcVar8 = (char *)0x0;
    }
    ppcVar5[1] = pcVar8 + 0x20;
    pcVar4 = *param_2;
    *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar8) = 0x1010125;
    *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar8) = &PTR_FUN_0024b2d0;
    *(char **)((int)(ppcVar5 + 4) + (int)pcVar8) = pcVar4;
    *(char *)((int)(ppcVar5 + 5) + (int)pcVar8) = '\x01';
LAB_0020344a:
    *(int *)((int)(ppcVar5 + 6) + (int)pcVar8) = cVar2 + -0x30;
    pcVar8 = (char *)((int)(ppcVar5 + 2) + (int)pcVar8);
  }
  else {
    pcVar6 = pcVar8 + 1;
    *param_3 = pcVar6;
    if (pcVar6 != pcVar4) {
      cVar1 = *pcVar6;
      if (cVar1 == 'I') {
        pcVar6 = pcVar8 + 2;
        *param_3 = pcVar6;
      }
      if ((pcVar4 != pcVar6) && (cVar2 = *pcVar6, (byte)(cVar2 - 0x31U) < 5)) {
        *param_3 = pcVar6 + 1;
        if (param_1 != (undefined *)0x0) {
          *param_1 = 1;
        }
        if ((cVar1 == 'I') && (iVar7 = FUN_00200b40(), iVar7 == 0)) {
          return (char *)0x0;
        }
        ppcVar3 = (char **)param_3[0x45b];
        pcVar8 = ppcVar3[1];
        ppcVar5 = ppcVar3;
        if ((char *)0xff7 < pcVar8 + 0x20) {
          ppcVar5 = (char **)FUN_0018add0(0x1000);
          if (ppcVar5 == (char **)0x0) goto LAB_00203460;
          *ppcVar5 = (char *)ppcVar3;
          ppcVar5[1] = (char *)0x0;
          param_3[0x45b] = (char *)ppcVar5;
          pcVar8 = (char *)0x0;
        }
        ppcVar5[1] = pcVar8 + 0x20;
        pcVar4 = *param_2;
        *(undefined4 *)((int)(ppcVar5 + 3) + (int)pcVar8) = 0x1010125;
        *(undefined ***)((int)(ppcVar5 + 2) + (int)pcVar8) = &PTR_FUN_0024b2d0;
        *(char **)((int)(ppcVar5 + 4) + (int)pcVar8) = pcVar4;
        *(char *)((int)(ppcVar5 + 5) + (int)pcVar8) = '\0';
        goto LAB_0020344a;
      }
    }
    pcVar8 = (char *)0x0;
  }
  return pcVar8;
}

