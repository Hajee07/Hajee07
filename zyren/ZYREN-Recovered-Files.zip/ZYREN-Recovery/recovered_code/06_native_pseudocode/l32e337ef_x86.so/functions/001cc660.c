/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001cc660 FUN_001cc660 */

uint FUN_001cc660(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined local_810 [2048];
  
  uVar3 = 0x1cc66f;
  uVar1 = FUN_001cc120(param_1,param_4,param_5,local_810,0x800);
  uVar2 = uVar1;
  if ((uVar1 < 0xffffff89) && (uVar2 = 0xffffffb8, uVar1 < param_5)) {
    uVar2 = FUN_001cc310(param_4 + uVar1,param_5 - uVar1,param_1,uVar3);
  }
  return uVar2;
}

