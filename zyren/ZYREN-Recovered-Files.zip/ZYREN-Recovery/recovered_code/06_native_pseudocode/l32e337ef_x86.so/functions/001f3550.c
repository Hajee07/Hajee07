/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f3550 FUN_001f3550 */

bool FUN_001f3550(char *param_1,char *param_2)

{
  char cVar1;
  
  cVar1 = *param_1;
  while ((cVar1 != '\0' && (param_1 = param_1 + 1, cVar1 == *param_2))) {
    param_2 = param_2 + 1;
    cVar1 = *param_1;
  }
  return *param_2 == '\0';
}

