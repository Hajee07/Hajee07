/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002101a0 FUN_002101a0 */

undefined4 FUN_002101a0(undefined4 param_1,int param_2)

{
  (**(code **)(**(int **)(param_2 + 8) + 0x18))(param_1,*(int **)(param_2 + 8));
  return param_1;
}

