/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00213fe5 FUN_00213fe5 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void __regparm2 FUN_00213fe5(byte *param_1_00,byte *param_2_00,int param_1,undefined4 *param_2)

{
  uint uVar1;
  byte *pbVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  byte bVar6;
  uint uVar7;
  undefined4 extraout_EDX;
  int *piVar8;
  byte **ppbVar9;
  byte **ppbVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  byte bVar13;
  byte *local_3c;
  undefined4 *local_38;
  uint *local_34;
  byte *local_30;
  uint local_28;
  int local_24;
  int aiStack_20 [3];
  undefined4 uStack_14;
  
  bVar13 = 0;
  uStack_14 = 0x213ff0;
  local_38 = (undefined4 *)0x0;
  param_2[0x24] = 0;
  local_34 = &local_28;
  ppbVar9 = &local_3c;
  local_3c = param_2_00;
LAB_00214017:
  while( true ) {
    while( true ) {
      pbVar2 = param_1_00;
      if ((local_3c <= pbVar2) ||
         (uVar1 = param_2[0x29],
         (uint)(*(int *)(param_1 + 0x4c) - (*(int *)(param_1 + 0x60) >> 0x1f)) <= uVar1)) {
        return;
      }
      uVar7 = (uint)*pbVar2;
      local_30 = pbVar2 + 1;
      bVar6 = *pbVar2 & 0xc0;
      param_1_00 = local_30;
      if (bVar6 != 0x40) break;
      param_2[0x29] = (uVar7 & 0x3f) * param_2[0x2c] + uVar1;
    }
    if (bVar6 == 0x80) break;
    if (bVar6 != 0xc0) goto code_r0x002140d6;
    local_28 = uVar7 & 0x3f;
    if ((byte)local_28 < 0x12) {
      param_2[local_28 * 2 + 1] = 0;
    }
  }
  local_28 = uVar7 & 0x3f;
  ppbVar9[-1] = (byte *)0x214085;
  local_30 = (byte *)FUN_00213bab();
  iVar3 = local_24 * param_2[0x2b];
  goto joined_r0x0021409b;
code_r0x002140d6:
  switch(uVar7) {
  case 0:
  case 0x2d:
    goto LAB_00214017;
  case 1:
    ppbVar9[-1] = &UNK_002140f6;
    FUN_00213f82();
    ppbVar9[-1] = (byte *)extraout_EDX;
    ppbVar9[-2] = (byte *)extraout_EDX;
    ppbVar9[-3] = (byte *)aiStack_20;
    ppbVar9[-4] = local_30;
    ppbVar9[-5] = &UNK_00214108;
    param_1_00 = (byte *)FUN_00213c15();
    param_2[0x29] = aiStack_20[0];
    goto LAB_00214017;
  case 2:
    param_2[0x29] = uVar1 + (uint)pbVar2[1] * param_2[0x2c];
    param_1_00 = pbVar2 + 2;
    goto LAB_00214017;
  case 3:
    param_2[0x29] = uVar1 + (uint)*(ushort *)(pbVar2 + 1) * param_2[0x2c];
    param_1_00 = pbVar2 + 3;
    goto LAB_00214017;
  case 4:
    param_2[0x29] = uVar1 + param_2[0x2c] * *(int *)(pbVar2 + 1);
    param_1_00 = pbVar2 + 5;
    goto LAB_00214017;
  case 5:
    ppbVar9[-1] = &UNK_00214183;
    FUN_00213bab();
    ppbVar9[-1] = &UNK_0021418b;
    local_30 = (byte *)FUN_00213bab();
    iVar3 = local_24 * param_2[0x2b];
    break;
  case 6:
    ppbVar9[-1] = &UNK_002141c3;
    param_1_00 = (byte *)FUN_00213bab();
    if (local_28 < 0x12) {
      param_2[local_28 * 2 + 1] = 0;
    }
    goto LAB_00214017;
  case 7:
    ppbVar9[-1] = &UNK_00214217;
    param_1_00 = (byte *)FUN_00213bab();
    if (local_28 < 0x12) {
      param_2[local_28 * 2 + 1] = 6;
    }
    goto LAB_00214017;
  case 8:
    ppbVar9[-1] = &UNK_002141ed;
    param_1_00 = (byte *)FUN_00213bab();
    if (local_28 < 0x12) {
      param_2[local_28 * 2 + 1] = 0;
    }
    goto LAB_00214017;
  case 9:
    ppbVar9[-1] = &UNK_00214241;
    FUN_00213bab();
    ppbVar9[-1] = &UNK_00214249;
    param_1_00 = (byte *)FUN_00213bab();
    if (local_28 < 0x12) {
      (param_2 + local_28 * 2)[1] = 2;
      param_2[local_28 * 2] = aiStack_20[0];
    }
    goto LAB_00214017;
  case 10:
    if (local_38 == (undefined4 *)0x0) {
      ppbVar10 = ppbVar9 + -0x30;
      puVar4 = (undefined4 *)((int)ppbVar9 - 0xb1U & 0xfffffff0);
    }
    else {
      puVar4 = local_38;
      ppbVar10 = ppbVar9;
      local_38 = (undefined4 *)local_38[0x24];
    }
    puVar11 = param_2;
    puVar12 = puVar4;
    for (iVar3 = 0x29; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar12 = *puVar11;
      puVar11 = puVar11 + (uint)bVar13 * -2 + 1;
      puVar12 = puVar12 + (uint)bVar13 * -2 + 1;
    }
    param_2[0x24] = puVar4;
    ppbVar9 = ppbVar10;
    goto LAB_00214017;
  case 0xb:
    puVar4 = (undefined4 *)param_2[0x24];
    puVar11 = puVar4;
    puVar12 = param_2;
    for (iVar3 = 0x29; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar12 = *puVar11;
      puVar11 = puVar11 + (uint)bVar13 * -2 + 1;
      puVar12 = puVar12 + (uint)bVar13 * -2 + 1;
    }
    puVar4[0x24] = local_38;
    local_38 = puVar4;
    goto LAB_00214017;
  case 0xc:
    ppbVar9[-1] = &UNK_002142dd;
    FUN_00213bab();
    param_2[0x26] = local_24;
    ppbVar9[-1] = &UNK_002142f0;
    local_30 = (byte *)FUN_00213bab();
    param_2[0x25] = local_24;
    goto code_r0x0021431f;
  case 0xd:
    ppbVar9[-1] = &UNK_0021430e;
    local_30 = (byte *)FUN_00213bab();
    param_2[0x26] = local_24;
code_r0x0021431f:
    param_2[0x28] = 1;
    param_1_00 = local_30;
    goto LAB_00214017;
  case 0xe:
    ppbVar9[-1] = &UNK_00214339;
    local_30 = (byte *)FUN_00213bab();
    iVar3 = local_24;
    goto code_r0x00214433;
  case 0xf:
    param_2[0x28] = 2;
    param_2[0x27] = local_30;
    goto code_r0x00214389;
  case 0x10:
    ppbVar9[-1] = &UNK_0021436f;
    uVar5 = FUN_00213bab();
    if (0x11 < local_28) goto code_r0x00214389;
    puVar4 = param_2 + local_28 * 2;
    puVar4[1] = 3;
    goto code_r0x00214384;
  case 0x11:
    ppbVar9[-1] = &UNK_002143a1;
    FUN_00213bab();
    ppbVar9[-1] = &UNK_002143a9;
    local_30 = (byte *)FUN_00213bd6();
    iVar3 = aiStack_20[0] * param_2[0x2b];
    break;
  case 0x12:
    ppbVar9[-1] = &UNK_002143da;
    FUN_00213bab();
    param_2[0x26] = local_24;
    ppbVar9[-1] = &UNK_002143ee;
    param_1_00 = (byte *)FUN_00213bd6();
    param_2[0x28] = 1;
    param_2[0x25] = aiStack_20[0] * param_2[0x2b];
    goto LAB_00214017;
  case 0x13:
    ppbVar9[-1] = &UNK_00214421;
    local_30 = (byte *)FUN_00213bd6();
    iVar3 = aiStack_20[0] * param_2[0x2b];
code_r0x00214433:
    param_2[0x25] = iVar3;
    param_1_00 = local_30;
    goto LAB_00214017;
  case 0x14:
    ppbVar9[-1] = &UNK_00214449;
    FUN_00213bab();
    ppbVar9[-1] = &UNK_00214451;
    local_30 = (byte *)FUN_00213bab();
    iVar3 = local_24 * param_2[0x2b];
    goto joined_r0x0021449b;
  case 0x15:
    ppbVar9[-1] = &UNK_0021447d;
    FUN_00213bab();
    ppbVar9[-1] = &UNK_00214485;
    local_30 = (byte *)FUN_00213bd6();
    iVar3 = aiStack_20[0] * param_2[0x2b];
joined_r0x0021449b:
    param_1_00 = local_30;
    if (0x11 < local_28) goto LAB_00214017;
    piVar8 = param_2 + local_28 * 2;
    piVar8[1] = 4;
    goto code_r0x002141b1;
  case 0x16:
    ppbVar9[-1] = &UNK_002144bb;
    uVar5 = FUN_00213bab();
    if (0x11 < local_28) goto code_r0x00214389;
    puVar4 = param_2 + local_28 * 2;
    puVar4[1] = 5;
code_r0x00214384:
    *puVar4 = uVar5;
code_r0x00214389:
    ppbVar9[-1] = &UNK_0021438e;
    iVar3 = FUN_00213bab();
    param_1_00 = (byte *)(iVar3 + local_24);
    goto LAB_00214017;
  default:
    goto LAB_00214531;
  case 0x2e:
    ppbVar9[-1] = &UNK_002144e4;
    param_1_00 = (byte *)FUN_00213bab();
    *(int *)(param_1 + 0x68) = local_24;
    goto LAB_00214017;
  case 0x2f:
    ppbVar9[-1] = &UNK_002144fd;
    FUN_00213bab();
    ppbVar9[-1] = &UNK_00214505;
    local_30 = (byte *)FUN_00213bab();
    param_1_00 = local_30;
    if (0x11 < local_28) goto LAB_00214017;
    iVar3 = -(param_2[0x2b] * local_24);
    piVar8 = param_2 + local_28 * 2;
    piVar8[1] = 1;
    goto code_r0x002141b1;
  }
joined_r0x0021409b:
  param_1_00 = local_30;
  if (0x11 < local_28) goto LAB_00214017;
  piVar8 = param_2 + local_28 * 2;
  piVar8[1] = 1;
code_r0x002141b1:
  *piVar8 = iVar3;
  param_1_00 = local_30;
  goto LAB_00214017;
LAB_00214531:
                    /* WARNING: Subroutine does not return */
  ppbVar9[-1] = (byte *)0x214536;
  FUN_0018b160();
}

