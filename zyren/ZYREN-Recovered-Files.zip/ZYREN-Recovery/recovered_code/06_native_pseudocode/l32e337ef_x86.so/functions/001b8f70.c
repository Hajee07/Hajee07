/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b8f70 FUN_001b8f70 */

uint FUN_001b8f70(undefined4 param_1)

{
  int iVar1;
  uint uVar2;
  byte *pbVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  byte local_4010 [16384];
  
  FUN_0018ae30(local_4010,0,0x4000);
  iVar1 = FUN_0018b0c0(param_1,&DAT_00218693);
  if (iVar1 == 0) {
    uVar4 = 0;
  }
  else {
    uVar2 = FUN_0018b100(local_4010,1,0x4000,iVar1);
    uVar4 = 0;
    if (uVar2 != 0) {
      uVar5 = 0xffffffff;
      if (3 < uVar2) goto LAB_001b901e;
LAB_001b90c0:
      pbVar3 = local_4010;
      do {
        do {
          uVar5 = uVar5 >> 8 ^ *(uint *)(&DAT_0021d810 + (uVar5 & 0xff ^ (uint)*pbVar3) * 4);
          pbVar3 = pbVar3 + 1;
          uVar2 = uVar2 - 1;
        } while (uVar2 != 0);
        do {
          uVar4 = ~uVar5;
          uVar2 = FUN_0018b100(local_4010,1,0x4000,iVar1);
          if (uVar2 == 0) goto LAB_001b90ed;
          if (uVar2 < 4) goto LAB_001b90c0;
LAB_001b901e:
          pbVar3 = local_4010;
          uVar4 = uVar2 - 4;
          uVar6 = uVar4 & 0xfffffffc;
          do {
            uVar5 = uVar5 >> 8 ^ *(uint *)(&DAT_0021d810 + (uVar5 & 0xff ^ (uint)*pbVar3) * 4);
            uVar5 = uVar5 >> 8 ^ *(uint *)(&DAT_0021d810 + (uVar5 & 0xff ^ (uint)pbVar3[1]) * 4);
            uVar5 = uVar5 >> 8 ^ *(uint *)(&DAT_0021d810 + (uVar5 & 0xff ^ (uint)pbVar3[2]) * 4);
            uVar5 = uVar5 >> 8 ^ *(uint *)(&DAT_0021d810 + (uVar5 & 0xff ^ (uint)pbVar3[3]) * 4);
            uVar2 = uVar2 - 4;
            pbVar3 = pbVar3 + 4;
          } while (3 < uVar2);
          uVar2 = uVar4 - uVar6;
        } while (uVar2 == 0);
        pbVar3 = local_4010 + uVar6 + 4;
      } while( true );
    }
LAB_001b90ed:
    FUN_0018b120(iVar1);
  }
  return uVar4;
}

