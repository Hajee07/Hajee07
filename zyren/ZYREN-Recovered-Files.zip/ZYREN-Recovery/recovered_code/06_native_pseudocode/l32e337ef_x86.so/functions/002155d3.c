/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 002155d3 FUN_002155d3 */

/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined8 __regparm2 FUN_002155d3(undefined4 param_1_00,undefined4 param_2,int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  byte bVar5;
  undefined4 local_11c [32];
  undefined4 local_9c [18];
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_18;
  undefined4 local_14;
  
  bVar5 = 0;
  local_14 = param_2;
  FUN_00215085();
  iVar1 = *(int *)(param_1 + 0xc);
  puVar3 = local_11c;
  puVar4 = local_9c;
  for (iVar2 = 0x20; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = *puVar3;
    puVar3 = puVar3 + (uint)bVar5 * -2 + 1;
    puVar4 = puVar4 + (uint)bVar5 * -2 + 1;
  }
  if (iVar1 == 0) {
    iVar1 = FUN_00215150();
  }
  else {
    iVar1 = FUN_00215218();
  }
  if (iVar1 != 7) {
                    /* WARNING: Subroutine does not return */
    FUN_0018b160();
  }
  iVar1 = FUN_00213db9();
  FUN_002153c2(local_54,local_50,iVar1,iVar1);
  *(undefined4 *)(&stack0x00000000 + iVar1) = local_50;
  return CONCAT44(local_14,local_18);
}

