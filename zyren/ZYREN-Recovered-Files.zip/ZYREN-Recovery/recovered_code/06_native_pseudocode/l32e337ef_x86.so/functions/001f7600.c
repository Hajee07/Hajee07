/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7600 FUN_001f7600 */

void FUN_001f7600(undefined4 *param_1,undefined4 param_2)

{
  FUN_001f73f0(*param_1,param_2);
  return;
}

