/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001ddc00 FUN_001ddc00 */

undefined4 FUN_001ddc00(uint *param_1,int param_2,uint param_3)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  code *pcVar4;
  
  uVar2 = 0;
  if (param_1 == (uint *)0x0) {
    return uVar2;
  }
  uVar1 = param_1[0x12];
  if ((uVar1 == 0) || (param_1[5] != 1)) {
    param_1[7] = 0x18;
    return uVar2;
  }
  if ((param_3 & 0x4000) == 0) {
    uVar3 = param_1[4];
    if (*(int *)(uVar1 + 0x34) != 0) goto LAB_001ddc70;
    if (uVar3 == 0xffff) goto LAB_001ddc9d;
    if (param_1[1] + (uint)(0xffffffb3 < *param_1) != 0) {
      param_1[7] = 3;
      return uVar2;
    }
  }
  else {
    if (*(int *)(uVar1 + 0x34) == 0) goto LAB_001ddd25;
    uVar3 = param_1[4];
LAB_001ddc70:
    if (uVar3 == 0xffffffff) {
LAB_001ddc9d:
      param_1[7] = 2;
      return uVar2;
    }
  }
  if (*(int *)(uVar1 + 0x3c) == 0) {
    if (*(int *)(uVar1 + 0x48) == 0) {
      if (param_1[0xf] == 0) goto LAB_001ddd25;
      goto LAB_001ddcd1;
    }
    if ((uint *)param_1[0x11] != param_1) {
LAB_001ddd25:
      param_1[7] = 0x18;
      return uVar2;
    }
    *(undefined4 *)(uVar1 + 0x50) = *(undefined4 *)(uVar1 + 0x4c);
    pcVar4 = FUN_001dd1e0;
  }
  else if (((uint *)param_1[0x11] != param_1) ||
          ((pcVar4 = FUN_001dd850, param_2 == 0 && (param_1[6] == 4)))) goto LAB_001ddd25;
  param_1[0xf] = (uint)pcVar4;
  param_1[0x10] = 0;
LAB_001ddcd1:
  param_1[1] = param_1[3];
  *param_1 = param_1[2];
  param_1[2] = 0;
  param_1[3] = 0;
  (*(code *)param_1[0xb])(param_1[0xd],*(undefined4 *)(uVar1 + 0x20));
  *(undefined4 *)(uVar1 + 0x24) = 0;
  *(undefined4 *)(uVar1 + 0x20) = 0;
  *(undefined4 *)(uVar1 + 0x2c) = 0;
  *(undefined4 *)(uVar1 + 0x28) = 0;
  param_1[5] = 2;
  return 1;
}

