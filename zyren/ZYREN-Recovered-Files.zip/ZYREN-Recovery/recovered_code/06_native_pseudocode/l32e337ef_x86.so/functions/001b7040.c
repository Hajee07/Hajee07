/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b7040 FUN_001b7040 */

undefined8 FUN_001b7040(byte *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  if (*param_1 == 0) {
    uVar2 = 0;
    uVar4 = 0;
LAB_001b70bd:
    return CONCAT44(uVar4,uVar2);
  }
  uVar5 = 0;
  uVar2 = 0;
  uVar4 = 0;
  uVar7 = (uint)*param_1;
  do {
    uVar8 = 0;
    uVar6 = (uVar4 << 0x1d | uVar2 >> 3) ^ uVar2 << 7;
    uVar3 = uVar4 >> 3 ^ (uVar4 << 7 | uVar2 >> 0x19);
    while( true ) {
      uVar2 = uVar2 ^ uVar7 ^ uVar6;
      uVar4 = uVar4 ^ uVar8 ^ uVar3;
      iVar1 = uVar5 + 1;
      uVar5 = uVar5 + 1;
      if (param_1[iVar1] == 0) goto LAB_001b70bd;
      uVar7 = (uint)param_1[iVar1];
      if ((uVar5 & 1) == 0) break;
      uVar3 = uVar4 << 0xb | uVar2 >> 0x15;
      uVar6 = uVar2 << 0xb | uVar7;
      uVar7 = ~(uVar4 << 0x1b | uVar2 >> 5);
      uVar8 = ~(uVar4 >> 5);
    }
  } while( true );
}

