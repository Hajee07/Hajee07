/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00190170 FUN_00190170 */

void FUN_00190170(undefined4 param_1,undefined4 param_2)

{
  FUN_001901a0(param_1,param_2);
  return;
}

