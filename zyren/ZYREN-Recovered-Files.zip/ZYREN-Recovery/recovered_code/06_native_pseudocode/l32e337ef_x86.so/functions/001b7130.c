/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b7130 FUN_001b7130 */

uint FUN_001b7130(uint param_1,uint param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  
  iVar6 = *(int *)PTR_DAT_0024bccc;
  if (iVar6 != 0) {
    iVar4 = 0;
    do {
      while( true ) {
        uVar5 = (iVar4 * 2 + iVar6) / 2;
        puVar1 = *(uint **)(*(int *)PTR_DAT_0024bcd0 + uVar5 * 4);
        uVar2 = *puVar1;
        uVar3 = puVar1[1];
        if (uVar3 < param_2 || uVar3 - param_2 < (uint)(uVar2 < param_1)) break;
        if (uVar3 <= param_2 && (uint)(param_1 < uVar2) <= param_2 - uVar3) {
          return uVar5;
        }
        iVar6 = uVar5 - iVar4;
        if (iVar6 == 0) {
          return 0xffffffff;
        }
      }
      iVar6 = iVar6 + iVar4;
      iVar4 = uVar5 + 1;
      iVar6 = iVar6 + ~uVar5;
    } while (iVar6 != 0);
  }
  return 0xffffffff;
}

