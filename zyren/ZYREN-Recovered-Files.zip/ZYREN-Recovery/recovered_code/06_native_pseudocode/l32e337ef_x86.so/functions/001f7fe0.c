/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7fe0 FUN_001f7fe0 */

void FUN_001f7fe0(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined *puVar2;
  undefined4 local_20 [2];
  int local_18;
  
  puVar2 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(int *)PTR___stack_chk_guard_0024bd6c;
  FUN_001f4b70(param_1 + 0xc);
  if ((*(byte *)(param_1 + 0x14) & 1) == 0) {
    local_20[0] = 0;
    iVar1 = *(int *)(param_1 + 8);
    FUN_001f8ce0(local_20);
    if (iVar1 == 0) {
      FUN_001f8d40(param_1 + 8,param_2);
      *(byte *)(param_1 + 0x14) = *(byte *)(param_1 + 0x14) | 4;
      FUN_001f76c0(param_1 + 0x10);
      FUN_001f4bf0(param_1 + 0xc);
      if (*(int *)puVar2 == local_18) {
        return;
      }
                    /* WARNING: Subroutine does not return */
      FUN_0018adc0();
    }
  }
                    /* try { // try from 001f8081 to 001f808f has its CatchHandler @ 001f8090 */
                    /* WARNING: Subroutine does not return */
  FUN_001f7e20(2);
}

