/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f6aa0 FUN_001f6aa0 */

void FUN_001f6aa0(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  undefined *puVar5;
  undefined4 local_40;
  uint local_3c;
  undefined4 local_38;
  uint local_34;
  int local_30;
  byte local_2c;
  undefined local_28 [4];
  undefined4 local_24;
  int local_1c;
  undefined4 local_18;
  
  puVar5 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(undefined4 *)PTR___stack_chk_guard_0024bd6c;
  local_40 = param_2;
  local_3c = param_3;
  local_34 = 0;
  local_38 = 0;
  local_30 = 0;
  uVar1 = FUN_0018af10(param_4);
  if (0xffffffef < uVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_001a6e40(&local_38);
  }
  if (uVar1 < 0xb) {
    local_38 = CONCAT31(local_38._1_3_,(char)uVar1 * '\x02');
    iVar2 = (int)&local_38 + 1;
    if (uVar1 == 0) goto LAB_001f6b57;
  }
  else {
    uVar3 = uVar1 + 0x10 & 0xfffffff0;
    iVar2 = FUN_001f5520(uVar3);
    local_38 = uVar3 | 1;
    local_34 = uVar1;
    local_30 = iVar2;
  }
  FUN_0018ae80(iVar2,param_4,uVar1,puVar5);
LAB_001f6b57:
  *(undefined *)(iVar2 + uVar1) = 0;
                    /* try { // try from 001f6b5b to 001f6b79 has its CatchHandler @ 001f6c0c */
  piVar4 = &local_38;
  FUN_001f63b0(local_28,&local_40);
                    /* try { // try from 001f6b7d to 001f6b88 has its CatchHandler @ 001f6bee */
  FUN_001f5c20(param_1,local_28);
  if ((local_2c & 1) != 0) {
    FUN_001f5680(local_24);
  }
  if ((local_3c & 1) != 0) {
    FUN_001f5680(local_34);
  }
  *param_1 = PTR_DAT_0024bd84 + 8;
  param_1[2] = param_2;
  param_1[3] = param_3;
  if (*piVar4 != local_1c) {
                    /* WARNING: Subroutine does not return */
    FUN_0018adc0();
  }
  return;
}

