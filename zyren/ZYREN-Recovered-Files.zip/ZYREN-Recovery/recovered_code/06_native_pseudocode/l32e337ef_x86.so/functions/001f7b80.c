/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7b80 FUN_001f7b80 */

undefined4 * FUN_001f7b80(void)

{
  int iVar1;
  
  if (DAT_00276e64 == '\0') {
    iVar1 = FUN_001f9a30(&DAT_00276e64);
    if (iVar1 != 0) {
      FUN_001f5de0(&DAT_00276e60);
      DAT_00276e60 = &PTR_FUN_0024a240;
      FUN_0018adb0(PTR_FUN_0024bd90,&DAT_00276e60,&PTR_LOOP_00249de0);
      FUN_001f9ba0(&DAT_00276e64);
    }
  }
  return &DAT_00276e60;
}

