/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f7c10 FUN_001f7c10 */

/* WARNING: Removing unreachable block (ram,0x001f7c60) */

void FUN_001f7c10(undefined4 *param_1,undefined8 param_2)

{
  undefined *puVar1;
  undefined local_28 [12];
  int local_1c;
  undefined4 local_18;
  
  puVar1 = PTR___stack_chk_guard_0024bd6c;
  local_18 = *(undefined4 *)PTR___stack_chk_guard_0024bd6c;
  FUN_001f6370(local_28);
                    /* try { // try from 001f7c4a to 001f7c58 has its CatchHandler @ 001f7c98 */
  FUN_001f5a60(param_1,local_28);
  *param_1 = PTR_DAT_0024bd94 + 8;
  *(undefined8 *)(param_1 + 2) = param_2;
  if (*(int *)puVar1 != local_1c) {
                    /* WARNING: Subroutine does not return */
    FUN_0018adc0();
  }
  return;
}

