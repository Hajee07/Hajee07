/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000e8170 FUN_000e8170 */

int FUN_000e8170(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *in_ECX;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  char *pcVar8;
  char *pcVar9;
  undefined4 local_ac;
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined2 local_9c;
  undefined4 local_98;
  undefined2 local_94;
  undefined2 uStack_92;
  undefined2 uStack_90;
  undefined4 local_8e;
  undefined4 local_88;
  undefined4 local_84;
  undefined4 local_80;
  undefined local_7c [15];
  undefined4 uStack_6d;
  undefined local_5c [16];
  undefined4 local_4c;
  undefined4 local_48;
  uint uStack_44;
  undefined local_3c [16];
  undefined local_2c [16];
  
  local_5c = ZEXT816(0);
  local_4c = 0;
  local_48 = 0;
  uStack_44 = uStack_44 & 0xff000000;
  thunk_FUN_00061f80(local_5c,&LAB_0017f0cb,0x1b);
  local_7c = SUB1615(ZEXT816(0),0);
  uStack_6d = 0;
  thunk_FUN_00061f80(local_7c,&DAT_0017f0e6,0x13);
  iVar1 = (**(code **)(*in_ECX + 0x18))(in_ECX,local_5c);
  iVar5 = 0;
  if (iVar1 != 0) {
    pcVar8 = "()Landroid/app/Application;";
    iVar2 = (**(code **)(*in_ECX + 0x1c4))(in_ECX,iVar1,local_7c,"()Landroid/app/Application;");
    if ((iVar2 != 0) && (iVar5 = (**(code **)(*in_ECX + 0x1c8))(in_ECX,iVar1,iVar2), iVar5 == 0)) {
      local_a0 = 0;
      local_a4 = 0;
      local_9c = 0;
      thunk_FUN_00061f80(&local_a4,&DAT_0017f0f9,10);
      local_a8 = 0;
      local_ac = 0;
      thunk_FUN_00061f80(&local_ac,&DAT_0017f103,8);
      local_84 = 0;
      local_88 = 0;
      local_80 = 0;
      puVar6 = &local_88;
      thunk_FUN_00061f80(puVar6,&DAT_0017f10b,0xc);
      local_94 = 0;
      local_98 = 0;
      local_8e = 0;
      uStack_92 = 0;
      uStack_90 = 0;
      thunk_FUN_00061f80(&local_98,&DAT_0017f117,0xe);
      local_2c = ZEXT816(0);
      local_3c = ZEXT816(0);
      puVar7 = (undefined4 *)DAT_0028032c;
      pcVar9 = DAT_0028032c;
      if (DAT_0028032c == (char *)0x0) {
        puVar6 = &local_a4;
        puVar7 = &local_ac;
        pcVar9 = pcVar8;
      }
      FUN_000fe96a(local_3c,puVar6,puVar7,pcVar9);
      uVar3 = (**(code **)(*in_ECX + 0x18))(in_ECX,local_3c);
      uVar4 = (**(code **)(*in_ECX + 0x1c4))(in_ECX,uVar3,&local_98,"()Landroid/content/Context;");
      iVar5 = (**(code **)(*in_ECX + 0x1c8))(in_ECX,uVar3,uVar4);
    }
  }
  return iVar5;
}

