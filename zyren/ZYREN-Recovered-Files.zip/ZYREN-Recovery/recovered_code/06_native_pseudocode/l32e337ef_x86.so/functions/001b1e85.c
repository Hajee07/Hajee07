/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b1e85 FUN_001b1e85 */

undefined4 FUN_001b1e85(void)

{
  int unaff_retaddr;
  
  return CONCAT31((int3)((uint)*(int **)(&DAT_00099e1f + unaff_retaddr) >> 8),
                  **(int **)(&DAT_00099e1f + unaff_retaddr) != 0);
}

