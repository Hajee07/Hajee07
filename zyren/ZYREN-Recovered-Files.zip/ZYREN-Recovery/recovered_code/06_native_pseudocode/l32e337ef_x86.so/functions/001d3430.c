/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d3430 FUN_001d3430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __regparm1 FUN_001d3430(undefined4 param_1_00,int param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined *puVar6;
  undefined4 *puVar7;
  
  if (param_1 == 0) {
    return 0xfffffffe;
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  puVar6 = PTR_FUN_0024bd00;
  pcVar1 = *(code **)(param_1 + 0x20);
  if (pcVar1 == (code *)0x0) {
    *(undefined **)(param_1 + 0x20) = PTR_FUN_0024bd00;
    iVar2 = *(int *)(param_1 + 0x24);
    pcVar1 = (code *)puVar6;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x24);
  }
  if (iVar2 == 0) {
    *(undefined **)(param_1 + 0x24) = PTR_FUN_0024bd04;
  }
  puVar7 = (undefined4 *)(*pcVar1)(*(undefined4 *)(param_1 + 0x28),1,0xab08,0x1d3438,param_1_00);
  if (puVar7 == (undefined4 *)0x0) {
    return 0xfffffffc;
  }
  *(undefined4 **)(param_1 + 0x1c) = puVar7;
  *puVar7 = 0;
  puVar7[0x2ac1] = 1;
  uVar5 = _UNK_0021b67c;
  uVar4 = _UNK_0021b678;
  uVar3 = _UNK_0021b674;
  puVar7[0xabc] = _DAT_0021b670;
  puVar7[0xabd] = uVar3;
  puVar7[0xabe] = uVar4;
  puVar7[0xabf] = uVar5;
  puVar7[0xac0] = 0xf;
  return 0;
}

