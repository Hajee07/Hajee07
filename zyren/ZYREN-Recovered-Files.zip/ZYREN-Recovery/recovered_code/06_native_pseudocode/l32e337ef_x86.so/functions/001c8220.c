/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c8220 FUN_001c8220 */

undefined4 FUN_001c8220(int param_1,int param_2,uint param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  *(undefined4 *)(param_1 + 0x5cf0) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d0c) = 0;
  *(undefined4 *)(param_1 + 0x5cfc) = 0;
  *(undefined4 *)(param_1 + 0x5d18) = 0;
  puVar1 = *(undefined4 **)(param_1 + 0x5ce8);
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = puVar1[0x170c];
    uVar3 = puVar1[0x170d];
    uVar4 = puVar1[0x170e];
    FUN_001cc0e0(*puVar1,uVar2,uVar3,uVar4);
    FUN_001cc0e0(puVar1,uVar2,uVar3,uVar4);
  }
  if ((param_2 == 0) || (param_3 < 8)) {
    *(undefined4 *)(param_1 + 0x5ce8) = 0;
    iVar5 = 0;
  }
  else {
    iVar5 = FUN_001c7a50(param_2,param_3,0,0,0,0);
    *(int *)(param_1 + 0x5ce8) = iVar5;
    if (iVar5 == 0) {
      return 0xffffffc0;
    }
  }
  *(int *)(param_1 + 0x5cec) = iVar5;
  *(undefined4 *)(param_1 + 0x5d24) = 0;
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  return 5;
}

