/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c80b0 FUN_001c80b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_001c80b0(int *param_1,undefined *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  
  piVar1 = (int *)0x0;
  if ((&UNK_00025d47 < param_2) && (((uint)param_1 & 7) == 0)) {
    param_1[0x170f] = 5;
    param_1[0x1719] = 0;
    iVar2 = (int)param_1 + _DAT_0021b5c0;
    iVar3 = (int)param_1 + _UNK_0021b5c4;
    iVar4 = (int)param_1 + _UNK_0021b5c8;
    puVar5 = (undefined4 *)((int)param_1 + _UNK_0021b5cc);
    param_1[0x170c] = 0;
    param_1[0x170b] = 0;
    param_1[0x170e] = 0;
    param_1[0x170d] = 0;
    *puVar5 = 0xc00000c;
    param_1[0x171b] = 0;
    param_1[0x171a] = 0;
    param_1[0x1732] = 0;
    *(undefined8 *)(param_1 + 0x1708) = DAT_0021dc64;
    param_1[0x170a] = DAT_0021dc6c;
    *param_1 = iVar2;
    param_1[1] = iVar3;
    param_1[2] = iVar4;
    param_1[3] = (int)puVar5;
    param_1[0x1740] = 0x8000001;
    param_1[0x1742] = 0;
    param_1[0x173b] = 0;
    param_1[0x173a] = 0;
    param_1[0x173c] = 0;
    param_1[0x173e] = 0;
    param_1[0x1739] = (int)param_2;
    param_1[0x173d] = (int)(param_1 + 0x9752);
    piVar1 = param_1;
  }
  return piVar1;
}

