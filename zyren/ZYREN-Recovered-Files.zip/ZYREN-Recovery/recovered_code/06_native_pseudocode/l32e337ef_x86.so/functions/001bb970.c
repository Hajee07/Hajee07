/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001bb970 FUN_001bb970 */

undefined4 FUN_001bb970(int *param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uVar6;
  uint uVar7;
  
  iVar2 = param_2[2];
  uVar7 = (uint)(*(ushort *)param_2[10] >> 8);
  iVar3 = *(int *)((ushort *)param_2[10] + 1);
  iVar4 = *(int *)(iVar2 + uVar7 * 0xc);
  if (((iVar4 == 0x4000) || (iVar4 == 0x100)) &&
     (iVar4 = *(int *)(iVar2 + 4 + uVar7 * 0xc), iVar4 != 0)) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar4);
  }
  *(undefined4 *)(iVar2 + uVar7 * 0xc) = 0x4000;
  pcVar5 = (char *)(*(int *)(*param_2 + 0x2c) + *(int *)(*(int *)(*param_2 + 8) + iVar3 * 4));
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 < '\0');
  uVar6 = (**(code **)(*param_1 + 0x29c))(param_1,pcVar5);
  *(undefined4 *)(iVar2 + 4 + uVar7 * 0xc) = uVar6;
  return 0;
}

