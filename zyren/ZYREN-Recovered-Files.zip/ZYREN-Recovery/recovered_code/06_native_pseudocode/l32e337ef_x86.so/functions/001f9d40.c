/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9d40 FUN_001f9d40 */

void __regparm3 FUN_001f9d40(undefined4 param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  
                    /* try { // try from 001f9d4f to 001f9d53 has its CatchHandler @ 001f9d87 */
  piVar3 = (int *)FUN_001f9920(param_1);
  if ((piVar3 != (int *)0x0) && (iVar1 = *piVar3, iVar1 != 0)) {
                    /* try { // try from 001f9d61 to 001f9d68 has its CatchHandler @ 001f9d85 */
    cVar2 = FUN_001f8f60(iVar1 + 0x30);
    if (cVar2 != '\0') {
      uVar4 = *(undefined4 *)(iVar1 + 0xc);
      goto LAB_001f9d7a;
    }
  }
  uVar4 = *(undefined4 *)PTR_PTR_FUN_0024bdac;
LAB_001f9d7a:
  uVar4 = FUN_001f9e20(uVar4);
                    /* catch(type#1 @ 00000000) { ... } // from try @ 001f9d61 with catch @ 001f9d85
                        */
                    /* catch(type#1 @ 00000000) { ... } // from try @ 001f9d4f with catch @ 001f9d87
                        */
                    /* WARNING: Subroutine does not return */
  FUN_001a68b0(uVar4);
}

