/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a6a50 FUN_001a6a50 */

void FUN_001a6a50(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_001f8f90(8);
                    /* try { // try from 001a6a74 to 001a6a7f has its CatchHandler @ 001a6a9f */
  FUN_001a6ac0(uVar1,param_1);
  uVar2 = FUN_001f9120(uVar1,PTR_PTR_0024bc44,PTR_FUN_0024bc40);
                    /* catch() { ... } // from try @ 001a6a74 with catch @ 001a6a9f */
  FUN_001f8ff0(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_002155d3(uVar2);
}

