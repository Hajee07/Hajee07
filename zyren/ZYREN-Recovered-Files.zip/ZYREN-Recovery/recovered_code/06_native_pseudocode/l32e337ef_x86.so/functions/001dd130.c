/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001dd130 FUN_001dd130 */

undefined4 FUN_001dd130(int param_1,uint param_2,uint param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  *(code **)(param_1 + 0x3c) = FUN_001dd1e0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  if ((short)param_4 < 0) {
    *(code **)(param_1 + 0x38) = FUN_001d8590;
  }
  *(int *)(param_1 + 0x44) = param_1;
  iVar1 = FUN_001dcd00(param_1,param_2,0,param_4);
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    *(undefined4 *)(param_1 + 0x18) = 3;
    if (param_2 < param_3) {
      param_2 = param_3;
    }
    uVar3 = 1;
    if (param_2 != 0) {
      iVar2 = (**(code **)(param_1 + 0x28))(*(undefined4 *)(param_1 + 0x34),1,param_2);
      iVar1 = *(int *)(param_1 + 0x48);
      *(int *)(iVar1 + 0x48) = iVar2;
      if (iVar2 == 0) {
        uVar3 = 0;
        FUN_001dd2d0();
        *(undefined4 *)(param_1 + 0x1c) = 0x10;
      }
      else {
        *(uint *)(iVar1 + 0x50) = param_2;
      }
    }
  }
  return uVar3;
}

