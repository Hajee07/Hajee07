/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001d0aa0 FUN_001d0aa0 */

uint FUN_001d0aa0(void)

{
  longlong lVar1;
  undefined8 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar4 = DAT_00272704 & 0x3fffffff;
  do {
    do {
      uVar2 = rdtsc();
      uVar3 = (uint)uVar2 - uVar4;
    } while (uVar3 == 0);
    uVar5 = uVar4;
    if (uVar4 == 0) {
      uVar5 = 1;
    }
    lVar1 = (ulonglong)uVar3 * (ulonglong)uVar5;
    DAT_00272704 = (int)((ulonglong)lVar1 >> 0x20) +
                   ((int)((ulonglong)uVar2 >> 0x20) - (uint)((uint)uVar2 < uVar4)) * uVar5 +
                   (int)lVar1;
    uVar4 = uVar4 & 7;
    uVar3 = DAT_00272704 << (byte)uVar4;
    uVar5 = DAT_00272704 >> ((byte)uVar4 ^ 0x1f) | uVar3;
  } while ((uVar3 < 0x10000) || ((uVar5 & 0xffff) == 0));
  return uVar5;
}

