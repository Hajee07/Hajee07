/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001f9a30 FUN_001f9a30 */

undefined4 FUN_001f9a30(char *param_1)

{
  byte bVar1;
  bool bVar2;
  int iVar3;
  undefined4 uVar4;
  int local_18;
  
  uVar4 = 0;
  if (*param_1 == '\0') {
    iVar3 = FUN_0018adf0(&DAT_00276e74);
    if (iVar3 != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_001fd290("%s failed to acquire mutex","__cxa_guard_acquire");
    }
    if ((param_1[1] & 2U) == 0) {
      bVar2 = false;
    }
    else {
      iVar3 = *(int *)(param_1 + 4);
                    /* try { // try from 001f9a84 to 001f9a8f has its CatchHandler @ 001f9b59 */
      local_18 = FUN_0018b040(0xe0);
      if (iVar3 == local_18) {
                    /* try { // try from 001f9b48 to 001f9b58 has its CatchHandler @ 001f9b59 */
                    /* WARNING: Subroutine does not return */
        FUN_001fd290("__cxa_guard_acquire detected recursive initialization");
      }
      bVar2 = true;
    }
    while (bVar1 = param_1[1], (bVar1 & 2) != 0) {
      param_1[1] = bVar1 | 4;
                    /* try { // try from 001f9abd to 001f9acc has its CatchHandler @ 001f9b66 */
      FUN_0018b450(&DAT_00276e78,&DAT_00276e74);
    }
    uVar4 = 0;
    if (bVar1 != 1) {
      if (!bVar2) {
                    /* try { // try from 001f9ae0 to 001f9aeb has its CatchHandler @ 001f9b59 */
        local_18 = FUN_0018b040(0xe0);
      }
      *(int *)(param_1 + 4) = local_18;
      param_1[1] = '\x02';
      uVar4 = 1;
    }
                    /* try { // try from 001f9af8 to 001f9b03 has its CatchHandler @ 001f9b5b */
    iVar3 = FUN_0018ae00(&DAT_00276e74);
    if (iVar3 != 0) {
                    /* try { // try from 001f9b2d to 001f9b47 has its CatchHandler @ 001f9b5b */
                    /* WARNING: Subroutine does not return */
      FUN_001fd290("%s failed to release mutex","__cxa_guard_acquire");
    }
  }
  return uVar4;
}

