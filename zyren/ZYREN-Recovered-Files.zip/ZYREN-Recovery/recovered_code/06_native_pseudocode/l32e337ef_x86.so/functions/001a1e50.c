/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a1e50 FUN_001a1e50 */

undefined FUN_001a1e50(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,
                      undefined4 param_6,undefined param_7)

{
  undefined *puVar1;
  undefined *puVar2;
  undefined *puVar3;
  undefined uVar4;
  int *piVar5;
  int iVar6;
  
  uVar4 = (**(code **)PTR_DAT_0024bbc8)(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  if ((param_1 != 0) && (DAT_00273e74 == 0)) {
    piVar5 = (int *)FUN_001f5520(0xc);
    piVar5[2] = param_1;
    puVar2 = PTR_DAT_0024bba8;
    piVar5[1] = (int)PTR_DAT_0024bba8;
    iVar6 = *(int *)puVar2;
    *piVar5 = iVar6;
    *(int **)(iVar6 + 4) = piVar5;
    *(int **)puVar2 = piVar5;
    *(int *)(puVar2 + 8) = *(int *)(puVar2 + 8) + 1;
  }
  puVar2 = PTR_DAT_0024bb68;
  if ((((*PTR_DAT_0024bbcc != '\0') && (param_2 != 0)) && (param_1 != 0)) && (param_3 != 0)) {
    FUN_001f4b70(PTR_DAT_0024bb68);
    puVar3 = PTR_DAT_0024bb6c;
    for (puVar1 = *(undefined **)(PTR_DAT_0024bb6c + 4); puVar1 != PTR_DAT_0024bb6c;
        puVar1 = *(undefined **)(puVar1 + 4)) {
      if (*(int *)(puVar1 + 0xc) == param_3) goto LAB_001a1f6f;
    }
    iVar6 = FUN_0018af40(param_2);
    piVar5 = (int *)FUN_001f5520(0x18);
    piVar5[2] = param_1;
    piVar5[3] = param_3;
    piVar5[4] = 0;
    piVar5[5] = iVar6;
    piVar5[1] = (int)puVar3;
    iVar6 = *(int *)puVar3;
    *piVar5 = iVar6;
    *(int **)(iVar6 + 4) = piVar5;
    *(int **)puVar3 = piVar5;
    *(int *)(puVar3 + 8) = *(int *)(puVar3 + 8) + 1;
LAB_001a1f6f:
    FUN_001f4bf0(puVar2);
  }
  return uVar4;
}

