/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c3400 FUN_001c3400 */

undefined4 FUN_001c3400(int *param_1,int param_2)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  iVar2 = *(int *)(param_2 + 8);
  uVar1 = **(ushort **)(param_2 + 0x28);
  uVar5 = uVar1 >> 8 & 0xf;
  uVar6 = (uint)(uVar1 >> 0xc);
  uVar1 = (*(ushort **)(param_2 + 0x28))[1];
  iVar3 = *(int *)(iVar2 + uVar5 * 0xc);
  if (((iVar3 == 0x4000) || (iVar3 == 0x100)) &&
     (iVar3 = *(int *)(iVar2 + 4 + uVar5 * 0xc), iVar3 != 0)) {
    (**(code **)(*param_1 + 0x5c))(param_1,iVar3);
  }
  *(undefined4 *)(iVar2 + uVar5 * 0xc) = 0x10;
  iVar3 = *(int *)(iVar2 + uVar6 * 0xc);
  uVar4 = 0;
  switch(iVar3) {
  case 1:
  case 2:
    uVar4 = (uint)*(char *)(iVar2 + 4 + uVar6 * 0xc);
    break;
  case 3:
  case 5:
  case 6:
  case 7:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    break;
  case 4:
    uVar4 = (uint)*(ushort *)(iVar2 + 4 + uVar6 * 0xc);
    break;
  case 8:
    uVar4 = (uint)*(short *)(iVar2 + 4 + uVar6 * 0xc);
    break;
  default:
    if (iVar3 != 0x1000) break;
  case 0x10:
    uVar4 = *(uint *)(iVar2 + 4 + uVar6 * 0xc);
  }
  *(uint *)(iVar2 + 4 + uVar5 * 0xc) = (int)(short)uVar1 - uVar4;
  return 0;
}

