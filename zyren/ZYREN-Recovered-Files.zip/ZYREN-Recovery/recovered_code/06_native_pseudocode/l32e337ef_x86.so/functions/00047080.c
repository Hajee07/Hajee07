/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00047080 FUN_00047080 */

undefined4 FUN_00047080(int **param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  bool bVar4;
  int **local_2c;
  ushort local_26;
  int **local_18;
  
  bVar4 = PTR_dl_iterate_phdr_0028125c == (undefined *)0x0;
  if (bVar4) {
    thunk_FUN_00175380(param_1);
  }
  else {
    FUN_000546d2(FUN_001111e0,param_1);
  }
  local_18 = (int **)*param_1;
  do {
    if (local_18 == param_1) {
      if (bVar4) {
        FUN_00111800(param_1);
      }
      local_18 = (int **)*param_1;
      while( true ) {
        if (local_18 != param_1) {
          local_2c = (int **)*local_18;
        }
        if (local_18 == param_1 || local_18 == (int **)0x0) break;
        if (((local_18[6] == (int *)0x0) || (local_18[7] == (int *)0x0)) ||
           ((local_18[0xb] == (int *)0x0 && (local_18[0xc] == (int *)0x0)))) {
          piVar1 = *local_18;
          piVar2 = local_18[1];
          piVar1[1] = (int)piVar2;
          *piVar2 = (int)piVar1;
          FUN_0005464e(local_18);
        }
        local_18 = local_2c;
      }
      return 0;
    }
    if ((*(byte *)(local_18 + 0xf) & 1) == 0) {
      piVar1 = local_18[2];
      if ((int *)piVar1[7] < local_18[3]) {
        iVar3 = (int)local_18[2] + piVar1[7];
        for (local_26 = 0; local_26 != *(ushort *)(piVar1 + 0xb); local_26 = local_26 + 1) {
          if (*(int *)(iVar3 + (uint)local_26 * 0x20) == 1) {
            local_18[10] = (int *)((int)local_18[2] - *(int *)(iVar3 + (uint)local_26 * 0x20 + 8));
            break;
          }
        }
        FUN_00111480(local_18,iVar3,*(undefined2 *)(piVar1 + 0xb));
      }
      else {
        FUN_0005460c(4,"IMPORT","error: special e_phoff found at %s",(int)local_18 + 0x3d);
      }
    }
    local_18 = (int **)*local_18;
  } while( true );
}

