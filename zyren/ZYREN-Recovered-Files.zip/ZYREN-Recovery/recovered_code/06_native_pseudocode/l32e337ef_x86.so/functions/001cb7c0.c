/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001cb7c0 FUN_001cb7c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_001cb7c0(uint *param_1,ulonglong *param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  ulonglong *puVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  longlong lVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  
  uVar1 = *param_1;
  *param_1 = *param_1 + param_3;
  param_1[1] = param_1[1] + (uint)CARRY4(uVar1,param_3);
  uVar1 = param_1[0x12];
  if (uVar1 + param_3 < 0x20) {
    FUN_0018ae80((int)param_1 + uVar1 + 0x28,param_2,param_3);
    param_3 = param_3 + param_1[0x12];
  }
  else {
    puVar9 = (ulonglong *)(param_3 + (int)param_2);
    if (uVar1 != 0) {
      FUN_0018ae80((int)param_1 + uVar1 + 0x28,param_2,0x20 - uVar1);
      uVar8 = _UNK_0021b638;
      uVar7 = _DAT_0021b630;
      uVar6 = _UNK_0021b628;
      uVar5 = _DAT_0021b620;
      uVar4 = _UNK_0021b618;
      uVar3 = _DAT_0021b610;
      uVar2 = _UNK_0021b608;
      uVar1 = _DAT_0021b600;
      uVar10 = *(ulonglong *)(param_1 + 10);
      uVar11 = *(ulonglong *)(param_1 + 0xc);
      uVar19 = *(longlong *)(param_1 + 2) +
               ((uVar10 >> 0x20) * (ulonglong)_DAT_0021b600 +
                (uVar10 & 0xffffffff) * (ulonglong)_DAT_0021b610 << 0x20) +
               (uVar10 & 0xffffffff) * (ulonglong)_DAT_0021b600;
      uVar20 = *(longlong *)(param_1 + 4) +
               ((uVar11 >> 0x20) * (ulonglong)_UNK_0021b608 +
                (uVar11 & 0xffffffff) * (ulonglong)_UNK_0021b618 << 0x20) +
               (uVar11 & 0xffffffff) * (ulonglong)_UNK_0021b608;
      uVar12 = uVar19 * 0x80000000;
      uVar13 = uVar20 * 0x80000000;
      uVar19 = uVar19 >> 0x21;
      uVar20 = uVar20 >> 0x21;
      uVar14 = (ulonglong)_UNK_0021b638;
      uVar10 = (ulonglong)_UNK_0021b628;
      uVar11 = (ulonglong)_UNK_0021b628;
      *(ulonglong *)(param_1 + 2) =
           (uVar19 | uVar12 & 0xffffffff) * (ulonglong)_DAT_0021b620 +
           ((uVar12 >> 0x20) * (ulonglong)_DAT_0021b620 +
            (uVar19 | uVar12 & 0xffffffff) * (ulonglong)_DAT_0021b630 << 0x20);
      *(ulonglong *)(param_1 + 4) =
           (uVar20 | uVar13 & 0xffffffff) * uVar11 +
           ((uVar13 >> 0x20) * uVar10 + (uVar20 | uVar13 & 0xffffffff) * uVar14 << 0x20);
      uVar10 = *(ulonglong *)(param_1 + 0xe);
      uVar11 = *(ulonglong *)(param_1 + 0x10);
      uVar14 = (uVar10 & 0xffffffff) * (ulonglong)uVar1 +
               ((uVar10 >> 0x20) * (ulonglong)uVar1 + (ulonglong)uVar3 * (uVar10 & 0xffffffff) <<
               0x20) + *(longlong *)(param_1 + 6);
      uVar12 = (uVar11 & 0xffffffff) * (ulonglong)uVar2 +
               ((uVar11 >> 0x20) * (ulonglong)uVar2 + (ulonglong)uVar4 * (uVar11 & 0xffffffff) <<
               0x20) + *(longlong *)(param_1 + 8);
      uVar10 = uVar14 * 0x80000000;
      uVar11 = uVar12 * 0x80000000;
      uVar14 = uVar14 >> 0x21;
      uVar12 = uVar12 >> 0x21;
      *(ulonglong *)(param_1 + 6) =
           (uVar14 | uVar10 & 0xffffffff) * (ulonglong)uVar5 +
           ((uVar10 >> 0x20) * (ulonglong)uVar5 + (ulonglong)uVar7 * (uVar14 | uVar10 & 0xffffffff)
           << 0x20);
      *(ulonglong *)(param_1 + 8) =
           (uVar12 | uVar11 & 0xffffffff) * (ulonglong)uVar6 +
           ((uVar11 >> 0x20) * (ulonglong)uVar6 + (ulonglong)uVar8 * (uVar12 | uVar11 & 0xffffffff)
           << 0x20);
      param_2 = (ulonglong *)((int)param_2 + (0x20 - param_1[0x12]));
      param_1[0x12] = 0;
    }
    if (param_2 + 4 <= puVar9) {
      lVar15 = *(longlong *)(param_1 + 2);
      lVar16 = *(longlong *)(param_1 + 4);
      lVar17 = *(longlong *)(param_1 + 6);
      lVar18 = *(longlong *)(param_1 + 8);
      do {
        uVar10 = *param_2;
        uVar11 = param_2[1];
        uVar14 = param_2[2];
        uVar12 = param_2[3];
        uVar13 = (uVar10 & 0xffffffff) * (ulonglong)_DAT_0021b600 +
                 ((uVar10 >> 0x20) * (ulonglong)_DAT_0021b600 +
                  (uVar10 & 0xffffffff) * (ulonglong)_DAT_0021b610 << 0x20) + lVar15;
        uVar19 = (uVar11 & 0xffffffff) * (ulonglong)_UNK_0021b608 +
                 ((uVar11 >> 0x20) * (ulonglong)_UNK_0021b608 +
                  (uVar11 & 0xffffffff) * (ulonglong)_UNK_0021b618 << 0x20) + lVar16;
        uVar10 = uVar13 * 0x80000000;
        uVar11 = uVar19 * 0x80000000;
        uVar13 = uVar13 >> 0x21;
        uVar19 = uVar19 >> 0x21;
        lVar15 = (uVar13 | uVar10 & 0xffffffff) * (ulonglong)_DAT_0021b620 +
                 ((uVar10 >> 0x20) * (ulonglong)_DAT_0021b620 +
                  (uVar13 | uVar10 & 0xffffffff) * (ulonglong)_DAT_0021b630 << 0x20);
        lVar16 = (uVar19 | uVar11 & 0xffffffff) * (ulonglong)_UNK_0021b628 +
                 ((uVar11 >> 0x20) * (ulonglong)_UNK_0021b628 +
                  (uVar19 | uVar11 & 0xffffffff) * (ulonglong)_UNK_0021b638 << 0x20);
        uVar10 = (uVar14 & 0xffffffff) * (ulonglong)_DAT_0021b600 +
                 ((uVar14 >> 0x20) * (ulonglong)_DAT_0021b600 +
                  (uVar14 & 0xffffffff) * (ulonglong)_DAT_0021b610 << 0x20) + lVar17;
        uVar11 = (uVar12 & 0xffffffff) * (ulonglong)_UNK_0021b608 +
                 ((uVar12 >> 0x20) * (ulonglong)_UNK_0021b608 +
                  (uVar12 & 0xffffffff) * (ulonglong)_UNK_0021b618 << 0x20) + lVar18;
        uVar14 = uVar10 * 0x80000000;
        uVar12 = uVar11 * 0x80000000;
        uVar10 = uVar10 >> 0x21;
        uVar11 = uVar11 >> 0x21;
        lVar17 = (uVar10 | uVar14 & 0xffffffff) * (ulonglong)_DAT_0021b620 +
                 ((uVar14 >> 0x20) * (ulonglong)_DAT_0021b620 +
                  (uVar10 | uVar14 & 0xffffffff) * (ulonglong)_DAT_0021b630 << 0x20);
        lVar18 = (uVar11 | uVar12 & 0xffffffff) * (ulonglong)_UNK_0021b628 +
                 ((uVar12 >> 0x20) * (ulonglong)_UNK_0021b628 +
                  (uVar11 | uVar12 & 0xffffffff) * (ulonglong)_UNK_0021b638 << 0x20);
        param_2 = param_2 + 4;
      } while (param_2 <= puVar9 + -4);
      *(longlong *)(param_1 + 2) = lVar15;
      *(longlong *)(param_1 + 4) = lVar16;
      *(longlong *)(param_1 + 6) = lVar17;
      *(longlong *)(param_1 + 8) = lVar18;
    }
    if (puVar9 <= param_2) {
      return 0;
    }
    param_3 = (int)puVar9 - (int)param_2;
    FUN_0018ae80(param_1 + 10,param_2,param_3);
  }
  param_1[0x12] = param_3;
  return 0;
}

