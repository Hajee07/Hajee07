/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001a0110 FUN_001a0110 */

undefined4 FUN_001a0110(int param_1,undefined4 param_2)

{
  undefined *puVar1;
  undefined *puVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  iVar3 = param_1;
  uVar4 = thunk_FUN_001b5fb5();
  puVar2 = PTR_FUN_0024bb8c;
  iVar5 = FUN_001b6030(uVar4,iVar3,PTR_FUN_0024bb8c);
  if (iVar5 != 0) {
    uVar4 = thunk_FUN_001b5fb5();
    FUN_001b60e0(uVar4,iVar3,puVar2);
    if (*(int *)(iVar5 + 4) != 0) {
      FUN_0018ae20(*(int *)(iVar5 + 4));
      *(undefined4 *)(iVar5 + 4) = 0;
    }
  }
  puVar2 = PTR_DAT_0024bb88;
  if (*(int *)(PTR_DAT_0024bb24 + 8) != 0) {
    for (puVar1 = *(undefined **)(PTR_DAT_0024bb88 + 4); puVar1 != PTR_DAT_0024bb88;
        puVar1 = *(undefined **)(puVar1 + 4)) {
      if (*(int *)(puVar1 + 8) == iVar3) {
        FUN_0018ae20(iVar3);
        FUN_001a6670(puVar2,&param_1);
        return 0;
      }
    }
  }
  uVar4 = (**(code **)PTR_DAT_0024bb84)(iVar3,param_2);
  return uVar4;
}

