/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001e2c70 thunk_FUN_001e2c75 */

undefined4 thunk_FUN_001e2c75(uint param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (0xffffffe2 < param_1) {
    uVar1 = *(undefined4 *)(&UNK_00249f04 + param_1 * -4);
  }
  return uVar1;
}

