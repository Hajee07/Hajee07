/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c9050 FUN_001c9050 */

int __regparm3
FUN_001c9050(undefined4 param_1_00,undefined8 *param_2_00,undefined8 *param_3_00,int param_1,
            int param_2,uint param_3,int *param_4,uint param_5,undefined8 *param_6,int param_7,
            uint param_8)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  int iVar12;
  undefined8 *puVar13;
  uint uVar14;
  uint uVar15;
  undefined8 *puVar16;
  int iVar17;
  undefined8 *puVar18;
  undefined8 *puVar19;
  undefined8 *puVar20;
  int iVar21;
  uint uVar22;
  
  iVar12 = param_2 + param_1;
  puVar13 = (undefined8 *)(iVar12 + (int)param_3_00);
  if (param_2_00 < puVar13) {
    return -0x46;
  }
  puVar19 = (undefined8 *)*param_4;
  if (param_5 < (uint)((int)puVar19 + param_1)) {
    return -0x14;
  }
  puVar20 = (undefined8 *)(param_1 + (int)param_3_00);
  puVar16 = param_2_00 + -1;
  if (puVar20 <= puVar16) {
    return -1;
  }
  if (puVar16 < param_3_00 || (int)puVar16 - (int)param_3_00 == 0) {
    puVar16 = param_3_00;
    if (puVar20 <= param_3_00) goto LAB_001c9161;
  }
  else {
    uVar14 = ((uint)((int)param_2_00 + (-9 - (int)param_3_00)) >> 3) + 1;
    puVar18 = param_3_00;
    if ((uVar14 < 4) ||
       ((uVar15 = ~(uint)param_3_00 + (int)param_2_00 & 0xfffffff8,
        param_3_00 < (undefined8 *)((int)puVar19 + uVar15) &&
        (puVar19 < (undefined8 *)(uVar15 + (int)param_3_00))))) {
LAB_001c9100:
      do {
        *puVar18 = *puVar19;
        puVar18 = puVar18 + 1;
        puVar19 = puVar19 + 1;
      } while (puVar18 < puVar16);
    }
    else {
      uVar15 = uVar14 & 0xfffffffc;
      uVar22 = 0;
      do {
        puVar3 = puVar19 + uVar22;
        uVar5 = *(undefined4 *)((int)puVar3 + 4);
        uVar6 = *(undefined4 *)(puVar3 + 1);
        uVar7 = *(undefined4 *)((int)puVar3 + 0xc);
        puVar18 = puVar19 + uVar22 + 2;
        uVar8 = *(undefined4 *)puVar18;
        uVar9 = *(undefined4 *)((int)puVar18 + 4);
        uVar10 = *(undefined4 *)(puVar18 + 1);
        uVar11 = *(undefined4 *)((int)puVar18 + 0xc);
        puVar18 = param_3_00 + uVar22;
        *(undefined4 *)puVar18 = *(undefined4 *)puVar3;
        *(undefined4 *)((int)puVar18 + 4) = uVar5;
        *(undefined4 *)(puVar18 + 1) = uVar6;
        *(undefined4 *)((int)puVar18 + 0xc) = uVar7;
        puVar18 = param_3_00 + uVar22 + 2;
        *(undefined4 *)puVar18 = uVar8;
        *(undefined4 *)((int)puVar18 + 4) = uVar9;
        *(undefined4 *)(puVar18 + 1) = uVar10;
        *(undefined4 *)((int)puVar18 + 0xc) = uVar11;
        uVar22 = uVar22 + 4;
      } while (uVar15 != uVar22);
      puVar18 = param_3_00 + uVar15;
      puVar19 = puVar19 + uVar15;
      if (uVar14 != uVar15) goto LAB_001c9100;
    }
    puVar19 = (undefined8 *)(((int)puVar16 - (int)param_3_00) + *param_4);
    *param_4 = (int)puVar19;
    if (puVar20 <= puVar16) goto LAB_001c9161;
  }
  *param_4 = (int)puVar19 + 1;
  *(undefined *)puVar16 = *(undefined *)puVar19;
  while (puVar16 = (undefined8 *)((int)puVar16 + 1), puVar16 < puVar20) {
    puVar4 = (undefined *)*param_4;
    *param_4 = (int)(puVar4 + 1);
    *(undefined *)puVar16 = *puVar4;
  }
LAB_001c9161:
  puVar19 = (undefined8 *)((int)puVar20 - param_3);
  if ((uint)((int)puVar20 - (int)param_6) < param_3) {
    if ((uint)((int)puVar20 - param_7) < param_3) {
      return -0x14;
    }
    iVar21 = (int)puVar19 - (int)param_6;
    iVar17 = param_8 + iVar21;
    if ((uint)(iVar17 + param_2) <= param_8) {
      FUN_0018ae40(puVar20,iVar17,param_2,0x1c905c);
      return iVar12;
    }
    FUN_0018ae40(puVar20,iVar17,-iVar21,0x1c905c);
    puVar16 = (undefined8 *)((int)puVar20 - iVar21);
    puVar19 = param_6;
  }
  if (puVar16 < puVar13) {
    uVar14 = ((param_2 + param_1) - (int)puVar16) + (int)param_3_00;
    if ((0x1f < uVar14) &&
       (((undefined8 *)((int)puVar19 + uVar14) <= puVar16 || (puVar13 <= puVar19)))) {
      uVar22 = uVar14 & 0xffffffe0;
      uVar15 = 0;
      do {
        puVar1 = (undefined4 *)((int)puVar19 + uVar15);
        uVar5 = puVar1[1];
        uVar6 = puVar1[2];
        uVar7 = puVar1[3];
        puVar2 = (undefined4 *)((int)puVar19 + uVar15 + 0x10);
        uVar8 = *puVar2;
        uVar9 = puVar2[1];
        uVar10 = puVar2[2];
        uVar11 = puVar2[3];
        puVar2 = (undefined4 *)((int)puVar16 + uVar15);
        *puVar2 = *puVar1;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar1 = (undefined4 *)((int)puVar16 + uVar15 + 0x10);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        uVar15 = uVar15 + 0x20;
      } while (uVar22 != uVar15);
      puVar19 = (undefined8 *)((int)puVar19 + uVar22);
      puVar16 = (undefined8 *)((int)puVar16 + uVar22);
      if (uVar22 == uVar14) {
        return iVar12;
      }
    }
    iVar17 = 0;
    do {
      *(undefined *)((int)puVar16 + iVar17) = *(undefined *)((int)puVar19 + iVar17);
      iVar17 = iVar17 + 1;
    } while ((int)param_3_00 + ((param_2 + param_1) - (int)puVar16) != iVar17);
  }
  return iVar12;
}

