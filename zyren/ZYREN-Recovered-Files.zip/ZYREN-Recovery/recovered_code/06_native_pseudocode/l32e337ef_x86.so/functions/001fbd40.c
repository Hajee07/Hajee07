/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fbd40 FUN_001fbd40 */

bool FUN_001fbd40(int param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  
  if (*(undefined **)(param_2 + 4) == PTR_DAT_0024bdcc) {
    if (*(int *)(param_1 + 0xc) == 0) {
      puVar2 = &DAT_0021fb78;
    }
    else {
      iVar1 = FUN_001fbe70(*(int *)(param_1 + 0xc),PTR_PTR_0024bdc4,PTR_PTR_0024bdd8,0);
      puVar2 = &DAT_0021fb70;
      if (iVar1 == 0) {
        puVar2 = &DAT_0021fb78;
      }
    }
    *param_3 = puVar2;
    return true;
  }
  if ((*(byte *)(param_1 + 8) & 0x18) == 0) {
    iVar1 = FUN_001fbe70(param_2,PTR_PTR_0024bdc4,PTR_PTR_0024bdc8,0);
    if (iVar1 == 0) goto LAB_001fbdfe;
    if ((*(byte *)(iVar1 + 8) & 0x18) == 0) {
      if (*(int *)(param_1 + 4) == *(int *)(param_2 + 4)) {
        return true;
      }
      goto LAB_001fbdfe;
    }
  }
  if (param_1 == param_2) {
    return true;
  }
  iVar1 = FUN_0018b060(*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_2 + 4));
  if (iVar1 == 0) {
    return true;
  }
LAB_001fbdfe:
  iVar1 = FUN_001fbe70(param_2,PTR_PTR_0024bdc4,PTR_PTR_0024bddc,0);
  if (iVar1 != 0) {
    if ((((~*(uint *)(param_1 + 8) & *(uint *)(iVar1 + 8) & 7) == 0) &&
        ((~*(uint *)(iVar1 + 8) & *(uint *)(param_1 + 8) & 0x60) == 0)) &&
       (*(int *)(*(int *)(param_1 + 0xc) + 4) == *(int *)(*(int *)(iVar1 + 0xc) + 4))) {
      return *(int *)(*(int *)(param_1 + 0x10) + 4) == *(int *)(*(int *)(iVar1 + 0x10) + 4);
    }
  }
  return false;
}

