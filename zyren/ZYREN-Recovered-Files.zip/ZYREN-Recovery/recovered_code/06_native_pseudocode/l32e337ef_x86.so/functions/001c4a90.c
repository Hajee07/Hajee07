/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001c4a90 FUN_001c4a90 */

void FUN_001c4a90(undefined4 param_1,undefined4 param_2)

{
  FUN_0018ae80(param_1,param_2,0x5cf4,0x1c4a99);
  return;
}

