/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00110c50 FUN_00110c50 */

void FUN_00110c50(int param_1)

{
  *(int *)param_1 = param_1;
  *(int *)(param_1 + 4) = param_1;
  FUN_00047080(param_1);
  DAT_0027da14 = PTR_sigprocmask_002811fc;
  DAT_0027da20 = PTR_sigaction_002811f8;
  DAT_0027da2c = FUN_00110960;
  return;
}

