/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b8490 FUN_001b8490 */

longdouble FUN_001b8490(undefined4 param_1)

{
  undefined8 local_10;
  
  thunk_FUN_00154500((int)&local_10 + 4,param_1);
  return (longdouble)local_10;
}

