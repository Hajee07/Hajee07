/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020efc0 FUN_0020efc0 */

void FUN_0020efc0(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(&DAT_0024b938 + *(int *)(param_2 + 8) * 4);
  *param_1 = (&PTR_s_allocator_0024b920)[*(int *)(param_2 + 8)];
  param_1[1] = uVar1;
  return;
}

