/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001fbba0 FUN_001fbba0 */

undefined4 FUN_001fbba0(int param_1,int param_2)

{
  undefined *puVar1;
  undefined *puVar2;
  undefined *puVar3;
  int iVar4;
  int iVar5;
  int local_20;
  
  puVar2 = PTR_PTR_0024bdd0;
  puVar1 = PTR_PTR_0024bdc4;
  if (param_2 != 0) {
    local_20 = param_1;
    do {
      iVar4 = FUN_001fbe70(param_2,puVar1,puVar2,0);
      if (iVar4 == 0) {
        return 0;
      }
      if ((*(uint *)(iVar4 + 8) & ~*(uint *)(local_20 + 8)) != 0) {
        return 0;
      }
      iVar5 = *(int *)(local_20 + 0xc);
      if (*(int *)(iVar5 + 4) == *(int *)(*(int *)(iVar4 + 0xc) + 4)) {
        return CONCAT31((int3)((uint)*(int *)(iVar4 + 0xc) >> 8),1);
      }
      if ((*(uint *)(local_20 + 8) & 1) == 0) {
        return 0;
      }
      if (iVar5 == 0) {
        return 0;
      }
      iVar5 = FUN_001fbe70(iVar5,puVar1,puVar2,0);
      puVar3 = PTR_PTR_0024bddc;
      if (iVar5 == 0) {
        if (*(int *)(local_20 + 0xc) == 0) {
          return 0;
        }
        iVar5 = FUN_001fbe70(*(int *)(local_20 + 0xc),puVar1,PTR_PTR_0024bddc,0);
        if (iVar5 == 0) {
          return 0;
        }
        if (*(int *)(iVar4 + 0xc) == 0) {
          return 0;
        }
        iVar4 = FUN_001fbe70(*(int *)(iVar4 + 0xc),puVar1,puVar3,0);
        if (iVar4 == 0) {
          return 0;
        }
        if ((*(uint *)(iVar4 + 8) & ~*(uint *)(iVar5 + 8)) != 0) {
          return 0;
        }
        if (*(int *)(*(int *)(iVar5 + 0xc) + 4) != *(int *)(*(int *)(iVar4 + 0xc) + 4)) {
          return 0;
        }
        return CONCAT31((int3)((uint)*(int *)(iVar4 + 0x10) >> 8),
                        *(int *)(*(int *)(iVar5 + 0x10) + 4) == *(int *)(*(int *)(iVar4 + 0x10) + 4)
                       );
      }
      param_2 = *(int *)(iVar4 + 0xc);
      local_20 = iVar5;
    } while (param_2 != 0);
  }
  return 0;
}

