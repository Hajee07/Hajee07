/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 001b5a50 FUN_001b5a50 */

int FUN_001b5a50(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + -4) + 8;
  if (*(int *)(param_1 + -4) == 0) {
    iVar1 = 0;
  }
  return iVar1;
}

