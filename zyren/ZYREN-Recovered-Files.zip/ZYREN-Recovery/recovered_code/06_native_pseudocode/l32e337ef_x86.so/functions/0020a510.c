/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0020a510 FUN_0020a510 */

void FUN_0020a510(int param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  
  iVar8 = param_2[1];
  iVar2 = param_2[3];
  param_2[3] = -1;
  iVar3 = param_2[4];
  param_2[4] = -1;
  piVar4 = *(int **)(param_1 + 8);
                    /* try { // try from 0020a559 to 0020a575 has its CatchHandler @ 0020a69f */
  (**(code **)(*piVar4 + 0x10))(piVar4,param_2);
  if (*(char *)((int)piVar4 + 5) != '\x01') {
    (**(code **)(*piVar4 + 0x14))(piVar4,param_2);
  }
  uVar5 = param_2[4];
  if (uVar5 == 0xffffffff) {
    iVar8 = param_2[1];
    uVar5 = iVar8 + 3;
    if (uVar5 < (uint)param_2[2]) {
      iVar7 = *param_2;
    }
    else {
      uVar9 = param_2[2] * 2;
      if (uVar9 < uVar5) {
        uVar9 = uVar5;
      }
      param_2[2] = uVar9;
      iVar7 = FUN_0018b200(*param_2,uVar9);
      *param_2 = iVar7;
      if (iVar7 == 0) {
LAB_0020a69a:
                    /* WARNING: Subroutine does not return */
        FUN_001f9d40();
      }
      iVar8 = param_2[1];
    }
    *(undefined *)(iVar7 + 2 + iVar8) = 0x2e;
    *(undefined2 *)(iVar7 + iVar8) = 0x2e2e;
    param_2[1] = param_2[1] + 3;
  }
  else if (uVar5 == 0) {
    param_2[1] = iVar8;
  }
  else if (1 < uVar5) {
    uVar9 = 1;
    do {
      iVar8 = param_2[1];
      uVar1 = iVar8 + 2;
      if (uVar1 < (uint)param_2[2]) {
        iVar7 = *param_2;
      }
      else {
        uVar6 = param_2[2] * 2;
        if (uVar6 < uVar1) {
          uVar6 = uVar1;
        }
        param_2[2] = uVar6;
        iVar7 = FUN_0018b200(*param_2,uVar6);
        *param_2 = iVar7;
        if (iVar7 == 0) goto LAB_0020a69a;
        iVar8 = param_2[1];
      }
      *(undefined2 *)(iVar7 + iVar8) = 0x202c;
      param_2[1] = param_2[1] + 2;
      param_2[3] = uVar9;
      piVar4 = *(int **)(param_1 + 8);
                    /* try { // try from 0020a62f to 0020a64e has its CatchHandler @ 0020a6a1 */
      (**(code **)(*piVar4 + 0x10))(piVar4,param_2);
      if (*(char *)((int)piVar4 + 5) != '\x01') {
        (**(code **)(*piVar4 + 0x14))(piVar4,param_2);
      }
      uVar9 = uVar9 + 1;
    } while (uVar5 != uVar9);
  }
  param_2[4] = iVar3;
  param_2[3] = iVar2;
  return;
}

