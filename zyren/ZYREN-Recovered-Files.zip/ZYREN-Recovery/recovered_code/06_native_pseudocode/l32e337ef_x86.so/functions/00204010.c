/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00204010 FUN_00204010 */

undefined FUN_00204010(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined uVar2;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(undefined *)(param_1 + 0x10) = 1;
    puVar1 = *(undefined4 **)(param_1 + 0xc);
    if (*(char *)((int)puVar1 + 5) == '\x02') {
                    /* try { // try from 0020404a to 00204052 has its CatchHandler @ 00204069 */
      uVar2 = (**(code **)*puVar1)(puVar1,param_2);
    }
    else {
      uVar2 = *(char *)((int)puVar1 + 5) == '\0';
    }
    *(undefined *)(param_1 + 0x10) = 0;
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

