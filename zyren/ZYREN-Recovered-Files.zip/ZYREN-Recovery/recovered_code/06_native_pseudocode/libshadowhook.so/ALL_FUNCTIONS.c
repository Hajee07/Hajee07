/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00012800 FUN_00012800 */

void FUN_00012800(undefined4 param_1,undefined4 param_2)

{
  int unaff_r4;
  code *UNRECOVERED_JUMPTABLE;
  
  if (unaff_r4 != DAT_00012814) {
    UNRECOVERED_JUMPTABLE = (code *)((int)&DAT_00012838 + DAT_00012838);
  }
                    /* WARNING: Could not recover jumptable at 0x0001285c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(param_1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00012b00 shadowhook_allow_reentrant */

void shadowhook_allow_reentrant(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00012b28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00012b2c + 0x12b24))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00012d00 shadowhook_disallow_reentrant */

void shadowhook_disallow_reentrant(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00012d28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00012d2c + 0x12d24))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00012d40 shadowhook_init */

void shadowhook_init(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00012d68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00012d6c + 0x12d64))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00012e80 shadowhook_register_dl_fini_callback */

void shadowhook_register_dl_fini_callback(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00012ea8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00012eac + 0x12ea4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013540 shadowhook_get_records */

void shadowhook_get_records(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00013568. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0001356c + 0x13564))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013600 shadowhook_get_recordable */

void shadowhook_get_recordable(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00013628. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0001362c + 0x13624))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00014140 entry */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void processEntry entry(undefined4 param_1)

{
  undefined4 in_r1;
  undefined4 in_r2;
  undefined4 in_r3;
  
                    /* WARNING: Could not recover jumptable at 0x000155a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_00015568 + DAT_00015568))(param_1,in_r1,in_r2,in_r3,param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00014550 _FINI_1 */

void _FINI_1(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            code *param_5,undefined4 param_6,undefined4 param_7)

{
  code *param_9;
  
  param_9 = param_5;
                    /* WARNING: Could not recover jumptable at 0x0001458c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*param_5)(param_6,param_7,param_3);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00014564 _FINI_0 */

void _FINI_0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,code *UNRECOVERED_JUMPTABLE)

{
                    /* WARNING: Could not recover jumptable at 0x0001458c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(param_5,param_6,param_3);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00014c00 shadowhook_get_prev_func */

void shadowhook_get_prev_func(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00014c28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00014c2c + 0x14c24))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00016200 _DT_INIT */

void _DT_INIT(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
                    /* WARNING: Could not recover jumptable at 0x00044388. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_00044330 + DAT_00044330))
            (param_1,param_2,param_3,param_4,param_1,param_2,param_3,param_4);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00016240 shadowhook_dlsym_symtab */

void shadowhook_dlsym_symtab(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00016268. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0001626c + 0x16264))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00016660 _INIT_0 */

void _INIT_0(undefined4 param_1)

{
  undefined4 in_stack_00000000;
  code *UNRECOVERED_JUMPTABLE;
  
  UNRECOVERED_JUMPTABLE = (code *)(DAT_0001626c + 0x16264);
                    /* WARNING: Could not recover jumptable at 0x00016268. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(in_stack_00000000,param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00016f58 _INIT_1 */

void _INIT_1(int param_1)

{
  code *pcVar1;
  int unaff_r6;
  
  *(byte *)(unaff_r6 + 0xd) = (byte)((uint)unaff_r6 >> 0x1c);
  *(short *)(param_1 + 0xc) = (short)param_1;
                    /* WARNING: Does not return */
  pcVar1 = (code *)software_udf(0xb6,93000);
  (*pcVar1)();
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00018930 _INIT_2 */

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _INIT_2(int param_1,int param_2,uint param_3,undefined4 param_4)

{
  ushort uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint unaff_r5;
  int unaff_r6;
  undefined4 *puVar5;
  uint *unaff_r7;
  undefined4 unaff_r9;
  char in_CY;
  char in_OV;
  undefined4 in_cr8;
  
  if (in_OV == '\0') {
    if ((bool)in_CY) {
      puVar5 = (undefined4 *)(param_3 - 2);
      *puVar5 = 0;
      *(int *)(param_3 + 2) = param_2;
      *(undefined4 *)(param_3 + 6) = param_4;
      *(undefined4 **)(param_3 + 10) = puVar5;
      *(uint **)(param_3 + 0xe) = unaff_r7;
      if (unaff_r5 < 0xf2) {
        DAT_00018c00 = (short)unaff_r5;
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined4 *)(param_2 + 0x74) = 0xc5;
      unaff_r7[0x17] = (uint)unaff_r7;
      _DAT_000000c5 = 0;
      software_bkpt(0x5c);
      if (((uint)unaff_r7 & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uRam00000010 = (undefined)param_4;
      uVar1 = *(ushort *)(param_3 + (int)puVar5);
      uRam00000017 = 0;
      uVar4 = (int)unaff_r7 >> 0x13;
      *(uint *)((int)unaff_r7 * 0x8000000 + 0x6c) = uVar4;
      *(uint **)(uVar4 + 8) = unaff_r7;
      uVar2 = (uint)*(byte *)(((int)unaff_r7 >> 7) + param_3);
      *(uint *)(unaff_r5 + 0x40) = param_3;
      *(char *)(uVar4 + 8) = (char)unaff_r7;
      *unaff_r7 = uVar2;
      unaff_r7[1] = (int)unaff_r7 * 0x8000000;
      unaff_r7[2] = param_3;
      unaff_r7[3] = uVar4;
      unaff_r7[4] = (uint)&stack0x00000190;
      unaff_r7[5] = (uint)uVar1;
      unaff_r7[6] = (uint)unaff_r7;
      iVar3 = (int)(uVar4 - unaff_r5) >> 0xd;
      *(short *)(uVar2 + 8) = (short)iVar3;
      *(undefined4 *)(*(int *)(iVar3 + 0x38) + 0xe9) = *(undefined4 *)(uVar1 + 8);
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  else {
    if (param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    in_CY = ((uint)unaff_r7 & 1) != 0;
    *(int *)(param_1 + 0x1c) = param_2;
  }
  *(char *)(param_1 + unaff_r6) = (char)unaff_r6;
  *(uint **)(param_1 + 0x7c) = unaff_r7;
  if (in_CY == '\0') {
    coprocessor_moveto2(0xb,0xd,*(undefined4 *)(param_3 + 0xc),unaff_r9,in_cr8);
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021200 shadowhook_register_dl_init_callback */

void shadowhook_register_dl_init_callback(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00021228. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002122c + 0x21224))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00021940 shadowhook_hook_sym_name_callback */

void shadowhook_hook_sym_name_callback(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00021968. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002196c + 0x21964))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00022680 thunk_FUN_00028dc4 */

void thunk_FUN_00028dc4(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
                    /* WARNING: Could not recover jumptable at 0x00028e58. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_00028e08 + DAT_00028e08))(param_1,param_2,param_3);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00022b80 shadowhook_hook_sym_addr */

void shadowhook_hook_sym_addr(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00022ba8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00022bac + 0x22ba4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00022d40 shadowhook_dlclose */

void shadowhook_dlclose(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00022d68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00022d6c + 0x22d64))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00025580 shadowhook_get_debuggable */

void shadowhook_get_debuggable(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x000255a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_000255ac + 0x255a4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00025680 shadowhook_pop_stack */

void shadowhook_pop_stack(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x000256a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_000256ac + 0x256a4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000256c0 shadowhook_dlsym_dynsym */

void shadowhook_dlsym_dynsym(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x000256e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_000256ec + 0x256e4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00026dc0 shadowhook_get_errno */

void shadowhook_get_errno(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00026de8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00026dec + 0x26de4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00027f40 shadowhook_unregister_dl_fini_callback */

void shadowhook_unregister_dl_fini_callback(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00027f68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00027f6c + 0x27f64))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028040 shadowhook_set_recordable */

void shadowhook_set_recordable(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00028068. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002806c + 0x28064))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00028dc4 FUN_00028dc4 */

void FUN_00028dc4(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
                    /* WARNING: Could not recover jumptable at 0x00028e58. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&DAT_00028e08 + DAT_00028e08))(param_1,param_2,param_3);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002a740 shadowhook_get_return_address */

void shadowhook_get_return_address(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002a768. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002a76c + 0x2a764))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002a780 shadowhook_dlsym */

void shadowhook_dlsym(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002a7a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002a7ac + 0x2a7a4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002aa00 shadowhook_unhook */

void shadowhook_unhook(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002aa28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002aa2c + 0x2aa24))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002b500 shadowhook_unregister_dl_init_callback */

void shadowhook_unregister_dl_init_callback(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002b528. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002b52c + 0x2b524))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002b640 shadowhook_dlopen */

void shadowhook_dlopen(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002b668. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002b66c + 0x2b664))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002d5c0 shadowhook_hook_sym_name */

void shadowhook_hook_sym_name(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002d5e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002d5ec + 0x2d5e4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002dd00 shadowhook_to_errmsg */

void shadowhook_to_errmsg(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x0002dd28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0002dd2c + 0x2dd24))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e1c0 sysconf */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
  long lVar1;
  
  lVar1 = (*DAT_00056c08)();
  return lVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e1cc memcpy */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*DAT_00056c0c)();
  return pvVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e1d8 memset */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*DAT_00056c10)();
  return pvVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e1e4 memmove */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*DAT_00056c14)();
  return pvVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e1f0 __aeabi_memclr4 */

void __aeabi_memclr4(void)

{
  (*DAT_00056c18)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e1fc raise */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int raise(int __sig)

{
  int iVar1;
  
  iVar1 = (*DAT_00056c1c)();
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e208 mmap */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * mmap(void *__addr,size_t __len,int __prot,int __flags,int __fd,__off_t __offset)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*DAT_00056c20)();
  return pvVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e214 abort */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
  (*DAT_00056c24)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e220 sbrk */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * sbrk(intptr_t __delta)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*DAT_00056c28)();
  return pvVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e22c __errno */

void __errno(void)

{
  (*DAT_00056c2c)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e238 munmap */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int munmap(void *__addr,size_t __len)

{
  int iVar1;
  
  iVar1 = (*DAT_00056c30)();
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e244 bsd_signal */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__sighandler_t bsd_signal(int __sig,__sighandler_t __handler)

{
  __sighandler_t p_Var1;
  
  p_Var1 = (__sighandler_t)(*DAT_00056c34)();
  return p_Var1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e250 dl_iterate_phdr */

void dl_iterate_phdr(void)

{
  (*DAT_00056c38)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e25c __android_log_print */

void __android_log_print(void)

{
  (*DAT_00056c3c)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e268 strlen */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
  size_t sVar1;
  
  sVar1 = (*DAT_00056c40)();
  return sVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e274 strcpy */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strcpy(char *__dest,char *__src)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*DAT_00056c44)();
  return pcVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e280 open */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int open(char *__file,int __oflag,...)

{
  int iVar1;
  
  iVar1 = (*DAT_00056c48)();
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e28c read */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ssize_t read(int __fd,void *__buf,size_t __nbytes)

{
  ssize_t sVar1;
  
  sVar1 = (*DAT_00056c4c)();
  return sVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e298 strcmp */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = (*DAT_00056c50)();
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2a4 strncmp */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strncmp(char *__s1,char *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = (*DAT_00056c54)();
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2b0 strstr */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*DAT_00056c58)();
  return pcVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2bc close */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int close(int __fd)

{
  int iVar1;
  
  iVar1 = (*DAT_00056c5c)();
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2c8 strrchr */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strrchr(char *__s,int __c)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*DAT_00056c60)();
  return pcVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2d4 dlsym */

void dlsym(void)

{
  (*DAT_00056c6c)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2e0 dlvsym */

void dlvsym(void)

{
  (*DAT_00056c70)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2ec dladdr */

void dladdr(void)

{
  (*DAT_00056c74)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e2f8 getprogname */

void getprogname(void)

{
  (*DAT_00056c7c)();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e494 FUN_0002e494 */

undefined4 FUN_0002e494(int *param_1)

{
  int iVar1;
  
  iVar1 = DAT_0002e52c;
  param_1[0x170b] = 0;
  param_1[0x170c] = 0;
  param_1[0x170d] = 0;
  param_1[0x170e] = 0;
  param_1[0x170f] = 5;
  param_1[0x1733] = 0;
  param_1[0x1719] = 0;
  param_1[0x171a] = 0;
  param_1[0x171b] = 0;
  param_1[0x507] = 0xc00000c;
  memcpy(param_1 + 0x1708,(void *)(iVar1 + 0x2e4c4),0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e530 FUN_0002e530 */

int * FUN_0002e530(int param_1,int param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar3 = (int *)0x0;
  if (((param_1 == 0) == (param_2 == 0)) &&
     (piVar2 = (int *)FUN_0003a4a8(&LAB_00025d50,param_1,param_2,param_3), iVar1 = DAT_0002e654,
     piVar2 != (int *)0x0)) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = param_1;
    piVar2[0x1736] = param_2;
    piVar2[0x1737] = param_3;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    memcpy(piVar2 + 0x1708,(void *)(iVar1 + 0x2e5b8),0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    piVar3 = piVar2;
  }
  return piVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e658 FUN_0002e658 */

int * FUN_0002e658(int *param_1,undefined *param_2)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = DAT_0002e738;
  piVar2 = (int *)0x0;
  if ((&UNK_00025d4f < param_2) && (((uint)param_1 & 7) == 0)) {
    param_1[0x170b] = 0;
    param_1[0x170c] = 0;
    param_1[0x170d] = 0;
    param_1[0x170e] = 0;
    param_1[0x170f] = 5;
    param_1[0x507] = 0xc00000c;
    param_1[0x1733] = 0;
    param_1[0x1719] = 0;
    param_1[0x171a] = 0;
    param_1[0x171b] = 0;
    memcpy(param_1 + 0x1708,(void *)(iVar1 + 0x2e6b4),0xc);
    *param_1 = (int)(param_1 + 4);
    param_1[1] = (int)(param_1 + 0x306);
    param_1[2] = (int)(param_1 + 0x205);
    param_1[3] = (int)(param_1 + 0x507);
    param_1[0x1741] = 0x8000001;
    param_1[0x1743] = 0;
    param_1[0x173a] = (int)param_2;
    param_1[0x173b] = 0;
    param_1[0x173c] = 0;
    param_1[0x173d] = 0;
    param_1[0x173e] = (int)(param_1 + 0x9754);
    param_1[0x173f] = 0;
    piVar2 = param_1;
  }
  return piVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e73c FUN_0002e73c */

int * FUN_0002e73c(void)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)FUN_0003a4a8(&LAB_00025d50,0,0,0);
  iVar1 = DAT_0002e834;
  piVar3 = (int *)0x0;
  if (piVar2 != (int *)0x0) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = 0;
    piVar2[0x1736] = 0;
    piVar2[0x1737] = 0;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    memcpy(piVar2 + 0x1708,(void *)(iVar1 + 0x2e79c),0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    piVar3 = piVar2;
  }
  return piVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002e838 FUN_0002e838 */

undefined4 FUN_0002e838(int param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  if (param_1 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = 0xffffffc0;
    if (*(int *)(param_1 + 0x5ce8) == 0) {
      puVar2 = *(undefined4 **)(param_1 + 0x5cec);
      uVar3 = *(undefined4 *)(param_1 + 0x5cd4);
      uVar4 = *(undefined4 *)(param_1 + 0x5cd8);
      uVar7 = *(undefined4 *)(param_1 + 0x5cdc);
      if (puVar2 != (undefined4 *)0x0) {
        uVar5 = puVar2[0x170d];
        uVar6 = puVar2[0x170e];
        uVar1 = puVar2[0x170c];
        FUN_0003a514(*puVar2,uVar1,uVar5,uVar6);
        FUN_0003a514(puVar2,uVar1,uVar5,uVar6);
      }
      uVar1 = 0;
      *(undefined4 *)(param_1 + 0x5cec) = 0;
      FUN_0003a514(*(undefined4 *)(param_1 + 0x5cf8),uVar3,uVar4,uVar7);
      *(undefined4 *)(param_1 + 0x5cf8) = 0;
      FUN_0003a514(param_1,uVar3,uVar4,uVar7);
    }
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002ea08 FUN_0002ea08 */

uint FUN_0002ea08(uint *param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  longlong lVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  
  uVar11 = 5;
  if (4 < param_3) {
    if (*param_2 == 0xfd2fb528) {
      bVar1 = *(byte *)(param_2 + 1);
      iVar9 = 6;
      if ((bVar1 & 0x20) != 0) {
        iVar9 = 5;
      }
      uVar11 = *(int *)(DAT_0002ec4c + 0x2ea5c + (uint)(bVar1 >> 6) * 4) +
               *(int *)(DAT_0002ec48 + 0x2ea54 + (bVar1 & 3) * 4) + iVar9 +
               ((uint)(bVar1 >> 6 == 0) & (bVar1 & 0x20) >> 5);
      if (uVar11 <= param_3) {
        param_1[5] = uVar11;
        uVar11 = 0xfffffff2;
        bVar1 = *(byte *)(param_2 + 1);
        if ((bVar1 & 8) == 0) {
          uVar11 = 0;
          if ((bVar1 & 0x20) == 0) {
            uVar8 = (uint)(*(byte *)((int)param_2 + 5) >> 3);
            uVar5 = uVar8 + 10;
            if (0x1b < uVar5) {
              return 0xfffffff0;
            }
            uVar4 = *(byte *)((int)param_2 + 5) & 7;
            uVar7 = 1 >> (0x20 - uVar5 & 0xff);
            uVar8 = uVar8 - 0x16;
            uVar5 = 1 << uVar5;
            if (-1 < (int)uVar8) {
              uVar5 = 0;
              uVar7 = 1 << (uVar8 & 0xff);
            }
            lVar2 = (ulonglong)uVar4 * (ulonglong)(uVar5 >> 3 | uVar7 << 0x1d);
            uVar8 = (uint)lVar2;
            uVar10 = uVar8 + uVar5;
            uVar8 = (uVar7 >> 3) * uVar4 + (int)((ulonglong)lVar2 >> 0x20) + uVar7 +
                    (uint)CARRY4(uVar8,uVar5);
            iVar9 = 6;
          }
          else {
            iVar9 = 5;
            uVar10 = 0;
            uVar8 = 0;
          }
          uVar5 = bVar1 & 3;
          bVar3 = bVar1 >> 6;
          if (uVar5 == 3) {
            uVar11 = *(uint *)((int)param_2 + iVar9);
            iVar9 = iVar9 + 4;
          }
          else if (uVar5 == 2) {
            puVar6 = (ushort *)((int)param_2 + iVar9);
            iVar9 = iVar9 + 2;
            uVar11 = (uint)*puVar6;
          }
          else if (uVar5 == 1) {
            uVar11 = (uint)*(byte *)((int)param_2 + iVar9);
            iVar9 = iVar9 + 1;
          }
          if (bVar3 == 1) {
            uVar7 = *(ushort *)((int)param_2 + iVar9) + 0x100;
            uVar5 = 0;
          }
          else if (bVar3 == 2) {
            uVar7 = *(uint *)((int)param_2 + iVar9);
            uVar5 = 0;
          }
          else if (bVar3 == 3) {
            uVar7 = *(uint *)((int)param_2 + iVar9);
            uVar5 = ((uint *)((int)param_2 + iVar9))[1];
          }
          else {
            uVar7 = 0xffffffff;
            uVar5 = 0xffffffff;
            if ((bVar1 & 0x20) != 0) {
              uVar7 = (uint)*(byte *)((int)param_2 + iVar9);
              uVar5 = 0;
            }
          }
          if ((bVar1 & 0x20) != 0) {
            uVar10 = uVar7;
          }
          if ((bVar1 & 0x20) != 0) {
            uVar8 = uVar5;
          }
          param_1[6] = uVar11;
          param_1[7] = ((uint)bVar1 << 0x1d) >> 0x1f;
          *param_1 = uVar7;
          param_1[1] = uVar5;
          param_1[2] = uVar10;
          param_1[3] = uVar8;
          param_1[4] = 0;
          return 0;
        }
      }
    }
    else {
      uVar11 = 0xfffffff6;
      if ((*param_2 >> 4 == 0x184d2a5) && (uVar11 = 8, 7 < param_3)) {
        memset(param_1,0,0x20);
        *param_1 = param_2[1];
        param_1[1] = 0;
        param_1[2] = 0;
        param_1[3] = 0;
        param_1[4] = 1;
        return 0;
      }
    }
  }
  return uVar11;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002ec50 FUN_0002ec50 */

undefined8 FUN_0002ec50(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 local_28;
  undefined4 uStack_24;
  int local_18;
  
  iVar1 = FUN_0002ea08(&local_28,param_1,param_2);
  if (iVar1 != 0) {
    return 0xfffffffffffffffe;
  }
  uVar2 = 0;
  uVar3 = 0;
  if (local_18 != 1) {
    uVar2 = local_28;
    uVar3 = uStack_24;
  }
  return CONCAT44(uVar3,uVar2);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002eca0 FUN_0002eca0 */

undefined8 FUN_0002eca0(uint *param_1,uint param_2)

{
  bool bVar1;
  ushort uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  uint local_48;
  uint uStack_44;
  int local_38;
  int local_34;
  int local_2c;
  
  uVar8 = 0;
  if (param_2 < 5) {
    uVar7 = 0;
  }
  else {
    uVar8 = 0;
    uVar7 = 0;
    do {
      if ((*param_1 & 0xfffffff0) == 0x184d2a50) {
        if (param_2 < 8) {
          return 0xffffffb8;
        }
        uVar3 = param_1[1] + 8;
        if (param_2 < uVar3) {
          return 0xfffffffffffffffe;
        }
      }
      else {
        iVar4 = FUN_0002ea08(&local_48,param_1,param_2);
        if (iVar4 != 0) {
          return 0xfffffffffffffffe;
        }
        if (local_38 == 1) {
          uVar3 = 0;
          uVar5 = 0;
        }
        else {
          uVar3 = local_48;
          uVar5 = uStack_44;
          if (0xfffffffe < uStack_44 && (uint)(local_48 < 0xfffffffe) <= -uStack_44 - 1)
          goto LAB_0002ee80;
        }
        bVar9 = CARRY4(uVar3,uVar8);
        uVar8 = uVar3 + uVar8;
        uVar3 = uVar5 + uVar7;
        bVar1 = CARRY4(uVar5,uVar7);
        uVar7 = uVar5 + uVar7 + (uint)bVar9;
        if (bVar1 || CARRY4(uVar3,(uint)bVar9)) {
          return 0xfffffffffffffffe;
        }
        if ((param_2 < 8) || ((*param_1 & 0xfffffff0) != 0x184d2a50)) {
          uVar3 = FUN_0002ea08(&local_48,param_1,param_2);
          if (uVar3 < 0xffffff89) {
            if (uVar3 != 0) {
              return 0xfffffffffffffffe;
            }
            uVar5 = param_2 - local_34;
            puVar6 = (ushort *)((int)param_1 + local_34);
            do {
              if (uVar5 < 3) {
                return 0xfffffffffffffffe;
              }
              uVar2 = *puVar6;
              uVar3 = ((uint)uVar2 << 0x1d) >> 0x1e;
              if (uVar3 != 1) {
                if (uVar3 == 3) {
                  return 0xfffffffffffffffe;
                }
                uVar3 = (uint)(uint3)(CONCAT12(*(undefined *)(puVar6 + 1),uVar2) >> 3);
              }
              uVar3 = uVar3 + 3;
              if (uVar5 < uVar3) {
                return 0xfffffffffffffffe;
              }
              uVar5 = uVar5 - uVar3;
              puVar6 = (ushort *)((int)puVar6 + uVar3);
            } while ((uVar2 & 1) == 0);
            if (local_2c != 0) {
              uVar3 = 0xffffffb8;
              if (uVar5 < 4) goto joined_r0x0002ee44;
              puVar6 = puVar6 + 2;
            }
            uVar3 = (int)puVar6 - (int)param_1;
          }
        }
        else {
          uVar3 = param_1[1] + 8;
        }
joined_r0x0002ee44:
        if (0xffffff88 < uVar3) {
          return 0xfffffffffffffffe;
        }
      }
      param_2 = param_2 - uVar3;
      param_1 = (uint *)((int)param_1 + uVar3);
    } while (4 < param_2);
  }
  local_48 = 0xfffffffe;
  uStack_44 = 0xffffffff;
  if (param_2 == 0) {
    local_48 = uVar8;
    uStack_44 = uVar7;
  }
LAB_0002ee80:
  return CONCAT44(uStack_44,local_48);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002ee98 FUN_0002ee98 */

uint FUN_0002ee98(uint *param_1,uint param_2)

{
  ushort uVar1;
  uint uVar2;
  ushort *puVar3;
  undefined auStack_30 [20];
  int local_1c;
  int local_14;
  
  if ((7 < param_2) && (*param_1 >> 4 == 0x184d2a5)) {
    return param_1[1] + 8;
  }
  uVar2 = FUN_0002ea08(auStack_30,param_1,param_2);
  if (uVar2 < 0xffffff89) {
    if (uVar2 != 0) {
      return 0xffffffb8;
    }
    param_2 = param_2 - local_1c;
    puVar3 = (ushort *)((int)param_1 + local_1c);
    do {
      if (param_2 < 3) {
        return 0xffffffb8;
      }
      uVar1 = *puVar3;
      uVar2 = ((uint)uVar1 << 0x1d) >> 0x1e;
      if (uVar2 != 1) {
        if (uVar2 == 3) {
          return 0xffffffec;
        }
        uVar2 = (uint)(uint3)(CONCAT12(*(undefined *)(puVar3 + 1),uVar1) >> 3);
      }
      uVar2 = uVar2 + 3;
      if (param_2 < uVar2) {
        return 0xffffffb8;
      }
      param_2 = param_2 - uVar2;
      puVar3 = (ushort *)((int)puVar3 + uVar2);
    } while ((uVar1 & 1) == 0);
    if (local_14 != 0) {
      if (param_2 < 4) {
        return 0xffffffb8;
      }
      puVar3 = puVar3 + 2;
    }
    uVar2 = (int)puVar3 - (int)param_1;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002ef8c FUN_0002ef8c */

undefined8 FUN_0002ef8c(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint local_28;
  int iStack_24;
  int local_18;
  
  iVar1 = FUN_0002ea08(&local_28,param_1,param_2);
  if ((iVar1 == 0) && (local_18 != 1)) {
    if ((uint)(0xfffffffd < local_28) <= iStack_24 + 1U) goto LAB_0002efdc;
  }
  local_28 = 0;
  iStack_24 = 0;
LAB_0002efdc:
  return CONCAT44(iStack_24,local_28);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002f034 FUN_0002f034 */

uint FUN_0002f034(int param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  bool bVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  void *__dest;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  uVar6 = 0xffffffec;
  if (param_3 < 3) {
    return 0xffffffec;
  }
  bVar1 = *(byte *)param_2;
  uVar3 = (uint)bVar1;
  uVar7 = uVar3 & 3;
  switch(uVar7) {
  case 0:
    uVar6 = (uVar3 << 0x1c) >> 0x1e;
    if (uVar6 == 1) {
      uVar6 = (uint)(*(ushort *)param_2 >> 4);
      iVar4 = 2;
    }
    else if (uVar6 == 3) {
      uVar6 = (uint)(*(uint3 *)param_2 >> 4);
      iVar4 = 3;
    }
    else {
      uVar6 = (uint)(bVar1 >> 3);
      iVar4 = 1;
    }
    uVar3 = iVar4 + uVar6;
    if (param_3 < uVar3 + 8) {
      if (param_3 < uVar3) {
        return 0xffffffec;
      }
      __dest = (void *)(param_1 + 0x5d30);
      memcpy(__dest,(byte *)((int)param_2 + iVar4),uVar6);
      *(uint *)(param_1 + 0x5ce0) = uVar6;
      *(void **)(param_1 + 0x5cd0) = __dest;
      memset((void *)((int)__dest + uVar6),0,8);
      return uVar3;
    }
    *(uint *)(param_1 + 0x5ce0) = uVar6;
    *(byte **)(param_1 + 0x5cd0) = (byte *)((int)param_2 + iVar4);
    return uVar3;
  case 3:
    if (*(int *)(param_1 + 0x5c68) == 0) {
      return 0xffffffe2;
    }
  case 2:
    if (4 < param_3) {
      uVar8 = *param_2;
      uVar3 = (uVar3 << 0x1c) >> 0x1e;
      if (uVar3 == 2) {
        uVar5 = uVar8 >> 0x12;
        uVar9 = (uVar8 << 0xe) >> 0x12;
        bVar2 = false;
        iVar4 = 4;
      }
      else if (uVar3 == 3) {
        uVar9 = (uVar8 << 10) >> 0xe;
        if (0x20000 < uVar9) {
          return 0xffffffec;
        }
        bVar2 = false;
        uVar5 = (uint)*(byte *)(param_2 + 1) << 10 | uVar8 >> 0x16;
        iVar4 = 5;
      }
      else {
        uVar5 = (uVar8 << 8) >> 0x16;
        uVar9 = (uVar8 << 0x12) >> 0x16;
        bVar2 = uVar3 == 0;
        iVar4 = 3;
      }
      if (uVar5 + iVar4 <= param_3) {
        if (uVar7 == 3) {
          if (bVar2) {
            uVar3 = FUN_00037e60(param_1 + 0x5d30,uVar9,(byte *)((int)param_2 + iVar4),uVar5,
                                 *(undefined4 *)(param_1 + 0xc));
          }
          else {
            uVar3 = FUN_00037ee0(param_1 + 0x5d30,uVar9,(byte *)((int)param_2 + iVar4),uVar5,
                                 *(undefined4 *)(param_1 + 0xc));
          }
        }
        else if (bVar2) {
          uVar3 = FUN_00034224(param_1 + 0x141c,param_1 + 0x5d30,uVar9,
                               (byte *)((int)param_2 + iVar4),uVar5,param_1 + 0x5420,0x800);
        }
        else {
          uVar3 = FUN_0003824c(param_1 + 0x141c,param_1 + 0x5d30,uVar9,
                               (byte *)((int)param_2 + iVar4),uVar5,param_1 + 0x5420,0x800);
        }
        if (uVar3 < 0xffffff89) {
          *(uint *)(param_1 + 0x5ce0) = uVar9;
          *(int *)(param_1 + 0x5cd0) = param_1 + 0x5d30;
          *(int *)(param_1 + 0x5c68) = 1;
          if (uVar7 == 2) {
            *(int *)(param_1 + 0xc) = param_1 + 0x141c;
          }
          memset((void *)(param_1 + uVar9 + 0x5d30),0,8);
          uVar6 = uVar5 + iVar4;
        }
      }
    }
    return uVar6;
  }
  uVar6 = (uVar3 << 0x1c) >> 0x1e;
  if (uVar6 == 1) {
    iVar4 = 2;
    uVar6 = (uint)(*(ushort *)param_2 >> 4);
  }
  else if (uVar6 == 3) {
    if (param_3 < 4) {
      return 0xffffffec;
    }
    if (0x20000f < *(uint3 *)param_2) {
      return 0xffffffec;
    }
    uVar6 = (uint)(*(uint3 *)param_2 >> 4);
    iVar4 = 3;
  }
  else {
    uVar6 = (uint)(bVar1 >> 3);
    iVar4 = 1;
  }
  memset((void *)(param_1 + 0x5d30),(uint)*(byte *)((int)param_2 + iVar4),uVar6 + 8);
  *(uint *)(param_1 + 0x5ce0) = uVar6;
  *(void **)(param_1 + 0x5cd0) = (void *)(param_1 + 0x5d30);
  return iVar4 + 1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002f338 FUN_0002f338 */

byte * FUN_0002f338(int **param_1,uint *param_2,byte *param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  int **ppiVar3;
  uint uVar4;
  int iVar5;
  byte *pbVar6;
  byte *pbVar7;
  int **ppiVar8;
  byte *pbVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_96 [106];
  uint local_2c;
  undefined4 local_28;
  
  if (param_4 == 0) {
    return (byte *)0xffffffb8;
  }
  pbVar6 = param_3 + 1;
  bVar1 = *param_3;
  uVar2 = (uint)bVar1;
  if (uVar2 == 0) {
    *param_2 = 0;
    return (byte *)0x1;
  }
  iVar5 = (int)(char)bVar1;
  if (iVar5 == -1 || iVar5 + 1 < 0 != SCARRY4(iVar5,1)) {
    if (iVar5 == -1) {
      if (param_4 < 3) {
        return (byte *)0xffffffb8;
      }
      pbVar6 = param_3 + 3;
      uVar2 = *(ushort *)(param_3 + 1) + 0x7f00;
    }
    else {
      if (param_4 < 2) {
        return (byte *)0xffffffb8;
      }
      pbVar6 = param_3 + 2;
      uVar2 = CONCAT11(bVar1,param_3[1]) - 0x8000;
    }
  }
  *param_2 = uVar2;
  pbVar9 = param_3 + param_4;
  if (pbVar9 < pbVar6 + 4) {
    return (byte *)0xffffffb8;
  }
  pbVar7 = pbVar6 + 1;
  bVar1 = *pbVar6;
  ppiVar8 = param_1 + 0x171b;
  local_28 = 0x23;
  uVar10 = ((uint)bVar1 << 0x1c) >> 0x1e;
  uVar11 = ((uint)bVar1 << 0x1a) >> 0x1e;
  uVar2 = (uint)(bVar1 >> 6);
  if (bVar1 >> 6 == 0) {
    *param_1 = (int *)(DAT_0002f6d0 + 0x2f464);
LAB_0002f4ec:
    pbVar7 = pbVar7 + uVar2;
    local_28 = 0x1c;
    if (uVar11 == 0) {
      param_1[2] = (int *)(DAT_0002f6d4 + 0x2f560);
      uVar2 = 0;
    }
    else if (uVar11 == 3) {
      uVar2 = 0;
      if (*ppiVar8 == (int *)0x0) goto LAB_0002f658;
    }
    else {
      ppiVar3 = param_1 + 0x205;
      if (uVar11 == 1) {
        if (((int)pbVar9 - (int)pbVar7 == 0) || (0x1c < *pbVar7)) goto LAB_0002f658;
        FUN_00032ae0();
        uVar2 = 1;
        param_1[2] = (int *)ppiVar3;
      }
      else {
        uVar11 = FUN_00033888(auStack_96,&local_28,&local_2c,pbVar7,(int)pbVar9 - (int)pbVar7);
        uVar2 = 0xffffffec;
        if ((uVar11 < 0xffffff89) && (uVar2 = 0xffffffec, local_2c < 9)) {
          FUN_00032918(ppiVar3,auStack_96,local_28);
          param_1[2] = (int *)ppiVar3;
          uVar2 = uVar11;
        }
        if (0xffffff88 < uVar2) {
          return (byte *)0xffffffec;
        }
      }
    }
    pbVar7 = pbVar7 + uVar2;
    local_28 = 0x34;
    if (uVar10 == 0) {
      param_1[1] = (int *)(DAT_0002f6d8 + 0x2f648);
      uVar2 = 0;
    }
    else if (uVar10 == 3) {
      uVar2 = 0;
      if (*ppiVar8 == (int *)0x0) goto LAB_0002f658;
    }
    else {
      ppiVar8 = param_1 + 0x306;
      if (uVar10 == 1) {
        if (((int)pbVar9 - (int)pbVar7 == 0) || (0x34 < *pbVar7)) goto LAB_0002f658;
        FUN_00032ae0(ppiVar8);
        uVar2 = 1;
        param_1[1] = (int *)ppiVar8;
      }
      else {
        uVar10 = FUN_00033888(auStack_96,&local_28,&local_2c,pbVar7,(int)pbVar9 - (int)pbVar7);
        uVar2 = 0xffffffec;
        if ((uVar10 < 0xffffff89) && (uVar2 = 0xffffffec, local_2c < 10)) {
          FUN_00032918(ppiVar8,auStack_96,local_28);
          param_1[1] = (int *)ppiVar8;
          uVar2 = uVar10;
        }
        if (0xffffff88 < uVar2) {
          return (byte *)0xffffffec;
        }
      }
    }
    pbVar7 = pbVar7 + (uVar2 - (int)param_3);
  }
  else {
    if (uVar2 != 3) {
      ppiVar3 = param_1 + 4;
      if (uVar2 == 1) {
        if (((int)pbVar9 - (int)pbVar7 == 0) || (0x23 < *pbVar7)) goto LAB_0002f658;
        FUN_00032ae0();
        uVar2 = 1;
        *param_1 = (int *)ppiVar3;
      }
      else {
        uVar4 = FUN_00033888(auStack_96,&local_28,&local_2c,pbVar7,(int)pbVar9 - (int)pbVar7);
        uVar2 = 0xffffffec;
        if ((uVar4 < 0xffffff89) && (uVar2 = 0xffffffec, local_2c < 10)) {
          FUN_00032918(ppiVar3,auStack_96,local_28);
          *param_1 = (int *)ppiVar3;
          uVar2 = uVar4;
        }
        if (0xffffff88 < uVar2) {
          return (byte *)0xffffffec;
        }
      }
      goto LAB_0002f4ec;
    }
    uVar2 = 0;
    if (*ppiVar8 != (int *)0x0) goto LAB_0002f4ec;
LAB_0002f658:
    pbVar7 = (byte *)0xffffffec;
  }
  return pbVar7;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002f6dc FUN_0002f6dc */

void FUN_0002f6dc(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)(param_1 + 0x5c2c);
  iVar1 = *piVar2;
  if (iVar1 != param_2) {
    *(int *)(param_1 + 0x5c38) = iVar1;
    iVar3 = *(int *)(param_1 + 0x5c30);
    *piVar2 = param_2;
    *(int *)(param_1 + 0x5c30) = param_2;
    *(int *)(param_1 + 0x5c34) = param_2 + (iVar3 - iVar1);
  }
  iVar1 = FUN_0002f73c(param_1,param_2,param_3,param_4,param_5);
  *piVar2 = param_2 + iVar1;
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0002f73c FUN_0002f73c */

uint FUN_0002f73c(ushort **param_1,void *param_2,int param_3,int param_4,uint param_5)

{
  uint uVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort *puVar4;
  ushort *puVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  void *__src;
  undefined *puVar9;
  uint *puVar10;
  uint *puVar11;
  int iVar12;
  undefined *puVar13;
  uint uVar14;
  uint uVar15;
  ushort *puVar16;
  undefined *puVar17;
  uint uVar18;
  undefined *puVar19;
  ushort *puVar20;
  ushort *puVar21;
  undefined *puVar22;
  int iVar23;
  void *__dest;
  uint local_70;
  uint local_6c;
  uint *local_68;
  uint *local_64;
  uint *local_60;
  uint local_5c;
  ushort *local_58;
  uint local_54;
  ushort *local_50;
  uint local_4c;
  ushort *local_48;
  ushort *local_44 [6];
  int local_2c;
  ushort *local_28;
  
  if (param_5 >> 0x11 != 0) {
    return 0xffffffb8;
  }
  uVar1 = FUN_0002f034(param_1,param_4,param_5);
  if (0xffffff88 < uVar1) {
    return uVar1;
  }
  param_4 = param_4 + uVar1;
  puVar21 = param_1[0x1734];
  puVar2 = param_1[0x170c];
  puVar3 = param_1[0x170d];
  puVar4 = param_1[0x170e];
  puVar5 = param_1[0x1738];
  local_28 = puVar21;
  uVar6 = FUN_0002f338(param_1,&local_2c,param_4,param_5 - uVar1);
  puVar7 = (uint *)(param_4 + uVar6);
  if (0xffffff88 < uVar6) {
    return uVar6;
  }
  puVar13 = (undefined *)((int)param_2 + param_3);
  puVar5 = (ushort *)((int)puVar21 + (int)puVar5);
  __dest = param_2;
  if (local_2c == 0) {
LAB_000302ec:
    uVar1 = (int)puVar5 - (int)puVar21;
    if (uVar1 <= (uint)((int)puVar13 - (int)__dest)) {
      memcpy(__dest,puVar21,uVar1);
      return (int)__dest + (uVar1 - (int)param_2);
    }
    return 0xffffffba;
  }
  param_4 = param_4 + (param_5 - uVar1);
  param_1[0x171b] = (ushort *)0x1;
  local_44[0] = param_1[0x1708];
  local_44[1] = param_1[0x1709];
  local_44[2] = param_1[0x170a];
  uVar1 = param_4 - (int)puVar7;
  if (uVar1 == 0) {
    memset(&local_70,0,0x14);
    return 0xffffffec;
  }
  local_60 = puVar7 + 1;
  if (uVar1 < 4) {
    local_70 = (uint)*(byte *)puVar7;
    if (uVar1 == 2) {
LAB_0002f8e8:
      local_70 = local_70 + (uint)*(byte *)((int)puVar7 + 1) * 0x100;
    }
    else if (uVar1 == 3) {
      local_70 = local_70 | (uint)*(byte *)((int)puVar7 + 2) << 0x10;
      goto LAB_0002f8e8;
    }
    uVar6 = (uint)*(byte *)((int)puVar7 + (uVar1 - 1));
    if (uVar6 == 0) {
      return 0xffffffec;
    }
    uVar6 = LZCOUNT(uVar6) + uVar1 * -8 + 9;
    local_68 = puVar7;
  }
  else {
    local_70 = *(uint *)(param_4 + -4);
    uVar6 = (uint)*(byte *)((int)puVar7 + (uVar1 - 1));
    if (uVar6 == 0) {
      return 0xffffffec;
    }
    uVar6 = LZCOUNT(uVar6) - 0x17;
    local_68 = (uint *)(param_4 + -4);
    if (0xffffff88 < uVar1) {
      return 0xffffffec;
    }
  }
  uVar8 = (uint)**param_1;
  uVar1 = uVar6 + uVar8;
  local_5c = ((local_70 << (uVar6 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f);
  puVar10 = local_68;
  if (uVar1 < 0x21) {
    if (local_68 < local_60) {
      puVar10 = puVar7;
      if (local_68 == puVar7) goto LAB_0002f9c4;
      uVar6 = uVar1 >> 3;
      if ((uint *)((int)local_68 - (uVar1 >> 3)) < puVar7) {
        uVar6 = (int)local_68 - (int)puVar7;
      }
      uVar8 = uVar1 + uVar6 * -8;
      local_70 = *(uint *)((int)local_68 - uVar6);
    }
    else {
      uVar8 = uVar1 & 7;
      uVar6 = uVar1 >> 3;
      local_70 = *(uint *)((int)local_68 - (uVar1 >> 3));
    }
    local_68 = (uint *)((int)local_68 - uVar6);
    puVar10 = local_68;
    uVar1 = uVar8;
  }
LAB_0002f9c4:
  local_58 = *param_1 + 2;
  uVar8 = (uint)*param_1[2];
  uVar6 = uVar1 + uVar8;
  local_54 = ((local_70 << (uVar1 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f);
  puVar11 = puVar10;
  if (uVar6 < 0x21) {
    if (puVar10 < local_60) {
      puVar11 = puVar7;
      if (puVar10 == puVar7) goto LAB_0002fa5c;
      uVar1 = uVar6 >> 3;
      if ((uint *)((int)puVar10 - (uVar6 >> 3)) < puVar7) {
        uVar1 = (int)puVar10 - (int)puVar7;
      }
      uVar8 = uVar6 + uVar1 * -8;
      local_70 = *(uint *)((int)puVar10 - uVar1);
    }
    else {
      uVar8 = uVar6 & 7;
      uVar1 = uVar6 >> 3;
      local_70 = *(uint *)((int)puVar10 - (uVar6 >> 3));
    }
    local_68 = (uint *)((int)puVar10 - uVar1);
    uVar6 = uVar8;
    puVar11 = local_68;
  }
LAB_0002fa5c:
  local_50 = param_1[2] + 2;
  uVar1 = (uint)*param_1[1];
  local_6c = uVar6 + uVar1;
  local_4c = ((local_70 << (uVar6 & 0x1f)) >> 1) >> (0x1f - uVar1 & 0x1f);
  if (local_6c < 0x21) {
    if (puVar11 < local_60) {
      if (puVar11 == puVar7) goto LAB_0002faf0;
      uVar1 = local_6c >> 3;
      if ((uint *)((int)puVar11 - (local_6c >> 3)) < puVar7) {
        uVar1 = (int)puVar11 - (int)puVar7;
      }
      uVar6 = local_6c + uVar1 * -8;
      local_70 = *(uint *)((int)puVar11 - uVar1);
    }
    else {
      uVar6 = local_6c & 7;
      uVar1 = local_6c >> 3;
      local_70 = *(uint *)((int)puVar11 - (local_6c >> 3));
    }
    local_68 = (uint *)((int)puVar11 - uVar1);
    local_6c = uVar6;
  }
LAB_0002faf0:
  local_48 = param_1[1] + 2;
  if (0x20 < local_6c) {
    return 0xffffffec;
  }
  puVar22 = puVar13 + -8;
  local_64 = puVar7;
  if (local_68 < local_60) goto LAB_0002fb38;
LAB_0002fb28:
  local_68 = (uint *)((int)local_68 - (local_6c >> 3));
  local_6c = local_6c & 7;
  do {
    local_70 = *local_68;
    do {
      puVar21 = local_28;
      if (local_2c == 0) {
LAB_000302d0:
        param_1[0x1708] = local_44[0];
        param_1[0x1709] = local_44[1];
        param_1[0x170a] = local_44[2];
        puVar21 = local_28;
        goto LAB_000302ec;
      }
      local_2c = local_2c + -1;
      uVar8 = (uint)*(byte *)(local_58 + local_5c * 2 + 1);
      uVar6 = (uint)*(byte *)(local_48 + local_4c * 2 + 1);
      iVar23 = *(int *)(DAT_0003032c + 0x2fbcc + uVar8 * 4);
      iVar12 = *(int *)(DAT_00030330 + 0x2fbdc + uVar6 * 4);
      uVar1 = (uint)*(byte *)(local_50 + local_54 * 2 + 1);
      if (uVar1 == 0) {
        puVar16 = (ushort *)0x0;
LAB_0002fcb4:
        if (uVar8 == 0) {
          puVar16 = (ushort *)((int)puVar16 + 1);
        }
        if (puVar16 != (ushort *)0x0) {
          if (puVar16 == (ushort *)0x3) {
            puVar20 = (ushort *)((int)local_44[0] + -1);
            if ((ushort *)((int)local_44[0] + -1) == (ushort *)0x0) {
              puVar20 = local_44[0];
            }
LAB_0002fd24:
            local_44[2] = local_44[1];
          }
          else {
            puVar20 = local_44[(int)puVar16];
            if (puVar20 == (ushort *)0x0) {
              puVar20 = (ushort *)0x1;
            }
            if (puVar16 != (ushort *)0x1) goto LAB_0002fd24;
          }
          local_44[1] = local_44[0];
          local_44[0] = puVar20;
        }
      }
      else {
        uVar15 = local_6c & 0x1f;
        local_6c = local_6c + uVar1;
        uVar15 = local_70 << uVar15;
        if (local_6c < 0x21) {
          if (local_68 < local_60) {
            if (local_68 == local_64) goto LAB_0002fc98;
            uVar18 = local_6c >> 3;
            if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
              uVar18 = (int)local_68 - (int)local_64;
            }
            uVar14 = local_6c + uVar18 * -8;
            local_70 = *(uint *)((int)local_68 - uVar18);
          }
          else {
            uVar14 = local_6c & 7;
            uVar18 = local_6c >> 3;
            local_70 = *(uint *)((int)local_68 - (local_6c >> 3));
          }
          local_68 = (uint *)((int)local_68 - uVar18);
          local_6c = uVar14;
        }
LAB_0002fc98:
        puVar16 = (ushort *)
                  (*(int *)(DAT_00030334 + 0x2fc1c + uVar1 * 4) + (uVar15 >> (-uVar1 & 0x1f)));
        if (uVar1 < 2) goto LAB_0002fcb4;
        local_44[2] = local_44[1];
        local_44[1] = local_44[0];
        local_44[0] = puVar16;
      }
      puVar16 = local_44[0];
      uVar1 = 0;
      if (0x1f < uVar6) {
        uVar1 = local_6c & 0x1f;
        local_6c = local_6c + iVar12;
        uVar1 = (local_70 << uVar1) >> (-iVar12 & 0x1fU);
      }
      if ((0x18 < (uint)(iVar12 + iVar23)) && (local_6c < 0x21)) {
        if (local_68 < local_60) {
          if (local_68 == local_64) goto LAB_0002fdf0;
          uVar15 = local_6c >> 3;
          if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
            uVar15 = (int)local_68 - (int)local_64;
          }
          uVar18 = local_6c + uVar15 * -8;
          local_70 = *(uint *)((int)local_68 - uVar15);
        }
        else {
          uVar18 = local_6c & 7;
          uVar15 = local_6c >> 3;
          local_70 = *(uint *)((int)local_68 - (local_6c >> 3));
        }
        local_68 = (uint *)((int)local_68 - uVar15);
        local_6c = uVar18;
      }
LAB_0002fdf0:
      uVar15 = 0;
      if (0xf < uVar8) {
        uVar15 = (local_70 << (local_6c & 0x1f)) >> (-iVar23 & 0x1fU);
        local_6c = local_6c + iVar23;
      }
      if (local_6c < 0x21) {
        if (local_68 < local_60) {
          if (local_68 == local_64) goto LAB_0002fea8;
          uVar18 = local_6c >> 3;
          if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
            uVar18 = (int)local_68 - (int)local_64;
          }
          uVar14 = local_6c + uVar18 * -8;
          local_70 = *(uint *)((int)local_68 - uVar18);
        }
        else {
          uVar14 = local_6c & 7;
          uVar18 = local_6c >> 3;
          local_70 = *(uint *)((int)local_68 - (local_6c >> 3));
        }
        local_68 = (uint *)((int)local_68 - uVar18);
        local_6c = uVar14;
      }
LAB_0002fea8:
      uVar15 = uVar15 + *(int *)(DAT_0003033c + 0x2fe40 + uVar8 * 4);
      uVar1 = uVar1 + *(int *)(DAT_00030338 + 0x2fe34 + uVar6 * 4);
      uVar6 = (uint)*(byte *)((int)(local_58 + local_5c * 2) + 3);
      uVar18 = local_6c + uVar6;
      local_5c = (uint)local_58[local_5c * 2] +
                 (((local_70 << (local_6c & 0x1f)) >> 1) >> (0x1f - uVar6 & 0x1f));
      uVar8 = (uint)*(byte *)((int)(local_48 + local_4c * 2) + 3);
      uVar6 = uVar18 + uVar8;
      local_4c = (uint)local_48[local_4c * 2] +
                 (((local_70 << (uVar18 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f));
      if (uVar6 < 0x21) {
        if (local_68 < local_60) {
          if (local_68 == local_64) goto LAB_0002ff8c;
          uVar8 = uVar6 >> 3;
          if ((uint *)((int)local_68 - (uVar6 >> 3)) < local_64) {
            uVar8 = (int)local_68 - (int)local_64;
          }
          uVar18 = uVar6 + uVar8 * -8;
          local_70 = *(uint *)((int)local_68 - uVar8);
        }
        else {
          uVar18 = uVar6 & 7;
          uVar8 = uVar6 >> 3;
          local_70 = *(uint *)((int)local_68 - (uVar6 >> 3));
        }
        local_68 = (uint *)((int)local_68 - uVar8);
        uVar6 = uVar18;
      }
LAB_0002ff8c:
      uVar8 = (uint)*(byte *)((int)(local_50 + local_54 * 2) + 3);
      local_6c = uVar6 + uVar8;
      local_54 = (uint)local_50[local_54 * 2] +
                 (((local_70 << (uVar6 & 0x1f)) >> 1) >> (0x1f - uVar8 & 0x1f));
      uVar6 = uVar15 + uVar1;
      puVar9 = (undefined *)((int)__dest + uVar6);
      if (puVar13 < puVar9) {
        return 0xffffffba;
      }
      puVar20 = (ushort *)((int)local_28 + uVar15);
      if (puVar5 < puVar20) {
        return 0xffffffec;
      }
      puVar17 = (undefined *)((int)__dest + uVar15);
      if (puVar22 < puVar17) {
        uVar6 = FUN_000325a4(__dest,puVar13,uVar15,uVar1,local_44[0],local_44[0],&local_28,puVar5,
                             puVar2,puVar3,puVar4);
      }
      else {
        memcpy(__dest,local_28,8);
        if (8 < uVar15) {
          puVar19 = (undefined *)((int)__dest + 8);
          do {
            puVar21 = puVar21 + 4;
            memcpy(puVar19,puVar21,8);
            puVar19 = puVar19 + 8;
          } while (puVar19 < puVar17);
        }
        puVar21 = (ushort *)(puVar17 + -(int)puVar16);
        local_28 = puVar20;
        if (puVar17 + -(int)puVar2 < puVar16) {
          if (puVar17 + -(int)puVar3 < puVar16) {
            return 0xffffffec;
          }
          iVar12 = (int)puVar21 - (int)puVar2;
          __src = (void *)((int)puVar4 + iVar12);
          if (puVar4 < (ushort *)((int)__src + uVar1)) {
            memmove(puVar17,__src,-iVar12);
            puVar17 = puVar17 + -iVar12;
            uVar1 = iVar12 + uVar1;
            puVar21 = puVar2;
            if ((puVar17 <= puVar22) && (2 < uVar1)) {
              if (puVar16 < (ushort *)0x8) goto LAB_00030144;
              goto LAB_00030124;
            }
            for (; uVar1 != 0; uVar1 = uVar1 - 1) {
              *puVar17 = *(undefined *)puVar21;
              puVar21 = (ushort *)((int)puVar21 + 1);
              puVar17 = puVar17 + 1;
            }
          }
          else {
            memmove(puVar17,__src,uVar1);
          }
        }
        else {
          if (puVar16 < (ushort *)0x8) {
LAB_00030144:
            *puVar17 = *(undefined *)puVar21;
            puVar17[1] = *(undefined *)((int)puVar21 + 1);
            iVar12 = DAT_00030340;
            puVar17[2] = *(undefined *)(puVar21 + 1);
            puVar17[3] = *(undefined *)((int)puVar21 + 3);
            puVar19 = (undefined *)((int)puVar21 + *(int *)(iVar12 + 0x3016c + (int)puVar16 * 4));
            memcpy(puVar17 + 4,puVar19,4);
            puVar21 = (ushort *)(puVar19 + -*(int *)(DAT_00030344 + 0x30190 + (int)puVar16 * 4));
          }
          else {
LAB_00030124:
            memcpy(puVar17,puVar21,8);
          }
          puVar21 = puVar21 + 4;
          puVar19 = puVar17 + 8;
          if (puVar13 + -0xd < puVar9) {
            puVar17 = puVar19;
            puVar16 = puVar21;
            if (puVar19 < puVar22) {
              do {
                memcpy(puVar17,puVar16,8);
                puVar17 = puVar17 + 8;
                puVar16 = puVar16 + 4;
              } while (puVar17 < puVar22);
              puVar21 = (ushort *)((int)puVar21 + ((int)puVar22 - (int)puVar19));
              puVar19 = puVar22;
            }
            for (; puVar19 < puVar9; puVar19 = puVar19 + 1) {
              *puVar19 = *(undefined *)puVar21;
              puVar21 = (ushort *)((int)puVar21 + 1);
            }
          }
          else {
            do {
              memcpy(puVar19,puVar21,8);
              puVar19 = puVar19 + 8;
              puVar21 = puVar21 + 4;
            } while (puVar19 < puVar17 + uVar1);
          }
        }
      }
      if (0xffffff88 < uVar6) {
        return uVar6;
      }
      __dest = (void *)((int)__dest + uVar6);
      if (0x20 < local_6c) {
        if (local_2c != 0) {
          return 0xffffffec;
        }
        goto LAB_000302d0;
      }
      if (local_60 <= local_68) goto LAB_0002fb28;
LAB_0002fb38:
    } while (local_68 == local_64);
    uVar1 = local_6c >> 3;
    if ((uint *)((int)local_68 - (local_6c >> 3)) < local_64) {
      uVar1 = (int)local_68 - (int)local_64;
    }
    local_68 = (uint *)((int)local_68 - uVar1);
    local_6c = local_6c + uVar1 * -8;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030384 FUN_00030384 */

uint FUN_00030384(void *param_1,uint param_2,int param_3,uint param_4)

{
  uint uVar1;
  
  uVar1 = 0xffffffba;
  if (param_4 <= param_2) {
    memset(param_1,param_3,param_4);
    uVar1 = param_4;
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000303b4 FUN_000303b4 */

void FUN_000303b4(void)

{
  FUN_000303e8();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000303e8 FUN_000303e8 */

uint FUN_000303e8(int **param_1,int *param_2,int param_3,uint *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,int param_8)

{
  byte bVar1;
  ushort uVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  byte *__src;
  uint uVar9;
  undefined8 uVar10;
  int local_48;
  int *local_28;
  
  if (param_8 != 0) {
    param_6 = *(undefined4 *)(param_8 + 4);
    param_7 = *(undefined4 *)(param_8 + 8);
  }
  local_28 = param_2;
  if (4 < param_5) {
    piVar3 = (int *)(param_1 + 0x171c);
    local_48 = param_3;
    do {
      uVar4 = *param_4;
      if (uVar4 == 0xfd2fb528) {
        if (param_8 == 0) {
          uVar4 = FUN_00030f1c(param_1,param_6,param_7);
          if (0xffffff88 < uVar4) {
            return uVar4;
          }
          piVar5 = param_1[0x170b];
        }
        else {
          param_1[0x170b] = (int *)0x0;
          param_1[0x170c] = (int *)0x0;
          param_1[0x170d] = (int *)0x0;
          param_1[0x170e] = (int *)0x0;
          param_1[0x170f] = (int *)0x5;
          param_1[0x507] = (int *)0xc00000c;
          param_1[0x1733] = (int *)0x0;
          param_1[0x1719] = (int *)0x0;
          param_1[0x171a] = (int *)0x0;
          param_1[0x171b] = (int *)0x0;
          memcpy(param_1 + 0x1708,(void *)(DAT_00030950 + 0x30530),0xc);
          *param_1 = (int *)(param_1 + 4);
          param_1[1] = (int *)(param_1 + 0x306);
          param_1[2] = (int *)(param_1 + 0x205);
          param_1[3] = (int *)(param_1 + 0x507);
          param_1[0x1733] = *(int **)(param_8 + 0x5c28);
          piVar5 = *(int **)(param_8 + 4);
          param_1[0x170c] = piVar5;
          param_1[0x170d] = piVar5;
          piVar5 = (int *)((int)piVar5 + *(int *)(param_8 + 8));
          param_1[0x170e] = piVar5;
          param_1[0x170b] = piVar5;
          if (*(int *)(param_8 + 0x5c2c) == 0) {
            param_1[0x171a] = (int *)0x0;
            param_1[0x171b] = (int *)0x0;
          }
          else {
            param_1[0x171a] = (int *)0x1;
            param_1[0x171b] = (int *)0x1;
            *param_1 = (int *)(param_8 + 0xc);
            param_1[1] = (int *)(param_8 + 0xc14);
            param_1[2] = (int *)(param_8 + 0x810);
            param_1[3] = (int *)(param_8 + 0x1418);
            param_1[0x1708] = (int *)*(int *)(param_8 + 0x5c1c);
            param_1[0x1709] = *(int **)(param_8 + 0x5c20);
            param_1[0x170a] = *(int **)(param_8 + 0x5c24);
          }
        }
        if (piVar5 != local_28) {
          param_1[0x170e] = piVar5;
          piVar7 = param_1[0x170c];
          param_1[0x170b] = local_28;
          param_1[0x170c] = local_28;
          param_1[0x170d] = (int *)((int)local_28 + ((int)piVar7 - (int)piVar5));
        }
        if (param_5 < 9) {
          return 0xffffffb8;
        }
        bVar1 = *(byte *)(param_4 + 1);
        iVar8 = 6;
        if ((bVar1 & 0x20) != 0) {
          iVar8 = 5;
        }
        uVar4 = *(int *)(DAT_00030958 + 0x306a4 + (uint)(bVar1 >> 6) * 4) +
                *(int *)(DAT_00030954 + 0x30690 + (bVar1 & 3) * 4) + iVar8 +
                ((uint)(bVar1 >> 6 == 0) & (bVar1 & 0x20) >> 5);
        if (0xffffff88 < uVar4) {
          return uVar4;
        }
        if (param_5 < uVar4 + 3) {
          return 0xffffffb8;
        }
        uVar10 = FUN_0002ea08(param_1 + 0x1710,param_4,uVar4);
        piVar5 = (int *)((ulonglong)uVar10 >> 0x20);
        uVar9 = (uint)uVar10;
        if (0xffffff88 < uVar9) {
          return uVar9;
        }
        if (uVar9 != 0) {
          return 0xffffffb8;
        }
        piVar7 = param_1[0x1716];
        if (piVar7 != (int *)0x0) {
          piVar5 = param_1[0x1733];
        }
        if (piVar7 != (int *)0x0 && piVar5 != piVar7) {
          return 0xffffffe0;
        }
        if (param_1[0x1717] != (int *)0x0) {
          FUN_00039660(piVar3,piVar5,0,0);
        }
        param_5 = param_5 - uVar4;
        param_4 = (uint *)((int)param_4 + uVar4);
        piVar5 = local_28;
        if (param_5 < 3) {
          return 0xffffffb8;
        }
        while( true ) {
          uVar2 = *(ushort *)param_4;
          uVar4 = (uint)(*(uint3 *)param_4 >> 3);
          uVar6 = ((uint)uVar2 << 0x1d) >> 0x1e;
          uVar9 = uVar6;
          if ((uVar6 != 1) && (uVar9 = uVar4, uVar6 == 3)) {
            return 0xffffffec;
          }
          if (param_5 - 3 < uVar9) {
            return 0xffffffb8;
          }
          __src = (byte *)((int)param_4 + 3);
          if (uVar6 == 2) {
            uVar4 = FUN_0002f73c(param_1,piVar5,(int)local_28 + (local_48 - (int)piVar5),__src,uVar9
                                );
            if (0xffffff88 < uVar4) {
              return uVar4;
            }
          }
          else if (uVar6 == 1) {
            if ((uint)((int)local_28 + (local_48 - (int)piVar5)) < uVar4) {
              return 0xffffffba;
            }
            memset(piVar5,(uint)*__src,uVar4);
          }
          else {
            if (uVar6 != 0) {
              return 0xffffffec;
            }
            if ((uint)((int)local_28 + (local_48 - (int)piVar5)) < uVar9) {
              return 0xffffffba;
            }
            memcpy(piVar5,__src,uVar9);
            uVar4 = uVar9;
          }
          if (param_1[0x1717] != (int *)0x0) {
            FUN_000399ac(piVar3,piVar5,uVar4);
          }
          param_5 = (param_5 - 3) - uVar9;
          param_4 = (uint *)(__src + uVar9);
          piVar5 = (int *)((int)piVar5 + uVar4);
          if ((uVar2 & 1) != 0) break;
          if (param_5 < 3) {
            return 0xffffffb8;
          }
        }
        if (param_1[0x1717] != (int *)0x0) {
          uVar4 = FUN_00039e88(piVar3);
          if (param_5 < 4) {
            return 0xffffffea;
          }
          if (*param_4 != uVar4) {
            return 0xffffffea;
          }
          param_5 = param_5 - 4;
          param_4 = param_4 + 1;
        }
        uVar4 = (int)piVar5 - (int)local_28;
        if (0xffffff88 < uVar4) {
          return uVar4;
        }
        local_48 = local_48 - uVar4;
        local_28 = piVar5;
      }
      else {
        if (uVar4 >> 4 != 0x184d2a5) {
          return 0xfffffff6;
        }
        if (7 < param_5) {
          uVar4 = param_4[1] + 8;
        }
        if (7 >= param_5 || param_5 < uVar4) {
          return 0xffffffb8;
        }
        param_5 = param_5 - uVar4;
        param_4 = (uint *)((int)param_4 + uVar4);
      }
    } while (4 < param_5);
  }
  uVar4 = 0xffffffb8;
  if (param_5 == 0) {
    uVar4 = (int)local_28 - (int)param_2;
  }
  return uVar4;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003095c FUN_0003095c */

void FUN_0003095c(void)

{
  FUN_000303e8();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030988 FUN_00030988 */

undefined4 FUN_00030988(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  
  piVar2 = (int *)FUN_0003a4a8(&LAB_00025d50,0,0,0);
  iVar1 = DAT_00030ad0;
  if (piVar2 != (int *)0x0) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = 0;
    piVar2[0x1736] = 0;
    piVar2[0x1737] = 0;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    memcpy(piVar2 + 0x1708,(void *)(iVar1 + 0x309fc),0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    uVar3 = FUN_000303e8(piVar2,param_1,param_2,param_3,param_4,0,0,0);
    FUN_0002e838(piVar2);
    return uVar3;
  }
  return 0xffffffc0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030b0c FUN_00030b0c */

uint FUN_00030b0c(int param_1,void *param_2,uint param_3,uint *param_4,uint param_5)

{
  byte bVar1;
  ushort uVar2;
  uint uVar3;
  undefined4 uVar4;
  void *pvVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  void **ppvVar9;
  bool bVar10;
  
  if (*(size_t *)(param_1 + 0x5c3c) != param_5) {
    return 0xffffffb8;
  }
  pvVar5 = (void *)0x5c2c;
  ppvVar9 = (void **)(param_1 + 0x5c2c);
  if (param_3 != 0) {
    pvVar5 = *ppvVar9;
  }
  if (param_3 != 0 && pvVar5 != param_2) {
    *(void **)(param_1 + 0x5c38) = pvVar5;
    iVar7 = *(int *)(param_1 + 0x5c30);
    *ppvVar9 = param_2;
    *(void **)(param_1 + 0x5c30) = param_2;
    *(int *)(param_1 + 0x5c34) = (int)param_2 + (iVar7 - (int)pvVar5);
  }
  switch(*(undefined4 *)(param_1 + 0x5c64)) {
  case 0:
    if (param_5 != 5) {
      return 0xffffffb8;
    }
    if (*param_4 >> 4 != 0x184d2a5) {
      bVar1 = *(byte *)(param_4 + 1);
      iVar7 = 6;
      if ((bVar1 & 0x20) != 0) {
        iVar7 = 5;
      }
      uVar3 = *(int *)(DAT_00030f18 + 0x30dd8 + (uint)(bVar1 >> 6) * 4) +
              *(int *)(DAT_00030f14 + 0x30dd0 + (bVar1 & 3) * 4) + iVar7 +
              ((uint)(bVar1 >> 6 == 0) & (bVar1 & 0x20) >> 5);
      *(uint *)(param_1 + 0x5cc8) = uVar3;
      if (0xffffff88 < uVar3) {
        return uVar3;
      }
      memcpy(&UNK_00025d38 + param_1,param_4,5);
      if (5 < *(uint *)(param_1 + 0x5cc8)) {
        iVar7 = *(uint *)(param_1 + 0x5cc8) - 5;
        *(undefined4 *)(param_1 + 0x5c64) = 1;
        goto LAB_00030f04;
      }
      param_5 = 0;
      *(undefined4 *)(param_1 + 0x5c3c) = 0;
      goto switchD_00030b8c_caseD_1;
    }
    memcpy(&UNK_00025d38 + param_1,param_4,5);
    uVar4 = 6;
    goto LAB_00030efc;
  case 1:
switchD_00030b8c_caseD_1:
    memcpy(&UNK_00025d3d + param_1,param_4,param_5);
    iVar7 = *(int *)(param_1 + 0x5cc8);
    uVar3 = FUN_0002ea08(param_1 + 0x5c40,&UNK_00025d38 + param_1);
    if ((0xffffff88 < uVar3) || (bVar10 = uVar3 != 0, uVar3 = 0xffffffb8, bVar10)) {
      return uVar3;
    }
    iVar6 = *(int *)(param_1 + 0x5c58);
    if (iVar6 != 0) {
      iVar7 = *(int *)(param_1 + 0x5ccc);
      uVar3 = 0xffffffe0;
    }
    if (iVar6 != 0 && iVar7 != iVar6) {
      return uVar3;
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      FUN_00039660(param_1 + 0x5c70,iVar6,0,0);
    }
    break;
  case 2:
    uVar2 = *(ushort *)param_4;
    uVar8 = ((uint)uVar2 << 0x1d) >> 0x1e;
    uVar3 = uVar8;
    if ((uVar8 != 1) && (uVar3 = (uint)(*(uint3 *)param_4 >> 3), uVar8 == 3)) {
      return 0xffffffec;
    }
    *(uint *)(param_1 + 0x5ce4) = (uint)(*(uint3 *)param_4 >> 3);
    *(uint *)(param_1 + 0x5c60) = uVar8;
    *(uint *)(param_1 + 0x5c3c) = uVar3;
    if (uVar3 != 0) {
      uVar4 = 3;
      if ((uVar2 & 1) != 0) {
        uVar4 = 4;
      }
      *(undefined4 *)(param_1 + 0x5c64) = uVar4;
      return 0;
    }
    if ((uVar2 & 1) != 0) {
      if (*(int *)(param_1 + 0x5c5c) != 0) {
        *(undefined4 *)(param_1 + 0x5c64) = 5;
        iVar7 = 4;
        goto LAB_00030f04;
      }
      goto switchD_00030b8c_caseD_7;
    }
    break;
  case 3:
  case 4:
    iVar7 = *(int *)(param_1 + 0x5c60);
    if (iVar7 == 0) {
      if (param_3 < param_5) {
        return 0xffffffba;
      }
      memcpy(param_2,param_4,param_5);
      if (0xffffff88 < param_5) {
        return param_5;
      }
    }
    else {
      if (iVar7 == 1) {
        if (param_5 != 1) {
          return 0xffffffb8;
        }
        param_5 = *(uint *)(param_1 + 0x5ce4);
        if (param_3 < param_5) {
          return 0xffffffba;
        }
        memset(param_2,(uint)*(byte *)param_4,param_5);
      }
      else {
        if (iVar7 != 2) {
          return 0xffffffec;
        }
        param_5 = FUN_0002f73c(param_1,param_2,param_3,param_4,param_5);
      }
      if (0xffffff88 < param_5) {
        return param_5;
      }
    }
    if (*(int *)(param_1 + 0x5c5c) != 0) {
      FUN_000399ac(param_1 + 0x5c70,param_2,param_5);
    }
    if (*(int *)(param_1 + 0x5c64) == 4) {
      if (*(int *)(param_1 + 0x5c5c) == 0) {
        uVar4 = 0;
        *(undefined4 *)(param_1 + 0x5c64) = 0;
      }
      else {
        *(undefined4 *)(param_1 + 0x5c64) = 5;
        uVar4 = 4;
      }
      *(undefined4 *)(param_1 + 0x5c3c) = uVar4;
    }
    else {
      *(undefined4 *)(param_1 + 0x5c3c) = 3;
      *(undefined4 *)(param_1 + 0x5c64) = 2;
      *ppvVar9 = (void *)((int)param_2 + param_5);
    }
    return param_5;
  case 5:
    uVar3 = FUN_00039e88(param_1 + 0x5c70);
    if (*param_4 != uVar3) {
      return 0xffffffea;
    }
  case 7:
switchD_00030b8c_caseD_7:
    *(undefined4 *)(param_1 + 0x5c64) = 0;
    *(undefined4 *)(param_1 + 0x5c3c) = 0;
    return 0;
  case 6:
    memcpy(&UNK_00025d3d + param_1,param_4,param_5);
    *(undefined4 *)(param_1 + 0x5c3c) = *(undefined4 *)(&DAT_00025d3c + param_1);
    *(undefined4 *)(param_1 + 0x5c64) = 7;
    return 0;
  default:
    return 0xffffffff;
  }
  uVar4 = 2;
LAB_00030efc:
  *(undefined4 *)(param_1 + 0x5c64) = uVar4;
  iVar7 = 3;
LAB_00030f04:
  *(int *)(param_1 + 0x5c3c) = iVar7;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00030f1c FUN_00030f1c */

undefined4 FUN_00030f1c(int *param_1,int *param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar2 = DAT_00031058;
  piVar4 = param_1 + 0x170b;
  *piVar4 = 0;
  param_1[0x170c] = 0;
  param_1[0x170d] = 0;
  param_1[0x170e] = 0;
  param_1[0x170f] = 5;
  param_1[0x1733] = 0;
  param_1[0x1719] = 0;
  param_1[0x171a] = 0;
  param_1[0x171b] = 0;
  param_1[0x507] = 0xc00000c;
  memcpy(param_1 + 0x1708,(void *)(iVar2 + 0x30f68),0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  if (param_2 != (int *)0x0 && param_3 != 0) {
    if ((param_3 < 8) || (*param_2 != -0x13cf5bc9)) {
      iVar2 = *piVar4;
      iVar3 = param_1[0x170c];
      *piVar4 = (int)param_2 + param_3;
      param_1[0x170c] = (int)param_2;
      param_1[0x170d] = (int)param_2 + (iVar3 - iVar2);
      param_1[0x170e] = iVar2;
    }
    else {
      param_1[0x1733] = param_2[1];
      uVar1 = FUN_00032720(param_1 + 4,param_2,param_3);
      if (0xffffff88 < uVar1) {
        return 0xffffffe2;
      }
      iVar2 = *piVar4;
      iVar3 = param_1[0x170c];
      param_1[0x171a] = 1;
      param_1[0x171b] = 1;
      *piVar4 = (int)param_2 + param_3;
      param_1[0x170c] = (int)param_2 + uVar1;
      param_1[0x170d] = (int)param_2 + uVar1 + (iVar3 - iVar2);
      param_1[0x170e] = iVar2;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003105c FUN_0003105c */

undefined4 FUN_0003105c(int *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = DAT_000311b8;
  param_1[0x1719] = 0;
  param_1[0x170f] = 5;
  param_1[0x170e] = 0;
  param_1[0x170d] = 0;
  param_1[0x170c] = 0;
  param_1[0x170b] = 0;
  param_1[0x171b] = 0;
  param_1[0x1733] = 0;
  param_1[0x171a] = 0;
  param_1[0x507] = 0xc00000c;
  memcpy(param_1 + 0x1708,(void *)(iVar1 + 0x31098),0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  if (param_2 != 0) {
    param_1[0x1733] = *(int *)(param_2 + 0x5c28);
    iVar1 = *(int *)(param_2 + 4);
    param_1[0x170d] = iVar1;
    param_1[0x170c] = iVar1;
    iVar1 = iVar1 + *(int *)(param_2 + 8);
    param_1[0x170b] = iVar1;
    param_1[0x170e] = iVar1;
    if (*(int *)(param_2 + 0x5c2c) != 0) {
      param_1[0x171a] = 1;
      param_1[0x171b] = 1;
      *param_1 = param_2 + 0xc;
      param_1[1] = param_2 + 0xc14;
      param_1[2] = param_2 + 0x810;
      param_1[3] = param_2 + 0x1418;
      param_1[0x1708] = *(int *)(param_2 + 0x5c1c);
      param_1[0x1709] = *(int *)(param_2 + 0x5c20);
      param_1[0x170a] = *(int *)(param_2 + 0x5c24);
      return 0;
    }
    param_1[0x171a] = 0;
    param_1[0x171b] = 0;
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000311bc FUN_000311bc */

undefined4 *
FUN_000311bc(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5,
            undefined4 param_6)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (((param_4 == 0) == (param_5 == 0)) &&
     (puVar1 = (undefined4 *)FUN_0003a4a8(0x5c3c,param_4,param_5,param_6),
     puVar1 != (undefined4 *)0x0)) {
    puVar1[0x170c] = param_4;
    puVar1[0x170d] = param_5;
    puVar1[0x170e] = param_6;
    uVar2 = FUN_00031284(puVar1,param_1,param_2,param_3);
    if (uVar2 < 0xffffff89) {
      return puVar1;
    }
    iVar3 = puVar1[0x170c];
    uVar4 = puVar1[0x170d];
    uVar5 = puVar1[0x170e];
    FUN_0003a514(*puVar1,iVar3,uVar4,uVar5);
    FUN_0003a514(puVar1,iVar3,uVar4,uVar5);
  }
  return (undefined4 *)0x0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031284 FUN_00031284 */

undefined4 FUN_00031284(void **param_1,void *param_2,void *param_3,int param_4)

{
  void *__dest;
  undefined4 uVar1;
  uint uVar2;
  int *piVar3;
  
  if ((param_3 == (void *)0x0 || param_2 == (void *)0x0) || (param_4 != 0)) {
    *param_1 = (void *)0x0;
    param_1[1] = param_2;
  }
  else {
    __dest = (void *)FUN_0003a4a8(param_3,param_1[0x170c],param_1[0x170d],param_1[0x170e]);
    *param_1 = __dest;
    param_1[1] = __dest;
    if (__dest == (void *)0x0) {
      return 0xffffffc0;
    }
    memcpy(__dest,param_2,(size_t)param_3);
  }
  param_1[2] = param_3;
  param_1[0x506] = (void *)0xc00000c;
  uVar1 = 0;
  param_1[0x170a] = (void *)0x0;
  param_1[0x170b] = (void *)0x0;
  if (((void *)0x7 < param_3) && (piVar3 = (int *)param_1[1], *piVar3 == -0x13cf5bc9)) {
    param_1[0x170a] = (void *)piVar3[1];
    uVar2 = FUN_00032720(param_1 + 3,piVar3,param_3);
    uVar1 = 0xffffffe2;
    if (uVar2 < 0xffffff89) {
      param_1[0x170b] = (void *)0x1;
      uVar1 = 0;
    }
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003136c FUN_0003136c */

undefined4 * FUN_0003136c(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  
  puVar1 = (undefined4 *)FUN_0003a4a8(0x5c3c,0,0,0);
  puVar5 = (undefined4 *)0x0;
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[0x170c] = 0;
    puVar1[0x170d] = 0;
    puVar1[0x170e] = 0;
    uVar2 = FUN_00031284(puVar1,param_1,param_2,0);
    puVar5 = puVar1;
    if (0xffffff88 < uVar2) {
      uVar3 = puVar1[0x170d];
      uVar4 = puVar1[0x170e];
      uVar6 = puVar1[0x170c];
      FUN_0003a514(*puVar1,uVar6,uVar3,uVar4);
      FUN_0003a514(puVar1,uVar6,uVar3,uVar4);
      puVar5 = (undefined4 *)0x0;
    }
  }
  return puVar5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031414 FUN_00031414 */

undefined4 * FUN_00031414(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  
  puVar1 = (undefined4 *)FUN_0003a4a8(0x5c3c,0,0,0);
  puVar5 = (undefined4 *)0x0;
  if (puVar1 != (undefined4 *)0x0) {
    *puVar1 = 0;
    puVar1[1] = param_1;
    puVar1[2] = param_2;
    puVar1[0x506] = 0xc00000c;
    puVar1[0x170a] = 0;
    puVar1[0x170b] = 0;
    puVar1[0x170c] = 0;
    puVar1[0x170d] = 0;
    puVar1[0x170e] = 0;
    puVar5 = puVar1;
    if ((7 < param_2) && (*param_1 == -0x13cf5bc9)) {
      puVar1[0x170a] = param_1[1];
      uVar2 = FUN_00032720(puVar1 + 3,param_1,param_2);
      if (uVar2 < 0xffffff89) {
        puVar1[0x170b] = 1;
        return puVar1;
      }
      uVar3 = puVar1[0x170c];
      uVar6 = puVar1[0x170d];
      uVar4 = puVar1[0x170e];
      FUN_0003a514(*puVar1,uVar3,uVar6,uVar4);
      FUN_0003a514(puVar1,uVar3,uVar6,uVar4);
      puVar5 = (undefined4 *)0x0;
    }
  }
  return puVar5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031518 FUN_00031518 */

undefined4 * FUN_00031518(undefined4 *param_1,uint param_2,int *param_3,uint param_4,int param_5)

{
  undefined4 *puVar1;
  uint uVar2;
  
  puVar1 = (undefined4 *)0x0;
  if (((uint)param_1 & 7) == 0) {
    uVar2 = param_4 + 0x5c3c;
    if (param_5 != 0) {
      uVar2 = 0x5c3c;
    }
    if (uVar2 <= param_2) {
      if (param_5 == 0) {
        memcpy(param_1 + 0x170f,param_3,param_4);
        param_3 = param_1 + 0x170f;
      }
      *param_1 = 0;
      param_1[1] = param_3;
      param_1[2] = param_4;
      param_1[0x506] = 0xc00000c;
      param_1[0x170a] = 0;
      param_1[0x170b] = 0;
      puVar1 = param_1;
      if ((7 < param_4) && (*param_3 == -0x13cf5bc9)) {
        param_1[0x170a] = param_3[1];
        uVar2 = FUN_00032720(param_1 + 3,param_3,param_4);
        puVar1 = (undefined4 *)(uint)(uVar2 < 0xffffff89);
        if (uVar2 < 0xffffff89) {
          param_1[0x170b] = (undefined4 *)(uint)(uVar2 < 0xffffff89);
          puVar1 = param_1;
        }
      }
    }
  }
  return puVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031674 FUN_00031674 */

undefined4 FUN_00031674(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_14 = 0;
  local_18 = 0;
  local_1c = 0;
  local_20 = 0;
  local_24 = 0;
  local_28 = 0;
  local_2c = 0;
  local_30 = 0;
  uVar1 = FUN_0002ea08(&local_30,param_1,param_2);
  if (0xffffff88 < uVar1) {
    local_18 = 0;
  }
  return local_18;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000316cc FUN_000316cc */

void FUN_000316cc(void)

{
  FUN_000303e8();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031700 FUN_00031700 */

int * FUN_00031700(void)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)FUN_0003a4a8(&LAB_00025d50,0,0,0);
  iVar1 = DAT_000317f8;
  piVar3 = (int *)0x0;
  if (piVar2 != (int *)0x0) {
    piVar2[0x1748] = 0;
    piVar2[0x1749] = 0;
    piVar2[0x1735] = 0;
    piVar2[0x1736] = 0;
    piVar2[0x1737] = 0;
    piVar2[0x170b] = 0;
    piVar2[0x170c] = 0;
    piVar2[0x170d] = 0;
    piVar2[0x170e] = 0;
    piVar2[0x170f] = 5;
    piVar2[0x507] = 0xc00000c;
    piVar2[0x1733] = 0;
    piVar2[0x1719] = 0;
    piVar2[0x171a] = 0;
    piVar2[0x171b] = 0;
    memcpy(piVar2 + 0x1708,(void *)(iVar1 + 0x31760),0xc);
    *piVar2 = (int)(piVar2 + 4);
    piVar2[1] = (int)(piVar2 + 0x306);
    piVar2[2] = (int)(piVar2 + 0x205);
    piVar2[3] = (int)(piVar2 + 0x507);
    piVar2[0x1743] = 0;
    piVar2[0x173a] = 0;
    piVar2[0x173b] = 0;
    piVar2[0x173c] = 0;
    piVar2[0x173d] = 0;
    piVar2[0x173e] = 0;
    piVar2[0x173f] = 0;
    piVar2[0x1741] = 0x8000001;
    piVar3 = piVar2;
  }
  return piVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000318fc FUN_000318fc */

undefined4 FUN_000318fc(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  piVar2 = (int *)(param_1 + 0x5cec);
  puVar4 = (undefined4 *)*piVar2;
  puVar3 = (undefined4 *)0x0;
  *(undefined4 *)(param_1 + 0x5cf4) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d14) = 0;
  *(undefined4 *)(param_1 + 0x5d1c) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  if (puVar4 != (undefined4 *)0x0) {
    uVar5 = puVar4[0x170c];
    uVar7 = puVar4[0x170d];
    uVar6 = puVar4[0x170e];
    FUN_0003a514(*puVar4,uVar5,uVar7,uVar6);
    FUN_0003a514(puVar4,uVar5,uVar7,uVar6);
  }
  if ((param_2 != 0) && (7 < param_3)) {
    puVar3 = (undefined4 *)FUN_0003a4a8(0x5c3c,0,0,0);
    if (puVar3 != (undefined4 *)0x0) {
      puVar3[0x170c] = 0;
      puVar3[0x170d] = 0;
      puVar3[0x170e] = 0;
      uVar1 = FUN_00031284(puVar3,param_2,param_3,0);
      if (uVar1 < 0xffffff89) goto LAB_000319e4;
      uVar5 = puVar3[0x170d];
      uVar6 = puVar3[0x170e];
      uVar7 = puVar3[0x170c];
      FUN_0003a514(*puVar3,uVar7,uVar5,uVar6);
      FUN_0003a514(puVar3,uVar7,uVar5,uVar6);
    }
    *piVar2 = 0;
    return 0xffffffc0;
  }
LAB_000319e4:
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  *(undefined4 *)(param_1 + 0x5d2c) = 0;
  *piVar2 = (int)puVar3;
  *(undefined4 **)(param_1 + 0x5cf0) = puVar3;
  return 5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031a44 FUN_00031a44 */

undefined4 FUN_00031a44(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(undefined4 *)(param_1 + 0x5cec);
  *(undefined4 *)(param_1 + 0x5cf4) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d14) = 0;
  *(undefined4 *)(param_1 + 0x5d1c) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = puVar1[0x170d];
    uVar3 = puVar1[0x170e];
    uVar4 = puVar1[0x170c];
    FUN_0003a514(*puVar1,uVar4,uVar2,uVar3);
    FUN_0003a514(puVar1,uVar4,uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  *(undefined4 *)(param_1 + 0x5d2c) = 0;
  *(undefined4 *)(param_1 + 0x5cec) = 0;
  *(undefined4 *)(param_1 + 0x5cf0) = 0;
  return 5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031acc FUN_00031acc */

undefined4 FUN_00031acc(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(undefined4 *)(param_1 + 0x5cec);
  *(undefined4 *)(param_1 + 0x5cf4) = 1;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d14) = 0;
  *(undefined4 *)(param_1 + 0x5d1c) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = puVar1[0x170c];
    uVar4 = puVar1[0x170d];
    uVar3 = puVar1[0x170e];
    FUN_0003a514(*puVar1,uVar2,uVar4,uVar3);
    FUN_0003a514(puVar1,uVar2,uVar4,uVar3);
  }
  *(undefined4 *)(param_1 + 0x5d28) = 0;
  *(undefined4 *)(param_1 + 0x5d2c) = 0;
  *(undefined4 *)(param_1 + 0x5cec) = 0;
  *(undefined4 *)(param_1 + 0x5cf0) = param_2;
  return 5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031c30 FUN_00031c30 */

undefined * FUN_00031c30(undefined4 param_1,undefined4 param_2)

{
  undefined *puVar1;
  undefined *puVar2;
  uint uVar3;
  undefined auStack_28 [8];
  uint local_20;
  int local_1c;
  
  puVar1 = (undefined *)FUN_0002ea08(auStack_28,param_1,param_2);
  puVar2 = puVar1;
  if ((puVar1 < (undefined *)0xffffff89) &&
     (puVar2 = (undefined *)0xffffffb8, puVar1 == (undefined *)0x0)) {
    puVar2 = (undefined *)0xfffffff0;
    if ((uint)-local_1c < (uint)(local_20 < 0x8000001)) {
      uVar3 = local_20;
      if (0x1ffff < local_20) {
        uVar3 = 0x20000;
      }
      puVar2 = &UNK_00025d60 + local_20 + uVar3 * 2;
    }
  }
  return puVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00031c9c FUN_00031c9c */

uint FUN_00031c9c(int *param_1,int *param_2,int *param_3)

{
  ushort uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  ushort *puVar6;
  int iVar7;
  int iVar8;
  uint *puVar9;
  uint *puVar10;
  void *pvVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  uint *puVar17;
  uint *puVar18;
  uint *__src;
  uint *puVar19;
  uint uVar20;
  bool bVar21;
  undefined8 uVar22;
  void *local_70;
  undefined auStack_48 [20];
  int local_34;
  int local_2c;
  
  puVar9 = (uint *)(param_1 + 0x1710);
  puVar19 = (uint *)(param_1 + 0x1712);
  puVar10 = (uint *)(param_1 + 0x974e);
  iVar2 = *param_2;
  iVar16 = param_2[1];
  pvVar11 = (void *)(iVar2 + param_2[2]);
  puVar17 = (uint *)(*param_3 + param_3[2]);
  puVar3 = (uint *)(*param_3 + param_3[1]);
  uVar4 = (int)puVar3 - (int)puVar17;
  local_70 = pvVar11;
  puVar18 = puVar17;
LAB_00031d5c:
  uVar5 = (iVar2 + iVar16) - (int)local_70;
  __src = puVar18;
LAB_00031d68:
  puVar18 = __src;
  switch(param_1[0x173d]) {
  case 0:
    iVar7 = 0;
    param_1[0x173d] = 1;
    param_1[0x1744] = 0;
    param_1[0x1745] = 0;
    param_1[0x174a] = 0;
    param_1[0x174b] = 0;
    param_1[0x1747] = 0;
    param_1[0x1740] = 0;
    break;
  case 1:
    iVar7 = param_1[0x1747];
    break;
  case 2:
    goto switchD_00031d7c_caseD_2;
  case 3:
    uVar13 = param_1[0x170f];
    goto LAB_00032144;
  case 4:
    goto switchD_00031d7c_caseD_4;
  default:
    return 0xffffffff;
  }
  uVar13 = FUN_0002ea08(puVar9,puVar10,iVar7);
  if (0xffffff88 < uVar13) {
    return uVar13;
  }
  if (uVar13 == 0) {
    bVar21 = (*puVar9 | param_1[0x1711]) == 0;
    if (!bVar21) {
      bVar21 = (*puVar19 | param_1[0x1713]) == 0;
    }
    if ((!bVar21) && ((uint)-param_1[0x1711] < (uint)(*puVar9 <= uVar5))) {
      if ((uVar4 < 8) || ((*puVar17 & 0xfffffff0) != 0x184d2a50)) {
        uVar13 = FUN_0002ea08(auStack_48,puVar17,uVar4);
        if (uVar13 < 0xffffff89) {
          if (uVar13 == 0) {
            uVar12 = uVar4 - local_34;
            puVar6 = (ushort *)((int)puVar17 + local_34);
            do {
              if (uVar12 < 3) {
LAB_0003231c:
                uVar13 = 0xffffffb8;
                if (uVar4 < 0xffffffb8) goto LAB_00031e54;
                goto LAB_00032538;
              }
              uVar1 = *puVar6;
              uVar13 = ((uint)uVar1 << 0x1d) >> 0x1e;
              if (uVar13 != 1) {
                if (uVar13 == 3) {
                  uVar13 = 0xffffffec;
                  if (uVar4 < 0xffffffec) goto LAB_00031e54;
                  goto LAB_00032538;
                }
                uVar13 = (uint)(uint3)(CONCAT12(*(undefined *)(puVar6 + 1),uVar1) >> 3);
              }
              uVar13 = uVar13 + 3;
              if (uVar12 < uVar13) goto LAB_0003231c;
              uVar12 = uVar12 - uVar13;
              puVar6 = (ushort *)((int)puVar6 + uVar13);
            } while ((uVar1 & 1) == 0);
            if (local_2c != 0) {
              uVar13 = 0xffffffb8;
              if (uVar12 < 4) goto joined_r0x00032314;
              puVar6 = puVar6 + 2;
            }
            uVar13 = (int)puVar6 - (int)puVar17;
          }
          else {
            uVar13 = 0xffffffb8;
          }
        }
      }
      else {
        uVar13 = puVar17[1] + 8;
      }
joined_r0x00032314:
      if (uVar13 <= uVar4) {
LAB_00032538:
        uVar4 = FUN_000303e8(param_1,local_70,uVar5,puVar17,uVar13,0,0,param_1[0x173c]);
        if (0xffffff88 < uVar4) {
          return uVar4;
        }
        param_1[0x170f] = 0;
        local_70 = (void *)((int)local_70 + uVar4);
        param_1[0x173d] = 0;
        puVar18 = (uint *)((int)puVar17 + uVar13);
        goto LAB_00032454;
      }
    }
LAB_00031e54:
    iVar7 = param_1[0x173c];
    param_1[0x170b] = 0;
    param_1[0x170c] = 0;
    param_1[0x170d] = 0;
    param_1[0x170e] = 0;
    param_1[0x170f] = 5;
    param_1[0x507] = 0xc00000c;
    param_1[0x1733] = 0;
    param_1[0x1719] = 0;
    param_1[0x171a] = 0;
    param_1[0x171b] = 0;
    memcpy(param_1 + 0x1708,(void *)(DAT_000325a0 + 0x31ea8),0xc);
    *param_1 = (int)(param_1 + 4);
    param_1[1] = (int)(param_1 + 0x306);
    param_1[2] = (int)(param_1 + 0x205);
    param_1[3] = (int)(param_1 + 0x507);
    if (iVar7 != 0) {
      param_1[0x1733] = *(int *)(iVar7 + 0x5c28);
      iVar8 = *(int *)(iVar7 + 4);
      param_1[0x170d] = iVar8;
      param_1[0x170c] = iVar8;
      iVar8 = iVar8 + *(int *)(iVar7 + 8);
      param_1[0x170b] = iVar8;
      param_1[0x170e] = iVar8;
      if (*(int *)(iVar7 + 0x5c2c) == 0) {
        param_1[0x171a] = 0;
        param_1[0x171b] = 0;
      }
      else {
        param_1[0x171a] = 1;
        param_1[0x171b] = 1;
        *param_1 = iVar7 + 0xc;
        param_1[1] = iVar7 + 0xc14;
        param_1[2] = iVar7 + 0x810;
        param_1[3] = iVar7 + 0x1418;
        param_1[0x1708] = *(int *)(iVar7 + 0x5c1c);
        param_1[0x1709] = *(int *)(iVar7 + 0x5c20);
        param_1[0x170a] = *(int *)(iVar7 + 0x5c24);
      }
    }
    if ((*puVar10 & 0xfffffff0) == 0x184d2a50) {
      iVar14 = param_1[0x974f];
      iVar8 = 7;
    }
    else {
      uVar22 = FUN_0002ea08(puVar9,puVar10,param_1[0x1747]);
      iVar7 = (int)((ulonglong)uVar22 >> 0x20);
      uVar13 = (uint)uVar22;
      if (0xffffff88 < uVar13) {
        return uVar13;
      }
      if (uVar13 != 0) {
        return 0xffffffb8;
      }
      iVar8 = param_1[0x1716];
      if (iVar8 != 0) {
        iVar7 = param_1[0x1733];
      }
      if (iVar8 != 0 && iVar7 != iVar8) {
        return 0xffffffe0;
      }
      iVar8 = 2;
      iVar14 = 3;
      if (param_1[0x1717] != 0) {
        FUN_00039660(param_1 + 0x171c,iVar7,0,0);
      }
    }
    param_1[0x170f] = iVar14;
    uVar13 = *puVar19;
    uVar12 = param_1[0x1713];
    param_1[0x1719] = iVar8;
    if (-uVar12 < (uint)(uVar13 < 0x401)) {
      uVar13 = 0x400;
      uVar12 = 0;
    }
    *puVar19 = uVar13;
    param_1[0x1713] = uVar12;
    if ((uint)(uVar13 <= (uint)param_1[0x1741]) <= -uVar12) {
      return 0xfffffff0;
    }
    uVar20 = uVar13;
    if (uVar12 != 0 || uVar12 < (0x1ffff < uVar13)) {
      uVar20 = 0x20000;
    }
    uVar13 = uVar13 + uVar20;
    param_1[0x1746] = uVar20;
    uVar12 = uVar13 + 0x10;
    if (uVar20 <= (uint)param_1[0x173f]) {
      uVar13 = param_1[0x1743];
    }
    if (uVar20 > (uint)param_1[0x173f] || uVar13 < uVar12) {
      if (param_1[0x173a] == 0) {
        FUN_0003a514(param_1[0x173e],param_1[0x1735],param_1[0x1736],param_1[0x1737]);
        param_1[0x1743] = 0;
        param_1[0x173f] = 0;
        iVar7 = FUN_0003a4a8(uVar12 + uVar20,param_1[0x1735],param_1[0x1736],param_1[0x1737]);
        param_1[0x173e] = iVar7;
        if (iVar7 == 0) {
          return 0xffffffc0;
        }
      }
      else {
        if (param_1[0x173a] - 0x25d50U < uVar12 + uVar20) {
          return 0xffffffc0;
        }
        iVar7 = param_1[0x173e];
      }
      param_1[0x1742] = iVar7 + uVar20;
      param_1[0x1743] = uVar12;
      param_1[0x173f] = uVar20;
    }
    param_1[0x173d] = 2;
switchD_00031d7c_caseD_2:
    uVar13 = param_1[0x170f];
    if (uVar13 == 0) {
      param_1[0x173d] = 0;
      goto LAB_00032454;
    }
    if ((uint)((int)puVar3 - (int)__src) < uVar13) {
      puVar18 = puVar3;
      if (__src == puVar3) goto LAB_00032454;
      param_1[0x173d] = 3;
LAB_00032144:
      iVar7 = param_1[0x1740];
      uVar12 = uVar13 - iVar7;
      if ((uint)(param_1[0x173f] - iVar7) < uVar12) {
        return 0xffffffec;
      }
      uVar15 = (int)puVar3 - (int)__src;
      uVar20 = uVar15;
      if (uVar12 < uVar15) {
        uVar20 = uVar12;
      }
      memcpy((void *)(param_1[0x173e] + iVar7),__src,uVar20);
      puVar18 = (uint *)((int)__src + uVar20);
      param_1[0x1740] = param_1[0x1740] + uVar20;
      if (uVar15 < uVar12) goto LAB_00032454;
      iVar7 = param_1[0x1719];
      uVar13 = FUN_00030b0c(param_1,param_1[0x1742] + param_1[0x1744],
                            param_1[0x1743] - param_1[0x1744],param_1[0x173e],uVar13);
      if (0xffffff88 < uVar13) {
        return uVar13;
      }
      param_1[0x1740] = 0;
      uVar12 = uVar13;
      if (iVar7 == 7) {
        uVar12 = uVar13 | 1;
      }
      if (uVar12 != 0) {
        iVar7 = param_1[0x1744];
        param_1[0x173d] = 4;
        iVar8 = iVar7 + uVar13;
        param_1[0x1745] = iVar8;
        goto LAB_0003235c;
      }
      param_1[0x173d] = 2;
      __src = puVar18;
    }
    else {
      iVar8 = param_1[0x1719];
      iVar7 = 0;
      if (iVar8 != 7) {
        iVar7 = param_1[0x1743];
      }
      if (iVar8 != 7) {
        iVar7 = iVar7 - param_1[0x1744];
      }
      uVar12 = FUN_00030b0c(param_1,param_1[0x1742] + param_1[0x1744],iVar7,__src,uVar13);
      if (0xffffff88 < uVar12) {
        return uVar12;
      }
      __src = (uint *)((int)__src + uVar13);
      if ((uVar12 | iVar8 == 7) != 0) {
        param_1[0x173d] = 4;
        param_1[0x1745] = param_1[0x1744] + uVar12;
      }
    }
  }
  else {
    iVar7 = param_1[0x1747];
    uVar12 = (int)puVar3 - (int)__src;
    uVar20 = uVar13 - iVar7;
    if (uVar12 < uVar20) {
      if (0 < (int)uVar12) {
        memcpy(&UNK_00025d38 + (int)param_1 + iVar7,__src,uVar12);
        iVar7 = param_1[0x1747] + uVar12;
        param_1[0x1747] = iVar7;
      }
      if (uVar13 < 7) {
        uVar13 = 6;
      }
      param_3[2] = param_3[1];
      return (uVar13 - iVar7) + 3;
    }
    memcpy(&UNK_00025d38 + (int)param_1 + iVar7,__src,uVar20);
    __src = (uint *)((int)__src + uVar20);
    param_1[0x1747] = uVar13;
  }
  goto LAB_00031d68;
switchD_00031d7c_caseD_4:
  iVar7 = param_1[0x1744];
  iVar8 = param_1[0x1745];
LAB_0003235c:
  uVar12 = iVar8 - iVar7;
  uVar13 = uVar12;
  if (uVar5 < uVar12) {
    uVar13 = uVar5;
  }
  memcpy(local_70,(void *)(param_1[0x1742] + iVar7),uVar13);
  iVar7 = param_1[0x1744];
  local_70 = (void *)((int)local_70 + uVar13);
  param_1[0x1744] = iVar7 + uVar13;
  if (uVar5 < uVar12) {
LAB_00032454:
    uVar4 = (int)puVar18 + (param_3[2] - (int)puVar17);
    param_3[2] = uVar4;
    param_2[2] = (int)local_70 + (param_2[2] - (int)pvVar11);
    uVar5 = param_1[0x170f];
    if (uVar5 != 0) {
      if (param_1[0x1719] == 3) {
        uVar5 = uVar5 + 3;
      }
      uVar4 = uVar5 - param_1[0x1740];
      if (uVar5 < (uint)param_1[0x1740]) {
        uVar4 = 0xffffffff;
      }
      return uVar4;
    }
    if (param_1[0x1745] == param_1[0x1744]) {
      uVar5 = 0;
      if (param_1[0x174b] != 0) {
        if (uVar4 < (uint)param_3[1]) {
          param_3[2] = uVar4 + 1;
        }
        else {
          uVar5 = 1;
          param_1[0x173d] = 2;
        }
      }
    }
    else {
      uVar5 = 1;
      if (param_1[0x174b] == 0) {
        uVar5 = 1;
        param_3[2] = uVar4 - 1;
        param_1[0x174b] = 1;
      }
    }
    return uVar5;
  }
  param_1[0x173d] = 2;
  if ((uint)param_1[0x1743] < param_1[0x1746] + iVar7 + uVar13) {
    param_1[0x1744] = 0;
    param_1[0x1745] = 0;
  }
  goto LAB_00031d5c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000325a4 FUN_000325a4 */

int FUN_000325a4(undefined *param_1,undefined *param_2,int param_3,size_t param_4,uint param_5,
                undefined4 param_6,int *param_7,undefined *param_8,undefined *param_9,int param_10,
                uint param_11)

{
  undefined uVar1;
  void *__src;
  int iVar2;
  undefined *puVar3;
  undefined *puVar4;
  undefined *__dest;
  undefined *puVar5;
  int iVar6;
  
  iVar6 = param_3 + param_4;
  puVar3 = param_1 + iVar6;
  iVar2 = -0x46;
  if (puVar3 <= param_2) {
    puVar4 = (undefined *)*param_7;
    iVar2 = -0x14;
    if (puVar4 + param_3 <= param_8) {
      puVar5 = param_1 + param_3;
      param_2 = param_2 + -8;
      iVar2 = -1;
      if (param_2 < puVar5) {
        __dest = param_1;
        if (param_1 < param_2) {
          do {
            memcpy(__dest,puVar4,8);
            __dest = __dest + 8;
            puVar4 = puVar4 + 8;
          } while (__dest < param_2);
          puVar4 = param_2 + (*param_7 - (int)param_1);
          *param_7 = (int)puVar4;
          param_1 = param_2;
        }
        if (param_1 < puVar5) {
          *param_7 = (int)(puVar4 + 1);
          uVar1 = *puVar4;
          puVar4 = param_1;
          while( true ) {
            param_1 = puVar4 + 1;
            *puVar4 = uVar1;
            if (puVar5 <= param_1) break;
            puVar4 = (undefined *)*param_7;
            *param_7 = (int)(puVar4 + 1);
            uVar1 = *puVar4;
            puVar4 = param_1;
          }
        }
        puVar4 = puVar5 + -param_5;
        if ((uint)((int)puVar5 - (int)param_9) < param_5) {
          if ((uint)((int)puVar5 - param_10) < param_5) {
            return -0x14;
          }
          iVar2 = (int)puVar4 - (int)param_9;
          __src = (void *)(param_11 + iVar2);
          if ((int)__src + param_4 <= param_11) {
            memmove(puVar5,__src,param_4);
            return iVar6;
          }
          memmove(puVar5,__src,-iVar2);
          param_1 = puVar5 + -iVar2;
          puVar4 = param_9;
        }
        iVar2 = iVar6;
        if (param_1 < puVar3) {
          do {
            puVar5 = param_1 + 1;
            *param_1 = *puVar4;
            param_1 = puVar5;
            puVar4 = puVar4 + 1;
          } while (puVar3 != puVar5);
        }
      }
    }
  }
  return iVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032720 FUN_00032720 */

int FUN_00032720(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  uint *puVar7;
  bool bVar8;
  bool bVar9;
  undefined auStack_92 [106];
  uint uStack_28;
  undefined4 local_24;
  
  iVar6 = -0x1e;
  if (8 < param_3) {
    uVar1 = FUN_0003599c(param_1 + 0x140c,param_2 + 8,param_3 - 8,param_1 + 0x5410,0x800);
    if (uVar1 < 0xffffff89) {
      iVar4 = param_2 + 8 + uVar1;
      puVar7 = (uint *)(param_2 + param_3);
      local_24 = 0x1c;
      uVar1 = FUN_00033888(auStack_92,&local_24,&uStack_28,iVar4,(int)puVar7 - iVar4);
      bVar8 = 0xffffff87 < uVar1;
      if (uVar1 < 0xffffff89) {
        bVar8 = 8 < uStack_28;
      }
      if ((!bVar8) &&
         (uVar2 = FUN_00032918(param_1 + 0x804,auStack_92,local_24), uVar2 < 0xffffff89)) {
        iVar4 = iVar4 + uVar1;
        local_24 = 0x34;
        uVar1 = FUN_00033888(auStack_92,&local_24,&uStack_28,iVar4,(int)puVar7 - iVar4);
        bVar8 = 0xffffff87 < uVar1;
        if (uVar1 < 0xffffff89) {
          bVar8 = 9 < uStack_28;
        }
        if ((!bVar8) &&
           (uVar2 = FUN_00032918(param_1 + 0xc08,auStack_92,local_24), uVar2 < 0xffffff89)) {
          puVar5 = (uint *)(iVar4 + uVar1);
          local_24 = 0x23;
          uVar1 = FUN_00033888(auStack_92,&local_24,&uStack_28,puVar5,(int)puVar7 - (int)puVar5);
          bVar8 = 0xffffff87 < uVar1;
          if (uVar1 < 0xffffff89) {
            bVar8 = 9 < uStack_28;
          }
          if (!bVar8) {
            puVar3 = (uint *)FUN_00032918(param_1,auStack_92,local_24);
            if (puVar3 < (uint *)0xffffff89) {
              puVar5 = (uint *)((int)puVar5 + uVar1);
            }
            bVar9 = (uint *)0xffffff87 < puVar3;
            bVar8 = puVar3 == (uint *)0xffffff88;
            if (puVar3 < (uint *)0xffffff89) {
              puVar3 = puVar5 + 3;
              bVar9 = puVar7 <= puVar3;
              bVar8 = puVar3 == puVar7;
            }
            if (((!bVar9 || bVar8) && (uVar1 = *puVar5, uVar1 != 0)) &&
               (uVar2 = (int)puVar7 - (int)puVar3, uVar1 < uVar2)) {
              *(uint *)(param_1 + 0x5c10) = uVar1;
              uVar1 = puVar5[1];
              if ((uVar1 != 0) && (uVar1 < uVar2)) {
                *(uint *)(param_1 + 0x5c14) = uVar1;
                uVar1 = puVar5[2];
                if ((uVar1 != 0) && (uVar1 < uVar2)) {
                  *(uint *)(param_1 + 0x5c18) = uVar1;
                  iVar6 = (int)puVar5 + (0xc - param_2);
                }
              }
            }
          }
        }
      }
    }
  }
  return iVar6;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032918 FUN_00032918 */

undefined4 FUN_00032918(void *param_1,ushort *param_2,uint param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  ushort *puVar3;
  ushort *puVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  ushort uVar8;
  int iVar9;
  short *psVar10;
  int iVar11;
  bool bVar12;
  bool bVar13;
  undefined2 local_22c;
  undefined2 local_22a;
  ushort auStack_228 [258];
  
  uVar6 = 0xffffffd2;
  bVar13 = 0xfe < param_3;
  bVar12 = param_3 == 0xff;
  if (param_3 < 0x100) {
    uVar6 = 0xffffffd4;
    bVar13 = 0xb < param_4;
    bVar12 = param_4 == 0xc;
  }
  if (!bVar13 || bVar12) {
    psVar10 = (short *)((int)param_1 + 4);
    uVar1 = 1 << (param_4 & 0xff);
    local_22a = 1;
    local_22c = (undefined2)param_4;
    if (param_3 == 0xffffffff) {
      memcpy(param_1,&local_22c,4);
    }
    else {
      uVar7 = (1 << (param_4 & 0xff)) - 1;
      iVar11 = 0;
      puVar3 = param_2;
      puVar4 = auStack_228;
      uVar5 = uVar7;
      do {
        uVar8 = *puVar3;
        if (uVar8 == 0xffff) {
          *(char *)(psVar10 + uVar5 * 2 + 1) = (char)iVar11;
          uVar8 = 1;
          uVar5 = uVar5 - 1;
        }
        else if ((0x10000 << (param_4 - 1 & 0xff)) >> 0x10 <= (int)(short)uVar8) {
          local_22a = 0;
        }
        *puVar4 = uVar8;
        puVar3 = puVar3 + 1;
        iVar11 = iVar11 + 1;
        puVar4 = puVar4 + 1;
      } while (param_3 + 1 != iVar11);
      memcpy(param_1,&local_22c,4);
      if (param_3 != 0xffffffff) {
        iVar11 = 0;
        uVar2 = 0;
        do {
          uVar8 = param_2[iVar11];
          if (0 < (short)uVar8) {
            iVar9 = 0;
            do {
              *(char *)(psVar10 + uVar2 * 2 + 1) = (char)iVar11;
              do {
                uVar2 = (uVar1 >> 3) + (uVar1 >> 1) + 3 + uVar2 & uVar7;
              } while (uVar5 < uVar2);
              iVar9 = iVar9 + 1;
            } while (iVar9 < (short)uVar8);
          }
          iVar11 = iVar11 + 1;
        } while (iVar11 != param_3 + 1);
        if (uVar2 != 0) {
          return 0xffffffff;
        }
      }
    }
    uVar6 = 0;
    uVar5 = 0;
    do {
      uVar5 = uVar5 + 1;
      uVar8 = auStack_228[*(byte *)(psVar10 + 1)];
      auStack_228[*(byte *)(psVar10 + 1)] = uVar8 + 1;
      uVar7 = (param_4 - 0x1f) + LZCOUNT((uint)uVar8);
      *(char *)((int)psVar10 + 3) = (char)uVar7;
      *psVar10 = (uVar8 << (uVar7 & 0xff)) - (short)uVar1;
      psVar10 = psVar10 + 2;
    } while (uVar5 < uVar1);
  }
  return uVar6;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032ae0 FUN_00032ae0 */

undefined4 FUN_00032ae0(undefined4 *param_1,undefined param_2)

{
  *(undefined *)((int)param_1 + 7) = 0;
  *(undefined *)((int)param_1 + 6) = param_2;
  *(undefined2 *)(param_1 + 1) = 0;
  *param_1 = 0;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00032b44 FUN_00032b44 */

undefined *
FUN_00032b44(undefined *param_1,int param_2,uint *param_3,undefined *param_4,ushort *param_5)

{
  byte bVar1;
  byte bVar2;
  ushort uVar3;
  ushort uVar4;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  ushort *puVar8;
  uint *puVar9;
  int iVar10;
  uint uVar11;
  undefined *puVar12;
  uint uVar13;
  uint *puVar14;
  undefined *puVar15;
  uint uVar16;
  undefined *puVar17;
  bool bVar18;
  uint local_38 [2];
  uint *local_30;
  
  puVar15 = param_1;
  local_30 = param_3;
  if (param_5[1] == 0) {
    if (param_4 == (undefined *)0x0) goto LAB_00032c20;
    puVar14 = param_3 + 1;
    if (param_4 < (undefined *)0x4) {
      local_38[0] = (uint)*(byte *)param_3;
      if (param_4 == (undefined *)0x2) {
LAB_00032cf8:
        local_38[0] = local_38[0] + (uint)*(byte *)((int)param_3 + 1) * 0x100;
      }
      else if (param_4 == (undefined *)0x3) {
        local_38[0] = local_38[0] | (uint)*(byte *)((int)param_3 + 2) << 0x10;
        goto LAB_00032cf8;
      }
      if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
        return (undefined *)0xffffffec;
      }
      puVar12 = (undefined *)0x0;
      uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) + (int)param_4 * -8 + 9;
    }
    else {
      puVar12 = param_4 + -4;
      local_30 = (uint *)((int)param_3 + (int)puVar12);
      local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
      if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
        return (undefined *)0xffffffff;
      }
      uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) - 0x17;
      if ((undefined *)0xffffff88 < param_4) {
        return param_4;
      }
    }
    uVar13 = (uint)*param_5;
    uVar5 = uVar11 + uVar13;
    uVar16 = 0x1f - uVar13 & 0x1f;
    uVar11 = ((local_38[0] << (uVar11 & 0x1f)) >> 1) >> uVar16;
    if (uVar5 < 0x21) {
      if ((int)puVar12 < 4) {
        if (puVar12 == (undefined *)0x0) {
          puVar12 = (undefined *)0x0;
          goto LAB_00032ec4;
        }
        puVar17 = puVar12;
        if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar5 >> 3)))) {
          puVar17 = (undefined *)(uVar5 >> 3);
        }
        uVar7 = uVar5 + (int)puVar17 * -8;
      }
      else {
        uVar7 = uVar5 & 7;
        puVar17 = (undefined *)(uVar5 >> 3);
      }
      puVar12 = puVar12 + -(int)puVar17;
      local_30 = (uint *)((int)param_3 + (int)puVar12);
      local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
      uVar5 = uVar7;
    }
LAB_00032ec4:
    uVar13 = uVar5 + uVar13;
    uVar5 = ((local_38[0] << (uVar5 & 0x1f)) >> 1) >> uVar16;
    if (uVar13 < 0x21) {
      if (3 < (int)puVar12) {
        local_30 = (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
        local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
        uVar13 = uVar13 & 7;
LAB_0003331c:
        puVar17 = param_1 + 2;
        puVar12 = param_1;
        if (local_30 < puVar14) goto LAB_00033340;
        do {
          puVar6 = (uint *)((int)local_30 - (uVar13 >> 3));
          uVar13 = uVar13 & 7;
          bVar18 = false;
          while( true ) {
            puVar15 = puVar17 + -2;
            local_38[0] = *puVar6;
            local_30 = puVar6;
            if ((param_1 + param_2 + -3 <= puVar15) || (bVar18)) goto LAB_00032ef8;
            puVar8 = param_5 + uVar11 * 2 + 2;
            uVar4 = *puVar8;
            bVar2 = *(byte *)((int)puVar8 + 3);
            uVar16 = uVar13 + bVar2;
            puVar17[-2] = *(undefined *)(puVar8 + 1);
            puVar8 = param_5 + uVar5 * 2 + 2;
            uVar3 = *puVar8;
            uVar11 = uVar13 & 0x1f;
            bVar1 = *(byte *)((int)puVar8 + 3);
            uVar13 = uVar16 + bVar1;
            puVar17[-1] = *(undefined *)(puVar8 + 1);
            uVar11 = (uint)uVar4 + (((local_38[0] << uVar11) >> 1) >> (0x1f - bVar2 & 0x1f));
            uVar5 = (uint)uVar3 + (((local_38[0] << (uVar16 & 0x1f)) >> 1) >> (0x1f - bVar1 & 0x1f))
            ;
            puVar15 = puVar17;
            if (0x20 < uVar13) goto LAB_00032ef8;
            if (puVar6 < puVar14) {
              if (puVar6 == param_3) goto LAB_00032ef8;
              puVar9 = (uint *)((int)puVar6 - (uVar13 >> 3));
              uVar16 = uVar13 >> 3;
              if (puVar9 < param_3) {
                uVar16 = (int)puVar6 - (int)param_3;
              }
              local_30 = (uint *)((int)puVar6 - uVar16);
              uVar13 = uVar13 + uVar16 * -8;
              local_38[0] = *(uint *)((int)puVar6 - uVar16);
              uVar16 = uVar13;
              if (puVar9 < param_3) goto LAB_00032ef8;
            }
            else {
              uVar16 = uVar13 & 7;
              local_30 = (uint *)((int)puVar6 - (uVar13 >> 3));
              local_38[0] = *(uint *)((int)puVar6 - (uVar13 >> 3));
            }
            puVar8 = param_5 + uVar11 * 2 + 2;
            uVar4 = *puVar8;
            bVar2 = *(byte *)((int)puVar8 + 3);
            uVar7 = uVar16 + bVar2;
            *puVar17 = *(undefined *)(puVar8 + 1);
            puVar8 = param_5 + uVar5 * 2 + 2;
            uVar3 = *puVar8;
            bVar1 = *(byte *)((int)puVar8 + 3);
            uVar13 = uVar7 + bVar1;
            puVar17[1] = *(undefined *)(puVar8 + 1);
            uVar11 = (uint)uVar4 +
                     (((local_38[0] << (uVar16 & 0x1f)) >> 1) >> (0x1f - bVar2 & 0x1f));
            uVar5 = (uint)uVar3 + (((local_38[0] << (uVar7 & 0x1f)) >> 1) >> (0x1f - bVar1 & 0x1f));
            if (0x20 < uVar13) {
              puVar15 = puVar17 + 2;
              goto LAB_00032ef8;
            }
            puVar12 = puVar12 + 4;
            puVar17 = puVar17 + 4;
            if (puVar14 <= local_30) break;
LAB_00033340:
            puVar15 = puVar12;
            if (local_30 == param_3) goto LAB_00032ef8;
            uVar16 = uVar13 >> 3;
            bVar18 = (uint *)((int)local_30 - (uVar13 >> 3)) < param_3;
            if (bVar18) {
              uVar16 = (int)local_30 - (int)param_3;
            }
            puVar6 = (uint *)((int)local_30 - uVar16);
            uVar13 = uVar13 + uVar16 * -8;
          }
        } while( true );
      }
      if (puVar12 == (undefined *)0x0) goto LAB_0003331c;
      puVar17 = puVar12;
      if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)))) {
        puVar17 = (undefined *)(uVar13 >> 3);
      }
      local_30 = (uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
      uVar13 = uVar13 + (int)puVar17 * -8;
      local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
      if (uVar13 < 0x21) goto LAB_0003331c;
    }
LAB_00032ef8:
    uVar16 = local_38[0];
    while( true ) {
      if (param_1 + param_2 + -2 < puVar15) {
        return (undefined *)0xffffffba;
      }
      puVar8 = param_5 + uVar11 * 2 + 2;
      uVar4 = *puVar8;
      bVar2 = *(byte *)((int)puVar8 + 3);
      uVar7 = uVar13 + bVar2;
      *puVar15 = *(undefined *)(puVar8 + 1);
      if (0x20 < uVar7) break;
      if (local_30 < puVar14) {
        local_38[0] = uVar16;
        if (local_30 != param_3) {
          uVar11 = uVar7 >> 3;
          if ((uint *)((int)local_30 - (uVar7 >> 3)) < param_3) {
            uVar11 = (int)local_30 - (int)param_3;
          }
          uVar7 = uVar7 + uVar11 * -8;
          goto LAB_00032f88;
        }
      }
      else {
        uVar11 = uVar7 >> 3;
        uVar7 = uVar7 & 7;
LAB_00032f88:
        local_30 = (uint *)((int)local_30 - uVar11);
        local_38[0] = *local_30;
      }
      if (param_1 + param_2 + -2 < puVar15 + 1) {
        return (undefined *)0xffffffba;
      }
      uVar11 = (uint)uVar4 + (((uVar16 << (uVar13 & 0x1f)) >> 1) >> (0x1f - bVar2 & 0x1f));
      puVar8 = param_5 + uVar5 * 2 + 2;
      uVar4 = *puVar8;
      bVar2 = *(byte *)((int)puVar8 + 3);
      uVar13 = uVar7 + bVar2;
      puVar15[1] = *(undefined *)(puVar8 + 1);
      if (0x20 < uVar13) {
        puVar12 = puVar15 + 2;
        iVar10 = 3;
        uVar5 = uVar11;
        goto LAB_00033300;
      }
      uVar5 = local_38[0] << (uVar7 & 0x1f);
      puVar15 = puVar15 + 2;
      if (local_30 < puVar14) {
        if (local_30 != param_3) {
          uVar16 = uVar13 >> 3;
          if ((uint *)((int)local_30 - (uVar13 >> 3)) < param_3) {
            uVar16 = (int)local_30 - (int)param_3;
          }
          uVar13 = uVar13 + uVar16 * -8;
          goto LAB_00033050;
        }
      }
      else {
        uVar16 = uVar13 >> 3;
        uVar13 = uVar13 & 7;
LAB_00033050:
        local_30 = (uint *)((int)local_30 - uVar16);
        local_38[0] = *local_30;
      }
      uVar5 = (uint)uVar4 + ((uVar5 >> 1) >> (0x1f - bVar2 & 0x1f));
      uVar16 = local_38[0];
    }
    puVar12 = puVar15 + 1;
    iVar10 = 2;
LAB_00033300:
    param_5 = param_5 + uVar5 * 2 + 2;
    goto LAB_000336e8;
  }
  if (param_4 == (undefined *)0x0) {
LAB_00032c20:
    memset(local_38,0,0x14);
    return (undefined *)0xffffffb8;
  }
  puVar14 = param_3 + 1;
  if (param_4 < (undefined *)0x4) {
    local_38[0] = (uint)*(byte *)param_3;
    if (param_4 == (undefined *)0x2) {
LAB_00032c60:
      local_38[0] = local_38[0] + (uint)*(byte *)((int)param_3 + 1) * 0x100;
    }
    else if (param_4 == (undefined *)0x3) {
      local_38[0] = local_38[0] | (uint)*(byte *)((int)param_3 + 2) << 0x10;
      goto LAB_00032c60;
    }
    if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
      return (undefined *)0xffffffec;
    }
    puVar12 = (undefined *)0x0;
    uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) + (int)param_4 * -8 + 9;
  }
  else {
    puVar12 = param_4 + -4;
    local_30 = (uint *)((int)param_3 + (int)puVar12);
    local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
    if (*(byte *)((int)param_3 + (int)(param_4 + -1)) == 0) {
      return (undefined *)0xffffffff;
    }
    uVar11 = LZCOUNT((uint)*(byte *)((int)param_3 + (int)(param_4 + -1))) - 0x17;
    if ((undefined *)0xffffff88 < param_4) {
      return param_4;
    }
  }
  uVar13 = (uint)*param_5;
  uVar5 = uVar11 + uVar13;
  uVar16 = 0x1f - uVar13 & 0x1f;
  uVar11 = ((local_38[0] << (uVar11 & 0x1f)) >> 1) >> uVar16;
  if (uVar5 < 0x21) {
    if ((int)puVar12 < 4) {
      if (puVar12 == (undefined *)0x0) {
        puVar12 = (undefined *)0x0;
        goto LAB_00032e0c;
      }
      puVar17 = puVar12;
      if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar5 >> 3)))) {
        puVar17 = (undefined *)(uVar5 >> 3);
      }
      uVar7 = uVar5 + (int)puVar17 * -8;
    }
    else {
      uVar7 = uVar5 & 7;
      puVar17 = (undefined *)(uVar5 >> 3);
    }
    puVar12 = puVar12 + -(int)puVar17;
    local_30 = (uint *)((int)param_3 + (int)puVar12);
    local_38[0] = *(uint *)((int)param_3 + (int)puVar12);
    uVar5 = uVar7;
  }
LAB_00032e0c:
  uVar13 = uVar5 + uVar13;
  uVar5 = ((local_38[0] << (uVar5 & 0x1f)) >> 1) >> uVar16;
  if (uVar13 < 0x21) {
    if (3 < (int)puVar12) {
      local_30 = (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
      local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)));
      uVar13 = uVar13 & 7;
LAB_000330e4:
      puVar17 = param_1 + 2;
      puVar12 = param_1;
      if (local_30 < puVar14) goto LAB_00033108;
      do {
        puVar6 = (uint *)((int)local_30 - (uVar13 >> 3));
        uVar13 = uVar13 & 7;
        bVar18 = false;
        while( true ) {
          puVar15 = puVar17 + -2;
          local_38[0] = *puVar6;
          local_30 = puVar6;
          if ((param_1 + param_2 + -3 <= puVar15) || (bVar18)) goto LAB_00033548;
          puVar8 = param_5 + uVar11 * 2 + 2;
          uVar4 = *puVar8;
          bVar2 = *(byte *)((int)puVar8 + 3);
          uVar16 = uVar13 + bVar2;
          puVar17[-2] = *(undefined *)(puVar8 + 1);
          puVar8 = param_5 + uVar5 * 2 + 2;
          uVar3 = *puVar8;
          uVar11 = uVar13 & 0x1f;
          bVar1 = *(byte *)((int)puVar8 + 3);
          uVar13 = uVar16 + bVar1;
          puVar17[-1] = *(undefined *)(puVar8 + 1);
          uVar11 = (uint)uVar4 + ((local_38[0] << uVar11) >> (-(uint)bVar2 & 0x1f));
          uVar5 = (uint)uVar3 + ((local_38[0] << (uVar16 & 0x1f)) >> (-(uint)bVar1 & 0x1f));
          puVar15 = puVar17;
          if (0x20 < uVar13) goto LAB_00033548;
          if (puVar6 < puVar14) {
            if (puVar6 == param_3) goto LAB_00033548;
            puVar9 = (uint *)((int)puVar6 - (uVar13 >> 3));
            uVar16 = uVar13 >> 3;
            if (puVar9 < param_3) {
              uVar16 = (int)puVar6 - (int)param_3;
            }
            local_30 = (uint *)((int)puVar6 - uVar16);
            uVar13 = uVar13 + uVar16 * -8;
            local_38[0] = *(uint *)((int)puVar6 - uVar16);
            uVar16 = uVar13;
            if (puVar9 < param_3) goto LAB_00033548;
          }
          else {
            uVar16 = uVar13 & 7;
            local_30 = (uint *)((int)puVar6 - (uVar13 >> 3));
            local_38[0] = *(uint *)((int)puVar6 - (uVar13 >> 3));
          }
          puVar8 = param_5 + uVar11 * 2 + 2;
          uVar4 = *puVar8;
          bVar2 = *(byte *)((int)puVar8 + 3);
          uVar7 = uVar16 + bVar2;
          *puVar17 = *(undefined *)(puVar8 + 1);
          puVar8 = param_5 + uVar5 * 2 + 2;
          uVar3 = *puVar8;
          bVar1 = *(byte *)((int)puVar8 + 3);
          uVar13 = uVar7 + bVar1;
          puVar17[1] = *(undefined *)(puVar8 + 1);
          uVar11 = (uint)uVar4 + ((local_38[0] << (uVar16 & 0x1f)) >> (-(uint)bVar2 & 0x1f));
          uVar5 = (uint)uVar3 + ((local_38[0] << (uVar7 & 0x1f)) >> (-(uint)bVar1 & 0x1f));
          if (0x20 < uVar13) {
            puVar15 = puVar17 + 2;
            goto LAB_00033548;
          }
          puVar12 = puVar12 + 4;
          puVar17 = puVar17 + 4;
          if (puVar14 <= local_30) break;
LAB_00033108:
          puVar15 = puVar12;
          if (local_30 == param_3) goto LAB_00033548;
          uVar16 = uVar13 >> 3;
          bVar18 = (uint *)((int)local_30 - (uVar13 >> 3)) < param_3;
          if (bVar18) {
            uVar16 = (int)local_30 - (int)param_3;
          }
          puVar6 = (uint *)((int)local_30 - uVar16);
          uVar13 = uVar13 + uVar16 * -8;
        }
      } while( true );
    }
    if (puVar12 == (undefined *)0x0) goto LAB_000330e4;
    puVar17 = puVar12;
    if (param_3 <= (uint *)((int)param_3 + ((int)puVar12 - (uVar13 >> 3)))) {
      puVar17 = (undefined *)(uVar13 >> 3);
    }
    local_30 = (uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
    uVar13 = uVar13 + (int)puVar17 * -8;
    local_38[0] = *(uint *)((int)param_3 + ((int)puVar12 - (int)puVar17));
    if (uVar13 < 0x21) goto LAB_000330e4;
  }
LAB_00033548:
  uVar16 = local_38[0];
  while( true ) {
    if (param_1 + param_2 + -2 < puVar15) {
      return (undefined *)0xffffffba;
    }
    puVar8 = param_5 + uVar11 * 2 + 2;
    uVar4 = *puVar8;
    bVar2 = *(byte *)((int)puVar8 + 3);
    uVar7 = uVar13 + bVar2;
    *puVar15 = *(undefined *)(puVar8 + 1);
    if (0x20 < uVar7) break;
    if (local_30 < puVar14) {
      local_38[0] = uVar16;
      if (local_30 != param_3) {
        uVar11 = uVar7 >> 3;
        if ((uint *)((int)local_30 - (uVar7 >> 3)) < param_3) {
          uVar11 = (int)local_30 - (int)param_3;
        }
        uVar7 = uVar7 + uVar11 * -8;
        goto LAB_000335dc;
      }
    }
    else {
      uVar11 = uVar7 >> 3;
      uVar7 = uVar7 & 7;
LAB_000335dc:
      local_30 = (uint *)((int)local_30 - uVar11);
      local_38[0] = *local_30;
    }
    if (param_1 + param_2 + -2 < puVar15 + 1) {
      return (undefined *)0xffffffba;
    }
    uVar11 = (uint)uVar4 + ((uVar16 << (uVar13 & 0x1f)) >> (-(uint)bVar2 & 0x1f));
    puVar8 = param_5 + uVar5 * 2 + 2;
    uVar4 = *puVar8;
    bVar2 = *(byte *)((int)puVar8 + 3);
    uVar13 = uVar7 + bVar2;
    puVar15[1] = *(undefined *)(puVar8 + 1);
    if (0x20 < uVar13) {
      puVar12 = puVar15 + 2;
      iVar10 = 3;
      param_5 = param_5 + uVar11 * 2 + 2;
      goto LAB_000336e8;
    }
    puVar15 = puVar15 + 2;
    uVar5 = local_38[0] << (uVar7 & 0x1f);
    if (local_30 < puVar14) {
      if (local_30 != param_3) {
        uVar16 = uVar13 >> 3;
        if ((uint *)((int)local_30 - (uVar13 >> 3)) < param_3) {
          uVar16 = (int)local_30 - (int)param_3;
        }
        uVar13 = uVar13 + uVar16 * -8;
        goto LAB_00033698;
      }
    }
    else {
      uVar16 = uVar13 >> 3;
      uVar13 = uVar13 & 7;
LAB_00033698:
      local_30 = (uint *)((int)local_30 - uVar16);
      local_38[0] = *local_30;
    }
    uVar5 = (uint)uVar4 + (uVar5 >> (-(uint)bVar2 & 0x1f));
    uVar16 = local_38[0];
  }
  puVar12 = puVar15 + 1;
  iVar10 = 2;
  param_5 = param_5 + uVar5 * 2 + 2;
LAB_000336e8:
  *puVar12 = *(undefined *)(param_5 + 1);
  return puVar15 + (iVar10 - (int)param_1);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033728 FUN_00033728 */

uint FUN_00033728(undefined4 param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined4 local_22c;
  uint local_228;
  undefined auStack_224 [516];
  
  local_22c = 0xff;
  uVar1 = FUN_00033888(auStack_224,&local_22c,&local_228,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_228 <= param_6) {
      uVar2 = FUN_00032918(param_5,auStack_224,local_22c);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_00032b44(param_1,param_2,param_3 + uVar1,param_4 - uVar1,param_5);
      }
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000337c0 FUN_000337c0 */

uint FUN_000337c0(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_4230 [16388];
  undefined4 local_22c;
  uint local_228;
  undefined auStack_224 [516];
  
  local_22c = 0xff;
  uVar1 = FUN_00033888(auStack_224,&local_22c,&local_228,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_228 < 0xd) {
      uVar2 = FUN_00032918(auStack_4230,auStack_224,local_22c);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_00032b44(param_1,param_2,param_3 + uVar1,param_4 - uVar1,auStack_4230);
      }
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033888 FUN_00033888 */

int FUN_00033888(int param_1,uint *param_2,uint *param_3,uint *param_4,uint param_5)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  undefined2 *puVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint *puVar10;
  uint uVar11;
  uint uVar12;
  uint *puVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint *puVar17;
  uint uVar18;
  bool bVar19;
  bool bVar20;
  
  iVar1 = -0x48;
  if (3 < param_5) {
    uVar9 = *param_4;
    iVar1 = -0x2c;
    uVar11 = uVar9 & 0xf;
    if (uVar11 + 5 < 0x10) {
      *param_3 = uVar11 + 5;
      uVar7 = 0x20 << uVar11;
      iVar1 = -0x14;
      if (1 < uVar7) {
        uVar16 = uVar7 | 1;
        puVar13 = (uint *)((int)param_4 + (param_5 - 7));
        puVar17 = (uint *)((int)param_4 + (param_5 - 4));
        uVar2 = *param_2;
        iVar1 = uVar11 + 6;
        uVar9 = uVar9 >> 4;
        uVar11 = 4;
        bVar19 = false;
        uVar12 = 0;
        puVar10 = param_4;
        do {
          uVar15 = uVar12;
          if (bVar19) {
            while ((uVar9 & 0xffff) == 0xffff) {
              if (puVar10 < (uint *)((int)param_4 + (param_5 - 5))) {
                puVar10 = (uint *)((int)puVar10 + 2);
                uVar9 = *puVar10 >> (uVar11 & 0xff);
              }
              else {
                uVar11 = uVar11 + 0x10;
                uVar9 = uVar9 >> 0x10;
              }
              uVar15 = uVar15 + 0x18;
            }
            for (uVar18 = uVar9 & 3; uVar18 == 3; uVar18 = uVar18 >> 0x1e) {
              uVar18 = uVar9 << 0x1c;
              uVar11 = uVar11 + 2;
              uVar15 = uVar15 + 3;
              uVar9 = uVar9 >> 2;
            }
            uVar14 = uVar15 + uVar18;
            if (uVar2 < uVar14) {
              return -0x30;
            }
            if (uVar12 < uVar14) {
              iVar3 = (uVar15 + uVar18) - uVar12;
              puVar6 = (undefined2 *)(param_1 + uVar12 * 2);
              do {
                *puVar6 = 0;
                iVar3 = iVar3 + -1;
                puVar6 = puVar6 + 1;
                uVar12 = uVar14;
              } while (iVar3 != 0);
            }
            uVar11 = uVar11 + 2;
            bVar20 = puVar13 <= puVar10;
            bVar19 = puVar10 == puVar13;
            iVar3 = (int)uVar11 >> 3;
            if (bVar20 && !bVar19) {
              puVar4 = (uint *)((int)puVar10 + iVar3);
              bVar20 = puVar17 <= puVar4;
              bVar19 = puVar4 == puVar17;
            }
            uVar15 = uVar12;
            if (bVar20 && !bVar19) {
              uVar9 = uVar9 >> 2;
            }
            else {
              uVar11 = uVar11 & 7;
              puVar10 = (uint *)((int)puVar10 + iVar3);
              uVar9 = *puVar10 >> uVar11;
            }
          }
          uVar18 = uVar9 & uVar7 - 1;
          uVar14 = uVar7 * 2 - 1;
          uVar12 = uVar14 - uVar16;
          if (uVar18 < uVar12) {
            iVar3 = iVar1 + -1;
          }
          else {
            uVar18 = uVar9 & uVar14;
            iVar3 = iVar1;
            if ((int)uVar7 <= (int)uVar18) {
              uVar18 = uVar18 - uVar12;
            }
          }
          iVar8 = uVar18 - 1;
          iVar5 = iVar8;
          if ((int)uVar18 < 1) {
            iVar5 = 1 - uVar18;
          }
          uVar16 = uVar16 - iVar5;
          *(short *)(param_1 + uVar15 * 2) = (short)iVar8;
          for (; (int)uVar16 < (int)uVar7; uVar7 = (int)uVar7 >> 1) {
            iVar1 = iVar1 + -1;
          }
          uVar9 = iVar3 + uVar11;
          bVar20 = puVar13 <= puVar10;
          bVar19 = puVar10 == puVar13;
          if (bVar20 && !bVar19) {
            puVar4 = (uint *)((int)puVar10 + ((int)uVar9 >> 3));
            bVar20 = puVar17 <= puVar4;
            bVar19 = puVar4 == puVar17;
          }
          if (bVar20 && !bVar19) {
            uVar11 = uVar9 + ((int)puVar17 - (int)puVar10) * -8;
            puVar10 = puVar17;
          }
          else {
            uVar11 = uVar9 & 7;
            puVar10 = (uint *)((int)puVar10 + ((int)uVar9 >> 3));
          }
          if ((int)uVar16 < 2) break;
          uVar12 = uVar15 + 1;
          bVar19 = iVar8 == 0;
          uVar9 = *puVar10 >> (uVar11 & 0x1f);
        } while (uVar12 <= uVar2);
        if (uVar16 != 1) {
          return -0x14;
        }
        iVar1 = -0x14;
        if ((int)uVar11 < 0x21) {
          *param_2 = uVar15;
          iVar1 = (int)puVar10 + (((int)(uVar11 + 7) >> 3) - (int)param_4);
        }
      }
    }
  }
  return iVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033b44 FUN_00033b44 */

uint FUN_00033b44(byte *param_1,uint param_2,void *param_3,int *param_4,uint *param_5,byte *param_6,
                 uint param_7)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_12c [264];
  
  if (param_7 == 0) {
    return 0xffffffb8;
  }
  iVar3 = (int)(char)*param_6;
  uVar8 = (uint)*param_6;
  if (iVar3 == -1 || iVar3 + 1 < 0 != SCARRY4(iVar3,1)) {
    if (param_7 <= uVar8 - 0x7e >> 1) {
      return 0xffffffb8;
    }
    uVar1 = uVar8 - 0x7f;
    if (param_2 <= uVar1) {
      return 0xffffffec;
    }
    if (uVar1 == 0) {
      memset(param_3,0,0x34);
      return 0xffffffec;
    }
    uVar8 = uVar8 - 0x7e >> 1;
    uVar5 = 0;
    do {
      pbVar4 = param_1 + uVar5;
      *pbVar4 = param_6[(uVar5 >> 1) + 1] >> 4;
      uVar6 = uVar5 >> 1;
      uVar5 = uVar5 + 2;
      pbVar4[1] = param_6[uVar6 + 1] & 0xf;
    } while (uVar5 < uVar1);
  }
  else {
    if (param_7 <= uVar8) {
      return 0xffffffb8;
    }
    uVar1 = FUN_00033728(param_1,param_2 - 1,param_6 + 1,uVar8,auStack_12c,6);
    if (0xffffff88 < uVar1) {
      return uVar1;
    }
  }
  uVar6 = 0;
  memset(param_3,0,0x34);
  uVar7 = 0xffffffec;
  pbVar4 = param_1;
  uVar5 = uVar1;
  if (uVar1 != 0) {
    do {
      uVar2 = (uint)*pbVar4;
      if (0xb < uVar2) {
        return 0xffffffec;
      }
      uVar5 = uVar5 - 1;
      *(int *)((int)param_3 + uVar2 * 4) = *(int *)((int)param_3 + uVar2 * 4) + 1;
      uVar6 = uVar6 + ((1 << *pbVar4) >> 1);
      pbVar4 = pbVar4 + 1;
    } while (uVar5 != 0);
    if ((uVar6 != 0) && (uVar6 >> 0xc == 0)) {
      *param_5 = 0x20U - LZCOUNT(uVar6);
      uVar6 = (1 << (0x20U - LZCOUNT(uVar6) & 0xff)) - uVar6;
      iVar3 = LZCOUNT(uVar6);
      if (uVar6 == 0x80000000U >> iVar3) {
        iVar3 = 0x20 - iVar3;
        param_1[uVar1] = (byte)iVar3;
        *(int *)((int)param_3 + iVar3 * 4) = *(int *)((int)param_3 + iVar3 * 4) + 1;
        if ((1 < *(uint *)((int)param_3 + 4)) && ((*(uint *)((int)param_3 + 4) & 1) == 0)) {
          uVar7 = uVar8 + 1;
          *param_4 = uVar1 + 1;
        }
      }
    }
  }
  return uVar7;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033cfc FUN_00033cfc */

uint FUN_00033cfc(void *param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  
  local_2c = 0;
  local_30 = 0;
  uVar4 = 0xffffffd4;
  if (0x13f < param_5) {
    uVar2 = FUN_00033b44(param_4 + 0x40,0x100,param_4,&local_30,&local_2c,param_2,param_3);
    uVar4 = uVar2;
    if ((uVar2 < 0xffffff89) &&
       (memcpy(&local_28,param_1,4), uVar4 = 0xffffffd4, local_2c <= (local_28 & 0xff) + 1)) {
      local_34._0_2_ = (undefined2)local_28;
      iVar8 = 0;
      local_34 = CONCAT22(local_34._2_2_,(undefined2)local_34) & 0xffff00ff;
      memcpy(param_1,&local_34,4);
      local_2c = local_2c + 1;
      if (1 < local_2c) {
        uVar4 = 1;
        do {
          iVar3 = *(int *)(param_4 + uVar4 * 4);
          uVar6 = uVar4 - 1;
          *(int *)(param_4 + uVar4 * 4) = iVar8;
          uVar4 = uVar4 + 1;
          iVar8 = iVar8 + (iVar3 << (uVar6 & 0xff));
        } while (uVar4 < local_2c);
      }
      uVar4 = uVar2;
      if (local_30 != 0) {
        uVar6 = 0;
        do {
          bVar1 = *(byte *)(param_4 + 0x40 + uVar6);
          uVar9 = (uint)bVar1;
          uVar4 = *(uint *)(param_4 + uVar9 * 4);
          iVar8 = (1 << uVar9) >> 1;
          uVar5 = uVar4 + iVar8;
          if (uVar4 < uVar5) {
            do {
              uVar7 = uVar4 + 1;
              *(byte *)((int)param_1 + uVar4 * 2 + 5) = (char)local_2c - bVar1;
              *(char *)((int)param_1 + uVar4 * 2 + 4) = (char)uVar6;
              uVar5 = *(int *)(param_4 + uVar9 * 4) + iVar8;
              uVar4 = uVar7;
            } while (uVar7 < uVar5);
          }
          uVar6 = uVar6 + 1;
          *(uint *)(param_4 + uVar9 * 4) = uVar5;
          uVar4 = uVar2;
        } while (uVar6 < local_30);
      }
    }
  }
  return uVar4;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033e4c FUN_00033e4c */

void FUN_00033e4c(void)

{
  FUN_00033cfc();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033e74 FUN_00033e74 */

undefined4
FUN_00033e74(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            void *param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  memcpy(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    return 0xffffffff;
  }
  uVar1 = FUN_00033ee0(param_1,param_2,param_3,param_4,param_5);
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00033ee0 FUN_00033ee0 */

uint FUN_00033ee0(undefined *param_1,uint param_2,uint *param_3,uint param_4,void *param_5)

{
  uint uVar1;
  undefined *puVar2;
  uint uVar3;
  uint *puVar4;
  undefined *puVar5;
  undefined *puVar6;
  bool bVar7;
  undefined4 local_34;
  uint local_30;
  uint *local_2c;
  
  memcpy(&local_34,param_5,4);
  if (param_4 == 0) {
    memset(&local_34,0,0x14);
    return 0xffffffb8;
  }
  uVar3 = (uint)local_34._2_2_;
  puVar4 = param_3 + 1;
  if (3 < param_4) {
    local_2c = (uint *)((int)param_3 + (param_4 - 4));
    local_34 = *(uint *)((int)param_3 + (param_4 - 4));
    uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
    if (uVar1 == 0) {
      return 0xffffffff;
    }
    local_30 = LZCOUNT(uVar1) - 0x17;
    if (0xffffff88 < param_4) {
      return param_4;
    }
    goto LAB_00033fd4;
  }
  local_34 = (uint)*(byte *)param_3;
  if (param_4 == 2) {
LAB_00033fa8:
    local_34 = local_34 + (uint)*(byte *)((int)param_3 + 1) * 0x100;
  }
  else if (param_4 == 3) {
    local_34 = local_34 | (uint)*(byte *)((int)param_3 + 2) << 0x10;
    goto LAB_00033fa8;
  }
  uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
  if (uVar1 == 0) {
    return 0xffffffec;
  }
  local_30 = LZCOUNT(uVar1) + param_4 * -8 + 9;
  local_2c = param_3;
LAB_00033fd4:
  puVar6 = param_1 + param_2;
  uVar3 = -uVar3 & 0x1f;
  puVar5 = param_1;
  if (local_30 < 0x21) {
    if (puVar4 <= local_2c) goto LAB_0003402c;
    do {
      puVar5 = param_1;
      if (local_2c == param_3) goto LAB_00034118;
      uVar1 = local_30 >> 3;
      bVar7 = (uint *)((int)local_2c - (local_30 >> 3)) < param_3;
      if (bVar7) {
        uVar1 = (int)local_2c - (int)param_3;
      }
      local_2c = (uint *)((int)local_2c - uVar1);
      local_30 = local_30 + uVar1 * -8;
      while( true ) {
        local_34 = *local_2c;
        if ((puVar6 + -4 < param_1) || (bVar7)) goto LAB_00034110;
        puVar5 = (undefined *)((int)param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2 + 4);
        local_30 = local_30 + (byte)puVar5[1];
        *param_1 = *puVar5;
        puVar5 = (undefined *)((int)param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2 + 4);
        local_30 = local_30 + (byte)puVar5[1];
        param_1[1] = *puVar5;
        param_1 = param_1 + 2;
        puVar5 = param_1;
        if (0x20 < local_30) goto joined_r0x0003418c;
        if (local_2c < puVar4) break;
LAB_0003402c:
        local_2c = (uint *)((int)local_2c - (local_30 >> 3));
        local_30 = local_30 & 7;
        bVar7 = false;
      }
    } while( true );
  }
joined_r0x0003418c:
  if (puVar5 < puVar6) {
    puVar2 = (undefined *)((int)param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2 + 4);
    local_30 = local_30 + (byte)puVar2[1];
    *puVar5 = *puVar2;
    while (puVar5 = puVar5 + 1, puVar5 != puVar6) {
      puVar2 = (undefined *)((int)param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2 + 4);
      local_30 = local_30 + (byte)puVar2[1];
      *puVar5 = *puVar2;
    }
  }
  if (((uint)local_2c ^ (uint)param_3 | local_30 ^ 0x20) != 0) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_00034110:
  puVar5 = param_1;
  if (0x20 < local_30) goto joined_r0x0003418c;
LAB_00034118:
  if (local_2c < puVar4) {
    if (local_2c == param_3) goto joined_r0x0003418c;
    uVar1 = local_30 >> 3;
    bVar7 = (uint *)((int)local_2c - (local_30 >> 3)) < param_3;
    if (bVar7) {
      uVar1 = (int)local_2c - (int)param_3;
    }
    local_30 = local_30 + uVar1 * -8;
  }
  else {
    uVar1 = local_30 >> 3;
    local_30 = local_30 & 7;
    bVar7 = false;
  }
  local_2c = (uint *)((int)local_2c - uVar1);
  local_34 = *local_2c;
  if ((puVar6 <= puVar5) || (bVar7)) goto joined_r0x0003418c;
  puVar2 = (undefined *)((int)param_5 + ((local_34 << (local_30 & 0x1f)) >> uVar3) * 2 + 4);
  local_30 = local_30 + (byte)puVar2[1];
  param_1 = puVar5 + 1;
  *puVar5 = *puVar2;
  goto LAB_00034110;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00034224 FUN_00034224 */

uint FUN_00034224(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_00033cfc(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00033ee0(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000342a0 FUN_000342a0 */

uint FUN_000342a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_00033cfc(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00033ee0(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00034320 FUN_00034320 */

uint FUN_00034320(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_2824;
  undefined auStack_2820 [8192];
  undefined auStack_820 [2048];
  
  __aeabi_memclr4(auStack_2820,0x2000);
  local_2824 = 0xb00000b;
  uVar1 = FUN_00033cfc(&local_2824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00033ee0(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_2824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000343bc FUN_000343bc */

undefined4
FUN_000343bc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            void *param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  memcpy(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    return 0xffffffff;
  }
  uVar1 = FUN_00034428(param_1,param_2,param_3,param_4,param_5);
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00034428 FUN_00034428 */

uint FUN_00034428(undefined *param_1,uint param_2,ushort *param_3,uint param_4,void *param_5)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  byte bVar4;
  undefined *puVar5;
  undefined *puVar6;
  undefined *puVar7;
  uint uVar8;
  undefined *puVar9;
  undefined *puVar10;
  byte bVar11;
  uint *puVar12;
  int iVar13;
  uint *puVar14;
  undefined *puVar15;
  uint *puVar16;
  undefined *puVar17;
  uint uVar18;
  uint uVar19;
  undefined *puVar20;
  undefined *puVar21;
  uint uVar22;
  uint uVar23;
  uint *puVar24;
  bool bVar25;
  byte bVar26;
  bool bVar27;
  uint local_8c;
  uint local_74;
  uint local_70;
  uint *local_6c;
  uint local_60;
  uint local_5c;
  uint *local_58;
  uint *local_54;
  uint *local_50;
  uint local_4c;
  uint local_48;
  uint *local_44;
  uint *local_40;
  uint *local_3c;
  uint local_38;
  uint local_34;
  uint *local_30;
  uint *local_2c;
  uint *local_28;
  
  if (param_4 < 10) {
    return 0xffffffec;
  }
  uVar23 = (uint)param_3[2];
  uVar22 = (uint)param_3[1];
  uVar18 = (uint)*param_3;
  memcpy(&local_38,param_5,4);
  uVar2 = uVar18 + 6 + uVar22 + uVar23;
  uVar3 = param_4 - uVar2;
  if (param_4 < uVar2) {
    return 0xffffffec;
  }
  if (uVar18 == 0) {
    puVar16 = &local_38;
    goto LAB_00034740;
  }
  uVar2 = local_38 >> 0x10;
  local_2c = (uint *)(param_3 + 3);
  local_28 = (uint *)(param_3 + 5);
  if (uVar18 < 4) {
    local_38 = (uint)*(byte *)local_2c;
    if (uVar18 == 2) {
LAB_0003451c:
      local_38 = local_38 + (uint)*(byte *)((int)param_3 + 7) * 0x100;
    }
    else if (uVar18 == 3) {
      local_38 = local_38 | (uint)*(byte *)(param_3 + 4) << 0x10;
      goto LAB_0003451c;
    }
    uVar8 = (uint)*(byte *)((int)local_2c + (uVar18 - 1));
    if (uVar8 == 0) {
      return 0xffffffec;
    }
    uVar19 = LZCOUNT(uVar8) + uVar18 * -8 + 9;
    uVar8 = 6;
    local_30 = local_2c;
  }
  else {
    uVar8 = uVar18 + 2;
    local_38 = *(uint *)((int)param_3 + uVar8);
    uVar19 = (uint)*(byte *)((int)local_2c + (uVar18 - 1));
    if (uVar19 == 0) {
      return 0xffffffff;
    }
    uVar19 = LZCOUNT(uVar19) - 0x17;
    local_30 = (uint *)((int)param_3 + uVar8);
  }
  local_34 = uVar19;
  if (uVar22 == 0) {
    puVar16 = &local_4c;
    goto LAB_00034740;
  }
  local_40 = (uint *)((int)param_3 + uVar18 + 6);
  puVar24 = (uint *)((int)local_40 + uVar22);
  local_3c = local_40 + 1;
  if (uVar22 < 4) {
    local_4c = (uint)*(byte *)local_40;
    if (uVar22 == 2) {
LAB_000345d0:
      local_4c = local_4c + (uint)*(byte *)((int)local_40 + 1) * 0x100;
    }
    else if (uVar22 == 3) {
      local_4c = local_4c | (uint)*(byte *)((int)local_40 + 2) << 0x10;
      goto LAB_000345d0;
    }
    if (*(byte *)((int)puVar24 + -1) == 0) {
      return 0xffffffec;
    }
    uVar18 = 0;
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar24 + -1)) + uVar22 * -8 + 9;
    local_44 = local_40;
  }
  else {
    uVar18 = uVar22 - 4;
    local_4c = *(uint *)((int)local_40 + uVar18);
    if (*(byte *)((int)puVar24 + -1) == 0) {
      return 0xffffffff;
    }
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar24 + -1)) - 0x17;
    local_44 = (uint *)((int)local_40 + uVar18);
  }
  if (uVar23 == 0) {
    puVar16 = &local_60;
    goto LAB_00034740;
  }
  puVar16 = (uint *)((int)puVar24 + uVar23);
  local_50 = puVar24 + 1;
  if (uVar23 < 4) {
    local_60 = (uint)*(byte *)puVar24;
    if (uVar23 == 2) {
LAB_00034694:
      local_60 = local_60 + (uint)*(byte *)((int)puVar24 + 1) * 0x100;
    }
    else if (uVar23 == 3) {
      local_60 = local_60 | (uint)*(byte *)((int)puVar24 + 2) << 0x10;
      goto LAB_00034694;
    }
    if (*(byte *)((int)puVar16 + -1) == 0) {
      return 0xffffffec;
    }
    local_5c = LZCOUNT((uint)*(byte *)((int)puVar16 + -1)) + uVar23 * -8 + 9;
    uVar23 = 0;
    local_58 = puVar24;
  }
  else {
    uVar23 = uVar23 - 4;
    local_60 = *(uint *)((int)puVar24 + uVar23);
    if (*(byte *)((int)puVar16 + -1) == 0) {
      return 0xffffffff;
    }
    local_5c = LZCOUNT((uint)*(byte *)((int)puVar16 + -1)) - 0x17;
    local_58 = (uint *)((int)puVar24 + uVar23);
  }
  if (uVar3 == 0) {
    puVar16 = &local_74;
    local_54 = puVar24;
LAB_00034740:
    memset(puVar16,0,0x14);
    return 0xffffffb8;
  }
  puVar12 = puVar16 + 1;
  if (3 < uVar3) {
    local_8c = uVar3 - 4;
    local_74 = *(uint *)((int)puVar16 + local_8c);
    uVar22 = (uint)*(byte *)((int)puVar16 + (uVar3 - 1));
    if (uVar22 == 0) {
      return 0xffffffff;
    }
    local_70 = LZCOUNT(uVar22) - 0x17;
    local_6c = (uint *)((int)puVar16 + local_8c);
    if (0xffffff88 < uVar3) {
      return uVar3;
    }
    goto LAB_000347b4;
  }
  local_74 = (uint)*(byte *)puVar16;
  if (uVar3 == 2) {
LAB_00034780:
    local_74 = local_74 + (uint)*(byte *)((int)puVar16 + 1) * 0x100;
  }
  else if (uVar3 == 3) {
    local_74 = local_74 | (uint)*(byte *)((int)puVar16 + 2) << 0x10;
    goto LAB_00034780;
  }
  uVar22 = (uint)*(byte *)((int)puVar16 + (uVar3 - 1));
  if (uVar22 == 0) {
    return 0xffffffec;
  }
  local_70 = LZCOUNT(uVar22) + uVar3 * -8 + 9;
  local_8c = 0;
  local_6c = puVar16;
LAB_000347b4:
  uVar3 = 3;
  if (uVar19 < 0x21) {
    if (uVar8 < 10) {
      if (uVar8 == 6) {
        uVar22 = 2;
        if (uVar19 < 0x20) {
          uVar22 = 1;
        }
      }
      else {
        iVar13 = uVar8 - (uVar19 >> 3);
        uVar22 = uVar19 >> 3;
        if (iVar13 < 6) {
          uVar22 = uVar8 - 6;
        }
        local_30 = (uint *)((int)param_3 + (uVar8 - uVar22));
        local_34 = uVar19 + uVar22 * -8;
        local_38 = *(uint *)((int)param_3 + (uVar8 - uVar22));
        uVar22 = 0;
        if (iVar13 < 6) {
          uVar22 = 1;
        }
      }
    }
    else {
      local_34 = uVar19 & 7;
      local_30 = (uint *)((int)param_3 + (uVar8 - (uVar19 >> 3)));
      local_38 = *(uint *)((int)param_3 + (uVar8 - (uVar19 >> 3)));
      uVar22 = 0;
    }
  }
  else {
    uVar22 = 3;
  }
  uVar8 = param_2 + 3;
  if (local_48 < 0x21) {
    if ((int)uVar18 < 4) {
      if (uVar18 == 0) {
        uVar3 = 2;
        bVar25 = 0x1f < local_48;
      }
      else {
        puVar14 = (uint *)((int)local_40 + (uVar18 - (local_48 >> 3)));
        uVar3 = uVar18;
        if (local_40 <= puVar14) {
          uVar3 = local_48 >> 3;
        }
        local_44 = (uint *)((int)local_40 + (uVar18 - uVar3));
        local_48 = local_48 + uVar3 * -8;
        local_4c = *(uint *)((int)local_40 + (uVar18 - uVar3));
        uVar3 = 0;
        bVar25 = local_40 <= puVar14;
      }
      if (!bVar25) {
        uVar3 = 1;
      }
    }
    else {
      local_44 = (uint *)((int)local_40 + (uVar18 - (local_48 >> 3)));
      local_4c = *(uint *)((int)local_40 + (uVar18 - (local_48 >> 3)));
      uVar3 = 0;
      local_48 = local_48 & 7;
    }
  }
  puVar17 = param_1 + (uVar8 >> 2);
  uVar18 = 3;
  uVar19 = 3;
  if (local_5c < 0x21) {
    if ((int)uVar23 < 4) {
      if (uVar23 == 0) {
        uVar19 = 2;
        bVar25 = 0x1f < local_5c;
      }
      else {
        puVar14 = (uint *)((int)puVar24 + (uVar23 - (local_5c >> 3)));
        uVar19 = uVar23;
        if (puVar24 <= puVar14) {
          uVar19 = local_5c >> 3;
        }
        local_58 = (uint *)((int)puVar24 + (uVar23 - uVar19));
        local_5c = local_5c + uVar19 * -8;
        local_60 = *(uint *)((int)puVar24 + (uVar23 - uVar19));
        uVar19 = 0;
        bVar25 = puVar24 <= puVar14;
      }
      if (!bVar25) {
        uVar19 = 1;
      }
    }
    else {
      local_58 = (uint *)((int)puVar24 + (uVar23 - (local_5c >> 3)));
      local_60 = *(uint *)((int)puVar24 + (uVar23 - (local_5c >> 3)));
      uVar19 = 0;
      local_5c = local_5c & 7;
    }
  }
  puVar20 = puVar17 + (uVar8 >> 2);
  if (local_70 < 0x21) {
    if ((int)local_8c < 4) {
      if (local_8c == 0) {
        uVar18 = 2;
        bVar25 = 0x1f < local_70;
      }
      else {
        puVar14 = (uint *)((int)puVar16 + (local_8c - (local_70 >> 3)));
        uVar23 = local_8c;
        if (puVar16 <= puVar14) {
          uVar23 = local_70 >> 3;
        }
        local_6c = (uint *)((int)puVar16 + (local_8c - uVar23));
        local_70 = local_70 + uVar23 * -8;
        bVar25 = puVar16 <= puVar14;
        local_74 = *(uint *)((int)puVar16 + (local_8c - uVar23));
        uVar18 = 0;
      }
      if (!bVar25) {
        uVar18 = 1;
      }
    }
    else {
      local_6c = (uint *)((int)puVar16 + (local_8c - (local_70 >> 3)));
      local_74 = *(uint *)((int)puVar16 + (local_8c - (local_70 >> 3)));
      uVar18 = 0;
      local_70 = local_70 & 7;
    }
  }
  puVar9 = param_1 + param_2;
  puVar21 = puVar20 + (uVar8 >> 2);
  puVar10 = puVar21;
  puVar15 = puVar20;
  puVar5 = puVar17;
  if (((uVar3 | uVar22 | uVar19 | uVar18) == 0) && (puVar21 < puVar9 + -7)) {
    uVar8 = uVar8 >> 2;
    iVar13 = uVar8 * 3;
    uVar3 = -uVar2 & 0x1f;
    while( true ) {
      puVar5 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar3) * 2 + 4);
      local_34 = local_34 + (byte)puVar5[1];
      *param_1 = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar3) * 2 + 4);
      local_48 = local_48 + (byte)puVar5[1];
      param_1[uVar8] = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar3) * 2 + 4);
      local_5c = local_5c + (byte)puVar5[1];
      param_1[uVar8 * 2] = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar3) * 2 + 4);
      local_70 = local_70 + (byte)puVar5[1];
      param_1[iVar13] = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar3) * 2 + 4);
      local_34 = local_34 + (byte)puVar5[1];
      param_1[1] = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar3) * 2 + 4);
      local_48 = local_48 + (byte)puVar5[1];
      (param_1 + uVar8)[1] = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar3) * 2 + 4);
      local_5c = local_5c + (byte)puVar5[1];
      param_1[uVar8 * 2 + 1] = *puVar5;
      puVar5 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar3) * 2 + 4);
      local_70 = local_70 + (byte)puVar5[1];
      param_1[iVar13 + 1] = *puVar5;
      bVar4 = 3;
      if (local_34 < 0x21) {
        if (local_30 < local_28) {
          if (local_30 == local_2c) {
            bVar26 = 2;
            if (local_34 < 0x20) {
              bVar26 = 1;
            }
          }
          else {
            puVar14 = (uint *)((int)local_30 - (local_34 >> 3));
            uVar23 = local_34 >> 3;
            if (puVar14 < local_2c) {
              uVar23 = (int)local_30 - (int)local_2c;
            }
            local_34 = local_34 + uVar23 * -8;
            local_38 = *(uint *)((int)local_30 - uVar23);
            bVar26 = puVar14 < local_2c;
            local_30 = (uint *)((int)local_30 - uVar23);
          }
        }
        else {
          uVar23 = local_34 >> 3;
          local_38 = *(uint *)((int)local_30 - (local_34 >> 3));
          bVar26 = 0;
          local_34 = local_34 & 7;
          local_30 = (uint *)((int)local_30 - uVar23);
        }
      }
      else {
        bVar26 = 3;
      }
      if (local_48 < 0x21) {
        if (local_44 < local_3c) {
          if (local_44 == local_40) {
            bVar25 = 0x1f < local_48;
            bVar4 = 2;
          }
          else {
            puVar14 = (uint *)((int)local_44 - (local_48 >> 3));
            uVar23 = local_48 >> 3;
            if (puVar14 < local_40) {
              uVar23 = (int)local_44 - (int)local_40;
            }
            bVar25 = local_40 <= puVar14;
            local_48 = local_48 + uVar23 * -8;
            local_4c = *(uint *)((int)local_44 - uVar23);
            bVar4 = 0;
            local_44 = (uint *)((int)local_44 - uVar23);
          }
          if (!bVar25) {
            bVar4 = 1;
          }
        }
        else {
          uVar23 = local_48 >> 3;
          local_4c = *(uint *)((int)local_44 - (local_48 >> 3));
          bVar4 = 0;
          local_48 = local_48 & 7;
          local_44 = (uint *)((int)local_44 - uVar23);
        }
      }
      bVar1 = 3;
      bVar11 = 3;
      if (local_5c < 0x21) {
        if (local_58 < local_50) {
          if (local_58 == puVar24) {
            bVar25 = 0x1f < local_5c;
            bVar11 = 2;
          }
          else {
            puVar14 = (uint *)((int)local_58 - (local_5c >> 3));
            uVar23 = local_5c >> 3;
            if (puVar14 < puVar24) {
              uVar23 = (int)local_58 - (int)puVar24;
            }
            bVar25 = puVar24 <= puVar14;
            local_5c = local_5c + uVar23 * -8;
            local_60 = *(uint *)((int)local_58 - uVar23);
            bVar11 = 0;
            local_58 = (uint *)((int)local_58 - uVar23);
          }
          if (!bVar25) {
            bVar11 = 1;
          }
        }
        else {
          uVar23 = local_5c >> 3;
          local_60 = *(uint *)((int)local_58 - (local_5c >> 3));
          bVar11 = 0;
          local_5c = local_5c & 7;
          local_58 = (uint *)((int)local_58 - uVar23);
        }
      }
      if (local_70 < 0x21) {
        if (local_6c < puVar12) {
          if (local_6c == puVar16) {
            bVar25 = 0x1f < local_70;
            bVar1 = 2;
          }
          else {
            puVar14 = (uint *)((int)local_6c - (local_70 >> 3));
            uVar23 = local_70 >> 3;
            if (puVar14 < puVar16) {
              uVar23 = (int)local_6c - (int)puVar16;
            }
            bVar25 = puVar16 <= puVar14;
            local_70 = local_70 + uVar23 * -8;
            local_74 = *(uint *)((int)local_6c - uVar23);
            bVar1 = 0;
            local_6c = (uint *)((int)local_6c - uVar23);
          }
          if (!bVar25) {
            bVar1 = 1;
          }
        }
        else {
          uVar23 = local_70 >> 3;
          local_74 = *(uint *)((int)local_6c - (local_70 >> 3));
          bVar1 = 0;
          local_70 = local_70 & 7;
          local_6c = (uint *)((int)local_6c - uVar23);
        }
      }
      puVar10 = param_1 + iVar13 + 2;
      if (((byte)(bVar4 | bVar26 | bVar11 | bVar1) != 0) || (puVar9 + -7 <= puVar10)) break;
      param_1 = param_1 + 2;
    }
    puVar15 = param_1 + uVar8 * 2 + 2;
    puVar5 = param_1 + uVar8 + 2;
    param_1 = param_1 + 2;
  }
  bVar27 = puVar21 <= puVar15;
  bVar25 = puVar15 == puVar21;
  if (!bVar27 || bVar25) {
    bVar27 = puVar20 <= puVar5;
    bVar25 = puVar5 == puVar20;
  }
  if (bVar27 && !bVar25) {
    return 0xffffffec;
  }
  if (puVar17 < param_1) {
    return 0xffffffec;
  }
  uVar2 = -uVar2 & 0x1f;
  puVar6 = param_1;
  if (local_34 < 0x21) {
    do {
      if (local_30 < local_28) {
        puVar6 = param_1;
        if (local_30 == local_2c) goto LAB_00035174;
        uVar3 = local_34 >> 3;
        bVar25 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
        if (bVar25) {
          uVar3 = (int)local_30 - (int)local_2c;
        }
        local_34 = local_34 + uVar3 * -8;
      }
      else {
        uVar3 = local_34 >> 3;
        local_34 = local_34 & 7;
        bVar25 = false;
      }
      local_30 = (uint *)((int)local_30 - uVar3);
      local_38 = *local_30;
      if ((puVar17 + -4 < param_1) || (bVar25)) goto LAB_0003516c;
      puVar6 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2 + 4);
      local_34 = local_34 + (byte)puVar6[1];
      *param_1 = *puVar6;
      puVar6 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2 + 4);
      local_34 = local_34 + (byte)puVar6[1];
      param_1[1] = *puVar6;
      param_1 = param_1 + 2;
      puVar6 = param_1;
    } while (local_34 < 0x21);
  }
joined_r0x00035214:
  if (puVar6 < puVar17) {
    puVar7 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2 + 4);
    local_34 = local_34 + (byte)puVar7[1];
    *puVar6 = *puVar7;
    while (puVar6 = puVar6 + 1, puVar6 != puVar17) {
      puVar7 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2 + 4);
      local_34 = local_34 + (byte)puVar7[1];
      *puVar6 = *puVar7;
    }
  }
  if (local_48 < 0x21) {
    do {
      if (local_44 < local_3c) {
        puVar17 = puVar5;
        if (local_44 == local_40) goto LAB_00035380;
        uVar3 = local_48 >> 3;
        bVar25 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
        if (bVar25) {
          uVar3 = (int)local_44 - (int)local_40;
        }
        local_48 = local_48 + uVar3 * -8;
      }
      else {
        uVar3 = local_48 >> 3;
        local_48 = local_48 & 7;
        bVar25 = false;
      }
      local_44 = (uint *)((int)local_44 - uVar3);
      local_4c = *local_44;
      if ((puVar20 + -4 < puVar5) || (bVar25)) goto LAB_00035378;
      puVar17 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2 + 4);
      local_48 = local_48 + (byte)puVar17[1];
      *puVar5 = *puVar17;
      puVar17 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2 + 4);
      local_48 = local_48 + (byte)puVar17[1];
      puVar5[1] = *puVar17;
      puVar5 = puVar5 + 2;
    } while (local_48 < 0x21);
  }
joined_r0x00035428:
  if (puVar5 < puVar20) {
    puVar17 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2 + 4);
    local_48 = local_48 + (byte)puVar17[1];
    *puVar5 = *puVar17;
    while (puVar5 = puVar5 + 1, puVar5 != puVar20) {
      puVar17 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2 + 4);
      local_48 = local_48 + (byte)puVar17[1];
      *puVar5 = *puVar17;
    }
  }
  if (local_5c < 0x21) {
    do {
      if (local_58 < local_50) {
        puVar17 = puVar15;
        if (local_58 == puVar24) goto LAB_0003558c;
        uVar3 = local_5c >> 3;
        bVar25 = (uint *)((int)local_58 - (local_5c >> 3)) < puVar24;
        if (bVar25) {
          uVar3 = (int)local_58 - (int)puVar24;
        }
        local_5c = local_5c + uVar3 * -8;
      }
      else {
        uVar3 = local_5c >> 3;
        local_5c = local_5c & 7;
        bVar25 = false;
      }
      local_58 = (uint *)((int)local_58 - uVar3);
      local_60 = *local_58;
      if ((puVar21 + -4 < puVar15) || (bVar25)) goto LAB_00035584;
      puVar17 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2 + 4);
      local_5c = local_5c + (byte)puVar17[1];
      *puVar15 = *puVar17;
      puVar17 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2 + 4);
      local_5c = local_5c + (byte)puVar17[1];
      puVar15[1] = *puVar17;
      puVar15 = puVar15 + 2;
    } while (local_5c < 0x21);
  }
joined_r0x00035634:
  if (puVar15 < puVar21) {
    puVar17 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2 + 4);
    local_5c = local_5c + (byte)puVar17[1];
    *puVar15 = *puVar17;
    while (puVar15 = puVar15 + 1, puVar15 != puVar21) {
      puVar17 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2 + 4);
      local_5c = local_5c + (byte)puVar17[1];
      *puVar15 = *puVar17;
    }
  }
  if (local_70 < 0x21) {
    do {
      if (local_6c < puVar12) {
        puVar17 = puVar10;
        if (local_6c == puVar16) goto LAB_0003575c;
        uVar3 = local_70 >> 3;
        bVar25 = (uint *)((int)local_6c - (local_70 >> 3)) < puVar16;
        if (bVar25) {
          uVar3 = (int)local_6c - (int)puVar16;
        }
        local_70 = local_70 + uVar3 * -8;
      }
      else {
        uVar3 = local_70 >> 3;
        local_70 = local_70 & 7;
        bVar25 = false;
      }
      local_6c = (uint *)((int)local_6c - uVar3);
      local_74 = *local_6c;
      if ((puVar9 + -4 < puVar10) || (bVar25)) goto LAB_00035754;
      puVar17 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2 + 4);
      local_70 = local_70 + (byte)puVar17[1];
      *puVar10 = *puVar17;
      puVar17 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2 + 4);
      local_70 = local_70 + (byte)puVar17[1];
      puVar10[1] = *puVar17;
      puVar10 = puVar10 + 2;
    } while (local_70 < 0x21);
  }
joined_r0x000357fc:
  if (puVar10 < puVar9) {
    puVar17 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2 + 4);
    local_70 = local_70 + (byte)puVar17[1];
    *puVar10 = *puVar17;
    while (puVar10 = puVar10 + 1, puVar10 != puVar9) {
      puVar17 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2 + 4);
      local_70 = local_70 + (byte)puVar17[1];
      *puVar10 = *puVar17;
    }
  }
  if ((((local_44 != local_40 || local_48 != 0x20) || (local_30 != local_2c || local_34 != 0x20)) ||
      (local_58 != puVar24 || local_5c != 0x20)) || (local_6c != puVar16 || local_70 != 0x20)) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_0003516c:
  puVar6 = param_1;
  if (0x20 < local_34) goto joined_r0x00035214;
LAB_00035174:
  if (local_30 < local_28) {
    if (local_30 == local_2c) goto joined_r0x00035214;
    uVar3 = local_34 >> 3;
    bVar25 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
    if (bVar25) {
      uVar3 = (int)local_30 - (int)local_2c;
    }
    local_34 = local_34 + uVar3 * -8;
  }
  else {
    uVar3 = local_34 >> 3;
    local_34 = local_34 & 7;
    bVar25 = false;
  }
  local_30 = (uint *)((int)local_30 - uVar3);
  local_38 = *local_30;
  if ((puVar17 <= puVar6) || (bVar25)) goto joined_r0x00035214;
  puVar7 = (undefined *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar2) * 2 + 4);
  local_34 = local_34 + (byte)puVar7[1];
  param_1 = puVar6 + 1;
  *puVar6 = *puVar7;
  goto LAB_0003516c;
LAB_00035378:
  puVar17 = puVar5;
  if (0x20 < local_48) goto joined_r0x00035428;
LAB_00035380:
  puVar5 = puVar17;
  if (local_44 < local_3c) {
    if (local_44 == local_40) goto joined_r0x00035428;
    uVar3 = local_48 >> 3;
    bVar25 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
    if (bVar25) {
      uVar3 = (int)local_44 - (int)local_40;
    }
    local_48 = local_48 + uVar3 * -8;
  }
  else {
    uVar3 = local_48 >> 3;
    local_48 = local_48 & 7;
    bVar25 = false;
  }
  local_44 = (uint *)((int)local_44 - uVar3);
  local_4c = *local_44;
  if ((puVar20 <= puVar17) || (bVar25)) goto joined_r0x00035428;
  puVar6 = (undefined *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar2) * 2 + 4);
  local_48 = local_48 + (byte)puVar6[1];
  puVar5 = puVar17 + 1;
  *puVar17 = *puVar6;
  goto LAB_00035378;
LAB_00035584:
  puVar17 = puVar15;
  if (0x20 < local_5c) goto joined_r0x00035634;
LAB_0003558c:
  puVar15 = puVar17;
  if (local_58 < local_50) {
    if (local_58 == puVar24) goto joined_r0x00035634;
    uVar3 = local_5c >> 3;
    bVar25 = (uint *)((int)local_58 - (local_5c >> 3)) < puVar24;
    if (bVar25) {
      uVar3 = (int)local_58 - (int)puVar24;
    }
    local_5c = local_5c + uVar3 * -8;
  }
  else {
    uVar3 = local_5c >> 3;
    local_5c = local_5c & 7;
    bVar25 = false;
  }
  local_58 = (uint *)((int)local_58 - uVar3);
  local_60 = *local_58;
  if ((puVar21 <= puVar17) || (bVar25)) goto joined_r0x00035634;
  puVar20 = (undefined *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar2) * 2 + 4);
  local_5c = local_5c + (byte)puVar20[1];
  puVar15 = puVar17 + 1;
  *puVar17 = *puVar20;
  goto LAB_00035584;
LAB_00035754:
  puVar17 = puVar10;
  if (0x20 < local_70) goto joined_r0x000357fc;
LAB_0003575c:
  puVar10 = puVar17;
  if (local_6c < puVar12) {
    if (local_6c == puVar16) goto joined_r0x000357fc;
    uVar3 = local_70 >> 3;
    bVar25 = (uint *)((int)local_6c - (local_70 >> 3)) < puVar16;
    if (bVar25) {
      uVar3 = (int)local_6c - (int)puVar16;
    }
    local_70 = local_70 + uVar3 * -8;
  }
  else {
    uVar3 = local_70 >> 3;
    local_70 = local_70 & 7;
    bVar25 = false;
  }
  local_6c = (uint *)((int)local_6c - uVar3);
  local_74 = *local_6c;
  if ((puVar9 <= puVar17) || (bVar25)) goto joined_r0x000357fc;
  puVar20 = (undefined *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar2) * 2 + 4);
  local_70 = local_70 + (byte)puVar20[1];
  puVar10 = puVar17 + 1;
  *puVar17 = *puVar20;
  goto LAB_00035754;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00035804 FUN_00035804 */

uint FUN_00035804(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_00033cfc(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00034428(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00035880 FUN_00035880 */

uint FUN_00035880(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_00033cfc(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00034428(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00035900 caseD_0 */

uint switchD_00038098::caseD_0(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_2824;
  undefined auStack_2820 [8192];
  undefined auStack_820 [2048];
  
  __aeabi_memclr4(auStack_2820,0x2000);
  local_2824 = 0xb00000b;
  uVar1 = FUN_00033cfc(&local_2824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00034428(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_2824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003599c FUN_0003599c */

uint FUN_0003599c(void *param_1,undefined4 param_2,undefined4 param_3,void *param_4,uint param_5)

{
  byte bVar1;
  undefined uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  int iVar6;
  byte *pbVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  undefined *puVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  uint uVar17;
  uint *puVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  int iVar22;
  int *piVar23;
  undefined4 local_98;
  uint local_94;
  uint local_90;
  uint auStack_8c [13];
  uint local_58 [13];
  
  memcpy(local_58,param_1,4);
  uVar10 = 0xffffffd4;
  local_98 = local_58[0];
  uVar20 = uVar10;
  if (0x5db < param_5) {
    uVar19 = local_58[0] & 0xff;
    memset((void *)((int)param_4 + 0x270),0,0x6c);
    if (uVar19 < 0xd) {
      uVar3 = FUN_00033b44((int)param_4 + 0x4dc,0x100,(void *)((int)param_4 + 0x270),&local_94,
                           &local_90,param_2,param_3);
      uVar20 = uVar3;
      if ((uVar3 < 0xffffff89) && (uVar20 = uVar10, local_90 <= uVar19)) {
        piVar23 = (int *)((int)param_4 + 0x2a8);
        uVar20 = uVar19 + 1;
        iVar22 = 0;
        iVar6 = local_90 + 0x9c;
        iVar16 = -2;
        do {
          iVar9 = iVar16;
          iVar8 = iVar6;
          uVar20 = uVar20 - 1;
          iVar22 = iVar22 + 0x34;
          iVar6 = iVar8 + -1;
          iVar16 = iVar9 + 1;
        } while (*(int *)((int)param_4 + iVar8 * 4) == 0);
        uVar10 = iVar8 - 0x9b;
        iVar8 = iVar8 + -0x9c;
        iVar6 = 0;
        if (1 < uVar10) {
          iVar6 = 0;
          iVar16 = 0;
          do {
            iVar12 = iVar16 + 1;
            *(int *)((int)param_4 + iVar16 * 4 + 0x2ac) = iVar6;
            iVar6 = *(int *)((int)param_4 + iVar16 * 4 + 0x274) + iVar6;
            iVar16 = iVar12;
          } while (iVar8 != iVar12);
        }
        *piVar23 = iVar6;
        if (local_94 != 0) {
          uVar11 = 0;
          do {
            bVar1 = *(byte *)((int)param_4 + 0x4dc + uVar11);
            iVar16 = piVar23[bVar1];
            piVar23[bVar1] = iVar16 + 1;
            puVar13 = (undefined *)((int)param_4 + iVar16 * 2 + 0x2dc);
            *puVar13 = (char)uVar11;
            uVar11 = uVar11 + 1;
            puVar13[1] = bVar1;
          } while (uVar11 < local_94);
        }
        *piVar23 = 0;
        if (1 < uVar10) {
          iVar12 = 0;
          iVar16 = 0;
          do {
            iVar14 = iVar16 + 1;
            *(int *)((int)param_4 + iVar16 * 4 + 4) = iVar12;
            iVar12 = iVar12 + (*(int *)((int)param_4 + iVar16 * 4 + 0x274) <<
                              ((uVar19 - local_90) + iVar16 & 0xff));
            iVar16 = iVar14;
          } while (iVar8 != iVar14);
        }
        uVar4 = iVar9 + 3;
        uVar11 = uVar4;
        if (uVar4 < uVar20) {
          do {
            if (1 < uVar10) {
              iVar16 = 0;
              do {
                *(uint *)((int)param_4 + iVar16 * 4 + iVar22 + 4) =
                     *(uint *)((int)param_4 + iVar16 * 4 + 4) >> (uVar11 & 0xff);
                iVar16 = iVar16 + 1;
              } while (iVar8 != iVar16);
            }
            uVar11 = uVar11 + 1;
            iVar22 = iVar22 + 0x34;
          } while (uVar20 != uVar11);
        }
        memcpy(auStack_8c,param_4,0x34);
        if (iVar6 != 0) {
          iVar22 = local_90 + 1;
          iVar16 = 0;
          do {
            pbVar7 = (byte *)((int)param_4 + iVar16 * 2 + 0x2dc);
            bVar1 = *pbVar7;
            uVar11 = (uint)pbVar7[1];
            uVar21 = iVar22 - uVar11;
            uVar10 = auStack_8c[uVar11];
            uVar20 = uVar19 - uVar21;
            iVar8 = 1 << (uVar20 & 0xff);
            if (uVar20 < uVar4) {
              uVar20 = iVar8 + uVar10;
              if (uVar10 < uVar20) {
                puVar5 = (uint *)((int)param_1 + uVar10 * 4 + 4);
                do {
                  *puVar5 = (uint)bVar1 | (uVar21 & 0xff) << 0x10 | 0x1000000;
                  iVar8 = iVar8 + -1;
                  puVar5 = puVar5 + 1;
                } while (iVar8 != 0);
              }
            }
            else {
              iVar12 = uVar21 + (iVar22 - uVar19);
              iVar9 = 1;
              if (1 < iVar12) {
                iVar9 = iVar12;
              }
              iVar14 = *(int *)((int)param_4 + iVar9 * 4 + 0x2a4);
              memcpy(local_58,(void *)(uVar21 * 0x34 + (int)param_4),0x34);
              puVar5 = (uint *)((int)param_1 + uVar10 * 4 + 4);
              if ((1 < iVar12) && (uVar10 = local_58[iVar9], uVar10 != 0)) {
                puVar18 = puVar5;
                do {
                  *puVar18 = (uint)bVar1 | (uVar21 & 0xff) << 0x10 | 0x1000000;
                  uVar10 = uVar10 - 1;
                  puVar18 = puVar18 + 1;
                } while (uVar10 != 0);
              }
              if (iVar6 != iVar14) {
                iVar9 = 0;
                do {
                  puVar13 = (undefined *)((int)param_4 + iVar9 * 2 + iVar14 * 2 + 0x2dc);
                  uVar2 = *puVar13;
                  uVar10 = (uint)(byte)puVar13[1];
                  uVar15 = local_58[uVar10];
                  uVar17 = uVar15 + (1 << (uVar20 - (iVar22 - uVar10) & 0xff));
                  do {
                    puVar5[uVar15] =
                         (uint)CONCAT11(uVar2,bVar1) | ((iVar22 - uVar10) + uVar21 & 0xff) << 0x10 |
                         0x2000000;
                    uVar15 = uVar15 + 1;
                  } while (uVar15 < uVar17);
                  iVar9 = iVar9 + 1;
                  local_58[uVar10] = uVar17;
                } while (iVar9 != iVar6 - iVar14);
              }
              uVar20 = auStack_8c[uVar11] + iVar8;
            }
            iVar16 = iVar16 + 1;
            auStack_8c[uVar11] = uVar20;
          } while (iVar16 != iVar6);
        }
        local_98 = CONCAT22(CONCAT11(local_98._3_1_,(char)local_58[0]),
                            CONCAT11(1,(undefined)local_98));
        memcpy(param_1,&local_98,4);
        uVar20 = uVar3;
      }
    }
  }
  return uVar20;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00035de4 FUN_00035de4 */

void FUN_00035de4(void)

{
  FUN_0003599c();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00035e0c FUN_00035e0c */

undefined4
FUN_00035e0c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            void *param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  memcpy(&uStack_24,param_5,4);
  uVar1 = 0xffffffff;
  if (local_23 == '\x01') {
    uVar1 = FUN_00035e70(param_1,param_2,param_3,param_4,param_5);
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00035e70 FUN_00035e70 */

uint FUN_00035e70(void *param_1,uint param_2,uint *param_3,uint param_4,void *param_5)

{
  uint uVar1;
  uint uVar2;
  void *pvVar3;
  void *pvVar4;
  bool bVar5;
  uint local_3c;
  uint local_38;
  uint *local_34;
  uint *local_30;
  uint *local_2c;
  undefined auStack_28 [2];
  ushort local_26;
  
  if (param_4 == 0) {
    memset(&local_3c,0,0x14);
    return 0xffffffb8;
  }
  local_2c = param_3 + 1;
  if (3 < param_4) {
    local_34 = (uint *)((int)param_3 + (param_4 - 4));
    local_3c = *(uint *)((int)param_3 + (param_4 - 4));
    uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
    if (uVar1 == 0) {
      return 0xffffffff;
    }
    local_38 = LZCOUNT(uVar1) - 0x17;
    if (0xffffff88 < param_4) {
      return param_4;
    }
    goto LAB_00035f44;
  }
  local_3c = (uint)*(byte *)param_3;
  if (param_4 == 2) {
LAB_00035f18:
    local_3c = local_3c + (uint)*(byte *)((int)param_3 + 1) * 0x100;
  }
  else if (param_4 == 3) {
    local_3c = local_3c | (uint)*(byte *)((int)param_3 + 2) << 0x10;
    goto LAB_00035f18;
  }
  uVar1 = (uint)*(byte *)((int)param_3 + (param_4 - 1));
  if (uVar1 == 0) {
    return 0xffffffec;
  }
  local_38 = LZCOUNT(uVar1) + param_4 * -8 + 9;
  local_34 = param_3;
LAB_00035f44:
  local_30 = param_3;
  memcpy(auStack_28,param_5,4);
  pvVar4 = (void *)((int)param_1 + param_2);
  if (local_38 < 0x21) {
    uVar1 = -(uint)local_26 & 0x1f;
    do {
      if (local_34 < local_2c) {
        if (local_34 == local_30) goto LAB_000360b4;
        uVar2 = local_38 >> 3;
        bVar5 = (uint *)((int)local_34 - (local_38 >> 3)) < local_30;
        if (bVar5) {
          uVar2 = (int)local_34 - (int)local_30;
        }
        local_38 = local_38 + uVar2 * -8;
      }
      else {
        uVar2 = local_38 >> 3;
        local_38 = local_38 & 7;
        bVar5 = false;
      }
      local_34 = (uint *)((int)local_34 - uVar2);
      local_3c = *local_34;
      if (((void *)((int)pvVar4 + -3) <= param_1) || (bVar5)) goto LAB_000360ac;
      pvVar3 = (void *)((int)param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar1) * 4 + 4);
      memcpy(param_1,pvVar3,2);
      local_38 = local_38 + *(byte *)((int)pvVar3 + 2);
      param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar3 + 3));
      pvVar3 = (void *)((int)param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar1) * 4 + 4);
      memcpy(param_1,pvVar3,2);
      local_38 = local_38 + *(byte *)((int)pvVar3 + 2);
      param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar3 + 3));
    } while (local_38 < 0x21);
  }
  else {
    uVar1 = -(uint)local_26 & 0x1f;
  }
LAB_0003619c:
  for (; param_1 <= (void *)((int)pvVar4 + -2);
      param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar3 + 3))) {
    pvVar3 = (void *)((int)param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar1) * 4 + 4);
    memcpy(param_1,pvVar3,2);
    local_38 = local_38 + *(byte *)((int)pvVar3 + 2);
  }
  if (param_1 < pvVar4) {
    param_5 = (void *)((int)param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar1) * 4 + 4);
    memcpy(param_1,param_5,1);
    if (*(char *)((int)param_5 + 3) == '\x01') {
      local_38 = local_38 + *(byte *)((int)param_5 + 2);
    }
    else if ((local_38 < 0x20) &&
            (local_38 = local_38 + *(byte *)((int)param_5 + 2), 0x1f < local_38)) {
      local_38 = 0x20;
    }
  }
  if (((uint)local_34 ^ (uint)local_30 | local_38 ^ 0x20) != 0) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_000360ac:
  if (0x20 < local_38) goto LAB_0003619c;
LAB_000360b4:
  if (local_34 < local_2c) {
    if (local_34 == local_30) goto LAB_0003619c;
    uVar2 = local_38 >> 3;
    bVar5 = (uint *)((int)local_34 - (local_38 >> 3)) < local_30;
    if (bVar5) {
      uVar2 = (int)local_34 - (int)local_30;
    }
    local_38 = local_38 + uVar2 * -8;
  }
  else {
    uVar2 = local_38 >> 3;
    local_38 = local_38 & 7;
    bVar5 = false;
  }
  local_34 = (uint *)((int)local_34 - uVar2);
  local_3c = *local_34;
  if (((void *)((int)pvVar4 + -2) < param_1) || (bVar5)) goto LAB_0003619c;
  pvVar3 = (void *)((int)param_5 + ((local_3c << (local_38 & 0x1f)) >> uVar1) * 4 + 4);
  memcpy(param_1,pvVar3,2);
  local_38 = local_38 + *(byte *)((int)pvVar3 + 2);
  param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar3 + 3));
  goto LAB_000360ac;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036234 FUN_00036234 */

uint FUN_00036234(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_0003599c(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00035e70(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000362b0 FUN_000362b0 */

uint FUN_000362b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_0003599c(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00035e70(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036330 FUN_00036330 */

uint FUN_00036330(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_4824;
  undefined auStack_4820 [16384];
  undefined auStack_820 [2048];
  
  __aeabi_memclr4(auStack_4820,0x4000);
  local_4824 = 0xc00000c;
  uVar1 = FUN_0003599c(&local_4824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00035e70(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_4824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000363cc FUN_000363cc */

undefined4
FUN_000363cc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            void *param_5)

{
  undefined4 uVar1;
  undefined uStack_24;
  char local_23;
  
  memcpy(&uStack_24,param_5,4);
  uVar1 = 0xffffffff;
  if (local_23 == '\x01') {
    uVar1 = FUN_00036430(param_1,param_2,param_3,param_4,param_5);
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00036430 FUN_00036430 */

uint FUN_00036430(void *param_1,uint param_2,ushort *param_3,uint param_4,void *param_5)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  void *pvVar7;
  void *pvVar8;
  uint uVar9;
  uint *puVar10;
  void *pvVar11;
  byte bVar12;
  byte bVar13;
  void *pvVar14;
  uint uVar15;
  uint *puVar16;
  int iVar17;
  void *pvVar18;
  void *pvVar19;
  void *pvVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  bool bVar24;
  byte bVar25;
  bool bVar26;
  uint local_90;
  void *local_84;
  void *local_80;
  uint local_7c;
  uint local_74;
  uint local_70;
  uint *local_6c;
  uint *local_68;
  uint *local_64;
  uint local_60;
  uint local_5c;
  uint *local_58;
  uint *local_54;
  uint *local_50;
  uint local_4c;
  uint local_48;
  uint *local_44;
  uint *local_40;
  uint *local_3c;
  uint local_38;
  uint local_34;
  uint *local_30;
  uint *local_2c;
  uint *local_28;
  
  if (param_4 < 10) {
    return 0xffffffec;
  }
  uVar23 = (uint)param_3[2];
  uVar22 = (uint)param_3[1];
  uVar15 = (uint)*param_3;
  memcpy(&local_38,param_5,4);
  uVar5 = uVar15 + 6 + uVar22 + uVar23;
  uVar6 = param_4 - uVar5;
  if (param_4 < uVar5) {
    return 0xffffffec;
  }
  if (uVar15 == 0) {
    puVar16 = &local_38;
    goto LAB_000367dc;
  }
  uVar5 = local_38 >> 0x10;
  local_2c = (uint *)(param_3 + 3);
  local_28 = (uint *)(param_3 + 5);
  if (uVar15 < 4) {
    local_38 = (uint)*(byte *)local_2c;
    if (uVar15 == 2) {
LAB_00036524:
      local_38 = local_38 + (uint)*(byte *)((int)param_3 + 7) * 0x100;
    }
    else if (uVar15 == 3) {
      local_38 = local_38 | (uint)*(byte *)(param_3 + 4) << 0x10;
      goto LAB_00036524;
    }
    uVar9 = (uint)*(byte *)((int)local_2c + (uVar15 - 1));
    if (uVar9 == 0) {
      return 0xffffffec;
    }
    uVar21 = LZCOUNT(uVar9) + uVar15 * -8 + 9;
    uVar9 = 6;
    local_30 = local_2c;
  }
  else {
    uVar9 = uVar15 + 2;
    local_38 = *(uint *)((int)param_3 + uVar9);
    uVar21 = (uint)*(byte *)((int)local_2c + (uVar15 - 1));
    if (uVar21 == 0) {
      return 0xffffffff;
    }
    uVar21 = LZCOUNT(uVar21) - 0x17;
    local_30 = (uint *)((int)param_3 + uVar9);
  }
  local_34 = uVar21;
  if (uVar22 == 0) {
    puVar16 = &local_4c;
    goto LAB_000367dc;
  }
  local_40 = (uint *)((int)param_3 + uVar15 + 6);
  puVar16 = (uint *)((int)local_40 + uVar22);
  local_3c = local_40 + 1;
  if (uVar22 < 4) {
    local_4c = (uint)*(byte *)local_40;
    if (uVar22 == 2) {
LAB_00036624:
      local_4c = local_4c + (uint)*(byte *)((int)local_40 + 1) * 0x100;
    }
    else if (uVar22 == 3) {
      local_4c = local_4c | (uint)*(byte *)((int)local_40 + 2) << 0x10;
      goto LAB_00036624;
    }
    if (*(byte *)((int)puVar16 + -1) == 0) {
      return 0xffffffec;
    }
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar16 + -1)) + uVar22 * -8 + 9;
    uVar22 = 0;
    local_44 = local_40;
  }
  else {
    uVar22 = uVar22 - 4;
    local_4c = *(uint *)((int)local_40 + uVar22);
    if (*(byte *)((int)puVar16 + -1) == 0) {
      return 0xffffffff;
    }
    local_48 = LZCOUNT((uint)*(byte *)((int)puVar16 + -1)) - 0x17;
    local_44 = (uint *)((int)local_40 + uVar22);
  }
  if (uVar23 == 0) {
    puVar16 = &local_60;
    goto LAB_000367dc;
  }
  local_68 = (uint *)((int)puVar16 + uVar23);
  local_50 = puVar16 + 1;
  if (uVar23 < 4) {
    local_60 = (uint)*(byte *)puVar16;
    if (uVar23 == 2) {
LAB_00036724:
      local_60 = local_60 + (uint)*(byte *)((int)puVar16 + 1) * 0x100;
    }
    else if (uVar23 == 3) {
      local_60 = local_60 | (uint)*(byte *)((int)puVar16 + 2) << 0x10;
      goto LAB_00036724;
    }
    if (*(byte *)((int)local_68 + -1) == 0) {
      return 0xffffffec;
    }
    uVar15 = 0;
    local_5c = LZCOUNT((uint)*(byte *)((int)local_68 + -1)) + uVar23 * -8 + 9;
    local_58 = puVar16;
  }
  else {
    uVar15 = uVar23 - 4;
    local_60 = *(uint *)((int)puVar16 + uVar15);
    if (*(byte *)((int)local_68 + -1) == 0) {
      return 0xffffffff;
    }
    local_5c = LZCOUNT((uint)*(byte *)((int)local_68 + -1)) - 0x17;
    local_58 = (uint *)((int)puVar16 + uVar15);
  }
  local_54 = puVar16;
  if (uVar6 == 0) {
    puVar16 = &local_74;
LAB_000367dc:
    memset(puVar16,0,0x14);
    return 0xffffffb8;
  }
  local_64 = local_68 + 1;
  if (3 < uVar6) {
    local_90 = uVar6 - 4;
    local_74 = *(uint *)((int)local_68 + local_90);
    uVar23 = (uint)*(byte *)((int)local_68 + (uVar6 - 1));
    if (uVar23 == 0) {
      return 0xffffffff;
    }
    local_70 = LZCOUNT(uVar23) - 0x17;
    local_6c = (uint *)((int)local_68 + local_90);
    if (0xffffff88 < uVar6) {
      return uVar6;
    }
    goto LAB_00036884;
  }
  local_74 = (uint)*(byte *)local_68;
  if (uVar6 == 2) {
LAB_00036848:
    local_74 = local_74 + (uint)*(byte *)((int)local_68 + 1) * 0x100;
  }
  else if (uVar6 == 3) {
    local_74 = local_74 | (uint)*(byte *)((int)local_68 + 2) << 0x10;
    goto LAB_00036848;
  }
  uVar23 = (uint)*(byte *)((int)local_68 + (uVar6 - 1));
  if (uVar23 == 0) {
    return 0xffffffec;
  }
  local_70 = LZCOUNT(uVar23) + uVar6 * -8 + 9;
  local_90 = 0;
  local_6c = local_68;
LAB_00036884:
  uVar6 = 3;
  if (uVar21 < 0x21) {
    if (uVar9 < 10) {
      if (uVar9 == 6) {
        uVar23 = 2;
        if (uVar21 < 0x20) {
          uVar23 = 1;
        }
      }
      else {
        iVar17 = uVar9 - (uVar21 >> 3);
        uVar23 = uVar21 >> 3;
        if (iVar17 < 6) {
          uVar23 = uVar9 - 6;
        }
        local_30 = (uint *)((int)param_3 + (uVar9 - uVar23));
        local_34 = uVar21 + uVar23 * -8;
        local_38 = *(uint *)((int)param_3 + (uVar9 - uVar23));
        uVar23 = 0;
        if (iVar17 < 6) {
          uVar23 = 1;
        }
      }
    }
    else {
      local_34 = uVar21 & 7;
      local_30 = (uint *)((int)param_3 + (uVar9 - (uVar21 >> 3)));
      local_38 = *(uint *)((int)param_3 + (uVar9 - (uVar21 >> 3)));
      uVar23 = 0;
    }
  }
  else {
    uVar23 = 3;
  }
  uVar9 = param_2 + 3;
  if (local_48 < 0x21) {
    if ((int)uVar22 < 4) {
      if (uVar22 == 0) {
        uVar6 = 2;
        bVar24 = 0x1f < local_48;
      }
      else {
        puVar10 = (uint *)((int)local_40 + (uVar22 - (local_48 >> 3)));
        uVar6 = uVar22;
        if (local_40 <= puVar10) {
          uVar6 = local_48 >> 3;
        }
        local_44 = (uint *)((int)local_40 + (uVar22 - uVar6));
        local_48 = local_48 + uVar6 * -8;
        bVar24 = local_40 <= puVar10;
        local_4c = *(uint *)((int)local_40 + (uVar22 - uVar6));
        uVar6 = 0;
      }
      if (!bVar24) {
        uVar6 = 1;
      }
    }
    else {
      local_44 = (uint *)((int)local_40 + (uVar22 - (local_48 >> 3)));
      local_4c = *(uint *)((int)local_40 + (uVar22 - (local_48 >> 3)));
      uVar6 = 0;
      local_48 = local_48 & 7;
    }
  }
  pvVar11 = (void *)((int)param_1 + (uVar9 >> 2));
  uVar22 = 3;
  uVar21 = 3;
  if (local_5c < 0x21) {
    if ((int)uVar15 < 4) {
      if (uVar15 == 0) {
        uVar21 = 2;
        bVar24 = 0x1f < local_5c;
      }
      else {
        puVar10 = (uint *)((int)puVar16 + (uVar15 - (local_5c >> 3)));
        uVar21 = uVar15;
        if (puVar16 <= puVar10) {
          uVar21 = local_5c >> 3;
        }
        local_58 = (uint *)((int)puVar16 + (uVar15 - uVar21));
        local_5c = local_5c + uVar21 * -8;
        bVar24 = puVar16 <= puVar10;
        local_60 = *(uint *)((int)puVar16 + (uVar15 - uVar21));
        uVar21 = 0;
      }
      if (!bVar24) {
        uVar21 = 1;
      }
    }
    else {
      local_58 = (uint *)((int)puVar16 + (uVar15 - (local_5c >> 3)));
      local_60 = *(uint *)((int)puVar16 + (uVar15 - (local_5c >> 3)));
      uVar21 = 0;
      local_5c = local_5c & 7;
    }
  }
  pvVar18 = (void *)((int)pvVar11 + (uVar9 >> 2));
  pvVar19 = (void *)((int)param_1 + param_2);
  if (local_70 < 0x21) {
    if ((int)local_90 < 4) {
      if (local_90 == 0) {
        uVar22 = 2;
        bVar24 = 0x1f < local_70;
      }
      else {
        puVar16 = (uint *)((int)local_68 + (local_90 - (local_70 >> 3)));
        uVar22 = local_90;
        if (local_68 <= puVar16) {
          uVar22 = local_70 >> 3;
        }
        local_6c = (uint *)((int)local_68 + (local_90 - uVar22));
        local_70 = local_70 + uVar22 * -8;
        bVar24 = local_68 <= puVar16;
        local_74 = *(uint *)((int)local_68 + (local_90 - uVar22));
        uVar22 = 0;
      }
      if (!bVar24) {
        uVar22 = 1;
      }
    }
    else {
      local_6c = (uint *)((int)local_68 + (local_90 - (local_70 >> 3)));
      local_74 = *(uint *)((int)local_68 + (local_90 - (local_70 >> 3)));
      uVar22 = 0;
      local_70 = local_70 & 7;
    }
  }
  pvVar14 = (void *)((int)pvVar18 + (uVar9 >> 2));
  pvVar7 = (void *)((int)pvVar19 + -3);
  pvVar8 = pvVar18;
  local_84 = pvVar11;
  local_80 = pvVar14;
  if (((uVar6 | uVar23 | uVar21 | uVar22) == 0) && (pvVar14 < pvVar7)) {
    uVar6 = -uVar5 & 0x1f;
    do {
      pvVar20 = (void *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(param_1,pvVar20,2);
      local_34 = local_34 + *(byte *)((int)pvVar20 + 2);
      bVar1 = *(byte *)((int)pvVar20 + 3);
      pvVar20 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(local_84,pvVar20,2);
      local_48 = local_48 + *(byte *)((int)pvVar20 + 2);
      bVar2 = *(byte *)((int)pvVar20 + 3);
      pvVar20 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(pvVar8,pvVar20,2);
      local_5c = local_5c + *(byte *)((int)pvVar20 + 2);
      bVar3 = *(byte *)((int)pvVar20 + 3);
      pvVar20 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(local_80,pvVar20,2);
      local_70 = local_70 + *(byte *)((int)pvVar20 + 2);
      bVar12 = *(byte *)((int)pvVar20 + 3);
      pvVar20 = (void *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4 + 4);
      param_1 = (void *)((int)param_1 + (uint)bVar1);
      memcpy(param_1,pvVar20,2);
      local_34 = local_34 + *(byte *)((int)pvVar20 + 2);
      bVar1 = *(byte *)((int)pvVar20 + 3);
      local_84 = (void *)((int)local_84 + (uint)bVar2);
      pvVar20 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(local_84,pvVar20,2);
      local_48 = local_48 + *(byte *)((int)pvVar20 + 2);
      bVar2 = *(byte *)((int)pvVar20 + 3);
      pvVar20 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
      pvVar8 = (void *)((int)pvVar8 + (uint)bVar3);
      memcpy(pvVar8,pvVar20,2);
      local_5c = local_5c + *(byte *)((int)pvVar20 + 2);
      local_80 = (void *)((int)local_80 + (uint)bVar12);
      bVar3 = *(byte *)((int)pvVar20 + 3);
      pvVar20 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(local_80,pvVar20,2);
      bVar12 = 3;
      local_70 = local_70 + *(byte *)((int)pvVar20 + 2);
      if (local_34 < 0x21) {
        if (local_30 < local_28) {
          if (local_30 == local_2c) {
            bVar25 = 2;
            if (local_34 < 0x20) {
              bVar25 = 1;
            }
          }
          else {
            puVar16 = (uint *)((int)local_30 - (local_34 >> 3));
            uVar22 = local_34 >> 3;
            if (puVar16 < local_2c) {
              uVar22 = (int)local_30 - (int)local_2c;
            }
            local_34 = local_34 + uVar22 * -8;
            bVar25 = puVar16 < local_2c;
            local_38 = *(uint *)((int)local_30 - uVar22);
            local_30 = (uint *)((int)local_30 - uVar22);
          }
        }
        else {
          uVar22 = local_34 >> 3;
          local_38 = *(uint *)((int)local_30 - (local_34 >> 3));
          bVar25 = 0;
          local_34 = local_34 & 7;
          local_30 = (uint *)((int)local_30 - uVar22);
        }
      }
      else {
        bVar25 = 3;
      }
      if (local_48 < 0x21) {
        if (local_44 < local_3c) {
          if (local_44 == local_40) {
            bVar24 = 0x1f < local_48;
            bVar12 = 2;
          }
          else {
            puVar16 = (uint *)((int)local_44 - (local_48 >> 3));
            uVar22 = local_48 >> 3;
            if (puVar16 < local_40) {
              uVar22 = (int)local_44 - (int)local_40;
            }
            bVar24 = local_40 <= puVar16;
            local_48 = local_48 + uVar22 * -8;
            local_4c = *(uint *)((int)local_44 - uVar22);
            bVar12 = 0;
            local_44 = (uint *)((int)local_44 - uVar22);
          }
          if (!bVar24) {
            bVar12 = 1;
          }
        }
        else {
          uVar22 = local_48 >> 3;
          local_4c = *(uint *)((int)local_44 - (local_48 >> 3));
          bVar12 = 0;
          local_48 = local_48 & 7;
          local_44 = (uint *)((int)local_44 - uVar22);
        }
      }
      bVar13 = 3;
      bVar4 = 3;
      if (local_5c < 0x21) {
        if (local_58 < local_50) {
          if (local_58 == local_54) {
            bVar24 = 0x1f < local_5c;
            bVar4 = 2;
          }
          else {
            puVar16 = (uint *)((int)local_58 - (local_5c >> 3));
            uVar22 = local_5c >> 3;
            if (puVar16 < local_54) {
              uVar22 = (int)local_58 - (int)local_54;
            }
            local_5c = local_5c + uVar22 * -8;
            local_60 = *(uint *)((int)local_58 - uVar22);
            bVar24 = local_54 <= puVar16;
            bVar4 = 0;
            local_58 = (uint *)((int)local_58 - uVar22);
          }
          if (!bVar24) {
            bVar4 = 1;
          }
        }
        else {
          uVar22 = local_5c >> 3;
          local_60 = *(uint *)((int)local_58 - (local_5c >> 3));
          bVar4 = 0;
          local_5c = local_5c & 7;
          local_58 = (uint *)((int)local_58 - uVar22);
        }
      }
      if (local_70 < 0x21) {
        if (local_6c < local_64) {
          if (local_6c == local_68) {
            bVar24 = 0x1f < local_70;
            bVar13 = 2;
          }
          else {
            puVar16 = (uint *)((int)local_6c - (local_70 >> 3));
            uVar22 = local_70 >> 3;
            if (puVar16 < local_68) {
              uVar22 = (int)local_6c - (int)local_68;
            }
            bVar24 = local_68 <= puVar16;
            local_70 = local_70 + uVar22 * -8;
            local_74 = *(uint *)((int)local_6c - uVar22);
            bVar13 = 0;
            local_6c = (uint *)((int)local_6c - uVar22);
          }
          if (!bVar24) {
            bVar13 = 1;
          }
        }
        else {
          uVar22 = local_70 >> 3;
          local_74 = *(uint *)((int)local_6c - (local_70 >> 3));
          bVar13 = 0;
          local_70 = local_70 & 7;
          local_6c = (uint *)((int)local_6c - uVar22);
        }
      }
      param_1 = (void *)((int)param_1 + (uint)bVar1);
      local_84 = (void *)((int)local_84 + (uint)bVar2);
      pvVar8 = (void *)((int)pvVar8 + (uint)bVar3);
      local_80 = (void *)((int)local_80 + (uint)*(byte *)((int)pvVar20 + 3));
    } while (((byte)(bVar12 | bVar25 | bVar4 | bVar13) == 0) && (local_80 < pvVar7));
  }
  bVar26 = pvVar14 <= pvVar8;
  bVar24 = pvVar8 == pvVar14;
  if (!bVar26 || bVar24) {
    bVar26 = pvVar18 <= local_84;
    bVar24 = local_84 == pvVar18;
  }
  if (bVar26 && !bVar24) {
    return 0xffffffec;
  }
  if (pvVar11 < param_1) {
    return 0xffffffec;
  }
  if (local_34 < 0x21) {
    uVar6 = -uVar5 & 0x1f;
    do {
      if (local_30 < local_28) {
        if (local_30 == local_2c) goto LAB_0003743c;
        uVar22 = local_34 >> 3;
        bVar24 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
        if (bVar24) {
          uVar22 = (int)local_30 - (int)local_2c;
        }
        local_7c = local_34 + uVar22 * -8;
      }
      else {
        uVar22 = local_34 >> 3;
        local_7c = local_34 & 7;
        bVar24 = false;
      }
      local_30 = (uint *)((int)local_30 - uVar22);
      local_34 = local_7c;
      local_38 = *local_30;
      if (((void *)((int)pvVar11 + -3) <= param_1) || (bVar24)) {
        if (local_7c < 0x21) goto LAB_0003743c;
        break;
      }
      pvVar20 = (void *)((int)param_5 + ((local_38 << (local_7c & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(param_1,pvVar20,2);
      local_34 = local_34 + *(byte *)((int)pvVar20 + 2);
      param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar20 + 3));
      pvVar20 = (void *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(param_1,pvVar20,2);
      local_34 = local_34 + *(byte *)((int)pvVar20 + 2);
      param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar20 + 3));
    } while (local_34 < 0x21);
  }
  else {
    uVar6 = -uVar5 & 0x1f;
  }
LAB_00037208:
  for (; param_1 <= (void *)((int)pvVar11 + -2);
      param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar20 + 3))) {
    pvVar20 = (void *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4 + 4);
    memcpy(param_1,pvVar20,2);
    local_34 = local_34 + *(byte *)((int)pvVar20 + 2);
  }
  if (param_1 < pvVar11) {
    pvVar11 = (void *)((int)param_5 + ((local_38 << (local_34 & 0x1f)) >> uVar6) * 4 + 4);
    memcpy(param_1,pvVar11,1);
    if (*(char *)((int)pvVar11 + 3) == '\x01') {
      local_34 = local_34 + *(byte *)((int)pvVar11 + 2);
    }
    else if ((local_34 < 0x20) &&
            (local_34 = local_34 + *(byte *)((int)pvVar11 + 2), 0x1f < local_34)) {
      local_34 = 0x20;
    }
  }
  if (local_48 < 0x21) {
    uVar6 = -uVar5 & 0x1f;
    do {
      if (local_44 < local_3c) {
        if (local_44 == local_40) goto LAB_00037524;
        uVar22 = local_48 >> 3;
        bVar24 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
        if (bVar24) {
          uVar22 = (int)local_44 - (int)local_40;
        }
        local_48 = local_48 + uVar22 * -8;
      }
      else {
        uVar22 = local_48 >> 3;
        local_48 = local_48 & 7;
        bVar24 = false;
      }
      local_44 = (uint *)((int)local_44 - uVar22);
      local_4c = *local_44;
      if (((void *)((int)pvVar18 + -3) <= local_84) || (bVar24)) goto LAB_0003751c;
      pvVar11 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(local_84,pvVar11,2);
      local_48 = local_48 + *(byte *)((int)pvVar11 + 2);
      local_84 = (void *)((int)local_84 + (uint)*(byte *)((int)pvVar11 + 3));
      pvVar11 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(local_84,pvVar11,2);
      local_48 = local_48 + *(byte *)((int)pvVar11 + 2);
      local_84 = (void *)((int)local_84 + (uint)*(byte *)((int)pvVar11 + 3));
    } while (local_48 < 0x21);
  }
  else {
    uVar6 = -uVar5 & 0x1f;
  }
LAB_00037610:
  for (; local_84 <= (void *)((int)pvVar18 + -2);
      local_84 = (void *)((int)local_84 + (uint)*(byte *)((int)pvVar11 + 3))) {
    pvVar11 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
    memcpy(local_84,pvVar11,2);
    local_48 = local_48 + *(byte *)((int)pvVar11 + 2);
  }
  if (local_84 < pvVar18) {
    pvVar11 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
    memcpy(local_84,pvVar11,1);
    if (*(char *)((int)pvVar11 + 3) == '\x01') {
      local_48 = local_48 + *(byte *)((int)pvVar11 + 2);
    }
    else if ((local_48 < 0x20) &&
            (local_48 = local_48 + *(byte *)((int)pvVar11 + 2), 0x1f < local_48)) {
      local_48 = 0x20;
    }
  }
  if (local_5c < 0x21) {
    uVar6 = -uVar5 & 0x1f;
    do {
      if (local_58 < local_50) {
        if (local_58 != local_54) {
          uVar22 = local_5c >> 3;
          bVar24 = (uint *)((int)local_58 - (local_5c >> 3)) < local_54;
          if (bVar24) {
            uVar22 = (int)local_58 - (int)local_54;
          }
          local_5c = local_5c + uVar22 * -8;
          goto LAB_00037710;
        }
LAB_000377d8:
        goto LAB_000377e0;
      }
      uVar22 = local_5c >> 3;
      local_5c = local_5c & 7;
      bVar24 = false;
LAB_00037710:
      local_58 = (uint *)((int)local_58 - uVar22);
      local_60 = *local_58;
      if (((void *)((int)pvVar14 + -3) <= pvVar8) || (bVar24)) {
        if (local_5c < 0x21) goto LAB_000377d8;
        break;
      }
      pvVar11 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(pvVar8,pvVar11,2);
      local_5c = local_5c + *(byte *)((int)pvVar11 + 2);
      pvVar8 = (void *)((int)pvVar8 + (uint)*(byte *)((int)pvVar11 + 3));
      pvVar11 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
      memcpy(pvVar8,pvVar11,2);
      local_5c = local_5c + *(byte *)((int)pvVar11 + 2);
      pvVar8 = (void *)((int)pvVar8 + (uint)*(byte *)((int)pvVar11 + 3));
    } while (local_5c < 0x21);
  }
  else {
    uVar6 = -uVar5 & 0x1f;
  }
LAB_000378d8:
  for (; pvVar8 <= (void *)((int)pvVar14 - 2U);
      pvVar8 = (void *)((int)pvVar8 + (uint)*(byte *)((int)pvVar11 + 3))) {
    pvVar11 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
    memcpy(pvVar8,pvVar11,2);
    local_5c = local_5c + *(byte *)((int)pvVar11 + 2);
  }
  if (pvVar8 < pvVar14) {
    pvVar11 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
    memcpy(pvVar8,pvVar11,1);
    if (*(char *)((int)pvVar11 + 3) == '\x01') {
      local_5c = local_5c + *(byte *)((int)pvVar11 + 2);
    }
    else if ((local_5c < 0x20) &&
            (local_5c = local_5c + *(byte *)((int)pvVar11 + 2), 0x1f < local_5c)) {
      local_5c = 0x20;
    }
  }
  if (local_70 < 0x21) {
    uVar5 = -uVar5 & 0x1f;
    do {
      if (local_6c < local_64) {
        if (local_6c == local_68) goto LAB_00037c10;
        uVar6 = local_70 >> 3;
        bVar24 = (uint *)((int)local_6c - (local_70 >> 3)) < local_68;
        if (bVar24) {
          uVar6 = (int)local_6c - (int)local_68;
        }
        local_70 = local_70 + uVar6 * -8;
      }
      else {
        uVar6 = local_70 >> 3;
        local_70 = local_70 & 7;
        bVar24 = false;
      }
      local_6c = (uint *)((int)local_6c - uVar6);
      local_74 = *local_6c;
      if ((pvVar7 <= local_80) || (bVar24)) goto LAB_00037c08;
      pvVar11 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4 + 4);
      memcpy(local_80,pvVar11,2);
      local_70 = local_70 + *(byte *)((int)pvVar11 + 2);
      local_80 = (void *)((int)local_80 + (uint)*(byte *)((int)pvVar11 + 3));
      pvVar11 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4 + 4);
      memcpy(local_80,pvVar11,2);
      local_70 = local_70 + *(byte *)((int)pvVar11 + 2);
      local_80 = (void *)((int)local_80 + (uint)*(byte *)((int)pvVar11 + 3));
    } while (local_70 < 0x21);
  }
  else {
    uVar5 = -uVar5 & 0x1f;
  }
LAB_00037a8c:
  for (; local_80 <= (void *)((int)pvVar19 + -2);
      local_80 = (void *)((int)local_80 + (uint)*(byte *)((int)pvVar11 + 3))) {
    pvVar11 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4 + 4);
    memcpy(local_80,pvVar11,2);
    local_70 = local_70 + *(byte *)((int)pvVar11 + 2);
  }
  if (local_80 < pvVar19) {
    param_5 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4 + 4);
    memcpy(local_80,param_5,1);
    if (*(char *)((int)param_5 + 3) == '\x01') {
      local_70 = local_70 + *(byte *)((int)param_5 + 2);
    }
    else if ((local_70 < 0x20) &&
            (local_70 = local_70 + *(byte *)((int)param_5 + 2), 0x1f < local_70)) {
      local_70 = 0x20;
    }
  }
  if ((((local_44 != local_40 || local_48 != 0x20) || (local_30 != local_2c || local_34 != 0x20)) ||
      (local_58 != local_54 || local_5c != 0x20)) ||
      ((uint)local_6c ^ (uint)local_68 | local_70 ^ 0x20) != 0) {
    param_2 = 0xffffffec;
  }
  return param_2;
LAB_0003743c:
  if (local_30 < local_28) {
    if (local_30 == local_2c) goto LAB_00037208;
    uVar22 = local_34 >> 3;
    bVar24 = (uint *)((int)local_30 - (local_34 >> 3)) < local_2c;
    if (bVar24) {
      uVar22 = (int)local_30 - (int)local_2c;
    }
    local_7c = local_34 + uVar22 * -8;
  }
  else {
    uVar22 = local_34 >> 3;
    local_7c = local_34 & 7;
    bVar24 = false;
  }
  local_30 = (uint *)((int)local_30 - uVar22);
  local_34 = local_7c;
  local_38 = *local_30;
  if (((void *)((int)pvVar11 - 2U) < param_1) || (bVar24)) goto LAB_00037208;
  pvVar20 = (void *)((int)param_5 + ((local_38 << (local_7c & 0x1f)) >> uVar6) * 4 + 4);
  memcpy(param_1,pvVar20,2);
  local_34 = local_34 + *(byte *)((int)pvVar20 + 2);
  param_1 = (void *)((int)param_1 + (uint)*(byte *)((int)pvVar20 + 3));
  if (0x20 < local_34) goto LAB_00037208;
  goto LAB_0003743c;
LAB_0003751c:
  if (0x20 < local_48) goto LAB_00037610;
LAB_00037524:
  if (local_44 < local_3c) {
    if (local_44 == local_40) goto LAB_00037610;
    uVar22 = local_48 >> 3;
    bVar24 = (uint *)((int)local_44 - (local_48 >> 3)) < local_40;
    if (bVar24) {
      uVar22 = (int)local_44 - (int)local_40;
    }
    local_48 = local_48 + uVar22 * -8;
  }
  else {
    uVar22 = local_48 >> 3;
    local_48 = local_48 & 7;
    bVar24 = false;
  }
  local_44 = (uint *)((int)local_44 - uVar22);
  local_4c = *local_44;
  if (((void *)((int)pvVar18 + -2) < local_84) || (bVar24)) goto LAB_00037610;
  pvVar11 = (void *)((int)param_5 + ((local_4c << (local_48 & 0x1f)) >> uVar6) * 4 + 4);
  memcpy(local_84,pvVar11,2);
  local_48 = local_48 + *(byte *)((int)pvVar11 + 2);
  local_84 = (void *)((int)local_84 + (uint)*(byte *)((int)pvVar11 + 3));
  goto LAB_0003751c;
LAB_000377e0:
  if (local_58 < local_50) {
    if (local_58 == local_54) goto LAB_000378d8;
    uVar22 = local_5c >> 3;
    bVar24 = (uint *)((int)local_58 - (local_5c >> 3)) < local_54;
    if (bVar24) {
      uVar22 = (int)local_58 - (int)local_54;
    }
    local_5c = local_5c + uVar22 * -8;
  }
  else {
    uVar22 = local_5c >> 3;
    local_5c = local_5c & 7;
    bVar24 = false;
  }
  local_58 = (uint *)((int)local_58 - uVar22);
  local_60 = *local_58;
  if (((void *)((int)pvVar14 - 2U) < pvVar8) || (bVar24)) goto LAB_000378d8;
  pvVar11 = (void *)((int)param_5 + ((local_60 << (local_5c & 0x1f)) >> uVar6) * 4 + 4);
  memcpy(pvVar8,pvVar11,2);
  local_5c = local_5c + *(byte *)((int)pvVar11 + 2);
  pvVar8 = (void *)((int)pvVar8 + (uint)*(byte *)((int)pvVar11 + 3));
  if (0x20 < local_5c) goto LAB_000378d8;
  goto LAB_000377e0;
LAB_00037c08:
  if (0x20 < local_70) goto LAB_00037a8c;
LAB_00037c10:
  if (local_6c < local_64) {
    if (local_6c == local_68) goto LAB_00037a8c;
    uVar6 = local_70 >> 3;
    bVar24 = (uint *)((int)local_6c - (local_70 >> 3)) < local_68;
    if (bVar24) {
      uVar6 = (int)local_6c - (int)local_68;
    }
    local_70 = local_70 + uVar6 * -8;
  }
  else {
    uVar6 = local_70 >> 3;
    local_70 = local_70 & 7;
    bVar24 = false;
  }
  local_6c = (uint *)((int)local_6c - uVar6);
  local_74 = *local_6c;
  if (((void *)((int)pvVar19 - 2U) < local_80) || (bVar24)) goto LAB_00037a8c;
  pvVar11 = (void *)((int)param_5 + ((local_74 << (local_70 & 0x1f)) >> uVar5) * 4 + 4);
  memcpy(local_80,pvVar11,2);
  local_70 = local_70 + *(byte *)((int)pvVar11 + 2);
  local_80 = (void *)((int)local_80 + (uint)*(byte *)((int)pvVar11 + 3));
  goto LAB_00037c08;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037cc8 FUN_00037cc8 */

uint FUN_00037cc8(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar1 = FUN_0003599c(param_1,param_4,param_5,param_6,param_7);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00036430(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
    return uVar2;
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037d44 FUN_00037d44 */

uint FUN_00037d44(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_820 [2048];
  
  uVar1 = FUN_0003599c(param_1,param_4,param_5,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_5 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00036430(param_2,param_3,param_4 + uVar1,param_5 - uVar1,param_1);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037dc4 caseD_1 */

uint switchD_00038098::caseD_1(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 local_4824;
  undefined auStack_4820 [16384];
  undefined auStack_820 [2048];
  
  __aeabi_memclr4(auStack_4820,0x4000);
  local_4824 = 0xc00000c;
  uVar1 = FUN_0003599c(&local_4824,param_3,param_4,auStack_820,0x800);
  bVar3 = 0xffffff87 < uVar1;
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffb8;
    bVar3 = param_4 <= uVar1;
  }
  if (!bVar3) {
    uVar2 = FUN_00036430(param_1,param_2,param_3 + uVar1,param_4 - uVar1,&local_4824);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037e60 FUN_00037e60 */

void FUN_00037e60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 void *param_5)

{
  undefined uStack_24;
  char local_23;
  
  memcpy(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    FUN_00035e70(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_00033ee0(param_1,param_2,param_3,param_4,param_5);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037ee0 FUN_00037ee0 */

void FUN_00037ee0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 void *param_5)

{
  undefined uStack_24;
  char local_23;
  
  memcpy(&uStack_24,param_5,4);
  if (local_23 != '\0') {
    FUN_00036430(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_00034428(param_1,param_2,param_3,param_4,param_5);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037f60 FUN_00037f60 */

bool FUN_00037f60(uint param_1,uint param_2)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  
  iVar1 = 0xf;
  if (param_2 < param_1) {
    iVar1 = FUN_0003a538(param_2 << 4,param_1);
  }
  piVar2 = (int *)(DAT_00037fbc + 0x37f98 + iVar1 * 0x18);
  uVar3 = piVar2[3] * (param_1 >> 8) + piVar2[2];
  return uVar3 + (uVar3 >> 3) < piVar2[1] * (param_1 >> 8) + *piVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00037fc0 FUN_00037fc0 */

uint FUN_00037fc0(void *param_1,uint param_2,byte *param_3,uint param_4)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  
  if (param_2 == 0) {
    return 0xffffffba;
  }
  uVar3 = 0xffffffec;
  if (param_4 <= param_2) {
    uVar3 = param_2;
    if (param_4 == param_2) {
      memcpy(param_1,param_3,param_2);
    }
    else {
      if (param_4 != 1) {
        iVar1 = 0xf;
        if (param_4 < param_2) {
          iVar1 = FUN_0003a538(param_4 << 4,param_2);
        }
        piVar2 = (int *)(DAT_0003809c + 0x38054 + iVar1 * 0x18);
        uVar3 = piVar2[3] * (param_2 >> 8) + piVar2[2];
                    /* WARNING: Could not emulate address calculation at 0x00038088 */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(DAT_000380a0 + 0x38078 +
                            (uint)(uVar3 + (uVar3 >> 3) < piVar2[1] * (param_2 >> 8) + *piVar2) * 4)
                )(param_1,param_2,param_3,param_4);
        return uVar3;
      }
      memset(param_1,(uint)*param_3,param_2);
    }
  }
  return uVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000380a4 FUN_000380a4 */

uint FUN_000380a4(undefined4 param_1,void *param_2,uint param_3,byte *param_4,uint param_5)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  undefined auStack_820 [2048];
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_3 < param_5) {
    return 0xffffffec;
  }
  if (param_5 == param_3) {
    memcpy(param_2,param_4,param_3);
  }
  else {
    if (param_5 != 1) {
      iVar1 = 0xf;
      if (param_5 < param_3) {
        iVar1 = FUN_0003a538(param_5 << 4,param_3);
      }
      piVar2 = (int *)(DAT_0003821c + 0x38154 + iVar1 * 0x18);
      uVar3 = piVar2[3] * (param_3 >> 8) + piVar2[2];
      if (piVar2[1] * (param_3 >> 8) + *piVar2 <= uVar3 + (uVar3 >> 3)) {
        uVar3 = FUN_00033cfc(param_1,param_4,param_5,auStack_820,0x800);
        if (0xffffff88 < uVar3) {
          return uVar3;
        }
        if (param_5 <= uVar3) {
          return 0xffffffb8;
        }
        uVar3 = FUN_00034428(param_2,param_3,param_4 + uVar3,param_5 - uVar3,param_1);
        return uVar3;
      }
      uVar3 = FUN_0003599c(param_1,param_4,param_5,auStack_820,0x800);
      if (0xffffff88 < uVar3) {
        return uVar3;
      }
      if (param_5 <= uVar3) {
        return 0xffffffb8;
      }
      uVar3 = FUN_00036430(param_2,param_3,param_4 + uVar3,param_5 - uVar3,param_1);
      return uVar3;
    }
    memset(param_2,(uint)*param_4,param_3);
  }
  return param_3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00038220 FUN_00038220 */

void FUN_00038220(void)

{
  FUN_0003824c();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003824c FUN_0003824c */

uint FUN_0003824c(undefined4 param_1,undefined4 param_2,uint param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_5 != 0) {
    iVar1 = 0xf;
    if (param_5 < param_3) {
      iVar1 = FUN_0003a538(param_5 << 4,param_3);
    }
    piVar3 = (int *)(DAT_0003837c + 0x382ac + iVar1 * 0x18);
    uVar4 = piVar3[3] * (param_3 >> 8) + piVar3[2];
    if (uVar4 + (uVar4 >> 3) < piVar3[1] * (param_3 >> 8) + *piVar3) {
      uVar2 = FUN_0003599c(param_1,param_4,param_5,param_6,param_7);
      uVar4 = uVar2;
      if ((uVar2 < 0xffffff89) && (uVar4 = 0xffffffb8, uVar2 < param_5)) {
        uVar4 = FUN_00036430(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
        return uVar4;
      }
    }
    else {
      uVar2 = FUN_00033cfc(param_1,param_4,param_5,param_6,param_7);
      uVar4 = uVar2;
      if ((uVar2 < 0xffffff89) && (uVar4 = 0xffffffb8, uVar2 < param_5)) {
        uVar4 = FUN_00034428(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
      }
    }
    return uVar4;
  }
  return 0xffffffec;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00038380 FUN_00038380 */

uint FUN_00038380(undefined4 param_1,void *param_2,uint param_3,byte *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_3 < param_5) {
    return 0xffffffec;
  }
  if (param_5 == param_3) {
    memcpy(param_2,param_4,param_3);
  }
  else {
    if (param_5 != 1) {
      iVar1 = 0xf;
      if (param_5 < param_3) {
        iVar1 = FUN_0003a538(param_5 << 4,param_3);
      }
      piVar3 = (int *)(DAT_000384f0 + 0x38434 + iVar1 * 0x18);
      uVar2 = piVar3[3] * (param_3 >> 8) + piVar3[2];
      if (piVar3[1] * (param_3 >> 8) + *piVar3 <= uVar2 + (uVar2 >> 3)) {
        uVar2 = FUN_00033cfc(param_1,param_4,param_5,param_6,param_7);
        if (0xffffff88 < uVar2) {
          return uVar2;
        }
        if (param_5 <= uVar2) {
          return 0xffffffb8;
        }
        uVar2 = FUN_00033ee0(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
        return uVar2;
      }
      uVar2 = FUN_0003599c(param_1,param_4,param_5,param_6,param_7);
      if (0xffffff88 < uVar2) {
        return uVar2;
      }
      if (param_5 <= uVar2) {
        return 0xffffffb8;
      }
      uVar2 = FUN_00035e70(param_2,param_3,param_4 + uVar2,param_5 - uVar2,param_1);
      return uVar2;
    }
    memset(param_2,(uint)*param_4,param_3);
  }
  return param_3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000384f4 FUN_000384f4 */

void FUN_000384f4(void)

{
  FUN_00038380();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00038538 FUN_00038538 */

uint FUN_00038538(int *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  
  piVar10 = (int *)((int)param_1 + param_2);
  if (((uint)param_1 & 3) == 0) {
    if (param_2 < 0x10) {
      iVar7 = param_3 + 0x165667b1;
    }
    else {
      uVar12 = param_3 + 0x61c8864f;
      uVar9 = param_3 + 0x85ebca77;
      uVar11 = param_3 + 0x24234428;
      do {
        piVar8 = param_1 + 3;
        piVar5 = param_1 + 2;
        uVar9 = param_1[1] * -0x7a143589 + uVar9;
        uVar11 = *param_1 * -0x7a143589 + uVar11;
        param_1 = param_1 + 4;
        param_3 = *piVar5 * -0x7a143589 + param_3;
        uVar12 = *piVar8 * -0x7a143589 + uVar12;
        uVar1 = uVar9 >> 0x13 | uVar9 * 0x2000;
        uVar2 = uVar11 >> 0x13 | uVar11 * 0x2000;
        uVar11 = uVar2 * -0x61c8864f;
        uVar3 = param_3 >> 0x13 | param_3 * 0x2000;
        param_3 = uVar3 * -0x61c8864f;
        uVar4 = uVar12 >> 0x13 | uVar12 * 0x2000;
        uVar12 = uVar4 * -0x61c8864f;
        uVar9 = uVar1 * -0x61c8864f;
      } while (param_1 <= piVar10 + -4);
      iVar7 = (uVar1 * 0x1bbcd880 | uVar9 >> 0x19) + (uVar2 * 0x3c6ef362 | uVar11 >> 0x1f) +
              (uVar3 * 0x779b1000 | param_3 >> 0x14) + (uVar12 >> 0xe | uVar4 * -0x193c0000);
    }
    param_2 = iVar7 + param_2;
    piVar8 = param_1 + 1;
    while (piVar8 <= piVar10) {
      param_2 = *param_1 * -0x3d4d51c3 + param_2;
      param_2 = (param_2 >> 0xf | param_2 * 0x20000) * 0x27d4eb2f;
      piVar8 = param_1 + 2;
      param_1 = param_1 + 1;
    }
    if (param_1 < piVar10) {
      do {
        piVar8 = (int *)((int)param_1 + 1);
        param_2 = (uint)*(byte *)param_1 * 0x165667b1 + param_2;
        param_2 = (param_2 >> 0x15 | param_2 * 0x800) * -0x61c8864f;
        param_1 = piVar8;
      } while (piVar10 != piVar8);
    }
  }
  else {
    if (param_2 < 0x10) {
      iVar7 = param_3 + 0x165667b1;
    }
    else {
      uVar12 = param_3 + 0x61c8864f;
      uVar11 = param_3 + 0x85ebca77;
      uVar9 = param_3 + 0x24234428;
      do {
        piVar8 = param_1 + 3;
        piVar5 = param_1 + 2;
        piVar6 = param_1 + 1;
        uVar9 = *param_1 * -0x7a143589 + uVar9;
        param_1 = param_1 + 4;
        param_3 = *piVar5 * -0x7a143589 + param_3;
        uVar12 = *piVar8 * -0x7a143589 + uVar12;
        uVar11 = *piVar6 * -0x7a143589 + uVar11;
        uVar1 = uVar9 >> 0x13 | uVar9 * 0x2000;
        uVar2 = param_3 >> 0x13 | param_3 * 0x2000;
        param_3 = uVar2 * -0x61c8864f;
        uVar3 = uVar12 >> 0x13 | uVar12 * 0x2000;
        uVar12 = uVar3 * -0x61c8864f;
        uVar4 = uVar11 >> 0x13 | uVar11 * 0x2000;
        uVar11 = uVar4 * -0x61c8864f;
        uVar9 = uVar1 * -0x61c8864f;
      } while (param_1 <= piVar10 + -4);
      iVar7 = (uVar4 * 0x1bbcd880 | uVar11 >> 0x19) + (uVar1 * 0x3c6ef362 | uVar9 >> 0x1f) +
              (uVar2 * 0x779b1000 | param_3 >> 0x14) + (uVar12 >> 0xe | uVar3 * -0x193c0000);
    }
    param_2 = iVar7 + param_2;
    piVar8 = param_1 + 1;
    while (piVar8 <= piVar10) {
      param_2 = *param_1 * -0x3d4d51c3 + param_2;
      param_2 = (param_2 >> 0xf | param_2 * 0x20000) * 0x27d4eb2f;
      piVar8 = param_1 + 2;
      param_1 = param_1 + 1;
    }
    if (param_1 < piVar10) {
      do {
        piVar8 = (int *)((int)param_1 + 1);
        param_2 = (uint)*(byte *)param_1 * 0x165667b1 + param_2;
        param_2 = (param_2 >> 0x15 | param_2 * 0x800) * -0x61c8864f;
        param_1 = piVar8;
      } while (piVar10 != piVar8);
    }
  }
  uVar9 = (param_2 ^ param_2 >> 0xf) * -0x7a143589;
  uVar9 = (uVar9 ^ uVar9 >> 0xd) * -0x3d4d51c3;
  return uVar9 ^ uVar9 >> 0x10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003884c FUN_0003884c */

uint FUN_0003884c(uint *param_1,uint param_2,uint param_3,uint param_4)

{
  uint *puVar1;
  uint *puVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint *puVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  int iVar24;
  uint *puVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  uint uVar34;
  uint uVar35;
  uint uVar36;
  uint uVar37;
  uint uVar38;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  uint uVar42;
  uint uVar43;
  uint uVar44;
  uint local_38;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  
  puVar25 = (uint *)((int)param_1 + param_2);
  if (((uint)param_1 & 7) == 0) {
    if (param_2 < 0x20) {
      uVar26 = param_3 + 0x165667c5;
      iVar24 = param_4 + 0x27d4eb2f + (uint)(0xe9a9983a < param_3);
    }
    else {
      uVar37 = param_3 + 0x7a143579;
      local_2c = param_4 + 0x61c8864e + (uint)(0x85ebca86 < param_3);
      local_34 = param_3 + 0x27d4eb4f;
      uVar26 = param_4 + 0xc2b2ae3d + (uint)(0xd82b14b0 < param_3);
      uVar36 = param_3 + 0xadc0b5d6;
      local_30 = param_4 + 0x60ea27ee + (uint)(0x523f4a29 < param_3);
      local_28 = param_4;
      do {
        lVar3 = (ulonglong)param_1[6] * 0x27d4eb4f;
        uVar16 = (uint)lVar3;
        uVar17 = uVar16 + uVar37;
        uVar37 = param_1[7] * 0x27d4eb4f +
                 param_1[6] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_2c +
                 (uint)CARRY4(uVar16,uVar37);
        uVar16 = uVar37 >> 1;
        uVar29 = uVar17 * -0x80000000 | uVar16;
        uVar17 = uVar17 >> 1;
        uVar11 = uVar37 * -0x80000000 | uVar17;
        uVar37 = (uint)((ulonglong)uVar29 * 0x85ebca87);
        puVar15 = param_1 + 3;
        local_2c = uVar11 * -0x7a143579 +
                   uVar29 * -0x61c8864f + (int)((ulonglong)uVar29 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)param_1[4] * 0x27d4eb4f;
        uVar18 = (uint)lVar3;
        uVar19 = uVar18 + param_3;
        uVar12 = param_1[5] * 0x27d4eb4f +
                 param_1[4] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_28 +
                 (uint)CARRY4(uVar18,param_3);
        uVar18 = uVar12 >> 1;
        uVar22 = uVar19 * -0x80000000 | uVar18;
        uVar19 = uVar19 >> 1;
        uVar13 = uVar12 * -0x80000000 | uVar19;
        param_3 = (uint)((ulonglong)uVar22 * 0x85ebca87);
        uVar14 = *param_1;
        local_28 = uVar13 * -0x7a143579 +
                   uVar22 * -0x61c8864f + (int)((ulonglong)uVar22 * 0x85ebca87 >> 0x20);
        puVar1 = param_1 + 2;
        lVar3 = (ulonglong)*puVar1 * 0x27d4eb4f;
        uVar12 = (uint)lVar3;
        puVar2 = param_1 + 1;
        param_1 = param_1 + 8;
        uVar31 = uVar12 + local_34;
        uVar26 = *puVar15 * 0x27d4eb4f + *puVar1 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 uVar26 + (uint)CARRY4(uVar12,local_34);
        uVar12 = uVar26 >> 1;
        uVar30 = uVar31 * -0x80000000 | uVar12;
        uVar31 = uVar31 >> 1;
        uVar20 = uVar26 * -0x80000000 | uVar31;
        local_34 = (uint)((ulonglong)uVar30 * 0x85ebca87);
        uVar26 = uVar20 * -0x7a143579 +
                 uVar30 * -0x61c8864f + (int)((ulonglong)uVar30 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)uVar14 * 0x27d4eb4f;
        uVar32 = (uint)lVar3;
        uVar21 = uVar32 + uVar36;
        uVar32 = *puVar2 * 0x27d4eb4f + uVar14 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 local_30 + (uint)CARRY4(uVar32,uVar36);
        uVar14 = uVar32 >> 1;
        uVar41 = uVar21 * -0x80000000 | uVar14;
        uVar36 = (uint)((ulonglong)uVar41 * 0x85ebca87);
        uVar21 = uVar21 >> 1;
        uVar32 = uVar32 * -0x80000000 | uVar21;
        local_30 = uVar32 * -0x7a143579 +
                   uVar41 * -0x61c8864f + (int)((ulonglong)uVar41 * 0x85ebca87 >> 0x20);
      } while (param_1 <= puVar25 + -8);
      uVar39 = (uint)((ulonglong)uVar41 * 0xbd7950e) | local_30 >> 0x1f;
      uVar33 = (uint)((ulonglong)uVar30 * 0xf5e54380) | uVar26 >> 0x19;
      uVar40 = uVar33 + uVar39;
      uVar34 = (uint)((ulonglong)uVar22 * 0xbca87000) | local_28 >> 0x14;
      uVar44 = uVar40 + uVar34;
      uVar37 = (uint)((ulonglong)uVar41 * 0x80000000) |
               uVar32 * 0xf796ca9 +
               uVar41 * -0x210ca4ff + (int)((ulonglong)uVar41 * 0xf796ca9 >> 0x20) >> 1;
      uVar35 = (uint)((ulonglong)uVar29 * 0x2a1c0000) | local_2c >> 0xe;
      lVar3 = (ulonglong)uVar37 * 0x85ebca87;
      uVar28 = uVar44 + uVar35 ^ (uint)lVar3;
      lVar4 = (ulonglong)uVar28 * 0x85ebca87;
      uVar38 = (uint)lVar4;
      uVar42 = (uint)((ulonglong)uVar30 * 0x80000000) |
               uVar20 * 0xf796ca9 +
               uVar30 * -0x210ca4ff + (int)((ulonglong)uVar30 * 0xf796ca9 >> 0x20) >> 1;
      lVar5 = (ulonglong)uVar42 * 0x85ebca87;
      uVar36 = uVar38 + 0xc2b2ae63 ^ (uint)lVar5;
      lVar6 = (ulonglong)uVar36 * 0x85ebca87;
      uVar32 = (uint)lVar6;
      uVar20 = (uint)((ulonglong)uVar22 * 0x80000000) |
               uVar13 * 0xf796ca9 +
               uVar22 * -0x210ca4ff + (int)((ulonglong)uVar22 * 0xf796ca9 >> 0x20) >> 1;
      lVar7 = (ulonglong)uVar20 * 0x85ebca87;
      uVar13 = uVar32 + 0xc2b2ae63 ^ (uint)lVar7;
      lVar8 = (ulonglong)uVar13 * 0x85ebca87;
      uVar23 = (uint)lVar8;
      uVar11 = (uint)((ulonglong)uVar29 * 0x80000000) |
               uVar11 * 0xf796ca9 +
               uVar29 * -0x210ca4ff + (int)((ulonglong)uVar29 * 0xf796ca9 >> 0x20) >> 1;
      lVar9 = (ulonglong)uVar11 * 0x85ebca87;
      uVar27 = uVar23 + 0xc2b2ae63 ^ (uint)lVar9;
      lVar10 = (ulonglong)uVar27 * 0x85ebca87;
      uVar43 = (uint)lVar10;
      uVar26 = uVar43 + 0xc2b2ae63;
      iVar24 = ((((uVar31 * -0xa1abc80 +
                   uVar12 * 0x1bbcd8c2 + (int)((ulonglong)uVar30 * 0xf5e54380 >> 0x20) +
                   uVar21 * 0xbd7950e +
                   uVar41 * 0x3c6ef363 + (int)((ulonglong)uVar41 * 0xbd7950e >> 0x20) +
                   (uint)CARRY4(uVar33,uVar39) +
                   uVar19 * -0x43579000 +
                   uVar18 * 0x779b185e + (int)((ulonglong)uVar22 * 0xbca87000 >> 0x20) +
                   (uint)CARRY4(uVar40,uVar34) +
                   uVar17 * 0x2a1c0000 +
                   uVar29 * -0x1939e851 + (int)((ulonglong)uVar29 * 0x2a1c0000 >> 0x20) +
                   (uint)CARRY4(uVar44,uVar35) ^
                  (uVar21 * -0x80000000 +
                  uVar14 * -0x784349ac + (int)((ulonglong)uVar41 * 0x80000000 >> 0x20)) *
                  -0x7a143579 + uVar37 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20)) *
                  -0x7a143579 + uVar28 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20) + -0x7a143589
                  + (uint)(0x3d4d519c < uVar38) ^
                 (uVar31 * -0x80000000 +
                 uVar12 * -0x784349ac + (int)((ulonglong)uVar30 * 0x80000000 >> 0x20)) * -0x7a143579
                 + uVar42 * -0x61c8864f + (int)((ulonglong)lVar5 >> 0x20)) * -0x7a143579 +
                 uVar36 * -0x61c8864f + (int)((ulonglong)lVar6 >> 0x20) + -0x7a143589 +
                 (uint)(0x3d4d519c < uVar32) ^
                (uVar19 * -0x80000000 +
                uVar18 * -0x784349ac + (int)((ulonglong)uVar22 * 0x80000000 >> 0x20)) * -0x7a143579
                + uVar20 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20)) * -0x7a143579 +
                uVar13 * -0x61c8864f + (int)((ulonglong)lVar8 >> 0x20) + -0x7a143589 +
                (uint)(0x3d4d519c < uVar23) ^
               (uVar17 * -0x80000000 +
               uVar16 * -0x784349ac + (int)((ulonglong)uVar29 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar11 * -0x61c8864f + (int)((ulonglong)lVar9 >> 0x20)) * -0x7a143579 +
               uVar27 * -0x61c8864f + (int)((ulonglong)lVar10 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar43);
    }
    uVar37 = uVar26 + param_2;
    uVar26 = iVar24 + (uint)CARRY4(uVar26,param_2);
    puVar15 = param_1 + 2;
    while (puVar15 <= puVar25) {
      uVar17 = *param_1;
      uVar36 = (uint)((ulonglong)uVar17 * 0x80000000) |
               param_1[1] * 0x27d4eb4f +
               uVar17 * -0x3d4d51c3 + (int)((ulonglong)uVar17 * 0x27d4eb4f >> 0x20) >> 1;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar16 = (uint)lVar3 ^ uVar37;
      uVar26 = (param_1[1] * -0x80000000 +
               uVar17 * -0x6c158a59 + (int)((ulonglong)uVar17 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar36 = uVar16 << 0x1b | uVar26 >> 5;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0xc2b2ae63;
      uVar26 = (uVar26 << 0x1b | uVar16 >> 5) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar17);
      puVar15 = param_1 + 4;
      param_1 = param_1 + 2;
    }
    if (param_1 + 1 <= puVar25) {
      lVar3 = (ulonglong)*param_1 * 0x85ebca87;
      uVar36 = (uint)lVar3 ^ uVar37;
      uVar26 = *param_1 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar16 = uVar36 << 0x17 | uVar26 >> 9;
      lVar3 = (ulonglong)uVar16 * 0x27d4eb4f;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0x9e3779f9;
      uVar26 = (uVar26 << 0x17 | uVar36 >> 9) * 0x27d4eb4f +
               uVar16 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + 0x165667b1 +
               (uint)(0x61c88606 < uVar17);
      param_1 = param_1 + 1;
    }
    if (param_1 < puVar25) {
      do {
        puVar15 = (uint *)((int)param_1 + 1);
        lVar3 = (ulonglong)(uint)*(byte *)param_1 * 0x165667c5;
        uVar16 = (uint)lVar3 ^ uVar37;
        uVar26 = (uint)*(byte *)param_1 * 0x27d4eb2f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
        uVar36 = uVar16 << 0xb | uVar26 >> 0x15;
        lVar3 = (ulonglong)uVar36 * 0x85ebca87;
        uVar37 = (uint)lVar3;
        uVar26 = (uVar26 << 0xb | uVar16 >> 0x15) * -0x7a143579 +
                 uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20);
        param_1 = puVar15;
      } while (puVar25 != puVar15);
    }
  }
  else {
    if (param_2 < 0x20) {
      uVar26 = param_3 + 0x165667c5;
      iVar24 = param_4 + 0x27d4eb2f + (uint)(0xe9a9983a < param_3);
    }
    else {
      uVar37 = param_3 + 0x7a143579;
      local_2c = param_4 + 0x61c8864e + (uint)(0x85ebca86 < param_3);
      local_34 = param_3 + 0x27d4eb4f;
      local_30 = param_4 + 0xc2b2ae3d + (uint)(0xd82b14b0 < param_3);
      uVar26 = param_3 + 0xadc0b5d6;
      uVar36 = param_4 + 0x60ea27ee + (uint)(0x523f4a29 < param_3);
      local_38 = param_3;
      local_28 = param_4;
      do {
        lVar3 = (ulonglong)param_1[6] * 0x27d4eb4f;
        uVar16 = (uint)lVar3;
        uVar17 = uVar16 + uVar37;
        puVar15 = param_1 + 3;
        uVar37 = param_1[7] * 0x27d4eb4f +
                 param_1[6] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_2c +
                 (uint)CARRY4(uVar16,uVar37);
        uVar16 = uVar37 >> 1;
        uVar29 = uVar17 * -0x80000000 | uVar16;
        uVar17 = uVar17 >> 1;
        uVar11 = uVar37 * -0x80000000 | uVar17;
        uVar37 = (uint)((ulonglong)uVar29 * 0x85ebca87);
        local_2c = uVar11 * -0x7a143579 +
                   uVar29 * -0x61c8864f + (int)((ulonglong)uVar29 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)param_1[4] * 0x27d4eb4f;
        uVar18 = (uint)lVar3;
        uVar19 = uVar18 + local_38;
        uVar12 = param_1[5] * 0x27d4eb4f +
                 param_1[4] * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + local_28 +
                 (uint)CARRY4(uVar18,local_38);
        uVar18 = uVar12 >> 1;
        uVar30 = uVar19 * -0x80000000 | uVar18;
        uVar19 = uVar19 >> 1;
        uVar13 = uVar12 * -0x80000000 | uVar19;
        local_38 = (uint)((ulonglong)uVar30 * 0x85ebca87);
        puVar1 = param_1 + 1;
        local_28 = uVar13 * -0x7a143579 +
                   uVar30 * -0x61c8864f + (int)((ulonglong)uVar30 * 0x85ebca87 >> 0x20);
        puVar2 = param_1 + 2;
        lVar3 = (ulonglong)*puVar2 * 0x27d4eb4f;
        uVar12 = (uint)lVar3;
        uVar14 = *param_1;
        uVar31 = uVar12 + local_34;
        param_1 = param_1 + 8;
        uVar21 = *puVar15 * 0x27d4eb4f + *puVar2 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 local_30 + (uint)CARRY4(uVar12,local_34);
        uVar12 = uVar21 >> 1;
        uVar41 = uVar31 * -0x80000000 | uVar12;
        uVar31 = uVar31 >> 1;
        uVar22 = uVar21 * -0x80000000 | uVar31;
        local_34 = (uint)((ulonglong)uVar41 * 0x85ebca87);
        local_30 = uVar22 * -0x7a143579 +
                   uVar41 * -0x61c8864f + (int)((ulonglong)uVar41 * 0x85ebca87 >> 0x20);
        lVar3 = (ulonglong)uVar14 * 0x27d4eb4f;
        uVar32 = (uint)lVar3;
        uVar21 = uVar32 + uVar26;
        uVar26 = *puVar1 * 0x27d4eb4f + uVar14 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) +
                 uVar36 + (uint)CARRY4(uVar32,uVar26);
        uVar14 = uVar26 >> 1;
        uVar32 = uVar21 * -0x80000000 | uVar14;
        uVar21 = uVar21 >> 1;
        uVar20 = uVar26 * -0x80000000 | uVar21;
        uVar26 = (uint)((ulonglong)uVar32 * 0x85ebca87);
        uVar36 = uVar20 * -0x7a143579 +
                 uVar32 * -0x61c8864f + (int)((ulonglong)uVar32 * 0x85ebca87 >> 0x20);
      } while (param_1 <= puVar25 + -8);
      uVar27 = (uint)((ulonglong)uVar41 * 0xf5e54380) | local_30 >> 0x19;
      uVar33 = (uint)((ulonglong)uVar32 * 0xbd7950e) | uVar36 >> 0x1f;
      uVar42 = uVar27 + uVar33;
      uVar34 = (uint)((ulonglong)uVar30 * 0xbca87000) | local_28 >> 0x14;
      uVar43 = uVar42 + uVar34;
      uVar44 = (uint)((ulonglong)uVar32 * 0x80000000) |
               uVar20 * 0xf796ca9 +
               uVar32 * -0x210ca4ff + (int)((ulonglong)uVar32 * 0xf796ca9 >> 0x20) >> 1;
      uVar38 = (uint)((ulonglong)uVar29 * 0x2a1c0000) | local_2c >> 0xe;
      lVar3 = (ulonglong)uVar44 * 0x85ebca87;
      uVar28 = uVar43 + uVar38 ^ (uint)lVar3;
      lVar4 = (ulonglong)uVar28 * 0x85ebca87;
      uVar35 = (uint)lVar4;
      uVar39 = (uint)((ulonglong)uVar41 * 0x80000000) |
               uVar22 * 0xf796ca9 +
               uVar41 * -0x210ca4ff + (int)((ulonglong)uVar41 * 0xf796ca9 >> 0x20) >> 1;
      lVar5 = (ulonglong)uVar39 * 0x85ebca87;
      uVar37 = uVar35 + 0xc2b2ae63 ^ (uint)lVar5;
      lVar6 = (ulonglong)uVar37 * 0x85ebca87;
      uVar20 = (uint)lVar6;
      uVar13 = (uint)((ulonglong)uVar30 * 0x80000000) |
               uVar13 * 0xf796ca9 +
               uVar30 * -0x210ca4ff + (int)((ulonglong)uVar30 * 0xf796ca9 >> 0x20) >> 1;
      lVar7 = (ulonglong)uVar13 * 0x85ebca87;
      uVar36 = uVar20 + 0xc2b2ae63 ^ (uint)lVar7;
      lVar8 = (ulonglong)uVar36 * 0x85ebca87;
      uVar22 = (uint)lVar8;
      uVar11 = (uint)((ulonglong)uVar29 * 0x80000000) |
               uVar11 * 0xf796ca9 +
               uVar29 * -0x210ca4ff + (int)((ulonglong)uVar29 * 0xf796ca9 >> 0x20) >> 1;
      lVar9 = (ulonglong)uVar11 * 0x85ebca87;
      uVar23 = uVar22 + 0xc2b2ae63 ^ (uint)lVar9;
      lVar10 = (ulonglong)uVar23 * 0x85ebca87;
      uVar40 = (uint)lVar10;
      uVar26 = uVar40 + 0xc2b2ae63;
      iVar24 = ((((uVar31 * -0xa1abc80 +
                   uVar12 * 0x1bbcd8c2 + (int)((ulonglong)uVar41 * 0xf5e54380 >> 0x20) +
                   uVar21 * 0xbd7950e +
                   uVar32 * 0x3c6ef363 + (int)((ulonglong)uVar32 * 0xbd7950e >> 0x20) +
                   (uint)CARRY4(uVar27,uVar33) +
                   uVar19 * -0x43579000 +
                   uVar18 * 0x779b185e + (int)((ulonglong)uVar30 * 0xbca87000 >> 0x20) +
                   (uint)CARRY4(uVar42,uVar34) +
                   uVar17 * 0x2a1c0000 +
                   uVar29 * -0x1939e851 + (int)((ulonglong)uVar29 * 0x2a1c0000 >> 0x20) +
                   (uint)CARRY4(uVar43,uVar38) ^
                  (uVar21 * -0x80000000 +
                  uVar14 * -0x784349ac + (int)((ulonglong)uVar32 * 0x80000000 >> 0x20)) *
                  -0x7a143579 + uVar44 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20)) *
                  -0x7a143579 + uVar28 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20) + -0x7a143589
                  + (uint)(0x3d4d519c < uVar35) ^
                 (uVar31 * -0x80000000 +
                 uVar12 * -0x784349ac + (int)((ulonglong)uVar41 * 0x80000000 >> 0x20)) * -0x7a143579
                 + uVar39 * -0x61c8864f + (int)((ulonglong)lVar5 >> 0x20)) * -0x7a143579 +
                 uVar37 * -0x61c8864f + (int)((ulonglong)lVar6 >> 0x20) + -0x7a143589 +
                 (uint)(0x3d4d519c < uVar20) ^
                (uVar19 * -0x80000000 +
                uVar18 * -0x784349ac + (int)((ulonglong)uVar30 * 0x80000000 >> 0x20)) * -0x7a143579
                + uVar13 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20)) * -0x7a143579 +
                uVar36 * -0x61c8864f + (int)((ulonglong)lVar8 >> 0x20) + -0x7a143589 +
                (uint)(0x3d4d519c < uVar22) ^
               (uVar17 * -0x80000000 +
               uVar16 * -0x784349ac + (int)((ulonglong)uVar29 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar11 * -0x61c8864f + (int)((ulonglong)lVar9 >> 0x20)) * -0x7a143579 +
               uVar23 * -0x61c8864f + (int)((ulonglong)lVar10 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar40);
    }
    uVar37 = uVar26 + param_2;
    uVar26 = iVar24 + (uint)CARRY4(uVar26,param_2);
    puVar15 = param_1 + 2;
    while (puVar15 <= puVar25) {
      uVar17 = *param_1;
      uVar36 = (uint)((ulonglong)uVar17 * 0x80000000) |
               param_1[1] * 0x27d4eb4f +
               uVar17 * -0x3d4d51c3 + (int)((ulonglong)uVar17 * 0x27d4eb4f >> 0x20) >> 1;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar16 = (uint)lVar3 ^ uVar37;
      uVar26 = (param_1[1] * -0x80000000 +
               uVar17 * -0x6c158a59 + (int)((ulonglong)uVar17 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar36 = uVar16 << 0x1b | uVar26 >> 5;
      lVar3 = (ulonglong)uVar36 * 0x85ebca87;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0xc2b2ae63;
      uVar26 = (uVar26 << 0x1b | uVar16 >> 5) * -0x7a143579 +
               uVar36 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar17);
      puVar15 = param_1 + 4;
      param_1 = param_1 + 2;
    }
    if (param_1 + 1 <= puVar25) {
      lVar3 = (ulonglong)*param_1 * 0x85ebca87;
      uVar36 = (uint)lVar3 ^ uVar37;
      uVar26 = *param_1 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
      uVar16 = uVar36 << 0x17 | uVar26 >> 9;
      lVar3 = (ulonglong)uVar16 * 0x27d4eb4f;
      uVar17 = (uint)lVar3;
      uVar37 = uVar17 + 0x9e3779f9;
      uVar26 = (uVar26 << 0x17 | uVar36 >> 9) * 0x27d4eb4f +
               uVar16 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20) + 0x165667b1 +
               (uint)(0x61c88606 < uVar17);
      param_1 = param_1 + 1;
    }
    if (param_1 < puVar25) {
      do {
        puVar15 = (uint *)((int)param_1 + 1);
        lVar3 = (ulonglong)(uint)*(byte *)param_1 * 0x165667c5;
        uVar36 = (uint)lVar3 ^ uVar37;
        uVar26 = (uint)*(byte *)param_1 * 0x27d4eb2f + (int)((ulonglong)lVar3 >> 0x20) ^ uVar26;
        uVar16 = uVar36 << 0xb | uVar26 >> 0x15;
        lVar3 = (ulonglong)uVar16 * 0x85ebca87;
        uVar37 = (uint)lVar3;
        uVar26 = (uVar26 << 0xb | uVar36 >> 0x15) * -0x7a143579 +
                 uVar16 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20);
        param_1 = puVar15;
      } while (puVar25 != puVar15);
    }
  }
  uVar37 = uVar37 ^ uVar26 >> 1;
  lVar3 = (ulonglong)uVar37 * 0x27d4eb4f;
  uVar36 = (uint)lVar3;
  uVar26 = uVar26 * 0x27d4eb4f + uVar37 * -0x3d4d51c3 + (int)((ulonglong)lVar3 >> 0x20);
  uVar36 = (uVar36 >> 0x1d | uVar26 * 8) ^ uVar36;
  lVar3 = (ulonglong)uVar36 * 0x9e3779f9;
  return (uVar26 ^ uVar26 >> 0x1d) * -0x61c88607 +
         uVar36 * 0x165667b1 + (int)((ulonglong)lVar3 >> 0x20) ^ (uint)lVar3;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000395e8 FUN_000395e8 */

undefined4 FUN_000395e8(void *param_1,int param_2)

{
  undefined auStack_48 [8];
  int local_40;
  int local_3c;
  int local_38;
  int local_34;
  
  memset(auStack_48,0,0x2c);
  local_34 = param_2 + 0x61c8864f;
  local_3c = param_2 + -0x7a143589;
  local_40 = param_2 + 0x24234428;
  local_38 = param_2;
  memcpy(param_1,auStack_48,0x30);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00039660 FUN_00039660 */

undefined4 FUN_00039660(void *param_1,undefined4 param_2,uint param_3,int param_4)

{
  undefined auStack_70 [8];
  int local_68;
  int local_64;
  int local_60;
  int local_5c;
  uint local_58;
  int local_54;
  int local_50;
  int local_4c;
  
  memset(auStack_70,0,0x50);
  local_50 = param_3 + 0x7a143579;
  local_4c = param_4 + 0x61c8864e + (uint)(0x85ebca86 < param_3);
  local_60 = param_3 + 0x27d4eb4f;
  local_5c = param_4 + -0x3d4d51c3 + (uint)(0xd82b14b0 < param_3);
  local_68 = param_3 + 0xadc0b5d6;
  local_64 = param_4 + 0x60ea27ee + (uint)(0x523f4a29 < param_3);
  local_58 = param_3;
  local_54 = param_4;
  memcpy(param_1,auStack_70,0x58);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00039710 FUN_00039710 */

undefined4 FUN_00039710(uint *param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  
  uVar5 = param_1[1];
  uVar4 = param_1[10];
  if (0xf < (*param_1 + param_3 | param_3)) {
    uVar5 = uVar5 | 1;
  }
  *param_1 = *param_1 + param_3;
  param_1[1] = uVar5;
  if (uVar4 + param_3 < 0x10) {
    memcpy((void *)((int)param_1 + uVar4 + 0x18),param_2,param_3);
    param_3 = param_1[10] + param_3;
  }
  else {
    piVar9 = (int *)((int)param_2 + param_3);
    if (uVar4 != 0) {
      memcpy((void *)((int)param_1 + uVar4 + 0x18),param_2,0x10 - uVar4);
      uVar4 = param_1[9] * -0x7a143589 + param_1[5];
      uVar5 = param_1[6] * -0x7a143589 + param_1[2];
      uVar6 = param_1[7] * -0x7a143589 + param_1[3];
      uVar7 = param_1[8] * -0x7a143589 + param_1[4];
      uVar8 = param_1[10];
      param_1[10] = 0;
      param_1[2] = (uVar5 >> 0x13 | uVar5 * 0x2000) * -0x61c8864f;
      param_1[3] = (uVar6 >> 0x13 | uVar6 * 0x2000) * -0x61c8864f;
      param_1[4] = (uVar7 >> 0x13 | uVar7 * 0x2000) * -0x61c8864f;
      param_1[5] = (uVar4 >> 0x13 | uVar4 * 0x2000) * -0x61c8864f;
      param_2 = (int *)((int)param_2 + (0x10 - uVar8));
    }
    if (param_2 <= piVar9 + -4) {
      uVar4 = param_1[2];
      uVar7 = param_1[3];
      uVar6 = param_1[4];
      uVar5 = param_1[5];
      do {
        piVar1 = param_2 + 2;
        iVar3 = *param_2;
        piVar2 = param_2 + 1;
        uVar5 = param_2[3] * -0x7a143589 + uVar5;
        param_2 = param_2 + 4;
        uVar6 = *piVar1 * -0x7a143589 + uVar6;
        uVar4 = iVar3 * -0x7a143589 + uVar4;
        uVar7 = *piVar2 * -0x7a143589 + uVar7;
        uVar5 = (uVar5 >> 0x13 | uVar5 * 0x2000) * -0x61c8864f;
        uVar6 = (uVar6 >> 0x13 | uVar6 * 0x2000) * -0x61c8864f;
        uVar4 = (uVar4 >> 0x13 | uVar4 * 0x2000) * -0x61c8864f;
        uVar7 = (uVar7 >> 0x13 | uVar7 * 0x2000) * -0x61c8864f;
      } while (param_2 <= piVar9 + -4);
      param_1[2] = uVar4;
      param_1[3] = uVar7;
      param_1[4] = uVar6;
      param_1[5] = uVar5;
    }
    if (piVar9 <= param_2) {
      return 0;
    }
    param_3 = (int)piVar9 - (int)param_2;
    memcpy(param_1 + 6,param_2,param_3);
  }
  param_1[10] = param_3;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000398bc FUN_000398bc */

uint FUN_000398bc(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)((int)(param_1 + 6) + param_1[10]);
  if (param_1[1] == 0) {
    iVar2 = param_1[4] + 0x165667b1;
  }
  else {
    iVar2 = ((uint)param_1[3] >> 0x19 | param_1[3] << 7) +
            ((uint)param_1[2] >> 0x1f | param_1[2] << 1) +
            ((uint)param_1[4] >> 0x14 | param_1[4] << 0xc) +
            ((uint)param_1[5] >> 0xe | param_1[5] << 0x12);
  }
  uVar3 = *param_1 + iVar2;
  piVar4 = param_1 + 7;
  piVar5 = param_1 + 6;
  while (piVar4 <= piVar1) {
    uVar3 = *piVar5 * -0x3d4d51c3 + uVar3;
    uVar3 = (uVar3 >> 0xf | uVar3 * 0x20000) * 0x27d4eb2f;
    piVar4 = piVar5 + 2;
    piVar5 = piVar5 + 1;
  }
  if (piVar5 < piVar1) {
    do {
      piVar1 = (int *)((int)piVar5 + 1);
      uVar3 = (uint)*(byte *)piVar5 * 0x165667b1 + uVar3;
      uVar3 = (uVar3 >> 0x15 | uVar3 * 0x800) * -0x61c8864f;
      piVar5 = piVar1;
    } while ((int *)((int)param_1 + param_1[10] + 0x18) != piVar1);
  }
  uVar3 = (uVar3 ^ uVar3 >> 0xf) * -0x7a143589;
  uVar3 = (uVar3 ^ uVar3 >> 0xd) * -0x3d4d51c3;
  return uVar3 ^ uVar3 >> 0x10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000399ac FUN_000399ac */

undefined4 FUN_000399ac(uint *param_1,uint *param_2,uint param_3)

{
  uint *puVar1;
  uint *puVar2;
  uint *puVar3;
  longlong lVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint uVar11;
  uint *__dest;
  uint *puVar12;
  uint uVar13;
  uint *puVar14;
  uint *puVar15;
  uint uVar16;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  
  uVar5 = *param_1;
  uVar6 = param_1[0x12];
  *param_1 = uVar5 + param_3;
  param_1[1] = param_1[1] + (uint)CARRY4(uVar5,param_3);
  if (uVar6 + param_3 < 0x20) {
    memcpy((void *)((int)param_1 + uVar6 + 0x28),param_2,param_3);
    param_3 = param_1[0x12] + param_3;
  }
  else {
    puVar7 = (uint *)((int)param_2 + param_3);
    puVar12 = param_1 + 2;
    __dest = param_1 + 10;
    puVar15 = param_1 + 4;
    puVar14 = param_1 + 6;
    puVar10 = param_1 + 8;
    if (uVar6 != 0) {
      memcpy((void *)((int)__dest + uVar6),param_2,0x20 - uVar6);
      lVar4 = (ulonglong)*__dest * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar6 = uVar5 + *puVar12;
      uVar5 = param_1[0xb] * 0x27d4eb4f + *__dest * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) +
              param_1[3] + (uint)CARRY4(uVar5,*puVar12);
      uVar8 = uVar6 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar8 * 0x85ebca87;
      *puVar12 = (uint)lVar4;
      param_1[3] = (uVar5 * -0x80000000 | uVar6 >> 1) * -0x7a143579 +
                   uVar8 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      lVar4 = (ulonglong)param_1[0xc] * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar8 = uVar5 + *puVar15;
      uVar5 = param_1[0xd] * 0x27d4eb4f +
              param_1[0xc] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + param_1[5] +
              (uint)CARRY4(uVar5,*puVar15);
      uVar6 = uVar8 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar6 * 0x85ebca87;
      *puVar15 = (uint)lVar4;
      param_1[5] = (uVar5 * -0x80000000 | uVar8 >> 1) * -0x7a143579 +
                   uVar6 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      lVar4 = (ulonglong)param_1[0xe] * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar8 = uVar5 + *puVar14;
      uVar5 = param_1[0xf] * 0x27d4eb4f +
              param_1[0xe] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + param_1[7] +
              (uint)CARRY4(uVar5,*puVar14);
      uVar6 = uVar8 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar6 * 0x85ebca87;
      *puVar14 = (uint)lVar4;
      param_1[7] = (uVar5 * -0x80000000 | uVar8 >> 1) * -0x7a143579 +
                   uVar6 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      lVar4 = (ulonglong)param_1[0x10] * 0x27d4eb4f;
      uVar5 = (uint)lVar4;
      uVar8 = uVar5 + *puVar10;
      uVar5 = param_1[0x11] * 0x27d4eb4f +
              param_1[0x10] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + param_1[9] +
              (uint)CARRY4(uVar5,*puVar10);
      uVar6 = uVar8 * -0x80000000 | uVar5 >> 1;
      lVar4 = (ulonglong)uVar6 * 0x85ebca87;
      *puVar10 = (uint)lVar4;
      param_1[9] = (uVar5 * -0x80000000 | uVar8 >> 1) * -0x7a143579 +
                   uVar6 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      uVar5 = param_1[0x12];
      param_1[0x12] = 0;
      param_2 = (uint *)((int)param_2 + (0x20 - uVar5));
    }
    if (param_2 + 8 <= puVar7) {
      local_30 = *puVar10;
      local_34 = param_1[9];
      local_2c = param_1[7];
      uVar5 = *puVar14;
      local_28 = *puVar15;
      uVar8 = param_1[5];
      uVar6 = *puVar12;
      uVar16 = param_1[3];
      do {
        lVar4 = (ulonglong)param_2[6] * 0x27d4eb4f;
        uVar13 = (uint)lVar4;
        uVar11 = uVar13 + local_30;
        puVar1 = param_2 + 1;
        uVar9 = param_2[7] * 0x27d4eb4f + param_2[6] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20)
                + local_34 + (uint)CARRY4(uVar13,local_30);
        uVar13 = uVar11 * -0x80000000 | uVar9 >> 1;
        lVar4 = (ulonglong)uVar13 * 0x85ebca87;
        local_30 = (uint)lVar4;
        local_34 = (uVar9 * -0x80000000 | uVar11 >> 1) * -0x7a143579 +
                   uVar13 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
        lVar4 = (ulonglong)param_2[4] * 0x27d4eb4f;
        uVar13 = (uint)lVar4;
        uVar9 = uVar13 + uVar5;
        uVar11 = param_2[5] * 0x27d4eb4f +
                 param_2[4] * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) + local_2c +
                 (uint)CARRY4(uVar13,uVar5);
        uVar13 = uVar9 * -0x80000000 | uVar11 >> 1;
        puVar2 = param_2 + 2;
        lVar4 = (ulonglong)uVar13 * 0x85ebca87;
        uVar5 = (uint)lVar4;
        puVar3 = param_2 + 3;
        local_2c = (uVar11 * -0x80000000 | uVar9 >> 1) * -0x7a143579 +
                   uVar13 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
        uVar11 = *param_2;
        param_2 = param_2 + 8;
        lVar4 = (ulonglong)*puVar2 * 0x27d4eb4f;
        uVar13 = (uint)lVar4;
        uVar9 = uVar13 + local_28;
        uVar8 = *puVar3 * 0x27d4eb4f + *puVar2 * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) +
                uVar8 + (uint)CARRY4(uVar13,local_28);
        uVar13 = uVar9 * -0x80000000 | uVar8 >> 1;
        lVar4 = (ulonglong)uVar13 * 0x85ebca87;
        local_28 = (uint)lVar4;
        uVar8 = (uVar8 * -0x80000000 | uVar9 >> 1) * -0x7a143579 +
                uVar13 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
        lVar4 = (ulonglong)uVar11 * 0x27d4eb4f;
        uVar13 = (uint)lVar4;
        uVar9 = uVar13 + uVar6;
        uVar16 = *puVar1 * 0x27d4eb4f + uVar11 * -0x3d4d51c3 + (int)((ulonglong)lVar4 >> 0x20) +
                 uVar16 + (uint)CARRY4(uVar13,uVar6);
        uVar13 = uVar9 * -0x80000000 | uVar16 >> 1;
        lVar4 = (ulonglong)uVar13 * 0x85ebca87;
        uVar6 = (uint)lVar4;
        uVar16 = (uVar16 * -0x80000000 | uVar9 >> 1) * -0x7a143579 +
                 uVar13 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20);
      } while (param_2 <= puVar7 + -8);
      *puVar12 = uVar6;
      param_1[3] = uVar16;
      *puVar15 = local_28;
      param_1[5] = uVar8;
      *puVar14 = uVar5;
      param_1[7] = local_2c;
      *puVar10 = local_30;
      param_1[9] = local_34;
    }
    if (puVar7 <= param_2) {
      return 0;
    }
    param_3 = (int)puVar7 - (int)param_2;
    memcpy(__dest,param_2,param_3);
  }
  param_1[0x12] = param_3;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00039e88 FUN_00039e88 */

uint FUN_00039e88(uint *param_1)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint *puVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  int iVar34;
  uint *puVar35;
  uint uVar36;
  uint *puVar37;
  uint uVar38;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  
  uVar17 = *param_1;
  uVar22 = param_1[1];
  puVar37 = (uint *)((int)(param_1 + 10) + param_1[0x12]);
  if (uVar22 == 0 && (0x1f < uVar17) <= uVar22) {
    uVar9 = param_1[6];
    uVar13 = uVar9 + 0x165667c5;
    iVar34 = param_1[7] + 0x27d4eb2f + (uint)(0xe9a9983a < uVar9);
  }
  else {
    uVar9 = param_1[2];
    uVar21 = param_1[3];
    uVar18 = param_1[5];
    uVar38 = param_1[4];
    uVar26 = uVar9 << 1 | uVar21 >> 0x1f;
    uVar27 = uVar38 << 7 | uVar18 >> 0x19;
    uVar40 = uVar27 + uVar26;
    uVar19 = param_1[7];
    uVar23 = param_1[6];
    uVar28 = uVar23 << 0xc | uVar19 >> 0x14;
    uVar24 = uVar40 + uVar28;
    uVar36 = (uint)((ulonglong)uVar9 * 0x80000000) |
             uVar21 * 0x27d4eb4f +
             uVar9 * -0x3d4d51c3 + (int)((ulonglong)uVar9 * 0x27d4eb4f >> 0x20) >> 1;
    uVar20 = param_1[8];
    uVar15 = param_1[9];
    uVar29 = uVar20 << 0x12 | uVar15 >> 0xe;
    lVar1 = (ulonglong)uVar36 * 0x85ebca87;
    uVar30 = uVar24 + uVar29 ^ (uint)lVar1;
    lVar2 = (ulonglong)uVar30 * 0x85ebca87;
    uVar25 = (uint)lVar2;
    uVar10 = (uint)((ulonglong)uVar38 * 0x80000000) |
             uVar18 * 0x27d4eb4f +
             uVar38 * -0x3d4d51c3 + (int)((ulonglong)uVar38 * 0x27d4eb4f >> 0x20) >> 1;
    lVar3 = (ulonglong)uVar10 * 0x85ebca87;
    uVar31 = uVar25 + 0xc2b2ae63 ^ (uint)lVar3;
    lVar4 = (ulonglong)uVar31 * 0x85ebca87;
    uVar41 = (uint)lVar4;
    uVar11 = (uint)((ulonglong)uVar23 * 0x80000000) |
             uVar19 * 0x27d4eb4f +
             uVar23 * -0x3d4d51c3 + (int)((ulonglong)uVar23 * 0x27d4eb4f >> 0x20) >> 1;
    lVar5 = (ulonglong)uVar11 * 0x85ebca87;
    uVar32 = uVar41 + 0xc2b2ae63 ^ (uint)lVar5;
    lVar6 = (ulonglong)uVar32 * 0x85ebca87;
    uVar39 = (uint)lVar6;
    uVar12 = (uint)((ulonglong)uVar20 * 0x80000000) |
             uVar15 * 0x27d4eb4f +
             uVar20 * -0x3d4d51c3 + (int)((ulonglong)uVar20 * 0x27d4eb4f >> 0x20) >> 1;
    lVar7 = (ulonglong)uVar12 * 0x85ebca87;
    uVar33 = uVar39 + 0xc2b2ae63 ^ (uint)lVar7;
    lVar8 = (ulonglong)uVar33 * 0x85ebca87;
    uVar16 = (uint)lVar8;
    uVar13 = uVar16 + 0xc2b2ae63;
    iVar34 = (((((uVar18 << 7 | uVar38 >> 0x19) + (uVar21 << 1 | uVar9 >> 0x1f) +
                 (uint)CARRY4(uVar27,uVar26) + (uVar19 << 0xc | uVar23 >> 0x14) +
                 (uint)CARRY4(uVar40,uVar28) + (uVar15 << 0x12 | uVar20 >> 0xe) +
                 (uint)CARRY4(uVar24,uVar29) ^
                (uVar21 * -0x80000000 +
                uVar9 * -0x6c158a59 + (int)((ulonglong)uVar9 * 0x80000000 >> 0x20)) * -0x7a143579 +
                uVar36 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20)) * -0x7a143579 +
                uVar30 * -0x61c8864f + (int)((ulonglong)lVar2 >> 0x20) + -0x7a143589 +
                (uint)(0x3d4d519c < uVar25) ^
               (uVar18 * -0x80000000 +
               uVar38 * -0x6c158a59 + (int)((ulonglong)uVar38 * 0x80000000 >> 0x20)) * -0x7a143579 +
               uVar10 * -0x61c8864f + (int)((ulonglong)lVar3 >> 0x20)) * -0x7a143579 +
               uVar31 * -0x61c8864f + (int)((ulonglong)lVar4 >> 0x20) + -0x7a143589 +
               (uint)(0x3d4d519c < uVar41) ^
              (uVar19 * -0x80000000 +
              uVar23 * -0x6c158a59 + (int)((ulonglong)uVar23 * 0x80000000 >> 0x20)) * -0x7a143579 +
              uVar11 * -0x61c8864f + (int)((ulonglong)lVar5 >> 0x20)) * -0x7a143579 +
              uVar32 * -0x61c8864f + (int)((ulonglong)lVar6 >> 0x20) + -0x7a143589 +
              (uint)(0x3d4d519c < uVar39) ^
             (uVar15 * -0x80000000 +
             uVar20 * -0x6c158a59 + (int)((ulonglong)uVar20 * 0x80000000 >> 0x20)) * -0x7a143579 +
             uVar12 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20)) * -0x7a143579 +
             uVar33 * -0x61c8864f + (int)((ulonglong)lVar8 >> 0x20) + -0x7a143589 +
             (uint)(0x3d4d519c < uVar16);
  }
  uVar9 = uVar13 + uVar17;
  uVar17 = iVar34 + uVar22 + (uint)CARRY4(uVar13,uVar17);
  puVar14 = param_1 + 0xc;
  puVar35 = param_1 + 10;
  while (puVar14 <= puVar37) {
    uVar22 = *puVar35;
    uVar13 = (uint)((ulonglong)uVar22 * 0x80000000) |
             puVar35[1] * 0x27d4eb4f +
             uVar22 * -0x3d4d51c3 + (int)((ulonglong)uVar22 * 0x27d4eb4f >> 0x20) >> 1;
    lVar1 = (ulonglong)uVar13 * 0x85ebca87;
    uVar10 = (uint)lVar1 ^ uVar9;
    uVar17 = (puVar35[1] * -0x80000000 +
             uVar22 * -0x6c158a59 + (int)((ulonglong)uVar22 * 0x80000000 >> 0x20)) * -0x7a143579 +
             uVar13 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20) ^ uVar17;
    uVar22 = uVar10 << 0x1b | uVar17 >> 5;
    lVar1 = (ulonglong)uVar22 * 0x85ebca87;
    uVar13 = (uint)lVar1;
    uVar9 = uVar13 + 0xc2b2ae63;
    uVar17 = (uVar17 << 0x1b | uVar10 >> 5) * -0x7a143579 +
             uVar22 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20) + -0x7a143589 +
             (uint)(0x3d4d519c < uVar13);
    puVar14 = puVar35 + 4;
    puVar35 = puVar35 + 2;
  }
  if (puVar35 + 1 <= puVar37) {
    lVar1 = (ulonglong)*puVar35 * 0x85ebca87;
    uVar22 = (uint)lVar1 ^ uVar9;
    uVar17 = *puVar35 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20) ^ uVar17;
    uVar13 = uVar22 << 0x17 | uVar17 >> 9;
    lVar1 = (ulonglong)uVar13 * 0x27d4eb4f;
    uVar10 = (uint)lVar1;
    uVar9 = uVar10 + 0x9e3779f9;
    uVar17 = (uVar17 << 0x17 | uVar22 >> 9) * 0x27d4eb4f +
             uVar13 * -0x3d4d51c3 + (int)((ulonglong)lVar1 >> 0x20) + 0x165667b1 +
             (uint)(0x61c88606 < uVar10);
    puVar35 = puVar35 + 1;
  }
  if (puVar35 < puVar37) {
    do {
      puVar37 = (uint *)((int)puVar35 + 1);
      lVar1 = (ulonglong)(uint)*(byte *)puVar35 * 0x165667c5;
      uVar22 = (uint)lVar1 ^ uVar9;
      uVar17 = (uint)*(byte *)puVar35 * 0x27d4eb2f + (int)((ulonglong)lVar1 >> 0x20) ^ uVar17;
      uVar13 = uVar22 << 0xb | uVar17 >> 0x15;
      lVar1 = (ulonglong)uVar13 * 0x85ebca87;
      uVar9 = (uint)lVar1;
      uVar17 = (uVar17 << 0xb | uVar22 >> 0x15) * -0x7a143579 +
               uVar13 * -0x61c8864f + (int)((ulonglong)lVar1 >> 0x20);
      puVar35 = puVar37;
    } while ((uint *)((int)param_1 + param_1[0x12] + 0x28) != puVar37);
  }
  uVar9 = uVar9 ^ uVar17 >> 1;
  lVar1 = (ulonglong)uVar9 * 0x27d4eb4f;
  uVar22 = (uint)lVar1;
  uVar17 = uVar17 * 0x27d4eb4f + uVar9 * -0x3d4d51c3 + (int)((ulonglong)lVar1 >> 0x20);
  uVar22 = (uVar22 >> 0x1d | uVar17 * 8) ^ uVar22;
  lVar1 = (ulonglong)uVar22 * 0x9e3779f9;
  return (uVar17 ^ uVar17 >> 0x1d) * -0x61c88607 +
         uVar22 * 0x165667b1 + (int)((ulonglong)lVar1 >> 0x20) ^ (uint)lVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a408 FUN_0003a408 */

void FUN_0003a408(void *param_1,uint param_2)

{
  uint local_c;
  
  local_c = param_2 << 0x18 | (param_2 >> 8 & 0xff) << 0x10 | (param_2 >> 0x10 & 0xff) << 8 |
            param_2 >> 0x18;
  memcpy(param_1,&local_c,4);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a430 FUN_0003a430 */

void FUN_0003a430(void *param_1,undefined4 param_2,uint param_3,uint param_4)

{
  uint local_10;
  uint local_c;
  
  local_c = param_3 << 0x18 | (param_3 >> 8 & 0xff) << 0x10 | (param_3 >> 0x10 & 0xff) << 8 |
            param_3 >> 0x18;
  local_10 = param_4 << 0x18 | (param_4 >> 8 & 0xff) << 0x10 | (param_4 >> 0x10 & 0xff) << 8 |
             param_4 >> 0x18;
  memcpy(param_1,&local_10,8);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a4a8 FUN_0003a4a8 */

void FUN_0003a4a8(undefined4 param_1,code *UNRECOVERED_JUMPTABLE,undefined4 param_3,
                 undefined4 param_4)

{
  if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0003a4bc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_4);
    return;
  }
  FUN_0003a770(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a4c8 FUN_0003a4c8 */

void * FUN_0003a4c8(size_t param_1,code *param_2,undefined4 param_3,undefined4 param_4)

{
  void *pvVar1;
  
  if (param_2 != (code *)0x0) {
    pvVar1 = (void *)(*param_2)(param_4,param_1);
    memset(pvVar1,0,param_1);
    return pvVar1;
  }
  pvVar1 = (void *)FUN_0003cbe8(1,param_1);
  return pvVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a514 FUN_0003a514 */

void FUN_0003a514(int param_1,undefined4 param_2,code *UNRECOVERED_JUMPTABLE,undefined4 param_4)

{
  if (param_1 == 0) {
    return;
  }
  if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0003a52c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_4);
    return;
  }
  FUN_0003bf1c(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a538 FUN_0003a538 */

ulonglong FUN_0003a538(uint param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  bool bVar8;
  bool bVar9;
  bool bVar10;
  bool bVar11;
  bool bVar12;
  bool bVar13;
  bool bVar14;
  bool bVar15;
  bool bVar16;
  bool bVar17;
  bool bVar18;
  bool bVar19;
  bool bVar20;
  bool bVar21;
  bool bVar22;
  bool bVar23;
  bool bVar24;
  bool bVar25;
  bool bVar26;
  bool bVar27;
  bool bVar28;
  bool bVar29;
  bool bVar30;
  bool bVar31;
  bool bVar32;
  bool bVar33;
  ulonglong uVar34;
  
  if (param_2 - 1 == 0) {
    return CONCAT44(param_2,param_1);
  }
  if (param_2 == 0) {
    uVar1 = raise(8);
    return (ulonglong)uVar1;
  }
  if (param_1 <= param_2) {
    return CONCAT44(param_2,(uint)(param_1 == param_2));
  }
  if ((param_2 & param_2 - 1) == 0) {
    return CONCAT44(param_2,param_1 >> (0x1fU - LZCOUNT(param_2) & 0xff));
  }
  iVar2 = 0x1f - (LZCOUNT(param_2) - LZCOUNT(param_1));
  if (iVar2 == 0) {
    bVar3 = param_2 << 0x1f <= param_1;
    if (bVar3) {
      param_1 = param_1 + param_2 * -0x80000000;
    }
    bVar4 = param_2 << 0x1e <= param_1;
    if (bVar4) {
      param_1 = param_1 + param_2 * -0x40000000;
    }
    bVar5 = param_2 << 0x1d <= param_1;
    if (bVar5) {
      param_1 = param_1 + param_2 * -0x20000000;
    }
    bVar6 = param_2 << 0x1c <= param_1;
    if (bVar6) {
      param_1 = param_1 + param_2 * -0x10000000;
    }
    bVar7 = param_2 << 0x1b <= param_1;
    if (bVar7) {
      param_1 = param_1 + param_2 * -0x8000000;
    }
    bVar8 = param_2 << 0x1a <= param_1;
    if (bVar8) {
      param_1 = param_1 + param_2 * -0x4000000;
    }
    bVar9 = param_2 << 0x19 <= param_1;
    if (bVar9) {
      param_1 = param_1 + param_2 * -0x2000000;
    }
    bVar10 = param_2 << 0x18 <= param_1;
    if (bVar10) {
      param_1 = param_1 + param_2 * -0x1000000;
    }
    bVar11 = param_2 << 0x17 <= param_1;
    if (bVar11) {
      param_1 = param_1 + param_2 * -0x800000;
    }
    bVar12 = param_2 << 0x16 <= param_1;
    if (bVar12) {
      param_1 = param_1 + param_2 * -0x400000;
    }
    bVar13 = param_2 << 0x15 <= param_1;
    if (bVar13) {
      param_1 = param_1 + param_2 * -0x200000;
    }
    bVar14 = param_2 << 0x14 <= param_1;
    if (bVar14) {
      param_1 = param_1 + param_2 * -0x100000;
    }
    bVar15 = param_2 << 0x13 <= param_1;
    if (bVar15) {
      param_1 = param_1 + param_2 * -0x80000;
    }
    bVar16 = param_2 << 0x12 <= param_1;
    if (bVar16) {
      param_1 = param_1 + param_2 * -0x40000;
    }
    bVar17 = param_2 << 0x11 <= param_1;
    if (bVar17) {
      param_1 = param_1 + param_2 * -0x20000;
    }
    bVar18 = param_2 << 0x10 <= param_1;
    if (bVar18) {
      param_1 = param_1 + param_2 * -0x10000;
    }
    bVar19 = param_2 << 0xf <= param_1;
    if (bVar19) {
      param_1 = param_1 + param_2 * -0x8000;
    }
    bVar20 = param_2 << 0xe <= param_1;
    if (bVar20) {
      param_1 = param_1 + param_2 * -0x4000;
    }
    bVar21 = param_2 << 0xd <= param_1;
    if (bVar21) {
      param_1 = param_1 + param_2 * -0x2000;
    }
    bVar22 = param_2 << 0xc <= param_1;
    if (bVar22) {
      param_1 = param_1 + param_2 * -0x1000;
    }
    bVar23 = param_2 << 0xb <= param_1;
    if (bVar23) {
      param_1 = param_1 + param_2 * -0x800;
    }
    bVar24 = param_2 << 10 <= param_1;
    if (bVar24) {
      param_1 = param_1 + param_2 * -0x400;
    }
    bVar25 = param_2 << 9 <= param_1;
    if (bVar25) {
      param_1 = param_1 + param_2 * -0x200;
    }
    bVar26 = param_2 << 8 <= param_1;
    if (bVar26) {
      param_1 = param_1 + param_2 * -0x100;
    }
    bVar27 = param_2 << 7 <= param_1;
    if (bVar27) {
      param_1 = param_1 + param_2 * -0x80;
    }
    bVar28 = param_2 << 6 <= param_1;
    if (bVar28) {
      param_1 = param_1 + param_2 * -0x40;
    }
    bVar29 = param_2 << 5 <= param_1;
    if (bVar29) {
      param_1 = param_1 + param_2 * -0x20;
    }
    bVar30 = param_2 << 4 <= param_1;
    if (bVar30) {
      param_1 = param_1 + param_2 * -0x10;
    }
    bVar31 = param_2 << 3 <= param_1;
    if (bVar31) {
      param_1 = param_1 + param_2 * -8;
    }
    bVar32 = param_2 << 2 <= param_1;
    if (bVar32) {
      param_1 = param_1 + param_2 * -4;
    }
    bVar33 = param_2 << 1 <= param_1;
    if (bVar33) {
      param_1 = param_1 + param_2 * -2;
    }
    return CONCAT44(param_2,(((((((((((((((((((((((((((((((uint)bVar3 * 2 + (uint)bVar4) * 2 +
                                                        (uint)bVar5) * 2 + (uint)bVar6) * 2 +
                                                      (uint)bVar7) * 2 + (uint)bVar8) * 2 +
                                                    (uint)bVar9) * 2 + (uint)bVar10) * 2 +
                                                  (uint)bVar11) * 2 + (uint)bVar12) * 2 +
                                                (uint)bVar13) * 2 + (uint)bVar14) * 2 + (uint)bVar15
                                              ) * 2 + (uint)bVar16) * 2 + (uint)bVar17) * 2 +
                                           (uint)bVar18) * 2 + (uint)bVar19) * 2 + (uint)bVar20) * 2
                                        + (uint)bVar21) * 2 + (uint)bVar22) * 2 + (uint)bVar23) * 2
                                     + (uint)bVar24) * 2 + (uint)bVar25) * 2 + (uint)bVar26) * 2 +
                                  (uint)bVar27) * 2 + (uint)bVar28) * 2 + (uint)bVar29) * 2 +
                               (uint)bVar30) * 2 + (uint)bVar31) * 2 + (uint)bVar32) * 2 +
                            (uint)bVar33) * 2 + (uint)(param_2 <= param_1));
  }
                    /* WARNING: Could not recover jumptable at 0x0003a56c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar34 = (*(code *)(iVar2 * 0xc + 0x3a574))();
  return uVar34;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a724 FUN_0003a724 */

void FUN_0003a724(undefined4 param_1,int param_2)

{
  if (param_2 != 0) {
    FUN_0003a538();
    return;
  }
  raise(8);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003a770 FUN_0003a770 */

/* WARNING: Type propagation algorithm not settling */

uint ** FUN_0003a770(uint param_1)

{
  void *pvVar1;
  uint **ppuVar2;
  uint **ppuVar3;
  uint *puVar4;
  uint **ppuVar5;
  uint uVar6;
  int iVar7;
  uint *puVar8;
  uint extraout_r1;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  uint **ppuVar13;
  uint uVar14;
  uint **ppuVar15;
  uint uVar16;
  uint uVar17;
  uint **ppuVar18;
  uint uVar19;
  undefined4 *puVar20;
  uint **ppuVar21;
  uint *puVar22;
  uint uVar23;
  uint uVar24;
  undefined4 *puVar25;
  undefined4 *puVar26;
  undefined4 *puVar27;
  uint *puVar28;
  uint uVar29;
  undefined4 *puVar30;
  uint *puVar31;
  undefined4 *puVar32;
  undefined4 *puVar33;
  bool bVar34;
  bool bVar35;
  
  iVar7 = DAT_0003b714;
  puVar31 = (uint *)(DAT_0003b714 + 0x3a794);
  if (param_1 < 0xf5) {
    uVar29 = param_1 + 0xb & 0xfffffff8;
    if (param_1 < 0xb) {
      uVar29 = 0x10;
    }
    uVar9 = uVar29 >> 3;
    uVar6 = *(uint *)(DAT_0003b718 + 0x3a7b8);
    uVar14 = uVar6 >> (uVar9 & 0xff);
    if ((uVar6 >> (uVar9 & 0xff) & 3) != 0) {
      uVar9 = (~uVar14 & 1) + uVar9;
      uVar29 = puVar31[uVar9 * 2 + 0xb];
      puVar22 = *(uint **)(uVar29 + 8);
      if (puVar22[3] == uVar29) {
        if (puVar22 == puVar31 + uVar9 * 2 + 9) {
          *puVar31 = uVar6 & ~(1 << (uVar9 & 0xff));
        }
        else {
          if (puVar22 < *(uint **)(DAT_0003b714 + 0x3a7a4)) goto LAB_0003ae30;
          puVar31[uVar9 * 2 + 0xb] = (uint)puVar22;
          puVar22[3] = (uint)(puVar31 + uVar9 * 2 + 9);
        }
        *(uint *)(uVar29 + 4) = uVar9 * 8 | 3;
        iVar7 = uVar29 + uVar9 * 8;
        *(uint *)(iVar7 + 4) = *(uint *)(iVar7 + 4) | 1;
        return (uint **)(uVar29 + 8);
      }
      goto LAB_0003ae30;
    }
    uVar10 = *(uint *)(DAT_0003b714 + 0x3a79c);
    if (uVar10 < uVar29) {
      if (uVar14 != 0) {
        uVar9 = (-(2 << (uVar9 & 0xff)) | 2 << (uVar9 & 0xff)) & uVar14 << (uVar9 & 0xff);
        uVar9 = (uVar9 & -uVar9) - 1;
        uVar14 = uVar9 >> 0xc & 0x10;
        uVar9 = uVar9 >> uVar14;
        uVar19 = uVar9 >> 5 & 8;
        uVar9 = uVar9 >> uVar19;
        uVar17 = uVar9 >> 2 & 4;
        uVar9 = uVar9 >> uVar17;
        uVar23 = uVar9 >> 1 & 2;
        uVar9 = uVar9 >> uVar23;
        uVar16 = (uVar9 << 0x1e) >> 0x1f;
        uVar9 = (uVar19 | uVar14 | uVar17 | uVar23 | uVar16) + (uVar9 >> uVar16);
        uVar14 = puVar31[uVar9 * 2 + 0xb];
        puVar22 = *(uint **)(uVar14 + 8);
        if (puVar22[3] == uVar14) {
          if (puVar22 == puVar31 + uVar9 * 2 + 9) {
            uVar6 = uVar6 & ~(1 << (uVar9 & 0xff));
            *puVar31 = uVar6;
          }
          else {
            if (puVar22 < *(uint **)(DAT_0003b714 + 0x3a7a4)) goto LAB_0003ae30;
            puVar31[uVar9 * 2 + 0xb] = (uint)puVar22;
            puVar22[3] = (uint)(puVar31 + uVar9 * 2 + 9);
          }
          *(uint *)(uVar14 + 4) = uVar29 | 3;
          uVar16 = uVar9 * 8 - uVar29;
          *(uint *)(uVar14 + uVar29 + 4) = uVar16 | 1;
          *(uint *)(uVar14 + uVar9 * 8) = uVar16;
          if (uVar10 != 0) {
            iVar11 = *(int *)(iVar7 + 0x3a7a8);
            uVar9 = uVar10 & 0xfffffff8;
            uVar17 = (int)puVar31 + uVar9 + 0x24;
            if ((uVar6 & 1 << (uVar10 >> 3 & 0xff)) == 0) {
              *puVar31 = uVar6 | 1 << (uVar10 >> 3 & 0xff);
              uVar6 = uVar17;
            }
            else {
              uVar6 = *(uint *)((int)puVar31 + uVar9 + 0x2c);
              if (uVar6 < *(uint *)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
            }
            *(int *)((int)puVar31 + uVar9 + 0x2c) = iVar11;
            *(int *)(uVar6 + 0xc) = iVar11;
            *(uint *)(iVar11 + 8) = uVar6;
            *(uint *)(iVar11 + 0xc) = uVar17;
          }
          *(uint *)(iVar7 + 0x3a7a8) = uVar14 + uVar29;
          *(uint *)(iVar7 + 0x3a79c) = uVar16;
          return (uint **)(uVar14 + 8);
        }
        goto LAB_0003ae30;
      }
      uVar9 = *(uint *)(DAT_0003b714 + 0x3a798);
      if (uVar9 != 0) {
        uVar14 = (uVar9 & -uVar9) - 1;
        uVar16 = uVar14 >> 0xc & 0x10;
        uVar14 = uVar14 >> uVar16;
        uVar24 = uVar14 >> 5 & 8;
        uVar14 = uVar14 >> uVar24;
        uVar19 = uVar14 >> 2 & 4;
        uVar14 = uVar14 >> uVar19;
        uVar17 = uVar14 >> 1 & 2;
        uVar14 = uVar14 >> uVar17;
        uVar23 = (uVar14 << 0x1e) >> 0x1f;
        puVar32 = (undefined4 *)
                  puVar31[(uVar24 | uVar16 | uVar19 | uVar17 | uVar23) + (uVar14 >> uVar23) + 0x4b];
        uVar14 = (puVar32[1] & 0xfffffffc) - uVar29;
        puVar33 = puVar32;
        while( true ) {
          puVar25 = (undefined4 *)puVar32[4];
          puVar30 = puVar25;
          if (puVar25 == (undefined4 *)0x0) {
            puVar30 = (undefined4 *)puVar32[5];
          }
          puVar32 = puVar30;
          if (puVar25 == (undefined4 *)0x0 && puVar32 == (undefined4 *)0x0) break;
          uVar16 = (puVar32[1] & 0xfffffffc) - uVar29;
          if (uVar16 < uVar14) {
            uVar14 = uVar16;
            puVar33 = puVar32;
          }
        }
        puVar32 = *(undefined4 **)(DAT_0003b714 + 0x3a7a4);
        if ((puVar33 < puVar32) ||
           (puVar30 = (undefined4 *)((int)puVar33 + uVar29), puVar30 <= puVar33)) goto LAB_0003ae30;
        puVar25 = (undefined4 *)puVar33[3];
        uVar16 = puVar33[6];
        if (puVar25 == puVar33) {
          puVar20 = (undefined4 *)puVar33[5];
          puVar26 = puVar33 + 5;
          if (puVar20 == (undefined4 *)0x0) {
            puVar20 = (undefined4 *)puVar33[4];
            puVar26 = puVar33 + 4;
            if (puVar20 == (undefined4 *)0x0) {
              puVar25 = (undefined4 *)0x0;
              goto LAB_0003b0e8;
            }
          }
          do {
            do {
              puVar27 = puVar26;
              puVar25 = puVar20;
              puVar20 = (undefined4 *)puVar25[5];
              puVar26 = puVar25 + 5;
            } while (puVar20 != (undefined4 *)0x0);
            puVar20 = (undefined4 *)puVar25[4];
            puVar26 = puVar25 + 4;
          } while (puVar20 != (undefined4 *)0x0);
          if (puVar27 < puVar32) goto LAB_0003ae30;
          *puVar27 = 0;
        }
        else {
          puVar26 = (undefined4 *)puVar33[2];
          puVar20 = (undefined4 *)puVar26[3];
          bVar34 = puVar20 == puVar33;
          if (bVar34) {
            puVar20 = (undefined4 *)puVar25[2];
          }
          if ((!bVar34 || puVar20 != puVar33) || (puVar26 < puVar32)) goto LAB_0003ae30;
          puVar26[3] = puVar25;
          puVar25[2] = puVar26;
        }
LAB_0003b0e8:
        if (uVar16 != 0) {
          uVar17 = puVar33[7];
          if (puVar33 == (undefined4 *)puVar31[uVar17 + 0x4b]) {
            puVar31[uVar17 + 0x4b] = (uint)puVar25;
            if (puVar25 == (undefined4 *)0x0) {
              *(uint *)(iVar7 + 0x3a798) = uVar9 & ~(1 << (uVar17 & 0xff));
            }
            else {
LAB_0003b1b8:
              puVar32 = *(undefined4 **)(iVar7 + 0x3a7a4);
              if (puVar25 < puVar32) goto LAB_0003ae30;
              puVar25[6] = uVar16;
              puVar20 = (undefined4 *)puVar33[4];
              if (puVar20 != (undefined4 *)0x0) {
                if (puVar20 < puVar32) goto LAB_0003ae30;
                puVar25[4] = puVar20;
                puVar20[6] = puVar25;
              }
              uVar9 = puVar33[5];
              if (uVar9 != 0) {
                if (uVar9 < *(uint *)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
                puVar25[5] = uVar9;
                *(undefined4 **)(uVar9 + 0x18) = puVar25;
              }
            }
          }
          else {
            if (uVar16 < *(uint *)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
            iVar11 = 0x14;
            if (*(undefined4 **)(uVar16 + 0x10) == puVar33) {
              iVar11 = 0x10;
            }
            *(undefined4 **)(uVar16 + iVar11) = puVar25;
            if (puVar25 != (undefined4 *)0x0) goto LAB_0003b1b8;
          }
        }
        if (uVar14 < 0x10) {
          uVar14 = uVar14 + uVar29;
          puVar33[1] = uVar14 | 3;
          *(uint *)((int)puVar33 + uVar14 + 4) = *(uint *)((int)puVar33 + uVar14 + 4) | 1;
        }
        else {
          puVar33[1] = uVar29 | 3;
          puVar30[1] = uVar14 | 1;
          *(uint *)((int)puVar30 + uVar14) = uVar14;
          if (uVar10 != 0) {
            iVar11 = *(int *)(iVar7 + 0x3a7a8);
            uVar29 = uVar10 & 0xfffffff8;
            uVar9 = (int)puVar31 + uVar29 + 0x24;
            if ((uVar6 & 1 << (uVar10 >> 3 & 0xff)) == 0) {
              *puVar31 = 1 << (uVar10 >> 3 & 0xff) | uVar6;
              uVar6 = uVar9;
            }
            else {
              uVar6 = *(uint *)((int)puVar31 + uVar29 + 0x2c);
              if (uVar6 < *(uint *)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
            }
            *(int *)((int)puVar31 + uVar29 + 0x2c) = iVar11;
            *(int *)(uVar6 + 0xc) = iVar11;
            *(uint *)(iVar11 + 8) = uVar6;
            *(uint *)(iVar11 + 0xc) = uVar9;
          }
          *(undefined4 **)(iVar7 + 0x3a7a8) = puVar30;
          *(uint *)(iVar7 + 0x3a79c) = uVar14;
        }
        return (uint **)(puVar33 + 2);
      }
    }
  }
  else {
    uVar29 = 0xffffffff;
    if (param_1 < 0xffffffc0) {
      param_1 = param_1 + 0xb;
      uVar9 = *(uint *)(DAT_0003b714 + 0x3a798);
      uVar29 = param_1 & 0xfffffff8;
      if (uVar9 != 0) {
        ppuVar3 = (uint **)0x0;
        uVar14 = 0;
        if ((param_1 >> 8 != 0) && (uVar14 = 0x1f, param_1 >> 0x18 == 0)) {
          param_1 = param_1 >> 8;
          uVar14 = param_1 + 0xfff00 >> 0x10 & 8;
          uVar10 = (param_1 << uVar14) + 0x7f000 >> 0x10 & 4;
          uVar6 = ((param_1 << uVar14) << uVar10) + 0x3c000 >> 0x10 & 2;
          iVar11 = ((((param_1 << uVar14) << uVar10) << uVar6) >> 0xf) - (uVar10 | uVar14 | uVar6);
          uVar14 = (uVar29 >> (iVar11 + 0x15U & 0xff) & 1 | iVar11 * 2) + 0x1c;
        }
        uVar6 = -uVar29;
        ppuVar2 = (uint **)puVar31[uVar14 + 0x4b];
        if (ppuVar2 == (uint **)0x0) {
          ppuVar5 = (uint **)0x0;
        }
        else {
          uVar10 = uVar14 - 0x1f;
          if (uVar10 != 0) {
            uVar10 = 0x19 - (uVar14 >> 1);
          }
          ppuVar3 = (uint **)0x0;
          ppuVar5 = (uint **)0x0;
          iVar11 = uVar29 << (uVar10 & 0xff);
          do {
            uVar10 = ((uint)ppuVar2[1] & 0xfffffffc) - uVar29;
            if ((uVar10 < uVar6) && (ppuVar5 = ppuVar2, uVar6 = uVar10, uVar10 == 0)) {
              uVar6 = 0;
              goto LAB_0003ab68;
            }
            ppuVar15 = (uint **)ppuVar2[5];
            ppuVar2 = (uint **)ppuVar2[4 - (iVar11 >> 0x1f)];
            ppuVar13 = ppuVar15;
            if (ppuVar15 == ppuVar2) {
              ppuVar13 = ppuVar3;
            }
            if (ppuVar15 != (uint **)0x0) {
              ppuVar3 = ppuVar13;
            }
            ppuVar13 = ppuVar2;
            if (ppuVar2 != (uint **)0x0) {
              ppuVar13 = (uint **)0x1;
            }
            iVar11 = iVar11 << ((uint)ppuVar13 & 0xff);
          } while (ppuVar2 != (uint **)0x0);
        }
        if (((uint)ppuVar3 | (uint)ppuVar5) == 0) {
          uVar14 = (-(2 << (uVar14 & 0xff)) | 2 << (uVar14 & 0xff)) & uVar9;
          if (uVar14 == 0) goto LAB_0003ac08;
          uVar14 = (uVar14 & -uVar14) - 1;
          uVar16 = uVar14 >> 0xc & 0x10;
          uVar14 = uVar14 >> uVar16;
          uVar17 = uVar14 >> 5 & 8;
          uVar14 = uVar14 >> uVar17;
          uVar23 = uVar14 >> 2 & 4;
          uVar14 = uVar14 >> uVar23;
          uVar10 = uVar14 >> 1 & 2;
          uVar14 = uVar14 >> uVar10;
          uVar19 = (uVar14 << 0x1e) >> 0x1f;
          ppuVar3 = (uint **)puVar31[(uVar17 | uVar16 | uVar23 | uVar10 | uVar19) +
                                     (uVar14 >> uVar19) + 0x4b];
        }
        while (ppuVar2 = ppuVar3, ppuVar2 != (uint **)0x0) {
LAB_0003ab68:
          uVar14 = ((uint)ppuVar2[1] & 0xfffffffc) - uVar29;
          if (uVar14 < uVar6) {
            uVar6 = uVar14;
            ppuVar5 = ppuVar2;
          }
          ppuVar3 = (uint **)ppuVar2[4];
          if ((uint **)ppuVar2[4] == (uint **)0x0) {
            ppuVar3 = (uint **)ppuVar2[5];
          }
        }
        if ((ppuVar5 != (uint **)0x0) && (uVar6 < *(int *)(DAT_0003b714 + 0x3a79c) - uVar29)) {
          ppuVar3 = *(uint ***)(DAT_0003b714 + 0x3a7a4);
          if ((ppuVar5 < ppuVar3) || (puVar22 = (uint *)((int)ppuVar5 + uVar29), puVar22 <= ppuVar5)
             ) goto LAB_0003ae30;
          puVar4 = ppuVar5[3];
          uVar14 = (uint)ppuVar5[6];
          if ((uint **)puVar4 == ppuVar5) {
            puVar28 = ppuVar5[5];
            ppuVar2 = ppuVar5 + 5;
            if (puVar28 == (uint *)0x0) {
              puVar28 = ppuVar5[4];
              ppuVar2 = ppuVar5 + 4;
              if (puVar28 == (uint *)0x0) {
                puVar4 = (uint *)0x0;
                goto LAB_0003ae8c;
              }
            }
            do {
              do {
                puVar4 = puVar28;
                ppuVar13 = ppuVar2;
                puVar28 = (uint *)puVar4[5];
                ppuVar2 = (uint **)(puVar4 + 5);
              } while (puVar28 != (uint *)0x0);
              puVar28 = (uint *)puVar4[4];
              ppuVar2 = (uint **)(puVar4 + 4);
            } while (puVar28 != (uint *)0x0);
            if (ppuVar13 < ppuVar3) goto LAB_0003ae30;
            *ppuVar13 = (uint *)0x0;
          }
          else {
            ppuVar13 = (uint **)ppuVar5[2];
            ppuVar2 = (uint **)ppuVar13[3];
            bVar34 = ppuVar2 != ppuVar5;
            if (!bVar34) {
              ppuVar2 = (uint **)puVar4[2];
            }
            if ((bVar34 || ppuVar2 != ppuVar5) || (ppuVar13 < ppuVar3)) goto LAB_0003ae30;
            ppuVar13[3] = puVar4;
            puVar4[2] = (uint)ppuVar13;
          }
LAB_0003ae8c:
          if (uVar14 != 0) {
            puVar28 = ppuVar5[7];
            if (ppuVar5 == (uint **)puVar31[(int)puVar28 + 0x4b]) {
              puVar31[(int)puVar28 + 0x4b] = (uint)puVar4;
              if (puVar4 == (uint *)0x0) {
                uVar9 = uVar9 & ~(1 << ((uint)puVar28 & 0xff));
                *(uint *)(iVar7 + 0x3a798) = uVar9;
              }
              else {
LAB_0003b13c:
                puVar28 = *(uint **)(iVar7 + 0x3a7a4);
                if (puVar4 < puVar28) goto LAB_0003ae30;
                puVar4[6] = uVar14;
                puVar8 = ppuVar5[4];
                if (puVar8 != (uint *)0x0) {
                  if (puVar8 < puVar28) goto LAB_0003ae30;
                  puVar4[4] = (uint)puVar8;
                  puVar8[6] = (uint)puVar4;
                }
                puVar28 = ppuVar5[5];
                if (puVar28 != (uint *)0x0) {
                  if (puVar28 < *(uint **)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
                  puVar4[5] = (uint)puVar28;
                  puVar28[6] = (uint)puVar4;
                }
              }
            }
            else {
              if (uVar14 < *(uint *)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
              iVar11 = 0x14;
              if (*(uint ***)(uVar14 + 0x10) == ppuVar5) {
                iVar11 = 0x10;
              }
              *(uint **)(uVar14 + iVar11) = puVar4;
              if (puVar4 != (uint *)0x0) goto LAB_0003b13c;
            }
          }
          if (uVar6 < 0x10) {
            uVar6 = uVar6 + uVar29;
            ppuVar5[1] = (uint *)(uVar6 | 3);
            *(uint *)((int)ppuVar5 + uVar6 + 4) = *(uint *)((int)ppuVar5 + uVar6 + 4) | 1;
          }
          else {
            ppuVar5[1] = (uint *)(uVar29 | 3);
            puVar22[1] = uVar6 | 1;
            *(uint *)((int)puVar22 + uVar6) = uVar6;
            if (0xff < uVar6) {
              uVar29 = 0;
              if ((uVar6 >> 8 != 0) && (uVar29 = 0x1f, uVar6 >> 0x18 == 0)) {
                uVar29 = uVar6 >> 8;
                uVar14 = uVar29 + 0xfff00 >> 0x10 & 8;
                uVar16 = (uVar29 << uVar14) + 0x7f000 >> 0x10 & 4;
                uVar10 = ((uVar29 << uVar14) << uVar16) + 0x3c000 >> 0x10 & 2;
                iVar11 = ((((uVar29 << uVar14) << uVar16) << uVar10) >> 0xf) -
                         (uVar16 | uVar14 | uVar10);
                uVar29 = (uVar6 >> (iVar11 + 0x15U & 0xff) & 1 | iVar11 * 2) + 0x1c;
              }
              puVar22[7] = uVar29;
              puVar22[4] = 0;
              puVar22[5] = 0;
              ppuVar3 = (uint **)(puVar31 + uVar29 + 0x4b);
              if ((uVar9 & 1 << (uVar29 & 0xff)) == 0) {
                *(uint *)(iVar7 + 0x3a798) = uVar9 | 1 << (uVar29 & 0xff);
                *ppuVar3 = puVar22;
              }
              else {
                uVar9 = uVar29 - 0x1f;
                if (uVar9 != 0) {
                  uVar9 = 0x19 - (uVar29 >> 1);
                }
                iVar11 = uVar6 << (uVar9 & 0xff);
                puVar31 = *ppuVar3;
                do {
                  ppuVar3 = (uint **)puVar31;
                  if (((uint)ppuVar3[1] & 0xfffffffc) == uVar6) {
                    puVar4 = ppuVar3[2];
                    puVar31 = *(uint **)(iVar7 + 0x3a7a4);
                    bVar35 = puVar4 <= puVar31;
                    bVar34 = puVar31 == puVar4;
                    if (!bVar35 || bVar34) {
                      bVar35 = ppuVar3 <= puVar31;
                      bVar34 = (uint **)puVar31 == ppuVar3;
                    }
                    if (bVar35 && !bVar34) goto LAB_0003ae30;
                    puVar4[3] = (uint)puVar22;
                    ppuVar3[2] = puVar22;
                    puVar22[6] = 0;
                    goto LAB_0003b394;
                  }
                  iVar12 = iVar11 >> 0x1f;
                  iVar11 = iVar11 << 1;
                  ppuVar2 = ppuVar3 + (4 - iVar12);
                  puVar31 = *ppuVar2;
                } while (*ppuVar2 != (uint *)0x0);
                if (ppuVar2 < *(uint ***)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
                *ppuVar2 = puVar22;
              }
              puVar22[6] = (uint)ppuVar3;
              puVar22[2] = (uint)puVar22;
              puVar22[3] = (uint)puVar22;
              goto LAB_0003b3c0;
            }
            uVar29 = uVar6 & 0xfffffff8;
            ppuVar3 = (uint **)((int)puVar31 + uVar29 + 0x24);
            if ((*puVar31 & 1 << (uVar6 >> 3 & 0xff)) == 0) {
              *puVar31 = *puVar31 | 1 << (uVar6 >> 3 & 0xff);
              puVar4 = (uint *)ppuVar3;
            }
            else {
              puVar4 = *(uint **)((int)puVar31 + uVar29 + 0x2c);
              if (puVar4 < *(uint **)(iVar7 + 0x3a7a4)) goto LAB_0003ae30;
            }
            *(uint **)((int)puVar31 + uVar29 + 0x2c) = puVar22;
            puVar4[3] = (uint)puVar22;
LAB_0003b394:
            puVar22[2] = (uint)puVar4;
            puVar22[3] = (uint)ppuVar3;
          }
LAB_0003b3c0:
          return ppuVar5 + 2;
        }
      }
    }
  }
LAB_0003ac08:
  uVar9 = *(uint *)(DAT_0003b714 + 0x3a79c);
  if (uVar29 <= uVar9) {
    iVar11 = *(int *)(DAT_0003b714 + 0x3a7a8);
    uVar14 = uVar9 - uVar29;
    if (uVar14 < 0x10) {
      *(undefined4 *)(DAT_0003b714 + 0x3a7a8) = 0;
      *(undefined4 *)(iVar7 + 0x3a79c) = 0;
      *(uint *)(iVar11 + 4) = uVar9 | 3;
      *(uint *)(iVar11 + uVar9 + 4) = *(uint *)(iVar11 + uVar9 + 4) | 1;
    }
    else {
      *(uint *)(DAT_0003b714 + 0x3a79c) = uVar14;
      *(uint *)(iVar7 + 0x3a7a8) = iVar11 + uVar29;
      *(uint *)(iVar11 + uVar29 + 4) = uVar14 | 1;
      *(uint *)(iVar11 + uVar9) = uVar14;
      *(uint *)(iVar11 + 4) = uVar29 | 3;
    }
    return (uint **)(iVar11 + 8);
  }
  uVar9 = *(uint *)(DAT_0003b714 + 0x3a7a0);
  if (uVar9 <= uVar29) {
    FUN_0003d23c();
    puVar31 = (uint *)(DAT_0003bc38 + 0x3ac90);
    uVar9 = *(uint *)(DAT_0003bc38 + 0x3ae44);
    if ((((uVar9 & 1) != 0) && (*(uint *)(DAT_0003bc3c + 0x3aca4) <= uVar29)) &&
       (uVar14 = uVar29 + *(int *)(DAT_0003bcac + 0x3acb4) + 0x1f &
                 -*(int *)(DAT_0003bcac + 0x3acb4), uVar29 < uVar14)) {
      pvVar1 = mmap((void *)0x0,uVar14,3,0x22,-1,0);
      if (pvVar1 != (void *)0xffffffff) {
        uVar29 = (int)pvVar1 + 8U & 7;
        if (uVar29 != 0) {
          uVar29 = -(int)pvVar1 - 8U & 7;
        }
        puVar22 = (uint *)((int)pvVar1 + uVar29);
        *puVar22 = uVar29 | 1;
        iVar7 = uVar14 - uVar29;
        puVar22[1] = iVar7 - 0x10U | 2;
        *(undefined4 *)((int)puVar22 + iVar7 + -8) = 0;
        *(undefined4 *)((int)puVar22 + iVar7 + -0xc) = 7;
        iVar7 = DAT_0003bd30;
        if (pvVar1 < *(void **)(DAT_0003bd30 + 0x3ad50)) {
          *(void **)(DAT_0003bd30 + 0x3ad50) = pvVar1;
        }
        uVar14 = *(int *)(iVar7 + 0x3aeec) + uVar14;
        *(uint *)(iVar7 + 0x3aeec) = uVar14;
        if (*(uint *)(iVar7 + 0x3aef0) < uVar14) {
          *(uint *)(iVar7 + 0x3aef0) = uVar14;
        }
        goto LAB_0003ac44;
      }
      puVar31 = (uint *)(DAT_0003bea8 + 0x3af10);
      uVar9 = *(uint *)(DAT_0003bea8 + 0x3b0c4);
    }
    if ((uVar9 & 4) == 0) {
      uVar9 = puVar31[6];
      if (uVar9 != 0) {
        puVar22 = puVar31 + 0x6e;
        do {
          if ((*puVar22 <= uVar9) && (uVar9 < *puVar22 + puVar22[1])) {
            uVar9 = (uVar29 - puVar31[3]) + *(int *)(DAT_0003bebc + 0x3afdc) + 0x29 &
                    -*(int *)(DAT_0003bebc + 0x3afdc);
            if (0x7ffffffe < uVar9) goto LAB_0003b4dc;
            ppuVar3 = (uint **)sbrk(uVar9);
            if (ppuVar3 != (uint **)(*puVar22 + puVar22[1])) goto LAB_0003b00c;
            puVar31 = (uint *)(DAT_0003bf18 + 0x3b3dc);
            ppuVar2 = ppuVar3;
            goto joined_r0x0003b3d8;
          }
          puVar22 = (uint *)puVar22[2];
        } while (puVar22 != (uint *)0x0);
      }
      ppuVar2 = (uint **)sbrk(0);
      puVar31 = (uint *)(DAT_0003beac + 0x3af68);
      if (ppuVar2 == (uint **)0xffffffff) {
LAB_0003b4dc:
        puVar31[0x6d] = puVar31[0x6d] | 4;
        goto LAB_0003b4e8;
      }
      uVar9 = uVar29 + *(int *)(DAT_0003beb0 + 0x3af78) + 0x29 & -*(int *)(DAT_0003beb0 + 0x3af78);
      iVar7 = *(int *)(DAT_0003beb4 + 0x3af90);
      if ((iVar7 - 1U & (uint)ppuVar2) != 0) {
        uVar9 = (uVar9 - (int)ppuVar2) + (iVar7 + (int)ppuVar2 & -iVar7);
      }
      if (0x7ffffffe < uVar9) goto LAB_0003b4dc;
      ppuVar3 = (uint **)sbrk(uVar9);
      if (ppuVar3 == ppuVar2) {
        puVar22 = (uint *)0x0;
        puVar31 = (uint *)(DAT_0003beb8 + 0x3b1ac);
      }
      else {
LAB_0003b00c:
        puVar31 = (uint *)(DAT_0003bec0 + 0x3b01c);
        ppuVar2 = ppuVar3;
        if ((uVar9 < 0x7fffffff) && (ppuVar3 != (uint **)0xffffffff)) {
          puVar22 = (uint *)0x0;
          if ((uVar9 < uVar29 + 0x29) &&
             (uVar14 = ((uVar29 + 0x29) - uVar9) + *(int *)(DAT_0003bec4 + 0x3b044) &
                       -*(int *)(DAT_0003bec4 + 0x3b044), uVar14 < 0x7fffffff)) {
            pvVar1 = sbrk(uVar14);
            if (pvVar1 == (void *)0xffffffff) {
              sbrk(-uVar9);
              puVar31 = (uint *)(DAT_0003becc + 0x3b4e0);
              goto LAB_0003b4dc;
            }
            uVar9 = uVar14 + uVar9;
            puVar31 = (uint *)(DAT_0003bec8 + 0x3b074);
          }
        }
        else {
joined_r0x0003b3d8:
          puVar22 = (uint *)0x0;
          if (ppuVar2 == (uint **)0xffffffff) goto LAB_0003b4dc;
        }
      }
    }
    else {
LAB_0003b4e8:
      puVar22 = (uint *)0x0;
      uVar9 = *(int *)(DAT_0003bed0 + 0x3b4fc) + uVar29 + 0x29 & -*(int *)(DAT_0003bed0 + 0x3b4fc);
      if (uVar29 < uVar9) {
        ppuVar2 = (uint **)mmap((void *)0x0,uVar9,3,0x22,-1,0);
        puVar22 = (uint *)((int)ppuVar2 + 1);
        if (puVar22 != (uint *)0x0) {
          puVar22 = (uint *)0x1;
        }
        if (ppuVar2 != (uint **)0xffffffff) {
          puVar31 = (uint *)(DAT_0003bed4 + 0x3b550);
          goto LAB_0003b5ac;
        }
        uVar9 = *(int *)(DAT_0003bed8 + 0x3b55c) + uVar29 + 0x29 & -*(int *)(DAT_0003bed8 + 0x3b55c)
        ;
      }
      if (0x7ffffffe < uVar9) goto LAB_0003badc;
      ppuVar2 = (uint **)sbrk(uVar9);
      ppuVar3 = (uint **)sbrk(0);
      puVar31 = (uint *)(DAT_0003bedc + 0x3b590);
      if ((ppuVar3 <= ppuVar2) || (ppuVar2 == (uint **)0xffffffff)) goto LAB_0003badc;
      bVar34 = (uint **)0xfffffffe < ppuVar3;
      uVar14 = extraout_r1;
      if (ppuVar3 != (uint **)0xffffffff) {
        uVar14 = uVar29 + 0x28;
        uVar9 = (int)ppuVar3 - (int)ppuVar2;
        bVar34 = uVar14 <= uVar9;
      }
      if (!bVar34 || (ppuVar3 == (uint **)0xffffffff || uVar9 == uVar14)) goto LAB_0003badc;
    }
LAB_0003b5ac:
    uVar14 = puVar31[0x6b] + uVar9;
    puVar31[0x6b] = uVar14;
    if (puVar31[0x6c] < uVar14) {
      puVar31[0x6c] = uVar14;
    }
    iVar7 = DAT_0003bee0;
    ppuVar3 = (uint **)puVar31[6];
    if (ppuVar3 == (uint **)0x0) {
      puVar31[0x71] = (uint)puVar22;
      puVar31[0x6e] = (uint)ppuVar2;
      puVar31[0x6f] = uVar9;
      uVar14 = (uint)*(byte *)(iVar7 + 0x3b608);
      puVar31[4] = (uint)ppuVar2;
      if (uVar14 != 0) {
        uVar14 = 0x58585858;
      }
      puVar31[8] = uVar14;
      iVar7 = 0;
      do {
        iVar11 = iVar7 + 8;
        iVar12 = (int)puVar31 + iVar7 + 0x24;
        *(int *)((int)puVar31 + iVar7 + 0x2c) = iVar12;
        *(int *)((int)puVar31 + iVar7 + 0x30) = iVar12;
        iVar7 = iVar11;
      } while (iVar11 != 0x100);
      uVar14 = (uint)(ppuVar2 + 2) & 7;
      if (uVar14 != 0) {
        uVar14 = -(int)ppuVar2 - 8U & 7;
      }
      uVar6 = (uVar9 - 0x28) - uVar14;
      iVar7 = (int)ppuVar2 + (uVar9 - 0x28);
      puVar31[3] = uVar6;
      puVar31[6] = (int)ppuVar2 + uVar14;
      *(uint *)((int)ppuVar2 + uVar14 + 4) = uVar6 | 1;
LAB_0003b678:
      *(undefined4 *)(iVar7 + 4) = 0x28;
      puVar31[7] = *(uint *)(DAT_0003bee4 + 0x3b68c);
    }
    else {
      puVar4 = puVar31 + 0x6e;
      do {
        if (ppuVar2 == (uint **)((int)(uint **)*puVar4 + puVar4[1])) {
          puVar28 = (uint *)puVar4[3];
          bVar34 = ((uint)puVar28 & 8) == 0;
          if (bVar34) {
            puVar28 = (uint *)((uint)puVar28 & 1);
          }
          if (((bVar34 && puVar28 == puVar22) && (ppuVar3 < ppuVar2)) &&
             ((uint **)*puVar4 <= ppuVar3)) {
            puVar4[1] = puVar4[1] + uVar9;
            uVar6 = puVar31[3];
            uVar14 = (uint)(ppuVar3 + 2) & 7;
            if (uVar14 != 0) {
              uVar14 = -(int)ppuVar3 - 8U & 7;
            }
            uVar10 = (uVar6 + uVar9) - uVar14;
            puVar31[6] = (int)ppuVar3 + uVar14;
            puVar31[3] = uVar10;
            *(uint *)((int)ppuVar3 + uVar14 + 4) = uVar10 | 1;
            iVar7 = (int)ppuVar3 + uVar6 + uVar9;
            goto LAB_0003b678;
          }
          break;
        }
        puVar4 = (uint *)puVar4[2];
      } while (puVar4 != (uint *)0x0);
      ppuVar15 = (uint **)((int)ppuVar2 + uVar9);
      ppuVar13 = (uint **)(puVar31 + 0x6e);
      ppuVar5 = (uint **)puVar31[4];
      if (ppuVar2 < (uint **)puVar31[4]) {
        puVar31[4] = (uint)ppuVar2;
        ppuVar5 = ppuVar2;
      }
      do {
        if ((uint **)*ppuVar13 == ppuVar15) {
          puVar4 = ppuVar13[3];
          bVar34 = ((uint)puVar4 & 8) == 0;
          if (bVar34) {
            puVar4 = (uint *)((uint)puVar4 & 1);
          }
          if (bVar34 && puVar4 == puVar22) {
            ppuVar21 = ppuVar2 + 2;
            *ppuVar13 = (uint *)ppuVar2;
            ppuVar13[1] = (uint *)((int)ppuVar13[1] + uVar9);
            if (((uint)ppuVar21 & 7) != 0) {
              ppuVar2 = (uint **)((int)ppuVar2 + (-(int)ppuVar2 - 8U & 7));
            }
            ppuVar2[1] = (uint *)(uVar29 | 3);
            if (((uint)(ppuVar15 + 2) & 7) != 0) {
              ppuVar15 = (uint **)((int)ppuVar15 + (-(int)ppuVar15 - 8U & 7));
            }
            uVar9 = (int)ppuVar15 + (-uVar29 - (int)ppuVar2);
            puVar22 = (uint *)((int)ppuVar2 + uVar29);
            if (ppuVar3 == ppuVar15) {
              uVar29 = puVar31[3];
              puVar31[6] = (uint)puVar22;
              puVar31[3] = uVar29 + uVar9;
              puVar22[1] = uVar29 + uVar9 | 1;
              goto LAB_0003be70;
            }
            if ((uint **)puVar31[5] == ppuVar15) {
              puVar31[5] = (uint)puVar22;
              uVar9 = puVar31[2] + uVar9;
              puVar31[2] = uVar9;
              puVar22[1] = uVar9 | 1;
              *(uint *)((int)puVar22 + uVar9) = uVar9;
              goto LAB_0003be70;
            }
            puVar4 = ppuVar15[1];
            if (((uint)puVar4 & 2) != 0) goto LAB_0003bce0;
            if ((uint *)0xff < puVar4) {
              ppuVar3 = (uint **)ppuVar15[3];
              puVar31 = ppuVar15[6];
              if (ppuVar3 == ppuVar15) {
                ppuVar21 = ppuVar15 + 5;
                ppuVar13 = (uint **)*ppuVar21;
                bVar34 = ppuVar13 == (uint **)0x0;
                if (bVar34) {
                  ppuVar21 = ppuVar15 + 4;
                  ppuVar13 = (uint **)*ppuVar21;
                }
                if (!bVar34 || ppuVar13 != (uint **)0x0) goto LAB_0003bb98;
                ppuVar3 = (uint **)0x0;
              }
              else {
                ppuVar21 = (uint **)ppuVar15[2];
                ppuVar13 = (uint **)ppuVar21[3];
                bVar34 = ppuVar13 != ppuVar15;
                if (!bVar34) {
                  ppuVar13 = (uint **)ppuVar3[2];
                }
                if ((bVar34 || ppuVar13 != ppuVar15) || (ppuVar21 < ppuVar5)) goto LAB_0003ae30;
                ppuVar21[3] = (uint *)ppuVar3;
                ppuVar3[2] = (uint *)ppuVar21;
              }
              goto LAB_0003bbd0;
            }
            ppuVar13 = (uint **)ppuVar15[2];
            ppuVar3 = (uint **)ppuVar13[3];
            bVar34 = ppuVar3 != ppuVar15;
            if (!bVar34) {
              ppuVar3 = (uint **)ppuVar15[3];
              ppuVar21 = (uint **)ppuVar3[2];
            }
            if (bVar34 || ppuVar21 != ppuVar15) goto LAB_0003ae30;
            if (ppuVar13 == ppuVar3) {
              *puVar31 = *(uint *)(DAT_0003bee8 + 0x3bc30) & ~(1 << ((uint)puVar4 >> 3 & 0xff));
              goto LAB_0003bccc;
            }
            ppuVar21 = (uint **)((int)puVar31 + ((uint)puVar4 & 0xfffffff8) + 0x24);
            bVar34 = ppuVar21 <= ppuVar13;
            if (ppuVar13 != ppuVar21) {
              bVar34 = ppuVar13 <= ppuVar5;
            }
            if (bVar34 && (ppuVar13 != ppuVar21 && ppuVar5 != ppuVar13)) goto LAB_0003ae30;
            bVar34 = ppuVar21 <= ppuVar3;
            if (ppuVar3 != ppuVar21) {
              bVar34 = ppuVar3 <= ppuVar5;
            }
            if (bVar34 && (ppuVar3 != ppuVar21 && ppuVar5 != ppuVar3)) goto LAB_0003ae30;
            ppuVar13[3] = (uint *)ppuVar3;
            ppuVar3[2] = (uint *)ppuVar13;
            goto LAB_0003bccc;
          }
          break;
        }
        ppuVar13 = (uint **)ppuVar13[2];
      } while (ppuVar13 != (uint **)0x0);
      for (puVar4 = puVar31 + 0x6e;
          (ppuVar3 < (uint **)*puVar4 ||
          (ppuVar5 = (uint **)((int)(uint **)*puVar4 + puVar4[1]), ppuVar5 <= ppuVar3));
          puVar4 = (uint *)puVar4[2]) {
      }
      uVar14 = (uint)(ppuVar2 + 2) & 7;
      if (uVar14 != 0) {
        uVar14 = -(int)ppuVar2 - 8U & 7;
      }
      uVar6 = (uVar9 - 0x28) - uVar14;
      puVar31[3] = uVar6;
      puVar31[6] = (int)ppuVar2 + uVar14;
      *(uint *)((int)ppuVar2 + uVar14 + 4) = uVar6 | 1;
      *(undefined4 *)((int)ppuVar2 + (uVar9 - 0x24)) = 0x28;
      puVar31[7] = *(uint *)(DAT_0003bf00 + 0x3b774);
      ppuVar13 = (uint **)((int)ppuVar5 + -0x2f);
      if (((int)ppuVar5 - 0x27U & 7) != 0) {
        ppuVar13 = (uint **)((int)ppuVar13 + (0x27U - (int)ppuVar5 & 7));
      }
      if (ppuVar13 < ppuVar3 + 4) {
        ppuVar13 = ppuVar3;
      }
      ppuVar13[1] = (uint *)0x1b;
      puVar31 = *(uint **)(DAT_0003bf04 + 0x3b960);
      puVar4 = *(uint **)(DAT_0003bf04 + 0x3b964);
      puVar28 = *(uint **)(DAT_0003bf04 + 0x3b968);
      ppuVar13[2] = *(uint **)(DAT_0003bf04 + 0x3b95c);
      ppuVar13[3] = puVar31;
      ppuVar13[4] = puVar4;
      ppuVar13[5] = puVar28;
      *(uint ***)(DAT_0003bf08 + 0x3b978) = ppuVar2;
      *(uint *)(DAT_0003bf0c + 0x3b988) = uVar9;
      *(uint ***)(DAT_0003bf10 + 0x3b998) = ppuVar13 + 2;
      iVar7 = DAT_0003bf14;
      puVar31 = (uint *)(DAT_0003bf14 + 0x3b7e8);
      *(uint **)(DAT_0003bf14 + 0x3b9ac) = puVar22;
      ppuVar2 = ppuVar13 + 7;
      do {
        ppuVar15 = ppuVar2 + 1;
        *ppuVar2 = (uint *)0x7;
        ppuVar2 = ppuVar15;
      } while (ppuVar15 < ppuVar5);
      if (ppuVar13 != ppuVar3) {
        ppuVar13[1] = (uint *)((uint)ppuVar13[1] & 0xfffffffe);
        puVar22 = (uint *)((int)ppuVar13 - (int)ppuVar3);
        ppuVar3[1] = (uint *)((uint)puVar22 | 1);
        *ppuVar13 = puVar22;
        if (puVar22 < (uint *)0x100) {
          uVar9 = (uint)puVar22 & 0xfffffff8;
          puVar4 = (uint *)((int)puVar31 + uVar9 + 0x24);
          if ((*puVar31 & 1 << ((uint)puVar22 >> 3 & 0xff)) == 0) {
            *puVar31 = *puVar31 | 1 << ((uint)puVar22 >> 3 & 0xff);
            puVar22 = puVar4;
          }
          else {
            puVar22 = *(uint **)((int)puVar31 + uVar9 + 0x2c);
            if (puVar22 < *(uint **)(iVar7 + 0x3b7f8)) {
LAB_0003ae30:
                    /* WARNING: Subroutine does not return */
              abort();
            }
          }
          *(uint ***)((int)puVar31 + uVar9 + 0x2c) = ppuVar3;
          puVar22[3] = (uint)ppuVar3;
          ppuVar3[2] = puVar22;
          ppuVar3[3] = puVar4;
        }
        else {
          puVar4 = (uint *)0x0;
          if (((uint)puVar22 >> 8 != 0) && (puVar4 = (uint *)0x1f, (uint)puVar22 >> 0x18 == 0)) {
            uVar9 = (uint)puVar22 >> 8;
            uVar6 = uVar9 + 0xfff00 >> 0x10 & 8;
            uVar14 = (uVar9 << uVar6) + 0x7f000 >> 0x10 & 4;
            uVar10 = ((uVar9 << uVar6) << uVar14) + 0x3c000 >> 0x10 & 2;
            iVar11 = ((((uVar9 << uVar6) << uVar14) << uVar10) >> 0xf) - (uVar14 | uVar6 | uVar10);
            puVar4 = (uint *)(((uint)puVar22 >> (iVar11 + 0x15U & 0xff) & 1 | iVar11 * 2) + 0x1c);
          }
          ppuVar3[7] = puVar4;
          ppuVar3[4] = (uint *)0x0;
          ppuVar3[5] = (uint *)0x0;
          ppuVar2 = (uint **)(puVar31 + (int)puVar4 + 0x4b);
          if ((*(uint *)(iVar7 + 0x3b7ec) & 1 << ((uint)puVar4 & 0xff)) == 0) {
            *(uint *)(iVar7 + 0x3b7ec) = *(uint *)(iVar7 + 0x3b7ec) | 1 << ((uint)puVar4 & 0xff);
            *ppuVar2 = (uint *)ppuVar3;
            ppuVar3[6] = (uint *)ppuVar2;
          }
          else {
            uVar9 = (int)puVar4 - 0x1f;
            if (uVar9 != 0) {
              uVar9 = 0x19 - ((uint)puVar4 >> 1);
            }
            iVar11 = (int)puVar22 << (uVar9 & 0xff);
            puVar4 = *ppuVar2;
            do {
              puVar28 = puVar4;
              if ((uint *)(puVar28[1] & 0xfffffffc) == puVar22) {
                puVar22 = (uint *)puVar28[2];
                puVar4 = *(uint **)(iVar7 + 0x3b7f8);
                bVar35 = puVar22 <= puVar4;
                bVar34 = puVar4 == puVar22;
                if (!bVar35 || bVar34) {
                  bVar35 = puVar28 <= puVar4;
                  bVar34 = puVar4 == puVar28;
                }
                if (bVar35 && !bVar34) goto LAB_0003ae30;
                puVar22[3] = (uint)ppuVar3;
                puVar28[2] = (uint)ppuVar3;
                ppuVar3[6] = (uint *)0x0;
                ppuVar3[2] = puVar22;
                ppuVar3[3] = puVar28;
                goto LAB_0003bad0;
              }
              iVar12 = iVar11 >> 0x1f;
              iVar11 = iVar11 << 1;
              ppuVar2 = (uint **)(puVar28 + (4 - iVar12));
              puVar4 = *ppuVar2;
            } while (*ppuVar2 != (uint *)0x0);
            if (ppuVar2 < *(uint ***)(iVar7 + 0x3b7f8)) goto LAB_0003ae30;
            *ppuVar2 = (uint *)ppuVar3;
            ppuVar3[6] = puVar28;
          }
          ppuVar3[2] = (uint *)ppuVar3;
          ppuVar3[3] = (uint *)ppuVar3;
        }
      }
    }
LAB_0003bad0:
    uVar9 = puVar31[3];
    if (uVar9 <= uVar29) {
LAB_0003badc:
      puVar32 = (undefined4 *)__errno();
      *puVar32 = 0xc;
      return (uint **)0x0;
    }
  }
  puVar22 = (uint *)puVar31[6];
  puVar31[3] = uVar9 - uVar29;
  puVar31[6] = (int)puVar22 + uVar29;
  *(uint *)((int)puVar22 + uVar29 + 4) = uVar9 - uVar29 | 1;
  puVar22[1] = uVar29 | 3;
LAB_0003ac44:
  return (uint **)(puVar22 + 2);
LAB_0003bb98:
  do {
    do {
      ppuVar3 = ppuVar13;
      ppuVar18 = ppuVar21;
      ppuVar13 = (uint **)ppuVar3[5];
      ppuVar21 = ppuVar3 + 5;
    } while (ppuVar13 != (uint **)0x0);
    ppuVar13 = (uint **)ppuVar3[4];
    ppuVar21 = ppuVar3 + 4;
  } while (ppuVar13 != (uint **)0x0);
  if (ppuVar18 < ppuVar5) goto LAB_0003ae30;
  *ppuVar18 = (uint *)0x0;
LAB_0003bbd0:
  if (puVar31 != (uint *)0x0) {
    puVar28 = ppuVar15[7];
    ppuVar5 = (uint **)(DAT_0003beec + (int)puVar28 * 4 + 0x3bd14);
    if ((uint **)*ppuVar5 == ppuVar15) {
      *ppuVar5 = (uint *)ppuVar3;
      if (ppuVar3 == (uint **)0x0) {
        *(uint *)(DAT_0003bef0 + 0x3bcc4) =
             *(uint *)(DAT_0003bef0 + 0x3bcc4) & ~(1 << ((uint)puVar28 & 0xff));
      }
      else {
LAB_0003bc4c:
        ppuVar5 = *(uint ***)(DAT_0003bef4 + 0x3bc68);
        if (ppuVar3 < ppuVar5) goto LAB_0003ae30;
        ppuVar3[6] = puVar31;
        ppuVar13 = (uint **)ppuVar15[4];
        if (ppuVar13 != (uint **)0x0) {
          if (ppuVar13 < ppuVar5) goto LAB_0003ae30;
          ppuVar3[4] = (uint *)ppuVar13;
          ppuVar13[6] = (uint *)ppuVar3;
        }
        puVar31 = ppuVar15[5];
        if (puVar31 != (uint *)0x0) {
          if (puVar31 < *(uint **)(DAT_0003bef8 + 0x3bca8)) goto LAB_0003ae30;
          ppuVar3[5] = puVar31;
          puVar31[6] = (uint)ppuVar3;
        }
      }
    }
    else {
      if (puVar31 < *(uint **)(DAT_0003beec + 0x3bbf8)) goto LAB_0003ae30;
      iVar7 = 0x14;
      if ((uint **)puVar31[4] == ppuVar15) {
        iVar7 = 0x10;
      }
      *(uint ***)((int)puVar31 + iVar7) = ppuVar3;
      if (ppuVar3 != (uint **)0x0) goto LAB_0003bc4c;
    }
  }
LAB_0003bccc:
  uVar9 = ((uint)puVar4 & 0xfffffffc) + uVar9;
  ppuVar15 = (uint **)((int)ppuVar15 + ((uint)puVar4 & 0xfffffffc));
  puVar31 = (uint *)(DAT_0003befc + 0x3bce4);
LAB_0003bce0:
  ppuVar15[1] = (uint *)((uint)ppuVar15[1] & 0xfffffffe);
  puVar22[1] = uVar9 | 1;
  *(uint *)((int)puVar22 + uVar9) = uVar9;
  if (uVar9 < 0x100) {
    uVar29 = uVar9 & 0xfffffff8;
    ppuVar3 = (uint **)((int)puVar31 + uVar29 + 0x24);
    if ((*puVar31 & 1 << (uVar9 >> 3 & 0xff)) == 0) {
      *puVar31 = *puVar31 | 1 << (uVar9 >> 3 & 0xff);
      ppuVar5 = ppuVar3;
    }
    else {
      ppuVar5 = *(uint ***)((int)puVar31 + uVar29 + 0x2c);
      if (ppuVar5 < (uint **)puVar31[4]) goto LAB_0003ae30;
    }
    *(uint **)((int)puVar31 + uVar29 + 0x2c) = puVar22;
    ppuVar5[3] = puVar22;
LAB_0003be48:
    puVar22[2] = (uint)ppuVar5;
    puVar22[3] = (uint)ppuVar3;
  }
  else {
    uVar29 = 0;
    if ((uVar9 >> 8 != 0) && (uVar29 = 0x1f, uVar9 >> 0x18 == 0)) {
      uVar29 = uVar9 >> 8;
      uVar14 = uVar29 + 0xfff00 >> 0x10 & 8;
      uVar10 = (uVar29 << uVar14) + 0x7f000 >> 0x10 & 4;
      uVar6 = ((uVar29 << uVar14) << uVar10) + 0x3c000 >> 0x10 & 2;
      iVar7 = ((((uVar29 << uVar14) << uVar10) << uVar6) >> 0xf) - (uVar10 | uVar14 | uVar6);
      uVar29 = (uVar9 >> (iVar7 + 0x15U & 0xff) & 1 | iVar7 * 2) + 0x1c;
    }
    puVar22[7] = uVar29;
    puVar22[4] = 0;
    puVar22[5] = 0;
    ppuVar3 = (uint **)(puVar31 + uVar29 + 0x4b);
    if ((puVar31[1] & 1 << (uVar29 & 0xff)) == 0) {
      puVar31[1] = puVar31[1] | 1 << (uVar29 & 0xff);
      *ppuVar3 = puVar22;
    }
    else {
      uVar14 = uVar29 - 0x1f;
      if (uVar14 != 0) {
        uVar14 = 0x19 - (uVar29 >> 1);
      }
      iVar7 = uVar9 << (uVar14 & 0xff);
      ppuVar5 = (uint **)*ppuVar3;
      do {
        ppuVar3 = ppuVar5;
        if (((uint)ppuVar3[1] & 0xfffffffc) == uVar9) {
          ppuVar5 = (uint **)ppuVar3[2];
          ppuVar13 = (uint **)puVar31[4];
          bVar35 = ppuVar5 <= ppuVar13;
          bVar34 = ppuVar13 == ppuVar5;
          if (!bVar35 || bVar34) {
            bVar35 = ppuVar3 <= ppuVar13;
            bVar34 = ppuVar13 == ppuVar3;
          }
          if (bVar35 && !bVar34) goto LAB_0003ae30;
          ppuVar5[3] = puVar22;
          ppuVar3[2] = puVar22;
          puVar22[6] = 0;
          goto LAB_0003be48;
        }
        iVar11 = iVar7 >> 0x1f;
        iVar7 = iVar7 << 1;
        ppuVar13 = ppuVar3 + (4 - iVar11);
        ppuVar5 = (uint **)*ppuVar13;
      } while ((uint **)*ppuVar13 != (uint **)0x0);
      if (ppuVar13 < (uint **)puVar31[4]) goto LAB_0003ae30;
      *ppuVar13 = puVar22;
    }
    puVar22[6] = (uint)ppuVar3;
    puVar22[2] = (uint)puVar22;
    puVar22[3] = (uint)puVar22;
  }
LAB_0003be70:
  return ppuVar2 + 2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003bf1c FUN_0003bf1c */

uint ** FUN_0003bf1c(int param_1)

{
  int iVar1;
  uint **ppuVar2;
  void *pvVar3;
  void *pvVar4;
  void *pvVar5;
  int iVar6;
  uint **ppuVar7;
  void **ppvVar8;
  uint uVar9;
  void *pvVar10;
  uint uVar11;
  uint **ppuVar12;
  int iVar13;
  void *pvVar14;
  void **ppvVar15;
  void **ppvVar16;
  void *pvVar17;
  uint *puVar18;
  size_t __len;
  uint **ppuVar19;
  uint **unaff_r5;
  uint **ppuVar20;
  uint **unaff_r6;
  uint uVar21;
  uint uVar22;
  uint **ppuVar23;
  uint uVar24;
  uint uVar25;
  uint *puVar26;
  uint *puVar27;
  void **ppvVar28;
  void **ppvVar29;
  uint *puVar30;
  int iVar31;
  bool bVar32;
  bool bVar33;
  int local_2c;
  
  iVar31 = DAT_0003c5ec;
  if (param_1 == 0) {
    return (uint **)0x0;
  }
  ppuVar7 = (uint **)(param_1 + -8);
  puVar27 = (uint *)(DAT_0003c5ec + 0x3bf3c);
  ppuVar12 = *(uint ***)(DAT_0003c5ec + 0x3bf4c);
  if ((ppuVar7 < ppuVar12) || (uVar22 = *(uint *)(param_1 + -4), (uVar22 & 2) == 0))
  goto LAB_0003c474;
  uVar9 = uVar22 & 0xfffffffc;
  ppuVar2 = (uint **)((int)ppuVar7 + uVar9);
  if ((uVar22 & 1) == 0) {
    puVar18 = *ppuVar7;
    if (((uint)puVar18 & 1) != 0) {
      __len = uVar9 + ((uint)puVar18 & 0xfffffffe) + 0x10;
      ppuVar7 = (uint **)munmap((void *)((int)ppuVar7 - ((uint)puVar18 & 0xfffffffe)),__len);
      if (ppuVar7 != (uint **)0x0) {
        return ppuVar7;
      }
      ppuVar7 = (uint **)(*(int *)(iVar31 + 0x3c0e8) - __len);
      *(uint ***)(iVar31 + 0x3c0e8) = ppuVar7;
      return ppuVar7;
    }
    ppuVar7 = (uint **)((int)ppuVar7 - (int)puVar18);
    if (ppuVar7 < ppuVar12) goto LAB_0003c474;
    uVar9 = (int)puVar18 + uVar9;
    if (*(uint ***)(DAT_0003c5ec + 0x3bf50) == ppuVar7) {
      puVar18 = ppuVar2[1];
      if (((uint)puVar18 & 3) == 3) {
        *(uint *)(DAT_0003c5ec + 0x3bf44) = uVar9;
        ppuVar2[1] = (uint *)((uint)puVar18 & 0xfffffffe);
        ppuVar7[1] = (uint *)(uint **)(uVar9 | 1);
        *(uint *)((int)ppuVar7 + uVar9) = uVar9;
        return (uint **)(uVar9 | 1);
      }
    }
    else if (puVar18 < 0x100) {
      unaff_r5 = (uint **)ppuVar7[2];
      ppuVar23 = (uint **)unaff_r5[3];
      bVar32 = ppuVar23 != ppuVar7;
      if (!bVar32) {
        unaff_r6 = (uint **)ppuVar7[3];
        ppuVar23 = (uint **)unaff_r6[2];
      }
      if (bVar32 || ppuVar23 != ppuVar7) goto LAB_0003c474;
      if (unaff_r5 == unaff_r6) {
        *puVar27 = *(uint *)(DAT_0003c5f0 + 0x3c124) & ~(1 << ((uint)puVar18 >> 3 & 0xff));
      }
      else {
        ppuVar23 = (uint **)((int)puVar27 + ((uint)puVar18 & 0xfffffff8) + 0x24);
        bVar32 = ppuVar23 <= unaff_r5;
        if (unaff_r5 != ppuVar23) {
          bVar32 = unaff_r5 <= ppuVar12;
        }
        if (bVar32 && (unaff_r5 != ppuVar23 && ppuVar12 != unaff_r5)) goto LAB_0003c474;
        bVar32 = ppuVar23 <= unaff_r6;
        if (unaff_r6 != ppuVar23) {
          bVar32 = unaff_r6 <= ppuVar12;
        }
        if (bVar32 && (unaff_r6 != ppuVar23 && ppuVar12 != unaff_r6)) goto LAB_0003c474;
        unaff_r5[3] = (uint *)unaff_r6;
        unaff_r6[2] = (uint *)unaff_r5;
      }
    }
    else {
      ppuVar23 = (uint **)ppuVar7[3];
      puVar18 = ppuVar7[6];
      if (ppuVar23 == ppuVar7) {
        ppuVar20 = ppuVar7 + 5;
        unaff_r5 = (uint **)*ppuVar20;
        bVar32 = unaff_r5 == (uint **)0x0;
        if (bVar32) {
          ppuVar20 = ppuVar7 + 4;
          unaff_r5 = (uint **)*ppuVar20;
        }
        if (bVar32 && unaff_r5 == (uint **)0x0) {
          ppuVar23 = (uint **)0x0;
        }
        else {
          do {
            do {
              ppuVar23 = unaff_r5;
              ppuVar19 = ppuVar20;
              unaff_r5 = (uint **)ppuVar23[5];
              ppuVar20 = ppuVar23 + 5;
            } while (unaff_r5 != (uint **)0x0);
            unaff_r5 = (uint **)ppuVar23[4];
            ppuVar20 = ppuVar23 + 4;
          } while (unaff_r5 != (uint **)0x0);
          if (ppuVar19 < ppuVar12) goto LAB_0003c474;
          *ppuVar19 = (uint *)0x0;
          unaff_r5 = (uint **)0x0;
        }
      }
      else {
        ppuVar20 = (uint **)ppuVar7[2];
        unaff_r5 = (uint **)ppuVar20[3];
        bVar32 = unaff_r5 != ppuVar7;
        if (!bVar32) {
          unaff_r5 = (uint **)ppuVar23[2];
        }
        if ((bVar32 || unaff_r5 != ppuVar7) || (ppuVar20 < ppuVar12)) goto LAB_0003c474;
        ppuVar20[3] = (uint *)ppuVar23;
        ppuVar23[2] = (uint *)ppuVar20;
      }
      if (puVar18 != (uint *)0x0) {
        puVar30 = ppuVar7[7];
        unaff_r5 = (uint **)puVar27[(int)puVar30 + 0x4b];
        if (unaff_r5 == ppuVar7) {
          puVar27[(int)puVar30 + 0x4b] = (uint)ppuVar23;
          if (ppuVar23 == (uint **)0x0) {
            *(uint *)(iVar31 + 0x3bf40) =
                 *(uint *)(iVar31 + 0x3bf40) & ~(1 << ((uint)puVar30 & 0xff));
          }
          else {
LAB_0003c138:
            ppuVar12 = *(uint ***)(iVar31 + 0x3bf4c);
            if (ppuVar23 < ppuVar12) goto LAB_0003c474;
            ppuVar23[6] = puVar18;
            ppuVar20 = (uint **)ppuVar7[4];
            if (ppuVar20 != (uint **)0x0) {
              if (ppuVar20 < ppuVar12) goto LAB_0003c474;
              ppuVar23[4] = (uint *)ppuVar20;
              ppuVar20[6] = (uint *)ppuVar23;
            }
            puVar18 = ppuVar7[5];
            if (puVar18 != (uint *)0x0) {
              if (puVar18 < *(uint **)(iVar31 + 0x3bf4c)) goto LAB_0003c474;
              ppuVar23[5] = puVar18;
              puVar18[6] = (uint)ppuVar23;
            }
          }
        }
        else {
          if (puVar18 < *(uint **)(iVar31 + 0x3bf4c)) goto LAB_0003c474;
          iVar13 = 0x14;
          if ((uint **)puVar18[4] == ppuVar7) {
            iVar13 = 0x10;
          }
          *(uint ***)((int)puVar18 + iVar13) = ppuVar23;
          if (ppuVar23 != (uint **)0x0) goto LAB_0003c138;
        }
      }
    }
  }
  if ((ppuVar2 <= ppuVar7) || (puVar18 = ppuVar2[1], ((uint)puVar18 & 1) == 0)) goto LAB_0003c474;
  if (((uint)puVar18 & 2) == 0) {
    if (*(uint ***)(iVar31 + 0x3bf54) == ppuVar2) {
      *(uint ***)(iVar31 + 0x3bf54) = ppuVar7;
      ppuVar12 = (uint **)(*(int *)(iVar31 + 0x3bf48) + uVar9);
      *(uint ***)(iVar31 + 0x3bf48) = ppuVar12;
      ppuVar7[1] = (uint *)((uint)ppuVar12 | 1);
      if (ppuVar7 == *(uint ***)(iVar31 + 0x3bf50)) {
        *(undefined4 *)(iVar31 + 0x3bf44) = 0;
        *(undefined4 *)(iVar31 + 0x3bf50) = 0;
      }
      if (ppuVar12 <= *(uint ***)(iVar31 + 0x3bf58)) {
        return ppuVar12;
      }
      ppuVar7 = (uint **)0x0;
      iVar31 = DAT_0003cbc0 + 0x3c620;
      uVar22 = *(uint *)(DAT_0003cbc0 + 0x3c638);
      if (uVar22 == 0) goto LAB_0003cbac;
      local_2c = 0;
      uVar9 = 0;
      if (0x28 < *(uint *)(DAT_0003cbc0 + 0x3c62c)) {
        iVar13 = *(int *)(DAT_0003cbc4 + 0x3c654);
        iVar31 = FUN_0003a538(*(uint *)(DAT_0003cbc0 + 0x3c62c) + iVar13 + -0x29,iVar13);
        uVar21 = (iVar31 + -1) * iVar13;
        iVar31 = DAT_0003cbc8 + 0x3c674;
        puVar27 = (uint *)(DAT_0003cbc8 + 0x3c82c);
        do {
          if ((*puVar27 <= uVar22) && (uVar22 < *puVar27 + puVar27[1])) goto LAB_0003c6a0;
          puVar27 = (uint *)puVar27[2];
        } while (puVar27 != (uint *)0x0);
        puVar27 = (uint *)0x0;
LAB_0003c6a0:
        uVar9 = 0;
        if ((puVar27[3] & 8) == 0) {
          if ((puVar27[3] & 1) == 0) {
            pvVar3 = sbrk(0);
            iVar31 = DAT_0003cbd0 + 0x3c6d8;
            uVar9 = 0;
            if (pvVar3 == (void *)(*puVar27 + puVar27[1])) {
              if (0x7ffffffe < uVar21) {
                uVar21 = 0x80000000 - iVar13;
              }
              pvVar4 = sbrk(-uVar21);
              uVar9 = 0;
              pvVar5 = sbrk(0);
              if (pvVar4 == (void *)0xffffffff) {
                iVar31 = DAT_0003cbd4 + 0x3c808;
              }
              else {
                uVar21 = (int)pvVar3 - (int)pvVar5;
                iVar31 = DAT_0003cbd8 + 0x3c718;
                if (pvVar5 <= pvVar3 && uVar21 != 0) goto LAB_0003c778;
              }
            }
          }
          else {
            uVar22 = puVar27[1];
            uVar9 = 0;
            if (uVar21 <= uVar22) {
              uVar9 = *puVar27;
              uVar24 = DAT_0003cbc8 + 0x3c82c;
              do {
                if ((uVar9 <= uVar24) && (uVar24 < uVar9 + uVar22)) {
                  uVar9 = 0;
                  goto LAB_0003c804;
                }
                uVar24 = *(uint *)(uVar24 + 8);
              } while (uVar24 != 0);
              iVar13 = munmap((void *)(uVar9 + (uVar22 - uVar21)),uVar21);
              uVar9 = 0;
              iVar31 = DAT_0003cbcc + 0x3c778;
              if (iVar13 == 0) {
LAB_0003c778:
                uVar9 = 0;
                if (uVar21 != 0) {
                  puVar27[1] = puVar27[1] - uVar21;
                  iVar6 = *(int *)(iVar31 + 0x18);
                  *(uint *)(iVar31 + 0x1ac) = *(int *)(iVar31 + 0x1ac) - uVar21;
                  uVar22 = iVar6 + 8U & 7;
                  iVar13 = *(int *)(iVar31 + 0xc) - uVar21;
                  if (uVar22 != 0) {
                    uVar22 = -iVar6 - 8U & 7;
                  }
                  uVar9 = iVar13 - uVar22;
                  *(uint *)(iVar31 + 0x18) = iVar6 + uVar22;
                  *(uint *)(iVar31 + 0xc) = uVar9;
                  *(uint *)(iVar6 + uVar22 + 4) = uVar9 | 1;
                  *(undefined4 *)(iVar6 + iVar13 + 4) = 0x28;
                  *(undefined4 *)(iVar31 + 0x1c) = *(undefined4 *)(DAT_0003cbdc + 0x3c7f0);
                  uVar9 = uVar21;
                }
              }
            }
          }
        }
      }
LAB_0003c804:
      if (*(void ***)(iVar31 + 0x1c0) != (void **)0x0) {
        local_2c = 0;
        ppvVar8 = (void **)(iVar31 + 0x1b8);
        ppvVar28 = *(void ***)(iVar31 + 0x1c0);
        do {
          ppvVar29 = (void **)ppvVar28[2];
          if (((uint)ppvVar28[3] & 9) == 1) {
            pvVar4 = *ppvVar28;
            pvVar3 = pvVar4;
            if (((int)pvVar4 + 8U & 7) != 0) {
              pvVar3 = (void *)((int)pvVar4 + (-(int)pvVar4 - 8U & 7));
            }
            uVar22 = *(uint *)((int)pvVar3 + 4);
            if ((uVar22 & 2) == 0) {
              pvVar5 = ppvVar28[1];
              uVar21 = uVar22 & 0xfffffffc;
              if (((int)pvVar4 + (int)pvVar5) - 0x28U <= (int)pvVar3 + uVar21) {
                if (*(void **)(iVar31 + 0x14) == pvVar3) {
                  *(undefined4 *)(iVar31 + 8) = 0;
                  *(undefined4 *)(iVar31 + 0x14) = 0;
                }
                else {
                  pvVar10 = *(void **)((int)pvVar3 + 0xc);
                  uVar24 = *(uint *)((int)pvVar3 + 0x18);
                  if (pvVar10 == pvVar3) {
                    ppvVar16 = (void **)((int)pvVar3 + 0x14);
                    pvVar14 = *ppvVar16;
                    bVar32 = pvVar14 == (void *)0x0;
                    if (bVar32) {
                      ppvVar16 = (void **)((int)pvVar3 + 0x10);
                      pvVar14 = *ppvVar16;
                    }
                    if (bVar32 && pvVar14 == (void *)0x0) {
                      pvVar10 = (void *)0x0;
                    }
                    else {
                      do {
                        do {
                          ppvVar15 = ppvVar16;
                          pvVar10 = pvVar14;
                          pvVar14 = *(void **)((int)pvVar10 + 0x14);
                          ppvVar16 = (void **)((int)pvVar10 + 0x14);
                        } while (pvVar14 != (void *)0x0);
                        pvVar14 = *(void **)((int)pvVar10 + 0x10);
                        ppvVar16 = (void **)((int)pvVar10 + 0x10);
                      } while (pvVar14 != (void *)0x0);
                      if (ppvVar15 < *(void ***)(iVar31 + 0x10)) goto LAB_0003cbbc;
                      *ppvVar15 = (void *)0x0;
                    }
                  }
                  else {
                    uVar25 = *(uint *)((int)pvVar3 + 8);
                    pvVar14 = *(void **)(uVar25 + 0xc);
                    bVar32 = pvVar14 != pvVar3;
                    if (!bVar32) {
                      pvVar14 = *(void **)((int)pvVar10 + 8);
                    }
                    if ((bVar32 || pvVar14 != pvVar3) || (uVar25 < *(uint *)(iVar31 + 0x10)))
                    goto LAB_0003cbbc;
                    *(void **)(uVar25 + 0xc) = pvVar10;
                    *(uint *)((int)pvVar10 + 8) = uVar25;
                  }
                  if (uVar24 != 0) {
                    uVar25 = *(uint *)((int)pvVar3 + 0x1c);
                    ppvVar16 = (void **)(iVar31 + uVar25 * 4 + 300);
                    if (*ppvVar16 == pvVar3) {
                      *ppvVar16 = pvVar10;
                      if (pvVar10 == (void *)0x0) {
                        *(uint *)(iVar31 + 4) = *(uint *)(iVar31 + 4) & ~(1 << (uVar25 & 0xff));
                      }
                      else {
LAB_0003c988:
                        pvVar14 = *(void **)(iVar31 + 0x10);
                        if (pvVar10 < pvVar14) goto LAB_0003cbbc;
                        *(uint *)((int)pvVar10 + 0x18) = uVar24;
                        pvVar17 = *(void **)((int)pvVar3 + 0x10);
                        if (pvVar17 != (void *)0x0) {
                          if (pvVar17 < pvVar14) goto LAB_0003cbbc;
                          *(void **)((int)pvVar10 + 0x10) = pvVar17;
                          *(void **)((int)pvVar17 + 0x18) = pvVar10;
                        }
                        uVar24 = *(uint *)((int)pvVar3 + 0x14);
                        if (uVar24 != 0) {
                          if (uVar24 < *(uint *)(iVar31 + 0x10)) goto LAB_0003cbbc;
                          *(uint *)((int)pvVar10 + 0x14) = uVar24;
                          *(void **)(uVar24 + 0x18) = pvVar10;
                        }
                      }
                    }
                    else {
                      if (uVar24 < *(uint *)(iVar31 + 0x10)) goto LAB_0003cbbc;
                      iVar13 = 0x14;
                      if (*(void **)(uVar24 + 0x10) == pvVar3) {
                        iVar13 = 0x10;
                      }
                      *(void **)(uVar24 + iVar13) = pvVar10;
                      if (pvVar10 != (void *)0x0) goto LAB_0003c988;
                    }
                  }
                }
                iVar31 = munmap(pvVar4,(size_t)pvVar5);
                iVar13 = DAT_0003cbe4;
                if (iVar31 == 0) {
                  iVar31 = DAT_0003cbe0 + 0x3cb10;
                  *(int *)(DAT_0003cbe0 + 0x3ccbc) = *(int *)(DAT_0003cbe0 + 0x3ccbc) - (int)pvVar5;
                  ppvVar8[2] = ppvVar29;
                  local_2c = (int)pvVar5 + local_2c;
                  ppvVar28 = ppvVar8;
                }
                else {
                  uVar24 = 0;
                  iVar31 = DAT_0003cbe4 + 0x3ca14;
                  if ((uVar22 >> 8 != 0) && (uVar24 = 0x1f, uVar22 >> 0x18 == 0)) {
                    uVar22 = uVar22 >> 8;
                    uVar24 = uVar22 + 0xfff00 >> 0x10 & 8;
                    uVar11 = (uVar22 << uVar24) + 0x7f000 >> 0x10 & 4;
                    uVar25 = ((uVar22 << uVar24) << uVar11) + 0x3c000 >> 0x10 & 2;
                    iVar6 = ((((uVar22 << uVar24) << uVar11) << uVar25) >> 0xf) -
                            (uVar11 | uVar24 | uVar25);
                    uVar24 = (uVar21 >> (iVar6 + 0x15U & 0xff) & 1 | iVar6 * 2) + 0x1c;
                  }
                  *(uint *)((int)pvVar3 + 0x1c) = uVar24;
                  *(undefined4 *)((int)pvVar3 + 0x10) = 0;
                  *(undefined4 *)((int)pvVar3 + 0x14) = 0;
                  ppvVar8 = (void **)(iVar31 + uVar24 * 4 + 300);
                  if ((*(uint *)(iVar13 + 0x3ca18) & 1 << (uVar24 & 0xff)) == 0) {
                    *(uint *)(iVar13 + 0x3ca18) = *(uint *)(iVar13 + 0x3ca18) | 1 << (uVar24 & 0xff)
                    ;
                    *ppvVar8 = pvVar3;
                    *(void ***)((int)pvVar3 + 0x18) = ppvVar8;
                  }
                  else {
                    uVar22 = uVar24 - 0x1f;
                    if (uVar22 != 0) {
                      uVar22 = 0x19 - (uVar24 >> 1);
                    }
                    iVar6 = uVar21 << (uVar22 & 0xff);
                    pvVar4 = *ppvVar8;
                    do {
                      pvVar5 = pvVar4;
                      if ((*(uint *)((int)pvVar5 + 4) & 0xfffffffc) == uVar21) {
                        pvVar4 = *(void **)((int)pvVar5 + 8);
                        pvVar10 = *(void **)(iVar13 + 0x3ca24);
                        bVar33 = pvVar4 <= pvVar10;
                        bVar32 = pvVar10 == pvVar4;
                        if (!bVar33 || bVar32) {
                          bVar33 = pvVar5 <= pvVar10;
                          bVar32 = pvVar10 == pvVar5;
                        }
                        if (bVar33 && !bVar32) goto LAB_0003cbbc;
                        *(void **)((int)pvVar4 + 0xc) = pvVar3;
                        *(void **)((int)pvVar5 + 8) = pvVar3;
                        *(undefined4 *)((int)pvVar3 + 0x18) = 0;
                        *(void **)((int)pvVar3 + 8) = pvVar4;
                        *(void **)((int)pvVar3 + 0xc) = pvVar5;
                        goto LAB_0003cb50;
                      }
                      iVar1 = iVar6 >> 0x1f;
                      iVar6 = iVar6 << 1;
                      ppvVar8 = (void **)((int)pvVar5 + iVar1 * -4 + 0x10);
                      pvVar4 = *ppvVar8;
                    } while (*ppvVar8 != (void *)0x0);
                    if (ppvVar8 < *(void ***)(iVar13 + 0x3ca24)) {
LAB_0003cbbc:
                    /* WARNING: Subroutine does not return */
                      abort();
                    }
                    *ppvVar8 = pvVar3;
                    *(void **)((int)pvVar3 + 0x18) = pvVar5;
                  }
                  *(void **)((int)pvVar3 + 8) = pvVar3;
                  *(void **)((int)pvVar3 + 0xc) = pvVar3;
                }
              }
            }
          }
LAB_0003cb50:
          ppvVar8 = ppvVar28;
          ppvVar28 = ppvVar29;
        } while (ppvVar29 != (void **)0x0);
      }
      ppuVar7 = (uint **)(local_2c + uVar9);
      if (ppuVar7 == (uint **)0x0) {
        *(undefined4 *)(iVar31 + 0x1c) = 0xffffffff;
        ppuVar7 = (uint **)0x0;
      }
LAB_0003cbac:
      if (ppuVar7 != (uint **)0x0) {
        ppuVar7 = (uint **)0x1;
      }
      return ppuVar7;
    }
    if (*(uint ***)(iVar31 + 0x3bf50) == ppuVar2) {
      *(uint ***)(iVar31 + 0x3bf50) = ppuVar7;
      ppuVar12 = (uint **)(*(int *)(iVar31 + 0x3bf44) + uVar9);
      *(uint ***)(iVar31 + 0x3bf44) = ppuVar12;
      ppuVar7[1] = (uint *)((uint)ppuVar12 | 1);
      *(uint ***)((int)ppuVar7 + (int)ppuVar12) = ppuVar12;
      return ppuVar12;
    }
    if (puVar18 < (uint *)0x100) {
      ppuVar23 = (uint **)ppuVar2[2];
      ppuVar12 = (uint **)ppuVar23[3];
      bVar32 = ppuVar12 != ppuVar2;
      if (!bVar32) {
        unaff_r5 = (uint **)ppuVar2[3];
        ppuVar12 = (uint **)unaff_r5[2];
      }
      if (bVar32 || ppuVar12 != ppuVar2) goto LAB_0003c474;
      if (ppuVar23 == unaff_r5) {
        *puVar27 = *(uint *)(DAT_0003c5f4 + 0x3c540) & ~(1 << ((uint)puVar18 >> 3 & 0xff));
      }
      else {
        ppuVar2 = (uint **)((int)puVar27 + ((uint)puVar18 & 0xfffffff8) + 0x24);
        bVar32 = ppuVar2 <= ppuVar23;
        if (ppuVar23 != ppuVar2) {
          ppuVar12 = *(uint ***)(iVar31 + 0x3bf4c);
          bVar32 = ppuVar23 <= ppuVar12;
        }
        if (bVar32 && (ppuVar23 != ppuVar2 && ppuVar12 != ppuVar23)) goto LAB_0003c474;
        bVar32 = ppuVar2 <= unaff_r5;
        bVar33 = unaff_r5 != ppuVar2;
        if (bVar33) {
          ppuVar2 = *(uint ***)(iVar31 + 0x3bf4c);
          bVar32 = unaff_r5 <= ppuVar2;
        }
        if (bVar32 && (bVar33 && ppuVar2 != unaff_r5)) goto LAB_0003c474;
        ppuVar23[3] = (uint *)unaff_r5;
        unaff_r5[2] = (uint *)ppuVar23;
      }
    }
    else {
      ppuVar12 = (uint **)ppuVar2[3];
      puVar30 = ppuVar2[6];
      if (ppuVar12 == ppuVar2) {
        ppuVar20 = ppuVar2 + 5;
        ppuVar23 = (uint **)*ppuVar20;
        bVar32 = ppuVar23 == (uint **)0x0;
        if (bVar32) {
          ppuVar20 = ppuVar2 + 4;
          ppuVar23 = (uint **)*ppuVar20;
        }
        if (bVar32 && ppuVar23 == (uint **)0x0) {
          ppuVar12 = (uint **)0x0;
        }
        else {
          do {
            do {
              ppuVar12 = ppuVar23;
              ppuVar19 = ppuVar20;
              ppuVar23 = (uint **)ppuVar12[5];
              ppuVar20 = ppuVar12 + 5;
            } while (ppuVar23 != (uint **)0x0);
            ppuVar23 = (uint **)ppuVar12[4];
            ppuVar20 = ppuVar12 + 4;
          } while (ppuVar23 != (uint **)0x0);
          if (ppuVar19 < *(uint ***)(iVar31 + 0x3bf4c)) goto LAB_0003c474;
          *ppuVar19 = (uint *)0x0;
        }
      }
      else {
        puVar26 = ppuVar2[2];
        ppuVar23 = (uint **)puVar26[3];
        bVar32 = ppuVar23 != ppuVar2;
        if (!bVar32) {
          ppuVar23 = (uint **)ppuVar12[2];
        }
        if ((bVar32 || ppuVar23 != ppuVar2) || (puVar26 < *(uint **)(iVar31 + 0x3bf4c)))
        goto LAB_0003c474;
        puVar26[3] = (uint)ppuVar12;
        ppuVar12[2] = puVar26;
      }
      if (puVar30 != (uint *)0x0) {
        puVar26 = ppuVar2[7];
        if ((uint **)puVar27[(int)puVar26 + 0x4b] == ppuVar2) {
          puVar27[(int)puVar26 + 0x4b] = (uint)ppuVar12;
          if (ppuVar12 == (uint **)0x0) {
            *(uint *)(iVar31 + 0x3bf40) =
                 *(uint *)(iVar31 + 0x3bf40) & ~(1 << ((uint)puVar26 & 0xff));
          }
          else {
LAB_0003c554:
            ppuVar23 = *(uint ***)(iVar31 + 0x3bf4c);
            if (ppuVar12 < ppuVar23) goto LAB_0003c474;
            ppuVar12[6] = puVar30;
            ppuVar20 = (uint **)ppuVar2[4];
            if (ppuVar20 != (uint **)0x0) {
              if (ppuVar20 < ppuVar23) goto LAB_0003c474;
              ppuVar12[4] = (uint *)ppuVar20;
              ppuVar20[6] = (uint *)ppuVar12;
            }
            puVar30 = ppuVar2[5];
            if (puVar30 != (uint *)0x0) {
              if (puVar30 < *(uint **)(iVar31 + 0x3bf4c)) goto LAB_0003c474;
              ppuVar12[5] = puVar30;
              puVar30[6] = (uint)ppuVar12;
            }
          }
        }
        else {
          if (puVar30 < *(uint **)(iVar31 + 0x3bf4c)) goto LAB_0003c474;
          iVar13 = 0x14;
          if ((uint **)puVar30[4] == ppuVar2) {
            iVar13 = 0x10;
          }
          *(uint ***)((int)puVar30 + iVar13) = ppuVar12;
          if (ppuVar12 != (uint **)0x0) goto LAB_0003c554;
        }
      }
    }
    uVar9 = ((uint)puVar18 & 0xfffffffc) + uVar9;
    ppuVar7[1] = (uint *)(uVar9 | 1);
    *(uint *)((int)ppuVar7 + uVar9) = uVar9;
    if (ppuVar7 == *(uint ***)(iVar31 + 0x3bf50)) {
      *(uint *)(iVar31 + 0x3bf44) = uVar9;
      return *(uint ***)(iVar31 + 0x3bf50);
    }
  }
  else {
    ppuVar2[1] = (uint *)((uint)puVar18 & 0xfffffffe);
    ppuVar7[1] = (uint *)(uVar9 | 1);
    *(uint *)((int)ppuVar7 + uVar9) = uVar9;
  }
  if (0xff < uVar9) {
    puVar18 = (uint *)0x0;
    if ((uVar9 >> 8 != 0) && (puVar18 = (uint *)0x1f, uVar9 >> 0x18 == 0)) {
      uVar22 = uVar9 >> 8;
      uVar24 = uVar22 + 0xfff00 >> 0x10 & 8;
      uVar21 = (uVar22 << uVar24) + 0x7f000 >> 0x10 & 4;
      uVar25 = ((uVar22 << uVar24) << uVar21) + 0x3c000 >> 0x10 & 2;
      iVar13 = ((((uVar22 << uVar24) << uVar21) << uVar25) >> 0xf) - (uVar21 | uVar24 | uVar25);
      puVar18 = (uint *)((uVar9 >> (iVar13 + 0x15U & 0xff) & 1 | iVar13 * 2) + 0x1c);
    }
    ppuVar7[7] = puVar18;
    ppuVar7[4] = (uint *)0x0;
    ppuVar7[5] = (uint *)0x0;
    ppuVar12 = (uint **)(puVar27 + (int)puVar18 + 0x4b);
    if ((*(uint *)(iVar31 + 0x3bf40) & 1 << ((uint)puVar18 & 0xff)) == 0) {
      *(uint *)(iVar31 + 0x3bf40) = *(uint *)(iVar31 + 0x3bf40) | 1 << ((uint)puVar18 & 0xff);
      *ppuVar12 = (uint *)ppuVar7;
      ppuVar7[6] = (uint *)ppuVar12;
    }
    else {
      uVar22 = (int)puVar18 - 0x1f;
      if (uVar22 != 0) {
        uVar22 = 0x19 - ((uint)puVar18 >> 1);
      }
      iVar13 = uVar9 << (uVar22 & 0xff);
      ppuVar12 = (uint **)*ppuVar12;
      do {
        ppuVar2 = ppuVar12;
        if (((uint)ppuVar2[1] & 0xfffffffc) == uVar9) {
          ppuVar12 = (uint **)ppuVar2[2];
          ppuVar23 = *(uint ***)(iVar31 + 0x3bf4c);
          bVar33 = ppuVar12 <= ppuVar23;
          bVar32 = ppuVar23 == ppuVar12;
          if (!bVar33 || bVar32) {
            bVar33 = ppuVar2 <= ppuVar23;
            bVar32 = ppuVar23 == ppuVar2;
          }
          if (!bVar33 || bVar32) {
            ppuVar12[3] = (uint *)ppuVar7;
            ppuVar2[2] = (uint *)ppuVar7;
            ppuVar7[6] = (uint *)0x0;
            ppuVar7[2] = (uint *)ppuVar12;
            ppuVar7[3] = (uint *)ppuVar2;
            return ppuVar12;
          }
          goto LAB_0003c474;
        }
        iVar6 = iVar13 >> 0x1f;
        iVar13 = iVar13 << 1;
        ppuVar23 = ppuVar2 + (4 - iVar6);
        ppuVar12 = (uint **)*ppuVar23;
      } while ((uint **)*ppuVar23 != (uint **)0x0);
      ppuVar12 = *(uint ***)(iVar31 + 0x3bf4c);
      if (ppuVar23 < ppuVar12) {
LAB_0003c474:
                    /* WARNING: Subroutine does not return */
        abort();
      }
      *ppuVar23 = (uint *)ppuVar7;
      ppuVar7[6] = (uint *)ppuVar2;
    }
    ppuVar7[2] = (uint *)ppuVar7;
    ppuVar7[3] = (uint *)ppuVar7;
    return ppuVar12;
  }
  uVar22 = uVar9 & 0xfffffff8;
  ppuVar12 = (uint **)((int)puVar27 + uVar22 + 0x24);
  if ((*puVar27 & 1 << (uVar9 >> 3 & 0xff)) == 0) {
    *puVar27 = *puVar27 | 1 << (uVar9 >> 3 & 0xff);
    ppuVar2 = ppuVar12;
  }
  else {
    ppuVar2 = *(uint ***)((int)puVar27 + uVar22 + 0x2c);
    if (ppuVar2 < *(uint ***)(iVar31 + 0x3bf4c)) goto LAB_0003c474;
  }
  *(uint ***)((int)puVar27 + uVar22 + 0x2c) = ppuVar7;
  ppuVar2[3] = (uint *)ppuVar7;
  ppuVar7[2] = (uint *)ppuVar2;
  ppuVar7[3] = (uint *)ppuVar12;
  return ppuVar12;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003cbe8 FUN_0003cbe8 */

void * FUN_0003cbe8(int param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  void *__s;
  
  if ((param_1 == 0) || (uVar1 = FUN_0003a538(0xffffffff,param_1), param_2 <= uVar1)) {
    __s = (void *)FUN_0003a770(param_2 * param_1);
    if (__s != (void *)0x0) {
      if (((*(byte *)((int)__s + -4) & 1) == 0) && ((*(byte *)((int)__s + -8) & 1) != 0)) {
        return __s;
      }
      memset(__s,0,param_2 * param_1);
      return __s;
    }
  }
  else {
    puVar2 = (undefined4 *)__errno();
    *puVar2 = 0xc;
  }
  return (void *)0x0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003cc74 FUN_0003cc74 */

void * FUN_0003cc74(void *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  void *pvVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  
  iVar4 = DAT_0003ce38;
  if (param_1 == (void *)0x0) {
    pvVar3 = (void *)FUN_0003a770(param_2);
    return pvVar3;
  }
  if (0xffffffbf < param_2) {
    puVar1 = (undefined4 *)__errno();
    *puVar1 = 0xc;
    return (void *)0x0;
  }
  uVar6 = *(uint *)((int)param_1 + -4);
  uVar7 = uVar6 & 0xfffffffc;
  if ((0 < (int)uVar7) && ((uVar6 & 2) != 0)) {
    pbVar8 = (byte *)((int)param_1 + -8);
    uVar2 = DAT_0003ce38 + 0x3ccdc;
    if ((*(byte **)(DAT_0003ce38 + 0x3ccec) <= pbVar8) &&
       ((*(byte *)((int)param_1 + (uVar7 - 4)) & 1) != 0)) {
      uVar5 = param_2 + 0xb & 0xfffffff8;
      if (param_2 < 0xb) {
        uVar5 = 0x10;
      }
      uVar6 = uVar6 & 1;
      if ((uVar6 == 0) && ((*pbVar8 & 1) != 0)) {
        if (0xff < uVar5) {
          uVar2 = uVar5 | 4;
        }
        if ((0xff < uVar5 && uVar2 <= uVar7) &&
           (uVar7 - uVar5 <= (uint)(*(int *)(DAT_0003ce3c + 0x3ce2c) * 2))) {
          return param_1;
        }
      }
      else {
        if (uVar5 <= uVar7) {
          uVar7 = uVar7 - uVar5;
          if (0xf < uVar7) {
            *(uint *)((int)param_1 + -4) = uVar5 | uVar6 | 2;
            *(uint *)(pbVar8 + uVar5 + 4) = uVar7 | 3;
            *(uint *)(pbVar8 + uVar7 + uVar5 + 4) = *(uint *)(pbVar8 + uVar7 + uVar5 + 4) | 1;
            FUN_0003bf1c(pbVar8 + uVar5 + 8);
            return param_1;
          }
          return param_1;
        }
        if ((*(int *)(DAT_0003ce38 + 0x3ccf4) == (int)param_1 + (uVar7 - 8)) &&
           (uVar2 = *(int *)(DAT_0003ce38 + 0x3cce8) + uVar7, uVar5 < uVar2)) {
          *(uint *)((int)param_1 + -4) = uVar5 | uVar6 | 2;
          uVar2 = uVar2 - uVar5;
          *(uint *)(pbVar8 + uVar5 + 4) = uVar2 | 1;
          *(uint *)(iVar4 + 0x3cce8) = uVar2;
          *(byte **)(iVar4 + 0x3ccf4) = pbVar8 + uVar5;
          return param_1;
        }
      }
      pvVar3 = (void *)FUN_0003a770(param_2);
      if (pvVar3 == (void *)0x0) {
        return (void *)0x0;
      }
      iVar4 = 4;
      if (((*(byte *)((int)param_1 + -4) & 1) == 0) && (iVar4 = 8, (*pbVar8 & 1) == 0)) {
        iVar4 = 4;
      }
      if (uVar7 - iVar4 < param_2) {
        param_2 = uVar7 - iVar4;
      }
      memcpy(pvVar3,param_1,param_2);
      FUN_0003bf1c(param_1);
      return pvVar3;
    }
  }
                    /* WARNING: Subroutine does not return */
  abort();
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d01c FUN_0003d01c */

void FUN_0003d01c(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_c;
  
  local_c = param_2;
  FUN_0003d044(param_1,&local_c,3,param_3);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d044 FUN_0003d044 */

void ** FUN_0003d044(int param_1,uint *param_2,uint param_3,void **param_4)

{
  uint *puVar1;
  void *__s;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  iVar2 = DAT_0003d204;
  if (param_4 == (void **)0x0) {
    if (param_1 == 0) {
      ppvVar3 = (void **)FUN_0003a770(0);
      return ppvVar3;
    }
    uVar8 = param_1 * 4 + 0xbU & 0xfffffff8;
    if ((uint)(param_1 << 2) < 0xb) {
      uVar8 = 0x10;
    }
  }
  else {
    uVar8 = 0;
    if (param_1 == 0) {
      return param_4;
    }
  }
  if ((param_3 & 1) == 0) {
    uVar6 = 0;
    uVar7 = 0;
    puVar1 = param_2;
    iVar4 = param_1;
    do {
      uVar5 = *puVar1 + 0xb & 0xfffffff8;
      if (*puVar1 < 0xb) {
        uVar5 = 0x10;
      }
      uVar7 = uVar5 + uVar7;
      iVar4 = iVar4 + -1;
      puVar1 = puVar1 + 1;
    } while (iVar4 != 0);
  }
  else {
    uVar6 = *param_2 + 0xb & 0xfffffff8;
    if (*param_2 < 0xb) {
      uVar6 = 0x10;
    }
    uVar7 = uVar6 * param_1;
  }
  uVar5 = *(uint *)(DAT_0003d204 + 0x3d2b0);
  *(uint *)(DAT_0003d204 + 0x3d2b0) = uVar5 & 0xfffffffe;
  __s = (void *)FUN_0003a770(uVar8 + uVar7 + -4);
  if ((uVar5 & 1) != 0) {
    *(uint *)(iVar2 + 0x3d2b0) = *(uint *)(iVar2 + 0x3d2b0) | 1;
  }
  if (__s == (void *)0x0) {
    param_4 = (void **)0x0;
  }
  else {
    uVar5 = *(uint *)((int)__s + -4) & 0xfffffffc;
    if ((param_3 & 2) != 0) {
      memset(__s,0,(uVar5 - uVar8) - 4);
    }
    iVar2 = (int)__s + -8;
    if (param_4 == (void **)0x0) {
      param_4 = (void **)(iVar2 + uVar7 + 8);
      *(uint *)(iVar2 + uVar7 + 4) = uVar5 - uVar7 | 3;
      uVar5 = uVar7;
    }
    *param_4 = __s;
    ppvVar3 = param_4;
    for (param_1 = param_1 + -1; param_1 != 0; param_1 = param_1 + -1) {
      ppvVar3 = ppvVar3 + 1;
      uVar8 = uVar6;
      if ((uVar6 == 0) && (uVar8 = *param_2 + 0xb & 0xfffffff8, *param_2 < 0xb)) {
        uVar8 = 0x10;
      }
      *(uint *)(iVar2 + 4) = uVar8 | 3;
      iVar2 = iVar2 + uVar8;
      uVar5 = uVar5 - uVar8;
      *ppvVar3 = (void *)(iVar2 + 8);
      param_2 = param_2 + 1;
    }
    *(uint *)(iVar2 + 4) = uVar5 | 3;
  }
  return param_4;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d23c FUN_0003d23c */

void FUN_0003d23c(void)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint *puVar5;
  
  iVar2 = DAT_0003d2dc;
  if (*(int *)(DAT_0003d2d0 + 0x3d250) != 0) {
    return;
  }
  pcVar3 = (char *)(DAT_0003d2d8 + 0x3d270);
  *(undefined4 *)(DAT_0003d2d4 + 0x3d268) = 0x200000;
  cVar1 = *pcVar3;
  *(undefined4 *)(iVar2 + 0x3d278) = 0x10000;
  iVar2 = DAT_0003d2e0;
  if (cVar1 == '\0') {
    *pcVar3 = '\x01';
    *(undefined4 *)(&UNK_0003d450 + iVar2) = 1;
  }
  uVar4 = sysconf(0x28);
  puVar5 = (uint *)(DAT_0003d2e8 + 0x3d2b8);
  *(uint *)(DAT_0003d2e4 + 0x3d2b4) = uVar4;
  *puVar5 = uVar4;
  if ((uVar4 & uVar4 - 1) == 0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  abort();
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d2ec FUN_0003d2ec */

uint * FUN_0003d2ec(int param_1)

{
  uint *puVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  int extraout_r1;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  uint *puVar10;
  
  FUN_0003d23c();
  uVar4 = *(uint *)(DAT_0003d31c + 0x3d308);
  uVar5 = (param_1 + uVar4) - 1 & -uVar4;
  if (uVar4 < 9) {
    puVar1 = (uint *)FUN_0003a770(uVar5);
    return puVar1;
  }
  if (uVar4 < 0x11) {
    uVar4 = 0x10;
  }
  uVar8 = 0x10;
  uVar7 = uVar4;
  if ((uVar4 & uVar4 - 1) != 0) {
    do {
      uVar7 = uVar8;
      uVar8 = uVar7 << 1;
    } while (uVar7 < uVar4);
  }
  if (-uVar7 - 0x40 <= uVar5) {
    puVar3 = (undefined4 *)__errno();
    *puVar3 = 0xc;
    return (uint *)0x0;
  }
  uVar4 = uVar5 + 0xb & 0xfffffff8;
  if (uVar5 < 0xb) {
    uVar4 = 0x10;
  }
  iVar2 = FUN_0003a770(uVar4 + uVar7 + 0xc);
  if (iVar2 == 0) {
    return (uint *)0x0;
  }
  FUN_0003a724(iVar2,uVar7);
  puVar1 = (uint *)(iVar2 + -8);
  if (extraout_r1 == 0) {
    puVar6 = (uint *)(iVar2 + -4);
    uVar5 = *puVar6;
  }
  else {
    puVar10 = (uint *)(((iVar2 + uVar7) - 1 & -uVar7) - 8);
    if ((uint)((int)puVar10 - (int)puVar1) < 0x10) {
      puVar10 = (uint *)((int)puVar10 + uVar7);
    }
    uVar8 = (int)puVar10 - (int)puVar1;
    uVar5 = (*(uint *)(iVar2 + -4) & 0xfffffffc) - uVar8;
    if (((*(uint *)(iVar2 + -4) & 1) != 0) || ((*puVar1 & 1) == 0)) {
      puVar6 = puVar10 + 1;
      *puVar6 = uVar5 | *puVar6 & 1 | 2;
      *(uint *)((int)puVar10 + uVar5 + 4) = *(uint *)((int)puVar10 + uVar5 + 4) | 1;
      *(uint *)(iVar2 + -4) = uVar8 | *(uint *)(iVar2 + -4) & 1 | 2;
      uVar5 = *puVar6 | 1;
      *puVar6 = uVar5;
      puVar1 = puVar10;
      goto LAB_0003cfa0;
    }
    *puVar10 = *puVar1 + uVar8;
    uVar5 = uVar5 | 2;
    puVar6 = puVar10 + 1;
    *puVar6 = uVar5;
    puVar1 = puVar10;
  }
  iVar2 = 0;
LAB_0003cfa0:
  if (((uVar5 & 1) != 0) || (pbVar9 = (byte *)0x0, (*(byte *)puVar1 & 1) == 0)) {
    uVar8 = uVar5 & 0xfffffffc;
    pbVar9 = (byte *)0x0;
    if (uVar4 + 0x10 < uVar8) {
      *puVar6 = uVar4 | uVar5 & 1 | 2;
      *(uint *)((int)puVar1 + uVar4 + 4) = uVar8 - uVar4 | 3;
      pbVar9 = (byte *)((int)puVar1 + uVar4 + 8);
      *(uint *)((int)puVar1 + uVar8 + 4) = *(uint *)((int)puVar1 + uVar8 + 4) | 1;
    }
  }
  if (iVar2 != 0) {
    FUN_0003bf1c(iVar2);
  }
  if (pbVar9 != (byte *)0x0) {
    FUN_0003bf1c(pbVar9);
  }
  return puVar1 + 2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d454 FUN_0003d454 */

undefined4 FUN_0003d454(int param_1,uint param_2)

{
  uint *puVar1;
  
  FUN_0003d23c();
  if (param_1 == -3) {
    puVar1 = (uint *)(DAT_0003d4d8 + 0x3d4c4);
  }
  else if (param_1 == -2) {
    if ((param_2 & param_2 - 1) != 0) {
      return 0;
    }
    if (param_2 < *(uint *)(DAT_0003d4d0 + 0x3d4a8)) {
      return 0;
    }
    puVar1 = (uint *)(DAT_0003d4d4 + 0x3d4b8);
  }
  else {
    if (param_1 != -1) {
      return 0;
    }
    puVar1 = (uint *)(DAT_0003d4cc + 0x3d490);
  }
  *puVar1 = param_2;
  return 1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d4dc FUN_0003d4dc */

void FUN_0003d4dc(code *param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  bool bVar7;
  
  iVar1 = DAT_0003d5bc;
  if (*(int *)(DAT_0003d5bc + 0x3d50c) != 0) {
    puVar6 = (uint *)(DAT_0003d5bc + 0x3d6ac);
    do {
      uVar2 = *puVar6;
      uVar5 = uVar2;
      if ((uVar2 + 8 & 7) != 0) {
        uVar5 = uVar2 + (-uVar2 - 8 & 7);
      }
      do {
        if (uVar2 + puVar6[1] <= uVar5) break;
        uVar4 = *(uint *)(iVar1 + 0x3d50c);
        bVar7 = uVar4 == uVar5;
        if (!bVar7) {
          uVar4 = *(uint *)(uVar5 + 4);
        }
        if (bVar7 || uVar4 == 7) break;
        if ((uVar4 & 2) == 0) {
          iVar3 = 0x20;
          if (uVar4 < 0x100) {
            iVar3 = 0x10;
          }
          (*param_1)(uVar5 + iVar3,uVar5 + (uVar4 & 0xfffffffc),param_2);
          uVar2 = *puVar6;
          uVar4 = *(uint *)(uVar5 + 4);
        }
        uVar5 = uVar5 + (uVar4 & 0xfffffffc);
      } while (uVar2 <= uVar5);
      if (*(uint *)(iVar1 + 0x3d50c) == uVar5) {
        (*param_1)(uVar5 + 0x10,uVar5 + (*(uint *)(uVar5 + 4) & 0xfffffffc),param_2);
      }
      puVar6 = (uint *)puVar6[2];
    } while (puVar6 != (uint *)0x0);
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d5c0 FUN_0003d5c0 */

void FUN_0003d5c0(code *param_1,undefined4 param_2)

{
  int iVar1;
  byte *pbVar2;
  byte *pbVar3;
  int iVar4;
  byte *pbVar5;
  byte **ppbVar6;
  bool bVar7;
  
  iVar1 = DAT_0003d6b8;
  ppbVar6 = (byte **)(DAT_0003d6b8 + 0x3d79c);
  do {
    pbVar2 = *ppbVar6;
    pbVar5 = pbVar2;
    if (((uint)(pbVar2 + 8) & 7) != 0) {
      pbVar5 = pbVar2 + (-(int)pbVar2 - 8U & 7);
    }
    do {
      if (pbVar2 + (int)ppbVar6[1] <= pbVar5) break;
      pbVar2 = *(byte **)(iVar1 + 0x3d5fc);
      bVar7 = pbVar2 == pbVar5;
      if (!bVar7) {
        pbVar2 = *(byte **)(pbVar5 + 4);
      }
      if (bVar7 || pbVar2 == (byte *)0x7) break;
      pbVar3 = (byte *)0x0;
      iVar4 = 0;
      if (((uint)pbVar2 & 2) != 0) {
        iVar4 = 4;
        if ((((uint)pbVar2 & 1) == 0) && (iVar4 = 8, (*pbVar5 & 1) == 0)) {
          iVar4 = 4;
        }
        pbVar3 = pbVar5 + 8;
        iVar4 = ((uint)pbVar2 & 0xfffffffc) - iVar4;
      }
      (*param_1)(pbVar5,(uint)pbVar2 & 0xfffffffc,pbVar3,iVar4,param_2);
      pbVar2 = *ppbVar6;
      pbVar5 = pbVar5 + (*(uint *)(pbVar5 + 4) & 0xfffffffc);
    } while (pbVar2 <= pbVar5);
    if (*(byte **)(iVar1 + 0x3d5fc) == pbVar5) {
      (*param_1)(pbVar5,*(undefined4 *)(iVar1 + 0x3d5f0),0,0,param_2);
    }
    ppbVar6 = (byte **)ppbVar6[2];
    if (ppbVar6 == (byte **)0x0) {
      return;
    }
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d6bc FUN_0003d6bc */

uint FUN_0003d6bc(byte *param_1)

{
  uint uVar1;
  uint local_8;
  byte *local_4;
  
  local_8 = 0;
  local_4 = param_1;
  while (*local_4 != 0) {
    local_8 = local_8 * 0x10 + (uint)*local_4;
    uVar1 = local_8 & 0xf0000000;
    if (uVar1 != 0) {
      local_8 = local_8 ^ uVar1 >> 0x18;
    }
    local_8 = local_8 & (uVar1 ^ 0xffffffff);
    local_4 = local_4 + 1;
  }
  return local_8;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d74c FUN_0003d74c */

void FUN_0003d74c(int param_1,__sighandler_t param_2)

{
  bsd_signal(param_1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003d774 FUN_0003d774 */

undefined4 FUN_0003d774(int **param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  int **local_2c;
  ushort local_26;
  int **local_18;
  
  bVar4 = *(int *)(DAT_0003da2c + 0x3d7a4) == 0;
  if (bVar4) {
    FUN_0003dd2c(param_1);
  }
  else {
    dl_iterate_phdr(DAT_0003da20 + 0x3d7b8,param_1);
  }
  local_18 = (int **)*param_1;
  do {
    if (local_18 == param_1) {
      if (bVar4) {
        FUN_0003e4a0(param_1);
      }
      local_18 = (int **)*param_1;
      while( true ) {
        if (local_18 != param_1) {
          local_2c = (int **)*local_18;
        }
        if (local_18 == param_1 || local_18 == (int **)0x0) break;
        if (((local_18[6] == (int *)0x0) || (local_18[7] == (int *)0x0)) ||
           ((local_18[0xb] == (int *)0x0 && (local_18[0xc] == (int *)0x0)))) {
          piVar1 = *local_18;
          piVar3 = local_18[1];
          piVar1[1] = (int)piVar3;
          *piVar3 = (int)piVar1;
          FUN_0003bf1c(local_18);
        }
        local_18 = local_2c;
      }
      return 0;
    }
    if ((*(byte *)(local_18 + 0xf) & 1) == 0) {
      piVar1 = local_18[2];
      if ((int *)piVar1[7] < local_18[3]) {
        iVar2 = (int)local_18[2] + piVar1[7];
        for (local_26 = 0; local_26 != *(ushort *)(piVar1 + 0xb); local_26 = local_26 + 1) {
          if (*(int *)(iVar2 + (uint)local_26 * 0x20) == 1) {
            local_18[10] = (int *)((int)local_18[2] - *(int *)(iVar2 + (uint)local_26 * 0x20 + 8));
            break;
          }
        }
        FUN_0003e060(local_18,iVar2,*(undefined2 *)(piVar1 + 0xb));
      }
      else {
        __android_log_print(6,DAT_0003da24 + 0x3d8cc,DAT_0003da28 + 0x3d8d4,(int)local_18 + 0x3d);
      }
    }
    local_18 = (int **)*local_18;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003da30 FUN_0003da30 */

undefined4 FUN_0003da30(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  size_t local_3c;
  undefined4 *local_2c;
  ushort local_22;
  int local_20;
  int local_1c;
  
  if ((*(short *)(param_1 + 3) != 0) && (param_1[2] != 0)) {
    local_1c = 0;
    local_20 = 0;
    for (local_22 = 0; local_22 != *(ushort *)(param_1 + 3); local_22 = local_22 + 1) {
      if (*(int *)(param_1[2] + (uint)local_22 * 0x20) == 1) {
        if (local_20 == 0) {
          local_20 = *(int *)(param_1[2] + (uint)local_22 * 0x20 + 8) + *param_1;
        }
        if ((*(uint *)(param_1[2] + (uint)local_22 * 0x20 + 4) <= *(uint *)(local_20 + 0x1c)) &&
           (iVar2 = param_1[2] + (uint)local_22 * 0x20,
           *(uint *)(local_20 + 0x1c) < (uint)(*(int *)(iVar2 + 4) + *(int *)(iVar2 + 0x10)))) {
          iVar2 = param_1[2] + (uint)local_22 * 0x20;
          local_1c = (*(int *)(local_20 + 0x1c) - *(int *)(iVar2 + 4)) +
                     *(int *)(iVar2 + 8) + *param_1;
          break;
        }
      }
    }
    if ((local_20 != 0) && (local_1c != 0)) {
      for (local_2c = (undefined4 *)*param_3; local_2c != param_3;
          local_2c = (undefined4 *)*local_2c) {
        if (local_2c[2] == local_20) {
          return 0;
        }
      }
      if (param_1[1] == 0) {
        local_3c = 0;
      }
      else {
        local_3c = strlen((char *)param_1[1]);
      }
      puVar1 = (undefined4 *)FUN_0003cbe8(1,local_3c + 0x40);
      puVar1[2] = local_20;
      if (param_1[1] != 0) {
        strcpy((char *)((int)puVar1 + 0x3d),(char *)param_1[1]);
      }
      FUN_0003e060(puVar1,local_1c,*(undefined2 *)(local_20 + 0x2c));
      *puVar1 = param_3;
      puVar1[1] = param_3[1];
      *(undefined4 **)puVar1[1] = puVar1;
      param_3[1] = puVar1;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003dd2c FUN_0003dd2c */

void FUN_0003dd2c(undefined4 *param_1)

{
  bool bVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  size_t sVar6;
  undefined4 *puVar7;
  char *pcVar8;
  undefined4 *local_108c;
  char *local_1078;
  char *local_1074;
  undefined4 local_1070;
  undefined4 local_106c;
  int local_1068;
  ssize_t local_1064;
  size_t local_1060;
  undefined4 local_105c;
  int local_1058;
  undefined auStack_1054 [4160];
  undefined4 *local_14;
  
  local_14 = param_1;
  local_1058 = open((char *)(DAT_0003e050 + 0x3dd48),0);
  local_105c = 0;
  local_1060 = 0;
  local_1064 = 0;
  while (local_1064 = read(local_1058,auStack_1054 + local_1060,0x1000 - local_1060), 0 < local_1064
        ) {
    auStack_1054[local_1060 + local_1064] = 0;
    local_1068 = 0;
    while (iVar2 = FUN_0003ed64(auStack_1054 + local_1068,(local_1060 + local_1064) - local_1068,
                                &local_106c,&local_1070,&local_1074,&local_1078), iVar2 != 0) {
      if (((local_1078 != (char *)0x0) && (*local_1078 == '/')) && (*local_1074 == 'r')) {
        piVar3 = (int *)FUN_0003efd4(local_106c);
        iVar4 = FUN_0003efd4(local_1070);
        bVar1 = false;
        for (local_108c = (undefined4 *)*local_14; local_108c != local_14;
            local_108c = (undefined4 *)*local_108c) {
          iVar5 = strcmp((char *)((int)local_108c + 0x3d),local_1078);
          if (iVar5 == 0) {
            local_108c[4] = iVar4 - local_108c[2];
            bVar1 = true;
          }
        }
        iVar4 = iVar4 - (int)piVar3;
        if (((!bVar1) && (4 < iVar4)) &&
           ((iVar5 = strncmp(local_1078,(char *)(DAT_0003e054 + 0x3df0c),5), iVar5 != 0 &&
            (*piVar3 == DAT_0003e058)))) {
          sVar6 = strlen(local_1078);
          puVar7 = (undefined4 *)FUN_0003cbe8(1,sVar6 + 0x40);
          puVar7[2] = piVar3;
          strcpy((char *)((int)puVar7 + 0x3d),local_1078);
          pcVar8 = (char *)(DAT_0003e05c + 0x3df70);
          puVar7[4] = iVar4;
          puVar7[3] = iVar4;
          pcVar8 = strstr((char *)((int)puVar7 + 0x3d),pcVar8);
          if (pcVar8 == (char *)0x0) {
            *puVar7 = local_14;
            puVar7[1] = local_14[1];
            *(undefined4 **)puVar7[1] = puVar7;
            local_14[1] = puVar7;
          }
        }
      }
      local_1068 = local_1068 + iVar2;
    }
    local_1060 = (local_1060 + local_1064) - local_1068;
    if (local_1060 != 0) {
      memmove(auStack_1054,auStack_1054 + local_1068,local_1060);
    }
  }
  close(local_1058);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e060 FUN_0003e060 */

void FUN_0003e060(int param_1,int param_2,int param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  char *local_34;
  int *local_30;
  int local_2c;
  int *local_28;
  int local_24;
  ushort local_1c;
  
  if (*(int *)(param_1 + 0x10) == 0) {
    bVar1 = true;
    for (local_1c = 0; local_1c != *(ushort *)(*(int *)(param_1 + 8) + 0x2c);
        local_1c = local_1c + 1) {
      if (*(int *)(param_2 + (uint)local_1c * 0x20) == 1) {
        if (bVar1) {
          *(int *)(param_1 + 0x28) =
               *(int *)(param_1 + 8) - *(int *)(param_2 + (uint)local_1c * 0x20 + 8);
          bVar1 = false;
        }
        iVar2 = param_2 + (uint)local_1c * 0x20;
        *(int *)(param_1 + 0x10) =
             (*(int *)(iVar2 + 8) + *(int *)(iVar2 + 0x14) + *(int *)(param_1 + 0x28)) -
             *(int *)(param_1 + 8);
      }
    }
  }
  iVar2 = *(int *)(param_1 + 0x28);
  *(undefined *)(param_1 + 0x3c) = 1;
  local_24 = 0;
  while( true ) {
    if (local_24 == param_3) goto LAB_0003e338;
    if (*(int *)(param_2 + local_24 * 0x20) == 2) break;
    local_24 = local_24 + 1;
  }
  *(int *)(param_1 + 0x14) = *(int *)(param_2 + local_24 * 0x20 + 8) + *(int *)(param_1 + 0x28);
  for (local_28 = *(int **)(param_1 + 0x14); *local_28 != 0; local_28 = local_28 + 2) {
    if (*local_28 == 6) {
      *(int *)(param_1 + 0x18) = local_28[1] + iVar2;
    }
    else if (*local_28 == 5) {
      *(int *)(param_1 + 0x1c) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_0003e494) {
      *(int *)(param_1 + 0x20) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_0003e498) {
      *(int *)(param_1 + 0x24) = local_28[1] + *(int *)(param_1 + 0x28);
    }
    else if (*local_28 == 4) {
      *(int *)(param_1 + 0x2c) = local_28[1] + iVar2;
    }
    else if (*local_28 == DAT_0003e49c) {
      *(int *)(param_1 + 0x30) = local_28[1] + iVar2;
    }
  }
LAB_0003e338:
  if (*(int *)(param_1 + 0x24) != 0) {
    local_2c = *(int *)(param_1 + 0x24);
    while( true ) {
      local_30 = (int *)(local_2c + *(int *)(local_2c + 0xc));
      if ((*(ushort *)(local_2c + 2) & 1) != 0) {
        *(int *)(param_1 + 0x38) = *(int *)(param_1 + 0x1c) + *local_30;
        *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(local_2c + 8);
        return;
      }
      for (; local_30[1] != 0; local_30 = (int *)((int)local_30 + local_30[1])) {
      }
      if (*(int *)(local_2c + 0x10) == 0) break;
      local_2c = local_2c + *(int *)(local_2c + 0x10);
    }
  }
  if (*(int *)(param_1 + 0x38) == 0) {
    local_34 = strrchr((char *)(param_1 + 0x3d),0x2f);
    if (local_34 == (char *)0x0) {
      local_34 = (char *)(param_1 + 0x3d);
    }
    else {
      local_34 = local_34 + 1;
    }
    *(char **)(param_1 + 0x38) = local_34;
    uVar3 = FUN_0003d6bc(*(undefined4 *)(param_1 + 0x38));
    *(undefined4 *)(param_1 + 0x34) = uVar3;
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e4a0 FUN_0003e4a0 */

void FUN_0003e4a0(int **param_1)

{
  int iVar1;
  char *__s2;
  int iVar2;
  int *piVar3;
  int **ppiVar4;
  char *local_2c;
  int **local_24;
  int **local_20;
  int *local_18;
  int **local_14;
  
  iVar1 = FUN_0003e7e4(param_1,DAT_0003e714 + 0x3e4b8);
  if (((iVar1 != 0) && (*(int *)(iVar1 + 0x14) != 0)) && (*(int *)(iVar1 + 0x1c) != 0)) {
    local_14 = (int **)0x0;
    for (local_18 = *(int **)(iVar1 + 0x14); *local_18 != 0; local_18 = local_18 + 2) {
      if ((*local_18 == 1) && (__s2 = (char *)(*(int *)(iVar1 + 0x1c) + local_18[1]), *__s2 != '\0')
         ) {
        local_24 = (int **)*param_1;
        while( true ) {
          if (local_24 != param_1) {
            local_20 = (int **)*local_24;
          }
          if (local_24 == param_1 || local_24 == (int **)0x0) break;
          local_2c = strrchr((char *)((int)local_24 + 0x3d),0x2f);
          if (local_2c == (char *)0x0) {
            local_2c = (char *)((int)local_24 + 0x3d);
          }
          else {
            local_2c = local_2c + 1;
          }
          iVar2 = strcmp(local_2c,__s2);
          if (iVar2 == 0) {
            piVar3 = *local_24;
            ppiVar4 = (int **)local_24[1];
            piVar3[1] = (int)ppiVar4;
            *ppiVar4 = piVar3;
            if (local_14 == (int **)0x0) {
              *local_24 = *param_1;
              local_24[1] = (int *)param_1;
              (*local_24)[1] = (int)local_24;
              *param_1 = (int *)local_24;
            }
            else {
              *local_24 = *local_14;
              local_24[1] = (int *)local_14;
              (*local_24)[1] = (int)local_24;
              *local_14 = (int *)local_24;
            }
            local_14 = local_24;
          }
          local_24 = local_20;
        }
      }
    }
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e718 FUN_0003e718 */

void FUN_0003e718(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  *(int *)param_1 = param_1;
  *(int *)(param_1 + 4) = param_1;
  FUN_0003d774(param_1);
  iVar1 = DAT_0003e780;
  iVar2 = DAT_0003e77c + 0x3e754;
  uVar3 = *(undefined4 *)(DAT_0003e784 + 0x3e764);
  *(undefined4 *)(DAT_0003e780 + 0x3e770) = *(undefined4 *)(DAT_0003e788 + 0x3e76c);
  *(undefined4 *)((int)&DAT_0003e77c + iVar1) = uVar3;
  *(int *)((int)&DAT_0003e788 + iVar1) = iVar2;
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e78c FUN_0003e78c */

undefined4 FUN_0003e78c(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_c;
  
  iVar1 = FUN_0003e7e4(param_1,param_2);
  if (iVar1 == 0) {
    local_c = 0;
  }
  else {
    local_c = *(undefined4 *)(iVar1 + 8);
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e7e4 FUN_0003e7e4 */

undefined4 * FUN_0003e7e4(undefined4 *param_1,uint param_2)

{
  undefined4 *local_14;
  
  local_14 = (undefined4 *)*param_1;
  while( true ) {
    if (local_14 == param_1) {
      return (undefined4 *)0x0;
    }
    if (((uint)local_14[2] <= param_2) && (param_2 < (uint)(local_14[2] + local_14[4]))) break;
    local_14 = (undefined4 *)*local_14;
  }
  return local_14;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e884 FUN_0003e884 */

void FUN_0003e884(int **param_1)

{
  int *piVar1;
  int **ppiVar2;
  int **local_18;
  int **local_14;
  
  local_14 = (int **)*param_1;
  while( true ) {
    if (local_14 != param_1) {
      local_18 = (int **)*local_14;
    }
    if (local_14 == param_1 || local_14 == (int **)0x0) break;
    piVar1 = *local_14;
    ppiVar2 = (int **)local_14[1];
    piVar1[1] = (int)ppiVar2;
    *ppiVar2 = piVar1;
    FUN_0003bf1c(local_14);
    local_14 = local_18;
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003e944 FUN_0003e944 */

int FUN_0003e944(undefined4 *param_1,char **param_2)

{
  uint uVar1;
  int local_30;
  int local_2c;
  int local_28;
  undefined4 local_24;
  undefined4 *local_20;
  undefined4 *local_1c;
  undefined4 *local_18;
  char **local_14;
  undefined4 *local_10;
  int local_c;
  
  if (**param_2 == '\0') {
    local_c = 0;
  }
  else {
    local_20 = (undefined4 *)0x0;
    local_24 = 0;
    local_18 = param_1;
    local_14 = param_2;
    local_10 = param_1;
    memset(&local_30,0,0xc);
    for (local_1c = (undefined4 *)*local_18; local_1c != local_18;
        local_1c = (undefined4 *)*local_1c) {
      if (((local_1c != local_20) &&
          (uVar1 = FUN_0003eaf0(local_1c,local_10 + 2,local_14,&local_30), (uVar1 & 1) != 0)) &&
         (local_30 != 0)) {
        return local_30;
      }
    }
    if (local_2c == 0) {
      if (local_28 == 0) {
        local_c = dlsym(0xffffffff,*local_14);
        if (local_c == 0) {
          local_c = 0;
        }
      }
      else {
        local_c = local_28;
      }
    }
    else {
      local_c = local_2c;
    }
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003eaf0 FUN_0003eaf0 */

byte FUN_0003eaf0(int param_1,undefined4 param_2,undefined4 param_3,code **param_4)

{
  int iVar1;
  code *local_34;
  code *local_2c;
  int local_24;
  byte local_1d;
  code **local_1c;
  undefined4 local_18;
  undefined4 local_14;
  int local_10;
  byte local_9;
  
  local_1d = 0;
  local_24 = 0;
  local_1c = param_4;
  local_18 = param_3;
  local_14 = param_2;
  local_10 = param_1;
  iVar1 = FUN_0003f0ec(param_1,param_3,&local_24);
  if (iVar1 < 0) {
    *local_1c = *(code **)(DAT_0003ed60 + iVar1 * -0xc + 0x3eb50);
    local_9 = 1;
  }
  else {
    if (iVar1 != 0) {
      local_2c = (code *)(*(int *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 4) +
                         *(int *)(local_10 + 0x28));
      if ((*(byte *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 0xc) & 0xf) == 10) {
        local_2c = (code *)(*local_2c)(local_2c);
      }
      if ((int)(uint)*(byte *)(*(int *)(local_10 + 0x18) + iVar1 * 0x10 + 0xc) >> 4 != 2) {
        if (*local_1c == (code *)0x0) {
          *local_1c = local_2c;
        }
        return 1;
      }
      if (local_1c[2] == (code *)0x0) {
        local_1c[2] = local_2c;
      }
      local_1d = 1;
    }
    if (local_24 != 0) {
      local_34 = (code *)(*(int *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 4) +
                         *(int *)(local_10 + 0x28));
      if ((*(byte *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 0xc) & 0xf) == 10) {
        local_34 = (code *)(*local_34)(local_34);
      }
      if ((int)(uint)*(byte *)(*(int *)(local_10 + 0x18) + local_24 * 0x10 + 0xc) >> 4 == 2) {
        if (local_1c[2] == (code *)0x0) {
          local_1c[2] = local_34;
        }
      }
      else if (local_1c[1] == (code *)0x0) {
        local_1c[1] = local_34;
      }
      local_1d = 1;
    }
    local_9 = local_1d & 1;
  }
  return local_9;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003ed64 FUN_0003ed64 */

undefined *
FUN_0003ed64(undefined *param_1,int param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  undefined *local_2c;
  undefined *local_28;
  int local_24;
  
  *param_3 = 0;
  *param_4 = 0;
  *param_6 = 0;
  *param_5 = 0;
  local_24 = 0;
  local_28 = (undefined *)0x0;
  local_2c = param_1;
  do {
    if (param_1 + param_2 <= local_2c) {
      return (undefined *)0x0;
    }
    switch(*local_2c) {
    case 9:
    case 0x20:
      local_28 = (undefined *)0x0;
      break;
    case 10:
    case 0xd:
      *local_2c = 0;
      return local_2c + (1 - (int)param_1);
    default:
switchD_0003edfc_caseD_b:
      if (local_28 == (undefined *)0x0) {
        local_28 = local_2c;
        switch(local_24) {
        case 0:
          *param_3 = local_2c;
          break;
        case 1:
          *param_4 = local_2c;
          break;
        case 2:
          if (param_1 + param_2 < local_2c + 4) {
            return (undefined *)0x0;
          }
          *param_5 = local_2c;
          break;
        case 6:
          *param_6 = local_2c;
        }
        local_24 = local_24 + 1;
      }
      break;
    case 0x2d:
      if (local_24 != 1) goto switchD_0003edfc_caseD_b;
      local_28 = (undefined *)0x0;
    }
    local_2c = local_2c + 1;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003efd4 FUN_0003efd4 */

undefined8 FUN_0003efd4(byte *param_1)

{
  byte local_11;
  uint local_10;
  uint local_c;
  byte *local_8;
  
  local_c = 0;
  local_10 = 0;
  for (local_8 = param_1; *local_8 != 0; local_8 = local_8 + 1) {
    local_11 = *local_8;
    if ((local_11 < 0x61) || (0x66 < local_11)) {
      if ((local_11 < 0x41) || (0x46 < local_11)) {
        if ((local_11 < 0x30) || (0x39 < local_11)) break;
        local_11 = local_11 - 0x30;
      }
      else {
        local_11 = local_11 - 0x37;
      }
    }
    else {
      local_11 = local_11 + 0xa9;
    }
    local_c = local_c << 4 | local_10 >> 0x1c;
    local_10 = local_10 << 4 | (uint)local_11;
  }
  return CONCAT44(local_c,local_10);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003f0ec FUN_0003f0ec */

undefined4 FUN_0003f0ec(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_18;
  
  local_18 = 0;
  if (*(int *)(param_1 + 0x30) == 0) {
    if (*(int *)(param_1 + 0x2c) != 0) {
      local_18 = FUN_0003f430(param_1,param_2,param_3);
    }
  }
  else {
    local_18 = FUN_0003f16c(param_1,param_2,param_3);
  }
  return local_18;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003f16c FUN_0003f16c */

uint FUN_0003f16c(int param_1,char **param_2,uint *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char *pcVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int extraout_r1;
  uint uVar9;
  uint uVar10;
  int extraout_r1_00;
  uint local_3c;
  
  iVar1 = *(int *)(param_1 + 0x18);
  iVar2 = *(int *)(param_1 + 0x1c);
  piVar3 = *(int **)(param_1 + 0x30);
  pcVar4 = *param_2;
  *param_3 = 0;
  uVar5 = FUN_0003f638(pcVar4);
  iVar7 = piVar3[2];
  iVar8 = *piVar3;
  FUN_0003a724(uVar5,*piVar3);
  local_3c = piVar3[iVar7 + extraout_r1 + 4];
  uVar9 = piVar3[1];
  if ((uVar9 <= local_3c) &&
     (uVar10 = piVar3[3], FUN_0003a724(uVar5 >> 5,piVar3[2],extraout_r1),
     uVar10 = 1 << (uVar5 & 0x1f) | 1 << (uVar5 >> (uVar10 & 0xff) & 0x1f),
     (piVar3[extraout_r1_00 + 4] & uVar10) == uVar10)) {
    while( true ) {
      if ((((uVar5 & 0xfffffffe) == (piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] & 0xfffffffeU))
          && (*(short *)(iVar1 + local_3c * 0x10 + 0xe) != 0)) &&
         (iVar6 = strcmp((char *)(iVar2 + *(int *)(iVar1 + local_3c * 0x10)),*param_2), iVar6 == 0))
      {
        if (param_2[1] == (char *)0x0) {
          return local_3c;
        }
        uVar10 = FUN_0003f6a4(param_1,param_2,local_3c);
        if ((uVar10 & 1) != 0) {
          return local_3c;
        }
        *param_3 = local_3c;
      }
      if (((piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] & 1U) != 0) &&
         (piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 4] !=
          piVar3[iVar7 + iVar8 + (local_3c - uVar9) + 5])) break;
      local_3c = local_3c + 1;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003f430 FUN_0003f430 */

int FUN_0003f430(int param_1,char **param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char *__s2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int extraout_r1;
  int local_34;
  int local_2c;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  iVar2 = *(int *)(param_1 + 0x18);
  __s2 = *param_2;
  iVar3 = FUN_0003d6bc(__s2);
  FUN_0003a724(iVar3,*piVar1);
  *param_3 = 0;
  for (local_34 = 0; local_34 != 4; local_34 = local_34 + 1) {
    if ((iVar3 == *(int *)(DAT_0003f630 + local_34 * 0xc + 0x3f4c0)) &&
       (iVar4 = strcmp(__s2,*(char **)(DAT_0003f634 + 0x3f4e4 + local_34 * 0xc)), iVar4 == 0)) {
      return -local_34;
    }
  }
  local_2c = piVar1[extraout_r1 + 2];
  do {
    if (local_2c == 0) {
      return 0;
    }
    if ((*(short *)(iVar2 + local_2c * 0x10 + 0xe) != 0) &&
       (iVar3 = strcmp((char *)(*(int *)(param_1 + 0x1c) + *(int *)(iVar2 + local_2c * 0x10)),__s2),
       iVar3 == 0)) {
      if (param_2[1] == (char *)0x0) {
        return local_2c;
      }
      uVar5 = FUN_0003f6a4(param_1,param_2,local_2c);
      if ((uVar5 & 1) != 0) {
        return local_2c;
      }
      *param_3 = local_2c;
    }
    local_2c = piVar1[*piVar1 + local_2c + 2];
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003f638 FUN_0003f638 */

int FUN_0003f638(byte *param_1)

{
  int local_c;
  byte local_5;
  byte *local_4;
  
  local_c = 0x1505;
  local_5 = *param_1;
  local_4 = param_1;
  while (local_5 != 0) {
    local_c = local_c * 0x21 + (uint)local_5;
    local_5 = local_4[1];
    local_4 = local_4 + 1;
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0003f6a4 FUN_0003f6a4 */

undefined FUN_0003f6a4(int param_1,int param_2,int param_3)

{
  int iVar1;
  int local_20;
  
  if ((*(int *)(param_1 + 0x20) != 0) && (*(int *)(param_1 + 0x24) != 0)) {
    local_20 = *(int *)(param_1 + 0x24);
    while( true ) {
      if (((*(ushort *)(local_20 + 2) & 1) == 0) &&
         ((*(ushort *)(*(int *)(param_1 + 0x20) + param_3 * 2) & 0x7fff) ==
          *(ushort *)(local_20 + 4))) {
        if ((*(int *)(param_2 + 8) == *(int *)(local_20 + 8)) &&
           (iVar1 = strcmp(*(char **)(param_2 + 4),
                           (char *)(*(int *)(param_1 + 0x1c) +
                                   *(int *)(local_20 + *(int *)(local_20 + 0xc)))), iVar1 == 0)) {
          return 1;
        }
        return 0;
      }
      if (*(int *)(local_20 + 0x10) == 0) break;
      local_20 = local_20 + *(int *)(local_20 + 0x10);
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000402c0 shadowhook_get_version */

void shadowhook_get_version(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x000402e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_000402ec + 0x402e4))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00040940 shadowhook_hook_func_addr */

void shadowhook_hook_func_addr(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00040968. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_0004096c + 0x40964))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00040f40 shadowhook_dump_records */

void shadowhook_dump_records(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00040f68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00040f6c + 0x40f64))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00042d40 shadowhook_get_mode */

void shadowhook_get_mode(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00042d68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00042d6c + 0x42d64))(param_1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00042e24 shadowhook_set_debuggable */

void shadowhook_set_debuggable(undefined4 param_1)

{
  thunk_FUN_00028dc4();
                    /* WARNING: Could not recover jumptable at 0x00042e4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(DAT_00042e50 + 0x42e48))(param_1);
  return;
}

