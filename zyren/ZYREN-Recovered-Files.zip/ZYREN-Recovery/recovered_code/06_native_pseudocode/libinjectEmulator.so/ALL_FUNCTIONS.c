/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00011140 FUN_00011140 */

void FUN_00011140(void)

{
  byte in_CF;
  byte in_PF;
  byte in_AF;
  byte in_ZF;
  byte in_SF;
  byte in_TF;
  byte in_IF;
  byte in_OF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  uint uVar1;
  
  uVar1 = (uint)(in_NT & 1) * 0x4000 | (uint)(in_OF & 1) * 0x800 | (uint)(in_IF & 1) * 0x200 |
          (uint)(in_TF & 1) * 0x100 | (uint)(in_SF & 1) * 0x80 | (uint)(in_ZF & 1) * 0x40 |
          (uint)(in_AF & 1) * 0x10 | (uint)(in_PF & 1) * 4 | (uint)(in_CF & 1) |
          (uint)(in_ID & 1) * 0x200000 | (uint)(in_VIP & 1) * 0x100000 |
          (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  FUN_00011186();
  LOCK();
  UNLOCK();
  FUN_0001118b(uVar1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00011186 FUN_00011186 */

void FUN_00011186(void)

{
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001118b FUN_0001118b */

undefined4 __regparm3 FUN_0001118b(undefined4 param_1)

{
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
                    /* WARNING: Treating indirect jump as return */
  return param_1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013040 FUN_00013040 */

void __regparm3 FUN_00013040(undefined4 param_1,undefined4 param_2)

{
  byte in_CF;
  byte in_PF;
  byte in_AF;
  byte in_ZF;
  byte in_SF;
  byte in_TF;
  byte in_IF;
  byte in_OF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  uint uVar1;
  
  uVar1 = (uint)(in_NT & 1) * 0x4000 | (uint)(in_OF & 1) * 0x800 | (uint)(in_IF & 1) * 0x200 |
          (uint)(in_TF & 1) * 0x100 | (uint)(in_SF & 1) * 0x80 | (uint)(in_ZF & 1) * 0x40 |
          (uint)(in_AF & 1) * 0x10 | (uint)(in_PF & 1) * 4 | (uint)(in_CF & 1) |
          (uint)(in_ID & 1) * 0x200000 | (uint)(in_VIP & 1) * 0x100000 |
          (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  FUN_00013087();
  LOCK();
  UNLOCK();
  FUN_0001308c(uVar1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013087 FUN_00013087 */

void FUN_00013087(void)

{
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0001308c FUN_0001308c */

undefined8 __regparm3 FUN_0001308c(undefined4 param_1)

{
  undefined4 unaff_retaddr;
  
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
                    /* WARNING: Treating indirect jump as return */
  return CONCAT44(unaff_retaddr,param_1);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c00 FUN_00013c00 */

void FUN_00013c00(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c00. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0xc))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c06 FUN_00013c06 */

void FUN_00013c06(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c06. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x10))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c0c FUN_00013c0c */

void FUN_00013c0c(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c0c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x14))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c12 FUN_00013c12 */

void FUN_00013c12(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c12. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x18))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c18 FUN_00013c18 */

void FUN_00013c18(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c18. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x1c))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c1e FUN_00013c1e */

void FUN_00013c1e(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c1e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x20))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c24 FUN_00013c24 */

void FUN_00013c24(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x24))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c2a FUN_00013c2a */

void FUN_00013c2a(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c2a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x28))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c30 FUN_00013c30 */

void FUN_00013c30(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c30. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x2c))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c36 FUN_00013c36 */

void FUN_00013c36(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c36. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x30))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c3c FUN_00013c3c */

void FUN_00013c3c(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c3c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x34))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c42 FUN_00013c42 */

void FUN_00013c42(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c42. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x38))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c48 FUN_00013c48 */

void FUN_00013c48(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c48. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x3c))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c4e FUN_00013c4e */

void FUN_00013c4e(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c4e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x40))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c54 FUN_00013c54 */

void FUN_00013c54(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c54. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x44))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c5a FUN_00013c5a */

void FUN_00013c5a(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c5a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x48))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c60 FUN_00013c60 */

void FUN_00013c60(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c60. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x4c))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c66 FUN_00013c66 */

void FUN_00013c66(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c66. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x50))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c6c FUN_00013c6c */

void FUN_00013c6c(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c6c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x54))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c72 FUN_00013c72 */

void FUN_00013c72(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c72. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x58))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c78 FUN_00013c78 */

void FUN_00013c78(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c78. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x5c))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00013c7e FUN_00013c7e */

void FUN_00013c7e(void)

{
  int unaff_EBX;
  
                    /* WARNING: Could not recover jumptable at 0x00013c7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(unaff_EBX + 0x68))();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00014540 thunk_FUN_0004db40 */

void __regparm3 thunk_FUN_0004db40(undefined4 param_1,undefined4 param_2)

{
  byte in_CF;
  byte in_PF;
  byte in_AF;
  byte in_ZF;
  byte in_SF;
  byte in_TF;
  byte in_IF;
  byte in_OF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  uint uVar1;
  
  uVar1 = (uint)(in_NT & 1) * 0x4000 | (uint)(in_OF & 1) * 0x800 | (uint)(in_IF & 1) * 0x200 |
          (uint)(in_TF & 1) * 0x100 | (uint)(in_SF & 1) * 0x80 | (uint)(in_ZF & 1) * 0x40 |
          (uint)(in_AF & 1) * 0x10 | (uint)(in_PF & 1) * 4 | (uint)(in_CF & 1) |
          (uint)(in_ID & 1) * 0x200000 | (uint)(in_VIP & 1) * 0x100000 |
          (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  FUN_0004db78();
  LOCK();
  UNLOCK();
  FUN_0004db7d(uVar1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00014e00 _DT_INIT */

void _DT_INIT(void)

{
  byte in_CF;
  byte in_PF;
  byte in_AF;
  byte in_ZF;
  byte in_SF;
  byte in_TF;
  byte in_IF;
  byte in_OF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  uint uVar1;
  
  uVar1 = (uint)(in_NT & 1) * 0x4000 | (uint)(in_OF & 1) * 0x800 | (uint)(in_IF & 1) * 0x200 |
          (uint)(in_TF & 1) * 0x100 | (uint)(in_SF & 1) * 0x80 | (uint)(in_ZF & 1) * 0x40 |
          (uint)(in_AF & 1) * 0x10 | (uint)(in_PF & 1) * 4 | (uint)(in_CF & 1) |
          (uint)(in_ID & 1) * 0x200000 | (uint)(in_VIP & 1) * 0x100000 |
          (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  FUN_00011186();
  LOCK();
  UNLOCK();
  FUN_0001118b(uVar1);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000343e0 _INIT_1 */

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Instruction at (ram,0x00034444) overlaps instruction at (ram,0x0003443f)
    */
/* WARNING: Removing unreachable block (ram,0x000344a8) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint __regparm3 _INIT_1(uint param_1,ushort param_2,undefined4 param_3,int param_4)

{
  byte *pbVar1;
  undefined uVar2;
  uint *puVar3;
  byte bVar4;
  code *pcVar5;
  uint uVar6;
  undefined *puVar7;
  undefined4 uVar8;
  short sVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  int extraout_ECX;
  undefined2 uVar13;
  undefined4 uVar14;
  byte bVar17;
  uint unaff_EBP;
  undefined4 *unaff_ESI;
  undefined4 unaff_EDI;
  uint *puVar18;
  uint *puVar19;
  undefined2 in_ES;
  bool bVar20;
  char in_AF;
  byte bVar21;
  longdouble in_ST0;
  longdouble extraout_ST0;
  undefined8 uVar22;
  byte *unaff_retaddr;
  uint *puStack_18;
  undefined *puStack_14;
  char cVar15;
  byte bVar16;
  
  bVar21 = 0;
  puVar19 = (uint *)segment(in_ES,(short)unaff_EDI);
  uVar14 = *unaff_ESI;
  puVar18 = (uint *)(CONCAT22((short)((uint)unaff_EDI >> 0x10),(short)unaff_EDI + 4) + param_1);
  out(*(undefined4 *)((int)unaff_ESI + 3),
      param_2 + (ushort)(_DAT_90966406 < 0xe4ba2e82 ||
                        _DAT_90966406 + 0x1b45d17e < (uint)(param_1 < *puVar19)) *
                (((ushort)unaff_ESI & 3) - (param_2 & 3)));
  uVar10 = CONCAT31((int3)((uint)param_3 >> 8),0xf2);
  puVar3 = puVar18 + 1;
  _DAT_ad0ac087 = (_DAT_ad0ac087 + -0x37fd87aa) - (uint)(*(uint *)((int)unaff_ESI + 7) < *puVar18);
  puVar19 = (uint *)(uVar10 + 0x90a2efaa);
  uVar6 = *puVar19;
  *puVar19 = *puVar19 + uVar10;
  iVar11 = CONCAT22((short)((uint)param_3 >> 0x10),
                    CONCAT11((char)((uint)param_3 >> 8) + (char)((uint)uVar14 >> 8),0xf2));
  puVar7 = (undefined *)
           ((CONCAT31((int3)((uint)uVar14 >> 8),((char)uVar14 + -0x21) - CARRY4(uVar6,uVar10)) ^
            0xfe78af93) - 1);
  bVar20 = false;
  bVar17 = *unaff_retaddr | 0x56;
  iVar12 = iVar11 + -1;
  if (iVar12 != 0 && bVar17 == 0) {
    pcVar5 = (code *)swi(1);
    uVar6 = (*pcVar5)();
    return uVar6;
  }
  if ((char)bVar17 < '\0') {
    uVar14 = CONCAT31((int3)((uint)unaff_retaddr >> 8),*(undefined *)(iVar11 + -0x17848c2f));
    puVar19 = puVar3;
    if (bVar17 != 0) {
      *(char *)(param_4 + 0x7b) = *(char *)(param_4 + 0x7b) << ((byte)puVar7 & 0x1f);
      puStack_18 = puVar3;
      puStack_14 = (undefined *)((int)unaff_ESI + 0xb);
      uVar22 = func_0x8f8c3ddd();
      uVar14 = (undefined4)((ulonglong)uVar22 >> 0x20);
      puVar19 = puVar18 + (uint)bVar21 * -2 + 2;
      *puVar3 = (uint)uVar22;
      in((short)((ulonglong)uVar22 >> 0x20));
      bVar20 = (byte)((uint)extraout_ECX >> 8) < (byte)param_4;
      iVar12 = extraout_ECX;
      in_ST0 = extraout_ST0;
    }
    *(char *)((int)puVar19 + -0x22c71355) = (char)iVar12;
    pbVar1 = (byte *)((int)unaff_ESI + -0x21);
    bVar17 = *pbVar1;
    bVar16 = (byte)((uint)uVar14 >> 8);
    bVar4 = bVar16 - *pbVar1;
    cVar15 = bVar4 - bVar20;
    uVar13 = CONCAT11(cVar15,(char)uVar14);
    do {
      uVar8 = in(uVar13);
      iVar12 = iVar12 + -1;
      if (iVar12 != 0 && cVar15 != '\0') {
        return CONCAT31((int3)((uint)uVar8 >> 8),DAT_7c24eaff);
      }
    } while ((SBORROW1(bVar16,*pbVar1) != SBORROW1(bVar4,bVar20)) == cVar15 < '\0');
    sVar9 = (short)((uint)uVar8 >> 0x10);
    XRELEASE();
    *(uint *)(unaff_EBP + 0x8ec791d3) = CONCAT22((short)((uint)uVar14 >> 0x10),uVar13);
    *(int *)(unaff_EBP - 2) = (int)ROUND(in_ST0);
    out(*(undefined *)((int)unaff_ESI + 0xb),uVar13);
    puVar7 = (undefined *)
             CONCAT31(CONCAT21(sVar9,(cVar15 < '\0') << 7 | (cVar15 == '\0') << 6 | in_AF << 4 |
                                     ((POPCOUNT(cVar15) & 1U) == 0) << 2 | 2U |
                                     (bVar16 < bVar17 || bVar4 < bVar20)),0xea);
    if (!CARRY4(unaff_EBP,*puVar19) && unaff_EBP + *puVar19 != 0) {
      iVar11 = *(int *)(unaff_EBP + *puVar19 + 0x184566b4);
      out(0x23,puVar7);
      *puVar19 = (uint)puVar7;
      uVar2 = in(sVar9 >> 0xf);
      *(undefined *)(puVar19 + (uint)bVar21 * -2 + 1) = uVar2;
      puVar7 = (undefined *)((int)&puStack_18 - iVar11 & 0x6c939c61);
      puVar7[param_4 * 2 + -0x3021615e] = puVar7[param_4 * 2 + -0x3021615e] + (char)puVar7;
      goto code_r0x0003444b;
    }
  }
  LOCK();
  *puVar7 = (char)((uint)param_4 >> 8);
  UNLOCK();
  iVar12 = CONCAT31((int3)((uint)iVar12 >> 8),(byte)iVar12 & (byte)param_4);
  _DAT_10878e2e = _DAT_10878e2e | 0x9ea25884;
code_r0x0003444b:
  bVar17 = (byte)iVar12 & 0x1f;
  uVar6 = *(uint *)(iVar12 + 0x24);
  *(uint *)(iVar12 + 0x24) = uVar6 << bVar17 | uVar6 >> 0x21 - bVar17;
  return (uint)puVar7 & 0xffffff17;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0004db40 FUN_0004db40 */

void __regparm3 FUN_0004db40(undefined4 param_1,undefined4 param_2)

{
  byte in_CF;
  byte in_PF;
  byte in_AF;
  byte in_ZF;
  byte in_SF;
  byte in_TF;
  byte in_IF;
  byte in_OF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  uint uVar1;
  
  uVar1 = (uint)(in_NT & 1) * 0x4000 | (uint)(in_OF & 1) * 0x800 | (uint)(in_IF & 1) * 0x200 |
          (uint)(in_TF & 1) * 0x100 | (uint)(in_SF & 1) * 0x80 | (uint)(in_ZF & 1) * 0x40 |
          (uint)(in_AF & 1) * 0x10 | (uint)(in_PF & 1) * 4 | (uint)(in_CF & 1) |
          (uint)(in_ID & 1) * 0x200000 | (uint)(in_VIP & 1) * 0x100000 |
          (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  FUN_0004db78();
  LOCK();
  UNLOCK();
  FUN_0004db7d(uVar1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0004db78 FUN_0004db78 */

void FUN_0004db78(void)

{
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0004db7d FUN_0004db7d */

undefined8 __regparm3 FUN_0004db7d(undefined4 param_1)

{
  undefined4 unaff_retaddr;
  
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
                    /* WARNING: Treating indirect jump as return */
  return CONCAT44(unaff_retaddr,param_1);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0004fa00 FUN_0004fa00 */

uint FUN_0004fa00(uint *param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  longlong lVar2;
  byte bVar3;
  uint uVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  uint local_1c;
  uint local_18;
  
  if (param_3 < 5) {
    return 5;
  }
  if (*param_2 != 0xfd2fb528) {
    if ((*param_2 & 0xfffffff0) != 0x184d2a50) {
      return 0xfffffff6;
    }
    if (7 < param_3) {
      FUN_00013c0c(param_1,0,0x20);
      *param_1 = param_2[1];
      param_1[1] = 0;
      param_1[4] = 1;
      param_1[3] = 0;
      param_1[2] = 0;
      return 0;
    }
    return 8;
  }
  bVar1 = *(byte *)(param_2 + 1);
  uVar4 = (bVar1 & 0x20) >> 5;
  uVar4 = ((*(int *)(&DAT_0004e4b0 + (uint)(bVar1 >> 6) * 4) +
           *(int *)(&DAT_0004e4a0 + (bVar1 & 3) * 4)) - uVar4) + 6 +
          (uint)(bVar1 >> 6 == 0 & (byte)uVar4);
  if (param_3 < uVar4) {
    return uVar4;
  }
  param_1[5] = uVar4;
  bVar1 = *(byte *)(param_2 + 1);
  if ((bVar1 & 8) != 0) {
    return 0xfffffff2;
  }
  if ((bVar1 & 0x20) == 0) {
    bVar5 = (*(byte *)((int)param_2 + 5) >> 3) + 10;
    if (0x1b < bVar5) {
      return 0xfffffff0;
    }
    uVar9 = 1 << (bVar5 & 0x1f);
    uVar8 = uVar9;
    uVar4 = 0 << (bVar5 & 0x1f) | 1U >> 0x20 - (bVar5 & 0x1f);
    if ((bVar5 & 0x20) != 0) {
      uVar8 = 0;
      uVar4 = uVar9;
    }
    uVar7 = *(byte *)((int)param_2 + 5) & 7;
    lVar2 = (ulonglong)(uVar4 << 0x1d | uVar8 >> 3) * (ulonglong)uVar7;
    uVar9 = (uint)lVar2;
    local_18 = uVar9 + uVar8;
    local_1c = (int)((ulonglong)lVar2 >> 0x20) + (uVar4 >> 3) * uVar7 + uVar4 +
               (uint)CARRY4(uVar9,uVar8);
    iVar6 = 6;
  }
  else {
    iVar6 = 5;
    local_18 = 0;
    local_1c = 0;
  }
  bVar3 = bVar1 & 3;
  bVar5 = bVar1 >> 6;
  if (bVar3 == 3) {
    uVar4 = *(uint *)((int)param_2 + iVar6);
    iVar6 = iVar6 + 4;
  }
  else if (bVar3 == 2) {
    uVar4 = (uint)*(ushort *)((int)param_2 + iVar6);
    iVar6 = iVar6 + 2;
  }
  else if (bVar3 == 1) {
    uVar4 = (uint)*(byte *)((int)param_2 + iVar6);
    iVar6 = iVar6 + 1;
  }
  else {
    uVar4 = 0;
  }
  if (bVar5 == 1) {
    uVar8 = *(ushort *)((int)param_2 + iVar6) + 0x100;
  }
  else if (bVar5 == 2) {
    uVar8 = *(uint *)((int)param_2 + iVar6);
  }
  else {
    if (bVar5 == 3) {
      uVar8 = *(uint *)((int)param_2 + iVar6);
      uVar9 = *(uint *)((int)param_2 + iVar6 + 4);
      goto LAB_0004fbd7;
    }
    uVar8 = 0xffffffff;
    uVar9 = 0xffffffff;
    if ((bVar1 & 0x20) == 0) goto LAB_0004fbd7;
    uVar8 = (uint)*(byte *)((int)param_2 + iVar6);
  }
  uVar9 = 0;
LAB_0004fbd7:
  bVar10 = (bVar1 & 0x20) != 0;
  if (bVar10) {
    local_18 = uVar8;
  }
  param_1[4] = 0;
  *param_1 = uVar8;
  if (bVar10) {
    local_1c = uVar9;
  }
  param_1[1] = uVar9;
  param_1[3] = local_1c;
  param_1[2] = local_18;
  param_1[6] = uVar4;
  param_1[7] = bVar1 >> 2 & 1;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00050010 FUN_00050010 */

uint FUN_00050010(int param_1,uint *param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  bool bVar7;
  uint local_24;
  
  uVar5 = 0xffffffec;
  if (param_3 < 3) {
    return 0xffffffec;
  }
  bVar1 = *(byte *)param_2;
  bVar3 = bVar1 & 3;
  switch(bVar3) {
  case 0:
    bVar3 = bVar1 >> 2 & 3;
    if (bVar3 == 1) {
      uVar5 = (uint)(*(ushort *)param_2 >> 4);
      iVar6 = 2;
    }
    else if (bVar3 == 3) {
      uVar5 = (uint)(*(uint3 *)param_2 >> 4);
      iVar6 = 3;
    }
    else {
      uVar5 = (uint)(bVar1 >> 3);
      iVar6 = 1;
    }
    uVar4 = iVar6 + uVar5;
    if (param_3 < iVar6 + 8 + uVar5) {
      if (param_3 < uVar4) {
        return 0xffffffec;
      }
      FUN_00013c06(param_1 + 0x5d2c,(byte *)((int)param_2 + iVar6),uVar5);
      *(int *)(param_1 + 0x5ccc) = param_1 + 0x5d2c;
      *(uint *)(param_1 + 0x5cdc) = uVar5;
      FUN_00013c0c(param_1 + 0x5d2c + uVar5,0,8);
      return uVar4;
    }
    *(byte **)(param_1 + 0x5ccc) = (byte *)((int)param_2 + iVar6);
    *(uint *)(param_1 + 0x5cdc) = uVar5;
    return uVar4;
  case 3:
    if (*(int *)(param_1 + 0x5c68) == 0) {
      return 0xffffffe2;
    }
  case 2:
    if (4 < param_3) {
      bVar1 = bVar1 >> 2 & 3;
      uVar4 = *param_2;
      if (bVar1 == 2) {
        local_24 = uVar4 >> 4 & 0x3fff;
        uVar4 = uVar4 >> 0x12;
        bVar7 = false;
        iVar6 = 4;
      }
      else if (bVar1 == 3) {
        local_24 = uVar4 >> 4 & 0x3ffff;
        if (0x20000 < local_24) {
          return 0xffffffec;
        }
        uVar4 = uVar4 >> 0x16 | (uint)*(byte *)(param_2 + 1) << 10;
        bVar7 = false;
        iVar6 = 5;
      }
      else {
        bVar7 = bVar1 == 0;
        local_24 = uVar4 >> 4 & 0x3ff;
        uVar4 = uVar4 >> 0xe & 0x3ff;
        iVar6 = 3;
      }
      if (uVar4 + iVar6 <= param_3) {
        if (bVar3 == 3) {
          if (bVar7) {
            uVar2 = FUN_00059cb0(param_1 + 0x5d2c,local_24,(byte *)((int)param_2 + iVar6),uVar4,
                                 *(undefined4 *)(param_1 + 0xc));
          }
          else {
            uVar2 = FUN_00059d20(param_1 + 0x5d2c,local_24,(byte *)((int)param_2 + iVar6),uVar4,
                                 *(undefined4 *)(param_1 + 0xc));
          }
        }
        else if (bVar7) {
          uVar2 = FUN_00055ad0(param_1 + 0x141c,param_1 + 0x5d2c,local_24,
                               (byte *)((int)param_2 + iVar6),uVar4,param_1 + 0x5420,0x800);
        }
        else {
          uVar2 = FUN_0005a080(param_1 + 0x141c,param_1 + 0x5d2c,local_24,
                               (byte *)((int)param_2 + iVar6),uVar4,param_1 + 0x5420,0x800);
        }
        if (uVar2 < 0xffffff89) {
          *(int *)(param_1 + 0x5ccc) = param_1 + 0x5d2c;
          *(uint *)(param_1 + 0x5cdc) = local_24;
          *(undefined4 *)(param_1 + 0x5c68) = 1;
          if (bVar3 == 2) {
            *(int *)(param_1 + 0xc) = param_1 + 0x141c;
          }
          FUN_00013c0c(param_1 + 0x5d2c + local_24,0,8);
          uVar5 = uVar4 + iVar6;
        }
      }
    }
    return uVar5;
  }
  bVar3 = bVar1 >> 2 & 3;
  if (bVar3 == 1) {
    uVar5 = (uint)(*(ushort *)param_2 >> 4);
    iVar6 = 2;
  }
  else if (bVar3 == 3) {
    if (param_3 < 4) {
      return 0xffffffec;
    }
    if (0x20000f < *(uint3 *)param_2) {
      return 0xffffffec;
    }
    uVar5 = (uint)(*(uint3 *)param_2 >> 4);
    iVar6 = 3;
  }
  else {
    uVar5 = (uint)(bVar1 >> 3);
    iVar6 = 1;
  }
  FUN_00013c0c(param_1 + 0x5d2c,*(byte *)((int)param_2 + iVar6),uVar5 + 8);
  *(int *)(param_1 + 0x5ccc) = param_1 + 0x5d2c;
  *(uint *)(param_1 + 0x5cdc) = uVar5;
  return iVar6 + 1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000503c0 FUN_000503c0 */

byte * FUN_000503c0(undefined4 *param_1,uint *param_2,byte *param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  undefined4 local_8c;
  undefined4 *local_88;
  uint local_84;
  uint local_80;
  undefined local_7a [106];
  
  if (param_4 == 0) {
    return (byte *)0xffffffb8;
  }
  bVar1 = *param_3;
  uVar3 = (uint)bVar1;
  if (uVar3 == 0) {
    *param_2 = 0;
    return (byte *)0x1;
  }
  if ((char)bVar1 < '\0') {
    if (bVar1 == 0xff) {
      if (param_4 < 3) {
        return (byte *)0xffffffb8;
      }
      pbVar6 = param_3 + 3;
      uVar3 = *(ushort *)(param_3 + 1) + 0x7f00;
    }
    else {
      if (param_4 < 2) {
        return (byte *)0xffffffb8;
      }
      pbVar6 = param_3 + 2;
      uVar3 = uVar3 * 0x100 + -0x8000 + (uint)param_3[1];
    }
  }
  else {
    pbVar6 = param_3 + 1;
  }
  pbVar4 = param_3 + param_4;
  *param_2 = uVar3;
  if (pbVar4 < pbVar6 + 4) {
    return (byte *)0xffffffb8;
  }
  local_88 = (undefined4 *)(uint)*pbVar6;
  bVar1 = *pbVar6 >> 6;
  pbVar6 = pbVar6 + 1;
  local_8c = 0x23;
  if (bVar1 == 0) {
    *param_1 = &DAT_00063190;
    uVar3 = 0;
  }
  else if (bVar1 == 3) {
    uVar3 = 0;
    if (param_1[0x171b] == 0) {
      return (byte *)0xffffffec;
    }
  }
  else {
    puVar5 = param_1 + 4;
    if (bVar1 == 1) {
      if ((int)pbVar4 - (int)pbVar6 == 0) {
        return (byte *)0xffffffec;
      }
      if (0x23 < *pbVar6) {
        return (byte *)0xffffffec;
      }
      FUN_00054180(puVar5,*pbVar6);
      uVar3 = 1;
      *param_1 = puVar5;
    }
    else {
      uVar2 = FUN_00054fe0(local_7a,&local_8c,&local_84,pbVar6,(int)pbVar4 - (int)pbVar6);
      uVar3 = 0xffffffec;
      if ((uVar2 < 0xffffff89) && (uVar3 = 0xffffffec, local_84 < 10)) {
        local_80 = uVar2;
        FUN_00053fb0(puVar5,local_7a,local_8c,local_84);
        *param_1 = puVar5;
        uVar3 = local_80;
      }
      if (0xffffff88 < uVar3) {
        return (byte *)0xffffffec;
      }
    }
  }
  uVar2 = (uint)local_88 >> 4 & 3;
  pbVar6 = pbVar6 + uVar3;
  local_8c = 0x1c;
  if (uVar2 == 0) {
    param_1[2] = &DAT_00063294;
    uVar3 = 0;
  }
  else if (uVar2 == 3) {
    uVar3 = 0;
    if (param_1[0x171b] == 0) {
      return (byte *)0xffffffec;
    }
  }
  else {
    puVar5 = param_1 + 0x205;
    if (uVar2 == 1) {
      if ((int)pbVar4 - (int)pbVar6 == 0) {
        return (byte *)0xffffffec;
      }
      if (0x1c < *pbVar6) {
        return (byte *)0xffffffec;
      }
      FUN_00054180(puVar5,*pbVar6);
      uVar3 = 1;
      param_1[2] = puVar5;
    }
    else {
      uVar2 = FUN_00054fe0(local_7a,&local_8c,&local_84,pbVar6,(int)pbVar4 - (int)pbVar6);
      uVar3 = 0xffffffec;
      if ((uVar2 < 0xffffff89) && (uVar3 = 0xffffffec, local_84 < 9)) {
        local_80 = uVar2;
        FUN_00053fb0(puVar5,local_7a,local_8c,local_84);
        param_1[2] = puVar5;
        uVar3 = local_80;
      }
      if (0xffffff88 < uVar3) {
        return (byte *)0xffffffec;
      }
    }
  }
  uVar2 = (uint)local_88 >> 2 & 3;
  pbVar6 = pbVar6 + uVar3;
  local_8c = 0x34;
  if (uVar2 == 0) {
    puVar5 = (undefined4 *)&DAT_00063318;
    uVar3 = 0;
  }
  else {
    if (uVar2 == 3) {
      uVar3 = 0;
      if (param_1[0x171b] == 0) {
        return (byte *)0xffffffec;
      }
      goto LAB_00050794;
    }
    puVar5 = param_1 + 0x306;
    local_88 = puVar5;
    if (uVar2 != 1) {
      uVar2 = FUN_00054fe0(local_7a,&local_8c,&local_84,pbVar6,(int)pbVar4 - (int)pbVar6);
      puVar5 = local_88;
      uVar3 = 0xffffffec;
      if ((uVar2 < 0xffffff89) && (uVar3 = 0xffffffec, local_84 < 10)) {
        FUN_00053fb0(local_88,local_7a,local_8c,local_84);
        param_1[1] = puVar5;
        uVar3 = uVar2;
      }
      if (0xffffff88 < uVar3) {
        return (byte *)0xffffffec;
      }
      goto LAB_00050794;
    }
    if ((int)pbVar4 - (int)pbVar6 == 0) {
      return (byte *)0xffffffec;
    }
    if (0x34 < *pbVar6) {
      return (byte *)0xffffffec;
    }
    FUN_00054180(puVar5,*pbVar6);
    uVar3 = 1;
  }
  param_1[1] = puVar5;
LAB_00050794:
  return pbVar6 + (uVar3 - (int)param_3);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00050830 FUN_00050830 */

uint __regparm3
FUN_00050830(undefined4 param_1_00,int param_2_00,ushort **param_3_00,int param_1,int param_2,
            uint param_3)

{
  uint *puVar1;
  ushort *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  byte bVar5;
  byte bVar6;
  byte bVar7;
  ushort uVar8;
  ushort *puVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  uint uVar17;
  uint uVar18;
  int iVar19;
  ushort *puVar20;
  undefined *puVar21;
  ushort *puVar22;
  ushort *puVar23;
  int iVar24;
  int iVar25;
  uint uVar26;
  ushort *puVar27;
  uint *puVar28;
  uint *puVar29;
  ushort *puVar30;
  uint uVar31;
  int local_c0;
  uint uStack_b4;
  uint uStack_b0;
  uint local_9c;
  uint local_98;
  uint *local_94;
  uint *local_90;
  uint *local_8c;
  uint uStack_88;
  ushort *puStack_84;
  uint uStack_80;
  ushort *puStack_7c;
  uint uStack_78;
  ushort *puStack_74;
  ushort *local_70 [7];
  ushort *puStack_54;
  int iStack_50;
  uint uStack_4c;
  int local_48;
  ushort *local_44;
  ushort *local_40;
  ushort *local_3c;
  int local_38;
  ushort *local_34;
  ushort *local_30;
  ushort *puStack_2c;
  int iStack_28;
  ushort *puStack_24;
  ushort *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  ushort *puStack_14;
  
  if (0x1ffff < param_3) {
    return 0xffffffb8;
  }
  local_38 = param_2_00;
  uVar17 = FUN_00050010(param_3_00,param_2,param_3);
  param_2 = param_2 + uVar17;
  if (0xffffff88 < uVar17) {
    return uVar17;
  }
  puVar30 = param_3_00[0x1733];
  local_3c = (ushort *)((int)param_3_00[0x1737] + (int)puVar30);
  puVar9 = param_3_00[0x170c];
  local_30 = param_3_00[0x170d];
  local_34 = param_3_00[0x170e];
  local_44 = puVar30;
  uVar18 = FUN_000503c0(param_3_00,&local_48,param_2,param_3 - uVar17);
  puVar1 = (uint *)(param_2 + uVar18);
  if (0xffffff88 < uVar18) {
    return uVar18;
  }
  puVar23 = (ushort *)(param_1 + local_38);
  local_c0 = local_38;
  if (local_48 == 0) {
LAB_000514a6:
    uVar18 = (int)local_3c - (int)puVar30;
    uVar17 = 0xffffffba;
    if (uVar18 <= (uint)((int)puVar23 - local_c0)) {
      FUN_00013c06(local_c0,puVar30,uVar18);
      uVar17 = (local_c0 + uVar18) - local_38;
    }
  }
  else {
    param_2 = param_2 + (param_3 - uVar17);
    param_3_00[0x171b] = (ushort *)0x1;
    local_70[0] = param_3_00[0x1708];
    local_70[1] = param_3_00[0x1709];
    local_70[2] = param_3_00[0x170a];
    uVar17 = param_2 - (int)puVar1;
    if (uVar17 == 0) {
      FUN_00013c0c(&local_9c,0,0x14);
    }
    else {
      local_8c = puVar1 + 1;
      local_40 = puVar23;
      if (uVar17 < 4) {
        local_9c = (uint)*(byte *)puVar1;
        if (uVar17 == 2) {
LAB_000509f0:
          local_9c = local_9c + (uint)*(byte *)((int)puVar1 + 1) * 0x100;
        }
        else if (uVar17 == 3) {
          local_9c = local_9c | (uint)*(byte *)((int)puVar1 + 2) << 0x10;
          goto LAB_000509f0;
        }
        bVar5 = *(byte *)((uVar17 - 1) + (int)puVar1);
        if (bVar5 == 0) goto LAB_00050bc7;
        iVar24 = 0x1f;
        if (bVar5 != 0) {
          for (; bVar5 >> iVar24 == 0; iVar24 = iVar24 + -1) {
          }
        }
        iVar24 = 0x28 - (iVar24 + uVar17 * 8);
        local_94 = puVar1;
      }
      else {
        local_9c = *(uint *)(param_2 + -4);
        bVar5 = *(byte *)((uVar17 - 1) + (int)puVar1);
        if (bVar5 == 0) goto LAB_00050bc7;
        uVar18 = 0x1f;
        if (bVar5 != 0) {
          for (; bVar5 >> uVar18 == 0; uVar18 = uVar18 - 1) {
          }
        }
        iVar24 = ~uVar18 + 9;
        local_94 = (uint *)(param_2 + -4);
        if (0xffffff88 < uVar17) {
          return 0xffffffec;
        }
      }
      uVar8 = **param_3_00;
      uStack_88 = ((local_9c << ((byte)iVar24 & 0x1f)) >> 1) >> (0x1fU - (char)uVar8 & 0x1f);
      local_98 = iVar24 + (uint)uVar8;
      puVar28 = local_94;
      if (local_98 < 0x21) {
        if (local_94 < local_8c) {
          puVar28 = puVar1;
          if ((int)local_94 - (int)puVar1 != 0) {
            uVar17 = local_98 >> 3;
            if ((uint *)((int)local_94 - (local_98 >> 3)) < puVar1) {
              uVar17 = (int)local_94 - (int)puVar1;
            }
            local_94 = (uint *)((int)local_94 - uVar17);
            local_98 = local_98 + uVar17 * -8;
            local_9c = *local_94;
            puVar28 = local_94;
          }
        }
        else {
          local_94 = (uint *)((int)local_94 - (local_98 >> 3));
          local_98 = local_98 & 7;
          local_9c = *local_94;
          puVar28 = local_94;
        }
      }
      puStack_84 = *param_3_00 + 2;
      uVar8 = *param_3_00[2];
      uStack_80 = ((local_9c << ((byte)local_98 & 0x1f)) >> 1) >> (0x1fU - (char)uVar8 & 0x1f);
      local_98 = local_98 + uVar8;
      puVar29 = puVar28;
      if (local_98 < 0x21) {
        if (puVar28 < local_8c) {
          puVar29 = puVar1;
          if ((int)puVar28 - (int)puVar1 == 0) goto LAB_00050b44;
          uVar17 = local_98 >> 3;
          if ((uint *)((int)puVar28 - (local_98 >> 3)) < puVar1) {
            uVar17 = (int)puVar28 - (int)puVar1;
          }
          local_98 = local_98 + uVar17 * -8;
        }
        else {
          uVar17 = local_98 >> 3;
          local_98 = local_98 & 7;
        }
        local_94 = (uint *)((int)puVar28 - uVar17);
        local_9c = *local_94;
        puVar29 = local_94;
      }
LAB_00050b44:
      puStack_7c = param_3_00[2] + 2;
      uVar8 = *param_3_00[1];
      uStack_78 = ((local_9c << ((byte)local_98 & 0x1f)) >> 1) >> (0x1fU - (char)uVar8 & 0x1f);
      local_98 = local_98 + uVar8;
      if (local_98 < 0x21) {
        if (puVar29 < local_8c) {
          if ((int)puVar29 - (int)puVar1 == 0) goto LAB_00050bb7;
          uVar17 = local_98 >> 3;
          if ((uint *)((int)puVar29 - (local_98 >> 3)) < puVar1) {
            uVar17 = (int)puVar29 - (int)puVar1;
          }
          local_98 = local_98 + uVar17 * -8;
        }
        else {
          uVar17 = local_98 >> 3;
          local_98 = local_98 & 7;
        }
        local_94 = (uint *)((int)puVar29 - uVar17);
        local_9c = *local_94;
      }
LAB_00050bb7:
      puStack_74 = param_3_00[1] + 2;
      if (local_98 < 0x21) {
        puVar30 = puVar23 + -4;
        puStack_24 = (ushort *)((int)puVar23 + -0xd);
        puStack_2c = puVar9 + 8;
        iStack_28 = -(int)puVar9;
        local_90 = puVar1;
        do {
          puVar23 = local_44;
          if (local_94 < local_8c) {
            if ((int)local_94 - (int)local_90 != 0) {
              uVar17 = local_98 >> 3;
              if ((uint *)((int)local_94 - (local_98 >> 3)) < local_90) {
                uVar17 = (int)local_94 - (int)local_90;
              }
              local_98 = local_98 + uVar17 * -8;
              goto LAB_00050c4e;
            }
          }
          else {
            uVar17 = local_98 >> 3;
            local_98 = local_98 & 7;
LAB_00050c4e:
            local_94 = (uint *)((int)local_94 - uVar17);
            local_9c = *local_94;
          }
          if (local_48 == 0) goto LAB_00051476;
          local_48 = local_48 + -1;
          uStack_1c = uStack_88;
          puStack_20 = puStack_84;
          bVar5 = *(byte *)(puStack_84 + uStack_88 * 2 + 1);
          bVar6 = *(byte *)(puStack_7c + uStack_80 * 2 + 1);
          uVar17 = (uint)bVar6;
          puStack_14 = puStack_74;
          uStack_18 = uStack_78;
          bVar7 = *(byte *)(puStack_74 + uStack_78 * 2 + 1);
          iVar24 = *(int *)(&UNK_0006341c + (uint)bVar5 * 4);
          iVar25 = *(int *)(&UNK_000634ac + (uint)bVar7 * 4);
          if (uVar17 == 0) {
            puStack_54 = (ushort *)0x0;
LAB_00050d99:
            iVar19 = (uint)(bVar5 == 0) + (int)puStack_54;
            if (iVar19 != 0) {
              if (iVar19 == 3) {
                puStack_54 = (ushort *)((int)local_70[0] + -1 + (uint)((int)local_70[0] + -1 == 0));
              }
              else {
                puStack_54 = (ushort *)
                             ((int)local_70[iVar19] + (uint)(local_70[iVar19] == (ushort *)0x0));
                if (iVar19 == 1) goto LAB_00050de8;
              }
              local_70[2] = local_70[1];
              goto LAB_00050de8;
            }
          }
          else {
            puStack_54 = (ushort *)((local_9c << ((byte)local_98 & 0x1f)) >> (-bVar6 & 0x1f));
            local_98 = local_98 + uVar17;
            if (local_98 < 0x21) {
              if (local_94 < local_8c) {
                if ((int)local_94 - (int)local_90 != 0) {
                  uVar18 = local_98 >> 3;
                  if ((uint *)((int)local_94 - (local_98 >> 3)) < local_90) {
                    uVar18 = (int)local_94 - (int)local_90;
                  }
                  local_94 = (uint *)((int)local_94 - uVar18);
                  local_98 = local_98 + uVar18 * -8;
                  local_9c = *local_94;
                }
              }
              else {
                local_94 = (uint *)((int)local_94 - (local_98 >> 3));
                local_98 = local_98 & 7;
                local_9c = *local_94;
              }
            }
            puStack_54 = (ushort *)((int)puStack_54 + *(int *)(&UNK_000636e4 + uVar17 * 4));
            if (bVar6 < 2) goto LAB_00050d99;
            local_70[2] = local_70[1];
LAB_00050de8:
            local_70[1] = local_70[0];
            local_70[0] = puStack_54;
          }
          uStack_b0 = 0;
          if (0x1f < bVar7) {
            uStack_b0 = (local_9c << ((byte)local_98 & 0x1f)) >> (-(char)iVar25 & 0x1fU);
            local_98 = local_98 + iVar25;
          }
          if ((0x18 < (uint)(iVar25 + iVar24)) && (local_98 < 0x21)) {
            if (local_94 < local_8c) {
              if ((int)local_94 - (int)local_90 == 0) goto LAB_00050e91;
              uVar17 = local_98 >> 3;
              if ((uint *)((int)local_94 - (local_98 >> 3)) < local_90) {
                uVar17 = (int)local_94 - (int)local_90;
              }
              local_98 = local_98 + uVar17 * -8;
            }
            else {
              uVar17 = local_98 >> 3;
              local_98 = local_98 & 7;
            }
            local_94 = (uint *)((int)local_94 - uVar17);
            local_9c = *local_94;
          }
LAB_00050e91:
          uStack_4c = 0;
          if (0xf < bVar5) {
            uStack_4c = (local_9c << ((byte)local_98 & 0x1f)) >> (-(char)iVar24 & 0x1fU);
            local_98 = local_98 + iVar24;
          }
          iVar24 = *(int *)(&UNK_00063610 + (uint)bVar7 * 4);
          iStack_50 = *(int *)(&UNK_00063580 + (uint)bVar5 * 4);
          if (local_98 < 0x21) {
            if (local_94 < local_8c) {
              if ((int)local_94 - (int)local_90 == 0) goto LAB_00050f28;
              uVar17 = local_98 >> 3;
              if ((uint *)((int)local_94 - (local_98 >> 3)) < local_90) {
                uVar17 = (int)local_94 - (int)local_90;
              }
              local_98 = local_98 + uVar17 * -8;
            }
            else {
              uVar17 = local_98 >> 3;
              local_98 = local_98 & 7;
            }
            local_94 = (uint *)((int)local_94 - uVar17);
            local_9c = *local_94;
          }
LAB_00050f28:
          bVar5 = *(byte *)((int)puStack_84 + uStack_88 * 4 + 3);
          uStack_88 = (((local_9c << ((byte)local_98 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                      (uint)puStack_84[uStack_88 * 2];
          iVar25 = local_98 + bVar5;
          bVar5 = *(byte *)((int)puStack_74 + uStack_78 * 4 + 3);
          uStack_78 = (((local_9c << ((byte)iVar25 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                      (uint)puStack_74[uStack_78 * 2];
          local_98 = iVar25 + (uint)bVar5;
          uStack_b4 = uStack_b0 + iVar24;
          uVar17 = uStack_4c + iStack_50;
          if (local_98 < 0x21) {
            if (local_94 < local_8c) {
              if ((int)local_94 - (int)local_90 == 0) goto LAB_00050ffd;
              uVar18 = local_98 >> 3;
              if ((uint *)((int)local_94 - (local_98 >> 3)) < local_90) {
                uVar18 = (int)local_94 - (int)local_90;
              }
              local_98 = local_98 + uVar18 * -8;
            }
            else {
              uVar18 = local_98 >> 3;
              local_98 = local_98 & 7;
            }
            local_94 = (uint *)((int)local_94 - uVar18);
            local_9c = *local_94;
          }
LAB_00050ffd:
          bVar5 = *(byte *)((int)puStack_7c + uStack_80 * 4 + 3);
          uStack_80 = (((local_9c << ((byte)local_98 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                      (uint)puStack_7c[uStack_80 * 2];
          local_98 = local_98 + bVar5;
          uVar18 = uVar17 + uStack_b4;
          puVar2 = (ushort *)(local_c0 + uVar18);
          if (local_40 < puVar2) {
            return 0xffffffba;
          }
          puVar22 = (ushort *)((int)local_44 + uVar17);
          if (local_3c < puVar22) {
            return 0xffffffec;
          }
          puVar20 = (ushort *)(local_c0 + uVar17);
          puStack_54 = local_70[0];
          if (puVar30 < puVar20) {
            uVar18 = FUN_00053b20(uVar17,uStack_b4,local_70[0],&local_44,local_3c,puVar9,local_30,
                                  local_34);
          }
          else {
            FUN_00013c06(local_c0,local_44,8);
            if (8 < uVar17) {
              puVar27 = (ushort *)(local_c0 + 8);
              do {
                puVar23 = puVar23 + 4;
                FUN_00013c06(puVar27,puVar23,8);
                puVar27 = puVar27 + 4;
              } while (puVar27 < puVar20);
            }
            puVar27 = (ushort *)((int)puVar20 - (int)puStack_54);
            puVar23 = puVar27;
            local_44 = puVar22;
            if ((ushort *)((int)puVar20 - (int)puVar9) < puStack_54) {
              if ((ushort *)((int)puVar20 - (int)local_30) < puStack_54) {
                return 0xffffffec;
              }
              iVar19 = (int)puVar27 - (int)puVar9;
              iVar25 = (int)local_34 + iVar19;
              if (local_34 < (ushort *)(iVar25 + uStack_b4)) {
                FUN_00013c12(puVar20,iVar25,-iVar19);
                puVar20 = (ushort *)((int)puVar20 - iVar19);
                uStack_b4 = uStack_b4 + iVar19;
                if ((puVar20 <= puVar30) && (puVar23 = puVar9, 2 < uStack_b4)) goto LAB_000511bb;
                if (uStack_b4 != 0) {
                  puVar21 = (undefined *)0x0;
                  uVar26 = 0;
                  if ((0x1f < uStack_b4) &&
                     (((ushort *)((int)puVar27 + iVar24 + uStack_b0) <= puVar20 ||
                      (uVar26 = 0,
                      (ushort *)(uStack_4c + uStack_b0 + iVar24 + iStack_50 + local_c0) <= puVar9)))
                     ) {
                    uVar26 = uStack_b4 & 0xffffffe0;
                    iVar25 = (uVar17 - (int)puVar27) + local_c0;
                    uVar17 = 0;
                    do {
                      puVar3 = (undefined4 *)((int)puVar9 + uVar17);
                      uVar10 = puVar3[1];
                      uVar11 = puVar3[2];
                      uVar12 = puVar3[3];
                      puVar4 = (undefined4 *)((int)puVar9 + uVar17 + 0x10);
                      uVar13 = *puVar4;
                      uVar14 = puVar4[1];
                      uVar15 = puVar4[2];
                      uVar16 = puVar4[3];
                      puVar4 = (undefined4 *)((int)puStack_2c + uVar17 + iVar25 + -0x10);
                      *puVar4 = *puVar3;
                      puVar4[1] = uVar10;
                      puVar4[2] = uVar11;
                      puVar4[3] = uVar12;
                      puVar3 = (undefined4 *)((int)puStack_2c + uVar17 + iVar25);
                      *puVar3 = uVar13;
                      puVar3[1] = uVar14;
                      puVar3[2] = uVar15;
                      puVar3[3] = uVar16;
                      uVar17 = uVar17 + 0x20;
                    } while (uVar26 != uVar17);
                    if (uStack_b4 == uVar26) goto joined_r0x00051428;
                  }
                  do {
                    *(undefined *)
                     ((int)puVar9 +
                     (int)(puVar21 + ((uStack_4c + uVar26 + iStack_50) - (int)puVar27) + local_c0))
                         = *(undefined *)((int)puVar9 + (int)(puVar21 + uVar26));
                    puVar21 = puVar21 + 1;
                  } while ((undefined *)((int)puVar27 + ((iVar24 + uStack_b0 + iStack_28) - uVar26))
                           != puVar21);
                }
              }
              else {
                FUN_00013c12(puVar20,iVar25,uStack_b4);
              }
            }
            else {
LAB_000511bb:
              puVar22 = puStack_54;
              if (puStack_54 < (ushort *)0x8) {
                *(undefined *)puVar20 = *(undefined *)puVar23;
                *(undefined *)((int)puVar20 + 1) = *(undefined *)((int)puVar23 + 1);
                *(undefined *)(puVar20 + 1) = *(undefined *)(puVar23 + 1);
                *(undefined *)((int)puVar20 + 3) = *(undefined *)((int)puVar23 + 3);
                iVar25 = *(int *)(&UNK_00015d40 + (int)puStack_54 * 4);
                FUN_00013c06(puVar20 + 2,(undefined *)((int)puVar23 + iVar25),4);
                puVar23 = (ushort *)
                          ((undefined *)((int)puVar23 + iVar25) +
                          -*(int *)(&UNK_00015d60 + (int)puVar22 * 4));
              }
              else {
                FUN_00013c06(puVar20,puVar23,8);
              }
              puVar22 = puVar20 + 4;
              puVar23 = puVar23 + 4;
              if (puStack_24 < puVar2) {
                puVar20 = puVar23;
                puVar27 = puVar22;
                if (puVar22 < puVar30) {
                  do {
                    FUN_00013c06(puVar27,puVar20,8);
                    puVar27 = puVar27 + 4;
                    puVar20 = puVar20 + 4;
                  } while (puVar27 < puVar30);
                  puVar23 = (ushort *)((int)puVar23 + ((int)puVar30 - (int)puVar22));
                  puVar22 = puVar30;
                }
                if (puVar22 < puVar2) {
                  uVar17 = ((uStack_b0 + uStack_4c + iVar24 + iStack_50) - (int)puVar22) + local_c0;
                  if ((0x1f < uVar17) &&
                     (((ushort *)
                       (((uStack_b0 + uStack_4c + iStack_50 + iVar24) - (int)puVar22) + local_c0 +
                       (int)puVar23) <= puVar22 || (puVar2 <= puVar23)))) {
                    uVar31 = uVar17 & 0xffffffe0;
                    uVar26 = 0;
                    do {
                      puVar4 = (undefined4 *)((int)puVar23 + uVar26);
                      uVar10 = puVar4[1];
                      uVar11 = puVar4[2];
                      uVar12 = puVar4[3];
                      puVar3 = (undefined4 *)((int)puVar23 + uVar26 + 0x10);
                      uVar13 = *puVar3;
                      uVar14 = puVar3[1];
                      uVar15 = puVar3[2];
                      uVar16 = puVar3[3];
                      puVar3 = (undefined4 *)((int)puVar22 + uVar26);
                      *puVar3 = *puVar4;
                      puVar3[1] = uVar10;
                      puVar3[2] = uVar11;
                      puVar3[3] = uVar12;
                      puVar3 = (undefined4 *)((int)puVar22 + uVar26 + 0x10);
                      *puVar3 = uVar13;
                      puVar3[1] = uVar14;
                      puVar3[2] = uVar15;
                      puVar3[3] = uVar16;
                      uVar26 = uVar26 + 0x20;
                    } while (uVar31 != uVar26);
                    puVar23 = (ushort *)((int)puVar23 + uVar31);
                    puVar22 = (ushort *)((int)puVar22 + uVar31);
                    if (uVar31 == uVar17) goto joined_r0x00051428;
                  }
                  do {
                    *(undefined *)puVar22 = *(undefined *)puVar23;
                    puVar22 = (ushort *)((int)puVar22 + 1);
                    puVar23 = (ushort *)((int)puVar23 + 1);
                  } while (puVar22 < puVar2);
                }
              }
              else {
                do {
                  FUN_00013c06(puVar22,puVar23,8);
                  puVar22 = puVar22 + 4;
                  puVar23 = puVar23 + 4;
                } while (puVar22 < (ushort *)((int)puVar20 + uStack_b4));
              }
            }
          }
joined_r0x00051428:
          if (0xffffff88 < uVar18) {
            return uVar18;
          }
          local_c0 = local_c0 + uVar18;
        } while (local_98 < 0x21);
        if (local_48 == 0) {
LAB_00051476:
          param_3_00[0x1708] = local_70[0];
          param_3_00[0x1709] = local_70[1];
          param_3_00[0x170a] = local_70[2];
          puVar23 = local_40;
          puVar30 = local_44;
          goto LAB_000514a6;
        }
      }
    }
LAB_00050bc7:
    uVar17 = 0xffffffec;
  }
  return uVar17;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00052120 FUN_00052120 */

undefined4 FUN_00052120(int *param_1,int *param_2,uint param_3)

{
  uint uVar1;
  
  param_1[0x170f] = 5;
  param_1[0x1719] = 0;
  *(undefined (*) [16])(param_1 + 0x170b) = ZEXT816(0);
  param_1[0x507] = 0xc00000c;
  param_1[0x171b] = 0;
  param_1[0x171a] = 0;
  param_1[0x1732] = 0;
  FUN_00013c06(param_1 + 0x1708,&DAT_00063184,0xc);
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  if ((param_2 != (int *)0x0) && (param_3 != 0)) {
    if ((param_3 < 8) || (*param_2 != -0x13cf5bc9)) {
      param_1[0x170e] = param_1[0x170b];
      param_1[0x170d] = (param_1[0x170c] - param_1[0x170b]) + (int)param_2;
      param_1[0x170c] = (int)param_2;
    }
    else {
      param_1[0x1732] = param_2[1];
      uVar1 = FUN_00053d20(param_3);
      if (0xffffff88 < uVar1) {
        return 0xffffffe2;
      }
      param_1[0x171b] = 1;
      param_1[0x171a] = 1;
      param_1[0x170e] = param_1[0x170b];
      param_1[0x170d] = (param_1[0x170c] - param_1[0x170b]) + uVar1 + (int)param_2;
      param_1[0x170c] = uVar1 + (int)param_2;
    }
    param_1[0x170b] = param_3 + (int)param_2;
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00053b20 FUN_00053b20 */

int __regparm3
FUN_00053b20(undefined4 param_1_00,undefined *param_2_00,undefined *param_3_00,int param_1,
            int param_2,uint param_3,int *param_4,undefined *param_5,undefined *param_6,int param_7,
            uint param_8)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined *puVar11;
  undefined *puVar12;
  undefined *puVar13;
  int iVar14;
  undefined *puVar15;
  undefined *puVar16;
  undefined4 uVar17;
  
  uVar17 = 0x53b2e;
  iVar1 = param_2 + param_1;
  puVar12 = param_3_00 + iVar1;
  iVar10 = -0x46;
  if (puVar12 <= param_2_00) {
    puVar13 = (undefined *)*param_4;
    iVar10 = -0x14;
    if (puVar13 + param_1 <= param_5) {
      puVar11 = param_3_00 + param_1;
      param_2_00 = param_2_00 + -8;
      iVar10 = -1;
      if (param_2_00 < puVar11) {
        puVar15 = param_3_00;
        if (param_3_00 <= param_2_00 && (int)param_2_00 - (int)param_3_00 != 0) {
          do {
            FUN_00013c06(puVar15,puVar13,8,uVar17);
            puVar15 = puVar15 + 8;
            puVar13 = puVar13 + 8;
          } while (puVar15 < param_2_00);
          puVar13 = (undefined *)(((int)param_2_00 - (int)param_3_00) + *param_4);
          *param_4 = (int)puVar13;
          puVar15 = param_2_00;
        }
        if (puVar15 < puVar11) {
          *param_4 = (int)(puVar13 + 1);
          *puVar15 = *puVar13;
          while (puVar15 = puVar15 + 1, puVar15 < puVar11) {
            puVar13 = (undefined *)*param_4;
            *param_4 = (int)(puVar13 + 1);
            *puVar15 = *puVar13;
          }
        }
        puVar13 = puVar11 + -param_3;
        if ((uint)((int)puVar11 - (int)param_6) < param_3) {
          if ((uint)((int)puVar11 - param_7) < param_3) {
            return -0x14;
          }
          iVar14 = (int)puVar13 - (int)param_6;
          iVar10 = param_8 + iVar14;
          if ((uint)(param_2 + iVar10) <= param_8) {
            FUN_00013c12(puVar11,iVar10,param_2);
            return iVar1;
          }
          FUN_00013c12(puVar11,iVar10,-iVar14);
          puVar15 = puVar11 + -iVar14;
          puVar13 = param_6;
        }
        iVar10 = iVar1;
        if (puVar15 < puVar12) {
          puVar11 = param_3_00 + ((param_2 + param_1) - (int)puVar15);
          if (((undefined *)0x1f < puVar11) &&
             ((puVar13 + (int)puVar11 <= puVar15 || (puVar12 <= puVar13)))) {
            puVar16 = (undefined *)((uint)puVar11 & 0xffffffe0);
            puVar12 = (undefined *)0x0;
            do {
              puVar3 = (undefined4 *)(puVar13 + (int)puVar12);
              uVar17 = puVar3[1];
              uVar4 = puVar3[2];
              uVar5 = puVar3[3];
              puVar2 = (undefined4 *)(puVar13 + 0x10 + (int)puVar12);
              uVar6 = *puVar2;
              uVar7 = puVar2[1];
              uVar8 = puVar2[2];
              uVar9 = puVar2[3];
              puVar2 = (undefined4 *)(puVar15 + (int)puVar12);
              *puVar2 = *puVar3;
              puVar2[1] = uVar17;
              puVar2[2] = uVar4;
              puVar2[3] = uVar5;
              puVar2 = (undefined4 *)(puVar15 + 0x10 + (int)puVar12);
              *puVar2 = uVar6;
              puVar2[1] = uVar7;
              puVar2[2] = uVar8;
              puVar2[3] = uVar9;
              puVar12 = puVar12 + 0x20;
            } while (puVar16 != puVar12);
            puVar13 = puVar13 + (int)puVar16;
            puVar15 = puVar15 + (int)puVar16;
            if (puVar16 == puVar11) {
              return iVar1;
            }
          }
          puVar12 = (undefined *)0x0;
          do {
            puVar15[(int)puVar12] = puVar13[(int)puVar12];
            puVar12 = puVar12 + 1;
          } while (param_3_00 + ((param_2 + param_1) - (int)puVar15) != puVar12);
        }
      }
    }
  }
  return iVar10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00053d20 FUN_00053d20 */

int __regparm3 FUN_00053d20(undefined4 param_1_00,int param_2,int param_3,uint param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  undefined4 local_90;
  int local_8c;
  uint local_88;
  uint *local_84;
  int local_80;
  undefined local_7a [106];
  
  if (8 < param_1) {
    local_8c = param_3;
    uVar2 = FUN_000573f0(param_3 + 0x140c,param_2 + 8,param_1 - 8,param_3 + 0x5410,0x800);
    iVar4 = param_2 + 8 + uVar2;
    if (uVar2 < 0xffffff89) {
      local_90 = 0x1c;
      local_80 = param_2;
      uVar2 = FUN_00054fe0(local_7a,&local_90,&local_88,iVar4,
                           (int)(uint *)(param_1 + param_2) - iVar4);
      if ((uVar2 < 0xffffff89) && (local_88 < 9)) {
        local_84 = (uint *)(param_1 + param_2);
        uVar3 = FUN_00053fb0(local_8c + 0x804,local_7a,local_90,local_88);
        iVar4 = uVar2 + iVar4;
        if (uVar3 < 0xffffff89) {
          local_90 = 0x34;
          uVar2 = FUN_00054fe0(local_7a,&local_90,&local_88,iVar4,(int)local_84 - iVar4);
          if ((uVar2 < 0xffffff89) && (local_88 < 10)) {
            uVar3 = FUN_00053fb0(local_8c + 0xc08,local_7a,local_90,local_88);
            puVar1 = local_84;
            iVar4 = uVar2 + iVar4;
            if (uVar3 < 0xffffff89) {
              local_90 = 0x23;
              uVar2 = FUN_00054fe0(local_7a,&local_90,&local_88,iVar4,(int)local_84 - iVar4);
              if ((uVar2 < 0xffffff89) && (local_88 < 10)) {
                uVar3 = FUN_00053fb0(local_8c,local_7a,local_90,local_88);
                puVar5 = (uint *)(uVar2 + iVar4);
                if ((uVar3 < 0xffffff89) &&
                   (((puVar5 + 3 <= puVar1 && (uVar2 = *puVar5, uVar2 != 0)) &&
                    (uVar3 = (int)puVar1 - (int)(puVar5 + 3), uVar2 < uVar3)))) {
                  *(uint *)(local_8c + 0x5c10) = uVar2;
                  uVar2 = puVar5[1];
                  if ((uVar2 != 0) && (uVar2 < uVar3)) {
                    *(uint *)(local_8c + 0x5c14) = uVar2;
                    uVar2 = puVar5[2];
                    if (uVar2 != 0) {
                      if (uVar2 < uVar3) {
                        *(uint *)(local_8c + 0x5c18) = uVar2;
                        return (int)puVar5 + (0xc - local_80);
                      }
                      return -0x1e;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return -0x1e;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00053fb0 FUN_00053fb0 */

undefined4 FUN_00053fb0(int param_1,int param_2,uint param_3,uint param_4)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  uint uVar4;
  ushort uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined2 local_224;
  undefined2 local_222;
  uint local_220;
  ushort auStack_210 [256];
  
  bVar1 = (byte)param_4;
  local_220 = 1 << (bVar1 & 0x1f);
  uVar6 = 0xffffffd2;
  if ((param_3 < 0x100) && (uVar6 = 0xffffffd4, param_4 < 0xd)) {
    local_224 = (undefined2)param_4;
    local_222 = 1;
    if (param_3 == 0xffffffff) {
      FUN_00013c06(param_1,&local_224,4,0x53fbf);
    }
    else {
      uVar8 = local_220 - 1;
      iVar3 = 0;
      uVar9 = uVar8;
      do {
        uVar5 = *(ushort *)(param_2 + iVar3 * 2);
        if ((short)uVar5 == -1) {
          *(char *)(param_1 + 6 + uVar9 * 4) = (char)iVar3;
          uVar9 = uVar9 - 1;
          uVar5 = 1;
        }
        else if ((0x10000 << (bVar1 - 1 & 0x1f)) >> 0x10 <= (int)(short)uVar5) {
          local_222 = 0;
        }
        auStack_210[iVar3] = uVar5;
        iVar3 = iVar3 + 1;
      } while (param_3 + 1 != iVar3);
      FUN_00013c06(param_1,&local_224,4,0x53fbf);
      if (param_3 != 0xffffffff) {
        uVar4 = 0;
        iVar3 = 0;
        do {
          iVar7 = (int)*(short *)(param_2 + iVar3 * 2);
          if (0 < iVar7) {
            iVar10 = 0;
            do {
              *(char *)(param_1 + 6 + uVar4 * 4) = (char)iVar3;
              do {
                uVar4 = uVar4 + (local_220 >> 3) + 3 + (local_220 >> 1) & uVar8;
              } while (uVar9 < uVar4);
              iVar10 = iVar10 + 1;
            } while (iVar10 < iVar7);
          }
          iVar3 = iVar3 + 1;
        } while (iVar3 != param_3 + 1);
        if (uVar4 != 0) {
          return 0xffffffff;
        }
      }
    }
    uVar8 = 0;
    do {
      bVar2 = *(byte *)(param_1 + 6 + uVar8 * 4);
      uVar5 = auStack_210[bVar2];
      auStack_210[bVar2] = uVar5 + 1;
      iVar3 = 0x1f;
      if (uVar5 != 0) {
        for (; uVar5 >> iVar3 == 0; iVar3 = iVar3 + -1) {
        }
      }
      bVar2 = bVar1 - (char)iVar3;
      *(byte *)(param_1 + 7 + uVar8 * 4) = bVar2;
      *(ushort *)(param_1 + 4 + uVar8 * 4) = (uVar5 << (bVar2 & 0x1f)) - (short)local_220;
      uVar8 = uVar8 + 1;
    } while (uVar8 < local_220);
    uVar6 = 0;
  }
  return uVar6;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00054180 FUN_00054180 */

undefined4 FUN_00054180(undefined4 *param_1,undefined param_2)

{
  *param_1 = 0;
  *(undefined2 *)(param_1 + 1) = 0;
  *(undefined *)((int)param_1 + 6) = param_2;
  *(undefined *)((int)param_1 + 7) = 0;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000541f0 FUN_000541f0 */

undefined *
FUN_000541f0(undefined *param_1,int param_2,uint *param_3,undefined *param_4,ushort *param_5)

{
  uint *puVar1;
  uint *puVar2;
  ushort uVar3;
  undefined *puVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined *puVar10;
  undefined *puVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  bool bVar15;
  undefined *local_38;
  uint local_34 [2];
  uint *local_2c;
  undefined *local_18;
  
  local_18 = param_1 + param_2 + -3;
  if (param_5[1] == 0) {
    if (param_4 == (undefined *)0x0) goto LAB_000542eb;
    puVar1 = param_3 + 1;
    if (param_4 < (undefined *)0x4) {
      local_2c = param_3;
      local_34[0] = (uint)*(byte *)param_3;
      if (param_4 == (undefined *)0x2) {
LAB_0005440c:
        local_34[0] = local_34[0] + (uint)*(byte *)((int)param_3 + 1) * 0x100;
      }
      else if (param_4 == (undefined *)0x3) {
        local_34[0] = local_34[0] | (uint)*(byte *)((int)param_3 + 2) << 0x10;
        goto LAB_0005440c;
      }
      bVar5 = (param_4 + -1)[(int)param_3];
      if (bVar5 == 0) {
        return (undefined *)0xffffffec;
      }
      iVar8 = 0x1f;
      if (bVar5 != 0) {
        for (; bVar5 >> iVar8 == 0; iVar8 = iVar8 + -1) {
        }
      }
      iVar8 = 0x28 - (iVar8 + (int)param_4 * 8);
      param_4 = (undefined *)0x0;
    }
    else {
      local_2c = (uint *)((int)param_3 + (int)(param_4 + -4));
      local_34[0] = *(uint *)((int)param_3 + (int)(param_4 + -4));
      bVar5 = (param_4 + -1)[(int)param_3];
      if (bVar5 == 0) {
        return (undefined *)0xffffffff;
      }
      uVar9 = 0x1f;
      if (bVar5 != 0) {
        for (; bVar5 >> uVar9 == 0; uVar9 = uVar9 - 1) {
        }
      }
      iVar8 = ~uVar9 + 9;
      if ((undefined *)0xffffff88 < param_4) {
        return param_4;
      }
      param_4 = param_4 + -4;
    }
    uVar3 = *param_5;
    bVar5 = 0x1fU - (char)uVar3 & 0x1f;
    uVar12 = ((local_34[0] << ((byte)iVar8 & 0x1f)) >> 1) >> bVar5;
    uVar9 = iVar8 + (uint)uVar3;
    if (uVar9 < 0x21) {
      if ((int)param_4 < 4) {
        if (param_4 == (undefined *)0x0) {
          param_4 = (undefined *)0x0;
          goto LAB_000545cc;
        }
        puVar11 = (undefined *)(uVar9 >> 3);
        if ((uint *)((int)param_3 + ((int)param_4 - (int)(undefined *)(uVar9 >> 3))) < param_3) {
          puVar11 = param_4;
        }
        param_4 = param_4 + -(int)puVar11;
        uVar9 = uVar9 + (int)puVar11 * -8;
        local_34[0] = *(uint *)((int)param_3 + (int)param_4);
      }
      else {
        param_4 = param_4 + -(uVar9 >> 3);
        uVar9 = uVar9 & 7;
        local_34[0] = *(uint *)((int)param_3 + (int)param_4);
      }
      local_2c = (uint *)((int)param_3 + (int)param_4);
    }
LAB_000545cc:
    uVar14 = ((local_34[0] << ((byte)uVar9 & 0x1f)) >> 1) >> bVar5;
    uVar9 = uVar3 + uVar9;
    puVar11 = param_1;
    if (uVar9 < 0x21) {
      if ((int)param_4 < 4) {
        if (param_4 != (undefined *)0x0) {
          puVar10 = (undefined *)(uVar9 >> 3);
          if ((uint *)((int)param_3 + ((int)param_4 - (int)(undefined *)(uVar9 >> 3))) < param_3) {
            puVar10 = param_4;
          }
          local_2c = (uint *)((int)param_3 + ((int)param_4 - (int)puVar10));
          uVar9 = uVar9 + (int)puVar10 * -8;
          local_34[0] = *local_2c;
          if (0x20 < uVar9) goto LAB_00054aac;
        }
      }
      else {
        local_2c = (uint *)((int)param_3 + ((int)param_4 - (uVar9 >> 3)));
        uVar9 = uVar9 & 7;
        local_34[0] = *local_2c;
      }
      puVar10 = param_1 + 2;
      puVar4 = param_1;
      while( true ) {
        if (local_2c < puVar1) {
          puVar11 = puVar4;
          if ((int)local_2c - (int)param_3 == 0) goto LAB_00054aac;
          bVar15 = (uint *)((int)local_2c - (uVar9 >> 3)) < param_3;
          uVar7 = uVar9 >> 3;
          if (bVar15) {
            uVar7 = (int)local_2c - (int)param_3;
          }
          uVar9 = uVar9 + uVar7 * -8;
        }
        else {
          uVar7 = uVar9 >> 3;
          uVar9 = uVar9 & 7;
          bVar15 = false;
        }
        local_2c = (uint *)((int)local_2c - uVar7);
        puVar11 = puVar10 + -2;
        local_34[0] = *local_2c;
        if ((local_18 <= puVar11) || (bVar15)) goto LAB_00054aac;
        bVar5 = *(byte *)((int)param_5 + uVar12 * 4 + 7);
        iVar6 = uVar9 + bVar5;
        iVar8 = uVar12 * 2;
        uVar12 = (((local_34[0] << ((byte)uVar9 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                 (uint)param_5[uVar12 * 2 + 2];
        puVar10[-2] = *(undefined *)(param_5 + iVar8 + 3);
        bVar5 = *(byte *)((int)param_5 + uVar14 * 4 + 7);
        uVar9 = iVar6 + (uint)bVar5;
        iVar8 = uVar14 * 2;
        uVar14 = (((local_34[0] << ((byte)iVar6 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                 (uint)param_5[uVar14 * 2 + 2];
        puVar10[-1] = *(undefined *)(param_5 + iVar8 + 3);
        puVar11 = puVar10;
        if (0x20 < uVar9) goto LAB_00054aac;
        if (local_2c < puVar1) {
          if ((int)local_2c - (int)param_3 == 0) goto LAB_00054aac;
          puVar2 = (uint *)((int)local_2c - (uVar9 >> 3));
          uVar7 = uVar9 >> 3;
          if (puVar2 < param_3) {
            uVar7 = (int)local_2c - (int)param_3;
          }
          local_2c = (uint *)((int)local_2c - uVar7);
          uVar9 = uVar9 + uVar7 * -8;
          local_34[0] = *local_2c;
          if (puVar2 < param_3) goto LAB_00054aac;
        }
        else {
          local_2c = (uint *)((int)local_2c - (uVar9 >> 3));
          uVar9 = uVar9 & 7;
          local_34[0] = *local_2c;
        }
        iVar8 = uVar12 * 2;
        bVar5 = *(byte *)((int)param_5 + uVar12 * 4 + 7);
        uVar12 = (((local_34[0] << ((byte)uVar9 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                 (uint)param_5[uVar12 * 2 + 2];
        iVar6 = uVar9 + bVar5;
        *puVar10 = *(undefined *)(param_5 + iVar8 + 3);
        bVar5 = *(byte *)((int)param_5 + uVar14 * 4 + 7);
        uVar7 = (((local_34[0] << ((byte)iVar6 & 0x1f)) >> 1) >> (0x1f - bVar5 & 0x1f)) +
                (uint)param_5[uVar14 * 2 + 2];
        uVar9 = iVar6 + (uint)bVar5;
        puVar10[1] = *(undefined *)(param_5 + uVar14 * 2 + 3);
        uVar14 = uVar7;
        if (0x20 < uVar9) break;
        puVar4 = puVar4 + 4;
        puVar10 = puVar10 + 4;
      }
      puVar11 = puVar10 + 2;
    }
LAB_00054aac:
    do {
      if (param_1 + param_2 + -2 < puVar11) {
        return (undefined *)0xffffffba;
      }
      uVar3 = param_5[uVar12 * 2 + 2];
      bVar5 = *(byte *)((int)param_5 + uVar12 * 4 + 7);
      uVar13 = local_34[0] << ((byte)uVar9 & 0x1f);
      uVar7 = uVar9 + bVar5;
      puVar10 = puVar11 + 1;
      *puVar11 = *(undefined *)(param_5 + uVar12 * 2 + 3);
      if (0x20 < uVar7) {
        iVar8 = 2;
        goto LAB_00054c7d;
      }
      if (local_2c < puVar1) {
        if ((int)local_2c - (int)param_3 != 0) {
          uVar9 = uVar7 >> 3;
          if ((uint *)((int)local_2c - (uVar7 >> 3)) < param_3) {
            uVar9 = (int)local_2c - (int)param_3;
          }
          uVar7 = uVar7 + uVar9 * -8;
          goto LAB_00054b7e;
        }
      }
      else {
        uVar9 = uVar7 >> 3;
        uVar7 = uVar7 & 7;
LAB_00054b7e:
        local_2c = (uint *)((int)local_2c - uVar9);
        local_34[0] = *local_2c;
      }
      if (param_1 + param_2 + -2 < puVar10) {
        return (undefined *)0xffffffba;
      }
      uVar12 = ((uVar13 >> 1) >> (0x1f - bVar5 & 0x1f)) + (uint)uVar3;
      bVar5 = *(byte *)((int)param_5 + uVar14 * 4 + 7);
      uVar9 = uVar7 + bVar5;
      uVar3 = param_5[uVar14 * 2 + 2];
      uVar7 = local_34[0] << ((byte)uVar7 & 0x1f);
      puVar11[1] = *(undefined *)(param_5 + uVar14 * 2 + 3);
      if (0x20 < uVar9) {
        puVar10 = puVar11 + 2;
        iVar8 = 3;
        uVar14 = uVar12;
LAB_00054c7d:
        *puVar10 = *(undefined *)(param_5 + uVar14 * 2 + 3);
        return puVar11 + (iVar8 - (int)param_1);
      }
      puVar11 = puVar11 + 2;
      if (local_2c < puVar1) {
        if ((int)local_2c - (int)param_3 != 0) {
          uVar14 = uVar9 >> 3;
          if ((uint *)((int)local_2c - (uVar9 >> 3)) < param_3) {
            uVar14 = (int)local_2c - (int)param_3;
          }
          uVar9 = uVar9 + uVar14 * -8;
          goto LAB_00054c2e;
        }
      }
      else {
        uVar14 = uVar9 >> 3;
        uVar9 = uVar9 & 7;
LAB_00054c2e:
        local_2c = (uint *)((int)local_2c - uVar14);
        local_34[0] = *local_2c;
      }
      uVar14 = ((uVar7 >> 1) >> (0x1f - bVar5 & 0x1f)) + (uint)uVar3;
    } while( true );
  }
  if (param_4 == (undefined *)0x0) {
LAB_000542eb:
    FUN_00013c0c(local_34,0,0x14,0x541fc);
    return (undefined *)0xffffffb8;
  }
  puVar1 = param_3 + 1;
  if (param_4 < (undefined *)0x4) {
    local_2c = param_3;
    local_34[0] = (uint)*(byte *)param_3;
    if (param_4 == (undefined *)0x2) {
LAB_0005432b:
      local_34[0] = local_34[0] + (uint)*(byte *)((int)param_3 + 1) * 0x100;
    }
    else if (param_4 == (undefined *)0x3) {
      local_34[0] = local_34[0] | (uint)*(byte *)((int)param_3 + 2) << 0x10;
      goto LAB_0005432b;
    }
    bVar5 = (param_4 + -1)[(int)param_3];
    if (bVar5 == 0) {
      return (undefined *)0xffffffec;
    }
    iVar8 = 0x1f;
    if (bVar5 != 0) {
      for (; bVar5 >> iVar8 == 0; iVar8 = iVar8 + -1) {
      }
    }
    iVar8 = 0x28 - (iVar8 + (int)param_4 * 8);
    local_38 = (undefined *)0x0;
  }
  else {
    local_2c = (uint *)((int)param_3 + (int)(param_4 + -4));
    local_34[0] = *(uint *)((int)param_3 + (int)(param_4 + -4));
    bVar5 = (param_4 + -1)[(int)param_3];
    if (bVar5 == 0) {
      return (undefined *)0xffffffff;
    }
    uVar9 = 0x1f;
    if (bVar5 != 0) {
      for (; bVar5 >> uVar9 == 0; uVar9 = uVar9 - 1) {
      }
    }
    iVar8 = ~uVar9 + 9;
    if ((undefined *)0xffffff88 < param_4) {
      return param_4;
    }
    local_38 = param_4 + -4;
  }
  uVar3 = *param_5;
  bVar5 = 0x1fU - (char)uVar3 & 0x1f;
  uVar12 = ((local_34[0] << ((byte)iVar8 & 0x1f)) >> 1) >> bVar5;
  uVar9 = iVar8 + (uint)uVar3;
  if (uVar9 < 0x21) {
    if ((int)local_38 < 4) {
      if (local_38 == (undefined *)0x0) {
        local_38 = (undefined *)0x0;
        goto LAB_0005450e;
      }
      puVar11 = (undefined *)(uVar9 >> 3);
      if ((uint *)((int)param_3 + ((int)local_38 - (int)(undefined *)(uVar9 >> 3))) < param_3) {
        puVar11 = local_38;
      }
      local_38 = local_38 + -(int)puVar11;
      uVar9 = uVar9 + (int)puVar11 * -8;
      local_34[0] = *(uint *)((int)param_3 + (int)local_38);
    }
    else {
      local_38 = local_38 + -(uVar9 >> 3);
      uVar9 = uVar9 & 7;
      local_34[0] = *(uint *)((int)param_3 + (int)local_38);
    }
    local_2c = (uint *)((int)param_3 + (int)local_38);
  }
LAB_0005450e:
  uVar14 = ((local_34[0] << ((byte)uVar9 & 0x1f)) >> 1) >> bVar5;
  uVar9 = uVar3 + uVar9;
  puVar11 = param_1;
  if (uVar9 < 0x21) {
    if ((int)local_38 < 4) {
      if (local_38 != (undefined *)0x0) {
        puVar10 = (undefined *)(uVar9 >> 3);
        if ((uint *)((int)param_3 + ((int)local_38 - (int)(undefined *)(uVar9 >> 3))) < param_3) {
          puVar10 = local_38;
        }
        local_2c = (uint *)((int)param_3 + ((int)local_38 - (int)puVar10));
        uVar9 = uVar9 + (int)puVar10 * -8;
        local_34[0] = *local_2c;
        if (0x20 < uVar9) goto LAB_00054ca5;
      }
    }
    else {
      local_2c = (uint *)((int)param_3 + ((int)local_38 - (uVar9 >> 3)));
      uVar9 = uVar9 & 7;
      local_34[0] = *local_2c;
    }
    puVar10 = param_1 + 2;
    puVar4 = param_1;
    while( true ) {
      if (local_2c < puVar1) {
        puVar11 = puVar4;
        if ((int)local_2c - (int)param_3 == 0) goto LAB_00054ca5;
        bVar15 = (uint *)((int)local_2c - (uVar9 >> 3)) < param_3;
        uVar7 = uVar9 >> 3;
        if (bVar15) {
          uVar7 = (int)local_2c - (int)param_3;
        }
        uVar9 = uVar9 + uVar7 * -8;
      }
      else {
        uVar7 = uVar9 >> 3;
        uVar9 = uVar9 & 7;
        bVar15 = false;
      }
      local_2c = (uint *)((int)local_2c - uVar7);
      puVar11 = puVar10 + -2;
      local_34[0] = *local_2c;
      if ((local_18 <= puVar11) || (bVar15)) goto LAB_00054ca5;
      iVar8 = uVar12 * 2;
      bVar5 = *(byte *)((int)param_5 + uVar12 * 4 + 7);
      iVar6 = uVar9 + bVar5;
      uVar12 = ((local_34[0] << ((byte)uVar9 & 0x1f)) >> (-bVar5 & 0x1f)) +
               (uint)param_5[uVar12 * 2 + 2];
      puVar10[-2] = *(undefined *)(param_5 + iVar8 + 3);
      bVar5 = *(byte *)((int)param_5 + uVar14 * 4 + 7);
      uVar9 = iVar6 + (uint)bVar5;
      uVar7 = ((local_34[0] << ((byte)iVar6 & 0x1f)) >> (-bVar5 & 0x1f)) +
              (uint)param_5[uVar14 * 2 + 2];
      puVar10[-1] = *(undefined *)(param_5 + uVar14 * 2 + 3);
      puVar11 = puVar10;
      uVar14 = uVar7;
      if (0x20 < uVar9) goto LAB_00054ca5;
      if (local_2c < puVar1) {
        if ((int)local_2c - (int)param_3 == 0) goto LAB_00054ca5;
        puVar2 = (uint *)((int)local_2c - (uVar9 >> 3));
        uVar13 = uVar9 >> 3;
        if (puVar2 < param_3) {
          uVar13 = (int)local_2c - (int)param_3;
        }
        local_2c = (uint *)((int)local_2c - uVar13);
        uVar9 = uVar9 + uVar13 * -8;
        local_34[0] = *local_2c;
        if (puVar2 < param_3) goto LAB_00054ca5;
      }
      else {
        local_2c = (uint *)((int)local_2c - (uVar9 >> 3));
        uVar9 = uVar9 & 7;
        local_34[0] = *local_2c;
      }
      iVar8 = uVar12 * 2;
      bVar5 = *(byte *)((int)param_5 + uVar12 * 4 + 7);
      iVar6 = uVar9 + bVar5;
      uVar12 = ((local_34[0] << ((byte)uVar9 & 0x1f)) >> (-bVar5 & 0x1f)) +
               (uint)param_5[uVar12 * 2 + 2];
      *puVar10 = *(undefined *)(param_5 + iVar8 + 3);
      bVar5 = *(byte *)((int)param_5 + uVar7 * 4 + 7);
      uVar9 = iVar6 + (uint)bVar5;
      uVar14 = ((local_34[0] << ((byte)iVar6 & 0x1f)) >> (-bVar5 & 0x1f)) +
               (uint)param_5[uVar7 * 2 + 2];
      puVar10[1] = *(undefined *)(param_5 + uVar7 * 2 + 3);
      if (0x20 < uVar9) break;
      puVar4 = puVar4 + 4;
      puVar10 = puVar10 + 4;
    }
    puVar11 = puVar10 + 2;
  }
LAB_00054ca5:
  do {
    if (param_1 + param_2 + -2 < puVar11) {
      return (undefined *)0xffffffba;
    }
    uVar3 = param_5[uVar12 * 2 + 2];
    bVar5 = *(byte *)((int)param_5 + uVar12 * 4 + 7);
    uVar13 = local_34[0] << ((byte)uVar9 & 0x1f);
    uVar7 = uVar9 + bVar5;
    puVar10 = puVar11 + 1;
    *puVar11 = *(undefined *)(param_5 + uVar12 * 2 + 3);
    if (0x20 < uVar7) {
      iVar8 = 2;
      goto LAB_00054e22;
    }
    if (local_2c < puVar1) {
      if ((int)local_2c - (int)param_3 != 0) {
        uVar9 = uVar7 >> 3;
        if ((uint *)((int)local_2c - (uVar7 >> 3)) < param_3) {
          uVar9 = (int)local_2c - (int)param_3;
        }
        uVar7 = uVar7 + uVar9 * -8;
        goto LAB_00054d4e;
      }
    }
    else {
      uVar9 = uVar7 >> 3;
      uVar7 = uVar7 & 7;
LAB_00054d4e:
      local_2c = (uint *)((int)local_2c - uVar9);
      local_34[0] = *local_2c;
    }
    if (param_1 + param_2 + -2 < puVar10) {
      return (undefined *)0xffffffba;
    }
    uVar12 = (uVar13 >> (-bVar5 & 0x1f)) + (uint)uVar3;
    uVar3 = param_5[uVar14 * 2 + 2];
    bVar5 = *(byte *)((int)param_5 + uVar14 * 4 + 7);
    uVar9 = uVar7 + bVar5;
    uVar7 = local_34[0] << ((byte)uVar7 & 0x1f);
    puVar11[1] = *(undefined *)(param_5 + uVar14 * 2 + 3);
    if (0x20 < uVar9) {
      puVar10 = puVar11 + 2;
      iVar8 = 3;
      uVar14 = uVar12;
LAB_00054e22:
      *puVar10 = *(undefined *)(param_5 + uVar14 * 2 + 3);
      return puVar11 + (iVar8 - (int)param_1);
    }
    puVar11 = puVar11 + 2;
    if (local_2c < puVar1) {
      if ((int)local_2c - (int)param_3 != 0) {
        uVar14 = uVar9 >> 3;
        if ((uint *)((int)local_2c - (uVar9 >> 3)) < param_3) {
          uVar14 = (int)local_2c - (int)param_3;
        }
        uVar9 = uVar9 + uVar14 * -8;
        goto LAB_00054dee;
      }
    }
    else {
      uVar14 = uVar9 >> 3;
      uVar9 = uVar9 & 7;
LAB_00054dee:
      local_2c = (uint *)((int)local_2c - uVar14);
      local_34[0] = *local_2c;
    }
    uVar14 = (uVar7 >> (-bVar5 & 0x1f)) + (uint)uVar3;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00054e50 FUN_00054e50 */

uint FUN_00054e50(undefined4 param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined4 local_218;
  uint local_214;
  undefined local_210 [512];
  
  local_218 = 0xff;
  uVar1 = FUN_00054fe0(local_210,&local_218,&local_214,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_214 <= param_6) {
      uVar2 = FUN_00053fb0(param_5,local_210,local_218,local_214);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_000541f0(param_1,param_2,param_3 + uVar1,param_4 - uVar1,param_5);
      }
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00054f00 FUN_00054f00 */

uint FUN_00054f00(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  uint uVar1;
  uint uVar2;
  undefined4 local_421c;
  uint local_4218;
  undefined local_4214 [512];
  undefined local_4014 [16388];
  
  local_421c = 0xff;
  uVar1 = FUN_00054fe0(local_4214,&local_421c,&local_4218,param_3,param_4);
  uVar2 = uVar1;
  if (uVar1 < 0xffffff89) {
    uVar2 = 0xffffffd4;
    if (local_4218 < 0xd) {
      uVar2 = FUN_00053fb0(local_4014,local_4214,local_421c,local_4218);
      if (uVar2 < 0xffffff89) {
        uVar2 = FUN_000541f0(param_1,param_2,param_3 + uVar1,param_4 - uVar1,local_4014);
      }
    }
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00054fe0 FUN_00054fe0 */

int FUN_00054fe0(int param_1,uint *param_2,uint *param_3,uint *param_4,uint param_5)

{
  uint *puVar1;
  uint *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined (*pauVar11) [16];
  undefined2 *puVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  short sVar17;
  uint uVar18;
  uint uVar19;
  bool bVar20;
  uint *local_3c;
  uint *local_34;
  uint local_30;
  
  iVar5 = -0x48;
  if (3 < param_5) {
    uVar18 = *param_4;
    uVar8 = uVar18 & 0xf;
    iVar5 = -0x2c;
    if (uVar8 + 5 < 0x10) {
      *param_3 = uVar8 + 5;
      uVar13 = 0x20 << (sbyte)uVar8;
      iVar5 = -0x14;
      if (1 < uVar13) {
        uVar6 = uVar13 | 1;
        uVar4 = *param_2;
        iVar5 = uVar8 + 6;
        uVar18 = uVar18 >> 4;
        puVar1 = (uint *)((int)param_4 + (param_5 - 7));
        puVar2 = (uint *)((int)param_4 + (param_5 - 4));
        uVar8 = 4;
        bVar20 = false;
        uVar14 = 0;
        local_34 = param_4;
        do {
          local_30 = uVar14;
          if (bVar20) {
            sVar17 = (short)uVar18;
            uVar15 = uVar14;
            while (sVar17 == -1) {
              if (local_34 < (uint *)((int)param_4 + (param_5 - 5))) {
                puVar3 = (uint *)((int)local_34 + 2);
                local_34 = (uint *)((int)local_34 + 2);
                uVar18 = *puVar3 >> ((byte)uVar8 & 0x1f);
              }
              else {
                uVar18 = uVar18 >> 0x10;
                uVar8 = uVar8 + 0x10;
              }
              uVar15 = uVar15 + 0x18;
              sVar17 = (short)uVar18;
            }
            for (; uVar9 = uVar18 & 3, uVar9 == 3; uVar18 = uVar18 >> 2) {
              uVar15 = uVar15 + 3;
              uVar8 = uVar8 + 2;
            }
            uVar19 = uVar15 + uVar9;
            if (uVar4 < uVar19) {
              return -0x30;
            }
            uVar8 = uVar8 + 2;
            if (uVar14 < uVar19) {
              uVar10 = (uVar15 + uVar9) - uVar14;
              local_3c = (uint *)uVar14;
              local_30 = uVar19;
              if (0xf < uVar10) {
                uVar19 = uVar10 & 0xfffffff0;
                pauVar11 = (undefined (*) [16])(param_1 + 0x10 + uVar14 * 2);
                local_3c = (uint *)(uVar14 + uVar19);
                uVar14 = uVar19;
                do {
                  pauVar11[-1] = ZEXT816(0);
                  *pauVar11 = ZEXT816(0);
                  pauVar11 = pauVar11 + 2;
                  uVar14 = uVar14 - 0x10;
                } while (uVar14 != 0);
                if (uVar10 == uVar19) goto LAB_000551a7;
              }
              puVar12 = (undefined2 *)(param_1 + (int)local_3c * 2);
              iVar16 = (uVar15 + uVar9) - (int)local_3c;
              do {
                *puVar12 = 0;
                puVar12 = puVar12 + 1;
                iVar16 = iVar16 + -1;
              } while (iVar16 != 0);
            }
LAB_000551a7:
            iVar16 = (int)uVar8 >> 3;
            local_3c = (uint *)((int)local_34 + iVar16);
            if ((puVar1 < local_34) && (puVar2 < local_3c)) {
              uVar18 = uVar18 >> 2;
              local_3c = local_34;
            }
            else {
              uVar8 = uVar8 & 7;
              uVar18 = *(uint *)((int)local_34 + iVar16) >> (sbyte)uVar8;
            }
          }
          else {
            local_3c = local_34;
          }
          uVar14 = uVar13 * 2 - 1;
          uVar15 = uVar14 - uVar6;
          uVar9 = uVar13 - 1 & uVar18;
          if (uVar9 < uVar15) {
            iVar16 = iVar5 + -1;
          }
          else {
            uVar18 = uVar18 & uVar14;
            if ((int)uVar18 < (int)uVar13) {
              uVar15 = 0;
            }
            uVar9 = uVar18 - uVar15;
            iVar16 = iVar5;
          }
          uVar8 = iVar16 + uVar8;
          iVar16 = uVar9 - 1;
          iVar7 = 1 - uVar9;
          if (0 < (int)uVar9) {
            iVar7 = iVar16;
          }
          uVar6 = uVar6 - iVar7;
          *(short *)(param_1 + local_30 * 2) = (short)iVar16;
          bVar20 = iVar16 == 0;
          for (; (int)uVar6 < (int)uVar13; uVar13 = (int)uVar13 >> 1) {
            iVar5 = iVar5 + -1;
          }
          local_34 = (uint *)(((int)uVar8 >> 3) + (int)local_3c);
          if ((puVar1 < local_3c) && (puVar2 < local_34)) {
            uVar8 = uVar8 + ((int)puVar2 - (int)local_3c) * -8;
            local_34 = puVar2;
          }
          else {
            uVar8 = uVar8 & 7;
          }
          uVar18 = *local_34 >> ((byte)uVar8 & 0x1f);
        } while ((1 < (int)uVar6) && (uVar14 = local_30 + 1, uVar14 <= uVar4));
        if (uVar6 == 1) {
          iVar5 = -0x14;
          if ((int)uVar8 < 0x21) {
            *param_2 = local_30;
            iVar5 = (int)local_34 + (((int)(uVar8 + 7) >> 3) - (int)param_4);
          }
        }
        else {
          iVar5 = -0x14;
        }
      }
    }
  }
  return iVar5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00055320 FUN_00055320 */

uint FUN_00055320(byte *param_1,uint param_2,int param_3,int *param_4,int *param_5,byte *param_6,
                 uint param_7)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined local_114 [260];
  
  uVar9 = 0x5532f;
  if (param_7 == 0) {
    return 0xffffffb8;
  }
  uVar5 = (uint)*param_6;
  if ((char)*param_6 < '\0') {
    uVar8 = uVar5 - 0x7e >> 1;
    if (param_7 <= uVar8) {
      return 0xffffffb8;
    }
    uVar2 = uVar5 - 0x7f;
    if (param_2 <= uVar2) {
      return 0xffffffec;
    }
    if (uVar2 == 0) {
      FUN_00013c0c(param_3,0,0x34,0x5532f);
      return 0xffffffec;
    }
    uVar5 = 0;
    do {
      param_1[uVar5] = param_6[(uVar5 >> 1) + 1] >> 4;
      param_1[uVar5 + 1] = param_6[(uVar5 >> 1) + 1] & 0xf;
      uVar5 = uVar5 + 2;
    } while (uVar5 < uVar2);
  }
  else {
    if (param_7 <= uVar5) {
      return 0xffffffb8;
    }
    uVar2 = FUN_00054e50(param_1,param_2 - 1,param_6 + 1,uVar5,local_114,6);
    uVar8 = uVar5;
    if (0xffffff88 < uVar2) {
      return uVar2;
    }
  }
  FUN_00013c0c(param_3,0,0x34,uVar9);
  uVar5 = 0xffffffec;
  if (uVar2 != 0) {
    uVar6 = 0;
    uVar3 = uVar2;
    pbVar7 = param_1;
    do {
      if (0xb < *pbVar7) {
        return 0xffffffec;
      }
      piVar1 = (int *)(param_3 + (uint)*pbVar7 * 4);
      *piVar1 = *piVar1 + 1;
      uVar6 = uVar6 + ((1 << (*pbVar7 & 0x1f)) >> 1);
      pbVar7 = pbVar7 + 1;
      uVar3 = uVar3 - 1;
    } while (uVar3 != 0);
    if ((uVar6 != 0) && (uVar6 < 0x1000)) {
      uVar3 = 0x1f;
      if (uVar6 != 0) {
        for (; uVar6 >> uVar3 == 0; uVar3 = uVar3 - 1) {
        }
      }
      iVar4 = (uVar3 ^ 0xffffffe0) + 0x21;
      *param_5 = iVar4;
      uVar6 = (1 << ((byte)iVar4 & 0x1f)) - uVar6;
      iVar4 = 0x1f;
      if (uVar6 != 0) {
        for (; uVar6 >> iVar4 == 0; iVar4 = iVar4 + -1) {
        }
      }
      if (1 << ((byte)iVar4 & 0x1f) == uVar6) {
        param_1[uVar2] = (byte)iVar4 + 1;
        piVar1 = (int *)(param_3 + 4 + iVar4 * 4);
        *piVar1 = *piVar1 + 1;
        if ((1 < *(uint *)(param_3 + 4)) && ((*(uint *)(param_3 + 4) & 1) == 0)) {
          *param_4 = uVar2 + 1;
          uVar5 = uVar8 + 1;
        }
      }
    }
  }
  return uVar5;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000554f0 FUN_000554f0 */

uint FUN_000554f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  byte local_2c;
  undefined local_2b;
  undefined local_2a;
  uint local_20;
  uint local_1c [3];
  
  local_20 = 0;
  local_1c[0] = 0;
  uVar8 = 0xffffffd4;
  if (((0x13f < param_5) &&
      (uVar3 = FUN_00055320(param_4 + 0x40,0x100,param_4,local_1c,&local_20,param_2,param_3,0x554fc)
      , uVar8 = uVar3, uVar3 < 0xffffff89)) &&
     (FUN_00013c06(&local_2c,param_1,4), uVar8 = 0xffffffd4, local_20 <= local_2c + 1)) {
    local_2b = 0;
    local_2a = (undefined)local_20;
    FUN_00013c06(param_1,&local_2c,4);
    if (1 < local_20 + 1) {
      uVar8 = 1;
      iVar9 = 0;
      do {
        iVar2 = *(int *)(param_4 + uVar8 * 4);
        cVar6 = (char)uVar8;
        *(int *)(param_4 + uVar8 * 4) = iVar9;
        uVar8 = uVar8 + 1;
        iVar9 = (iVar2 << (cVar6 - 1U & 0x1f)) + iVar9;
      } while (uVar8 < local_20 + 1);
    }
    uVar8 = uVar3;
    if (local_1c[0] != 0) {
      uVar4 = 0;
      do {
        bVar1 = *(byte *)(param_4 + 0x40 + uVar4);
        uVar7 = (uint)bVar1;
        iVar9 = (1 << (bVar1 & 0x1f)) >> 1;
        uVar5 = *(uint *)(param_4 + uVar7 * 4);
        uVar8 = uVar5 + iVar9;
        if (uVar5 < uVar8) {
          do {
            *(char *)(param_1 + 4 + uVar5 * 2) = (char)uVar4;
            *(byte *)(param_1 + 5 + uVar5 * 2) = ((char)local_20 + '\x01') - bVar1;
            uVar5 = uVar5 + 1;
            uVar8 = *(int *)(param_4 + uVar7 * 4) + iVar9;
          } while (uVar5 < uVar8);
        }
        *(uint *)(param_4 + uVar7 * 4) = uVar8;
        uVar4 = uVar4 + 1;
        uVar8 = uVar3;
      } while (uVar4 < local_1c[0]);
    }
  }
  return uVar8;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00055730 FUN_00055730 */

uint __regparm3
FUN_00055730(undefined4 param_1_00,uint param_2_00,undefined *param_3_00,uint *param_1,uint param_2,
            int param_3)

{
  uint *puVar1;
  undefined *puVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  bool bVar6;
  uint local_44;
  uint local_40;
  uint *local_3c;
  undefined *local_2c;
  undefined local_1c [2];
  char local_1a;
  
  local_2c = param_3_00;
  FUN_00013c06(local_1c,param_3,4,0x55742);
  if (param_2 == 0) {
    FUN_00013c0c(&local_44,0,0x14);
    return 0xffffffb8;
  }
  puVar1 = param_1 + 1;
  if (3 < param_2) {
    local_3c = (uint *)((int)param_1 + (param_2 - 4));
    local_44 = *(uint *)((int)param_1 + (param_2 - 4));
    bVar3 = *(byte *)((int)param_1 + (param_2 - 1));
    if (bVar3 == 0) {
      return 0xffffffff;
    }
    uVar5 = 0x1f;
    if (bVar3 != 0) {
      for (; bVar3 >> uVar5 == 0; uVar5 = uVar5 - 1) {
      }
    }
    local_40 = ~uVar5 + 9;
    if (0xffffff88 < param_2) {
      return param_2;
    }
    goto LAB_0005582b;
  }
  local_3c = param_1;
  local_44 = (uint)*(byte *)param_1;
  if (param_2 == 2) {
LAB_000557fa:
    local_44 = (uint)*(byte *)((int)param_1 + 1) * 0x100 + local_44;
  }
  else if (param_2 == 3) {
    local_44 = local_44 | (uint)*(byte *)((int)param_1 + 2) << 0x10;
    goto LAB_000557fa;
  }
  bVar3 = *(byte *)((param_2 - 1) + (int)param_1);
  if (bVar3 == 0) {
    return 0xffffffec;
  }
  iVar4 = 0x1f;
  if (bVar3 != 0) {
    for (; bVar3 >> iVar4 == 0; iVar4 = iVar4 + -1) {
    }
  }
  local_40 = 0x28 - (iVar4 + param_2 * 8);
LAB_0005582b:
  puVar2 = local_2c + param_2_00;
  bVar3 = -local_1a & 0x1f;
  if (0x20 < local_40) {
joined_r0x0005597f:
    if (local_2c < puVar2) {
      uVar5 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar3;
      local_40 = *(byte *)(param_3 + 5 + uVar5 * 2) + local_40;
      *local_2c = *(undefined *)(param_3 + 4 + uVar5 * 2);
      while (local_2c = local_2c + 1, local_2c != puVar2) {
        uVar5 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar3;
        local_40 = *(byte *)(param_3 + 5 + uVar5 * 2) + local_40;
        *local_2c = *(undefined *)(param_3 + 4 + uVar5 * 2);
      }
    }
    uVar5 = 0xffffffec;
    if ((local_40 ^ 0x20 | (uint)local_3c ^ (uint)param_1) == 0) {
      uVar5 = param_2_00;
    }
    return uVar5;
  }
  if (puVar1 <= local_3c) goto LAB_000558b0;
  while ((int)local_3c - (int)param_1 != 0) {
    bVar6 = (uint *)((int)local_3c - (local_40 >> 3)) < param_1;
    uVar5 = local_40 >> 3;
    if (bVar6) {
      uVar5 = (int)local_3c - (int)param_1;
    }
    local_3c = (uint *)((int)local_3c - uVar5);
    local_40 = local_40 + uVar5 * -8;
    while( true ) {
      local_44 = *local_3c;
      if (puVar2 + -4 < local_2c) goto joined_r0x00055972;
      if (bVar6) goto joined_r0x00055972;
      uVar5 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar3;
      iVar4 = *(byte *)(param_3 + 5 + uVar5 * 2) + local_40;
      *local_2c = *(undefined *)(param_3 + 4 + uVar5 * 2);
      uVar5 = (local_44 << ((byte)iVar4 & 0x1f)) >> bVar3;
      local_40 = (uint)*(byte *)(param_3 + 5 + uVar5 * 2) + iVar4;
      local_2c[1] = *(undefined *)(param_3 + 4 + uVar5 * 2);
      local_2c = local_2c + 2;
      if (0x20 < local_40) goto joined_r0x0005597f;
      if (local_3c < puVar1) break;
LAB_000558b0:
      local_3c = (uint *)((int)local_3c - (local_40 >> 3));
      local_40 = local_40 & 7;
      bVar6 = false;
    }
  }
  do {
    if (local_3c < puVar1) {
      if ((int)local_3c - (int)param_1 == 0) goto joined_r0x0005597f;
      bVar6 = (uint *)((int)local_3c - (local_40 >> 3)) < param_1;
      uVar5 = local_40 >> 3;
      if (bVar6) {
        uVar5 = (int)local_3c - (int)param_1;
      }
      local_40 = local_40 + uVar5 * -8;
    }
    else {
      uVar5 = local_40 >> 3;
      local_40 = local_40 & 7;
      bVar6 = false;
    }
    local_3c = (uint *)((int)local_3c - uVar5);
    local_44 = *local_3c;
    if ((puVar2 <= local_2c) || (bVar6)) goto joined_r0x0005597f;
    uVar5 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar3;
    local_40 = *(byte *)(param_3 + 5 + uVar5 * 2) + local_40;
    *local_2c = *(undefined *)(param_3 + 4 + uVar5 * 2);
    local_2c = local_2c + 1;
joined_r0x00055972:
    if (0x20 < local_40) goto joined_r0x0005597f;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00055ad0 FUN_00055ad0 */

uint FUN_00055ad0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  
  uVar3 = 0x55adc;
  uVar1 = FUN_000554f0(param_1,param_4,param_5,param_6,param_7);
  uVar2 = uVar1;
  if ((uVar1 < 0xffffff89) && (uVar2 = 0xffffffb8, uVar1 < param_5)) {
    uVar2 = FUN_00055730(param_4 + uVar1,param_5 - uVar1,param_1,uVar3);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00055ce0 FUN_00055ce0 */

/* WARNING: Type propagation algorithm not settling */

uint __regparm3
FUN_00055ce0(undefined4 param_1_00,uint param_2_00,undefined *param_3_00,ushort *param_1,
            uint param_2,int param_3)

{
  undefined *puVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  byte bVar8;
  uint uVar9;
  undefined *puVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  undefined *puVar17;
  undefined *puVar18;
  uint uVar19;
  uint uVar20;
  uint *puVar21;
  int iVar22;
  bool bVar23;
  undefined *puStack_b4;
  undefined *local_b0;
  undefined *local_a4;
  uint uStack_98;
  uint uStack_94;
  uint uStack_8c;
  uint uStack_88;
  uint *puStack_84;
  uint uStack_74;
  uint uStack_70;
  uint *puStack_6c;
  uint *puStack_68;
  uint *puStack_64;
  uint uStack_5c;
  uint uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  uint local_44;
  uint local_40;
  uint *local_3c;
  uint *local_38;
  uint *local_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_20;
  uint uStack_1c;
  uint local_18;
  undefined local_14 [2];
  char local_12;
  
  if (param_2 < 10) {
    return 0xffffffec;
  }
  uVar2 = *param_1;
  uVar19 = (uint)uVar2;
  uVar3 = param_1[1];
  uVar9 = (uint)uVar3;
  uVar4 = param_1[2];
  uVar6 = (uint)uVar4;
  uVar16 = uVar19 + 6 + uVar9 + uVar6;
  local_18 = param_2_00;
  FUN_00013c06(local_14,param_3,4,0x55cef);
  uVar20 = param_2 - uVar16;
  if (param_2 < uVar16) {
    return 0xffffffec;
  }
  if (uVar2 == 0) {
    puVar7 = &local_44;
    goto LAB_000560d0;
  }
  local_38 = (uint *)(param_1 + 3);
  local_34 = (uint *)(param_1 + 5);
  if (uVar2 < 4) {
    local_44 = (uint)*(byte *)local_38;
    if (uVar2 == 2) {
LAB_00055e27:
      local_44 = local_44 + (uint)*(byte *)((int)param_1 + 7) * 0x100;
    }
    else if (uVar2 == 3) {
      local_44 = local_44 | (uint)*(byte *)(param_1 + 4) << 0x10;
      goto LAB_00055e27;
    }
    bVar8 = *(byte *)((uVar19 - 1) + (int)local_38);
    if (bVar8 == 0) {
      return 0xffffffec;
    }
    iVar22 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> iVar22 == 0; iVar22 = iVar22 + -1) {
      }
    }
    local_40 = 0x28 - (iVar22 + uVar19 * 8);
    uVar16 = 6;
    local_3c = local_38;
  }
  else {
    local_44 = *(uint *)((int)param_1 + uVar19 + 2);
    bVar8 = *(byte *)((int)param_1 + uVar19 + 5);
    if (bVar8 == 0) {
      return 0xffffffff;
    }
    uVar16 = uVar19 + 2;
    uVar5 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> uVar5 == 0; uVar5 = uVar5 - 1) {
      }
    }
    local_40 = ~uVar5 + 9;
    local_3c = (uint *)((int)param_1 + uVar19 + 2);
  }
  if (uVar3 == 0) {
    puVar7 = &uStack_5c;
    goto LAB_000560d0;
  }
  puStack_50 = (uint *)((int)param_1 + uVar19 + 6);
  puStack_4c = puStack_50 + 1;
  if (uVar3 < 4) {
    uStack_5c = (uint)*(byte *)puStack_50;
    if (uVar3 == 2) {
LAB_00055ef6:
      uStack_5c = (uint)*(byte *)((int)puStack_50 + 1) * 0x100 + uStack_5c;
    }
    else if (uVar3 == 3) {
      uStack_5c = uStack_5c | (uint)*(byte *)((int)puStack_50 + 2) << 0x10;
      goto LAB_00055ef6;
    }
    bVar8 = *(byte *)((uVar9 - 1) + (int)puStack_50);
    if (bVar8 == 0) {
      return 0xffffffec;
    }
    iVar22 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> iVar22 == 0; iVar22 = iVar22 + -1) {
      }
    }
    uStack_58 = 0x28 - (iVar22 + uVar9 * 8);
    uStack_98 = 0;
    puStack_54 = puStack_50;
  }
  else {
    uStack_5c = *(uint *)((int)puStack_50 + (uVar9 - 4));
    bVar8 = *(byte *)((uVar9 - 1) + (int)puStack_50);
    if (bVar8 == 0) {
      return 0xffffffff;
    }
    uStack_98 = uVar9 - 4;
    uVar19 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> uVar19 == 0; uVar19 = uVar19 - 1) {
      }
    }
    uStack_58 = ~uVar19 + 9;
    puStack_54 = (uint *)((int)puStack_50 + (uVar9 - 4));
  }
  uStack_20 = uVar16;
  if (uVar4 == 0) {
    puVar7 = &uStack_74;
    goto LAB_000560d0;
  }
  puStack_68 = (uint *)(uVar9 + (int)puStack_50);
  puStack_64 = puStack_68 + 1;
  if (uVar4 < 4) {
    uStack_74 = (uint)*(byte *)puStack_68;
    if (uVar4 == 2) {
LAB_0005602a:
      uStack_74 = (uint)*(byte *)((int)puStack_68 + 1) * 0x100 + uStack_74;
    }
    else if (uVar4 == 3) {
      uStack_74 = uStack_74 | (uint)*(byte *)((int)puStack_68 + 2) << 0x10;
      goto LAB_0005602a;
    }
    bVar8 = *(byte *)((uVar6 - 1) + (int)puStack_68);
    if (bVar8 == 0) {
      return 0xffffffec;
    }
    iVar22 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> iVar22 == 0; iVar22 = iVar22 + -1) {
      }
    }
    uStack_30 = 0x28 - (iVar22 + uVar6 * 8);
    uStack_2c = 0;
    puStack_6c = puStack_68;
  }
  else {
    uStack_74 = *(uint *)((int)puStack_68 + (uVar6 - 4));
    bVar8 = *(byte *)((uVar6 - 1) + (int)puStack_68);
    if (bVar8 == 0) {
      return 0xffffffff;
    }
    uStack_2c = uVar6 - 4;
    uVar9 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> uVar9 == 0; uVar9 = uVar9 - 1) {
      }
    }
    uStack_30 = ~uVar9 + 9;
    puStack_6c = (uint *)((int)puStack_68 + (uVar6 - 4));
  }
  uStack_70 = uStack_30;
  if (uVar20 == 0) {
    puVar7 = &uStack_8c;
LAB_000560d0:
    FUN_00013c0c(puVar7,0,0x14);
    return 0xffffffb8;
  }
  puVar21 = (uint *)(uVar6 + (int)puStack_68);
  puVar7 = puVar21 + 1;
  if (3 < uVar20) {
    uStack_8c = *(uint *)((int)puVar21 + (uVar20 - 4));
    bVar8 = *(byte *)((uVar20 - 1) + (int)puVar21);
    if (bVar8 == 0) {
      return 0xffffffff;
    }
    uVar6 = 0x1f;
    if (bVar8 != 0) {
      for (; bVar8 >> uVar6 == 0; uVar6 = uVar6 - 1) {
      }
    }
    uStack_1c = ~uVar6 + 9;
    if (0xffffff88 < uVar20) {
      return uVar20;
    }
    uVar6 = uVar20 - 4;
    puStack_84 = (uint *)((int)puVar21 + (uVar20 - 4));
    goto LAB_00056147;
  }
  uStack_8c = (uint)*(byte *)puVar21;
  if (uVar20 == 2) {
LAB_0005610f:
    uStack_8c = (uint)*(byte *)((int)puVar21 + 1) * 0x100 + uStack_8c;
  }
  else if (uVar20 == 3) {
    uStack_8c = uStack_8c | (uint)*(byte *)((int)puVar21 + 2) << 0x10;
    goto LAB_0005610f;
  }
  bVar8 = *(byte *)((uVar20 - 1) + (int)puVar21);
  if (bVar8 == 0) {
    return 0xffffffec;
  }
  iVar22 = 0x1f;
  if (bVar8 != 0) {
    for (; bVar8 >> iVar22 == 0; iVar22 = iVar22 + -1) {
    }
  }
  uStack_1c = 0x28 - (iVar22 + uVar20 * 8);
  uVar6 = 0;
  puStack_84 = puVar21;
LAB_00056147:
  uStack_28 = 3;
  if (local_40 < 0x21) {
    if (uVar16 < 10) {
      if (uVar16 == 6) {
        uVar9 = 2 - (local_40 < 0x20);
      }
      else {
        iVar22 = uVar16 - (local_40 >> 3);
        uVar9 = (uint)(iVar22 < 6);
        uVar19 = uVar16 - 6;
        if (5 < iVar22) {
          uVar19 = local_40 >> 3;
        }
        local_3c = (uint *)((int)param_1 + (uVar16 - uVar19));
        local_40 = local_40 + uVar19 * -8;
        local_44 = *local_3c;
      }
    }
    else {
      local_3c = (uint *)((int)param_1 + (uVar16 - (local_40 >> 3)));
      local_40 = local_40 & 7;
      local_44 = *local_3c;
      uVar9 = 0;
    }
  }
  else {
    uVar9 = 3;
  }
  uVar16 = local_18 + 3 >> 2;
  if (uStack_58 < 0x21) {
    if ((int)uStack_98 < 4) {
      if (uStack_98 == 0) {
        uStack_28 = 2 - (uStack_58 < 0x20);
      }
      else {
        bVar23 = (uint *)((int)puStack_50 + (uStack_98 - (uStack_58 >> 3))) < puStack_50;
        uStack_28 = (uint)bVar23;
        uVar19 = uStack_58 >> 3;
        if (bVar23) {
          uVar19 = uStack_98;
        }
        puStack_54 = (uint *)((int)puStack_50 + (uStack_98 - uVar19));
        uStack_58 = uStack_58 + uVar19 * -8;
        uStack_5c = *puStack_54;
      }
    }
    else {
      puStack_54 = (uint *)((int)puStack_50 + (uStack_98 - (uStack_58 >> 3)));
      uStack_58 = uStack_58 & 7;
      uStack_5c = *puStack_54;
      uStack_28 = 0;
    }
  }
  puVar1 = param_3_00 + uVar16;
  puStack_b4 = (undefined *)0x3;
  uVar19 = 3;
  if (uStack_30 < 0x21) {
    if ((int)uStack_2c < 4) {
      if (uStack_2c == 0) {
        uVar19 = 2 - (uStack_30 < 0x20);
      }
      else {
        bVar23 = (uint *)((int)puStack_68 + (uStack_2c - (uStack_30 >> 3))) < puStack_68;
        uVar19 = (uint)bVar23;
        uVar20 = uStack_30 >> 3;
        if (bVar23) {
          uVar20 = uStack_2c;
        }
        puStack_6c = (uint *)((int)puStack_68 + (uStack_2c - uVar20));
        uStack_70 = uStack_30 + uVar20 * -8;
        uStack_74 = *puStack_6c;
      }
    }
    else {
      puStack_6c = (uint *)((int)puStack_68 + (uStack_2c - (uStack_30 >> 3)));
      uStack_70 = uStack_30 & 7;
      uStack_74 = *puStack_6c;
      uVar19 = 0;
    }
  }
  puVar17 = puVar1 + uVar16;
  uStack_88 = uStack_1c;
  if (uStack_1c < 0x21) {
    if ((int)uVar6 < 4) {
      if (uVar6 == 0) {
        puStack_b4 = (undefined *)(2 - (uStack_1c < 0x20));
      }
      else {
        bVar23 = (uint *)((int)puVar21 + (uVar6 - (uStack_1c >> 3))) < puVar21;
        puStack_b4 = (undefined *)(uint)bVar23;
        uVar20 = uStack_1c >> 3;
        if (bVar23) {
          uVar20 = uVar6;
        }
        puStack_84 = (uint *)((int)puVar21 + (uVar6 - uVar20));
        uStack_88 = uStack_1c + uVar20 * -8;
        uStack_8c = *puStack_84;
      }
    }
    else {
      puStack_84 = (uint *)((int)puVar21 + (uVar6 - (uStack_1c >> 3)));
      uStack_88 = uStack_1c & 7;
      uStack_8c = *puStack_84;
      puStack_b4 = (undefined *)0x0;
    }
  }
  puVar10 = param_3_00 + local_18;
  iVar22 = param_3 + 4;
  puVar18 = puVar17 + uVar16;
  uVar6 = uStack_28 | uVar9 | uVar19 | (uint)puStack_b4;
  local_a4 = puVar17;
  puStack_b4 = puVar18;
  local_b0 = puVar1;
  if ((uVar6 == 0) && (puVar18 < puVar10 + -7)) {
    bVar8 = -local_12 & 0x1f;
    iVar15 = uVar16 * 3;
    uStack_94 = local_40;
    while( true ) {
      uVar6 = (local_44 << ((byte)uStack_94 & 0x1f)) >> bVar8;
      iVar11 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_94;
      *param_3_00 = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_5c << ((byte)uStack_58 & 0x1f)) >> bVar8;
      iVar12 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_58;
      param_3_00[uVar16] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar8;
      iVar13 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_70;
      param_3_00[uVar16 * 2] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar8;
      iVar14 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_88;
      param_3_00[iVar15] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (local_44 << ((byte)iVar11 & 0x1f)) >> bVar8;
      local_40 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar11;
      param_3_00[1] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_5c << ((byte)iVar12 & 0x1f)) >> bVar8;
      uStack_58 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar12;
      param_3_00[uVar16 + 1] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_74 << ((byte)iVar13 & 0x1f)) >> bVar8;
      uStack_70 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar13;
      param_3_00[uVar16 * 2 + 1] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_8c << ((byte)iVar14 & 0x1f)) >> bVar8;
      uStack_88 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar14;
      param_3_00[iVar15 + 1] = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = 3;
      if (local_40 < 0x21) {
        if (local_3c < local_34) {
          if ((int)local_3c - (int)local_38 == 0) {
            local_b0 = (undefined *)(2 - (local_40 < 0x20));
          }
          else {
            bVar23 = (uint *)((int)local_3c - (local_40 >> 3)) < local_38;
            local_b0 = (undefined *)(uint)bVar23;
            uVar9 = local_40 >> 3;
            if (bVar23) {
              uVar9 = (int)local_3c - (int)local_38;
            }
            local_3c = (uint *)((int)local_3c - uVar9);
            local_40 = local_40 + uVar9 * -8;
            local_44 = *local_3c;
          }
        }
        else {
          local_3c = (uint *)((int)local_3c - (local_40 >> 3));
          local_40 = local_40 & 7;
          local_44 = *local_3c;
          local_b0 = (undefined *)0x0;
        }
      }
      else {
        local_b0 = (undefined *)0x3;
      }
      if (uStack_58 < 0x21) {
        if (puStack_54 < puStack_4c) {
          if ((int)puStack_54 - (int)puStack_50 == 0) {
            uVar6 = 2 - (uStack_58 < 0x20);
          }
          else {
            bVar23 = (uint *)((int)puStack_54 - (uStack_58 >> 3)) < puStack_50;
            uVar6 = (uint)bVar23;
            uVar9 = uStack_58 >> 3;
            if (bVar23) {
              uVar9 = (int)puStack_54 - (int)puStack_50;
            }
            puStack_54 = (uint *)((int)puStack_54 - uVar9);
            uStack_58 = uStack_58 + uVar9 * -8;
            uStack_5c = *puStack_54;
          }
        }
        else {
          puStack_54 = (uint *)((int)puStack_54 - (uStack_58 >> 3));
          uStack_58 = uStack_58 & 7;
          uStack_5c = *puStack_54;
          uVar6 = 0;
        }
      }
      uVar9 = 3;
      if (uStack_70 < 0x21) {
        if (puStack_6c < puStack_64) {
          if ((int)puStack_6c - (int)puStack_68 == 0) {
            uVar9 = 2 - (uStack_70 < 0x20);
          }
          else {
            bVar23 = (uint *)((int)puStack_6c - (uStack_70 >> 3)) < puStack_68;
            uVar9 = (uint)bVar23;
            uVar19 = uStack_70 >> 3;
            if (bVar23) {
              uVar19 = (int)puStack_6c - (int)puStack_68;
            }
            puStack_6c = (uint *)((int)puStack_6c - uVar19);
            uStack_70 = uStack_70 + uVar19 * -8;
            uStack_74 = *puStack_6c;
          }
        }
        else {
          puStack_6c = (uint *)((int)puStack_6c - (uStack_70 >> 3));
          uStack_70 = uStack_70 & 7;
          uStack_74 = *puStack_6c;
          uVar9 = 0;
        }
      }
      uVar9 = uVar6 | (uint)local_b0 | uVar9;
      if (uStack_88 < 0x21) {
        if (puStack_84 < puVar7) {
          if ((int)puStack_84 - (int)puVar21 == 0) {
            uVar9 = uVar9 | 2 - (uStack_88 < 0x20);
          }
          else {
            bVar23 = (uint *)((int)puStack_84 - (uStack_88 >> 3)) < puVar21;
            uVar6 = uStack_88 >> 3;
            if (bVar23) {
              uVar6 = (int)puStack_84 - (int)puVar21;
            }
            puStack_84 = (uint *)((int)puStack_84 - uVar6);
            uStack_88 = uStack_88 + uVar6 * -8;
            uStack_8c = *puStack_84;
            uVar9 = uVar9 | bVar23;
          }
        }
        else {
          puStack_84 = (uint *)((int)puStack_84 - (uStack_88 >> 3));
          uStack_88 = uStack_88 & 7;
          uStack_8c = *puStack_84;
        }
      }
      else {
        uVar9 = uVar9 | 3;
      }
      if ((uVar9 != 0) || (puVar10 + -7 <= param_3_00 + iVar15 + 2)) break;
      param_3_00 = param_3_00 + 2;
      uStack_94 = local_40;
    }
    local_b0 = param_3_00 + uVar16 + 2;
    local_a4 = param_3_00 + uVar16 * 2 + 2;
    puStack_b4 = param_3_00 + iVar15 + 2;
    param_3_00 = param_3_00 + 2;
  }
  if (puVar18 < local_a4) {
    return 0xffffffec;
  }
  if (puVar17 < local_b0) {
    return 0xffffffec;
  }
  if (puVar1 < param_3_00) {
    return 0xffffffec;
  }
  bVar8 = -local_12 & 0x1f;
  if (local_40 < 0x21) {
    do {
      if (local_3c < local_34) {
        if ((int)local_3c - (int)local_38 == 0) goto LAB_00056a6c;
        bVar23 = (uint *)((int)local_3c - (local_40 >> 3)) < local_38;
        uVar6 = local_40 >> 3;
        if (bVar23) {
          uVar6 = (int)local_3c - (int)local_38;
        }
        local_40 = local_40 + uVar6 * -8;
      }
      else {
        uVar6 = local_40 >> 3;
        local_40 = local_40 & 7;
        bVar23 = false;
      }
      local_3c = (uint *)((int)local_3c - uVar6);
      local_44 = *local_3c;
      if ((puVar1 + -4 < param_3_00) || (bVar23)) goto LAB_00056a63;
      uVar6 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar8;
      iVar15 = *(byte *)(param_3 + 5 + uVar6 * 2) + local_40;
      *param_3_00 = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (local_44 << ((byte)iVar15 & 0x1f)) >> bVar8;
      local_40 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar15;
      param_3_00[1] = *(undefined *)(iVar22 + uVar6 * 2);
      param_3_00 = param_3_00 + 2;
    } while (local_40 < 0x21);
  }
joined_r0x00056b1d:
  if (param_3_00 < puVar1) {
    uVar6 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar8;
    local_40 = *(byte *)(param_3 + 5 + uVar6 * 2) + local_40;
    *param_3_00 = *(undefined *)(iVar22 + uVar6 * 2);
    while (param_3_00 = param_3_00 + 1, param_3_00 != puVar1) {
      uVar6 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar8;
      local_40 = *(byte *)(param_3 + 5 + uVar6 * 2) + local_40;
      *param_3_00 = *(undefined *)(iVar22 + uVar6 * 2);
    }
  }
  if (uStack_58 < 0x21) {
    do {
      if (puStack_54 < puStack_4c) {
        if ((int)puStack_54 - (int)puStack_50 == 0) goto LAB_00056c7b;
        bVar23 = (uint *)((int)puStack_54 - (uStack_58 >> 3)) < puStack_50;
        uVar6 = uStack_58 >> 3;
        if (bVar23) {
          uVar6 = (int)puStack_54 - (int)puStack_50;
        }
        uStack_58 = uStack_58 + uVar6 * -8;
      }
      else {
        uVar6 = uStack_58 >> 3;
        uStack_58 = uStack_58 & 7;
        bVar23 = false;
      }
      puStack_54 = (uint *)((int)puStack_54 - uVar6);
      uStack_5c = *puStack_54;
      if ((puVar17 + -4 < local_b0) || (bVar23)) goto joined_r0x00056c75;
      uVar6 = (uStack_5c << ((byte)uStack_58 & 0x1f)) >> bVar8;
      iVar15 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_58;
      *local_b0 = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_5c << ((byte)iVar15 & 0x1f)) >> bVar8;
      uStack_58 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar15;
      local_b0[1] = *(undefined *)(iVar22 + uVar6 * 2);
      local_b0 = local_b0 + 2;
    } while (uStack_58 < 0x21);
  }
joined_r0x000571fa:
  if (local_b0 < puVar17) {
    uVar6 = (uStack_5c << ((byte)uStack_58 & 0x1f)) >> bVar8;
    uStack_58 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_58;
    *local_b0 = *(undefined *)(iVar22 + uVar6 * 2);
    while (local_b0 = local_b0 + 1, local_b0 != puVar17) {
      uVar6 = (uStack_5c << ((byte)uStack_58 & 0x1f)) >> bVar8;
      uStack_58 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_58;
      *local_b0 = *(undefined *)(iVar22 + uVar6 * 2);
    }
  }
  if (uStack_70 < 0x21) {
    do {
      if (puStack_6c < puStack_64) {
        if ((int)puStack_6c - (int)puStack_68 == 0) goto LAB_00056e83;
        bVar23 = (uint *)((int)puStack_6c - (uStack_70 >> 3)) < puStack_68;
        uVar6 = uStack_70 >> 3;
        if (bVar23) {
          uVar6 = (int)puStack_6c - (int)puStack_68;
        }
        uStack_70 = uStack_70 + uVar6 * -8;
      }
      else {
        uVar6 = uStack_70 >> 3;
        uStack_70 = uStack_70 & 7;
        bVar23 = false;
      }
      puStack_6c = (uint *)((int)puStack_6c - uVar6);
      uStack_74 = *puStack_6c;
      if ((puVar18 + -4 < local_a4) || (bVar23)) {
        if (uStack_70 < 0x21) goto LAB_00056e83;
        break;
      }
      uVar6 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar8;
      iVar15 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_70;
      *local_a4 = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_74 << ((byte)iVar15 & 0x1f)) >> bVar8;
      uStack_70 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar15;
      local_a4[1] = *(undefined *)(iVar22 + uVar6 * 2);
      local_a4 = local_a4 + 2;
    } while (uStack_70 < 0x21);
  }
joined_r0x0005720f:
  if (local_a4 < puVar18) {
    uVar6 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar8;
    uStack_70 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_70;
    *local_a4 = *(undefined *)(iVar22 + uVar6 * 2);
    while (local_a4 = local_a4 + 1, local_a4 != puVar18) {
      uVar6 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar8;
      uStack_70 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_70;
      *local_a4 = *(undefined *)(iVar22 + uVar6 * 2);
    }
  }
  if (uStack_88 < 0x21) {
    do {
      if (puStack_84 < puVar7) {
        if ((int)puStack_84 - (int)puVar21 == 0) goto LAB_00057071;
        bVar23 = (uint *)((int)puStack_84 - (uStack_88 >> 3)) < puVar21;
        uVar6 = uStack_88 >> 3;
        if (bVar23) {
          uVar6 = (int)puStack_84 - (int)puVar21;
        }
        uStack_88 = uStack_88 + uVar6 * -8;
      }
      else {
        uVar6 = uStack_88 >> 3;
        uStack_88 = uStack_88 & 7;
        bVar23 = false;
      }
      puStack_84 = (uint *)((int)puStack_84 - uVar6);
      uStack_8c = *puStack_84;
      if ((puVar10 + -4 < puStack_b4) || (bVar23)) {
        if (uStack_88 < 0x21) goto LAB_00057071;
        break;
      }
      uVar6 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar8;
      iVar15 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_88;
      *puStack_b4 = *(undefined *)(iVar22 + uVar6 * 2);
      uVar6 = (uStack_8c << ((byte)iVar15 & 0x1f)) >> bVar8;
      uStack_88 = (uint)*(byte *)(param_3 + 5 + uVar6 * 2) + iVar15;
      puStack_b4[1] = *(undefined *)(iVar22 + uVar6 * 2);
      puStack_b4 = puStack_b4 + 2;
    } while (uStack_88 < 0x21);
  }
joined_r0x00057227:
  if (puStack_b4 < puVar10) {
    uVar6 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar8;
    uStack_88 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_88;
    *puStack_b4 = *(undefined *)(iVar22 + uVar6 * 2);
    while (puStack_b4 = puStack_b4 + 1, puStack_b4 != puVar10) {
      uVar6 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar8;
      uStack_88 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_88;
      *puStack_b4 = *(undefined *)(iVar22 + uVar6 * 2);
    }
  }
  if ((((puStack_54 == puStack_50 && uStack_58 == 0x20) &&
       (local_3c == local_38 && local_40 == 0x20)) &&
      (puStack_6c == puStack_68 && uStack_70 == 0x20)) &&
      (puStack_84 == puVar21 && uStack_88 == 0x20)) {
    return local_18;
  }
  return 0xffffffec;
LAB_00056a63:
  if (0x20 < local_40) goto joined_r0x00056b1d;
LAB_00056a6c:
  if (local_3c < local_34) {
    if ((int)local_3c - (int)local_38 == 0) goto joined_r0x00056b1d;
    bVar23 = (uint *)((int)local_3c - (local_40 >> 3)) < local_38;
    uVar6 = local_40 >> 3;
    if (bVar23) {
      uVar6 = (int)local_3c - (int)local_38;
    }
    local_40 = local_40 + uVar6 * -8;
  }
  else {
    uVar6 = local_40 >> 3;
    local_40 = local_40 & 7;
    bVar23 = false;
  }
  local_3c = (uint *)((int)local_3c - uVar6);
  local_44 = *local_3c;
  if ((puVar1 <= param_3_00) || (bVar23)) goto joined_r0x00056b1d;
  uVar6 = (local_44 << ((byte)local_40 & 0x1f)) >> bVar8;
  local_40 = *(byte *)(param_3 + 5 + uVar6 * 2) + local_40;
  *param_3_00 = *(undefined *)(iVar22 + uVar6 * 2);
  param_3_00 = param_3_00 + 1;
  goto LAB_00056a63;
joined_r0x00056c75:
  if (0x20 < uStack_58) goto joined_r0x000571fa;
LAB_00056c7b:
  if (puStack_54 < puStack_4c) {
    if ((int)puStack_54 - (int)puStack_50 == 0) goto joined_r0x000571fa;
    bVar23 = (uint *)((int)puStack_54 - (uStack_58 >> 3)) < puStack_50;
    uVar6 = uStack_58 >> 3;
    if (bVar23) {
      uVar6 = (int)puStack_54 - (int)puStack_50;
    }
    uStack_58 = uStack_58 + uVar6 * -8;
  }
  else {
    uVar6 = uStack_58 >> 3;
    uStack_58 = uStack_58 & 7;
    bVar23 = false;
  }
  puStack_54 = (uint *)((int)puStack_54 - uVar6);
  uStack_5c = *puStack_54;
  if ((puVar17 <= local_b0) || (bVar23)) goto joined_r0x000571fa;
  uVar6 = (uStack_5c << ((byte)uStack_58 & 0x1f)) >> bVar8;
  uStack_58 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_58;
  *local_b0 = *(undefined *)(iVar22 + uVar6 * 2);
  local_b0 = local_b0 + 1;
  goto joined_r0x00056c75;
LAB_00056e83:
  if (puStack_6c < puStack_64) {
    if ((int)puStack_6c - (int)puStack_68 == 0) goto joined_r0x0005720f;
    bVar23 = (uint *)((int)puStack_6c - (uStack_70 >> 3)) < puStack_68;
    uVar6 = uStack_70 >> 3;
    if (bVar23) {
      uVar6 = (int)puStack_6c - (int)puStack_68;
    }
    uStack_70 = uStack_70 + uVar6 * -8;
  }
  else {
    uVar6 = uStack_70 >> 3;
    uStack_70 = uStack_70 & 7;
    bVar23 = false;
  }
  puStack_6c = (uint *)((int)puStack_6c - uVar6);
  uStack_74 = *puStack_6c;
  if ((puVar18 <= local_a4) || (bVar23)) goto joined_r0x0005720f;
  uVar6 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar8;
  uStack_70 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_70;
  *local_a4 = *(undefined *)(iVar22 + uVar6 * 2);
  local_a4 = local_a4 + 1;
  if (0x20 < uStack_70) goto joined_r0x0005720f;
  goto LAB_00056e83;
LAB_00057071:
  if (puStack_84 < puVar7) {
    if ((int)puStack_84 - (int)puVar21 == 0) goto joined_r0x00057227;
    bVar23 = (uint *)((int)puStack_84 - (uStack_88 >> 3)) < puVar21;
    uVar6 = uStack_88 >> 3;
    if (bVar23) {
      uVar6 = (int)puStack_84 - (int)puVar21;
    }
    uStack_88 = uStack_88 + uVar6 * -8;
  }
  else {
    uVar6 = uStack_88 >> 3;
    uStack_88 = uStack_88 & 7;
    bVar23 = false;
  }
  puStack_84 = (uint *)((int)puStack_84 - uVar6);
  uStack_8c = *puStack_84;
  if ((puVar10 <= puStack_b4) || (bVar23)) goto joined_r0x00057227;
  uVar6 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar8;
  uStack_88 = *(byte *)(param_3 + 5 + uVar6 * 2) + uStack_88;
  *puStack_b4 = *(undefined *)(iVar22 + uVar6 * 2);
  puStack_b4 = puStack_b4 + 1;
  if (0x20 < uStack_88) goto joined_r0x00057227;
  goto LAB_00057071;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00057340 FUN_00057340 */

uint FUN_00057340(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  undefined local_2814 [2048];
  undefined4 local_2014;
  undefined local_2010 [8192];
  
  FUN_00013c0c(local_2010,0,0x2000,0x5734f);
  local_2014 = 0xb00000b;
  uVar1 = FUN_000554f0(&local_2014,param_3,param_4,local_2814,0x800);
  uVar2 = uVar1;
  if ((uVar1 < 0xffffff89) && (uVar2 = 0xffffffb8, uVar1 < param_4)) {
    uVar2 = FUN_00055ce0(param_3 + uVar1,param_4 - uVar1,&local_2014);
  }
  return uVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000573f0 FUN_000573f0 */

uint FUN_000573f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint *puVar1;
  int iVar2;
  byte bVar3;
  int iVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  char cVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  int *piVar19;
  uint uVar20;
  uint uVar21;
  uint *puVar22;
  uint uVar23;
  uint uVar24;
  int local_dc;
  byte local_c4;
  undefined local_c3;
  byte local_c2;
  uint local_c0;
  uint local_bc;
  uint local_b8;
  int local_b4;
  int local_b0;
  undefined *local_ac;
  uint local_a8;
  int local_a4;
  uint local_a0;
  uint local_9c;
  uint local_98;
  int local_94;
  uint local_90;
  int local_8c;
  uint local_88;
  int local_84;
  uint local_80;
  uint local_7c;
  uint local_78 [13];
  uint local_44 [13];
  
  FUN_00013c06(&local_c4,param_1,4);
  uVar20 = 0xffffffd4;
  uVar24 = uVar20;
  if (0x5db < param_5) {
    iVar13 = param_4 + 0x270;
    FUN_00013c0c(iVar13,0,0x6c);
    if (((local_c4 < 0xd) &&
        (local_88 = FUN_00055320(param_4 + 0x4dc,0x100,iVar13,&local_80,&local_7c,param_2,param_3),
        uVar24 = local_88, local_88 < 0xffffff89)) &&
       (uVar11 = (uint)local_c4, uVar24 = uVar20, local_7c <= uVar11)) {
      local_b0 = param_1 + 4;
      local_8c = param_4 + 0x2dc;
      iVar2 = 0x34;
      uVar24 = local_7c;
      do {
        uVar20 = uVar24;
        iVar14 = iVar2;
        iVar2 = iVar14 + 0x34;
        uVar24 = uVar20 - 1;
      } while (*(int *)(iVar13 + uVar20 * 4) == 0);
      uVar24 = uVar20 + 1;
      local_a4 = 0;
      if (1 < uVar24) {
        uVar12 = 0;
        iVar13 = 0;
        do {
          local_a4 = *(int *)(param_4 + 0x274 + uVar12 * 4) + iVar13;
          *(int *)(param_4 + 0x2ac + uVar12 * 4) = iVar13;
          uVar12 = uVar12 + 1;
          iVar13 = local_a4;
        } while (uVar20 != uVar12);
      }
      *(int *)(param_4 + 0x2a8) = local_a4;
      if (local_80 != 0) {
        uVar12 = 0;
        do {
          bVar3 = *(byte *)(param_4 + 0x4dc + uVar12);
          iVar13 = *(int *)(param_4 + 0x2a8 + (uint)bVar3 * 4);
          *(int *)(param_4 + 0x2a8 + (uint)bVar3 * 4) = iVar13 + 1;
          *(char *)(param_4 + 0x2dc + iVar13 * 2) = (char)uVar12;
          *(byte *)(param_4 + 0x2dd + iVar13 * 2) = bVar3;
          uVar12 = uVar12 + 1;
        } while (uVar12 < local_80);
      }
      *(undefined4 *)(param_4 + 0x2a8) = 0;
      if (1 < uVar24) {
        uVar12 = 0;
        iVar13 = 0;
        do {
          iVar2 = uVar12 * 4;
          cVar7 = (char)uVar12;
          *(int *)(param_4 + 4 + uVar12 * 4) = iVar13;
          uVar12 = uVar12 + 1;
          iVar13 = (*(int *)(param_4 + 0x274 + iVar2) <<
                   ((local_c4 - (char)local_7c) + cVar7 & 0x1f)) + iVar13;
        } while (uVar20 != uVar12);
      }
      local_94 = local_7c + 1;
      local_90 = local_94 - uVar20;
      local_b8 = (uVar11 - local_90) + 1;
      if (local_90 < local_b8) {
        local_bc = local_7c * 0x34 + 0x38 + uVar20 * -0x34;
        local_9c = local_7c * 0x34 + 0x38 + uVar20 * -0x30;
        local_c0 = param_4 + 4;
        local_98 = param_4 + 4 + uVar20 * 4;
        uVar21 = uVar20 & 0xfffffff8;
        local_a0 = uVar21 + 1;
        local_dc = 0;
        uVar12 = local_90;
        do {
          if (1 < uVar24) {
            uVar15 = 1;
            if ((7 < uVar20) &&
               ((uVar16 = uVar21, puVar22 = (uint *)(param_4 + 0x14),
                local_98 <= local_bc + local_dc * 0x34 + param_4 ||
                (local_dc * 0x34 + local_9c + param_4 <= local_c0)))) {
              do {
                uVar15 = puVar22[-3];
                uVar23 = puVar22[-2];
                uVar18 = puVar22[-1];
                uVar17 = *puVar22;
                uVar8 = puVar22[1];
                uVar9 = puVar22[2];
                uVar10 = puVar22[3];
                uVar5 = (ulonglong)uVar12;
                uVar6 = (ulonglong)uVar12;
                puVar1 = (uint *)((int)puVar22 + iVar14 + -0x10);
                *puVar1 = puVar22[-4] >> uVar5;
                puVar1[1] = uVar15 >> uVar5;
                puVar1[2] = uVar23 >> uVar5;
                puVar1[3] = uVar18 >> uVar5;
                puVar1 = (uint *)((int)puVar22 + iVar14);
                *puVar1 = uVar17 >> uVar6;
                puVar1[1] = uVar8 >> uVar6;
                puVar1[2] = uVar9 >> uVar6;
                puVar1[3] = uVar10 >> uVar6;
                uVar16 = uVar16 - 8;
                puVar22 = puVar22 + 8;
              } while (uVar16 != 0);
              uVar15 = local_a0;
              if (uVar20 == uVar21) goto LAB_00057650;
            }
            do {
              *(uint *)(param_4 + iVar14 + uVar15 * 4) =
                   *(uint *)(param_4 + uVar15 * 4) >> ((byte)uVar12 & 0x1f);
              uVar15 = uVar15 + 1;
            } while (uVar24 != uVar15);
          }
LAB_00057650:
          uVar12 = uVar12 + 1;
          local_dc = local_dc + 1;
          iVar14 = iVar14 + 0x34;
        } while (local_b8 != uVar12);
      }
      local_ac = &DAT_000e0e28;
      FUN_00013c06(local_78,param_4,0x34);
      if (local_a4 != 0) {
        local_84 = local_94 - uVar11;
        local_b4 = param_1 + 0x14;
        iVar13 = 0;
        do {
          uVar21 = (uint)*(byte *)(local_8c + iVar13 * 2);
          uVar15 = (uint)*(byte *)(local_8c + 1 + iVar13 * 2);
          uVar20 = local_94 - uVar15;
          uVar24 = local_78[uVar15];
          uVar12 = uVar11 - uVar20;
          uVar16 = 1 << ((byte)uVar12 & 0x1f);
          if (uVar12 < local_90) {
            uVar23 = uVar16 + uVar24;
            if (uVar24 < uVar23) {
              iVar2 = (uVar20 & 0xff) * 0x10000 + 0x1000000 + uVar21;
              uVar20 = uVar24;
              if (2 < uVar12) {
                uVar21 = uVar16 & 0xfffffff8;
                uVar20 = uVar24 + uVar21;
                piVar19 = (int *)(local_b4 + uVar24 * 4);
                uVar12 = uVar21;
                do {
                  piVar19[-4] = iVar2;
                  piVar19[-3] = iVar2;
                  piVar19[-2] = iVar2;
                  piVar19[-1] = iVar2;
                  *piVar19 = iVar2;
                  piVar19[1] = iVar2;
                  piVar19[2] = iVar2;
                  piVar19[3] = iVar2;
                  piVar19 = piVar19 + 8;
                  uVar12 = uVar12 - 8;
                } while (uVar12 != 0);
                local_a8 = uVar16;
                if (uVar16 == uVar21) goto LAB_000577a4;
              }
              piVar19 = (int *)(local_b0 + uVar20 * 4);
              iVar14 = (uVar16 + uVar24) - uVar20;
              do {
                *piVar19 = iVar2;
                piVar19 = piVar19 + 1;
                iVar14 = iVar14 + -1;
              } while (iVar14 != 0);
            }
          }
          else {
            iVar2 = uVar20 + local_84;
            iVar14 = 1;
            if (0 < iVar2) {
              iVar14 = iVar2;
            }
            iVar4 = *(int *)(param_4 + 0x2a4 + iVar14 * 4);
            local_c0 = local_a4 - iVar4;
            local_bc = uVar21;
            local_a8 = uVar16;
            FUN_00013c06(local_44,uVar20 * 0x34 + param_4,0x34);
            if ((1 < iVar2) && (uVar21 = local_44[iVar14], uVar21 != 0)) {
              iVar2 = (uVar20 & 0xff) * 0x10000 + 0x1000000 + local_bc;
              uVar16 = 0;
              if (7 < uVar21) {
                uVar16 = uVar21 & 0xfffffff8;
                piVar19 = (int *)(local_b4 + uVar24 * 4);
                uVar23 = uVar16;
                do {
                  piVar19[-4] = iVar2;
                  piVar19[-3] = iVar2;
                  piVar19[-2] = iVar2;
                  piVar19[-1] = iVar2;
                  *piVar19 = iVar2;
                  piVar19[1] = iVar2;
                  piVar19[2] = iVar2;
                  piVar19[3] = iVar2;
                  piVar19 = piVar19 + 8;
                  uVar23 = uVar23 - 8;
                } while (uVar23 != 0);
                if (uVar21 == uVar16) goto LAB_00057958;
              }
              piVar19 = (int *)(local_b0 + (uVar24 + uVar16) * 4);
              iVar14 = uVar21 - uVar16;
              do {
                *piVar19 = iVar2;
                piVar19 = piVar19 + 1;
                iVar14 = iVar14 + -1;
              } while (iVar14 != 0);
            }
LAB_00057958:
            if (local_c0 != 0) {
              local_98 = local_8c + iVar4 * 2;
              local_a0 = local_b4 + uVar24 * 4;
              uVar21 = 0;
              do {
                local_b8 = uVar21;
                uVar23 = (uint)*(byte *)(local_98 + 1 + local_b8 * 2);
                uVar21 = local_44[uVar23];
                uVar18 = (1 << ((byte)uVar12 - (char)(local_94 - uVar23) & 0x1f)) + uVar21;
                iVar2 = ((local_94 - uVar23) + uVar20 & 0xff) * 0x10000 + 0x2000000 +
                        (uint)*(byte *)(local_98 + local_b8 * 2) * 0x100 + local_bc;
                uVar16 = uVar21 + 1;
                if (uVar21 + 1 < uVar18) {
                  uVar16 = uVar18;
                }
                uVar16 = uVar16 - uVar21;
                if (uVar16 < 8) {
LAB_00057a60:
                  do {
                    *(int *)(local_b0 + uVar24 * 4 + uVar21 * 4) = iVar2;
                    uVar21 = uVar21 + 1;
                  } while (uVar21 < uVar18);
                }
                else {
                  local_9c = uVar16 & 0xfffffff8;
                  piVar19 = (int *)(local_a0 + uVar21 * 4);
                  uVar21 = uVar21 + local_9c;
                  uVar17 = local_9c;
                  do {
                    piVar19[-4] = iVar2;
                    piVar19[-3] = iVar2;
                    piVar19[-2] = iVar2;
                    piVar19[-1] = iVar2;
                    *piVar19 = iVar2;
                    piVar19[1] = iVar2;
                    piVar19[2] = iVar2;
                    piVar19[3] = iVar2;
                    piVar19 = piVar19 + 8;
                    uVar17 = uVar17 - 8;
                  } while (uVar17 != 0);
                  if (uVar16 != local_9c) goto LAB_00057a60;
                }
                local_44[uVar23] = uVar18;
                uVar21 = local_b8 + 1;
              } while (local_b8 + 1 != local_c0);
            }
            uVar23 = local_a8 + local_78[uVar15];
          }
LAB_000577a4:
          local_78[uVar15] = uVar23;
          iVar13 = iVar13 + 1;
        } while (iVar13 != local_a4);
      }
      local_c2 = local_c4;
      local_c3 = 1;
      FUN_00013c06(param_1,&local_c4,4);
      uVar24 = local_88;
    }
  }
  return uVar24;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00057b60 FUN_00057b60 */

uint __regparm3
FUN_00057b60(undefined4 param_1_00,uint param_2_00,uint param_3_00,uint *param_1,uint param_2,
            int param_3)

{
  int iVar1;
  byte bVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  bool bVar6;
  uint local_3c;
  uint local_38;
  uint *local_34;
  uint *local_30;
  uint *local_2c;
  uint uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined auStack_14 [2];
  char cStack_12;
  
  if (param_2 == 0) {
    FUN_00013c0c(&local_3c,0,0x14);
    return 0xffffffb8;
  }
  local_30 = param_1;
  local_2c = param_1 + 1;
  if (param_2 < 4) {
    local_34 = param_1;
    local_3c = (uint)*(byte *)param_1;
    if (param_2 == 2) {
LAB_00057c04:
      local_3c = (uint)*(byte *)((int)param_1 + 1) * 0x100 + local_3c;
    }
    else if (param_2 == 3) {
      local_3c = local_3c | (uint)*(byte *)((int)param_1 + 2) << 0x10;
      goto LAB_00057c04;
    }
    bVar2 = *(byte *)((param_2 - 1) + (int)param_1);
    if (bVar2 == 0) {
      return 0xffffffec;
    }
    iVar1 = 0x1f;
    if (bVar2 != 0) {
      for (; bVar2 >> iVar1 == 0; iVar1 = iVar1 + -1) {
      }
    }
    local_38 = 0x28 - (iVar1 + param_2 * 8);
  }
  else {
    local_34 = (uint *)((int)param_1 + (param_2 - 4));
    local_3c = *(uint *)((int)param_1 + (param_2 - 4));
    bVar2 = *(byte *)((int)param_1 + (param_2 - 1));
    if (bVar2 == 0) {
      return 0xffffffff;
    }
    uVar3 = 0x1f;
    if (bVar2 != 0) {
      for (; bVar2 >> uVar3 == 0; uVar3 = uVar3 - 1) {
      }
    }
    local_38 = ~uVar3 + 9;
    if (0xffffff88 < param_2) {
      return param_2;
    }
  }
  uVar3 = param_3_00 + param_2_00;
  uStack_24 = param_2_00;
  FUN_00013c06(auStack_14,param_3,4);
  uStack_20 = uVar3;
  iStack_18 = param_3 + 4;
  if (local_38 < 0x21) {
    bVar2 = -cStack_12 & 0x1f;
    puStack_1c = &DAT_000e0e28;
    do {
      iVar1 = iStack_18;
      if (local_34 < local_2c) {
        if ((int)local_34 - (int)local_30 != 0) {
          bVar6 = (uint *)((int)local_34 - (local_38 >> 3)) < local_30;
          uVar3 = local_38 >> 3;
          if (bVar6) {
            uVar3 = (int)local_34 - (int)local_30;
          }
          local_38 = local_38 + uVar3 * -8;
          goto LAB_00057cf0;
        }
LAB_00057dcf:
        uVar3 = uStack_20 - 2;
        goto LAB_00057de0;
      }
      uVar3 = local_38 >> 3;
      local_38 = local_38 & 7;
      bVar6 = false;
LAB_00057cf0:
      local_34 = (uint *)((int)local_34 - uVar3);
      local_3c = *local_34;
      if ((uVar3 - 3 <= param_3_00) || (bVar6)) {
        uVar3 = uStack_20 - 2;
        if (local_38 < 0x21) goto LAB_00057dcf;
        goto LAB_00057e90;
      }
      uVar3 = (local_3c << ((byte)local_38 & 0x1f)) >> bVar2;
      FUN_00013c06(param_3_00,iStack_18 + uVar3 * 4,2);
      local_38 = *(byte *)(iVar1 + 2 + uVar3 * 4) + local_38;
      iVar4 = *(byte *)(iVar1 + 3 + uVar3 * 4) + param_3_00;
      uVar3 = (local_3c << ((byte)local_38 & 0x1f)) >> bVar2;
      FUN_00013c06(iVar4,iVar1 + uVar3 * 4,2);
      local_38 = *(byte *)(iVar1 + 2 + uVar3 * 4) + local_38;
      param_3_00 = (uint)*(byte *)(iVar1 + 3 + uVar3 * 4) + iVar4;
    } while (local_38 < 0x21);
    uVar3 = uStack_20 - 2;
  }
  else {
    bVar2 = -cStack_12 & 0x1f;
    uVar3 = uVar3 - 2;
  }
LAB_00057e90:
  iVar1 = iStack_18;
  if (uVar3 < param_3_00) {
    if (uStack_20 <= param_3_00) goto LAB_00057f56;
  }
  else {
    do {
      uVar5 = (local_3c << ((byte)local_38 & 0x1f)) >> bVar2;
      FUN_00013c06(param_3_00,iVar1 + uVar5 * 4,2);
      local_38 = *(byte *)(iVar1 + 2 + uVar5 * 4) + local_38;
      param_3_00 = param_3_00 + *(byte *)(iVar1 + 3 + uVar5 * 4);
    } while (param_3_00 <= uVar3);
    if (uStack_20 <= param_3_00) goto LAB_00057f56;
  }
  iVar1 = iStack_18;
  uVar3 = (local_3c << ((byte)local_38 & 0x1f)) >> bVar2;
  FUN_00013c06(param_3_00,iStack_18 + uVar3 * 4,1);
  if (*(char *)(iVar1 + 3 + uVar3 * 4) == '\x01') {
    local_38 = *(byte *)(iVar1 + 2 + uVar3 * 4) + local_38;
  }
  else if ((local_38 < 0x20) &&
          (local_38 = local_38 + *(byte *)(iVar1 + 2 + uVar3 * 4), 0x1f < local_38)) {
    local_38 = 0x20;
  }
LAB_00057f56:
  uVar3 = 0xffffffec;
  if ((local_38 ^ 0x20 | (uint)local_34 ^ (uint)local_30) == 0) {
    uVar3 = uStack_24;
  }
  return uVar3;
LAB_00057de0:
  iVar1 = iStack_18;
  if (local_34 < local_2c) {
    if ((int)local_34 - (int)local_30 == 0) goto LAB_00057e90;
    bVar6 = (uint *)((int)local_34 - (local_38 >> 3)) < local_30;
    uVar5 = local_38 >> 3;
    if (bVar6) {
      uVar5 = (int)local_34 - (int)local_30;
    }
    local_38 = local_38 + uVar5 * -8;
  }
  else {
    uVar5 = local_38 >> 3;
    local_38 = local_38 & 7;
    bVar6 = false;
  }
  local_34 = (uint *)((int)local_34 - uVar5);
  local_3c = *local_34;
  if ((uVar3 < param_3_00) || (bVar6)) goto LAB_00057e90;
  uVar5 = (local_3c << ((byte)local_38 & 0x1f)) >> bVar2;
  FUN_00013c06(param_3_00,iStack_18 + uVar5 * 4,2);
  local_38 = *(byte *)(iVar1 + 2 + uVar5 * 4) + local_38;
  param_3_00 = param_3_00 + *(byte *)(iVar1 + 3 + uVar5 * 4);
  if (0x20 < local_38) goto LAB_00057e90;
  goto LAB_00057de0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00058190 FUN_00058190 */

uint __regparm3
FUN_00058190(undefined4 param_1_00,uint param_2_00,uint param_3_00,ushort *param_1,uint param_2,
            int param_3)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  uint uVar4;
  uint *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  byte bVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  bool bVar18;
  uint local_cc;
  uint local_c8;
  uint local_c4;
  uint local_c0;
  uint uStack_b0;
  uint uStack_a4;
  uint uStack_a0;
  uint *puStack_9c;
  uint *puStack_98;
  uint *puStack_94;
  uint uStack_8c;
  uint uStack_88;
  uint *puStack_84;
  uint *puStack_80;
  uint *puStack_7c;
  uint uStack_74;
  uint uStack_70;
  uint *puStack_6c;
  uint *puStack_68;
  uint *puStack_64;
  uint local_5c;
  uint local_58;
  uint *local_54;
  uint *local_50;
  uint *local_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint *puStack_30;
  uint local_2c;
  uint uStack_28;
  undefined local_24 [2];
  char local_22;
  uint uStack_1c;
  uint *puStack_18;
  uint uStack_14;
  
  if (param_2 < 10) {
    return 0xffffffec;
  }
  uVar1 = *param_1;
  uVar17 = (uint)uVar1;
  uVar2 = param_1[1];
  uVar10 = (uint)uVar2;
  uVar3 = param_1[2];
  uVar4 = (uint)uVar3;
  uVar14 = uVar17 + 6 + uVar10 + uVar4;
  local_2c = param_2_00;
  FUN_00013c06(local_24,param_3,4);
  uVar16 = param_2 - uVar14;
  if (param_2 < uVar14) {
    return 0xffffffec;
  }
  if (uVar1 == 0) {
    puVar5 = &local_5c;
    goto LAB_000583b3;
  }
  local_50 = (uint *)(param_1 + 3);
  local_4c = (uint *)(param_1 + 5);
  if (uVar1 < 4) {
    local_5c = (uint)*(byte *)local_50;
    if (uVar1 == 2) {
LAB_00058365:
      local_5c = local_5c + (uint)*(byte *)((int)param_1 + 7) * 0x100;
    }
    else if (uVar1 == 3) {
      local_5c = local_5c | (uint)*(byte *)(param_1 + 4) << 0x10;
      goto LAB_00058365;
    }
    bVar11 = *(byte *)((uVar17 - 1) + (int)local_50);
    if (bVar11 == 0) {
      return 0xffffffec;
    }
    iVar15 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
      }
    }
    local_58 = 0x28 - (iVar15 + uVar17 * 8);
    uVar14 = 6;
    local_54 = local_50;
  }
  else {
    local_54 = (uint *)((int)param_1 + uVar17 + 2);
    local_5c = *(uint *)((int)param_1 + uVar17 + 2);
    bVar11 = *(byte *)((int)param_1 + uVar17 + 5);
    if (bVar11 == 0) {
      return 0xffffffff;
    }
    uVar14 = uVar17 + 2;
    uVar12 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> uVar12 == 0; uVar12 = uVar12 - 1) {
      }
    }
    local_58 = ~uVar12 + 9;
  }
  if (uVar2 == 0) {
    puVar5 = &uStack_74;
    goto LAB_000583b3;
  }
  puStack_68 = (uint *)((int)param_1 + uVar17 + 6);
  puStack_64 = puStack_68 + 1;
  if (uVar2 < 4) {
    uStack_74 = (uint)*(byte *)puStack_68;
    if (uVar2 == 2) {
LAB_00058439:
      uStack_74 = (uint)*(byte *)((int)puStack_68 + 1) * 0x100 + uStack_74;
    }
    else if (uVar2 == 3) {
      uStack_74 = uStack_74 | (uint)*(byte *)((int)puStack_68 + 2) << 0x10;
      goto LAB_00058439;
    }
    bVar11 = *(byte *)((uVar10 - 1) + (int)puStack_68);
    if (bVar11 == 0) {
      return 0xffffffec;
    }
    iVar15 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
      }
    }
    uStack_70 = 0x28 - (iVar15 + uVar10 * 8);
    uStack_b0 = 0;
    puStack_6c = puStack_68;
  }
  else {
    puStack_6c = (uint *)((int)puStack_68 + (uVar10 - 4));
    uStack_74 = *(uint *)((int)puStack_68 + (uVar10 - 4));
    bVar11 = *(byte *)((uVar10 - 1) + (int)puStack_68);
    if (bVar11 == 0) {
      return 0xffffffff;
    }
    uStack_b0 = uVar10 - 4;
    uVar17 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> uVar17 == 0; uVar17 = uVar17 - 1) {
      }
    }
    uStack_70 = ~uVar17 + 9;
  }
  if (uVar3 == 0) {
    puVar5 = &uStack_8c;
    goto LAB_000583b3;
  }
  puStack_80 = (uint *)(uVar10 + (int)puStack_68);
  puStack_7c = puStack_80 + 1;
  if (uVar3 < 4) {
    uStack_8c = (uint)*(byte *)puStack_80;
    if (uVar3 == 2) {
LAB_000584f8:
      uStack_8c = (uint)*(byte *)((int)puStack_80 + 1) * 0x100 + uStack_8c;
    }
    else if (uVar3 == 3) {
      uStack_8c = uStack_8c | (uint)*(byte *)((int)puStack_80 + 2) << 0x10;
      goto LAB_000584f8;
    }
    bVar11 = *(byte *)((uVar4 - 1) + (int)puStack_80);
    if (bVar11 == 0) {
      return 0xffffffec;
    }
    iVar15 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
      }
    }
    uStack_40 = 0x28 - (iVar15 + uVar4 * 8);
    uStack_38 = 0;
    puStack_84 = puStack_80;
  }
  else {
    uStack_8c = *(uint *)((int)puStack_80 + (uVar4 - 4));
    bVar11 = *(byte *)((uVar4 - 1) + (int)puStack_80);
    if (bVar11 == 0) {
      return 0xffffffff;
    }
    uStack_38 = uVar4 - 4;
    uVar10 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> uVar10 == 0; uVar10 = uVar10 - 1) {
      }
    }
    uStack_40 = ~uVar10 + 9;
    puStack_84 = (uint *)((int)puStack_80 + (uVar4 - 4));
  }
  uStack_88 = uStack_40;
  if (uVar16 == 0) {
    puVar5 = &uStack_a4;
LAB_000583b3:
    FUN_00013c0c(puVar5,0,0x14);
    return 0xffffffb8;
  }
  puStack_98 = (uint *)(uVar4 + (int)puStack_80);
  puStack_94 = puStack_98 + 1;
  if (uVar16 < 4) {
    uStack_a4 = (uint)*(byte *)puStack_98;
    if (uVar16 == 2) {
LAB_000585d6:
      uStack_a4 = (uint)*(byte *)((int)puStack_98 + 1) * 0x100 + uStack_a4;
    }
    else if (uVar16 == 3) {
      uStack_a4 = uStack_a4 | (uint)*(byte *)((int)puStack_98 + 2) << 0x10;
      goto LAB_000585d6;
    }
    bVar11 = *(byte *)((uVar16 - 1) + (int)puStack_98);
    if (bVar11 == 0) {
      return 0xffffffec;
    }
    iVar15 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
      }
    }
    uStack_3c = 0x28 - (iVar15 + uVar16 * 8);
    local_c0 = 0;
    puStack_9c = puStack_98;
  }
  else {
    uStack_a4 = *(uint *)((int)puStack_98 + (uVar16 - 4));
    bVar11 = *(byte *)((uVar16 - 1) + (int)puStack_98);
    if (bVar11 == 0) {
      return 0xffffffff;
    }
    uVar4 = 0x1f;
    if (bVar11 != 0) {
      for (; bVar11 >> uVar4 == 0; uVar4 = uVar4 - 1) {
      }
    }
    uStack_3c = ~uVar4 + 9;
    if (0xffffff88 < uVar16) {
      return uVar16;
    }
    local_c0 = uVar16 - 4;
    puStack_9c = (uint *)((int)puStack_98 + (uVar16 - 4));
  }
  if (local_58 < 0x21) {
    if (uVar14 < 10) {
      if (uVar14 == 6) {
        uVar4 = 2 - (local_58 < 0x20);
      }
      else {
        iVar15 = uVar14 - (local_58 >> 3);
        uVar4 = (uint)(iVar15 < 6);
        uVar10 = uVar14 - 6;
        if (5 < iVar15) {
          uVar10 = local_58 >> 3;
        }
        local_54 = (uint *)((int)param_1 + (uVar14 - uVar10));
        local_58 = local_58 + uVar10 * -8;
        local_5c = *local_54;
      }
    }
    else {
      local_54 = (uint *)((int)param_1 + (uVar14 - (local_58 >> 3)));
      local_58 = local_58 & 7;
      local_5c = *local_54;
      uVar4 = 0;
    }
  }
  else {
    uVar4 = 3;
  }
  uVar10 = local_2c + 3 >> 2;
  uVar14 = 3;
  if (uStack_70 < 0x21) {
    if ((int)uStack_b0 < 4) {
      if (uStack_b0 == 0) {
        uVar14 = 2 - (uStack_70 < 0x20);
      }
      else {
        bVar18 = (uint *)((int)puStack_68 + (uStack_b0 - (uStack_70 >> 3))) < puStack_68;
        uVar14 = (uint)bVar18;
        uVar16 = uStack_70 >> 3;
        if (bVar18) {
          uVar16 = uStack_b0;
        }
        puStack_6c = (uint *)((int)puStack_68 + (uStack_b0 - uVar16));
        uStack_70 = uStack_70 + uVar16 * -8;
        uStack_74 = *puStack_6c;
      }
    }
    else {
      puStack_6c = (uint *)((int)puStack_68 + (uStack_b0 - (uStack_70 >> 3)));
      uStack_70 = uStack_70 & 7;
      uStack_74 = *puStack_6c;
      uVar14 = 0;
    }
  }
  uVar16 = param_3_00 + uVar10;
  uVar17 = 3;
  uVar12 = 3;
  if (uStack_40 < 0x21) {
    if ((int)uStack_38 < 4) {
      if (uStack_38 == 0) {
        uVar12 = 2 - (uStack_40 < 0x20);
      }
      else {
        bVar18 = (uint *)((int)puStack_80 + (uStack_38 - (uStack_40 >> 3))) < puStack_80;
        uVar12 = (uint)bVar18;
        uVar13 = uStack_40 >> 3;
        if (bVar18) {
          uVar13 = uStack_38;
        }
        puStack_84 = (uint *)((int)puStack_80 + (uStack_38 - uVar13));
        uStack_88 = uStack_40 + uVar13 * -8;
        uStack_8c = *puStack_84;
      }
    }
    else {
      puStack_84 = (uint *)((int)puStack_80 + (uStack_38 - (uStack_40 >> 3)));
      uStack_88 = uStack_40 & 7;
      uStack_8c = *puStack_84;
      uVar12 = 0;
    }
  }
  local_c4 = uVar10 + uVar16;
  uStack_34 = local_2c + param_3_00;
  uStack_a0 = uStack_3c;
  if (uStack_3c < 0x21) {
    if ((int)local_c0 < 4) {
      if (local_c0 == 0) {
        uVar17 = 2 - (uStack_3c < 0x20);
      }
      else {
        bVar18 = (uint *)((int)puStack_98 + (local_c0 - (uStack_3c >> 3))) < puStack_98;
        uVar17 = (uint)bVar18;
        uVar13 = uStack_3c >> 3;
        if (bVar18) {
          uVar13 = local_c0;
        }
        puStack_9c = (uint *)((int)puStack_98 + (local_c0 - uVar13));
        uStack_a0 = uStack_3c + uVar13 * -8;
        uStack_a4 = *puStack_9c;
      }
    }
    else {
      puStack_9c = (uint *)((int)puStack_98 + (local_c0 - (uStack_3c >> 3)));
      uStack_a0 = uStack_3c & 7;
      uStack_a4 = *puStack_9c;
      uVar17 = 0;
    }
  }
  iVar15 = param_3 + 4;
  uVar10 = uVar10 + local_c4;
  uStack_28 = uStack_34 - 3;
  uStack_44 = uVar16;
  uStack_48 = local_c4;
  uVar13 = uVar10;
  local_c8 = param_3_00;
  if (((uVar14 | uVar4 | uVar12 | uVar17) == 0) && (uVar10 < uStack_28)) {
    bVar11 = -local_22;
    do {
      uVar4 = (local_5c << ((byte)local_58 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(local_c8,iVar15 + uVar4 * 4,2);
      local_58 = local_58 + *(byte *)(param_3 + 6 + uVar4 * 4);
      iVar6 = *(byte *)(param_3 + 7 + uVar4 * 4) + local_c8;
      uVar4 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(uVar16,iVar15 + uVar4 * 4,2);
      uStack_70 = uStack_70 + *(byte *)(param_3 + 6 + uVar4 * 4);
      iVar7 = *(byte *)(param_3 + 7 + uVar4 * 4) + uVar16;
      uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(local_c4,iVar15 + uVar4 * 4,2);
      uStack_88 = uStack_88 + *(byte *)(param_3 + 6 + uVar4 * 4);
      iVar8 = *(byte *)(param_3 + 7 + uVar4 * 4) + local_c4;
      uVar4 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(uVar13,iVar15 + uVar4 * 4,2);
      uStack_a0 = uStack_a0 + *(byte *)(param_3 + 6 + uVar4 * 4);
      iVar9 = *(byte *)(param_3 + 7 + uVar4 * 4) + uVar13;
      uVar4 = (local_5c << ((byte)local_58 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(iVar6,iVar15 + uVar4 * 4,2);
      local_58 = local_58 + *(byte *)(param_3 + 6 + uVar4 * 4);
      uStack_40 = (uint)*(byte *)(param_3 + 7 + uVar4 * 4);
      uVar4 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(iVar7,iVar15 + uVar4 * 4,2);
      uStack_70 = uStack_70 + *(byte *)(param_3 + 6 + uVar4 * 4);
      uStack_38 = (uint)*(byte *)(param_3 + 7 + uVar4 * 4);
      uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(iVar8,iVar15 + uVar4 * 4,2);
      uStack_88 = uStack_88 + *(byte *)(param_3 + 6 + uVar4 * 4);
      uStack_3c = (uint)*(byte *)(param_3 + 7 + uVar4 * 4);
      uVar4 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> (bVar11 & 0x1f);
      FUN_00013c06(iVar9,iVar15 + uVar4 * 4,2);
      uStack_a0 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_a0;
      uStack_14 = (uint)*(byte *)(param_3 + 7 + uVar4 * 4);
      uVar4 = 3;
      if (local_58 < 0x21) {
        if (local_54 < local_4c) {
          if ((int)local_54 - (int)local_50 == 0) {
            uVar14 = 2 - (local_58 < 0x20);
          }
          else {
            bVar18 = (uint *)((int)local_54 - (local_58 >> 3)) < local_50;
            uVar14 = (uint)bVar18;
            uVar16 = local_58 >> 3;
            if (bVar18) {
              uVar16 = (int)local_54 - (int)local_50;
            }
            local_54 = (uint *)((int)local_54 - uVar16);
            local_58 = local_58 + uVar16 * -8;
            local_5c = *local_54;
          }
        }
        else {
          local_54 = (uint *)((int)local_54 - (local_58 >> 3));
          local_58 = local_58 & 7;
          local_5c = *local_54;
          uVar14 = 0;
        }
      }
      else {
        uVar14 = 3;
      }
      if (uStack_70 < 0x21) {
        if (puStack_6c < puStack_64) {
          if ((int)puStack_6c - (int)puStack_68 == 0) {
            uVar4 = 2 - (uStack_70 < 0x20);
          }
          else {
            puStack_30 = puStack_68;
            bVar18 = (uint *)((int)puStack_6c - (uStack_70 >> 3)) < puStack_68;
            uVar4 = (uint)bVar18;
            uVar16 = uStack_70 >> 3;
            if (bVar18) {
              uVar16 = (int)puStack_6c - (int)puStack_68;
            }
            puStack_6c = (uint *)((int)puStack_6c - uVar16);
            uStack_70 = uStack_70 + uVar16 * -8;
            uStack_74 = *puStack_6c;
          }
        }
        else {
          puStack_6c = (uint *)((int)puStack_6c - (uStack_70 >> 3));
          uStack_70 = uStack_70 & 7;
          uStack_74 = *puStack_6c;
          uVar4 = 0;
        }
      }
      uStack_b0 = 3;
      uVar17 = 3;
      if (uStack_88 < 0x21) {
        if (puStack_84 < puStack_7c) {
          uVar16 = (int)puStack_84 - (int)puStack_80;
          if (uVar16 == 0) {
            uVar17 = 2 - (uStack_88 < 0x20);
          }
          else {
            puStack_30 = (uint *)((int)puStack_84 - (uStack_88 >> 3));
            puStack_18 = puStack_80;
            uVar17 = (uint)(puStack_30 < puStack_80);
            uVar12 = uStack_88 >> 3;
            if (puStack_30 < puStack_80) {
              uVar12 = uVar16;
            }
            puStack_84 = (uint *)((int)puStack_84 - uVar12);
            uStack_88 = uStack_88 + uVar12 * -8;
            uStack_8c = *puStack_84;
            uStack_1c = uVar16;
          }
        }
        else {
          puStack_84 = (uint *)((int)puStack_84 - (uStack_88 >> 3));
          uStack_88 = uStack_88 & 7;
          uStack_8c = *puStack_84;
          uVar17 = 0;
        }
      }
      if (uStack_a0 < 0x21) {
        if (puStack_9c < puStack_94) {
          if ((int)puStack_9c - (int)puStack_98 == 0) {
            uStack_b0 = 2 - (uStack_a0 < 0x20);
          }
          else {
            bVar18 = (uint *)((int)puStack_9c - (uStack_a0 >> 3)) < puStack_98;
            uStack_b0 = (uint)bVar18;
            uVar16 = uStack_a0 >> 3;
            if (bVar18) {
              uVar16 = (int)puStack_9c - (int)puStack_98;
            }
            puStack_9c = (uint *)((int)puStack_9c - uVar16);
            uStack_a0 = uStack_a0 + uVar16 * -8;
            uStack_a4 = *puStack_9c;
          }
        }
        else {
          puStack_9c = (uint *)((int)puStack_9c - (uStack_a0 >> 3));
          uStack_a0 = uStack_a0 & 7;
          uStack_a4 = *puStack_9c;
          uStack_b0 = 0;
        }
      }
      local_c8 = iVar6 + uStack_40;
      uVar16 = iVar7 + uStack_38;
      local_c4 = iVar8 + uStack_3c;
      uVar13 = iVar9 + uStack_14;
    } while (((uVar4 | uVar14 | uVar17 | uStack_b0) == 0) && (uVar13 < uStack_28));
  }
  if (uVar10 < local_c4) {
    return 0xffffffec;
  }
  if (uStack_48 < uVar16) {
    return 0xffffffec;
  }
  if (uStack_44 < local_c8) {
    return 0xffffffec;
  }
  if (local_58 < 0x21) {
    uVar4 = uStack_44 - 3;
    bVar11 = -local_22 & 0x1f;
    do {
      uVar14 = uStack_44;
      if (local_54 < local_4c) {
        if ((int)local_54 - (int)local_50 == 0) goto LAB_00059093;
        bVar18 = (uint *)((int)local_54 - (local_58 >> 3)) < local_50;
        uVar17 = local_58 >> 3;
        if (bVar18) {
          uVar17 = (int)local_54 - (int)local_50;
        }
        local_58 = local_58 + uVar17 * -8;
      }
      else {
        uVar17 = local_58 >> 3;
        local_58 = local_58 & 7;
        bVar18 = false;
      }
      local_54 = (uint *)((int)local_54 - uVar17);
      local_5c = *local_54;
      if ((uVar4 <= local_c8) || (bVar18)) {
        if (local_58 < 0x21) goto LAB_00059093;
        goto LAB_00059177;
      }
      uVar14 = (local_5c << ((byte)local_58 & 0x1f)) >> bVar11;
      FUN_00013c06(local_c8,iVar15 + uVar14 * 4,2);
      local_58 = *(byte *)(param_3 + 6 + uVar14 * 4) + local_58;
      iVar6 = *(byte *)(param_3 + 7 + uVar14 * 4) + local_c8;
      uVar14 = (local_5c << ((byte)local_58 & 0x1f)) >> bVar11;
      FUN_00013c06(iVar6,iVar15 + uVar14 * 4,2);
      local_58 = *(byte *)(param_3 + 6 + uVar14 * 4) + local_58;
      local_c8 = (uint)*(byte *)(param_3 + 7 + uVar14 * 4) + iVar6;
    } while (local_58 < 0x21);
  }
  else {
    bVar11 = -local_22 & 0x1f;
  }
  local_cc = uStack_44 - 2;
  if (local_cc < local_c8) goto LAB_00059181;
  goto LAB_0005901b;
LAB_00059177:
  local_cc = uVar14 - 2;
  if (local_c8 <= local_cc) goto LAB_0005901b;
LAB_00059181:
  if (local_c8 < uStack_44) goto LAB_0005918e;
  goto LAB_000591f8;
  while( true ) {
    uVar17 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar11;
    FUN_00013c06(uVar16,iVar15 + uVar17 * 4,2);
    uStack_70 = *(byte *)(param_3 + 6 + uVar17 * 4) + uStack_70;
    uVar16 = uVar16 + *(byte *)(param_3 + 7 + uVar17 * 4);
    if (0x20 < uStack_70) break;
LAB_0005935b:
    if (puStack_6c < puStack_64) {
      if ((int)puStack_6c - (int)puStack_68 == 0) {
        if (uVar16 <= uVar4) goto LAB_00059427;
        goto LAB_00059462;
      }
      bVar18 = (uint *)((int)puStack_6c - (uStack_70 >> 3)) < puStack_68;
      uVar17 = uStack_70 >> 3;
      if (bVar18) {
        uVar17 = (int)puStack_6c - (int)puStack_68;
      }
      uStack_70 = uStack_70 + uVar17 * -8;
    }
    else {
      uVar17 = uStack_70 >> 3;
      uStack_70 = uStack_70 & 7;
      bVar18 = false;
    }
    puStack_6c = (uint *)((int)puStack_6c - uVar17);
    uStack_74 = *puStack_6c;
    if ((uVar4 < uVar16) || (bVar18)) break;
  }
LAB_0005940f:
  uVar4 = uVar14 - 2;
  if (uVar16 <= uVar4) goto LAB_00059427;
  goto LAB_00059462;
  while( true ) {
    puStack_84 = (uint *)((int)puStack_84 - uVar4);
    uStack_8c = *puStack_84;
    if ((uVar10 - 2 < local_c4) || (bVar18)) goto LAB_000595ef;
    uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar11;
    FUN_00013c06(local_c4,iVar15 + uVar4 * 4,2);
    uStack_88 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_88;
    local_c4 = local_c4 + *(byte *)(param_3 + 7 + uVar4 * 4);
    if (0x20 < uStack_88) break;
LAB_0005962d:
    if (puStack_84 < puStack_7c) {
      if ((int)puStack_84 - (int)puStack_80 == 0) break;
      bVar18 = (uint *)((int)puStack_84 - (uStack_88 >> 3)) < puStack_80;
      uVar4 = uStack_88 >> 3;
      if (bVar18) {
        uVar4 = (int)puStack_84 - (int)puStack_80;
      }
      uStack_88 = uStack_88 + uVar4 * -8;
    }
    else {
      uVar4 = uStack_88 >> 3;
      uStack_88 = uStack_88 & 7;
      bVar18 = false;
    }
  }
  if (local_c4 <= uVar10 - 2) goto LAB_000596f1;
  goto joined_r0x00059743;
LAB_000598ed:
  do {
    if (puStack_9c < puStack_94) {
      if ((int)puStack_9c - (int)puStack_98 != 0) {
        bVar18 = (uint *)((int)puStack_9c - (uStack_a0 >> 3)) < puStack_98;
        uVar14 = uStack_a0 >> 3;
        if (bVar18) {
          uVar14 = (int)puStack_9c - (int)puStack_98;
        }
        uStack_a0 = uStack_a0 + uVar14 * -8;
        goto LAB_0005993d;
      }
LAB_000599ab:
      if (uVar13 <= uVar10) goto LAB_000599c3;
      goto LAB_00059a00;
    }
    uVar14 = uStack_a0 >> 3;
    uStack_a0 = uStack_a0 & 7;
    bVar18 = false;
LAB_0005993d:
    puStack_9c = (uint *)((int)puStack_9c - uVar14);
    uStack_a4 = *puStack_9c;
    if ((uVar10 < uVar13) || (bVar18)) goto LAB_000599ab;
    uVar14 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> bVar11;
    FUN_00013c06(uVar13,iVar15 + uVar14 * 4,2);
    uStack_a0 = *(byte *)(param_3 + 6 + uVar14 * 4) + uStack_a0;
    uVar13 = uVar13 + *(byte *)(param_3 + 7 + uVar14 * 4);
  } while (uStack_a0 < 0x21);
LAB_0005999d:
  uVar10 = uVar4 - 2;
  if (uVar10 < uVar13) goto LAB_00059a00;
  goto LAB_000599c3;
  while( true ) {
    local_54 = (uint *)((int)local_54 - uVar4);
    local_5c = *local_54;
    if ((uVar14 - 2 < local_c8) || (bVar18)) goto LAB_00059177;
    uVar4 = (local_5c << ((byte)local_58 & 0x1f)) >> bVar11;
    FUN_00013c06(local_c8,iVar15 + uVar4 * 4,2);
    local_58 = *(byte *)(param_3 + 6 + uVar4 * 4) + local_58;
    local_c8 = local_c8 + *(byte *)(param_3 + 7 + uVar4 * 4);
    if (0x20 < local_58) break;
LAB_00059093:
    local_cc = uVar14 - 2;
    if (local_54 < local_4c) {
      if ((int)local_54 - (int)local_50 == 0) goto LAB_00059177;
      bVar18 = (uint *)((int)local_54 - (local_58 >> 3)) < local_50;
      uVar4 = local_58 >> 3;
      if (bVar18) {
        uVar4 = (int)local_54 - (int)local_50;
      }
      local_58 = local_58 + uVar4 * -8;
    }
    else {
      uVar4 = local_58 >> 3;
      local_58 = local_58 & 7;
      bVar18 = false;
    }
  }
  if (local_cc < local_c8) goto LAB_00059181;
LAB_0005901b:
  do {
    uVar4 = (local_5c << ((byte)local_58 & 0x1f)) >> bVar11;
    FUN_00013c06(local_c8,iVar15 + uVar4 * 4,2);
    local_58 = *(byte *)(param_3 + 6 + uVar4 * 4) + local_58;
    local_c8 = local_c8 + *(byte *)(param_3 + 7 + uVar4 * 4);
  } while (local_c8 <= local_cc);
  if (local_c8 < uStack_44) {
LAB_0005918e:
    uVar4 = (local_5c << ((byte)local_58 & 0x1f)) >> bVar11;
    FUN_00013c06(local_c8,iVar15 + uVar4 * 4,1);
    if (*(char *)(param_3 + 7 + uVar4 * 4) == '\x01') {
      local_58 = local_58 + *(byte *)(param_3 + 6 + uVar4 * 4);
    }
    else if (local_58 < 0x20) {
      uVar4 = local_58 + *(byte *)(param_3 + 6 + uVar4 * 4);
      local_58 = 0x20;
      if (uVar4 < 0x20) {
        local_58 = uVar4;
      }
    }
  }
LAB_000591f8:
  if (uStack_70 < 0x21) {
    uVar4 = uStack_48 - 3;
    bVar11 = -local_22 & 0x1f;
    do {
      uVar14 = uStack_48;
      if (puStack_6c < puStack_64) {
        if ((int)puStack_6c - (int)puStack_68 != 0) {
          bVar18 = (uint *)((int)puStack_6c - (uStack_70 >> 3)) < puStack_68;
          uVar17 = uStack_70 >> 3;
          if (bVar18) {
            uVar17 = (int)puStack_6c - (int)puStack_68;
          }
          uStack_70 = uStack_70 + uVar17 * -8;
          goto LAB_0005927e;
        }
LAB_00059357:
        uVar4 = uStack_48 - 2;
        goto LAB_0005935b;
      }
      uVar17 = uStack_70 >> 3;
      uStack_70 = uStack_70 & 7;
      bVar18 = false;
LAB_0005927e:
      puStack_6c = (uint *)((int)puStack_6c - uVar17);
      uStack_74 = *puStack_6c;
      if ((uVar4 <= uVar16) || (bVar18)) {
        if (uStack_70 < 0x21) goto LAB_00059357;
        goto LAB_0005940f;
      }
      uVar14 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar11;
      FUN_00013c06(uVar16,iVar15 + uVar14 * 4,2);
      uStack_70 = *(byte *)(param_3 + 6 + uVar14 * 4) + uStack_70;
      iVar6 = *(byte *)(param_3 + 7 + uVar14 * 4) + uVar16;
      uVar14 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar11;
      FUN_00013c06(iVar6,iVar15 + uVar14 * 4,2);
      uStack_70 = *(byte *)(param_3 + 6 + uVar14 * 4) + uStack_70;
      uVar16 = (uint)*(byte *)(param_3 + 7 + uVar14 * 4) + iVar6;
    } while (uStack_70 < 0x21);
  }
  else {
    bVar11 = -local_22 & 0x1f;
  }
  uVar4 = uStack_48 - 2;
  if (uVar16 <= uVar4) {
LAB_00059427:
    do {
      uVar14 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar11;
      FUN_00013c06(uVar16,iVar15 + uVar14 * 4,2);
      uStack_70 = *(byte *)(param_3 + 6 + uVar14 * 4) + uStack_70;
      uVar16 = uVar16 + *(byte *)(param_3 + 7 + uVar14 * 4);
    } while (uVar16 <= uVar4);
  }
LAB_00059462:
  if (uVar16 < uStack_48) {
    uVar4 = (uStack_74 << ((byte)uStack_70 & 0x1f)) >> bVar11;
    FUN_00013c06(uVar16,iVar15 + uVar4 * 4,1);
    if (*(char *)(param_3 + 7 + uVar4 * 4) == '\x01') {
      uStack_70 = uStack_70 + *(byte *)(param_3 + 6 + uVar4 * 4);
    }
    else if (uStack_70 < 0x20) {
      uVar4 = uStack_70 + *(byte *)(param_3 + 6 + uVar4 * 4);
      uStack_70 = 0x20;
      if (uVar4 < 0x20) {
        uStack_70 = uVar4;
      }
    }
  }
  if (uStack_88 < 0x21) {
    bVar11 = -local_22 & 0x1f;
    do {
      if (puStack_84 < puStack_7c) {
        if ((int)puStack_84 - (int)puStack_80 != 0) {
          bVar18 = (uint *)((int)puStack_84 - (uStack_88 >> 3)) < puStack_80;
          uVar4 = uStack_88 >> 3;
          if (bVar18) {
            uVar4 = (int)puStack_84 - (int)puStack_80;
          }
          uStack_88 = uStack_88 + uVar4 * -8;
          goto LAB_0005954c;
        }
LAB_00059625:
        goto LAB_0005962d;
      }
      uVar4 = uStack_88 >> 3;
      uStack_88 = uStack_88 & 7;
      bVar18 = false;
LAB_0005954c:
      puStack_84 = (uint *)((int)puStack_84 - uVar4);
      uStack_8c = *puStack_84;
      if ((uVar10 - 3 <= local_c4) || (bVar18)) {
        if (uStack_88 < 0x21) goto LAB_00059625;
        break;
      }
      uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar11;
      FUN_00013c06(local_c4,iVar15 + uVar4 * 4,2);
      uStack_88 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_88;
      iVar6 = *(byte *)(param_3 + 7 + uVar4 * 4) + local_c4;
      uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar11;
      FUN_00013c06(iVar6,iVar15 + uVar4 * 4,2);
      uStack_88 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_88;
      local_c4 = (uint)*(byte *)(param_3 + 7 + uVar4 * 4) + iVar6;
    } while (uStack_88 < 0x21);
  }
  else {
    bVar11 = -local_22 & 0x1f;
  }
LAB_000595ef:
  if (local_c4 <= uVar10 - 2) {
LAB_000596f1:
    do {
      uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar11;
      FUN_00013c06(local_c4,iVar15 + uVar4 * 4,2);
      uStack_88 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_88;
      local_c4 = local_c4 + *(byte *)(param_3 + 7 + uVar4 * 4);
    } while (local_c4 <= uVar10 - 2);
  }
joined_r0x00059743:
  if (local_c4 < uVar10) {
    uVar4 = (uStack_8c << ((byte)uStack_88 & 0x1f)) >> bVar11;
    FUN_00013c06(local_c4,iVar15 + uVar4 * 4,1);
    if (*(char *)(param_3 + 7 + uVar4 * 4) == '\x01') {
      uStack_88 = uStack_88 + *(byte *)(param_3 + 6 + uVar4 * 4);
    }
    else if (uStack_88 < 0x20) {
      uVar4 = uStack_88 + *(byte *)(param_3 + 6 + uVar4 * 4);
      uStack_88 = 0x20;
      if (uVar4 < 0x20) {
        uStack_88 = uVar4;
      }
    }
  }
  if (uStack_a0 < 0x21) {
    bVar11 = -local_22 & 0x1f;
    do {
      uVar4 = uStack_34;
      if (puStack_9c < puStack_94) {
        if ((int)puStack_9c - (int)puStack_98 != 0) {
          bVar18 = (uint *)((int)puStack_9c - (uStack_a0 >> 3)) < puStack_98;
          uVar10 = uStack_a0 >> 3;
          if (bVar18) {
            uVar10 = (int)puStack_9c - (int)puStack_98;
          }
          uStack_a0 = uStack_a0 + uVar10 * -8;
          goto LAB_0005981a;
        }
LAB_000598e9:
        uVar10 = uStack_34 - 2;
        goto LAB_000598ed;
      }
      uVar10 = uStack_a0 >> 3;
      uStack_a0 = uStack_a0 & 7;
      bVar18 = false;
LAB_0005981a:
      puStack_9c = (uint *)((int)puStack_9c - uVar10);
      uStack_a4 = *puStack_9c;
      if ((uStack_28 <= uVar13) || (bVar18)) {
        if (uStack_a0 < 0x21) goto LAB_000598e9;
        goto LAB_0005999d;
      }
      uVar4 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> bVar11;
      FUN_00013c06(uVar13,iVar15 + uVar4 * 4,2);
      uStack_a0 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_a0;
      iVar6 = *(byte *)(param_3 + 7 + uVar4 * 4) + uVar13;
      uVar4 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> bVar11;
      FUN_00013c06(iVar6,iVar15 + uVar4 * 4,2);
      uStack_a0 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_a0;
      uVar13 = (uint)*(byte *)(param_3 + 7 + uVar4 * 4) + iVar6;
    } while (uStack_a0 < 0x21);
  }
  else {
    bVar11 = -local_22 & 0x1f;
  }
  uVar10 = uStack_34 - 2;
  if (uVar13 <= uVar10) {
LAB_000599c3:
    do {
      uVar4 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> bVar11;
      FUN_00013c06(uVar13,iVar15 + uVar4 * 4,2);
      uStack_a0 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_a0;
      uVar13 = uVar13 + *(byte *)(param_3 + 7 + uVar4 * 4);
    } while (uVar13 <= uVar10);
  }
LAB_00059a00:
  if (uVar13 < uStack_34) {
    uVar4 = (uStack_a4 << ((byte)uStack_a0 & 0x1f)) >> bVar11;
    FUN_00013c06(uVar13,iVar15 + uVar4 * 4,1);
    if (*(char *)(param_3 + 7 + uVar4 * 4) == '\x01') {
      uStack_a0 = *(byte *)(param_3 + 6 + uVar4 * 4) + uStack_a0;
    }
    else if ((uStack_a0 < 0x20) &&
            (uStack_a0 = uStack_a0 + *(byte *)(param_3 + 6 + uVar4 * 4), 0x1f < uStack_a0)) {
      uStack_a0 = 0x20;
    }
  }
  if ((((puStack_6c != puStack_68 || uStack_70 != 0x20) ||
       (local_54 != local_50 || local_58 != 0x20)) ||
      (puStack_84 != puStack_80 || uStack_88 != 0x20)) ||
      (uStack_a0 ^ 0x20 | (uint)puStack_9c ^ (uint)puStack_98) != 0) {
    local_2c = 0xffffffec;
  }
  return local_2c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00059cb0 FUN_00059cb0 */

void FUN_00059cb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined local_14;
  char local_13;
  
  FUN_00013c06(&local_14,param_5,4,0x59cbc);
  if (local_13 == '\0') {
    FUN_00055730(param_3,param_4,param_5);
  }
  else {
    FUN_00057b60(param_3,param_4,param_5);
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00059d20 FUN_00059d20 */

void FUN_00059d20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined local_14;
  char local_13;
  
  FUN_00013c06(&local_14,param_5,4,0x59d2c);
  if (local_13 == '\0') {
    FUN_00055ce0(param_3,param_4,param_5);
  }
  else {
    FUN_00058190(param_3,param_4,param_5);
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005a080 FUN_0005a080 */

uint FUN_0005a080(undefined4 param_1,undefined4 param_2,uint param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  
  if (param_3 == 0) {
    uVar1 = 0xffffffba;
  }
  else if (param_5 == 0) {
    uVar1 = 0xffffffec;
  }
  else {
    uVar1 = 0xf;
    if (param_5 < param_3) {
      uVar1 = (param_5 << 4) / param_3;
    }
    uVar2 = (param_3 >> 8) * *(int *)(&DAT_0006377c + uVar1 * 0x18) +
            *(int *)(&DAT_00063778 + uVar1 * 0x18);
    if ((uVar2 >> 3) + uVar2 <
        *(int *)(&DAT_00063774 + uVar1 * 0x18) * (param_3 >> 8) +
        *(int *)(&DAT_00063770 + uVar1 * 0x18)) {
      uVar2 = FUN_000573f0(param_1,param_4,param_5,param_6,param_7);
      uVar1 = uVar2;
      if ((uVar2 < 0xffffff89) && (uVar1 = 0xffffffb8, uVar2 < param_5)) {
        uVar1 = FUN_00058190(param_4 + uVar2,param_5 - uVar2,param_1);
      }
    }
    else {
      uVar2 = FUN_000554f0(param_1,param_4,param_5,param_6,param_7);
      uVar1 = uVar2;
      if ((uVar2 < 0xffffff89) && (uVar1 = 0xffffffb8, uVar2 < param_5)) {
        uVar1 = FUN_00055ce0(param_4 + uVar2,param_5 - uVar2,param_1);
      }
    }
  }
  return uVar1;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005ae90 FUN_0005ae90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0005ae90(undefined4 param_1,uint param_2,int param_3)

{
  undefined auVar1 [16];
  undefined local_64 [8];
  longlong local_5c;
  longlong lStack_54;
  uint local_4c;
  int local_48;
  int local_44;
  int local_40;
  
  FUN_00013c0c(local_64,0,0x4c);
  auVar1._8_4_ = param_2;
  auVar1._0_8_ = CONCAT44(param_3,param_2);
  auVar1._12_4_ = param_3;
  local_5c = CONCAT44(param_3,param_2) + _DAT_0004e4c0;
  lStack_54 = auVar1._8_8_ + _UNK_0004e4c8;
  local_48 = param_3;
  local_4c = param_2;
  local_44 = param_2 + 0x7a143579;
  local_40 = param_3 + 0x61c8864e + (uint)(0x85ebca86 < param_2);
  FUN_00013c06(param_1,local_64,0x54);
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005af10 FUN_0005af10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0005af10(uint *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  undefined auVar2 [16];
  undefined auVar3 [16];
  uint uVar4;
  int iVar8;
  undefined8 uVar5;
  uint uVar7;
  uint uVar9;
  uint uVar10;
  undefined auVar6 [16];
  undefined auVar11 [16];
  uint local_84;
  uint local_80;
  undefined8 local_7c;
  int iStack_74;
  int iStack_70;
  uint local_6c;
  uint uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  int local_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  undefined local_4c [16];
  undefined local_3c [16];
  undefined local_2c [16];
  
  uVar1 = *param_1;
  *param_1 = uVar1 + param_3;
  param_1[1] = param_1[1] | (uint)(0xf < (uVar1 + param_3 | param_3));
  uVar1 = param_1[10];
  if (uVar1 + param_3 < 0x10) {
    FUN_00013c06((int)param_1 + uVar1 + 0x18,param_2,param_3);
    param_3 = param_3 + param_1[10];
  }
  else {
    local_80 = param_3 + param_2;
    if (uVar1 != 0) {
      local_7c = CONCAT44(local_7c._4_4_,param_1 + 6);
      FUN_00013c06((int)param_1 + uVar1 + 0x18,param_2,0x10 - uVar1);
      uVar1 = param_1[2];
      FUN_00013c06(&local_84,(int)local_7c,4);
      uVar1 = local_84 * -0x7a143589 + uVar1;
      param_1[2] = (uVar1 * 0x2000 | uVar1 >> 0x13) * -0x61c8864f;
      uVar1 = param_1[3];
      FUN_00013c06(&local_84,param_1 + 7,4);
      uVar1 = local_84 * -0x7a143589 + uVar1;
      param_1[3] = (uVar1 * 0x2000 | uVar1 >> 0x13) * -0x61c8864f;
      uVar1 = param_1[4];
      FUN_00013c06(&local_84,param_1 + 8,4);
      uVar1 = local_84 * -0x7a143589 + uVar1;
      param_1[4] = (uVar1 * 0x2000 | uVar1 >> 0x13) * -0x61c8864f;
      uVar1 = param_1[5];
      FUN_00013c06(&local_84,param_1 + 9,4);
      uVar1 = local_84 * -0x7a143589 + uVar1;
      param_1[5] = (uVar1 * 0x2000 | uVar1 >> 0x13) * -0x61c8864f;
      param_2 = (param_2 - param_1[10]) + 0x10;
      param_1[10] = 0;
    }
    uVar1 = local_80 - 0x10;
    if (uVar1 < param_2) {
      if (local_80 <= param_2) {
        return 0;
      }
    }
    else {
      uVar5 = *(undefined8 *)(param_1 + 2);
      uVar4 = param_1[6];
      uVar7 = param_1[7];
      local_5c = _DAT_0004e4d0;
      uStack_58 = _UNK_0004e4d4;
      uStack_54 = _UNK_0004e4d8;
      uStack_50 = _UNK_0004e4dc;
      uStack_64 = _UNK_0004e4e8;
      uStack_60 = _UNK_0004e4ec;
      do {
        local_7c = uVar5;
        local_6c = uVar4;
        uStack_68 = uVar7;
        FUN_00013c06(&local_84,param_2,4);
        local_2c = ZEXT416(local_84);
        FUN_00013c06(&local_84,param_2 + 4,4);
        local_3c = ZEXT416(local_84);
        FUN_00013c06(&local_84,param_2 + 8,4);
        local_4c = ZEXT416(local_84);
        FUN_00013c06(&local_84,param_2 + 0xc,4);
        auVar11._4_4_ = local_3c._0_4_;
        auVar11._0_4_ = local_3c._0_4_;
        auVar11._8_4_ = local_84;
        auVar11._12_4_ = local_84;
        uVar4 = local_2c._0_4_ * local_5c + (int)local_7c;
        uVar7 = local_3c._0_4_ * local_5c + local_7c._4_4_;
        uVar9 = local_4c._0_4_ * uStack_54 + iStack_74;
        uVar10 = (int)((auVar11._8_8_ & 0xffffffff) * (ulonglong)uStack_54) + iStack_70;
        auVar2._0_4_ = uVar4 >> 0x13;
        auVar2._4_4_ = uVar7 >> 0x13;
        auVar2._8_4_ = uVar9 >> 0x13;
        auVar2._12_4_ = uVar10 >> 0x13;
        auVar6._0_4_ = uVar4 * 0x2000;
        auVar6._4_4_ = uVar7 * 0x2000;
        auVar6._8_4_ = uVar9 * 0x2000;
        auVar6._12_4_ = uVar10 * 0x2000;
        auVar6 = auVar6 | auVar2;
        iVar8 = auVar6._4_4_;
        auVar3._4_4_ = iVar8;
        auVar3._0_4_ = iVar8;
        auVar3._8_4_ = auVar6._12_4_;
        auVar3._12_4_ = auVar6._12_4_;
        uVar4 = (uint)((auVar6._8_8_ & 0xffffffff) * (ulonglong)uStack_64);
        uVar7 = (uint)((auVar3._8_8_ & 0xffffffff) * (ulonglong)uStack_64);
        uVar5 = CONCAT44(iVar8 * local_6c,auVar6._0_4_ * local_6c);
        param_2 = param_2 + 0x10;
      } while (param_2 <= uVar1);
      *(undefined8 *)(param_1 + 2) = uVar5;
      param_1[6] = uVar4;
      param_1[7] = uVar7;
      if (local_80 <= param_2) {
        return 0;
      }
    }
    param_3 = local_80 - param_2;
    FUN_00013c06(param_1 + 6,param_2,param_3);
  }
  param_1[10] = param_3;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005b2f0 FUN_0005b2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0005b2f0(uint *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  uint local_9c;
  uint uStack_98;
  uint local_90;
  undefined8 local_8c;
  undefined8 uStack_84;
  undefined local_7c [16];
  uint local_6c;
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  uint local_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  uint local_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  uint local_3c;
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  longlong local_2c;
  longlong lStack_24;
  
  uVar4 = *param_1;
  *param_1 = *param_1 + param_3;
  param_1[1] = param_1[1] + (uint)CARRY4(uVar4,param_3);
  uVar4 = param_1[0x12];
  if (uVar4 + param_3 < 0x20) {
    FUN_00013c06((int)param_1 + uVar4 + 0x28,param_2,param_3);
    param_3 = param_3 + param_1[0x12];
  }
  else {
    local_90 = param_3 + param_2;
    if (uVar4 != 0) {
      FUN_00013c06((int)param_1 + uVar4 + 0x28,param_2,0x20 - uVar4);
      uVar4 = param_1[2];
      local_8c = CONCAT44(local_8c._4_4_,param_1[3]);
      FUN_00013c06(&local_9c,param_1 + 10,8);
      uVar1 = (uint)((ulonglong)local_9c * 0x27d4eb4f);
      uVar2 = uVar1 + uVar4;
      uVar4 = local_9c * -0x3d4d51c3 + (int)((ulonglong)local_9c * 0x27d4eb4f >> 0x20) +
              uStack_98 * 0x27d4eb4f + (uint)local_8c + (uint)CARRY4(uVar1,uVar4);
      uVar1 = uVar4 >> 1 | uVar2 * -0x80000000;
      lVar7 = (ulonglong)uVar1 * 0x85ebca87;
      param_1[2] = (uint)lVar7;
      param_1[3] = (uVar4 * -0x80000000 | uVar2 >> 1) * -0x7a143579 +
                   uVar1 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20);
      uVar4 = param_1[4];
      uVar1 = param_1[5];
      FUN_00013c06(&local_9c,param_1 + 0xc,8);
      uVar2 = (uint)((ulonglong)local_9c * 0x27d4eb4f);
      uVar3 = uVar2 + uVar4;
      uVar4 = local_9c * -0x3d4d51c3 + (int)((ulonglong)local_9c * 0x27d4eb4f >> 0x20) +
              uStack_98 * 0x27d4eb4f + uVar1 + (uint)CARRY4(uVar2,uVar4);
      uVar1 = uVar4 >> 1 | uVar3 * -0x80000000;
      lVar7 = (ulonglong)uVar1 * 0x85ebca87;
      param_1[4] = (uint)lVar7;
      param_1[5] = (uVar4 * -0x80000000 | uVar3 >> 1) * -0x7a143579 +
                   uVar1 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20);
      uVar4 = param_1[6];
      uVar1 = param_1[7];
      FUN_00013c06(&local_9c,param_1 + 0xe,8);
      uVar2 = (uint)((ulonglong)local_9c * 0x27d4eb4f);
      uVar3 = uVar2 + uVar4;
      uVar4 = local_9c * -0x3d4d51c3 + (int)((ulonglong)local_9c * 0x27d4eb4f >> 0x20) +
              uStack_98 * 0x27d4eb4f + uVar1 + (uint)CARRY4(uVar2,uVar4);
      uVar1 = uVar4 >> 1 | uVar3 * -0x80000000;
      lVar7 = (ulonglong)uVar1 * 0x85ebca87;
      param_1[6] = (uint)lVar7;
      param_1[7] = (uVar4 * -0x80000000 | uVar3 >> 1) * -0x7a143579 +
                   uVar1 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20);
      uVar4 = param_1[8];
      uVar1 = param_1[9];
      FUN_00013c06(&local_9c,param_1 + 0x10,8);
      uVar2 = (uint)((ulonglong)local_9c * 0x27d4eb4f);
      uVar3 = uVar2 + uVar4;
      uVar4 = local_9c * -0x3d4d51c3 + (int)((ulonglong)local_9c * 0x27d4eb4f >> 0x20) +
              uStack_98 * 0x27d4eb4f + uVar1 + (uint)CARRY4(uVar2,uVar4);
      uVar1 = uVar4 >> 1 | uVar3 * -0x80000000;
      lVar7 = (ulonglong)uVar1 * 0x85ebca87;
      param_1[8] = (uint)lVar7;
      param_1[9] = (uVar4 * -0x80000000 | uVar3 >> 1) * -0x7a143579 +
                   uVar1 * -0x61c8864f + (int)((ulonglong)lVar7 >> 0x20);
      param_2 = (param_2 - param_1[0x12]) + 0x20;
      param_1[0x12] = 0;
    }
    if (param_2 + 0x20 <= local_90) {
      uVar4 = local_90 - 0x20;
      local_8c = *(longlong *)(param_1 + 2);
      uStack_84 = *(longlong *)(param_1 + 4);
      lVar7 = *(longlong *)(param_1 + 6);
      lVar8 = *(longlong *)(param_1 + 8);
      local_3c = _DAT_0004e4f0;
      uStack_38 = _UNK_0004e4f4;
      uStack_34 = _UNK_0004e4f8;
      uStack_30 = _UNK_0004e4fc;
      local_4c = _DAT_0004e500;
      uStack_48 = _UNK_0004e504;
      uStack_44 = _UNK_0004e508;
      uStack_40 = _UNK_0004e50c;
      local_5c = _DAT_0004e510;
      uStack_58 = _UNK_0004e514;
      uStack_54 = _UNK_0004e518;
      uStack_50 = _UNK_0004e51c;
      local_6c = _DAT_0004e520;
      uStack_68 = _UNK_0004e524;
      uStack_64 = _UNK_0004e528;
      uStack_60 = _UNK_0004e52c;
      do {
        local_2c = lVar7;
        lStack_24 = lVar8;
        FUN_00013c06(&local_9c,param_2,8);
        local_7c._4_4_ = uStack_98;
        local_7c._0_4_ = local_9c;
        local_7c._8_8_ = 0;
        FUN_00013c06(&local_9c,param_2 + 8,8);
        uVar9 = (local_7c._0_8_ & 0xffffffff) * (ulonglong)local_4c +
                (((ulonglong)local_7c._0_8_ >> 0x20) * (ulonglong)local_4c +
                 (local_7c._0_8_ & 0xffffffff) * (ulonglong)local_3c << 0x20) + local_8c;
        uVar10 = (ulonglong)local_9c * (ulonglong)uStack_44 +
                 ((ulonglong)uStack_98 * (ulonglong)uStack_44 +
                  (ulonglong)local_9c * (ulonglong)uStack_34 << 0x20) + uStack_84;
        uVar5 = uVar9 * 0x80000000;
        uVar6 = uVar10 * 0x80000000;
        uVar9 = uVar9 >> 0x21;
        uVar10 = uVar10 >> 0x21;
        local_8c = (uVar9 | uVar5 & 0xffffffff) * (ulonglong)local_6c +
                   ((uVar5 >> 0x20) * (ulonglong)local_6c +
                    (uVar9 | uVar5 & 0xffffffff) * (ulonglong)local_5c << 0x20);
        uStack_84 = (uVar10 | uVar6 & 0xffffffff) * (ulonglong)uStack_64 +
                    ((uVar6 >> 0x20) * (ulonglong)uStack_64 +
                     (uVar10 | uVar6 & 0xffffffff) * (ulonglong)uStack_54 << 0x20);
        FUN_00013c06(&local_9c,param_2 + 0x10,8);
        local_7c._4_4_ = uStack_98;
        local_7c._0_4_ = local_9c;
        local_7c._8_8_ = 0;
        FUN_00013c06(&local_9c,param_2 + 0x18,8);
        uVar9 = (local_7c._0_8_ & 0xffffffff) * (ulonglong)local_4c +
                (((ulonglong)local_7c._0_8_ >> 0x20) * (ulonglong)local_4c +
                 (local_7c._0_8_ & 0xffffffff) * (ulonglong)local_3c << 0x20) + local_2c;
        uVar10 = (ulonglong)local_9c * (ulonglong)uStack_44 +
                 ((ulonglong)uStack_98 * (ulonglong)uStack_44 +
                  (ulonglong)local_9c * (ulonglong)uStack_34 << 0x20) + lStack_24;
        uVar5 = uVar9 * 0x80000000;
        uVar6 = uVar10 * 0x80000000;
        uVar9 = uVar9 >> 0x21;
        uVar10 = uVar10 >> 0x21;
        lVar7 = (uVar9 | uVar5 & 0xffffffff) * (ulonglong)local_6c +
                ((uVar5 >> 0x20) * (ulonglong)local_6c +
                 (uVar9 | uVar5 & 0xffffffff) * (ulonglong)local_5c << 0x20);
        lVar8 = (uVar10 | uVar6 & 0xffffffff) * (ulonglong)uStack_64 +
                ((uVar6 >> 0x20) * (ulonglong)uStack_64 +
                 (uVar10 | uVar6 & 0xffffffff) * (ulonglong)uStack_54 << 0x20);
        param_2 = param_2 + 0x20;
      } while (param_2 <= uVar4);
      param_1[2] = (uint)local_8c;
      param_1[3] = local_8c._4_4_;
      param_1[4] = (uint)uStack_84;
      param_1[5] = uStack_84._4_4_;
      *(longlong *)(param_1 + 6) = lVar7;
      *(longlong *)(param_1 + 8) = lVar8;
    }
    if (local_90 <= param_2) {
      return 0;
    }
    param_3 = local_90 - param_2;
    FUN_00013c06(param_1 + 10,param_2,param_3);
  }
  param_1[0x12] = param_3;
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005b7b0 FUN_0005b7b0 */

uint FUN_0005b7b0(uint *param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  uint uVar33;
  uint uVar34;
  uint *puVar35;
  uint uVar36;
  uint *puVar37;
  uint uVar38;
  uint uVar39;
  int iVar40;
  uint uVar41;
  uint local_20;
  uint local_1c;
  int local_18;
  
  uVar41 = *param_1;
  uVar29 = param_1[0x12];
  puVar1 = (uint *)((int)param_1 + uVar29 + 0x28);
  if (param_1[1] < (uint)(uVar41 < 0x20)) {
    uVar25 = param_1[6] + 0x165667c5;
    iVar40 = param_1[7] + 0x27d4eb2f + (uint)(0xe9a9983a < param_1[6]);
  }
  else {
    uVar26 = param_1[2];
    uVar28 = param_1[3];
    uVar27 = param_1[4];
    uVar2 = param_1[5];
    uVar30 = uVar26 << 1 | uVar28 >> 0x1f;
    uVar15 = uVar27 << 7 | uVar2 >> 0x19;
    uVar16 = uVar15 + uVar30;
    uVar3 = param_1[6];
    uVar4 = param_1[7];
    uVar38 = uVar3 << 0xc | uVar4 >> 0x14;
    uVar39 = uVar38 + uVar16;
    uVar5 = param_1[8];
    uVar6 = param_1[9];
    uVar36 = uVar5 << 0x12 | uVar6 >> 0xe;
    uVar31 = uVar28 * 0x27d4eb4f +
             (int)((ulonglong)uVar26 * 0x27d4eb4f >> 0x20) + uVar26 * -0x3d4d51c3 >> 1 |
             (uint)((ulonglong)uVar26 * 0x80000000);
    lVar7 = (ulonglong)uVar31 * 0x85ebca87;
    uVar17 = (uint)lVar7 ^ uVar36 + uVar39;
    lVar8 = (ulonglong)uVar17 * 0x85ebca87;
    uVar18 = (uint)lVar8;
    uVar32 = uVar2 * 0x27d4eb4f +
             (int)((ulonglong)uVar27 * 0x27d4eb4f >> 0x20) + uVar27 * -0x3d4d51c3 >> 1 |
             (uint)((ulonglong)uVar27 * 0x80000000);
    lVar9 = (ulonglong)uVar32 * 0x85ebca87;
    uVar19 = (uint)lVar9 ^ uVar18 + 0xc2b2ae63;
    lVar10 = (ulonglong)uVar19 * 0x85ebca87;
    uVar20 = (uint)lVar10;
    uVar33 = uVar4 * 0x27d4eb4f + (int)((ulonglong)uVar3 * 0x27d4eb4f >> 0x20) + uVar3 * -0x3d4d51c3
             >> 1 | (uint)((ulonglong)uVar3 * 0x80000000);
    lVar11 = (ulonglong)uVar33 * 0x85ebca87;
    uVar21 = (uint)lVar11 ^ uVar20 + 0xc2b2ae63;
    lVar12 = (ulonglong)uVar21 * 0x85ebca87;
    uVar22 = (uint)lVar12;
    uVar34 = uVar6 * 0x27d4eb4f + (int)((ulonglong)uVar5 * 0x27d4eb4f >> 0x20) + uVar5 * -0x3d4d51c3
             >> 1 | (uint)((ulonglong)uVar5 * 0x80000000);
    lVar13 = (ulonglong)uVar34 * 0x85ebca87;
    uVar23 = (uint)lVar13 ^ uVar22 + 0xc2b2ae63;
    lVar14 = (ulonglong)uVar23 * 0x85ebca87;
    uVar24 = (uint)lVar14;
    uVar25 = uVar24 + 0xc2b2ae63;
    iVar40 = (int)((ulonglong)lVar14 >> 0x20) + uVar23 * -0x61c8864f +
             ((uVar6 * -0x80000000 +
              (int)((ulonglong)uVar5 * 0x80000000 >> 0x20) + uVar5 * -0x6c158a59) * -0x7a143579 +
              (int)((ulonglong)lVar13 >> 0x20) + uVar34 * -0x61c8864f ^
             (int)((ulonglong)lVar12 >> 0x20) + uVar21 * -0x61c8864f +
             ((uVar4 * -0x80000000 +
              (int)((ulonglong)uVar3 * 0x80000000 >> 0x20) + uVar3 * -0x6c158a59) * -0x7a143579 +
              (int)((ulonglong)lVar11 >> 0x20) + uVar33 * -0x61c8864f ^
             (int)((ulonglong)lVar10 >> 0x20) + uVar19 * -0x61c8864f +
             ((uVar2 * -0x80000000 +
              (int)((ulonglong)uVar27 * 0x80000000 >> 0x20) + uVar27 * -0x6c158a59) * -0x7a143579 +
              (int)((ulonglong)lVar9 >> 0x20) + uVar32 * -0x61c8864f ^
             ((uVar28 * -0x80000000 +
              (int)((ulonglong)uVar26 * 0x80000000 >> 0x20) + uVar26 * -0x6c158a59) * -0x7a143579 +
              (int)((ulonglong)lVar7 >> 0x20) + uVar31 * -0x61c8864f ^
             (uVar6 << 0x12 | uVar5 >> 0xe) +
             (uVar4 << 0xc | uVar3 >> 0x14) +
             (uVar2 << 7 | uVar27 >> 0x19) + (uVar28 << 1 | uVar26 >> 0x1f) +
             (uint)CARRY4(uVar15,uVar30) + (uint)CARRY4(uVar38,uVar16) + (uint)CARRY4(uVar36,uVar39)
             ) * -0x7a143579 + (int)((ulonglong)lVar8 >> 0x20) + uVar17 * -0x61c8864f + -0x7a143589
             + (uint)(0x3d4d519c < uVar18)) * -0x7a143579 + -0x7a143589 +
             (uint)(0x3d4d519c < uVar20)) * -0x7a143579 + -0x7a143589 + (uint)(0x3d4d519c < uVar22))
             * -0x7a143579 + -0x7a143589 + (uint)(0x3d4d519c < uVar24);
  }
  uVar26 = uVar25 + uVar41;
  uVar41 = iVar40 + param_1[1] + (uint)CARRY4(uVar25,uVar41);
  puVar35 = param_1 + 0xc;
  puVar37 = param_1 + 10;
  while (puVar35 <= puVar1) {
    FUN_00013c06(&local_1c,puVar37,8);
    uVar25 = local_18 * 0x27d4eb4f +
             (int)((ulonglong)local_1c * 0x27d4eb4f >> 0x20) + local_1c * -0x3d4d51c3 >> 1 |
             (uint)((ulonglong)local_1c * 0x80000000);
    lVar7 = (ulonglong)uVar25 * 0x85ebca87;
    uVar41 = (local_18 * -0x80000000 +
             (int)((ulonglong)local_1c * 0x80000000 >> 0x20) + local_1c * -0x6c158a59) * -0x7a143579
             + (int)((ulonglong)lVar7 >> 0x20) + uVar25 * -0x61c8864f ^ uVar41;
    uVar25 = (uint)lVar7 ^ uVar26;
    uVar28 = uVar25 << 0x1b | uVar41 >> 5;
    lVar7 = (ulonglong)uVar28 * 0x85ebca87;
    uVar27 = (uint)lVar7;
    uVar26 = uVar27 + 0xc2b2ae63;
    uVar41 = (uVar41 << 0x1b | uVar25 >> 5) * -0x7a143579 +
             (int)((ulonglong)lVar7 >> 0x20) + uVar28 * -0x61c8864f + -0x7a143589 +
             (uint)(0x3d4d519c < uVar27);
    puVar35 = puVar37 + 4;
    puVar37 = puVar37 + 2;
  }
  if (puVar37 + 1 <= puVar1) {
    FUN_00013c06(&local_20,puVar37,4);
    uVar41 = (int)((ulonglong)local_20 * 0x85ebca87 >> 0x20) + local_20 * -0x61c8864f ^ uVar41;
    uVar25 = (uint)((ulonglong)local_20 * 0x85ebca87) ^ uVar26;
    uVar28 = uVar25 << 0x17 | uVar41 >> 9;
    lVar7 = (ulonglong)uVar28 * 0x27d4eb4f;
    uVar27 = (uint)lVar7;
    uVar26 = uVar27 + 0x9e3779f9;
    uVar41 = (uVar41 << 0x17 | uVar25 >> 9) * 0x27d4eb4f +
             (int)((ulonglong)lVar7 >> 0x20) + uVar28 * -0x3d4d51c3 + 0x165667b1 +
             (uint)(0x61c88606 < uVar27);
    puVar37 = puVar37 + 1;
  }
  if (puVar37 < puVar1) {
    do {
      lVar7 = (ulonglong)(uint)*(byte *)puVar37 * 0x165667c5;
      uVar41 = (int)((ulonglong)lVar7 >> 0x20) + (uint)*(byte *)puVar37 * 0x27d4eb2f ^ uVar41;
      uVar25 = (uint)lVar7 ^ uVar26;
      uVar28 = uVar25 << 0xb | uVar41 >> 0x15;
      lVar7 = (ulonglong)uVar28 * 0x85ebca87;
      uVar26 = (uint)lVar7;
      uVar41 = (uVar41 << 0xb | uVar25 >> 0x15) * -0x7a143579 +
               (int)((ulonglong)lVar7 >> 0x20) + uVar28 * -0x61c8864f;
      puVar37 = (uint *)((int)puVar37 + 1);
    } while ((uint *)(uVar29 + 0x28 + (int)param_1) != puVar37);
  }
  uVar26 = uVar41 >> 1 ^ uVar26;
  lVar7 = (ulonglong)uVar26 * 0x27d4eb4f;
  uVar29 = (uint)lVar7;
  uVar41 = uVar41 * 0x27d4eb4f + (int)((ulonglong)lVar7 >> 0x20) + uVar26 * -0x3d4d51c3;
  uVar29 = (uVar41 * 8 | uVar29 >> 0x1d) ^ uVar29;
  lVar7 = (ulonglong)uVar29 * 0x9e3779f9;
  return (uint)lVar7 ^
         (int)((ulonglong)lVar7 >> 0x20) + uVar29 * 0x165667b1 +
         (uVar41 >> 0x1d ^ uVar41) * -0x61c88607;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005beec FUN_0005beec */

/* WARNING: Type propagation algorithm not settling */

uint ** FUN_0005beec(uint param_1)

{
  byte *pbVar1;
  uint **ppuVar2;
  uint uVar3;
  uint uVar4;
  uint **ppuVar5;
  uint **ppuVar6;
  int iVar7;
  uint **ppuVar8;
  uint *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint **ppuVar15;
  int iVar16;
  uint **ppuVar17;
  uint *puVar18;
  uint uVar19;
  byte bVar20;
  uint **ppuVar21;
  uint uVar22;
  uint uVar23;
  uint **ppuVar24;
  uint **local_28;
  uint local_24;
  
  ppuVar15 = DAT_000e0bf4;
  ppuVar6 = DAT_000e0bf0;
  uVar23 = DAT_000e0be4;
  local_24 = DAT_000e0be0;
  uVar4 = DAT_000e0bdc;
  if (param_1 < 0xf5) {
    uVar11 = 0x10;
    if (10 < param_1) {
      uVar11 = param_1 + 0xb & 0xfffffff8;
    }
    bVar20 = (byte)(uVar11 >> 3);
    uVar3 = DAT_000e0bdc >> (bVar20 & 0x1f);
    if ((uVar3 & 3) != 0) {
      uVar4 = (~uVar3 & 1) + (uVar11 >> 3);
      puVar9 = *(uint **)(&DAT_000e0c08 + uVar4 * 8);
      ppuVar6 = (uint **)puVar9[2];
      if (ppuVar6[3] == puVar9) {
        ppuVar15 = (uint **)(uVar4 * 8 + 0xe0c00);
        if (ppuVar6 == ppuVar15) {
          DAT_000e0bdc = DAT_000e0bdc & ~(1 << (uVar4 & 0x1f));
        }
        else {
          if (ppuVar6 < DAT_000e0bec) goto LAB_0005d501;
          *(uint ***)(&DAT_000e0c08 + uVar4 * 8) = ppuVar6;
          ppuVar6[3] = (uint *)ppuVar15;
        }
        puVar9[1] = uVar4 * 8 + 3;
        *(byte *)(puVar9 + uVar4 * 2 + 1) = *(byte *)(puVar9 + uVar4 * 2 + 1) | 1;
        return (uint **)(puVar9 + 2);
      }
      goto LAB_0005d501;
    }
    if (DAT_000e0be4 < uVar11) {
      if (uVar3 != 0) {
        uVar19 = 2 << (bVar20 & 0x1f);
        uVar3 = (-uVar19 | uVar19) & uVar3 << (bVar20 & 0x1f);
        uVar3 = (-uVar3 & uVar3) - 1;
        uVar22 = uVar3 >> 0xc & 0x10;
        uVar3 = uVar3 >> (sbyte)uVar22;
        uVar19 = uVar3 >> 5 & 8;
        uVar3 = uVar3 >> (sbyte)uVar19;
        uVar12 = uVar3 >> 2 & 4;
        uVar3 = uVar3 >> (sbyte)uVar12;
        uVar13 = uVar3 >> 1 & 2;
        uVar3 = uVar3 >> (sbyte)uVar13;
        uVar14 = uVar3 >> 1 & 1;
        uVar3 = (uVar3 >> (sbyte)uVar14) + (uVar22 | uVar19 | uVar12 | uVar13 | uVar14);
        puVar9 = *(uint **)(&DAT_000e0c08 + uVar3 * 8);
        ppuVar6 = (uint **)puVar9[2];
        if (ppuVar6[3] == puVar9) {
          ppuVar15 = (uint **)(uVar3 * 8 + 0xe0c00);
          if (ppuVar6 == ppuVar15) {
            uVar4 = DAT_000e0bdc & ~(1 << (uVar3 & 0x1f));
            DAT_000e0bdc = uVar4;
          }
          else {
            if (ppuVar6 < DAT_000e0bec) goto LAB_0005d506;
            *(uint ***)(&DAT_000e0c08 + uVar3 * 8) = ppuVar6;
            ppuVar6[3] = (uint *)ppuVar15;
          }
          uVar19 = uVar3 * 8 - uVar11;
          puVar9[1] = uVar11 | 3;
          *(uint *)((int)puVar9 + uVar11 + 4) = uVar19 | 1;
          puVar9[uVar3 * 2] = uVar19;
          if (uVar23 != 0) {
            uVar3 = uVar23 & 0xfffffff8;
            if ((uVar4 >> (uVar23 >> 3 & 0x1f) & 1) == 0) {
              DAT_000e0bdc = uVar4 | 1 << ((byte)(uVar23 >> 3) & 0x1f);
              ppuVar6 = (uint **)(uVar3 + 0xe0c00);
            }
            else {
              ppuVar6 = *(uint ***)(&DAT_000e0c08 + uVar3);
              if (*(uint ***)(&DAT_000e0c08 + uVar3) < DAT_000e0bec) goto LAB_0005d506;
            }
            *(uint ***)(&DAT_000e0c08 + uVar3) = DAT_000e0bf0;
            ppuVar6[3] = (uint *)DAT_000e0bf0;
            DAT_000e0bf0[2] = (uint *)ppuVar6;
            DAT_000e0bf0[3] = (uint *)(uint **)(uVar3 + 0xe0c00);
          }
          DAT_000e0be4 = uVar19;
          DAT_000e0bf0 = (uint **)(uVar11 + (int)puVar9);
          return (uint **)(puVar9 + 2);
        }
        goto LAB_0005d3a9;
      }
      if (DAT_000e0be0 != 0) {
        uVar22 = (-DAT_000e0be0 & DAT_000e0be0) - 1;
        uVar3 = uVar22 >> 0xc & 0x10;
        uVar22 = uVar22 >> (sbyte)uVar3;
        uVar19 = uVar22 >> 5 & 8;
        uVar22 = uVar22 >> (sbyte)uVar19;
        uVar12 = uVar22 >> 2 & 4;
        uVar22 = uVar22 >> (sbyte)uVar12;
        uVar13 = uVar22 >> 1 & 2;
        uVar22 = uVar22 >> (sbyte)uVar13;
        uVar14 = uVar22 >> 1 & 1;
        ppuVar6 = (uint **)(&DAT_000e0d08)
                           [(uVar22 >> (sbyte)uVar14) + (uVar3 | uVar19 | uVar12 | uVar13 | uVar14)]
        ;
        uVar3 = ((uint)ppuVar6[1] & 0xfffffffc) - uVar11;
        local_28 = ppuVar6;
        while ((ppuVar15 = (uint **)ppuVar6[4], ppuVar15 != (uint **)0x0 ||
               (ppuVar15 = (uint **)ppuVar6[5], ppuVar15 != (uint **)0x0))) {
          uVar19 = ((uint)ppuVar15[1] & 0xfffffffc) - uVar11;
          ppuVar6 = ppuVar15;
          if (uVar19 < uVar3) {
            uVar3 = uVar19;
            local_28 = ppuVar15;
          }
        }
        if ((local_28 < DAT_000e0bec) ||
           (ppuVar6 = (uint **)((int)local_28 + uVar11), ppuVar6 <= local_28)) goto LAB_0005d506;
        ppuVar15 = (uint **)local_28[3];
        ppuVar8 = (uint **)local_28[6];
        if (ppuVar15 == local_28) {
          if ((uint **)local_28[5] == (uint **)0x0) {
            if ((uint **)local_28[4] == (uint **)0x0) {
              ppuVar15 = (uint **)0x0;
              goto LAB_0005c9e8;
            }
            ppuVar5 = local_28 + 4;
            ppuVar17 = (uint **)local_28[4];
          }
          else {
            ppuVar5 = local_28 + 5;
            ppuVar17 = (uint **)local_28[5];
          }
          do {
            do {
              ppuVar15 = ppuVar17;
              ppuVar21 = ppuVar5;
              ppuVar5 = ppuVar15 + 5;
              ppuVar17 = (uint **)ppuVar15[5];
            } while ((uint **)ppuVar15[5] != (uint **)0x0);
            ppuVar5 = ppuVar15 + 4;
            ppuVar17 = (uint **)ppuVar15[4];
          } while ((uint **)ppuVar15[4] != (uint **)0x0);
          if (ppuVar21 < DAT_000e0bec) goto LAB_0005d506;
          *ppuVar21 = (uint *)0x0;
        }
        else {
          ppuVar5 = (uint **)local_28[2];
          if ((((uint **)ppuVar5[3] != local_28) || ((uint **)ppuVar15[2] != local_28)) ||
             (ppuVar5 < DAT_000e0bec)) goto LAB_0005d506;
          ppuVar5[3] = (uint *)ppuVar15;
          ppuVar15[2] = (uint *)ppuVar5;
        }
LAB_0005c9e8:
        if (ppuVar8 != (uint **)0x0) {
          puVar9 = local_28[7];
          if (local_28 == (uint **)(&DAT_000e0d08)[(int)puVar9]) {
            (&DAT_000e0d08)[(int)puVar9] = ppuVar15;
            if (ppuVar15 == (uint **)0x0) {
              DAT_000e0be0 = local_24 & ~(1 << ((uint)puVar9 & 0x1f));
            }
            else {
LAB_0005ca3c:
              ppuVar5 = DAT_000e0bec;
              if (ppuVar15 < DAT_000e0bec) goto LAB_0005d506;
              ppuVar15[6] = (uint *)ppuVar8;
              ppuVar8 = (uint **)local_28[4];
              if (ppuVar8 != (uint **)0x0) {
                if (ppuVar8 < ppuVar5) goto LAB_0005d506;
                ppuVar15[4] = (uint *)ppuVar8;
                ppuVar8[6] = (uint *)ppuVar15;
              }
              ppuVar8 = (uint **)local_28[5];
              if (ppuVar8 != (uint **)0x0) {
                if (ppuVar8 < DAT_000e0bec) goto LAB_0005d506;
                ppuVar15[5] = (uint *)ppuVar8;
                ppuVar8[6] = (uint *)ppuVar15;
              }
            }
          }
          else {
            if (ppuVar8 < DAT_000e0bec) goto LAB_0005d506;
            ppuVar8[((uint **)ppuVar8[4] != local_28) + 4] = (uint *)ppuVar15;
            if (ppuVar15 != (uint **)0x0) goto LAB_0005ca3c;
          }
        }
        if (uVar3 < 0x10) {
          local_28[1] = (uint *)(uVar3 + uVar11 | 3);
          pbVar1 = (byte *)((int)local_28 + uVar3 + uVar11 + 4);
          *pbVar1 = *pbVar1 | 1;
          uVar3 = DAT_000e0be4;
          ppuVar6 = DAT_000e0bf0;
        }
        else {
          local_28[1] = (uint *)(uVar11 | 3);
          *(uint *)((int)local_28 + uVar11 + 4) = uVar3 | 1;
          *(uint *)((int)ppuVar6 + uVar3) = uVar3;
          if (uVar23 == 0) goto LAB_0005c45b;
          uVar11 = uVar23 & 0xfffffff8;
          if ((uVar4 >> (uVar23 >> 3 & 0x1f) & 1) == 0) {
            DAT_000e0bdc = 1 << ((byte)(uVar23 >> 3) & 0x1f) | uVar4;
            ppuVar15 = (uint **)(uVar11 + 0xe0c00);
          }
          else {
            ppuVar15 = *(uint ***)(&DAT_000e0c08 + uVar11);
            if (*(uint ***)(&DAT_000e0c08 + uVar11) < DAT_000e0bec) goto LAB_0005d506;
          }
          *(uint ***)(&DAT_000e0c08 + uVar11) = DAT_000e0bf0;
          ppuVar15[3] = (uint *)DAT_000e0bf0;
          DAT_000e0bf0[2] = (uint *)ppuVar15;
          DAT_000e0bf0[3] = (uint *)(uint **)(uVar11 + 0xe0c00);
        }
        goto LAB_0005c45b;
      }
    }
  }
  else if (param_1 < 0xffffffc0) {
    uVar11 = param_1 + 0xb & 0xfffffff8;
    if (DAT_000e0be0 != 0) {
      ppuVar8 = (uint **)0x0;
      uVar3 = param_1 + 0xb >> 8;
      uVar4 = 0;
      if ((uVar3 != 0) && (uVar4 = 0x1f, uVar11 < 0x1000000)) {
        uVar4 = uVar3 + 0xfff00 >> 0x10 & 8;
        iVar7 = uVar3 << (sbyte)uVar4;
        uVar3 = iVar7 + 0x7f000U >> 0x10 & 4;
        iVar7 = iVar7 << (sbyte)uVar3;
        uVar19 = iVar7 + 0x3c000U >> 0x10 & 2;
        iVar7 = ((uint)(iVar7 << (sbyte)uVar19) >> 0xf) - (uVar4 | uVar3 | uVar19);
        uVar4 = (uVar11 >> ((char)iVar7 + 0x15U & 0x1f) & 1) + 0x1c + iVar7 * 2;
      }
      uVar3 = -uVar11;
      ppuVar5 = (uint **)(&DAT_000e0d08)[uVar4];
      if (ppuVar5 == (uint **)0x0) {
        local_28 = (uint **)0x0;
      }
      else {
        bVar20 = 0x19 - (char)(uVar4 >> 1);
        ppuVar8 = (uint **)0x0;
        if (uVar4 == 0x1f) {
          bVar20 = 0;
        }
        iVar7 = uVar11 << (bVar20 & 0x1f);
        local_28 = (uint **)0x0;
        do {
          uVar19 = ((uint)ppuVar5[1] & 0xfffffffc) - uVar11;
          if ((uVar19 < uVar3) && (uVar3 = uVar19, local_28 = ppuVar5, uVar19 == 0)) {
            uVar3 = 0;
            goto LAB_0005c27e;
          }
          ppuVar17 = (uint **)ppuVar5[5];
          ppuVar5 = (uint **)ppuVar5[4 - (iVar7 >> 0x1f)];
          ppuVar21 = ppuVar17;
          if (ppuVar17 == ppuVar5) {
            ppuVar21 = ppuVar8;
          }
          if (ppuVar17 != (uint **)0x0) {
            ppuVar8 = ppuVar21;
          }
          iVar7 = iVar7 << (ppuVar5 != (uint **)0x0);
        } while (ppuVar5 != (uint **)0x0);
      }
      if (((uint)ppuVar8 | (uint)local_28) == 0) {
        uVar4 = 2 << ((byte)uVar4 & 0x1f);
        uVar4 = (-uVar4 | uVar4) & DAT_000e0be0;
        if (uVar4 == 0) goto LAB_0005c308;
        uVar4 = (-uVar4 & uVar4) - 1;
        uVar22 = uVar4 >> 0xc & 0x10;
        uVar4 = uVar4 >> (sbyte)uVar22;
        uVar19 = uVar4 >> 5 & 8;
        uVar4 = uVar4 >> (sbyte)uVar19;
        uVar12 = uVar4 >> 2 & 4;
        uVar4 = uVar4 >> (sbyte)uVar12;
        uVar13 = uVar4 >> 1 & 2;
        uVar4 = uVar4 >> (sbyte)uVar13;
        uVar14 = uVar4 >> 1 & 1;
        ppuVar8 = (uint **)(&DAT_000e0d08)
                           [(uVar4 >> (sbyte)uVar14) + (uVar22 | uVar19 | uVar12 | uVar13 | uVar14)]
        ;
      }
      while (ppuVar5 = ppuVar8, ppuVar5 != (uint **)0x0) {
LAB_0005c27e:
        uVar4 = ((uint)ppuVar5[1] & 0xfffffffc) - uVar11;
        if (uVar4 < uVar3) {
          local_28 = ppuVar5;
          uVar3 = uVar4;
        }
        ppuVar8 = (uint **)ppuVar5[4];
        if ((uint **)ppuVar5[4] == (uint **)0x0) {
          ppuVar8 = (uint **)ppuVar5[5];
        }
      }
      if ((local_28 != (uint **)0x0) && (uVar3 < DAT_000e0be4 - uVar11)) {
        if ((local_28 < DAT_000e0bec) ||
           (ppuVar6 = (uint **)((int)local_28 + uVar11), ppuVar6 <= local_28)) goto LAB_0005d501;
        ppuVar15 = (uint **)local_28[3];
        ppuVar8 = (uint **)local_28[6];
        if (ppuVar15 == local_28) {
          if ((uint **)local_28[5] == (uint **)0x0) {
            if ((uint **)local_28[4] == (uint **)0x0) {
              ppuVar15 = (uint **)0x0;
              goto LAB_0005c73d;
            }
            ppuVar5 = local_28 + 4;
            ppuVar17 = (uint **)local_28[4];
          }
          else {
            ppuVar5 = local_28 + 5;
            ppuVar17 = (uint **)local_28[5];
          }
          do {
            do {
              ppuVar15 = ppuVar17;
              ppuVar21 = ppuVar5;
              ppuVar5 = ppuVar15 + 5;
              ppuVar17 = (uint **)ppuVar15[5];
            } while ((uint **)ppuVar15[5] != (uint **)0x0);
            ppuVar5 = ppuVar15 + 4;
            ppuVar17 = (uint **)ppuVar15[4];
          } while ((uint **)ppuVar15[4] != (uint **)0x0);
          if (ppuVar21 < DAT_000e0bec) goto LAB_0005d506;
          *ppuVar21 = (uint *)0x0;
        }
        else {
          ppuVar5 = (uint **)local_28[2];
          if ((((uint **)ppuVar5[3] != local_28) || ((uint **)ppuVar15[2] != local_28)) ||
             (ppuVar5 < DAT_000e0bec)) goto LAB_0005d501;
          ppuVar5[3] = (uint *)ppuVar15;
          ppuVar15[2] = (uint *)ppuVar5;
        }
LAB_0005c73d:
        if (ppuVar8 != (uint **)0x0) {
          puVar9 = local_28[7];
          if (local_28 == (uint **)(&DAT_000e0d08)[(int)puVar9]) {
            (&DAT_000e0d08)[(int)puVar9] = ppuVar15;
            if (ppuVar15 == (uint **)0x0) {
              local_24 = local_24 & ~(1 << ((uint)puVar9 & 0x1f));
              DAT_000e0be0 = local_24;
            }
            else {
LAB_0005c77e:
              ppuVar5 = DAT_000e0bec;
              if (ppuVar15 < DAT_000e0bec) goto LAB_0005d501;
              ppuVar15[6] = (uint *)ppuVar8;
              ppuVar8 = (uint **)local_28[4];
              if (ppuVar8 != (uint **)0x0) {
                if (ppuVar8 < ppuVar5) goto LAB_0005d501;
                ppuVar15[4] = (uint *)ppuVar8;
                ppuVar8[6] = (uint *)ppuVar15;
              }
              ppuVar8 = (uint **)local_28[5];
              if (ppuVar8 != (uint **)0x0) {
                if (ppuVar8 < DAT_000e0bec) goto LAB_0005d501;
                ppuVar15[5] = (uint *)ppuVar8;
                ppuVar8[6] = (uint *)ppuVar15;
              }
            }
          }
          else {
            if (ppuVar8 < DAT_000e0bec) goto LAB_0005d501;
            ppuVar8[((uint **)ppuVar8[4] != local_28) + 4] = (uint *)ppuVar15;
            if (ppuVar15 != (uint **)0x0) goto LAB_0005c77e;
          }
        }
        if (uVar3 < 0x10) {
          local_28[1] = (uint *)(uVar3 + uVar11 | 3);
          pbVar1 = (byte *)((int)local_28 + uVar3 + uVar11 + 4);
          *pbVar1 = *pbVar1 | 1;
          uVar3 = DAT_000e0be4;
          ppuVar6 = DAT_000e0bf0;
        }
        else {
          local_28[1] = (uint *)(uVar11 | 3);
          *(uint *)((int)local_28 + uVar11 + 4) = uVar3 | 1;
          *(uint *)((int)ppuVar6 + uVar3) = uVar3;
          if (0xff < uVar3) {
            uVar4 = uVar3 >> 8;
            puVar9 = (uint *)0x0;
            if ((uVar4 != 0) && (puVar9 = (uint *)0x1f, uVar3 < 0x1000000)) {
              uVar11 = uVar4 + 0xfff00 >> 0x10 & 8;
              iVar7 = uVar4 << (sbyte)uVar11;
              uVar4 = iVar7 + 0x7f000U >> 0x10 & 4;
              iVar7 = iVar7 << (sbyte)uVar4;
              uVar23 = iVar7 + 0x3c000U >> 0x10 & 2;
              iVar7 = ((uint)(iVar7 << (sbyte)uVar23) >> 0xf) - (uVar11 | uVar4 | uVar23);
              puVar9 = (uint *)((uVar3 >> ((char)iVar7 + 0x15U & 0x1f) & 1) + 0x1c + iVar7 * 2);
            }
            ppuVar6[7] = puVar9;
            ppuVar6[5] = (uint *)0x0;
            ppuVar6[4] = (uint *)0x0;
            if ((local_24 >> ((uint)puVar9 & 0x1f) & 1) == 0) {
              DAT_000e0be0 = local_24 | 1 << ((byte)puVar9 & 0x1f);
              (&DAT_000e0d08)[(int)puVar9] = ppuVar6;
              ppuVar6[6] = &DAT_000e0d08 + (int)puVar9;
              ppuVar6[3] = (uint *)ppuVar6;
              ppuVar6[2] = (uint *)ppuVar6;
              uVar3 = DAT_000e0be4;
              ppuVar6 = DAT_000e0bf0;
            }
            else {
              bVar20 = 0x19 - (char)((uint)puVar9 >> 1);
              if (puVar9 == (uint *)0x1f) {
                bVar20 = 0;
              }
              iVar7 = uVar3 << (bVar20 & 0x1f);
              ppuVar15 = (uint **)(&DAT_000e0d08)[(int)puVar9];
              do {
                ppuVar8 = ppuVar15;
                if (((uint)ppuVar8[1] & 0xfffffffc) == uVar3) {
                  ppuVar15 = (uint **)ppuVar8[2];
                  if ((ppuVar15 < DAT_000e0bec) || (ppuVar8 < DAT_000e0bec)) goto LAB_0005d501;
                  ppuVar15[3] = (uint *)ppuVar6;
                  ppuVar8[2] = (uint *)ppuVar6;
                  ppuVar6[2] = (uint *)ppuVar15;
                  ppuVar6[3] = (uint *)ppuVar8;
                  ppuVar6[6] = (uint *)0x0;
                  uVar3 = DAT_000e0be4;
                  ppuVar6 = DAT_000e0bf0;
                  goto LAB_0005c45b;
                }
                iVar16 = iVar7 >> 0x1f;
                iVar7 = iVar7 * 2;
                ppuVar15 = (uint **)ppuVar8[4 - iVar16];
              } while ((uint **)ppuVar8[4 - iVar16] != (uint **)0x0);
              if (ppuVar8 + (4 - iVar16) < DAT_000e0bec) goto LAB_0005d501;
              ppuVar8[4 - iVar16] = (uint *)ppuVar6;
              ppuVar6[6] = (uint *)ppuVar8;
              ppuVar6[3] = (uint *)ppuVar6;
              ppuVar6[2] = (uint *)ppuVar6;
              uVar3 = DAT_000e0be4;
              ppuVar6 = DAT_000e0bf0;
            }
            goto LAB_0005c45b;
          }
          uVar4 = uVar3 & 0xfffffff8;
          if ((DAT_000e0bdc >> (uVar3 >> 3 & 0x1f) & 1) == 0) {
            DAT_000e0bdc = DAT_000e0bdc | 1 << ((byte)(uVar3 >> 3) & 0x1f);
            ppuVar15 = (uint **)(uVar4 + 0xe0c00);
          }
          else {
            ppuVar15 = *(uint ***)(&DAT_000e0c08 + uVar4);
            if (*(uint ***)(&DAT_000e0c08 + uVar4) < DAT_000e0bec) goto LAB_0005d501;
          }
          *(uint ***)(&DAT_000e0c08 + uVar4) = ppuVar6;
          ppuVar15[3] = (uint *)ppuVar6;
          ppuVar6[2] = (uint *)ppuVar15;
          ppuVar6[3] = (uint *)(uint **)(uVar4 + 0xe0c00);
          uVar3 = DAT_000e0be4;
          ppuVar6 = DAT_000e0bf0;
        }
        goto LAB_0005c45b;
      }
    }
  }
  else {
    uVar11 = 0xffffffff;
  }
LAB_0005c308:
  uVar4 = DAT_000e0be4 - uVar11;
  if (DAT_000e0be4 < uVar11) {
    uVar4 = DAT_000e0be8 - uVar11;
    if (DAT_000e0be8 < uVar11 || uVar4 == 0) {
      FUN_0005e701();
      if ((((DAT_000e0d90 & 1) != 0) && (DAT_000e0db0 <= uVar11)) &&
         ((uVar4 = -DAT_000e0dac & uVar11 + 0x1f + DAT_000e0dac, uVar11 < uVar4 &&
          (ppuVar6 = (uint **)FUN_00013c18(0,uVar4,3,0x22,0xffffffff,0),
          ppuVar6 != (uint **)0xffffffff)))) {
        uVar23 = -(int)ppuVar6 - 8U & 7;
        if (((uint)(ppuVar6 + 2) & 7) == 0) {
          uVar23 = 0;
        }
        iVar7 = uVar4 - uVar23;
        *(uint *)((int)ppuVar6 + uVar23) = uVar23 | 1;
        *(uint *)((int)ppuVar6 + uVar23 + 4) = iVar7 - 0x10U | 2;
        local_28 = (uint **)((int)ppuVar6 + uVar23);
        *(undefined4 *)(iVar7 + -0xc + (int)local_28) = 7;
        *(undefined4 *)(iVar7 + -8 + (int)local_28) = 0;
        if (ppuVar6 < DAT_000e0bec) {
          DAT_000e0bec = ppuVar6;
        }
        DAT_000e0d88 = uVar4 + DAT_000e0d88;
        uVar3 = DAT_000e0be4;
        ppuVar6 = DAT_000e0bf0;
        if (uRam000e0d8c < DAT_000e0d88) {
          uRam000e0d8c = DAT_000e0d88;
        }
        goto LAB_0005c45b;
      }
      if ((DAT_000e0d90 & 4) == 0) {
        if (DAT_000e0bf4 != (uint **)0x0) {
          ppuVar6 = (uint **)&DAT_000e0d94;
          do {
            if ((*ppuVar6 <= DAT_000e0bf4) &&
               (DAT_000e0bf4 < (uint **)((int)*ppuVar6 + (int)ppuVar6[1]))) {
              uVar4 = -DAT_000e0dac & (uVar11 - DAT_000e0be8) + 0x29 + DAT_000e0dac;
              if (0x7ffffffe < uVar4) goto LAB_0005cb7e;
              ppuVar15 = (uint **)FUN_00013c1e(uVar4);
              ppuVar8 = ppuVar15;
              if (ppuVar15 != (uint **)((int)*ppuVar6 + (int)ppuVar6[1])) goto LAB_0005c67c;
              goto joined_r0x0005ca97;
            }
            ppuVar6 = (uint **)ppuVar6[2];
          } while (ppuVar6 != (uint **)0x0);
        }
        ppuVar15 = (uint **)FUN_00013c1e(0);
        if (ppuVar15 == (uint **)0xffffffff) {
LAB_0005cb7e:
          DAT_000e0d90 = DAT_000e0d90 | 4;
          goto LAB_0005cb89;
        }
        uVar4 = -DAT_000e0dac & uVar11 + 0x29 + DAT_000e0dac;
        if ((DAT_000e0da8 - 1U & (uint)ppuVar15) != 0) {
          uVar4 = (uVar4 - (int)ppuVar15) + (DAT_000e0da8 + (int)ppuVar15 & -DAT_000e0da8);
        }
        if (0x7ffffffe < uVar4) goto LAB_0005cb7e;
        ppuVar8 = (uint **)FUN_00013c1e(uVar4);
        if (ppuVar8 == ppuVar15) {
          uVar23 = 0;
        }
        else {
LAB_0005c67c:
          ppuVar15 = ppuVar8;
          if ((uVar4 < 0x7fffffff) && (ppuVar15 != (uint **)0xffffffff)) {
            uVar23 = 0;
            iVar7 = (uVar11 + 0x29) - uVar4;
            if ((uVar4 <= uVar11 + 0x29 && iVar7 != 0) &&
               (uVar3 = -DAT_000e0dac & iVar7 + DAT_000e0dac, uVar3 < 0x7fffffff)) {
              iVar7 = FUN_00013c1e(uVar3);
              if (iVar7 == -1) {
                FUN_00013c1e(-uVar4);
                goto LAB_0005cb7e;
              }
              uVar4 = uVar4 + uVar3;
              uVar23 = 0;
            }
          }
          else {
joined_r0x0005ca97:
            uVar23 = 0;
            if (ppuVar15 == (uint **)0xffffffff) goto LAB_0005cb7e;
          }
        }
      }
      else {
LAB_0005cb89:
        uVar4 = -DAT_000e0dac & DAT_000e0dac + 0x29 + uVar11;
        uVar23 = 0;
        if (uVar11 < uVar4) {
          ppuVar15 = (uint **)FUN_00013c18(0,uVar4,3,0x22,0xffffffff,0);
          uVar23 = (uint)(ppuVar15 != (uint **)0xffffffff);
          if (ppuVar15 != (uint **)0xffffffff) goto LAB_0005cc39;
          uVar4 = -DAT_000e0dac & uVar11 + 0x29 + DAT_000e0dac;
        }
        if (0x7ffffffe < uVar4) goto LAB_0005d1da;
        ppuVar15 = (uint **)FUN_00013c1e(uVar4);
        ppuVar6 = (uint **)FUN_00013c1e(0);
        if ((((ppuVar6 <= ppuVar15) || (ppuVar15 == (uint **)0xffffffff)) ||
            (ppuVar6 == (uint **)0xffffffff)) ||
           (uVar4 = (int)ppuVar6 - (int)ppuVar15, uVar4 <= uVar11 + 0x28)) goto LAB_0005d1da;
      }
LAB_0005cc39:
      ppuVar6 = DAT_000e0bf4;
      DAT_000e0d88 = DAT_000e0d88 + uVar4;
      if (uRam000e0d8c < DAT_000e0d88) {
        uRam000e0d8c = DAT_000e0d88;
      }
      if (DAT_000e0bf4 == (uint **)0x0) {
        iVar7 = 0xe0c00;
        uRam000e0bfc = 0x58585858;
        if (DAT_000e0da4 == '\0') {
          uRam000e0bfc = 0;
        }
        iVar16 = 0x20;
        DAT_000e0bec = ppuVar15;
        DAT_000e0d94 = ppuVar15;
        DAT_000e0d98 = uVar4;
        DAT_000e0da0 = uVar23;
        do {
          *(int *)(iVar7 + 0xc) = iVar7;
          *(int *)(iVar7 + 8) = iVar7;
          iVar7 = iVar7 + 8;
          iVar16 = iVar16 + -1;
        } while (iVar16 != 0);
        uVar23 = -(int)ppuVar15 - 8U & 7;
        if (((uint)(ppuVar15 + 2) & 7) == 0) {
          uVar23 = 0;
        }
        DAT_000e0bf4 = (uint **)((int)ppuVar15 + uVar23);
        DAT_000e0be8 = (uVar4 - 0x28) - uVar23;
        *(uint *)((int)ppuVar15 + uVar23 + 4) = DAT_000e0be8 | 1;
        *(undefined4 *)((int)ppuVar15 + (uVar4 - 0x24)) = 0x28;
        DAT_000e0bf8 = DAT_000e0db4;
        goto LAB_0005d19f;
      }
      puVar10 = &DAT_000e0d94;
      do {
        if (ppuVar15 == (uint **)((int)(uint **)*puVar10 + puVar10[1])) {
          if ((((puVar10[3] & 8) == 0) && ((puVar10[3] & 1) == uVar23)) &&
             ((DAT_000e0bf4 < ppuVar15 && ((uint **)*puVar10 <= DAT_000e0bf4)))) {
            puVar10[1] = puVar10[1] + uVar4;
            iVar7 = uVar4 + DAT_000e0be8;
            uVar4 = -(int)DAT_000e0bf4 - 8U & 7;
            if (((uint)(DAT_000e0bf4 + 2) & 7) == 0) {
              uVar4 = 0;
            }
            DAT_000e0be8 = iVar7 - uVar4;
            puVar9 = (uint *)((int)DAT_000e0bf4 + uVar4 + 4);
            DAT_000e0bf4 = (uint **)((int)DAT_000e0bf4 + uVar4);
            *puVar9 = DAT_000e0be8 | 1;
            *(undefined4 *)((int)ppuVar6 + iVar7 + 4) = 0x28;
            DAT_000e0bf8 = DAT_000e0db4;
            goto LAB_0005d19f;
          }
          break;
        }
        puVar10 = (undefined4 *)puVar10[2];
      } while (puVar10 != (undefined4 *)0x0);
      if (ppuVar15 < DAT_000e0bec) {
        DAT_000e0bec = ppuVar15;
      }
      ppuVar5 = DAT_000e0bec;
      puVar9 = (uint *)((int)ppuVar15 + uVar4);
      ppuVar8 = (uint **)&DAT_000e0d94;
      while (*ppuVar8 != puVar9) {
        ppuVar8 = (uint **)ppuVar8[2];
        if (ppuVar8 == (uint **)0x0) goto LAB_0005ced7;
      }
      if ((((uint)ppuVar8[3] & 8) != 0) || (((uint)ppuVar8[3] & 1) != uVar23)) goto LAB_0005ced7;
      *ppuVar8 = (uint *)ppuVar15;
      ppuVar8[1] = (uint *)((int)ppuVar8[1] + uVar4);
      uVar4 = -(int)ppuVar15 - 8U & 7;
      if (((uint)(ppuVar15 + 2) & 7) == 0) {
        uVar4 = 0;
      }
      uVar23 = -(int)puVar9 - 8U & 7;
      if (((uint)(puVar9 + 2) & 7) == 0) {
        uVar23 = 0;
      }
      local_28 = (uint **)((int)ppuVar15 + uVar4);
      ppuVar17 = (uint **)(uVar23 + (int)puVar9);
      uVar23 = (int)ppuVar17 + (-uVar11 - (int)local_28);
      ppuVar8 = (uint **)((int)local_28 + uVar11);
      *(uint *)((int)ppuVar15 + uVar4 + 4) = uVar11 | 3;
      if (ppuVar6 == ppuVar17) {
        DAT_000e0be8 = uVar23 + DAT_000e0be8;
        DAT_000e0bf4 = ppuVar8;
        ppuVar8[1] = (uint *)(DAT_000e0be8 | 1);
        uVar3 = DAT_000e0be4;
        ppuVar6 = DAT_000e0bf0;
        goto LAB_0005c45b;
      }
      if (DAT_000e0bf0 == ppuVar17) {
        uVar23 = uVar23 + DAT_000e0be4;
        DAT_000e0be4 = uVar23;
        DAT_000e0bf0 = ppuVar8;
        ppuVar8[1] = (uint *)(uVar23 | 1);
        *(uint *)((int)ppuVar8 + uVar23) = uVar23;
        uVar3 = DAT_000e0be4;
        ppuVar6 = DAT_000e0bf0;
        goto LAB_0005c45b;
      }
      puVar9 = ppuVar17[1];
      if (((uint)puVar9 & 2) != 0) goto LAB_0005d363;
      if (puVar9 < (uint *)0x100) {
        ppuVar6 = (uint **)ppuVar17[2];
        if (((uint **)ppuVar6[3] != ppuVar17) ||
           (ppuVar15 = (uint **)ppuVar17[3], (uint **)ppuVar15[2] != ppuVar17)) goto LAB_0005d506;
        if (ppuVar6 == ppuVar15) {
          bVar20 = (byte)((uint)puVar9 >> 3) & 0x1f;
          DAT_000e0bdc = DAT_000e0bdc & (-2 << bVar20 | 0xfffffffeU >> 0x20 - bVar20);
          goto LAB_0005d350;
        }
        ppuVar21 = (uint **)(((uint)puVar9 & 0xfffffff8) + 0xe0c00);
        if (((ppuVar6 != ppuVar21) && (ppuVar6 < ppuVar5)) ||
           ((ppuVar15 != ppuVar21 && (ppuVar15 < ppuVar5)))) goto LAB_0005d501;
        ppuVar6[3] = (uint *)ppuVar15;
        ppuVar15[2] = (uint *)ppuVar6;
        goto LAB_0005d350;
      }
      ppuVar6 = (uint **)ppuVar17[3];
      ppuVar15 = (uint **)ppuVar17[6];
      if (ppuVar6 != ppuVar17) {
        ppuVar21 = (uint **)ppuVar17[2];
        if ((((uint **)ppuVar21[3] != ppuVar17) || ((uint **)ppuVar6[2] != ppuVar17)) ||
           (ppuVar21 < ppuVar5)) goto LAB_0005d501;
        ppuVar21[3] = (uint *)ppuVar6;
        ppuVar6[2] = (uint *)ppuVar21;
        goto LAB_0005d2b7;
      }
      if ((uint **)ppuVar17[5] == (uint **)0x0) {
        ppuVar21 = (uint **)ppuVar17[4];
        ppuVar2 = ppuVar17 + 4;
        if (ppuVar21 != (uint **)0x0) goto LAB_0005d28a;
        ppuVar6 = (uint **)0x0;
        goto LAB_0005d2b7;
      }
      ppuVar21 = (uint **)ppuVar17[5];
      ppuVar2 = ppuVar17 + 5;
LAB_0005d28a:
      do {
        do {
          ppuVar24 = ppuVar2;
          ppuVar6 = ppuVar21;
          ppuVar21 = (uint **)ppuVar6[5];
          ppuVar2 = ppuVar6 + 5;
        } while ((uint **)ppuVar6[5] != (uint **)0x0);
        ppuVar21 = (uint **)ppuVar6[4];
        ppuVar2 = ppuVar6 + 4;
      } while ((uint **)ppuVar6[4] != (uint **)0x0);
      if (ppuVar24 < ppuVar5) {
LAB_0005d506:
                    /* WARNING: Subroutine does not return */
        FUN_00013c2a();
      }
      *ppuVar24 = (uint *)0x0;
LAB_0005d2b7:
      if (ppuVar15 != (uint **)0x0) {
        puVar18 = ppuVar17[7];
        if ((uint **)(&DAT_000e0d08)[(int)puVar18] == ppuVar17) {
          (&DAT_000e0d08)[(int)puVar18] = ppuVar6;
          if (ppuVar6 == (uint **)0x0) {
            bVar20 = (byte)puVar18 & 0x1f;
            DAT_000e0be0 = DAT_000e0be0 & (-2 << bVar20 | 0xfffffffeU >> 0x20 - bVar20);
          }
          else {
LAB_0005d2fe:
            ppuVar5 = DAT_000e0bec;
            if (ppuVar6 < DAT_000e0bec) goto LAB_0005d501;
            ppuVar6[6] = (uint *)ppuVar15;
            ppuVar15 = (uint **)ppuVar17[4];
            if (ppuVar15 != (uint **)0x0) {
              if (ppuVar15 < ppuVar5) goto LAB_0005d501;
              ppuVar6[4] = (uint *)ppuVar15;
              ppuVar15[6] = (uint *)ppuVar6;
            }
            ppuVar15 = (uint **)ppuVar17[5];
            if (ppuVar15 != (uint **)0x0) {
              if (ppuVar15 < DAT_000e0bec) goto LAB_0005d501;
              ppuVar6[5] = (uint *)ppuVar15;
              ppuVar15[6] = (uint *)ppuVar6;
            }
          }
        }
        else {
          if (ppuVar15 < DAT_000e0bec) goto LAB_0005d501;
          ppuVar15[((uint **)ppuVar15[4] != ppuVar17) + 4] = (uint *)ppuVar6;
          if (ppuVar6 != (uint **)0x0) goto LAB_0005d2fe;
        }
      }
LAB_0005d350:
      ppuVar17 = (uint **)((int)ppuVar17 + ((uint)puVar9 & 0xfffffffc));
      uVar23 = uVar23 + ((uint)puVar9 & 0xfffffffc);
LAB_0005d363:
      *(byte *)(ppuVar17 + 1) = *(byte *)(ppuVar17 + 1) & 0xfe;
      ppuVar8[1] = (uint *)(uVar23 | 1);
      *(uint *)((int)ppuVar8 + uVar23) = uVar23;
      if (uVar23 < 0x100) {
        uVar4 = uVar23 & 0xfffffff8;
        if ((DAT_000e0bdc >> (uVar23 >> 3 & 0x1f) & 1) == 0) {
          DAT_000e0bdc = DAT_000e0bdc | 1 << ((byte)(uVar23 >> 3) & 0x1f);
          puVar9 = (uint *)(uVar4 + 0xe0c00);
        }
        else {
          puVar9 = *(uint **)(&DAT_000e0c08 + uVar4);
          if (*(uint **)(&DAT_000e0c08 + uVar4) < DAT_000e0bec) {
LAB_0005d3a9:
                    /* WARNING: Subroutine does not return */
            FUN_00013c2a();
          }
        }
        *(uint ***)(&DAT_000e0c08 + uVar4) = ppuVar8;
        puVar9[3] = (uint)ppuVar8;
        ppuVar8[2] = puVar9;
        ppuVar8[3] = (uint *)(uVar4 + 0xe0c00);
        uVar3 = DAT_000e0be4;
        ppuVar6 = DAT_000e0bf0;
      }
      else {
        uVar4 = uVar23 >> 8;
        puVar9 = (uint *)0x0;
        if ((uVar4 != 0) && (puVar9 = (uint *)0x1f, uVar23 < 0x1000000)) {
          uVar11 = uVar4 + 0xfff00 >> 0x10 & 8;
          iVar7 = uVar4 << (sbyte)uVar11;
          uVar4 = iVar7 + 0x7f000U >> 0x10 & 4;
          iVar7 = iVar7 << (sbyte)uVar4;
          uVar3 = iVar7 + 0x3c000U >> 0x10 & 2;
          iVar7 = ((uint)(iVar7 << (sbyte)uVar3) >> 0xf) - (uVar11 | uVar4 | uVar3);
          puVar9 = (uint *)((uVar23 >> ((char)iVar7 + 0x15U & 0x1f) & 1) + 0x1c + iVar7 * 2);
        }
        ppuVar8[7] = puVar9;
        ppuVar8[5] = (uint *)0x0;
        ppuVar8[4] = (uint *)0x0;
        if ((DAT_000e0be0 >> ((uint)puVar9 & 0x1f) & 1) == 0) {
          DAT_000e0be0 = DAT_000e0be0 | 1 << ((byte)puVar9 & 0x1f);
          (&DAT_000e0d08)[(int)puVar9] = ppuVar8;
          ppuVar8[6] = &DAT_000e0d08 + (int)puVar9;
        }
        else {
          bVar20 = 0x19 - (char)((uint)puVar9 >> 1);
          if (puVar9 == (uint *)0x1f) {
            bVar20 = 0;
          }
          iVar7 = uVar23 << (bVar20 & 0x1f);
          ppuVar6 = (uint **)(&DAT_000e0d08)[(int)puVar9];
          do {
            ppuVar15 = ppuVar6;
            if (((uint)ppuVar15[1] & 0xfffffffc) == uVar23) {
              ppuVar6 = (uint **)ppuVar15[2];
              if ((ppuVar6 < DAT_000e0bec) || (ppuVar15 < DAT_000e0bec)) goto LAB_0005d501;
              ppuVar6[3] = (uint *)ppuVar8;
              ppuVar15[2] = (uint *)ppuVar8;
              ppuVar8[2] = (uint *)ppuVar6;
              ppuVar8[3] = (uint *)ppuVar15;
              ppuVar8[6] = (uint *)0x0;
              uVar3 = DAT_000e0be4;
              ppuVar6 = DAT_000e0bf0;
              goto LAB_0005c45b;
            }
            iVar16 = iVar7 >> 0x1f;
            iVar7 = iVar7 * 2;
            ppuVar6 = (uint **)ppuVar15[4 - iVar16];
          } while ((uint **)ppuVar15[4 - iVar16] != (uint **)0x0);
          if (ppuVar15 + (4 - iVar16) < DAT_000e0bec) {
LAB_0005d501:
                    /* WARNING: Subroutine does not return */
            FUN_00013c2a();
          }
          ppuVar15[4 - iVar16] = (uint *)ppuVar8;
          ppuVar8[6] = (uint *)ppuVar15;
        }
        ppuVar8[3] = (uint *)ppuVar8;
        ppuVar8[2] = (uint *)ppuVar8;
        uVar3 = DAT_000e0be4;
        ppuVar6 = DAT_000e0bf0;
      }
      goto LAB_0005c45b;
    }
    puVar9 = (uint *)((int)DAT_000e0bf4 + uVar11 + 4);
    DAT_000e0be8 = uVar4;
    DAT_000e0bf4 = (uint **)((int)DAT_000e0bf4 + uVar11);
    *puVar9 = uVar4 | 1;
    ppuVar6 = ppuVar15;
  }
  else {
    if (uVar4 < 0x10) {
      DAT_000e0be4 = 0;
      DAT_000e0bf0 = (uint **)0x0;
      ppuVar6[1] = (uint *)(uVar23 | 3);
      pbVar1 = (byte *)((int)ppuVar6 + uVar23 + 4);
      *pbVar1 = *pbVar1 | 1;
      local_28 = ppuVar6;
      uVar3 = DAT_000e0be4;
      ppuVar6 = DAT_000e0bf0;
      goto LAB_0005c45b;
    }
    puVar9 = (uint *)((int)DAT_000e0bf0 + uVar11 + 4);
    DAT_000e0be4 = uVar4;
    DAT_000e0bf0 = (uint **)((int)DAT_000e0bf0 + uVar11);
    *puVar9 = uVar4 | 1;
    *(uint *)((int)ppuVar6 + uVar23) = uVar4;
  }
  ppuVar6[1] = (uint *)(uVar11 | 3);
  local_28 = ppuVar6;
  uVar3 = DAT_000e0be4;
  ppuVar6 = DAT_000e0bf0;
LAB_0005c45b:
  DAT_000e0bf0 = ppuVar6;
  DAT_000e0be4 = uVar3;
  return local_28 + 2;
LAB_0005ced7:
  for (puVar10 = &DAT_000e0d94;
      (DAT_000e0bf4 < (uint **)*puVar10 ||
      (ppuVar8 = (uint **)((int)(uint **)*puVar10 + puVar10[1]), ppuVar8 <= DAT_000e0bf4));
      puVar10 = (undefined4 *)puVar10[2]) {
  }
  uVar3 = 0x27U - (int)ppuVar8 & 7;
  if (((int)ppuVar8 - 0x27U & 7) == 0) {
    uVar3 = 0;
  }
  ppuVar5 = (uint **)((int)ppuVar8 + (uVar3 - 0x2f));
  if (ppuVar5 < DAT_000e0bf4 + 4) {
    ppuVar5 = DAT_000e0bf4;
  }
  uVar3 = -(int)ppuVar15 - 8U & 7;
  if (((uint)(ppuVar15 + 2) & 7) == 0) {
    uVar3 = 0;
  }
  DAT_000e0bf4 = (uint **)((int)ppuVar15 + uVar3);
  DAT_000e0be8 = (uVar4 - 0x28) - uVar3;
  *(uint *)((int)ppuVar15 + uVar3 + 4) = DAT_000e0be8 | 1;
  *(undefined4 *)((int)ppuVar15 + (uVar4 - 0x24)) = 0x28;
  DAT_000e0bf8 = DAT_000e0db4;
  ppuVar5[1] = (uint *)0x1b;
  *(ulonglong *)(ppuVar5 + 4) = CONCAT44(DAT_000e0da0,DAT_000e0d9c);
  *(ulonglong *)(ppuVar5 + 2) = CONCAT44(DAT_000e0d98,DAT_000e0d94);
  ppuVar17 = ppuVar5 + 7;
  DAT_000e0d94 = ppuVar15;
  DAT_000e0d98 = uVar4;
  DAT_000e0d9c = ppuVar5 + 2;
  DAT_000e0da0 = uVar23;
  do {
    *ppuVar17 = (uint *)0x7;
    ppuVar17 = ppuVar17 + 1;
  } while (ppuVar17 < ppuVar8);
  puVar9 = (uint *)((int)ppuVar5 - (int)ppuVar6);
  if (puVar9 != (uint *)0x0) {
    *(byte *)(ppuVar5 + 1) = *(byte *)(ppuVar5 + 1) & 0xfe;
    ppuVar6[1] = (uint *)((uint)puVar9 | 1);
    *ppuVar5 = puVar9;
    if (puVar9 < (uint *)0x100) {
      uVar4 = (uint)puVar9 & 0xfffffff8;
      if ((DAT_000e0bdc >> ((uint)puVar9 >> 3 & 0x1f) & 1) == 0) {
        DAT_000e0bdc = DAT_000e0bdc | 1 << ((byte)((uint)puVar9 >> 3) & 0x1f);
        ppuVar15 = (uint **)(uVar4 + 0xe0c00);
      }
      else {
        ppuVar15 = *(uint ***)(&DAT_000e0c08 + uVar4);
        if (*(uint ***)(&DAT_000e0c08 + uVar4) < DAT_000e0bec) goto LAB_0005d506;
      }
      *(uint ***)(&DAT_000e0c08 + uVar4) = ppuVar6;
      ppuVar15[3] = (uint *)ppuVar6;
      ppuVar6[2] = (uint *)ppuVar15;
      ppuVar6[3] = (uint *)(uint **)(uVar4 + 0xe0c00);
    }
    else {
      uVar4 = (uint)puVar9 >> 8;
      puVar18 = (uint *)0x0;
      if ((uVar4 != 0) && (puVar18 = (uint *)0x1f, puVar9 < (uint *)0x1000000)) {
        uVar3 = uVar4 + 0xfff00 >> 0x10 & 8;
        iVar7 = uVar4 << (sbyte)uVar3;
        uVar4 = iVar7 + 0x7f000U >> 0x10 & 4;
        iVar7 = iVar7 << (sbyte)uVar4;
        uVar23 = iVar7 + 0x3c000U >> 0x10 & 2;
        iVar7 = ((uint)(iVar7 << (sbyte)uVar23) >> 0xf) - (uVar3 | uVar4 | uVar23);
        puVar18 = (uint *)(((uint)puVar9 >> ((char)iVar7 + 0x15U & 0x1f) & 1) + 0x1c + iVar7 * 2);
      }
      ppuVar6[7] = puVar18;
      ppuVar6[5] = (uint *)0x0;
      ppuVar6[4] = (uint *)0x0;
      if ((DAT_000e0be0 >> ((uint)puVar18 & 0x1f) & 1) == 0) {
        DAT_000e0be0 = DAT_000e0be0 | 1 << ((byte)puVar18 & 0x1f);
        (&DAT_000e0d08)[(int)puVar18] = ppuVar6;
        ppuVar6[6] = &DAT_000e0d08 + (int)puVar18;
      }
      else {
        bVar20 = 0x19 - (char)((uint)puVar18 >> 1);
        if (puVar18 == (uint *)0x1f) {
          bVar20 = 0;
        }
        iVar7 = (int)puVar9 << (bVar20 & 0x1f);
        ppuVar15 = (uint **)(&DAT_000e0d08)[(int)puVar18];
        do {
          ppuVar8 = ppuVar15;
          if ((uint *)((uint)ppuVar8[1] & 0xfffffffc) == puVar9) {
            ppuVar15 = (uint **)ppuVar8[2];
            if ((ppuVar15 < DAT_000e0bec) || (ppuVar8 < DAT_000e0bec)) goto LAB_0005d506;
            ppuVar15[3] = (uint *)ppuVar6;
            ppuVar8[2] = (uint *)ppuVar6;
            ppuVar6[2] = (uint *)ppuVar15;
            ppuVar6[3] = (uint *)ppuVar8;
            ppuVar6[6] = (uint *)0x0;
            goto LAB_0005d19f;
          }
          iVar16 = iVar7 >> 0x1f;
          iVar7 = iVar7 * 2;
          ppuVar15 = (uint **)ppuVar8[4 - iVar16];
        } while ((uint **)ppuVar8[4 - iVar16] != (uint **)0x0);
        if (ppuVar8 + (4 - iVar16) < DAT_000e0bec) goto LAB_0005d506;
        ppuVar8[4 - iVar16] = (uint *)ppuVar6;
        ppuVar6[6] = (uint *)ppuVar8;
      }
      ppuVar6[3] = (uint *)ppuVar6;
      ppuVar6[2] = (uint *)ppuVar6;
    }
  }
LAB_0005d19f:
  local_28 = DAT_000e0bf4;
  uVar4 = DAT_000e0be8 - uVar11;
  if (DAT_000e0be8 < uVar11 || uVar4 == 0) {
LAB_0005d1da:
    puVar10 = (undefined4 *)FUN_00013c24();
    *puVar10 = 0xc;
    return (uint **)0x0;
  }
  puVar9 = (uint *)((int)DAT_000e0bf4 + uVar11 + 4);
  DAT_000e0be8 = uVar4;
  DAT_000e0bf4 = (uint **)((int)DAT_000e0bf4 + uVar11);
  *puVar9 = uVar4 | 1;
  local_28[1] = (uint *)(uVar11 | 3);
  uVar3 = DAT_000e0be4;
  ppuVar6 = DAT_000e0bf0;
  goto LAB_0005c45b;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005d50e FUN_0005d50e */

uint ** FUN_0005d50e(int param_1)

{
  uint **ppuVar1;
  uint **ppuVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint uVar9;
  uint **ppuVar10;
  uint **ppuVar11;
  uint uVar12;
  byte bVar13;
  uint **ppuVar14;
  uint uVar15;
  int iVar16;
  uint **ppuVar17;
  int *piVar18;
  int *piVar19;
  uint **ppuVar20;
  uint *puVar21;
  uint *local_34;
  int local_30;
  uint **local_14;
  
  if (param_1 == 0) {
    return (uint **)0x0;
  }
  ppuVar14 = (uint **)(param_1 + -8);
  if ((ppuVar14 < DAT_000e0bec) || (uVar15 = *(uint *)(param_1 + -4), (uVar15 & 2) == 0))
  goto LAB_0005db90;
  local_14 = (uint **)(uVar15 & 0xfffffffc);
  ppuVar20 = (uint **)((int)ppuVar14 + (int)local_14);
  if ((uVar15 & 1) == 0) {
    puVar8 = *ppuVar14;
    if (((uint)puVar8 & 1) != 0) {
      iVar16 = (int)local_14 + ((uint)puVar8 & 0xfffffffe) + 0x10;
      ppuVar14 = (uint **)FUN_00013c30((int)ppuVar14 - ((uint)puVar8 & 0xfffffffe),iVar16);
      if (ppuVar14 != (uint **)0x0) {
        return ppuVar14;
      }
      DAT_000e0d88 = DAT_000e0d88 - iVar16;
      return (uint **)0x0;
    }
    ppuVar14 = (uint **)((int)ppuVar14 - (int)puVar8);
    if (ppuVar14 < DAT_000e0bec) goto LAB_0005db90;
    local_14 = (uint **)((int)local_14 + (int)puVar8);
    if (DAT_000e0bf0 == ppuVar14) {
      if (((uint)ppuVar20[1] & 3) == 3) {
        DAT_000e0be4 = local_14;
        ppuVar20[1] = (uint *)((uint)ppuVar20[1] & 0xfffffffe);
        goto LAB_0005d9a5;
      }
    }
    else if (puVar8 < 0x100) {
      ppuVar17 = (uint **)ppuVar14[2];
      if (((uint **)ppuVar17[3] != ppuVar14) ||
         (ppuVar2 = (uint **)ppuVar14[3], (uint **)ppuVar2[2] != ppuVar14)) goto LAB_0005db90;
      if (ppuVar17 == ppuVar2) {
        bVar13 = (byte)((uint)puVar8 >> 3) & 0x1f;
        DAT_000e0bdc = DAT_000e0bdc & (-2 << bVar13 | 0xfffffffeU >> 0x20 - bVar13);
      }
      else {
        ppuVar1 = (uint **)(((uint)puVar8 & 0xfffffff8) + 0xe0c00);
        if (((ppuVar17 != ppuVar1) && (ppuVar17 < DAT_000e0bec)) ||
           ((ppuVar2 != ppuVar1 && (ppuVar2 < DAT_000e0bec)))) goto LAB_0005db90;
        ppuVar17[3] = (uint *)ppuVar2;
        ppuVar2[2] = (uint *)ppuVar17;
      }
    }
    else {
      ppuVar17 = (uint **)ppuVar14[3];
      ppuVar2 = (uint **)ppuVar14[6];
      if (ppuVar17 == ppuVar14) {
        if ((uint **)ppuVar14[5] == (uint **)0x0) {
          ppuVar1 = (uint **)ppuVar14[4];
          ppuVar11 = ppuVar14 + 4;
          if (ppuVar1 == (uint **)0x0) {
            ppuVar17 = (uint **)0x0;
            goto LAB_0005d6cf;
          }
        }
        else {
          ppuVar11 = ppuVar14 + 5;
          ppuVar1 = (uint **)ppuVar14[5];
        }
        do {
          do {
            ppuVar17 = ppuVar1;
            ppuVar10 = ppuVar11;
            ppuVar11 = ppuVar17 + 5;
            ppuVar1 = (uint **)ppuVar17[5];
          } while ((uint **)ppuVar17[5] != (uint **)0x0);
          ppuVar11 = ppuVar17 + 4;
          ppuVar1 = (uint **)ppuVar17[4];
        } while ((uint **)ppuVar17[4] != (uint **)0x0);
        if (ppuVar10 < DAT_000e0bec) {
                    /* WARNING: Subroutine does not return */
          FUN_00013c2a();
        }
        *ppuVar10 = (uint *)0x0;
      }
      else {
        ppuVar1 = (uint **)ppuVar14[2];
        if ((((uint **)ppuVar1[3] != ppuVar14) || ((uint **)ppuVar17[2] != ppuVar14)) ||
           (ppuVar1 < DAT_000e0bec)) goto LAB_0005db90;
        ppuVar1[3] = (uint *)ppuVar17;
        ppuVar17[2] = (uint *)ppuVar1;
      }
LAB_0005d6cf:
      if (ppuVar2 != (uint **)0x0) {
        puVar8 = ppuVar14[7];
        if ((uint **)(&DAT_000e0d08)[(int)puVar8] == ppuVar14) {
          (&DAT_000e0d08)[(int)puVar8] = ppuVar17;
          if (ppuVar17 == (uint **)0x0) {
            bVar13 = (byte)puVar8 & 0x1f;
            DAT_000e0be0 = DAT_000e0be0 & (-2 << bVar13 | 0xfffffffeU >> 0x20 - bVar13);
          }
          else {
LAB_0005d70c:
            ppuVar1 = DAT_000e0bec;
            if (ppuVar17 < DAT_000e0bec) goto LAB_0005db90;
            ppuVar17[6] = (uint *)ppuVar2;
            ppuVar2 = (uint **)ppuVar14[4];
            if (ppuVar2 != (uint **)0x0) {
              if (ppuVar2 < ppuVar1) goto LAB_0005db90;
              ppuVar17[4] = (uint *)ppuVar2;
              ppuVar2[6] = (uint *)ppuVar17;
            }
            ppuVar2 = (uint **)ppuVar14[5];
            if (ppuVar2 != (uint **)0x0) {
              if (ppuVar2 < DAT_000e0bec) goto LAB_0005db90;
              ppuVar17[5] = (uint *)ppuVar2;
              ppuVar2[6] = (uint *)ppuVar17;
            }
          }
        }
        else {
          if (ppuVar2 < DAT_000e0bec) goto LAB_0005db90;
          ppuVar2[((uint **)ppuVar2[4] != ppuVar14) + 4] = (uint *)ppuVar17;
          if (ppuVar17 != (uint **)0x0) goto LAB_0005d70c;
        }
      }
    }
  }
  if ((ppuVar20 <= ppuVar14) || (puVar8 = ppuVar20[1], ((uint)puVar8 & 1) == 0)) goto LAB_0005db90;
  if (((uint)puVar8 & 2) == 0) {
    if (DAT_000e0bf4 == ppuVar20) {
      local_14 = (uint **)((int)local_14 + (int)DAT_000e0be8);
      DAT_000e0be8 = local_14;
      DAT_000e0bf4 = ppuVar14;
      ppuVar14[1] = (uint *)((uint)local_14 | 1);
      uVar15 = DAT_000e0dac;
      if (ppuVar14 == DAT_000e0bf0) {
        DAT_000e0bf0 = (uint **)0x0;
        DAT_000e0be4 = (uint **)0x0;
      }
      if (local_14 <= DAT_000e0bf8) {
        return local_14;
      }
      local_30 = 0;
      if (DAT_000e0bf4 == (uint **)0x0) goto LAB_0005e0af;
      local_34 = (uint *)0x0;
      if ((uint **)0x28 < DAT_000e0be8) {
        puVar8 = (uint *)((((int)DAT_000e0be8 + (DAT_000e0dac - 0x29)) / DAT_000e0dac - 1) *
                         DAT_000e0dac);
        ppuVar14 = (uint **)&DAT_000e0d94;
        do {
          if ((*ppuVar14 <= DAT_000e0bf4) &&
             (DAT_000e0bf4 < (uint **)((int)*ppuVar14 + (int)ppuVar14[1]))) goto LAB_0005dc26;
          ppuVar14 = (uint **)ppuVar14[2];
        } while (ppuVar14 != (uint **)0x0);
        ppuVar14 = (uint **)0x0;
LAB_0005dc26:
        local_34 = (uint *)0x0;
        if (((uint)ppuVar14[3] & 8) == 0) {
          if (((uint)ppuVar14[3] & 1) == 0) {
            uVar6 = FUN_00013c1e(0);
            if (uVar6 == (int)*ppuVar14 + (int)ppuVar14[1]) {
              puVar7 = (uint *)(-0x80000000 - uVar15);
              if (puVar8 < (uint *)0x7fffffff) {
                puVar7 = puVar8;
              }
              iVar16 = FUN_00013c1e(-(int)puVar7);
              local_34 = (uint *)0x0;
              uVar15 = FUN_00013c1e(0);
              if ((iVar16 != -1) && (uVar15 < uVar6)) {
                puVar8 = (uint *)(uVar6 - uVar15);
LAB_0005dcf3:
                local_34 = (uint *)0x0;
                if (puVar8 != (uint *)0x0) {
                  ppuVar14[1] = (uint *)((int)ppuVar14[1] - (int)puVar8);
                  ppuVar20 = DAT_000e0bf4;
                  ppuVar14 = DAT_000e0be8;
                  DAT_000e0d88 = DAT_000e0d88 - (int)puVar8;
                  uVar15 = -(int)DAT_000e0bf4 - 8U & 7;
                  if (((uint)(DAT_000e0bf4 + 2) & 7) == 0) {
                    uVar15 = 0;
                  }
                  DAT_000e0be8 = (uint **)((int)DAT_000e0be8 + (-uVar15 - (int)puVar8));
                  puVar7 = (uint *)((int)DAT_000e0bf4 + uVar15 + 4);
                  DAT_000e0bf4 = (uint **)((int)DAT_000e0bf4 + uVar15);
                  *puVar7 = (uint)DAT_000e0be8 | 1;
                  *(undefined4 *)((int)ppuVar20 + (int)ppuVar14 + (4 - (int)puVar8)) = 0x28;
                  DAT_000e0bf8 = DAT_000e0db4;
                  local_34 = puVar8;
                }
              }
            }
          }
          else {
            puVar7 = ppuVar14[1];
            if (puVar8 <= puVar7) {
              puVar3 = *ppuVar14;
              puVar21 = &DAT_000e0d94;
              do {
                if ((puVar3 <= puVar21) && (puVar21 < (uint *)((int)puVar7 + (int)puVar3)))
                goto LAB_0005dd68;
                puVar21 = (uint *)puVar21[2];
              } while (puVar21 != (uint *)0x0);
              iVar16 = FUN_00013c30((int)puVar3 + ((int)puVar7 - (int)puVar8),puVar8);
              if (iVar16 == 0) goto LAB_0005dcf3;
            }
          }
        }
      }
LAB_0005dd68:
      local_30 = 0;
      if (DAT_000e0d9c != (int *)0x0) {
        local_30 = 0;
        piVar18 = &DAT_000e0d94;
        piVar19 = DAT_000e0d9c;
        do {
          piVar4 = (int *)piVar19[2];
          if ((piVar19[3] & 9U) == 1) {
            iVar16 = *piVar19;
            uVar15 = -iVar16 - 8U & 7;
            if ((iVar16 + 8U & 7) == 0) {
              uVar15 = 0;
            }
            uVar6 = *(uint *)(iVar16 + 4 + uVar15);
            if ((uVar6 & 2) == 0) {
              iVar5 = piVar19[1];
              ppuVar14 = (uint **)(uVar15 + iVar16);
              uVar15 = uVar6 & 0xfffffffc;
              if ((uint)(iVar16 + -0x28 + iVar5) <= uVar15 + (int)ppuVar14) {
                if (DAT_000e0bf0 == ppuVar14) {
                  DAT_000e0bf0 = (uint **)0x0;
                  DAT_000e0be4 = (uint **)0x0;
                }
                else {
                  ppuVar20 = (uint **)ppuVar14[3];
                  ppuVar17 = (uint **)ppuVar14[6];
                  if (ppuVar20 == ppuVar14) {
                    if ((uint **)ppuVar14[5] == (uint **)0x0) {
                      ppuVar2 = (uint **)ppuVar14[4];
                      ppuVar1 = ppuVar14 + 4;
                      if (ppuVar2 == (uint **)0x0) {
                        ppuVar20 = (uint **)0x0;
                        goto LAB_0005de9b;
                      }
                    }
                    else {
                      ppuVar1 = ppuVar14 + 5;
                      ppuVar2 = (uint **)ppuVar14[5];
                    }
                    do {
                      do {
                        ppuVar20 = ppuVar2;
                        ppuVar11 = ppuVar1;
                        ppuVar1 = ppuVar20 + 5;
                        ppuVar2 = (uint **)ppuVar20[5];
                      } while ((uint **)ppuVar20[5] != (uint **)0x0);
                      ppuVar1 = ppuVar20 + 4;
                      ppuVar2 = (uint **)ppuVar20[4];
                    } while ((uint **)ppuVar20[4] != (uint **)0x0);
                    if (ppuVar11 < DAT_000e0bec) goto LAB_0005e0be;
                    *ppuVar11 = (uint *)0x0;
                  }
                  else {
                    ppuVar2 = (uint **)ppuVar14[2];
                    if ((((uint **)ppuVar2[3] != ppuVar14) || ((uint **)ppuVar20[2] != ppuVar14)) ||
                       (ppuVar2 < DAT_000e0bec)) goto LAB_0005e0be;
                    ppuVar2[3] = (uint *)ppuVar20;
                    ppuVar20[2] = (uint *)ppuVar2;
                  }
LAB_0005de9b:
                  if (ppuVar17 != (uint **)0x0) {
                    puVar8 = ppuVar14[7];
                    if ((uint **)(&DAT_000e0d08)[(int)puVar8] == ppuVar14) {
                      (&DAT_000e0d08)[(int)puVar8] = ppuVar20;
                      if (ppuVar20 == (uint **)0x0) {
                        bVar13 = (byte)puVar8 & 0x1f;
                        DAT_000e0be0 = DAT_000e0be0 & (-2 << bVar13 | 0xfffffffeU >> 0x20 - bVar13);
                      }
                      else {
LAB_0005ded8:
                        ppuVar2 = DAT_000e0bec;
                        if (ppuVar20 < DAT_000e0bec) goto LAB_0005e0be;
                        ppuVar20[6] = (uint *)ppuVar17;
                        ppuVar17 = (uint **)ppuVar14[4];
                        if (ppuVar17 != (uint **)0x0) {
                          if (ppuVar17 < ppuVar2) goto LAB_0005e0be;
                          ppuVar20[4] = (uint *)ppuVar17;
                          ppuVar17[6] = (uint *)ppuVar20;
                        }
                        ppuVar17 = (uint **)ppuVar14[5];
                        if (ppuVar17 != (uint **)0x0) {
                          if (ppuVar17 < DAT_000e0bec) goto LAB_0005e0be;
                          ppuVar20[5] = (uint *)ppuVar17;
                          ppuVar17[6] = (uint *)ppuVar20;
                        }
                      }
                    }
                    else {
                      if (ppuVar17 < DAT_000e0bec) goto LAB_0005e0be;
                      ppuVar17[((uint **)ppuVar17[4] != ppuVar14) + 4] = (uint *)ppuVar20;
                      if (ppuVar20 != (uint **)0x0) goto LAB_0005ded8;
                    }
                  }
                }
                iVar16 = FUN_00013c30(iVar16,iVar5);
                if (iVar16 == 0) {
                  local_30 = local_30 + iVar5;
                  DAT_000e0d88 = DAT_000e0d88 - iVar5;
                  piVar18[2] = (int)piVar4;
                  piVar19 = piVar18;
                }
                else {
                  uVar9 = uVar6 >> 8;
                  if (uVar9 == 0) {
                    puVar8 = (uint *)0x0;
                  }
                  else {
                    puVar8 = (uint *)0x1f;
                    if (uVar6 < 0x1000000) {
                      uVar6 = uVar9 + 0xfff00 >> 0x10 & 8;
                      iVar16 = uVar9 << (sbyte)uVar6;
                      uVar9 = iVar16 + 0x7f000U >> 0x10 & 4;
                      iVar16 = iVar16 << (sbyte)uVar9;
                      uVar12 = iVar16 + 0x3c000U >> 0x10 & 2;
                      iVar16 = ((uint)(iVar16 << (sbyte)uVar12) >> 0xf) - (uVar6 | uVar9 | uVar12);
                      puVar8 = (uint *)((uVar15 >> ((char)iVar16 + 0x15U & 0x1f) & 1) + 0x1c +
                                       iVar16 * 2);
                    }
                  }
                  ppuVar14[7] = puVar8;
                  ppuVar14[5] = (uint *)0x0;
                  ppuVar14[4] = (uint *)0x0;
                  if ((DAT_000e0be0 >> ((uint)puVar8 & 0x1f) & 1) == 0) {
                    DAT_000e0be0 = DAT_000e0be0 | 1 << ((byte)puVar8 & 0x1f);
                    (&DAT_000e0d08)[(int)puVar8] = ppuVar14;
                    ppuVar14[6] = &DAT_000e0d08 + (int)puVar8;
                  }
                  else {
                    bVar13 = 0x19 - (char)((uint)puVar8 >> 1);
                    if (puVar8 == (uint *)0x1f) {
                      bVar13 = 0;
                    }
                    iVar16 = uVar15 << (bVar13 & 0x1f);
                    ppuVar20 = (uint **)(&DAT_000e0d08)[(int)puVar8];
                    do {
                      ppuVar17 = ppuVar20;
                      if (((uint)ppuVar17[1] & 0xfffffffc) == uVar15) {
                        ppuVar20 = (uint **)ppuVar17[2];
                        if ((ppuVar20 < DAT_000e0bec) || (ppuVar17 < DAT_000e0bec))
                        goto LAB_0005e0be;
                        ppuVar20[3] = (uint *)ppuVar14;
                        ppuVar17[2] = (uint *)ppuVar14;
                        ppuVar14[2] = (uint *)ppuVar20;
                        ppuVar14[3] = (uint *)ppuVar17;
                        ppuVar14[6] = (uint *)0x0;
                        goto LAB_0005e084;
                      }
                      iVar5 = iVar16 >> 0x1f;
                      iVar16 = iVar16 * 2;
                      ppuVar20 = (uint **)ppuVar17[4 - iVar5];
                    } while ((uint **)ppuVar17[4 - iVar5] != (uint **)0x0);
                    if (ppuVar17 + (4 - iVar5) < DAT_000e0bec) {
LAB_0005e0be:
                    /* WARNING: Subroutine does not return */
                      FUN_00013c2a();
                    }
                    ppuVar17[4 - iVar5] = (uint *)ppuVar14;
                    ppuVar14[6] = (uint *)ppuVar17;
                  }
                  ppuVar14[3] = (uint *)ppuVar14;
                  ppuVar14[2] = (uint *)ppuVar14;
                }
              }
            }
          }
LAB_0005e084:
          piVar18 = piVar19;
          piVar19 = piVar4;
        } while (piVar4 != (int *)0x0);
      }
      local_30 = local_30 + (int)local_34;
      if (local_30 == 0) {
        DAT_000e0bf8 = (uint **)0xffffffff;
        local_30 = 0;
      }
LAB_0005e0af:
      return (uint **)(uint)(local_30 != 0);
    }
    if (DAT_000e0bf0 == ppuVar20) {
      local_14 = (uint **)((int)local_14 + (int)DAT_000e0be4);
      DAT_000e0be4 = local_14;
      DAT_000e0bf0 = ppuVar14;
LAB_0005d9a5:
      ppuVar14[1] = (uint *)((uint)local_14 | 1);
      *(uint ***)((int)ppuVar14 + (int)local_14) = local_14;
      return local_14;
    }
    if (puVar8 < (uint *)0x100) {
      ppuVar17 = (uint **)ppuVar20[2];
      if (((uint **)ppuVar17[3] != ppuVar20) ||
         (ppuVar2 = (uint **)ppuVar20[3], (uint **)ppuVar2[2] != ppuVar20)) goto LAB_0005db90;
      if (ppuVar17 == ppuVar2) {
        bVar13 = (byte)((uint)puVar8 >> 3) & 0x1f;
        DAT_000e0bdc = DAT_000e0bdc & (-2 << bVar13 | 0xfffffffeU >> 0x20 - bVar13);
      }
      else {
        ppuVar20 = (uint **)(((uint)puVar8 & 0xfffffff8) + 0xe0c00);
        if (((ppuVar17 != ppuVar20) && (ppuVar17 < DAT_000e0bec)) ||
           ((ppuVar2 != ppuVar20 && (ppuVar2 < DAT_000e0bec)))) goto LAB_0005db90;
        ppuVar17[3] = (uint *)ppuVar2;
        ppuVar2[2] = (uint *)ppuVar17;
      }
    }
    else {
      ppuVar17 = (uint **)ppuVar20[3];
      ppuVar2 = (uint **)ppuVar20[6];
      if (ppuVar17 == ppuVar20) {
        if ((uint **)ppuVar20[5] == (uint **)0x0) {
          ppuVar1 = (uint **)ppuVar20[4];
          ppuVar11 = ppuVar20 + 4;
          if (ppuVar1 == (uint **)0x0) {
            ppuVar17 = (uint **)0x0;
            goto LAB_0005dabf;
          }
        }
        else {
          ppuVar11 = ppuVar20 + 5;
          ppuVar1 = (uint **)ppuVar20[5];
        }
        do {
          do {
            ppuVar17 = ppuVar1;
            ppuVar10 = ppuVar11;
            ppuVar11 = ppuVar17 + 5;
            ppuVar1 = (uint **)ppuVar17[5];
          } while ((uint **)ppuVar17[5] != (uint **)0x0);
          ppuVar11 = ppuVar17 + 4;
          ppuVar1 = (uint **)ppuVar17[4];
        } while ((uint **)ppuVar17[4] != (uint **)0x0);
        if (ppuVar10 < DAT_000e0bec) goto LAB_0005dba0;
        *ppuVar10 = (uint *)0x0;
      }
      else {
        ppuVar1 = (uint **)ppuVar20[2];
        if ((((uint **)ppuVar1[3] != ppuVar20) || ((uint **)ppuVar17[2] != ppuVar20)) ||
           (ppuVar1 < DAT_000e0bec)) goto LAB_0005db90;
        ppuVar1[3] = (uint *)ppuVar17;
        ppuVar17[2] = (uint *)ppuVar1;
      }
LAB_0005dabf:
      if (ppuVar2 != (uint **)0x0) {
        puVar7 = ppuVar20[7];
        if ((uint **)(&DAT_000e0d08)[(int)puVar7] == ppuVar20) {
          (&DAT_000e0d08)[(int)puVar7] = ppuVar17;
          if (ppuVar17 == (uint **)0x0) {
            bVar13 = (byte)puVar7 & 0x1f;
            DAT_000e0be0 = DAT_000e0be0 & (-2 << bVar13 | 0xfffffffeU >> 0x20 - bVar13);
          }
          else {
LAB_0005daf8:
            ppuVar1 = DAT_000e0bec;
            if (ppuVar17 < DAT_000e0bec) goto LAB_0005dba0;
            ppuVar17[6] = (uint *)ppuVar2;
            ppuVar2 = (uint **)ppuVar20[4];
            if (ppuVar2 != (uint **)0x0) {
              if (ppuVar2 < ppuVar1) goto LAB_0005dba0;
              ppuVar17[4] = (uint *)ppuVar2;
              ppuVar2[6] = (uint *)ppuVar17;
            }
            ppuVar20 = (uint **)ppuVar20[5];
            if (ppuVar20 != (uint **)0x0) {
              if (ppuVar20 < DAT_000e0bec) {
LAB_0005db90:
                    /* WARNING: Subroutine does not return */
                FUN_00013c2a();
              }
              ppuVar17[5] = (uint *)ppuVar20;
              ppuVar20[6] = (uint *)ppuVar17;
            }
          }
        }
        else {
          if (ppuVar2 < DAT_000e0bec) goto LAB_0005db90;
          ppuVar2[((uint **)ppuVar2[4] != ppuVar20) + 4] = (uint *)ppuVar17;
          if (ppuVar17 != (uint **)0x0) goto LAB_0005daf8;
        }
      }
    }
    local_14 = (uint **)((int)local_14 + (int)(uint **)((uint)puVar8 & 0xfffffffc));
    ppuVar14[1] = (uint *)((uint)local_14 | 1);
    *(uint ***)((int)ppuVar14 + (int)local_14) = local_14;
    if (ppuVar14 == DAT_000e0bf0) {
      DAT_000e0be4 = local_14;
      return (uint **)((uint)puVar8 & 0xfffffffc);
    }
  }
  else {
    ppuVar20[1] = (uint *)((uint)puVar8 & 0xfffffffe);
    ppuVar14[1] = (uint *)((uint)local_14 | 1);
    *(uint ***)((int)ppuVar14 + (int)local_14) = local_14;
  }
  if (local_14 < (uint **)0x100) {
    uVar15 = (uint)local_14 & 0xfffffff8;
    if ((DAT_000e0bdc >> ((uint)local_14 >> 3 & 0x1f) & 1) == 0) {
      DAT_000e0bdc = DAT_000e0bdc | 1 << ((byte)((uint)local_14 >> 3) & 0x1f);
      ppuVar20 = (uint **)(uVar15 + 0xe0c00);
    }
    else {
      ppuVar20 = *(uint ***)(&DAT_000e0c08 + uVar15);
      if (*(uint ***)(&DAT_000e0c08 + uVar15) < DAT_000e0bec) {
LAB_0005dba0:
                    /* WARNING: Subroutine does not return */
        FUN_00013c2a();
      }
    }
    *(uint ***)(&DAT_000e0c08 + uVar15) = ppuVar14;
    ppuVar20[3] = (uint *)ppuVar14;
    ppuVar14[2] = (uint *)ppuVar20;
    ppuVar14[3] = (uint *)(uint **)(uVar15 + 0xe0c00);
  }
  else {
    uVar15 = (uint)local_14 >> 8;
    puVar8 = (uint *)0x0;
    if ((uVar15 != 0) && (puVar8 = (uint *)0x1f, local_14 < (uint **)0x1000000)) {
      uVar6 = uVar15 + 0xfff00 >> 0x10 & 8;
      iVar16 = uVar15 << (sbyte)uVar6;
      uVar15 = iVar16 + 0x7f000U >> 0x10 & 4;
      iVar16 = iVar16 << (sbyte)uVar15;
      uVar9 = iVar16 + 0x3c000U >> 0x10 & 2;
      iVar16 = ((uint)(iVar16 << (sbyte)uVar9) >> 0xf) - (uVar6 | uVar15 | uVar9);
      puVar8 = (uint *)(((uint)local_14 >> ((char)iVar16 + 0x15U & 0x1f) & 1) + 0x1c + iVar16 * 2);
    }
    ppuVar14[7] = puVar8;
    ppuVar14[5] = (uint *)0x0;
    ppuVar14[4] = (uint *)0x0;
    if ((DAT_000e0be0 >> ((uint)puVar8 & 0x1f) & 1) == 0) {
      ppuVar20 = (uint **)(&DAT_000e0d08 + (int)puVar8);
      DAT_000e0be0 = DAT_000e0be0 | 1 << ((byte)puVar8 & 0x1f);
      *ppuVar20 = (uint *)ppuVar14;
      ppuVar14[6] = (uint *)ppuVar20;
      ppuVar14[3] = (uint *)ppuVar14;
      ppuVar14[2] = (uint *)ppuVar14;
    }
    else {
      bVar13 = 0x19 - (char)((uint)puVar8 >> 1);
      if (puVar8 == (uint *)0x1f) {
        bVar13 = 0;
      }
      iVar16 = (int)local_14 << (bVar13 & 0x1f);
      ppuVar20 = (uint **)(&DAT_000e0d08)[(int)puVar8];
      do {
        ppuVar17 = ppuVar20;
        if ((uint **)((uint)ppuVar17[1] & 0xfffffffc) == local_14) {
          ppuVar20 = (uint **)ppuVar17[2];
          if ((DAT_000e0bec <= ppuVar20) && (DAT_000e0bec <= ppuVar17)) {
            ppuVar20[3] = (uint *)ppuVar14;
            ppuVar17[2] = (uint *)ppuVar14;
            ppuVar14[2] = (uint *)ppuVar20;
            ppuVar14[3] = (uint *)ppuVar17;
            ppuVar14[6] = (uint *)0x0;
            return ppuVar20;
          }
          goto LAB_0005dba0;
        }
        iVar5 = iVar16 >> 0x1f;
        iVar16 = iVar16 * 2;
        ppuVar20 = (uint **)ppuVar17[4 - iVar5];
      } while ((uint **)ppuVar17[4 - iVar5] != (uint **)0x0);
      ppuVar20 = ppuVar17 + (4 - iVar5);
      if (ppuVar20 < DAT_000e0bec) {
                    /* WARNING: Subroutine does not return */
        FUN_00013c2a();
      }
      *ppuVar20 = (uint *)ppuVar14;
      ppuVar14[6] = (uint *)ppuVar17;
      ppuVar14[3] = (uint *)ppuVar14;
      ppuVar14[2] = (uint *)ppuVar14;
    }
  }
  return ppuVar20;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005e0c3 FUN_0005e0c3 */

int FUN_0005e0c3(uint param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = 0x5e0cb;
  if ((param_1 == 0) || (iVar2 = 0, param_2 <= (uint)(0xffffffff / (ulonglong)param_1))) {
    iVar2 = FUN_0005beec(param_2 * param_1);
    if (iVar2 == 0) {
      iVar2 = 0;
    }
    else if (((*(byte *)(iVar2 + -4) & 1) != 0) || ((*(byte *)(iVar2 + -8) & 1) == 0)) {
      FUN_00013c0c(iVar2,0,param_2 * param_1,uVar3);
    }
  }
  else {
    puVar1 = (undefined4 *)FUN_00013c24();
    *puVar1 = 0xc;
  }
  return iVar2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005e132 FUN_0005e132 */

int FUN_0005e132(int param_1,uint param_2)

{
  uint *puVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  if (param_1 == 0) {
    iVar5 = FUN_0005beec(param_2);
    return iVar5;
  }
  if (param_2 < 0xffffffc0) {
    uVar4 = *(uint *)(param_1 + -4);
    uVar9 = uVar4 & 0xfffffffc;
    if (((((int)uVar9 < 1) || ((uVar4 & 2) == 0)) ||
        (puVar1 = (uint *)(param_1 - 8), puVar1 < DAT_000e0bec)) ||
       ((*(byte *)(param_1 + uVar9 + -4) & 1) == 0)) {
                    /* WARNING: Subroutine does not return */
      FUN_00013c2a();
    }
    uVar7 = 0x10;
    if (10 < param_2) {
      uVar7 = param_2 + 0xb & 0xfffffff8;
    }
    uVar4 = uVar4 & 1;
    if ((uVar4 == 0) && ((*(byte *)puVar1 & 1) != 0)) {
      if (((0xff < uVar7) && ((uVar7 | 4) <= uVar9)) && (uVar9 - uVar7 <= (uint)(DAT_000e0dac * 2)))
      {
        return param_1;
      }
    }
    else {
      uVar8 = uVar9 - uVar7;
      if (uVar7 <= uVar9) {
        if (uVar8 < 0x10) {
          return param_1;
        }
        *(uint *)(param_1 + -4) = uVar4 | uVar7 | 2;
        *(uint *)(param_1 + -4 + uVar7) = uVar8 | 3;
        pbVar2 = (byte *)((int)puVar1 + uVar8 + 4 + uVar7);
        *pbVar2 = *pbVar2 | 1;
        FUN_0005d50e(param_1 + uVar7);
        return param_1;
      }
      if ((DAT_000e0bf4 == (byte *)(param_1 + uVar9 + -8)) &&
         (uVar8 = (DAT_000e0be8 + uVar9) - uVar7, uVar7 <= DAT_000e0be8 + uVar9 && uVar8 != 0)) {
        *(uint *)(param_1 + -4) = uVar4 | uVar7 | 2;
        *(uint *)(param_1 + -4 + uVar7) = uVar8 | 1;
        DAT_000e0be8 = uVar8;
        DAT_000e0bf4 = (byte *)((int)puVar1 + uVar7);
        return param_1;
      }
    }
    iVar5 = FUN_0005beec(param_2);
    if (iVar5 != 0) {
      iVar6 = 4;
      if ((*(byte *)(param_1 + -4) & 1) == 0) {
        iVar6 = (*puVar1 & 1) * 4 + 4;
      }
      uVar4 = uVar9 - iVar6;
      if (param_2 <= uVar9 - iVar6) {
        uVar4 = param_2;
      }
      FUN_00013c06(iVar5,param_1,uVar4);
      FUN_0005d50e(param_1);
      return iVar5;
    }
  }
  else {
    puVar3 = (undefined4 *)FUN_00013c24();
    *puVar3 = 0xc;
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005e2f5 FUN_0005e2f5 */

uint * FUN_0005e2f5(uint param_1,uint param_2)

{
  uint *puVar1;
  byte *pbVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint *puVar9;
  byte *pbVar10;
  uint *local_1c;
  
  if (param_1 < 9) {
    puVar3 = (uint *)FUN_0005beec(param_2);
    return puVar3;
  }
  if (param_1 < 0x11) {
    param_1 = 0x10;
  }
  uVar4 = 0x10;
  uVar6 = param_1;
  if ((param_1 & param_1 - 1) != 0) {
    do {
      uVar6 = uVar4;
      uVar4 = uVar6 * 2;
    } while (uVar6 < param_1);
  }
  if (-uVar6 - 0x40 <= param_2) {
    puVar7 = (undefined4 *)FUN_00013c24();
    *puVar7 = 0xc;
    return (uint *)0x0;
  }
  uVar4 = 0x10;
  if (10 < param_2) {
    uVar4 = param_2 + 0xb & 0xfffffff8;
  }
  uVar5 = FUN_0005beec(uVar4 + 0xc + uVar6);
  if (uVar5 == 0) {
    return (uint *)0x0;
  }
  puVar3 = (uint *)(uVar5 - 8);
  if (uVar5 % uVar6 == 0) {
    local_1c = (uint *)(uVar5 - 4);
    uVar6 = *(uint *)(uVar5 - 4);
  }
  else {
    uVar8 = -uVar6 & (uVar5 - 1) + uVar6;
    puVar1 = (uint *)(uVar8 - 8);
    puVar9 = (uint *)((uVar8 - 8) + uVar6);
    if (0xf < (uint)((int)puVar1 - (int)puVar3)) {
      puVar9 = puVar1;
    }
    uVar8 = (int)puVar9 - (int)puVar3;
    uVar6 = (*(uint *)(uVar5 - 4) & 0xfffffffc) - uVar8;
    if (((*(uint *)(uVar5 - 4) & 1) != 0) || ((*puVar3 & 1) == 0)) {
      puVar9[1] = puVar9[1] & 1 | uVar6 | 2;
      pbVar10 = (byte *)((int)puVar9 + uVar6 + 4);
      *pbVar10 = *pbVar10 | 1;
      *(uint *)(uVar5 - 4) = uVar8 | *(uint *)(uVar5 - 4) & 1 | 2;
      local_1c = puVar9 + 1;
      uVar6 = puVar9[1] | 1;
      puVar9[1] = uVar6;
      puVar3 = puVar9;
      goto LAB_0005e446;
    }
    *puVar9 = *puVar3 + uVar8;
    uVar6 = uVar6 | 2;
    local_1c = puVar9 + 1;
    puVar9[1] = uVar6;
    puVar3 = puVar9;
  }
  uVar5 = 0;
LAB_0005e446:
  if (((uVar6 & 1) != 0) || (pbVar10 = (byte *)0x0, (*(byte *)puVar3 & 1) == 0)) {
    uVar8 = uVar6 & 0xfffffffc;
    pbVar10 = (byte *)0x0;
    if (uVar4 + 0x10 < uVar8) {
      *local_1c = uVar6 & 1 | uVar4 | 2;
      pbVar10 = (byte *)((int)puVar3 + uVar4 + 8);
      *(uint *)(pbVar10 + -4) = uVar8 - uVar4 | 3;
      pbVar2 = (byte *)((int)puVar3 + uVar8 + 4);
      *pbVar2 = *pbVar2 | 1;
    }
  }
  if (uVar5 != 0) {
    FUN_0005d50e(uVar5);
  }
  if (pbVar10 != (byte *)0x0) {
    FUN_0005d50e(pbVar10);
  }
  return puVar3 + 2;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005e701 FUN_0005e701 */

void FUN_0005e701(void)

{
  if (DAT_000e0da8 == 0) {
    DAT_000e0db0 = 0x10000;
    DAT_000e0db4 = 0x200000;
    if (DAT_000e0da4 == '\0') {
      DAT_000e0da4 = '\x01';
      DAT_000e0d90 = 1;
    }
    DAT_000e0da8 = FUN_00013c00(0x28);
    DAT_000e0dac = DAT_000e0da8;
    if ((DAT_000e0da8 & DAT_000e0da8 - 1) != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_00013c2a();
    }
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005eb00 FUN_0005eb00 */

uint FUN_0005eb00(char *param_1)

{
  uint uVar1;
  uint local_8;
  
  local_8 = 0;
  while (*param_1 != '\0') {
    local_8 = local_8 * 0x10 + (int)*param_1;
    uVar1 = local_8 & 0xf0000000;
    if (uVar1 != 0) {
      local_8 = uVar1 >> 0x18 ^ local_8;
    }
    local_8 = (uVar1 ^ 0xffffffff) & local_8;
    param_1 = param_1 + 1;
  }
  return local_8;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005eb70 FUN_0005eb70 */

void FUN_0005eb70(undefined4 param_1,undefined4 param_2)

{
  FUN_00013c36(param_1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005ebb0 FUN_0005ebb0 */

undefined4 FUN_0005ebb0(int **param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  bool bVar4;
  int **local_2c;
  ushort local_26;
  int **local_18;
  
  bVar4 = PTR_dl_iterate_phdr_000e0e5c == (undefined *)0x0;
  if (bVar4) {
    FUN_0005f0e0(param_1);
  }
  else {
    FUN_00013c3c(FUN_0005ee20,param_1);
  }
  local_18 = (int **)*param_1;
  do {
    if (local_18 == param_1) {
      if (bVar4) {
        FUN_0005f8a0(param_1);
      }
      local_18 = (int **)*param_1;
      while( true ) {
        if (local_18 != param_1) {
          local_2c = (int **)*local_18;
        }
        if (local_18 == param_1 || local_18 == (int **)0x0) break;
        if (((local_18[6] == (int *)0x0) || (local_18[7] == (int *)0x0)) ||
           ((local_18[0xb] == (int *)0x0 && (local_18[0xc] == (int *)0x0)))) {
          piVar1 = *local_18;
          piVar2 = local_18[1];
          piVar1[1] = (int)piVar2;
          *piVar2 = (int)piVar1;
          FUN_0005d50e(local_18);
        }
        local_18 = local_2c;
      }
      return 0;
    }
    if ((*(byte *)(local_18 + 0xf) & 1) == 0) {
      piVar1 = local_18[2];
      if ((int *)piVar1[7] < local_18[3]) {
        iVar3 = (int)local_18[2] + piVar1[7];
        for (local_26 = 0; local_26 != *(ushort *)(piVar1 + 0xb); local_26 = local_26 + 1) {
          if (*(int *)(iVar3 + (uint)local_26 * 0x20) == 1) {
            local_18[10] = (int *)((int)local_18[2] - *(int *)(iVar3 + (uint)local_26 * 0x20 + 8));
            break;
          }
        }
        FUN_0005f520(local_18,iVar3,*(undefined2 *)(piVar1 + 0xb));
      }
      else {
        FUN_00013c42(6,&DAT_0004d3ad,"error: special e_phoff found at %s",(int)local_18 + 0x3d);
      }
    }
    local_18 = (int **)*local_18;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005ee20 FUN_0005ee20 */

undefined4 FUN_0005ee20(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int local_3c;
  undefined4 *local_28;
  ushort local_1e;
  int local_1c;
  int local_18;
  
  if ((*(short *)(param_1 + 3) != 0) && (param_1[2] != 0)) {
    local_18 = 0;
    local_1c = 0;
    for (local_1e = 0; local_1e != *(ushort *)(param_1 + 3); local_1e = local_1e + 1) {
      if (*(int *)(param_1[2] + (uint)local_1e * 0x20) == 1) {
        if (local_1c == 0) {
          local_1c = *(int *)(param_1[2] + (uint)local_1e * 0x20 + 8) + *param_1;
        }
        if ((*(uint *)(param_1[2] + (uint)local_1e * 0x20 + 4) <= *(uint *)(local_1c + 0x1c)) &&
           (*(uint *)(local_1c + 0x1c) <
            (uint)(*(int *)(param_1[2] + (uint)local_1e * 0x20 + 4) +
                  *(int *)(param_1[2] + (uint)local_1e * 0x20 + 0x10)))) {
          local_18 = (*(int *)(local_1c + 0x1c) - *(int *)(param_1[2] + (uint)local_1e * 0x20 + 4))
                     + *(int *)(param_1[2] + (uint)local_1e * 0x20 + 8) + *param_1;
          break;
        }
      }
    }
    if ((local_1c != 0) && (local_18 != 0)) {
      for (local_28 = (undefined4 *)*param_3; local_28 != param_3;
          local_28 = (undefined4 *)*local_28) {
        if (local_28[2] == local_1c) {
          return 0;
        }
      }
      if (param_1[1] == 0) {
        local_3c = 0;
      }
      else {
        local_3c = FUN_00013c48(param_1[1]);
      }
      puVar1 = (undefined4 *)FUN_0005e0c3(1,local_3c + 0x40);
      puVar1[2] = local_1c;
      if (param_1[1] != 0) {
        FUN_00013c4e((int)puVar1 + 0x3d,param_1[1]);
      }
      FUN_0005f520(puVar1,local_18,*(undefined2 *)(local_1c + 0x2c));
      *puVar1 = param_3;
      puVar1[1] = param_3[1];
      *(undefined4 **)puVar1[1] = puVar1;
      param_3[1] = puVar1;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005f0e0 FUN_0005f0e0 */

void FUN_0005f0e0(undefined4 *param_1)

{
  bool bVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *local_1088;
  char *local_1074;
  char *local_1070;
  undefined4 local_106c;
  undefined4 local_1068;
  int local_1064;
  int local_1060;
  int local_105c;
  undefined4 local_1058;
  undefined4 local_1054;
  undefined local_1050 [4160];
  
  local_1054 = FUN_00013c54("/proc/self/maps",0);
  local_1058 = 0;
  local_105c = 0;
  local_1060 = 0;
  while (local_1060 = FUN_00013c5a(local_1054,local_1050 + local_105c,0x1000 - local_105c),
        0 < local_1060) {
    local_1050[local_105c + local_1060] = 0;
    local_1064 = 0;
    while (iVar2 = FUN_00060090(local_1050 + local_1064,(local_105c + local_1060) - local_1064,
                                &local_1068,&local_106c,&local_1070,&local_1074), iVar2 != 0) {
      if (((local_1074 != (char *)0x0) && (*local_1074 == '/')) && (*local_1070 == 'r')) {
        piVar3 = (int *)FUN_00060230(local_1068);
        iVar4 = FUN_00060230(local_106c);
        bVar1 = false;
        for (local_1088 = (undefined4 *)*param_1; local_1088 != param_1;
            local_1088 = (undefined4 *)*local_1088) {
          iVar5 = FUN_00013c60((int)local_1088 + 0x3d,local_1074);
          if (iVar5 == 0) {
            local_1088[4] = iVar4 - local_1088[2];
            bVar1 = true;
          }
        }
        iVar4 = iVar4 - (int)piVar3;
        if (((!bVar1) && (4 < iVar4)) &&
           ((iVar5 = FUN_00013c66(local_1074,"/dev/",5), iVar5 != 0 && (*piVar3 == 0x464c457f)))) {
          iVar5 = FUN_00013c48(local_1074);
          puVar6 = (undefined4 *)FUN_0005e0c3(1,iVar5 + 0x40);
          puVar6[2] = piVar3;
          FUN_00013c4e((int)puVar6 + 0x3d,local_1074);
          puVar6[4] = iVar4;
          puVar6[3] = iVar4;
          iVar4 = FUN_00013c6c((int)puVar6 + 0x3d,"/linker");
          if (iVar4 == 0) {
            *puVar6 = param_1;
            puVar6[1] = param_1[1];
            *(undefined4 **)puVar6[1] = puVar6;
            param_1[1] = puVar6;
          }
        }
      }
      local_1064 = iVar2 + local_1064;
    }
    local_105c = (local_105c + local_1060) - local_1064;
    if (local_105c != 0) {
      FUN_00013c12(local_1050,local_1050 + local_1064,local_105c);
    }
  }
  FUN_00013c72(local_1054);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005f520 FUN_0005f520 */

void FUN_0005f520(int param_1,int param_2,int param_3)

{
  int iVar1;
  bool bVar2;
  undefined4 uVar3;
  int local_30;
  int *local_2c;
  int local_28;
  int *local_24;
  int local_20;
  ushort local_18;
  
  if (*(int *)(param_1 + 0x10) == 0) {
    bVar2 = true;
    for (local_18 = 0; local_18 != *(ushort *)(*(int *)(param_1 + 8) + 0x2c);
        local_18 = local_18 + 1) {
      if (*(int *)(param_2 + (uint)local_18 * 0x20) == 1) {
        if (bVar2) {
          *(int *)(param_1 + 0x28) =
               *(int *)(param_1 + 8) - *(int *)(param_2 + (uint)local_18 * 0x20 + 8);
          bVar2 = false;
        }
        *(int *)(param_1 + 0x10) =
             (*(int *)(param_2 + (uint)local_18 * 0x20 + 8) +
              *(int *)(param_2 + (uint)local_18 * 0x20 + 0x14) + *(int *)(param_1 + 0x28)) -
             *(int *)(param_1 + 8);
      }
    }
  }
  iVar1 = *(int *)(param_1 + 0x28);
  *(undefined *)(param_1 + 0x3c) = 1;
  local_20 = 0;
  while( true ) {
    if (local_20 == param_3) goto LAB_0005f770;
    if (*(int *)(param_2 + local_20 * 0x20) == 2) break;
    local_20 = local_20 + 1;
  }
  *(int *)(param_1 + 0x14) = *(int *)(param_2 + local_20 * 0x20 + 8) + *(int *)(param_1 + 0x28);
  for (local_24 = *(int **)(param_1 + 0x14); *local_24 != 0; local_24 = local_24 + 2) {
    if (*local_24 == 6) {
      *(int *)(param_1 + 0x18) = local_24[1] + iVar1;
    }
    else if (*local_24 == 5) {
      *(int *)(param_1 + 0x1c) = local_24[1] + iVar1;
    }
    else if (*local_24 == 0x6ffffff0) {
      *(int *)(param_1 + 0x20) = local_24[1] + iVar1;
    }
    else if (*local_24 == 0x6ffffffc) {
      *(int *)(param_1 + 0x24) = local_24[1] + *(int *)(param_1 + 0x28);
    }
    else if (*local_24 == 4) {
      *(int *)(param_1 + 0x2c) = local_24[1] + iVar1;
    }
    else if (*local_24 == 0x6ffffef5) {
      *(int *)(param_1 + 0x30) = local_24[1] + iVar1;
    }
  }
LAB_0005f770:
  if (*(int *)(param_1 + 0x24) != 0) {
    local_28 = *(int *)(param_1 + 0x24);
    while( true ) {
      local_2c = (int *)(local_28 + *(int *)(local_28 + 0xc));
      if ((*(ushort *)(local_28 + 2) & 1) != 0) {
        *(int *)(param_1 + 0x38) = *(int *)(param_1 + 0x1c) + *local_2c;
        *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(local_28 + 8);
        return;
      }
      for (; local_2c[1] != 0; local_2c = (int *)((int)local_2c + local_2c[1])) {
      }
      if (*(int *)(local_28 + 0x10) == 0) break;
      local_28 = local_28 + *(int *)(local_28 + 0x10);
    }
  }
  if (*(int *)(param_1 + 0x38) == 0) {
    local_30 = FUN_00013c78(param_1 + 0x3d,0x2f,&DAT_000e0e28);
    if (local_30 == 0) {
      local_30 = param_1 + 0x3d;
    }
    else {
      local_30 = local_30 + 1;
    }
    *(int *)(param_1 + 0x38) = local_30;
    uVar3 = FUN_0005eb00(*(undefined4 *)(param_1 + 0x38));
    *(undefined4 *)(param_1 + 0x34) = uVar3;
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005f8a0 FUN_0005f8a0 */

void FUN_0005f8a0(int **param_1)

{
  int *piVar1;
  int **ppiVar2;
  int iVar3;
  char *pcVar4;
  int iVar5;
  int local_2c;
  int **local_24;
  int **local_20;
  int *local_18;
  int **local_14;
  
  iVar3 = FUN_0005fba0(param_1,FUN_0005ee20);
  if (((iVar3 != 0) && (*(int *)(iVar3 + 0x14) != 0)) && (*(int *)(iVar3 + 0x1c) != 0)) {
    local_14 = (int **)0x0;
    for (local_18 = *(int **)(iVar3 + 0x14); *local_18 != 0; local_18 = local_18 + 2) {
      if ((*local_18 == 1) &&
         (pcVar4 = (char *)(*(int *)(iVar3 + 0x1c) + local_18[1]), *pcVar4 != '\0')) {
        local_24 = (int **)*param_1;
        while( true ) {
          if (local_24 != param_1) {
            local_20 = (int **)*local_24;
          }
          if (local_24 == param_1 || local_24 == (int **)0x0) break;
          local_2c = FUN_00013c78((int)local_24 + 0x3d,0x2f);
          if (local_2c == 0) {
            local_2c = (int)local_24 + 0x3d;
          }
          else {
            local_2c = local_2c + 1;
          }
          iVar5 = FUN_00013c60(local_2c,pcVar4);
          if (iVar5 == 0) {
            piVar1 = *local_24;
            ppiVar2 = (int **)local_24[1];
            piVar1[1] = (int)ppiVar2;
            *ppiVar2 = piVar1;
            if (local_14 == (int **)0x0) {
              *local_24 = *param_1;
              local_24[1] = (int *)param_1;
              (*local_24)[1] = (int)local_24;
              *param_1 = (int *)local_24;
            }
            else {
              *local_24 = *local_14;
              local_24[1] = (int *)local_14;
              (*local_24)[1] = (int)local_24;
              *local_14 = (int *)local_24;
            }
            local_14 = local_24;
          }
          local_24 = local_20;
        }
      }
    }
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005fac0 FUN_0005fac0 */

void FUN_0005fac0(int param_1)

{
  *(int *)param_1 = param_1;
  *(int *)(param_1 + 4) = param_1;
  FUN_0005ebb0(param_1);
  DAT_000e0ec0 = PTR_sigprocmask_000e0e8c;
  DAT_000e0ecc = PTR_sigaction_000e0e88;
  DAT_000e0ed8 = FUN_0005eb70;
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005fb30 FUN_0005fb30 */

undefined4 FUN_0005fb30(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_14;
  
  iVar1 = FUN_0005fba0(param_1,param_2);
  if (iVar1 == 0) {
    local_14 = 0;
  }
  else {
    local_14 = *(undefined4 *)(iVar1 + 8);
  }
  return local_14;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005fba0 FUN_0005fba0 */

undefined4 * FUN_0005fba0(undefined4 *param_1,uint param_2)

{
  undefined4 *local_10;
  
  local_10 = (undefined4 *)*param_1;
  while( true ) {
    if (local_10 == param_1) {
      return (undefined4 *)0x0;
    }
    if (((uint)local_10[2] <= param_2) && (param_2 < (uint)(local_10[2] + local_10[4]))) break;
    local_10 = (undefined4 *)*local_10;
  }
  return local_10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005fc20 FUN_0005fc20 */

void FUN_0005fc20(int **param_1)

{
  int *piVar1;
  int **ppiVar2;
  int **local_14;
  int **local_10;
  
  local_10 = (int **)*param_1;
  while( true ) {
    if (local_10 != param_1) {
      local_14 = (int **)*local_10;
    }
    if (local_10 == param_1 || local_10 == (int **)0x0) break;
    piVar1 = *local_10;
    ppiVar2 = (int **)local_10[1];
    piVar1[1] = (int)ppiVar2;
    *ppiVar2 = piVar1;
    FUN_0005d50e(local_10);
    local_10 = local_14;
  }
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005fcd0 FUN_0005fcd0 */

int FUN_0005fcd0(undefined4 *param_1,char **param_2)

{
  undefined *puVar1;
  uint uVar2;
  undefined4 uVar3;
  int local_2c;
  int local_28;
  int local_24;
  undefined4 local_20;
  undefined4 *local_1c;
  undefined4 *local_18;
  undefined4 *local_14;
  int local_10;
  
  puVar1 = &DAT_000e0e28;
  if (**param_2 == '\0') {
    local_10 = 0;
  }
  else {
    local_14 = param_1;
    local_1c = (undefined4 *)0x0;
    local_20 = 0;
    uVar3 = 0;
    FUN_00013c0c(&local_2c,0,0xc);
    for (local_18 = (undefined4 *)*local_14; local_18 != local_14;
        local_18 = (undefined4 *)*local_18) {
      if (((local_18 != local_1c) &&
          (uVar2 = FUN_0005fe80(local_18,param_1 + 2,param_2,&local_2c,uVar3,puVar1),
          (uVar2 & 1) != 0)) && (local_2c != 0)) {
        return local_2c;
      }
    }
    if (local_28 == 0) {
      if (local_24 == 0) {
        local_10 = FUN_00013c7e(0xffffffff,*param_2);
        if (local_10 == 0) {
          local_10 = 0;
        }
      }
      else {
        local_10 = local_24;
      }
    }
    else {
      local_10 = local_28;
    }
  }
  return local_10;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 0005fe80 FUN_0005fe80 */

byte FUN_0005fe80(int param_1,undefined4 param_2,undefined4 param_3,code **param_4)

{
  int iVar1;
  code *local_28;
  code *local_20;
  int local_18;
  byte local_12;
  byte local_11;
  
  local_12 = 0;
  local_18 = 0;
  iVar1 = FUN_00060340(param_1,param_3,&local_18,param_1,param_2,param_3,param_4);
  if (iVar1 < 0) {
    *param_4 = *(code **)(&DAT_000e0eb4 + iVar1 * -0xc);
    local_11 = 1;
  }
  else {
    if (iVar1 != 0) {
      local_20 = (code *)(*(int *)(*(int *)(param_1 + 0x18) + iVar1 * 0x10 + 4) +
                         *(int *)(param_1 + 0x28));
      if ((*(byte *)(*(int *)(param_1 + 0x18) + iVar1 * 0x10 + 0xc) & 0xf) == 10) {
        local_20 = (code *)(*local_20)(local_20);
      }
      if ((int)(uint)*(byte *)(*(int *)(param_1 + 0x18) + iVar1 * 0x10 + 0xc) >> 4 != 2) {
        if (*param_4 == (code *)0x0) {
          *param_4 = local_20;
        }
        return 1;
      }
      if (param_4[2] == (code *)0x0) {
        param_4[2] = local_20;
      }
      local_12 = 1;
    }
    if (local_18 != 0) {
      local_28 = (code *)(*(int *)(*(int *)(param_1 + 0x18) + local_18 * 0x10 + 4) +
                         *(int *)(param_1 + 0x28));
      if ((*(byte *)(*(int *)(param_1 + 0x18) + local_18 * 0x10 + 0xc) & 0xf) == 10) {
        local_28 = (code *)(*local_28)(local_28);
      }
      if ((int)(uint)*(byte *)(*(int *)(param_1 + 0x18) + local_18 * 0x10 + 0xc) >> 4 == 2) {
        if (param_4[2] == (code *)0x0) {
          param_4[2] = local_28;
        }
      }
      else if (param_4[1] == (code *)0x0) {
        param_4[1] = local_28;
      }
      local_12 = 1;
    }
    local_11 = local_12 & 1;
  }
  return local_11;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060090 FUN_00060090 */

undefined8
FUN_00060090(char *param_1,int param_2,char **param_3,char **param_4,char **param_5,char **param_6)

{
  char **ppcVar1;
  char *local_24;
  char *local_20;
  int local_1c;
  char *local_14;
  
  *param_3 = (char *)0x0;
  *param_4 = (char *)0x0;
  *param_6 = (char *)0x0;
  *param_5 = (char *)0x0;
  local_1c = 0;
  local_20 = (char *)0x0;
  local_24 = param_1;
  ppcVar1 = param_5;
  do {
    if (param_1 + param_2 <= local_24) {
      local_14 = (char *)0x0;
LAB_00060223:
      return CONCAT44(ppcVar1,local_14);
    }
    ppcVar1 = (char **)(&DAT_000e0e28 + (&switchD_00060133::switchdataD_000638f0)[*local_24 + -9]);
    switch(*local_24) {
    case '\t':
    case ' ':
      local_20 = (char *)0x0;
      break;
    case '\n':
    case '\r':
      *local_24 = '\0';
      local_14 = local_24 + (1 - (int)param_1);
      goto LAB_00060223;
    default:
switchD_00060133_caseD_b:
      if (local_20 == (char *)0x0) {
        local_20 = local_24;
        ppcVar1 = (char **)(&DAT_000e0e28 + (&switchD_000601a5::switchdataD_00063984)[local_1c]);
        switch(local_1c) {
        case 0:
          *param_3 = local_24;
          break;
        case 1:
          *param_4 = local_24;
          break;
        case 2:
          if (param_1 + param_2 < local_24 + 4) {
            local_14 = (char *)0x0;
            goto LAB_00060223;
          }
          *param_5 = local_24;
          break;
        case 6:
          *param_6 = local_24;
        }
        local_1c = local_1c + 1;
      }
      break;
    case '-':
      if (local_1c != 1) goto switchD_00060133_caseD_b;
      local_20 = (char *)0x0;
    }
    local_24 = local_24 + 1;
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060230 FUN_00060230 */

undefined8 FUN_00060230(char *param_1)

{
  char local_15;
  uint local_14;
  uint local_10;
  char *local_c;
  
  local_10 = 0;
  local_14 = 0;
  for (local_c = param_1; *local_c != '\0'; local_c = local_c + 1) {
    local_15 = *local_c;
    if ((local_15 < 'a') || ('f' < local_15)) {
      if ((local_15 < 'A') || ('F' < local_15)) {
        if ((local_15 < '0') || ('9' < local_15)) break;
        local_15 = local_15 + -0x30;
      }
      else {
        local_15 = local_15 + -0x37;
      }
    }
    else {
      local_15 = local_15 + -0x57;
    }
    local_10 = local_10 << 4 | local_14 >> 0x1c | (int)local_15 >> 0x1f;
    local_14 = local_14 << 4 | (int)local_15;
  }
  return CONCAT44(local_10,local_14);
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060340 FUN_00060340 */

undefined4 FUN_00060340(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_14;
  
  local_14 = 0;
  if (*(int *)(param_1 + 0x30) == 0) {
    if (*(int *)(param_1 + 0x2c) != 0) {
      local_14 = FUN_00060650(param_1,param_2,param_3);
    }
  }
  else {
    local_14 = FUN_000603e0(param_1,param_2,param_3);
  }
  return local_14;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000603e0 FUN_000603e0 */

uint FUN_000603e0(int param_1,undefined4 *param_2,uint *param_3)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint local_38;
  
  iVar1 = *(int *)(param_1 + 0x18);
  iVar2 = *(int *)(param_1 + 0x1c);
  puVar3 = *(uint **)(param_1 + 0x30);
  uVar4 = *param_2;
  *param_3 = 0;
  uVar8 = FUN_00060830(uVar4);
  uVar5 = puVar3[2];
  uVar6 = *puVar3;
  local_38 = puVar3[uVar5 + uVar8 % *puVar3 + 4];
  uVar7 = puVar3[1];
  if ((uVar7 <= local_38) &&
     (uVar10 = 1 << ((byte)uVar8 & 0x1f) | 1 << ((byte)(uVar8 >> ((byte)puVar3[3] & 0x1f)) & 0x1f),
     (puVar3[(uVar8 >> 5) % puVar3[2] + 4] & uVar10) == uVar10)) {
    while( true ) {
      if ((((uVar8 & 0xfffffffe) == (puVar3[uVar5 + uVar6 + (local_38 - uVar7) + 4] & 0xfffffffe))
          && (*(short *)(iVar1 + local_38 * 0x10 + 0xe) != 0)) &&
         (iVar9 = FUN_00013c60(iVar2 + *(int *)(iVar1 + local_38 * 0x10),*param_2), iVar9 == 0)) {
        if (param_2[1] == 0) {
          return local_38;
        }
        uVar10 = FUN_00060890(param_1,param_2,local_38);
        if ((uVar10 & 1) != 0) {
          return local_38;
        }
        *param_3 = local_38;
      }
      if (((puVar3[uVar5 + uVar6 + (local_38 - uVar7) + 4] & 1) != 0) &&
         (puVar3[uVar5 + uVar6 + (local_38 - uVar7) + 4] !=
          puVar3[uVar5 + uVar6 + (local_38 - uVar7) + 5])) break;
      local_38 = local_38 + 1;
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060650 FUN_00060650 */

uint FUN_00060650(int param_1,undefined4 *param_2,uint *param_3)

{
  uint *puVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint *puVar9;
  int local_30;
  uint local_28;
  
  puVar1 = *(uint **)(param_1 + 0x2c);
  iVar2 = *(int *)(param_1 + 0x18);
  uVar3 = *param_2;
  iVar7 = param_1;
  puVar8 = param_2;
  puVar9 = param_3;
  uVar4 = FUN_0005eb00(uVar3);
  uVar6 = *puVar1;
  *param_3 = 0;
  for (local_30 = 0; local_30 != 4; local_30 = local_30 + 1) {
    if ((uVar4 == *(uint *)(&DAT_000e0eb0 + local_30 * 0xc)) &&
       (iVar5 = FUN_00013c60(uVar3,*(undefined4 *)(&DAT_000e0eac + local_30 * 0xc)), iVar5 == 0)) {
      return -local_30;
    }
  }
  local_28 = puVar1[uVar4 % uVar6 + 2];
  do {
    if (local_28 == 0) {
      return 0;
    }
    if ((*(short *)(iVar2 + local_28 * 0x10 + 0xe) != 0) &&
       (iVar5 = FUN_00013c60(*(int *)(param_1 + 0x1c) + *(int *)(iVar2 + local_28 * 0x10),uVar3),
       iVar5 == 0)) {
      if (param_2[1] == 0) {
        return local_28;
      }
      uVar6 = FUN_00060890(param_1,param_2,local_28,iVar7,puVar8,puVar9);
      if ((uVar6 & 1) != 0) {
        return local_28;
      }
      *param_3 = local_28;
    }
    local_28 = puVar1[*puVar1 + local_28 + 2];
  } while( true );
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060830 FUN_00060830 */

int FUN_00060830(byte *param_1)

{
  int local_c;
  byte local_5;
  
  local_c = 0x1505;
  local_5 = *param_1;
  while (local_5 != 0) {
    local_c = local_c * 0x21 + (uint)local_5;
    local_5 = param_1[1];
    param_1 = param_1 + 1;
  }
  return local_c;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060890 FUN_00060890 */

undefined FUN_00060890(int param_1,int param_2,int param_3)

{
  int iVar1;
  int local_18;
  
  if ((*(int *)(param_1 + 0x20) != 0) && (*(int *)(param_1 + 0x24) != 0)) {
    local_18 = *(int *)(param_1 + 0x24);
    while( true ) {
      if (((*(ushort *)(local_18 + 2) & 1) == 0) &&
         ((*(ushort *)(*(int *)(param_1 + 0x20) + param_3 * 2) & 0x7fff) ==
          *(ushort *)(local_18 + 4))) {
        if ((*(int *)(param_2 + 8) == *(int *)(local_18 + 8)) &&
           (iVar1 = FUN_00013c60(*(undefined4 *)(param_2 + 4),
                                 *(int *)(param_1 + 0x1c) +
                                 *(int *)(local_18 + *(int *)(local_18 + 0xc))), iVar1 == 0)) {
          return 1;
        }
        return 0;
      }
      if (*(int *)(local_18 + 0x10) == 0) break;
      local_18 = local_18 + *(int *)(local_18 + 0x10);
    }
  }
  return 0;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00060bc0 entry */

void __regparm3 entry(undefined4 param_1,undefined4 param_2)

{
  byte in_CF;
  byte in_PF;
  byte in_AF;
  byte in_ZF;
  byte in_SF;
  byte in_TF;
  byte in_IF;
  byte in_OF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  uint uVar1;
  
  uVar1 = (uint)(in_NT & 1) * 0x4000 | (uint)(in_OF & 1) * 0x800 | (uint)(in_IF & 1) * 0x200 |
          (uint)(in_TF & 1) * 0x100 | (uint)(in_SF & 1) * 0x80 | (uint)(in_ZF & 1) * 0x40 |
          (uint)(in_AF & 1) * 0x10 | (uint)(in_PF & 1) * 4 | (uint)(in_CF & 1) |
          (uint)(in_ID & 1) * 0x200000 | (uint)(in_VIP & 1) * 0x100000 |
          (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  FUN_00013087();
  LOCK();
  UNLOCK();
  FUN_0001308c(uVar1,param_2);
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000629e5 FUN_000629e5 */

void FUN_000629e5(void)

{
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 000629ea FUN_000629ea */

void FUN_000629ea(void)

{
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  thunk_FUN_0004db40();
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00063b7e FUN_00063b7e */

void FUN_00063b7e(void)

{
  return;
}



/* Inferred Ghidra pseudocode, NOT original source or independently buildable C/C++.
 * Names, types and control flow may be incomplete. Protected/VM logic is not automatically recovered.
 * Snapshot variants use supplied emulation-derived bytes and modeled import addresses.
 * No current APK/game execution or feature verification was performed.
 */

/* Function 00063b83 FUN_00063b83 */

undefined4 __regparm3 FUN_00063b83(undefined4 param_1)

{
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
  LOCK();
  UNLOCK();
                    /* WARNING: Treating indirect jump as return */
  return param_1;
}

