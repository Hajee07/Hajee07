# NX APK — recovery result

**Full original source code recover aagala. Indha package verified partial recovery.**

Pudhusa seythathu:
- APK-oda 159 original files exact-aa extract panni hash verify panniyirukkom.
- Available loader Java, complete on-disk Smali, resources recover panniyirukkom.
- Loader-oda 77 encoded string call sites readable-aa decode panniyirukkom.
- 7 native libraries-kku symbols, strings, instruction disassembly irukku.
- 7716 native function attempts-la 7677 C-like pseudocode outputs;
  39 initial decompilation failures. Idhu game-feature count illai.
- Per-function status/warnings irukku. Important large functions-ku separate retry result irukku.
- Neenga anuppina 345 previous recovery files-um separate-aa unchanged preserve panniyirukkom.

Main problem:
Disk DEX-la 4 loader/protection classes mattum irukku. Original MainActivity/Menu
implementations parsed class table-la illai. 781 KB opaque protected payload irukku.
Adhai decode/devirtualize seytha full source indha run-la kidaikkala.

Mudhalil `RECOVERY-REPORT.md`, appuram
`06_native_pseudocode/libNOVA_MENU.so/ALL_FUNCTIONS.c`,
`06_native_pseudocode/libNOVAXITERS.so/ALL_FUNCTIONS.c`,
`05_analysis/jni_function_index.json` open pannunga.

`.c` = inferred pseudocode; `.asm`/Smali = disassembly;
`04_supplied_prior_recovery` = unga old recovery, pudhu result illai.
Idhu original Android Studio project allathu ready-to-build working APK illai.
Game functions working-nu live test pannala. Invent panna source files include pannala.
