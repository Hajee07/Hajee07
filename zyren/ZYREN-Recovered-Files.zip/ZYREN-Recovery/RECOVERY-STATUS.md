# ZYREN recovery status

This folder preserves the available APK contents and supplied partial recovery.
It is not a claim of 100% original source recovery or verified app functionality.

- `original/NX-original.apk`: original supplied APK, 6,321,031 bytes; SHA-256
  `55e3514b0ba0be5658a64d07771644c41fe4ffad5009a6d3f363be28c2dc4644`.
- `original_apk_entries/`: **159/159 packaged APK files**, extracted byte-for-byte
  and independently checked against every size and SHA-256 in the supplied
  `original_entries.json`. This includes the protected/encrypted bytes as stored.
- `recovered_code/`: an unchanged copy of the supplied code-only recovery tree,
  including loader Java/Smali, recovered menu definitions, inferred native
  pseudocode and provenance/quality reports. These are not a buildable original
  Android source project. No supplied recovery script was executed for this copy.
- `reports/`: independent audit, missing-file manifest and exact priority paths
  needed from the larger uploaded ZIP.

## What remains missing

The parsed DEX defines four protection/loader classes. Original
`com.NovaX.MainActivity` and `com.NovaX.Menu` implementations remain unrecovered.
A 781,311-byte `VBPD` trailer remains opaque. Original source names/comments,
Gradle/CMake configuration and complete protected gameplay implementations have
not been recovered. Native C-like decompiler outputs can contain inferred types,
unresolved control flow and failures; they do not prove original-source recovery.

Only **37/345 prior-recovery files** are present in the code-only ZIP; all 37
match the supplied hashes. The larger ZIP exceeded the tool's 32 MiB transfer
limit. A priority missing subset is **49 files / 10,146,642 bytes**, consisting of
`native_memory/` and `loader_analysis/current_android_evidence/`. Their exact
paths and expected hashes are listed in `reports/NEEDED-FROM-LARGE-ZIP.txt`.
These include both full emulation snapshots and prior crash/logcat/DEX evidence.

## Rebuild and branding boundary

A binary-preserving APK rebuild can retain the packaged code while changing
visible branding. This does not recover the hidden original source or establish
that startup or game features work. Native JNI exports use `com.NovaX`; renaming
packages/classes globally without compatible native rebinding would break them.
Protection checks may also depend on signatures/resources. Read the build's own
validation report for what was actually built and tested.
